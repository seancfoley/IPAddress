exports.open = function() {
    var open = require('open');
    open('https://github.com/seancfoley/IPAddress/');
}
exports.open();
