/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierStringValidator } from './format/validate/HostIdentifierStringValidator';
import { MACAddressProvider } from './format/validate/MACAddressProvider';
import { Validator } from './format/validate/Validator';
import { MACAddress } from './mac/MACAddress';
import { HostIdentifierString } from './HostIdentifierString';
import { MACAddressStringParameters } from './MACAddressStringParameters';
import { IPAddress } from './IPAddress';
import { AddressStringException } from './AddressStringException';
import { IncompatibleAddressException } from './IncompatibleAddressException';
import { IPAddressString } from './IPAddressString';

/**
 * @param {string} addr the address in string format
 * 
 * This constructor allows you to alter the default validation options.
 * @param {MACAddressStringParameters} valOptions
 * @class
 * @author sfoley
 */
export class MACAddressString implements HostIdentifierString {
    static serialVersionUID : number = 4;

    static DEFAULT_BASIC_VALIDATION_OPTIONS : MACAddressStringParameters; public static DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$() : MACAddressStringParameters { if(MACAddressString.DEFAULT_BASIC_VALIDATION_OPTIONS == null) MACAddressString.DEFAULT_BASIC_VALIDATION_OPTIONS = new MACAddressStringParameters.Builder().toParams(); return MACAddressString.DEFAULT_BASIC_VALIDATION_OPTIONS; };

    public static EMPTY_ADDRESS : MACAddressString; public static EMPTY_ADDRESS_$LI$() : MACAddressString { if(MACAddressString.EMPTY_ADDRESS == null) MACAddressString.EMPTY_ADDRESS = new MACAddressString(""); return MACAddressString.EMPTY_ADDRESS; };

    public static ALL_ADDRESSES : MACAddressString; public static ALL_ADDRESSES_$LI$() : MACAddressString { if(MACAddressString.ALL_ADDRESSES == null) MACAddressString.ALL_ADDRESSES = new MACAddressString(IPAddress.SEGMENT_WILDCARD_STR_$LI$()); return MACAddressString.ALL_ADDRESSES; };

    validationOptions : MACAddressStringParameters;

    fullAddr : string;

    /*private*/ cachedException : AddressStringException;

    /*private*/ parsedAddress : MACAddressProvider;

    /*private*/ __isValid : boolean;

    public constructor(addr? : any, valOptions? : any) {
        if(((typeof addr === 'string') || addr === null) && ((valOptions != null && valOptions instanceof <any>MACAddressStringParameters) || valOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.cachedException===undefined) this.cachedException = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.__isValid===undefined) this.__isValid = null;
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.cachedException===undefined) this.cachedException = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.__isValid===undefined) this.__isValid = null;
            (() => {
                if(addr == null) {
                    this.fullAddr = addr = "";
                } else {
                    addr = addr.trim();
                    this.fullAddr = addr;
                }
                this.validationOptions = valOptions;
            })();
        } else if(((typeof addr === 'string') || addr === null) && valOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let valOptions : any = MACAddressString.DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$();
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.fullAddr===undefined) this.fullAddr = null;
                if(this.cachedException===undefined) this.cachedException = null;
                if(this.parsedAddress===undefined) this.parsedAddress = null;
                if(this.__isValid===undefined) this.__isValid = null;
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.fullAddr===undefined) this.fullAddr = null;
                if(this.cachedException===undefined) this.cachedException = null;
                if(this.parsedAddress===undefined) this.parsedAddress = null;
                if(this.__isValid===undefined) this.__isValid = null;
                (() => {
                    if(addr == null) {
                        this.fullAddr = addr = "";
                    } else {
                        addr = addr.trim();
                        this.fullAddr = addr;
                    }
                    this.validationOptions = valOptions;
                })();
            }
        } else if(((addr != null && addr instanceof <any>MACAddress) || addr === null) && valOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.cachedException===undefined) this.cachedException = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.__isValid===undefined) this.__isValid = null;
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.cachedException===undefined) this.cachedException = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.__isValid===undefined) this.__isValid = null;
            (() => {
                this.validationOptions = null;
                this.fullAddr = address.toNormalizedString();
                this.initByAddress(address);
            })();
        } else throw new Error('invalid overload');
    }

    cacheAddress(address : MACAddress) {
        this.initByAddress(address);
    }

    initByAddress(address : MACAddress) {
        this.parsedAddress = new MACAddressProvider(address);
        this.__isValid = true;
    }

    public getValidationOptions() : MACAddressStringParameters {
        return this.validationOptions;
    }

    /**
     * @return {boolean} whether this address represents the set of all addresses with the same prefix
     */
    public isPrefixed() : boolean {
        let addr : MACAddress = this.getAddress();
        return addr != null && addr.isPrefixed();
    }

    /**
     * @return {number} if this address is a valid prefixed address this returns that prefix length, otherwise returns null
     */
    public getPrefixLength() : number {
        let addr : MACAddress = this.getAddress();
        if(addr != null) {
            return addr.getPrefixLength();
        }
        return null;
    }

    /**
     * @return {boolean} whether the address represents the set all all valid MAC addresses
     */
    public isAllAddresses() : boolean {
        let addr : MACAddress = this.getAddress();
        return addr != null && addr.isAllAddresses();
    }

    /**
     * Returns true if the address is empty (zero-length).
     * @return
     * @return {boolean}
     */
    public isEmpty() : boolean {
        return this.isValid() && this.getAddress() == null;
    }

    public isZero() : boolean {
        let value : MACAddress = this.getAddress();
        return value != null && value.isZero();
    }

    /**
     * @return {boolean} whether the address represents one of the accepted address types, which are:
     * a MAC address, the address representing all addresses of all types, or an empty string.
     * If it does not, and you want more details, call validate() and examine the thrown exception.
     */
    public isValid() : boolean {
        if(this.__isValid == null) {
            try {
                this.validate();
                return true;
            } catch(e) {
                return false;
            };
        }
        return this.__isValid;
    }

    /*private*/ isValidated() : boolean {
        if(this.__isValid != null) {
            if(this.cachedException != null) {
                throw this.cachedException;
            }
            return true;
        }
        return false;
    }

    public validate(version? : any) : any {
        if(version === undefined) {
            return <any>this.validate$();
        } else throw new Error('invalid overload');
    }

    public validate$() {
        if(this.isValidated()) {
            return;
        }
        {
            if(this.isValidated()) {
                return;
            }
            try {
                this.parsedAddress = this.getValidator()['validateAddress$inet_ipaddr_MACAddressString'](this);
                this.__isValid = true;
            } catch(e) {
                this.cachedException = e;
                this.__isValid = false;
                throw e;
            };
        };
    }

    getValidator() : HostIdentifierStringValidator {
        return Validator.VALIDATOR_$LI$();
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        if(this.isValid() && !this.isEmpty()) {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.getAddress()));
        }
        return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.toString()));
    }

    /**
     * 
     * @param {MACAddressString} other
     * @return {number}
     */
    public compareTo(other : MACAddressString) : number {
        if(this === other) {
            return 0;
        }
        if(this.isValid()) {
            if(other.isValid()) {
                if(this.isEmpty()) {
                    if(other.isEmpty()) {
                        return 0;
                    }
                    return -1;
                } else if(other.isEmpty()) {
                    return 1;
                }
                return this.getAddress().compareTo(other.getAddress());
            }
            return 1;
        }
        if(other.isValid()) {
            return -1;
        }
        return /* compareTo */this.toString().localeCompare(other.toString());
    }

    /**
     * Two MACAddressString objects are equal if they represent the same set of addresses.
     * 
     * If a MACAddressString is invalid, it is equal to another address only if the other address was constructed from the same string.
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>MACAddressString) {
            let other : MACAddressString = <MACAddressString>o;
            if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.toString(),other.toString()))) {
                return true;
            }
            if(this.isEmpty()) {
                return other.isEmpty();
            }
            if(this.isValid() && other.isValid()) {
                return this.getAddress().equals(other.getAddress());
            }
        }
        return false;
    }

    public getAddress(version? : any) : any {
        if(version === undefined) {
            return <any>this.getAddress$();
        } else throw new Error('invalid overload');
    }

    public getAddress$() : MACAddress {
        if(this.isValid()) {
            return this.parsedAddress.getAddress();
        }
        return null;
    }

    public toAddress(version? : any) : any {
        if(version === undefined) {
            return <any>this.toAddress$();
        } else throw new Error('invalid overload');
    }

    public toAddress$() : MACAddress {
        this.validate();
        return this.parsedAddress.getAddress();
    }

    public toNormalizedString(wildcard? : any) : any {
        if(wildcard === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        let addr : MACAddress = this.getAddress();
        if(addr != null) {
            return addr.toNormalizedString();
        }
        return this.toString();
    }

    /**
     * Gives us the original string provided to the constructor.  For variations, call {@link #getAddress()}/{@link #toAddress()} and then use string methods on the address object.
     * @return {string}
     */
    public toString() : string {
        return this.fullAddr;
    }

    /**
     * Given a string with comma delimiters to denote segment elements, this method will count the possible combinations.
     * 
     * For example, given "1,2:3:4,5:6:7:8", this method will return 4 for the possible combinations: "1:3:4:6:7:8", "1:3:5:6:7:8", "2:3:4:6:7:8" and "2:3:5:6:7:8"
     * 
     * @param {string} str
     * @return
     * @return {number}
     */
    public static countDelimitedAddresses(str : string) : number {
        return IPAddressString.countDelimitedAddresses(str);
    }

    /**
     * Given a string with comma delimiters to denote segment elements, this method will provide an iterator to iterate through the possible combinations.
     * 
     * 
     * For example, given "1,2:3:4,5:6:7:8" this will iterate through "1:3:4:6:7:8", "1:3:5:6:7:8", "2:3:4:6:7:8" and "2:3:5:6:7:8"
     * 
     * Another example: "1-2,3:4:5:6:7:8" will iterate through "1-2:4:5:6:7:8" and "1-3:4:5:6:7:8"
     * 
     * This method will not validate strings.  Each string produced can be validated using an instance of MACAddressString.
     * 
     * @param {string} str
     * @return
     * @return {*}
     */
    public static parseDelimitedSegments(str : string) : any {
        return IPAddressString.parseDelimitedSegments(str);
    }
}
MACAddressString["__class"] = "inet.ipaddr.MACAddressString";
MACAddressString["__interfaces"] = ["java.lang.Comparable","inet.ipaddr.HostIdentifierString","java.io.Serializable"];





MACAddressString.ALL_ADDRESSES_$LI$();

MACAddressString.EMPTY_ADDRESS_$LI$();

MACAddressString.DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$();
