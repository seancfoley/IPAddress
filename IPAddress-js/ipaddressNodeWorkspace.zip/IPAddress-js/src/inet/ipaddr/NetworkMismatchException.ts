/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressStringException } from './AddressStringException';

export class NetworkMismatchException extends Error {
    static serialVersionUID : number = 1;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(NetworkMismatchException.errorMessage == null) NetworkMismatchException.errorMessage = this.message; return NetworkMismatchException.errorMessage; };

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(one? : any, two? : any) {
        if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || two === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(one + ", " + two + ", " + NetworkMismatchException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + two + ", " + NetworkMismatchException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, NetworkMismatchException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && two === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(one + ", " + NetworkMismatchException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + NetworkMismatchException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, NetworkMismatchException.prototype);
        } else throw new Error('invalid overload');
    }
}
NetworkMismatchException["__class"] = "inet.ipaddr.NetworkMismatchException";
NetworkMismatchException["__interfaces"] = ["java.io.Serializable"];





NetworkMismatchException.errorMessage_$LI$();
