/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressSegmentSeries } from './AddressSegmentSeries';

/**
 * @author sfoley
 * @class
 */
export interface AddressSection extends AddressSegmentSeries {
    contains(other? : any) : any;

    /**
     * 
     * @return {*}
     */
    getLower() : AddressSection;

    /**
     * 
     * @return {*}
     */
    getUpper() : AddressSection;

    /**
     * 
     * @return {*}
     */
    reverseSegments() : AddressSection;

    /**
     * 
     * @param {boolean} perByte
     * @return {*}
     */
    reverseBits(perByte? : any) : any;

    reverseBytes(perSegment? : any) : any;

    /**
     * 
     * @return {*}
     */
    reverseBytesPerSegment() : AddressSection;

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddressSection}
     */
    toPrefixBlock(networkPrefixLength? : any) : any;

    /**
     * 
     * @param {boolean} zeroed
     * @return {*}
     */
    removePrefixLength(zeroed? : any) : any;

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {*}
     */
    adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any;

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {*}
     */
    adjustPrefixLength(adjustment? : any, zeroed? : any) : any;

    setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any;

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {*}
     */
    applyPrefixLength(networkPrefixLength : number) : AddressSection;

    /**
     * 
     * @return {*}
     */
    getIterable() : java.lang.Iterable<any>;

    iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any;

    prefixBlockIterator(original? : any, creator? : any) : any;

    /**
     * 
     * @param {number} increment
     * @return {*}
     */
    increment(increment : number) : AddressSection;

    /**
     * 
     * @param {number} increment
     * @return {*}
     */
    incrementBoundary(increment : number) : AddressSection;
}


