/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressStringException } from './AddressStringException';

/**
 * Represents situations when an address, address section, address segment, or address string represents a valid type or format but
 * that type does not match the required type or format for a given operation.
 * 
 * All such occurrences occur only from subnet addresses and sections.
 * 
 * Examples include:
 * <ul>
 * <li>producing non-segmented hex, octal or base 85 strings from a subnet with a range that cannot be represented as a single range of values,
 * </li><li>masking multiple addresses in a way that produces a non-contiguous range of values in a segment,
 * </li><li>reversing values that are not reversible,
 * </li><li>producing new formats for which the range of values are incompatible with the new segments
 * (EUI-64, IPv4 inet_aton formats, IPv4 embedded within IPv6, dotted MAC addresses from standard mac addresses, reverse DNS strings),
 * or
 * </li><li>using a subnet for an operation that requires a single address, such as with @link {@link IPAddress#toCanonicalHostName()}.
 * </li></ul>
 * These issues cannot occur with single-valued address objects.  In most cases, these issues cannot occur when using a standard prefix block subnet.
 * 
 * @author sfoley
 * @param {*} one
 * @param {number} oneIndex
 * @param {*} two
 * @param {number} twoIndex
 * @param {string} key
 * @class
 * @extends Error
 */
export class IncompatibleAddressException extends Error {
    static serialVersionUID : number = 4;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(IncompatibleAddressException.errorMessage == null) IncompatibleAddressException.errorMessage = this.message; return IncompatibleAddressException.errorMessage; };

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(one? : any, oneIndex? : any, two? : any, twoIndex? : any, key? : any) {
        if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((typeof oneIndex === 'number') || oneIndex === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || two === null) && ((typeof twoIndex === 'number') || twoIndex === null) && ((typeof key === 'string') || key === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((oneIndex + 1) + ":" + one + ", " + (twoIndex + 1) + ":" + two + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=(oneIndex + 1) + ":" + one + ", " + (twoIndex + 1) + ":" + two + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((oneIndex != null && (oneIndex["__interfaces"] != null && oneIndex["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || oneIndex.constructor != null && oneIndex.constructor["__interfaces"] != null && oneIndex.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || oneIndex === null) && ((typeof two === 'string') || two === null) && twoIndex === undefined && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let two : any = __args[1];
            let key : any = __args[2];
            super(one + ", " + two + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + two + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((typeof oneIndex === 'number') || oneIndex === null) && ((typeof two === 'string') || two === null) && twoIndex === undefined && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefixLength : any = __args[1];
            let key : any = __args[2];
            super(one + " /" + prefixLength + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=one + " /" + prefixLength + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else if(((typeof one === 'number') || one === null) && ((typeof oneIndex === 'number') || oneIndex === null) && ((typeof two === 'string') || two === null) && twoIndex === undefined && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lower : any = __args[0];
            let upper : any = __args[1];
            let key : any = __args[2];
            super(lower + "-" + upper + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=lower + "-" + upper + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((typeof oneIndex === 'string') || oneIndex === null) && two === undefined && twoIndex === undefined && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[1];
            super(one + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof one === "string")) || one === null) && ((typeof oneIndex === 'string') || oneIndex === null) && two === undefined && twoIndex === undefined && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[1];
            super(one + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + IncompatibleAddressException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, IncompatibleAddressException.prototype);
        } else throw new Error('invalid overload');
    }
}
IncompatibleAddressException["__class"] = "inet.ipaddr.IncompatibleAddressException";
IncompatibleAddressException["__interfaces"] = ["java.io.Serializable"];





IncompatibleAddressException.errorMessage_$LI$();
