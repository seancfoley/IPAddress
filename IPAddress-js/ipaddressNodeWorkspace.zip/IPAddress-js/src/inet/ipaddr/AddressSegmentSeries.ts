/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivisionSeries } from './format/AddressDivisionSeries';
import { AddressComponent } from './AddressComponent';
import { AddressNetwork } from './AddressNetwork';
import { AddressSection } from './AddressSection';
import { AddressSegment } from './AddressSegment';

/**
 * Represents a series of address segments, each of equal byte size, the byte size being a whole number of bytes.
 * 
 * Each segment can potentially range over multiple values, and thus this series of segments can represent many different values as well.
 * 
 * 
 * @author sfoley
 * @class
 */
export interface AddressSegmentSeries extends AddressDivisionSeries, AddressComponent {
    /**
     * Returns the network object for series of the same version (eg IPv4, IPv6 and MAC each have their own network object)
     * @return
     * @return {AddressNetwork}
     */
    getNetwork() : AddressNetwork<any>;

    /**
     * Returns the number of segments in this series.
     * @return
     * @return {number}
     */
    getSegmentCount() : number;

    /**
     * Returns the number of bits comprising each segment in this series.  Segments in the same series are equal length.
     * @return
     * @return {number}
     */
    getBitsPerSegment() : number;

    /**
     * Returns the number of bytes comprising each segment in this series.  Segments in the same series are equal length.
     * @return
     * @return {number}
     */
    getBytesPerSegment() : number;

    /**
     * Gets the subsection from the series starting from the given index and ending just before the give endIndex
     * 
     * @throws IndexOutOfBoundsException if index is negative or endIndex extends beyond the end of the series
     * @param {number} index
     * @param {number} endIndex
     * @return
     * @return {*}
     */
    getSection(index? : any, endIndex? : any) : any;

    /**
     * Returns the segment from this series at the given index.
     * 
     * @throws IndexOutOfBoundsException if the index is negative or as large as the segment count
     * 
     * @return
     * @param {number} index
     * @return {*}
     */
    getSegment(index : number) : AddressSegment;

    /**
     * Returns the an array with the values of each segment as they would appear in the normalized with wildcards string.
     * 
     * @return
     * @return {Array}
     */
    getSegmentStrings() : string[];

    /**
     * get the segments from start to end and insert into the segs array at the the given index
     * @param {number} start the first segment index from this series to be included
     * @param {number} end the first segment index to be excluded
     * @param {Array} segs the target array
     * @param {number} index where to insert the segments in the segs array
     */
    getSegments(start? : any, end? : any, segs? : any, index? : any) : any;

    /**
     * If this represents a series with ranging values, returns a series representing the lower values of the range.
     * If this represents an series with a single value in each segment, returns this.
     * 
     * @return
     * @return {*}
     */
    getLower() : AddressSegmentSeries;

    /**
     * If this represents a series with ranging values, returns a series representing the upper values of the range
     * If this represents a series with a single value in each segment, returns this.
     * 
     * @return
     * @return {*}
     */
    getUpper() : AddressSegmentSeries;

    /**
     * 
     * @return {*}
     */
    getIterable() : java.lang.Iterable<any>;

    iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any;

    prefixBlockIterator(original? : any, creator? : any) : any;

    segmentsIterator(excludeZeroHosts? : any) : any;

    /**
     * Returns the series from the subnet that is the given increment upwards into the subnet range, with the increment of 0
     * returning the first address in the range.
     * 
     * <p>
     * If the subnet has multiple values and the increment exceeds the subnet size, then the
     * amount by which it exceeds the size - 1 is added to the upper series of the range (the final iterator value).
     * <p>
     * If the increment is negative, it is added to the lower series of the range (the first iterator value).
     * <p>
     * This method is equivalent to the combination of {@link #incrementSubnet(long)} with {@link #incrementBoundary(long)}
     * <p>
     * If the subnet is just a single address values, the series is simply incremented by the given value, positive or negative.
     * <p>
     * If a subnet has multiple values, a positive increment value is equivalent to the same number of values from the {@link #iterator()}
     * For instance, a increment of 0 is the first value from the iterator, an increment of 1 is the second value from the iterator, and so on.
     * A negative increment added to the subnet count is equivalent to the same number of values preceding the upper bound of the iterator.
     * For instance, an increment of count - 1 is the last value from the iterator, an increment of count - 2 is the second last value, and so on.
     * <p>
     * An increment of size count gives you the series just above the highest series of the subnet.
     * To get the series just below the lowest series of the subnet, use the increment -1.
     * 
     * @param {number} increment
     * @return
     * @return {*}
     */
    increment(increment : number) : AddressSegmentSeries;

    /**
     * If the given increment is positive, adds the value to the upper series ({@link #getUpper()} in the subnet range to produce a new series.
     * If the given increment is negative, adds the value to the lower series ({@link #getLower()} in the subnet range to produce a new series.
     * If the increment is zero, returns this.
     * <p>
     * In the case where the series is a single value, this simply returns the address produced by adding the given increment to this address series.
     * <p>
     * 
     * @param {number} increment
     * @return
     * @return {*}
     */
    incrementBoundary(increment : number) : AddressSegmentSeries;

    /**
     * Produces the canonical representation of the address
     * @return
     * @return {string}
     */
    toCanonicalString() : string;

    /**
     * Produces a short representation of the address while remaining within the confines of standard representation(s) of the address
     * @return
     * @return {string}
     */
    toCompressedString() : string;

    /**
     * Returns a new segment series with the segments reversed.
     * 
     * This does not throw {@link IncompatibleAddressException} since all address series can reverse their segments.
     * 
     * @return
     * @return {*}
     */
    reverseSegments() : AddressSegmentSeries;

    /**
     * Returns a new segment series with the bits reversed.
     * 
     * @throws IncompatibleAddressException if reversing the bits within a single segment cannot be done
     * because the segment represents a range, and when all values in that range are reversed, the result is not contiguous.
     * 
     * In practice this means that to be reversible the range must include all values except possibly the largest and/or smallest.
     * 
     * @return
     * @param {boolean} perByte
     * @return {*}
     */
    reverseBits(perByte? : any) : any;

    reverseBytes(perSegment? : any) : any;

    /**
     * Returns a new segment series with the bytes reversed within each segment.
     * 
     * @throws IncompatibleAddressException if the segments have more than 1 bytes,
     * and if reversing the bits within a single segment cannot be done because the segment represents a range that is not the entire segment range.
     * 
     * @return
     * @return {*}
     */
    reverseBytesPerSegment() : AddressSegmentSeries;

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    toPrefixBlock(networkPrefixLength? : any) : any;

    /**
     * Removes the prefix length.
     * 
     * @param {boolean} zeroed whether the bits outside the prefix become zero
     * @return
     * @return {*}
     */
    removePrefixLength(zeroed? : any) : any;

    /**
     * Increases or decreases prefix length to the next segment boundary.
     * 
     * @param {boolean} nextSegment whether to move prefix to previous or following segment coundary
     * @param {boolean} zeroed whether the bits that move from one side of the prefix to the other become zero or retain their original values
     * @return
     * @return {*}
     */
    adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any;

    /**
     * Increases or decreases prefix length by the given increment.
     * 
     * @param {boolean} zeroed whether the bits that move from one side of the prefix to the other become zero or retain their original values
     * @param {number} adjustment the increment
     * @return
     * @return {*}
     */
    adjustPrefixLength(adjustment? : any, zeroed? : any) : any;

    setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any;

    /**
     * Applies the given prefix length to create a new segment series.
     * <p>
     * Similar to {@link #setPrefixLength(int)} except that prefix lengths are never increased.
     * When this series already has a prefix length that is less than or equal to the requested prefix length, this series is returned.
     * <p>
     * Otherwise the returned series has the given prefix length.
     * <p>
     * The bits moved outside the prefix will become zero in the returned series.
     * 
     * @see #setPrefixLength(int)
     * @param {number} prefixLength
     * @return
     * @return {*}
     */
    applyPrefixLength(prefixLength : number) : AddressSegmentSeries;
}


