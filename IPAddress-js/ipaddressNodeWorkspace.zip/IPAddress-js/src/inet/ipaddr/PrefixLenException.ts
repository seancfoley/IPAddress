/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressValueException } from './AddressValueException';
import { AddressStringException } from './AddressStringException';
import { IPAddress } from './IPAddress';

export class PrefixLenException extends AddressValueException {
    static __inet_ipaddr_PrefixLenException_serialVersionUID : number = 1;

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(prefixLength? : any, version? : any, cause? : any) {
        if(((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefixLength === "string")) || prefixLength === null) && ((typeof version === 'number') || version === null) && ((cause != null && (cause["__classes"] && cause["__classes"].indexOf("java.lang.Throwable") >= 0) || cause != null && cause instanceof <any>Error) || cause === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(version + " /" + prefixLength + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message, cause);
            (<any>Object).setPrototypeOf(this, PrefixLenException.prototype);
        } else if(((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || prefixLength === null) && ((typeof version === 'number') || version === null) && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let one : any = __args[0];
            let prefixLength : any = __args[1];
            super(one + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, PrefixLenException.prototype);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof version === 'number') || version === null) && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(version + " /" + prefixLength + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, PrefixLenException.prototype);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && version === undefined && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, PrefixLenException.prototype);
        } else throw new Error('invalid overload');
    }
}
PrefixLenException["__class"] = "inet.ipaddr.PrefixLenException";
PrefixLenException["__interfaces"] = ["java.io.Serializable"];




