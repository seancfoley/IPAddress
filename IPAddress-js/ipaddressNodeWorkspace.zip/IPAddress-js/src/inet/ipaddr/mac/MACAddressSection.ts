/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressPositionException } from '../AddressPositionException';
import { AddressSection } from '../AddressSection';
import { AddressSegment } from '../AddressSegment';
import { AddressValueException } from '../AddressValueException';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { AddressBitsDivision } from '../format/AddressBitsDivision';
import { AddressDivision } from '../format/AddressDivision';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { AddressStringDivisionSeries } from '../format/AddressStringDivisionSeries';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { MACAddress } from './MACAddress';
import { MACAddressNetwork } from './MACAddressNetwork';
import { MACAddressSegment } from './MACAddressSegment';
import { AddressNetwork } from '../AddressNetwork';
import { IPAddressSection } from '../IPAddressSection';

export class MACAddressSection extends AddressDivisionGrouping implements AddressSection {
    static __inet_ipaddr_mac_MACAddressSection_serialVersionUID : number = 4;

    static MAX_VALUES_LONG : number[]; public static MAX_VALUES_LONG_$LI$() : number[] { if(MACAddressSection.MAX_VALUES_LONG == null) MACAddressSection.MAX_VALUES_LONG = [0, MACAddress.MAX_VALUE_PER_SEGMENT, 65535, 16777215, 4294967295, 1099511627775, 281474976710655, 72057594037927935]; return MACAddressSection.MAX_VALUES_LONG; };

    static MAX_VALUES : BigInteger[]; public static MAX_VALUES_$LI$() : BigInteger[] { if(MACAddressSection.MAX_VALUES == null) MACAddressSection.MAX_VALUES = [BigInteger.ZERO, BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[1]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[2]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[3]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[4]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[5]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[6]), BigInteger.valueOf(MACAddressSection.MAX_VALUES_LONG_$LI$()[7]), BigInteger.valueOf(1).shiftLeft(64).subtract(BigInteger.ONE)]; return MACAddressSection.MAX_VALUES; };

    static creators : MACAddressNetwork.MACAddressCreator[][]; public static creators_$LI$() : MACAddressNetwork.MACAddressCreator[][] { if(MACAddressSection.creators == null) MACAddressSection.creators = <any> (function(dims) { let allocate = function(dims) { if(dims.length==0) { return null; } else { let array = []; for(let i = 0; i < dims[0]; i++) { array.push(allocate(dims.slice(1))); } return array; }}; return allocate(dims);})([2, MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT]); return MACAddressSection.creators; };

    /*private*/ stringCache : MACAddressSection.MACStringCache;

    /*private*/ sectionCache : AddressDivisionGrouping.SectionCache<MACAddressSection>;

    public addressSegmentIndex : number;

    public extended : boolean;

    public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, startIndex? : any, extended? : any, cloneBytes? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null) && ((typeof cloneBytes === 'boolean') || cloneBytes === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            (() => {
                let segs : MACAddressSegment[] = this.getSegmentsInternal();
                AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                    throw new AddressPositionException(startIndex);
                }
                this.addressSegmentIndex = startIndex;
                this.extended = extended;
                if(bytes.length === segs.length) {
                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && ((typeof startIndex === 'boolean') || startIndex === null) && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segmentCount : any = __args[1];
            let startIndex : any = __args[2];
            let extended : any = __args[3];
            let cloneBytes : any = __args[4];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    let segs : MACAddressSegment[] = this.getSegmentsInternal();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    }
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                    if(bytes.length === segs.length) {
                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let startIndex : any = __args[2];
            let extended : any = __args[3];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(Math.max(0, (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$()) - startIndex)), false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            (() => {
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(this.getSegmentsInternal(), lowerValueProvider, upperValueProvider, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                    throw new AddressPositionException(startIndex);
                }
                this.addressSegmentIndex = startIndex;
                this.extended = extended;
            })();
        } else if(((typeof bytes === 'boolean') || bytes === null) && ((byteStartIndex != null && byteStartIndex instanceof <any>Array && (byteStartIndex.length==0 || byteStartIndex[0] == null ||(byteStartIndex[0] != null && byteStartIndex[0] instanceof <any>MACAddressSegment))) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let cloneSegments : any = __args[0];
            let segments : any = __args[1];
            let startIndex : any = __args[2];
            let extended : any = __args[3];
            super(cloneSegments?/* clone */segments.slice(0):segments);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            (() => {
                this.addressSegmentIndex = startIndex;
                this.extended = extended;
                if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                    throw new AddressPositionException(startIndex);
                } else if(startIndex + segments.length > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                    throw new AddressValueException(segments.length);
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>MACAddressSegment) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segment : any = __args[0];
            let startIndex : any = __args[1];
            let extended : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let cloneSegments : any = false;
                let segments : any = [segment];
                super(cloneSegments?/* clone */segments.slice(0):segments);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    } else if(startIndex + segments.length > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressValueException(segments.length);
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let startIndex : any = __args[1];
            let extended : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let cloneSegments : any = true;
                super(cloneSegments?/* clone */segments.slice(0):segments);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    } else if(startIndex + segments.length > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressValueException(segments.length);
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let startIndex : any = __args[1];
            let extended : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(Math.max(0, (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$()) - startIndex)), false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(this.getSegmentsInternal(), lowerValueProvider, upperValueProvider, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    }
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let startIndex : any = __args[1];
            let extended : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                let segmentCount : any = -1;
                let cloneBytes : any = true;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    let segs : MACAddressSegment[] = this.getSegmentsInternal();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    }
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                    if(bytes.length === segs.length) {
                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                    }
                })();
            }
        } else if(((typeof bytes === 'number') || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            let startIndex : any = __args[1];
            let extended : any = __args[2];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT), false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            (() => {
                if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                    throw new AddressPositionException(startIndex);
                } else if(!extended && (value > 281474976710655 || value < 0)) {
                    throw new AddressValueException(value);
                }
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(this.getSegmentsInternal(), 0, value, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                this.addressSegmentIndex = startIndex;
                this.extended = extended;
            })();
        } else if(((bytes != null && bytes instanceof <any>MACAddressSegment) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segment : any = __args[0];
            super([segment]);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.extended===undefined) this.extended = false;
            (() => {
                this.addressSegmentIndex = 0;
                this.extended = false;
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let startIndex : any = 0;
                let extended : any = __args[0].length > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let cloneSegments : any = true;
                    super(cloneSegments?/* clone */segments.slice(0):segments);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.extended===undefined) this.extended = false;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.extended===undefined) this.extended = false;
                    (() => {
                        this.addressSegmentIndex = startIndex;
                        this.extended = extended;
                        if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                            throw new AddressPositionException(startIndex);
                        } else if(startIndex + segments.length > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                            throw new AddressValueException(segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                let startIndex : any = 0;
                let extended : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(Math.max(0, (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$()) - startIndex)), false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(this.getSegmentsInternal(), lowerValueProvider, upperValueProvider, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    }
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let startIndex : any = 0;
                let extended : any = __args[0].length > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    let segmentCount : any = -1;
                    let cloneBytes : any = true;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.extended===undefined) this.extended = false;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.extended===undefined) this.extended = false;
                    (() => {
                        let segs : MACAddressSegment[] = this.getSegmentsInternal();
                        AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                        if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                            throw new AddressPositionException(startIndex);
                        }
                        this.addressSegmentIndex = startIndex;
                        this.extended = extended;
                        if(bytes.length === segs.length) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    })();
                }
            }
        } else if(((typeof bytes === 'number') || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && startIndex === undefined && extended === undefined && cloneBytes === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let startIndex : any = 0;
                let extended : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT), false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.extended===undefined) this.extended = false;
                (() => {
                    if(startIndex < 0 || startIndex > (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
                        throw new AddressPositionException(startIndex);
                    } else if(!extended && (value > 281474976710655 || value < 0)) {
                        throw new AddressValueException(value);
                    }
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(this.getSegmentsInternal(), 0, value, MACAddress.BITS_PER_SEGMENT, this.getNetwork(), null);
                    this.addressSegmentIndex = startIndex;
                    this.extended = extended;
                })();
            }
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {MACAddressNetwork}
     */
    public getNetwork() : MACAddressNetwork {
        return MACAddress.defaultMACNetwork();
    }

    public getIPv6Network() : IPv6AddressNetwork {
        return MACAddress.defaultIpv6Network();
    }

    public getAddressCreator$int$boolean(startIndex : number, extended : boolean) : MACAddressNetwork.MACAddressCreator {
        let creator : MACAddressNetwork.MACAddressCreator = null;
        let useCached : boolean = startIndex < MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
        let ext : number = 0;
        if(useCached) {
            if(extended) {
                ext = 1;
            }
            creator = MACAddressSection.creators_$LI$()[ext][startIndex];
        }
        if(creator != null) {
            useCached = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(creator.getNetwork(),this.getNetwork())) || useCached;
            if(useCached) {
                return creator;
            }
        }
        creator = new MACAddressSection.MACAddressSection$0(this, this.getNetwork(), startIndex, extended);
        if(useCached) {
            MACAddressSection.creators_$LI$()[ext][startIndex] = creator;
        }
        return creator;
    }

    public getAddressCreator(startIndex? : any, extended? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null)) {
            return <any>this.getAddressCreator$int$boolean(startIndex, extended);
        } else if(startIndex === undefined && extended === undefined) {
            return <any>this.getAddressCreator$();
        } else throw new Error('invalid overload');
    }

    getAddressCreator$() : MACAddressNetwork.MACAddressCreator {
        return this.getAddressCreator$int$boolean(this.addressSegmentIndex, this.extended);
    }

    getSegmentCreator() : AddressNetwork.AddressSegmentCreator<MACAddressSegment> {
        return this.getAddressCreator$int$boolean(0, false);
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>MACAddressSection) {
            let other : MACAddressSection = <MACAddressSection>o;
            return this.addressSegmentIndex === other.addressSegmentIndex && this.isExtended() === other.isExtended() && other.isSameGrouping(this);
        }
        return false;
    }

    getStringCache() : MACAddressSection.MACStringCache {
        return <MACAddressSection.MACStringCache>this.stringCache;
    }

    /**
     * 
     * @param {AddressDivisionGrouping} other
     * @return {boolean}
     */
    isSameGrouping(other : AddressDivisionGrouping) : boolean {
        return (other != null && other instanceof <any>MACAddressSection) && super.isSameGrouping(other);
    }

    public getSegments$() : MACAddressSegment[] {
        return <MACAddressSegment[]>/* clone */this.getDivisionsInternal().slice(0);
    }

    public getSegments$inet_ipaddr_AddressSegment_A(segs : AddressSegment[]) {
        this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, this.getDivisionCount(), segs, 0);
    }

    getSegmentsInternal() : MACAddressSegment[] {
        return <MACAddressSegment[]>super.getDivisionsInternal();
    }

    public getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start : number, end : number, segs : AddressSegment[], destIndex : number) {
        /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(this.getSegmentsInternal(), start, segs, destIndex, end - start);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} destIndex
     */
    public getSegments(start? : any, end? : any, segs? : any, destIndex? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof destIndex === 'number') || destIndex === null)) {
            return <any>this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start, end, segs, destIndex);
        } else if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && (segs instanceof Array)) || segs === null) && destIndex === undefined) {
            return <any>this.getSegments$int$int$java_util_Collection(start, end, segs);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(((start != null && (start instanceof Array)) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$java_util_Collection(start);
        } else if(start === undefined && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    /**
     * @return {boolean} whether this section is part of a larger EUI-64 address.
     */
    public isExtended() : boolean {
        return this.extended;
    }

    /**
     * 
     * @return {number}
     */
    public getSegmentCount() : number {
        return this.getDivisionCount();
    }

    public isEntireAddress(extended : boolean) : boolean {
        return this.getSegmentCount() === (extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT);
    }

    /**
     * 
     * @param {number} index
     * @return {MACAddressSegment}
     */
    public getDivision(index : number) : MACAddressSegment {
        return <MACAddressSegment>super.getDivision(index);
    }

    /**
     * 
     * @param {number} index
     * @return {MACAddressSegment}
     */
    public getSegment(index : number) : MACAddressSegment {
        return <MACAddressSegment>super.getDivision(index);
    }

    public getSegments$java_util_Collection(segs : Array<any>) {
        this.getSegments$int$int$java_util_Collection(0, this.getSegmentCount(), segs);
    }

    public getSegments$int$int$java_util_Collection(start : number, end : number, segs : Array<any>) {
        for(let i : number = start; i < end; i++) {
            /* add */(segs.push(this.getSegment(i))>0);
        };
    }

    /**
     * 
     * @return {number}
     */
    public getBitsPerSegment() : number {
        return MACAddress.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBytesPerSegment() : number {
        return MACAddress.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSegmentCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSegmentCount() << 3;
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        let segmentCount : number = this.getSegmentCount();
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segmentCount);
        for(let i : number = 0; i < segmentCount; i++) {
            let seg : MACAddressSegment = this.getSegment(i);
            let val : number = low?seg.getLowerSegmentValue():seg.getUpperSegmentValue();
            bytes[i] = (<number>val|0);
        };
        return bytes;
    }

    public getCountImpl(excludeZeroHosts? : any) : any {
        if(excludeZeroHosts === undefined) {
            return <any>this.getCountImpl$();
        } else throw new Error('invalid overload');
    }

    getCountImpl$() : BigInteger {
        let segCount : number = this.getSegmentCount();
        if(!this.isMultiple()) {
            return BigInteger.ONE;
        }
        let result : number = this.getSegment(0).getValueCount();
        let limit : number = Math.min(segCount, 7);
        for(let i : number = 1; i < limit; i++) {
            result *= this.getSegment(i).getValueCount();
        };
        if(segCount === 8) {
            let lastValue : number = this.getSegment(7).getValueCount();
            if(lastValue !== 1) {
                if(result <= 36028797018963967) {
                    result *= lastValue;
                } else {
                    return BigInteger.valueOf(result).multiply(BigInteger.valueOf(lastValue));
                }
            }
        }
        return BigInteger.valueOf(result);
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getPrefixCount() : BigInteger {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength == null || prefixLength >= this.getBitCount() || !this.isMultiple()) {
            return this.getCount();
        }
        let result : number = 1;
        let networkSegmentIndex : number = AddressDivisionGrouping.getNetworkSegmentIndex(prefixLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT);
        let hostSegmentIndex : number = AddressDivisionGrouping.getHostSegmentIndex(prefixLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT);
        let i : number = 0;
        for(; i < hostSegmentIndex; i++) {
            result *= this.getSegment(i).getValueCount();
        };
        if(i === networkSegmentIndex) {
            let lastValue : number = this.getSegment(i).getPrefixValueCount(AddressDivisionGrouping.getSegmentPrefixLength$int$java_lang_Integer$int(MACAddress.BITS_PER_SEGMENT, prefixLength, i));
            if(lastValue !== 1) {
                if(result <= 36028797018963967) {
                    result *= lastValue;
                } else {
                    return BigInteger.valueOf(result).multiply(BigInteger.valueOf(lastValue));
                }
            }
        }
        return BigInteger.valueOf(result);
    }

    /**
     * Indicates if the address represents all devices with the same OUI segments.
     * 
     * @return {boolean} true if all the ODI segments are full-range, covering all devices
     */
    public isPrefixed() : boolean {
        return this.getPrefixLength() != null;
    }

    public getOUISegmentCount() : number {
        return Math.max(0, MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_SEGMENT_COUNT - this.addressSegmentIndex);
    }

    public getODISegmentCount() : number {
        return this.getSegmentCount() - this.getOUISegmentCount();
    }

    /**
     * @return {number} the number of bits in the prefix.
     * 
     * The prefix is the smallest bit length x for which all possible values with the same first x bits are included in this range of sections,
     * unless that value x matches the bit count of this section, in which case the prefix is null.
     * 
     * If the prefix is the OUI bit length (24) then the ODI segments cover all possibly values.
     */
    public getPrefixLength() : number {
        let ret : number = this.cachedPrefixLength;
        if(ret == null) {
            let prefix : number = this.getMinPrefixLengthForBlock();
            if(prefix === this.getBitCount()) {
                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                return null;
            }
            return this.cachedPrefixLength = prefix;
        }
        if(ret === AddressDivisionGrouping.NO_PREFIX_LENGTH) {
            return null;
        }
        return ret;
    }

    assignPrefixLength(prefixLength : number) {
        if(prefixLength == null) {
            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            return;
        }
        if(prefixLength < 0) {
            throw new PrefixLenException(prefixLength);
        }
        let max : number = this.getBitCount();
        if(prefixLength > max) {
            let maxPrefixLength : number = this.extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_BIT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT_$LI$();
            if(prefixLength > maxPrefixLength) {
                throw new PrefixLenException(prefixLength);
            }
            prefixLength = max;
        }
        this.cachedPrefixLength = prefixLength;
    }

    public getSection$() : MACAddressSection {
        return this;
    }

    public getSection$int(index : number) : MACAddressSection {
        return this.getSection$int$int(index, this.getSegmentCount());
    }

    public getSection$int$int(index : number, endIndex : number) : MACAddressSection {
        let result : MACAddressSection = <any>(AddressDivisionGrouping.getSection<any, any>(index, endIndex, this, this.getAddressCreator$int$boolean(this.addressSegmentIndex + index, this.extended)));
        let prefix : number = this.getPrefixLength();
        if(prefix != null) {
            if(index > 0) {
                prefix = Math.max(0, prefix - (index << 3));
            }
            if(prefix > ((endIndex - index) << 3)) {
                prefix = null;
            }
        }
        result.assignPrefixLength(prefix);
        return result;
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {MACAddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    public getOUISection() : MACAddressSection {
        let segmentCount : number = this.getOUISegmentCount();
        let result : MACAddressSection = <any>(AddressDivisionGrouping.getSection<any, any>(0, segmentCount, this, this.getAddressCreator()));
        let prefix : number = this.getPrefixLength();
        if(prefix != null) {
            if(prefix > (segmentCount << 3)) {
                prefix = null;
            }
        }
        result.assignPrefixLength(prefix);
        return result;
    }

    public getODISection() : MACAddressSection {
        let segmentCount : number = this.getOUISegmentCount();
        let result : MACAddressSection = <any>(AddressDivisionGrouping.getSection<any, any>(segmentCount, this.getSegmentCount(), this, this.getAddressCreator$int$boolean(this.addressSegmentIndex + segmentCount, this.extended)));
        let prefix : number = this.getPrefixLength();
        if(prefix != null && segmentCount > 0) {
            prefix = Math.max(0, prefix - (segmentCount << 3));
        }
        result.assignPrefixLength(prefix);
        return result;
    }

    /**
     * Returns a section in which the range of values match the block for the OUI (organizationally unique identifier) bytes
     * 
     * @return
     * @return {MACAddressSection}
     */
    public toOUIPrefixBlock() : MACAddressSection {
        let ouiSegmentCount : number = this.getOUISegmentCount();
        let segmentCount : number = this.getSegmentCount();
        let currentPref : number = this.getPrefixLength();
        let newPref : number = ouiSegmentCount << 3;
        let createNew : boolean;
        if(!(createNew = (currentPref == null || currentPref > newPref))) {
            newPref = currentPref;
            for(let i : number = ouiSegmentCount; i < segmentCount; i++) {
                let segment : MACAddressSegment = this.getSegment(i);
                if(!segment.isFullRange()) {
                    createNew = true;
                    break;
                }
            };
        }
        if(createNew) {
            let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
            let allRangeSegment : MACAddressSegment = creator.createRangeSegment(0, MACAddress.MAX_VALUE_PER_SEGMENT);
            let newSegments : MACAddressSegment[] = AddressDivisionGrouping.setPrefixedSegments<any>(this.getNetwork(), newPref, this.getSegments(), MACAddress.BITS_PER_SEGMENT, MACAddress.BYTES_PER_SEGMENT, creator, ((allRangeSegment) => {
                return (seg, prefixLength) => (prefixLength === 0)?allRangeSegment:seg
            })(allRangeSegment));
            let result : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(newSegments);
            result.assignPrefixLength(newPref);
            return result;
        }
        return this;
    }

    /**
     * Converts to Ipv6.  Any MAC prefix length is ignored.  Other elements of this address section are incorporated into the conversion.
     * 
     * @return
     * @return {IPv6AddressSection}
     */
    public toEUI64IPv6() : IPv6AddressSection {
        return this.getIPv6Network().getAddressCreator().createSection$inet_ipaddr_mac_MACAddressSection(this);
    }

    public isEUI64$boolean(asMAC : boolean) : boolean {
        return this.isEUI64$boolean$boolean(asMAC, false);
    }

    public isEUI64$boolean$boolean(asMAC : boolean, partial : boolean) : boolean {
        if(this.isExtended()) {
            let segmentCount : number = this.getSegmentCount();
            let endIndex : number = this.addressSegmentIndex + segmentCount;
            if(this.addressSegmentIndex <= 3) {
                if(endIndex > 4) {
                    let index3 : number = 3 - this.addressSegmentIndex;
                    let seg3 : MACAddressSegment = this.getSegment(index3);
                    let seg4 : MACAddressSegment = this.getSegment(index3 + 1);
                    return seg4.matches$int(asMAC?255:254) && seg3.matches$int(255);
                } else if(partial && endIndex === 4) {
                    let seg3 : MACAddressSegment = this.getSegment(3 - this.addressSegmentIndex);
                    return seg3.matches$int(255);
                }
            } else if(partial && this.addressSegmentIndex === 4 && endIndex > 4) {
                let seg4 : MACAddressSegment = this.getSegment(4 - this.addressSegmentIndex);
                return seg4.matches$int(asMAC?255:254);
            }
            return partial;
        }
        return false;
    }

    /**
     * Whether this section is consistent with an EUI64 section,
     * which means it came from an extended 8 byte address,
     * and the corresponding segments in the middle match 0xff and 0xff/fe for MAC/not-MAC
     * 
     * @param {boolean} partial whether missing segments are considered a match (this only has an effect if this section came from an extended 8 byte address),
     * or in other words, we don't consider 6 byte addresses to be "missing" the bytes that would make it 8 byte.
     * @param {boolean} asMAC whether to search for the ffff or fffe pattern
     * @return
     * @return {boolean}
     */
    public isEUI64(asMAC? : any, partial? : any) : any {
        if(((typeof asMAC === 'boolean') || asMAC === null) && ((typeof partial === 'boolean') || partial === null)) {
            return <any>this.isEUI64$boolean$boolean(asMAC, partial);
        } else if(((typeof asMAC === 'boolean') || asMAC === null) && partial === undefined) {
            return <any>this.isEUI64$boolean(asMAC);
        } else throw new Error('invalid overload');
    }

    /**
     * If this section is part of a shorter 48 bit MAC or EUI-48 address see {@link #isExtended()},
     * then the required sections are inserted (FF-FF for MAC, FF-FE for EUI-48) to extend it to EUI-64.
     * 
     * However, if the section does not encompass the parts of the address where
     * the new sections should be placed, then the section is unchanged.
     * 
     * If the section is already part of an EUI-64 address, then it is checked
     * to see if it has the segments that identify it as extended to EUI-64 (FF-FF for MAC, FF-FE for EUI-48),
     * and if not, {@link IncompatibleAddressException} is thrown.
     * 
     * @param {boolean} asMAC
     * @return
     * @return {MACAddressSection}
     */
    public toEUI64(asMAC : boolean) : MACAddressSection {
        let originalSegmentCount : number = this.getSegmentCount();
        if(!this.isExtended()) {
            let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator$int$boolean(this.addressSegmentIndex, true);
            if(this.addressSegmentIndex + originalSegmentCount < 3 || this.addressSegmentIndex > 3) {
                return this;
            }
            let segs : MACAddressSegment[] = creator.createSegmentArray(originalSegmentCount + 2);
            let frontCount : number;
            if(this.addressSegmentIndex < 3) {
                frontCount = 3 - this.addressSegmentIndex;
                this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, frontCount, segs, 0);
            } else {
                frontCount = 0;
            }
            let ffSegment : MACAddressSegment = creator.createSegment$int(255);
            segs[frontCount] = ffSegment;
            segs[frontCount + 1] = asMAC?ffSegment:creator.createSegment$int(254);
            let prefLength : number = this.getPrefixLength();
            if(originalSegmentCount > frontCount) {
                this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(frontCount, originalSegmentCount, segs, frontCount + 2);
                if(prefLength != null && prefLength > frontCount << 3) {
                    prefLength += MACAddress.BITS_PER_SEGMENT << 1;
                }
            }
            let result : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(segs, this.addressSegmentIndex, true);
            result.assignPrefixLength(prefLength);
            return result;
        }
        let endIndex : number = this.addressSegmentIndex + originalSegmentCount;
        if(this.addressSegmentIndex <= 3) {
            if(endIndex > 4) {
                let index3 : number = 3 - this.addressSegmentIndex;
                let seg3 : MACAddressSegment = this.getSegment(index3);
                let seg4 : MACAddressSegment = this.getSegment(index3 + 1);
                if(!seg4.matches$int(asMAC?255:254) || !seg3.matches$int(255)) {
                    throw new IncompatibleAddressException(this, "ipaddress.mac.error.not.eui.convertible");
                }
            } else if(endIndex === 4) {
                let seg3 : MACAddressSegment = this.getSegment(3 - this.addressSegmentIndex);
                if(!seg3.matches$int(255)) {
                    throw new IncompatibleAddressException(this, "ipaddress.mac.error.not.eui.convertible");
                }
            }
        } else if(this.addressSegmentIndex === 4) {
            if(endIndex > 4) {
                let seg4 : MACAddressSegment = this.getSegment(4 - this.addressSegmentIndex);
                if(!seg4.matches$int(asMAC?255:254)) {
                    throw new IncompatibleAddressException(this, "ipaddress.mac.error.not.eui.convertible");
                }
            }
        }
        return this;
    }

    public append(other : MACAddressSection) : MACAddressSection {
        let count : number = this.getSegmentCount();
        return this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(count, count, other, 0, other.getSegmentCount());
    }

    public appendToPrefix(other : MACAddressSection) : MACAddressSection {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength == null) {
            return this.append(other);
        }
        let thizz : MACAddressSection = this;
        let bitsPerSegment : number = this.getBitsPerSegment();
        let adjustment : number = prefixLength % bitsPerSegment;
        if(adjustment !== 0) {
            prefixLength += bitsPerSegment - adjustment;
            thizz = this.setPrefixLength$int$boolean$boolean(prefixLength, false, false);
        }
        let index : number = prefixLength >>> 3;
        if(other.isPrefixed() && other.getPrefixLength() === 0) {
            return this.insert(index, other);
        }
        return thizz.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int$boolean(index, index, other, 0, other.getSegmentCount(), true);
    }

    public insert(index : number, other : MACAddressSection) : MACAddressSection {
        return this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(index, index, other, 0, other.getSegmentCount());
    }

    public replace$int$inet_ipaddr_mac_MACAddressSection(index : number, replacement : MACAddressSection) : MACAddressSection {
        return this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(index, index + replacement.getSegmentCount(), replacement, 0, replacement.getSegmentCount());
    }

    public replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(startIndex : number, endIndex : number, replacement : MACAddressSection, replacementStartIndex : number, replacementEndIndex : number) : MACAddressSection {
        return this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, false);
    }

    public replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int$boolean(startIndex : number, endIndex : number, replacement : MACAddressSection, replacementStartIndex : number, replacementEndIndex : number, appendNetwork : boolean) : MACAddressSection {
        let segmentCount : number = this.getSegmentCount();
        let replacedCount : number = endIndex - startIndex;
        let replacementCount : number = replacementEndIndex - replacementStartIndex;
        if(replacedCount < 0 || replacementCount < 0 || startIndex < 0 || replacementStartIndex < 0 || replacementEndIndex > replacement.getSegmentCount() || endIndex > segmentCount) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.IndexOutOfBoundsException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }
        let diff : number = replacementCount - replacedCount;
        let totalSegmentCount : number = segmentCount + diff;
        if(this.addressSegmentIndex + totalSegmentCount > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
            throw new AddressValueException(this, replacement, this.addressSegmentIndex + totalSegmentCount);
        } else if(replacementCount === 0) {
            if(this.isPrefixed()) {
                if(replacement.isPrefixed() && replacement.getPrefixLength() <= replacementEndIndex << 3) {
                    if(this.getPrefixLength() <= startIndex << 3) {
                        return this;
                    }
                } else {
                    return this;
                }
            } else if(!replacement.isPrefixed()) {
                return this;
            }
        }
        if(segmentCount === replacedCount && this.addressSegmentIndex === replacement.addressSegmentIndex && this.extended === replacement.extended) {
            if(!this.isPrefixed() || (replacement.isPrefixed() && replacement.getPrefixLength() === 0)) {
                return replacement;
            }
        }
        let result : MACAddressSection = <any>(AddressDivisionGrouping.replace<any, any>(this, startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, this.getAddressCreator(), appendNetwork, true));
        if(this.isPrefixed()) {
            let prefLength : number = this.getPrefixLength();
            let startBits : number = startIndex << 3;
            if(!appendNetwork && prefLength <= startBits) {
                result.assignPrefixLength(prefLength);
            } else if(replacement.isPrefixed() && replacement.getPrefixLength() <= replacementEndIndex << 3) {
                result.assignPrefixLength(Math.max(0, (replacement.getPrefixLength() - (replacementStartIndex << 3))) + startBits);
            } else if(prefLength <= endIndex << 3) {
                result.assignPrefixLength(startBits + (replacementCount << 3));
            } else {
                result.assignPrefixLength(prefLength + (diff << 3));
            }
        } else if(replacement.isPrefixed() && replacement.getPrefixLength() <= replacementEndIndex << 3) {
            result.assignPrefixLength(Math.max(0, (replacement.getPrefixLength() - (replacementStartIndex << 3))) + (startIndex << 3));
        } else {
            result.assignPrefixLength(null);
        }
        return result;
    }

    public replace(startIndex? : any, endIndex? : any, replacement? : any, replacementStartIndex? : any, replacementEndIndex? : any, appendNetwork? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>MACAddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && ((typeof appendNetwork === 'boolean') || appendNetwork === null)) {
            return <any>this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, appendNetwork);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>MACAddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && appendNetwork === undefined) {
            return <any>this.replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((endIndex != null && endIndex instanceof <any>MACAddressSection) || endIndex === null) && replacement === undefined && replacementStartIndex === undefined && replacementEndIndex === undefined && appendNetwork === undefined) {
            return <any>this.replace$int$inet_ipaddr_mac_MACAddressSection(startIndex, endIndex);
        } else throw new Error('invalid overload');
    }

    public contains$inet_ipaddr_mac_MACAddressSection(other : MACAddressSection) : boolean {
        if(this.addressSegmentIndex !== other.addressSegmentIndex || this.isExtended() !== other.isExtended() || this.getSegmentCount() !== other.getSegmentCount()) {
            return false;
        }
        for(let i : number = 0; i < this.getSegmentCount(); i++) {
            if(!this.getSegment(i).contains$inet_ipaddr_mac_MACAddressSegment(other.getSegment(i))) {
                return false;
            }
        };
        return true;
    }

    /**
     * @param {MACAddressSection} other
     * @return {boolean} whether this section contains the given address section
     */
    public contains(other? : any) : any {
        if(((other != null && other instanceof <any>MACAddressSection) || other === null)) {
            return <any>this.contains$inet_ipaddr_mac_MACAddressSection(other);
        } else if(((other != null && (other["__interfaces"] != null && other["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || other.constructor != null && other.constructor["__interfaces"] != null && other.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || other === null)) {
            return <any>this.contains$inet_ipaddr_AddressSection(other);
        } else throw new Error('invalid overload');
    }

    getLowestOrHighestSection(lowest : boolean) : MACAddressSection {
        let result : MACAddressSection = <any>(AddressDivisionGrouping.getSingleLowestOrHighestSection<any>(this));
        if(result == null) {
            if(this.sectionCache == null || (result = lowest?this.sectionCache.lower:this.sectionCache.upper) == null) {
                {
                    let create : boolean = (this.sectionCache == null);
                    if(create) {
                        this.sectionCache = <any>(new AddressDivisionGrouping.SectionCache<MACAddressSection>());
                    } else {
                        if(lowest) {
                            create = (result = this.sectionCache.lower) == null;
                        } else {
                            create = (result = this.sectionCache.upper) == null;
                        }
                    }
                    if(create) {
                        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
                        let segs : MACAddressSegment[] = AddressDivisionGrouping.createSingle<any, any>(this, creator, (i) => lowest?this.getSegment(i).getLower():this.getSegment(i).getUpper());
                        let prefLength : number;
                        result = (AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() || (prefLength = this.getPrefixLength()) == null)?creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(segs):creator.createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer$boolean(segs, prefLength, true);
                        if(lowest) {
                            this.sectionCache.lower = result;
                        } else {
                            this.sectionCache.upper = result;
                        }
                    }
                };
            }
        }
        return result;
    }

    getLowestOrHighest(addr : MACAddress, lowest : boolean) : MACAddress {
        let sectionResult : MACAddressSection = this.getLowestOrHighestSection(lowest);
        if(sectionResult === this) {
            return addr;
        }
        let result : MACAddress = null;
        let cache : MACAddressSection.AddressCache = addr.sectionCache;
        if(cache == null || (result = lowest?cache.lower:cache.upper) == null) {
            {
                cache = addr.sectionCache;
                let create : boolean = (cache == null);
                if(create) {
                    cache = addr.sectionCache = new MACAddressSection.AddressCache();
                } else {
                    if(lowest) {
                        create = (result = cache.lower) == null;
                    } else {
                        create = (result = cache.upper) == null;
                    }
                }
                if(create) {
                    result = this.getAddressCreator().createAddress$inet_ipaddr_mac_MACAddressSection(sectionResult);
                    if(lowest) {
                        cache.lower = result;
                    } else {
                        cache.upper = result;
                    }
                }
            };
        }
        return result;
    }

    /**
     * 
     * @return {MACAddressSection}
     */
    public getLower() : MACAddressSection {
        return this.getLowestOrHighestSection(true);
    }

    /**
     * 
     * @return {MACAddressSection}
     */
    public getUpper() : MACAddressSection {
        return this.getLowestOrHighestSection(false);
    }

    public longValue() : number {
        return this.getLongValue(true);
    }

    public upperLongValue() : number {
        return this.getLongValue(false);
    }

    getLongValue(lower : boolean) : number {
        let segCount : number = this.getSegmentCount();
        let result : number = 0;
        for(let i : number = 0; i < segCount; i++) {
            let seg : MACAddressSegment = this.getSegment(i);
            result = (result << MACAddress.BITS_PER_SEGMENT) | (lower?seg.getLowerSegmentValue():seg.getUpperSegmentValue());
        };
        return result;
    }

    public reverseBits$boolean(perByte : boolean) : MACAddressSection {
        let result : MACAddressSection = <any>(AddressDivisionGrouping.reverseBits<any, any>(perByte, this, this.getAddressCreator(), (i) => this.getSegment(i).reverseBits$boolean(perByte), false));
        result.assignPrefixLength(null);
        return result;
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {MACAddressSection}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else throw new Error('invalid overload');
    }

    public reverseBytes(perSegment? : any) : any {
        if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else throw new Error('invalid overload');
    }

    public reverseBytes$() : MACAddressSection {
        return this.reverseSegments();
    }

    /**
     * 
     * @return {MACAddressSection}
     */
    public reverseBytesPerSegment() : MACAddressSection {
        return this;
    }

    /**
     * 
     * @return {MACAddressSection}
     */
    public reverseSegments() : MACAddressSection {
        if(this.getSegmentCount() <= 1) {
            return this;
        }
        let result : MACAddressSection = <any>(AddressDivisionGrouping.reverseSegments<any, any>(this, this.getAddressCreator(), (index) => { return this.getSegment(index) }, false));
        result.assignPrefixLength(null);
        return result;
    }

    public removePrefixLength$() : MACAddressSection {
        return this.removePrefixLength$boolean(true);
    }

    public removePrefixLength$boolean(zeroed : boolean) : MACAddressSection {
        if(this.getPrefixLength() == null) {
            return this;
        }
        let oldSegs : MACAddressSegment[] = this.getSegmentsInternal();
        let newSegs : MACAddressSegment[] = AddressDivisionGrouping.removePrefix<any, any>(this, oldSegs, MACAddress.BITS_PER_SEGMENT, { apply : (seg, oldPrefLength, newPrefLength) => seg.setPrefixedSegment(oldPrefLength, newPrefLength, zeroed) });
        let result : MACAddressSection = this.getAddressCreator().createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(newSegs);
        result.assignPrefixLength(null);
        return result;
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {MACAddressSection}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : MACAddressSection {
        return this.adjustPrefixBySegment$boolean$boolean(nextSegment, true);
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : MACAddressSection {
        let existing : number = this.getPrefixLength();
        if(existing == null && nextSegment) {
            return this;
        }
        let prefix : number = this.getAdjustedPrefix$boolean$int$boolean(nextSegment, this.getBitsPerSegment(), true);
        return this.setPrefixLength$int$boolean(prefix, zeroed);
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {MACAddressSection}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : MACAddressSection {
        return this.adjustPrefixLength$int$boolean(adjustment, true);
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : MACAddressSection {
        if(adjustment === 0) {
            return this;
        }
        let prefix : number = this.getAdjustedPrefix$int$boolean$boolean(adjustment, true, true);
        return this.setPrefixLength$int$boolean(prefix, zeroed);
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {MACAddressSection}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {MACAddressSection}
     */
    public applyPrefixLength(prefixLength : number) : MACAddressSection {
        return this.setPrefixLength$int$boolean$boolean(prefixLength, true, true);
    }

    public setPrefixLength$int(prefixLength : number) : MACAddressSection {
        return this.setPrefixLength$int$boolean$boolean(prefixLength, true, false);
    }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : MACAddressSection {
        return this.setPrefixLength$int$boolean$boolean(prefixLength, zeroed, false);
    }

    public setPrefixLength$int$boolean$boolean(prefixLength : number, zeroed : boolean, noShrink : boolean) : MACAddressSection {
        if(prefixLength < 0) {
            throw new PrefixLenException(prefixLength);
        }
        let max : number = this.getBitCount();
        if(prefixLength > max) {
            if(prefixLength > (this.extended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_BIT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT_$LI$())) {
                throw new PrefixLenException(prefixLength);
            }
            prefixLength = max;
        }
        let oldPrefix : number = this.getPrefixLength();
        let prefixShrinking : boolean = oldPrefix == null || oldPrefix > prefixLength;
        let prefixGrowing : boolean;
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        if(prefixShrinking) {
            prefixGrowing = false;
        } else {
            prefixGrowing = !noShrink && oldPrefix < prefixLength;
            if(!prefixGrowing && !isAllSubnets) {
                return this;
            }
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
        let oldSegs : MACAddressSegment[] = this.getSegmentsInternal();
        let newSegs : MACAddressSegment[];
        let segmentBitCount : number = MACAddress.BITS_PER_SEGMENT;
        let segmentByteCount : number = MACAddress.BYTES_PER_SEGMENT;
        if(isAllSubnets) {
            if(prefixShrinking) {
                newSegs = AddressDivisionGrouping.setPrefixedSegments<any>(this.getNetwork(), prefixLength, /* clone */oldSegs.slice(0), segmentBitCount, segmentByteCount, creator, (segmentPrefixLength) => { return MACAddressSegment.toPrefixBlockSegment(segmentPrefixLength) });
                let result : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(newSegs);
                result.assignPrefixLength(prefixLength);
                return result;
            } else if(!prefixGrowing) {
                return this.toPrefixBlock();
            }
        }
        newSegs = /* clone */oldSegs.slice(0);
        for(let i : number = 0; i < newSegs.length; i++) {
            let newPref : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(MACAddress.BITS_PER_SEGMENT, prefixLength, i);
            let oldPref : number = oldPrefix == null?null:AddressDivisionGrouping.getPrefixedSegmentPrefixLength(MACAddress.BITS_PER_SEGMENT, oldPrefix, i);
            newSegs[i] = newSegs[i].setPrefixedSegment(oldPref, newPref, zeroed);
            if(isAllSubnets && newPref != null) {
                if(++i < newSegs.length) {
                    let zeroSeg : MACAddressSegment = creator.createRangeSegment(0, MACAddress.MAX_VALUE_PER_SEGMENT);
                    /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegs, i, newSegs.length, zeroSeg);
                    break;
                }
            }
        };
        let result : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(newSegs);
        result.assignPrefixLength(prefixLength);
        return result;
    }

    public setPrefixLength(prefixLength? : any, zeroed? : any, noShrink? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof zeroed === 'boolean') || zeroed === null) && ((typeof noShrink === 'boolean') || noShrink === null)) {
            return <any>this.setPrefixLength$int$boolean$boolean(prefixLength, zeroed, noShrink);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof zeroed === 'boolean') || zeroed === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(prefixLength, zeroed);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && zeroed === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(prefixLength);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddressSection}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : MACAddressSection {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength != null) {
            let segmentBitCount : number = MACAddress.BITS_PER_SEGMENT;
            let segmentByteCount : number = MACAddress.BYTES_PER_SEGMENT;
            let oldSegs : MACAddressSegment[] = this.getSegmentsInternal();
            for(let i : number = AddressDivisionGrouping.getHostSegmentIndex(prefixLength, segmentByteCount, segmentBitCount); i < oldSegs.length; i++) {
                let pref : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(segmentBitCount, prefixLength, i);
                let seg : MACAddressSegment = oldSegs[i];
                if(pref != null && !seg.isPrefixBlock$int(pref)) {
                    let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
                    let newSegs : MACAddressSegment[] = AddressDivisionGrouping.setPrefixedSegments<any>(this.getNetwork(), prefixLength, /* clone */oldSegs.slice(0), segmentBitCount, segmentByteCount, creator, (segmentPrefixLength) => { return MACAddressSegment.toPrefixBlockSegment(segmentPrefixLength) });
                    let result : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(newSegs);
                    result.assignPrefixLength(prefixLength);
                    return result;
                }
            };
        }
        return this;
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<MACAddressSection> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && ((typeof networkSegmentIndex === 'number') || networkSegmentIndex === null) && ((typeof hostSegmentIndex === 'number') || hostSegmentIndex === null) && ((typeof prefixedSegIteratorProducer === 'function' && (<any>prefixedSegIteratorProducer).length == 1) || prefixedSegIteratorProducer === null)) {
            super.iterator(segmentCreator, segSupplier, segIteratorProducer, excludeFunc, networkSegmentIndex, hostSegmentIndex, prefixedSegIteratorProducer);
        } else if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(segmentCreator, segSupplier, segIteratorProducer, excludeFunc);
        } else if(((segmentCreator != null && segmentCreator instanceof <any>MACAddress) || segmentCreator === null) && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_mac_MACAddress(segmentCreator);
        } else if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
        let isSingle : boolean = !this.isMultiple();
        return AddressDivisionGrouping.iterator(isSingle, this, creator, isSingle?null:this.segmentsIterator(), AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength());
    }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(((original != null && original instanceof <any>MACAddress) || original === null) && creator === undefined) {
            return <any>this.prefixBlockIterator$inet_ipaddr_mac_MACAddress(original);
        } else if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    public prefixBlockIterator$() : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator();
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(useOriginal, this, creator, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), AddressDivisionGrouping.getNetworkSegmentIndex(prefLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT), AddressDivisionGrouping.getHostSegmentIndex(prefLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT), ((prefLength) => {
            return (index) => this.getSegment(index).prefixBlockIterator(AddressDivisionGrouping.getSegmentPrefixLength$int$java_lang_Integer$int(MACAddress.BITS_PER_SEGMENT, prefLength, index))
        })(prefLength)), prefLength);
    }

    public segmentsIterator(excludeZeroHosts? : any) : any {
        if(excludeZeroHosts === undefined) {
            return <any>this.segmentsIterator$();
        } else throw new Error('invalid overload');
    }

    public segmentsIterator$() : any {
        return this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(this.getSegmentCreator(), () => this.getLower().getSegments(), (index) => this.getSegment(index).iterator(), <any>(null));
    }

    iterator$inet_ipaddr_mac_MACAddress(original : MACAddress) : any {
        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
        let isSingle : boolean = !this.isMultiple();
        return AddressDivisionGrouping.iterator(original, creator, isSingle, isSingle?null:this.segmentsIterator(), AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength());
    }

    prefixBlockIterator$inet_ipaddr_mac_MACAddress(original : MACAddress) : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator$inet_ipaddr_mac_MACAddress(original);
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(original, creator, useOriginal, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), AddressDivisionGrouping.getNetworkSegmentIndex(prefLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT), AddressDivisionGrouping.getHostSegmentIndex(prefLength, MACAddress.BYTES_PER_SEGMENT, MACAddress.BITS_PER_SEGMENT), ((prefLength) => {
            return (index) => this.getSegment(index).prefixBlockIterator(AddressDivisionGrouping.getSegmentPrefixLength$int$java_lang_Integer$int(MACAddress.BITS_PER_SEGMENT, prefLength, index))
        })(prefLength)), prefLength);
    }

    static getMaxValueLong(segmentCount : number) : number {
        return MACAddressSection.MAX_VALUES_LONG_$LI$()[segmentCount];
    }

    static getMaxValue(segmentCount : number) : BigInteger {
        return MACAddressSection.MAX_VALUES_$LI$()[segmentCount];
    }

    /**
     * 
     * @param {number} increment
     * @return {MACAddressSection}
     */
    public incrementBoundary(increment : number) : MACAddressSection {
        if(increment <= 0) {
            if(increment === 0) {
                return this;
            }
            return this.getLower().increment(increment);
        }
        return this.getUpper().increment(increment);
    }

    /**
     * 
     * @param {number} increment
     * @return {MACAddressSection}
     */
    public increment(increment : number) : MACAddressSection {
        if(increment === 0 && !this.isMultiple()) {
            return this;
        }
        if(!this.isExtended() || this.getSegmentCount() < 8) {
            let lowerValue : number = this.longValue();
            let upperValue : number = this.upperLongValue();
            let count : number = this.getCount().longValue();
            AddressDivisionGrouping.checkOverflow$long$long$long$long$java_util_function_LongSupplier(increment, lowerValue, upperValue, count, () => MACAddressSection.getMaxValueLong(this.getSegmentCount()));
            return <any>(AddressDivisionGrouping.increment(this, increment, this.getAddressCreator(), this.getCount().longValue(), this.longValue(), this.upperLongValue(), () => { return this.getLower() }, () => { return this.getUpper() }, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength()));
        }
        let lowerValue : BigInteger = this.getValue();
        let upperValue : BigInteger = this.getUpperValue();
        let count : BigInteger = this.getCount();
        let bigIncrement : BigInteger = BigInteger.valueOf(increment);
        AddressDivisionGrouping.checkOverflow$long$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_util_function_Supplier(increment, bigIncrement, lowerValue, upperValue, count, () => MACAddressSection.getMaxValue(this.getSegmentCount()));
        let prefixLength : number = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength();
        let result : MACAddressSection = <any>(AddressDivisionGrouping.fastIncrement<any, any>(this, increment, this.getAddressCreator(), () => { return this.getLower() }, () => { return this.getUpper() }, prefixLength));
        if(result != null) {
            return result;
        }
        return <any>(AddressDivisionGrouping.increment(this, increment, bigIncrement, this.getAddressCreator(), () => { return this.getLower() }, () => { return this.getUpper() }, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength()));
    }

    hasNoStringCache() : boolean {
        if(this.stringCache == null) {
            {
                if(this.stringCache == null) {
                    this.stringCache = new MACAddressSection.MACStringCache();
                    return true;
                }
            };
        }
        return false;
    }

    public toHexString$boolean(with0xPrefix : boolean) : string {
        let result : string;
        if(this.hasNoStringCache() || (result = (with0xPrefix?this.stringCache.hexStringPrefixed:this.stringCache.hexString)) == null) {
            result = this.toHexString$boolean$java_lang_CharSequence(with0xPrefix, null);
            if(with0xPrefix) {
                this.stringCache.hexStringPrefixed = result;
            } else {
                this.stringCache.hexString = result;
            }
        }
        return result;
    }

    public toHexString$boolean$java_lang_CharSequence(with0xPrefix : boolean, zone : any) : string {
        if(this.isDualString()) {
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(AddressDivisionGrouping.AddressStringParams.toParams(with0xPrefix?MACAddressSection.MACStringCache.hexPrefixedParams_$LI$():MACAddressSection.MACStringCache.hexParams_$LI$()), this.getLower(), this.getUpper(), null);
        }
        return this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(with0xPrefix?MACAddressSection.MACStringCache.hexPrefixedParams_$LI$():MACAddressSection.MACStringCache.hexParams_$LI$());
    }

    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toHexString$boolean$java_lang_CharSequence(with0xPrefix, zone);
        } else if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toNormalizedString(options? : any, zone? : any) : any {
        if(((options != null && options instanceof <any>AddressDivisionGrouping.StringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(options);
        } else if(options === undefined && zone === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(stringOptions : AddressDivisionGrouping.StringOptions) : string {
        return MACAddressSection.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions$inet_ipaddr_format_AddressDivisionGrouping(stringOptions, this);
    }

    public static toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions$inet_ipaddr_format_AddressDivisionGrouping(opts : AddressDivisionGrouping.StringOptions, section : AddressDivisionGrouping) : string {
        return MACAddressSection.toParams(opts).toString(section);
    }

    public static toNormalizedString(opts? : any, section? : any) : any {
        if(((opts != null && opts instanceof <any>AddressDivisionGrouping.StringOptions) || opts === null) && ((section != null && section instanceof <any>AddressDivisionGrouping) || section === null)) {
            return <any>MACAddressSection.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions$inet_ipaddr_format_AddressDivisionGrouping(opts, section);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringOptions) || opts === null) && ((section != null && (section["__interfaces"] != null && section["__interfaces"].indexOf("inet.ipaddr.format.AddressStringDivisionSeries") >= 0 || section.constructor != null && section.constructor["__interfaces"] != null && section.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressStringDivisionSeries") >= 0)) || section === null)) {
            return <any>MACAddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_AddressStringDivisionSeries(opts, section);
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().normalizedString) == null) {
            this.getStringCache().normalizedString = result = this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(MACAddressSection.MACStringCache.normalizedParams_$LI$());
        }
        return result;
    }

    /**
     * This produces a canonical string using the canonical standardized IEEE 802 MAC address representation of xx-xx-xx-xx-xx-xx
     * For range segments, '..' is used: 11-22-33..44-55-66
     * @return {string}
     */
    public toCanonicalString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().canonicalString) == null) {
            this.getStringCache().canonicalString = result = this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(MACAddressSection.MACStringCache.canonicalParams_$LI$());
        }
        return result;
    }

    /**
     * This produces a shorter string for the address that uses the canonical representation but not using leading zeroes.
     * 
     * Each address has a unique compressed string.
     * @return {string}
     */
    public toCompressedString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().compressedString) == null) {
            this.getStringCache().compressedString = result = this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(MACAddressSection.MACStringCache.compressedParams_$LI$());
        }
        return result;
    }

    /**
     * This produces the dotted hexadecimal format aaaa.bbbb.cccc
     * @return {string}
     */
    public toDottedString() : string {
        let result : string = null;
        if(this.hasNoStringCache() || (result = this.getStringCache().dottedString) == null) {
            let dottedGrouping : AddressDivisionGrouping = this.getDottedGrouping();
            this.getStringCache().dottedString = result = MACAddressSection.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions$inet_ipaddr_format_AddressDivisionGrouping(MACAddressSection.MACStringCache.dottedParams_$LI$(), dottedGrouping);
        }
        return result;
    }

    /**
     * This produces a string delimited by spaces: aa bb cc dd ee ff
     * @return {string}
     */
    public toSpaceDelimitedString() : string {
        let result : string = null;
        if(this.hasNoStringCache() || (result = this.getStringCache().spaceDelimitedString) == null) {
            this.getStringCache().spaceDelimitedString = result = this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(MACAddressSection.MACStringCache.spaceDelimitedParams_$LI$());
        }
        return result;
    }

    public toDashedString() : string {
        return this.toCanonicalString();
    }

    public toColonDelimitedString() : string {
        return this.toNormalizedString();
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.toNormalizedString();
    }

    /**
     * 
     * @return {Array}
     */
    public getSegmentStrings() : string[] {
        return this.getDivisionStrings();
    }

    public getDottedGrouping() : AddressDivisionGrouping {
        let start : number = this.addressSegmentIndex;
        let segmentCount : number = this.getSegmentCount();
        let newSegs : AddressDivision[];
        let newSegmentBitCount : number = MACAddress.BITS_PER_SEGMENT << 1;
        let segIndex : number;
        let newSegIndex : number;
        if((start & 1) === 0) {
            let newSegmentCount : number = (segmentCount + 1) >>> 1;
            newSegs = (s => { let a=[]; while(s-->0) a.push(null); return a; })(newSegmentCount);
            newSegIndex = segIndex = 0;
        } else {
            let newSegmentCount : number = (segmentCount >>> 1) + 1;
            newSegs = (s => { let a=[]; while(s-->0) a.push(null); return a; })(newSegmentCount);
            let segment : MACAddressSegment = this.getSegment(0);
            newSegs[0] = new AddressBitsDivision(segment.getLowerSegmentValue(), segment.getUpperSegmentValue(), newSegmentBitCount, MACAddress.DEFAULT_TEXTUAL_RADIX);
            newSegIndex = segIndex = 1;
        }
        while((segIndex + 1 < segmentCount)) {
            let segment1 : MACAddressSegment = this.getSegment(segIndex++);
            let segment2 : MACAddressSegment = this.getSegment(segIndex++);
            if(segment1.isMultiple() && !segment2.isFullRange()) {
                throw new IncompatibleAddressException(segment1, segIndex - 2, segment2, segIndex - 1, "ipaddress.error.invalid.joined.ranges");
            }
            let newSeg : AddressDivision = new AddressBitsDivision((segment1.getLowerSegmentValue() << MACAddress.BITS_PER_SEGMENT) | segment2.getLowerSegmentValue(), (segment1.getUpperSegmentValue() << MACAddress.BITS_PER_SEGMENT) | segment2.getUpperSegmentValue(), newSegmentBitCount, MACAddress.DEFAULT_TEXTUAL_RADIX);
            newSegs[newSegIndex++] = newSeg;
        };
        if(segIndex < segmentCount) {
            let segment : MACAddressSegment = this.getSegment(segIndex);
            newSegs[newSegIndex] = new AddressBitsDivision(segment.getLowerSegmentValue() << MACAddress.BITS_PER_SEGMENT, segment.getUpperSegmentValue() << MACAddress.BITS_PER_SEGMENT, newSegmentBitCount, MACAddress.DEFAULT_TEXTUAL_RADIX);
        }
        let dottedGrouping : AddressDivisionGrouping;
        if(this.cachedPrefixLength == null) {
            dottedGrouping = new AddressDivisionGrouping(newSegs);
        } else {
            let prefLength : number = this.cachedPrefixLength;
            dottedGrouping = new MACAddressSection.MACAddressSection$1(this, newSegs, prefLength);
        }
        return dottedGrouping;
    }

    static toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_AddressStringDivisionSeries(opts : IPAddressSection.IPStringOptions, section : AddressStringDivisionSeries) : string {
        return MACAddressSection.toParams(opts).toString(section);
    }

    public contains$inet_ipaddr_AddressSection(other : AddressSection) : boolean {
        return (other != null && other instanceof <any>MACAddressSection) && this.contains$inet_ipaddr_mac_MACAddressSection(<MACAddressSection><any>other);
    }

    static toParams(opts : AddressDivisionGrouping.StringOptions) : AddressDivisionGrouping.AddressStringParams<AddressStringDivisionSeries> {
        return AddressDivisionGrouping.AddressStringParams.toParams(opts);
    }
}
MACAddressSection["__class"] = "inet.ipaddr.mac.MACAddressSection";
MACAddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



export namespace MACAddressSection {

    export class MACStringCache extends AddressDivisionGrouping.StringCache {
        static __static_initialized : boolean = false;
        static __static_initialize() { if(!MACStringCache.__static_initialized) { MACStringCache.__static_initialized = true; MACStringCache.__static_initializer_0(); } }

        static hexParams : AddressDivisionGrouping.StringOptions; public static hexParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.hexParams; };

        static hexPrefixedParams : AddressDivisionGrouping.StringOptions; public static hexPrefixedParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.hexPrefixedParams; };

        static canonicalParams : AddressDivisionGrouping.StringOptions; public static canonicalParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.canonicalParams; };

        static compressedParams : AddressDivisionGrouping.StringOptions; public static compressedParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.compressedParams; };

        static normalizedParams : AddressDivisionGrouping.StringOptions; public static normalizedParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.normalizedParams; };

        static dottedParams : AddressDivisionGrouping.StringOptions; public static dottedParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.dottedParams; };

        static spaceDelimitedParams : AddressDivisionGrouping.StringOptions; public static spaceDelimitedParams_$LI$() : AddressDivisionGrouping.StringOptions { MACStringCache.__static_initialize(); return MACStringCache.spaceDelimitedParams; };

        static __static_initializer_0() {
            MACStringCache.hexParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(null).setExpandedSegments(true).setRadix(16).toOptions();
            MACStringCache.hexPrefixedParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(null).setExpandedSegments(true).setRadix(16).setAddressLabel(MACAddress.HEX_PREFIX).toOptions();
            MACStringCache.normalizedParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(MACAddress.COLON_SEGMENT_SEPARATOR).setExpandedSegments(true).setRadix(MACAddress.DEFAULT_TEXTUAL_RADIX).toOptions();
            MACStringCache.canonicalParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(MACAddress.DASH_SEGMENT_SEPARATOR).setExpandedSegments(true).setRadix(MACAddress.DEFAULT_TEXTUAL_RADIX).setWildcards(new StringOptions.Wildcards(MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR_STR, Address.SEGMENT_WILDCARD_STR, null)).toOptions();
            MACStringCache.compressedParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(MACAddress.COLON_SEGMENT_SEPARATOR).setRadix(MACAddress.DEFAULT_TEXTUAL_RADIX).toOptions();
            MACStringCache.dottedParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(MACAddress.DOTTED_SEGMENT_SEPARATOR).setExpandedSegments(true).setRadix(MACAddress.DEFAULT_TEXTUAL_RADIX).toOptions();
            MACStringCache.spaceDelimitedParams = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setSeparator(MACAddress.SPACE_SEGMENT_SEPARATOR).setExpandedSegments(true).setRadix(MACAddress.DEFAULT_TEXTUAL_RADIX).toOptions();
        }

        public compressedString : string;

        public normalizedString : string;

        public dottedString : string;

        public spaceDelimitedString : string;

        constructor() {
            super();
            if(this.compressedString===undefined) this.compressedString = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.dottedString===undefined) this.dottedString = null;
            if(this.spaceDelimitedString===undefined) this.spaceDelimitedString = null;
        }
    }
    MACStringCache["__class"] = "inet.ipaddr.mac.MACAddressSection.MACStringCache";


    export class AddressCache extends AddressDivisionGrouping.SectionCache<MACAddress> {
        constructor() {
            super();
        }
    }
    AddressCache["__class"] = "inet.ipaddr.mac.MACAddressSection.AddressCache";


    /**
     * Represents a clear way to create a specific type of string.
     * 
     * @author sfoley
     * @extends AddressDivisionGrouping.StringOptions
     * @class
     */
    export class MACStringOptions extends AddressDivisionGrouping.StringOptions {
        constructor(base : number, expandSegments : boolean, wildcards : StringOptions.Wildcards, segmentStrPrefix : string, separator : string, label : string, reverse : boolean, splitDigits : boolean, uppercase : boolean) {
            super(base, expandSegments, wildcards, segmentStrPrefix, separator, label, reverse, splitDigits, uppercase);
        }
    }
    MACStringOptions["__class"] = "inet.ipaddr.mac.MACAddressSection.MACStringOptions";


    export namespace MACStringOptions {

        export class __inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder extends AddressDivisionGrouping.StringOptions.Builder {
            public constructor(base : number = MACAddress.DEFAULT_TEXTUAL_RADIX, separator : string = MACAddress.COLON_SEGMENT_SEPARATOR) {
                super(base, separator);
            }

            /**
             * 
             * @return {MACAddressSection.MACStringOptions}
             */
            public toOptions() : MACAddressSection.MACStringOptions {
                return new MACAddressSection.MACStringOptions(this.base, this.expandSegments, this.wildcards, this.segmentStrPrefix, this.separator, this.addrLabel, this.reverse, this.splitDigits, this.uppercase);
            }
        }
        __inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder["__class"] = "inet.ipaddr.mac.MACAddressSection.MACStringOptions.Builder";

    }


    export class MACAddressSection$0 extends MACAddressNetwork.MACAddressCreator {
        public __parent: any;
        static serialVersionUID : number = 4;

        /**
         * 
         * @param {Array} bytes
         * @param {number} segmentCount
         * @param {number} prefixLength
         * @param {boolean} singleOnly
         * @return {MACAddressSection}
         */
        public createSectionInternal(bytes? : any, segmentCount? : any, prefixLength? : any, singleOnly? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefixLength, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefixLength, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'boolean') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'boolean') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$boolean(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && segmentCount === undefined && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(segments : MACAddressSegment[]) : MACAddressSection {
            return this.getNetwork().getAddressCreator().createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(segments, this.startIndex, this.extended);
        }

        constructor(__parent: any, __arg0: any, private startIndex: any, private extended: any) {
            super(__arg0);
            this.__parent = __parent;
        }
    }
    MACAddressSection$0["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];



    export class MACAddressSection$1 extends AddressDivisionGrouping {
        public __parent: any;
        constructor(__parent: any, __arg0: any, private prefLength: any) {
            super(__arg0);
            this.__parent = __parent;
            (() => {
                this.cachedPrefixLength = this.prefLength;
            })();
        }
    }
    MACAddressSection$1["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];


}




MACAddressSection.MACStringCache.spaceDelimitedParams_$LI$();

MACAddressSection.MACStringCache.dottedParams_$LI$();

MACAddressSection.MACStringCache.normalizedParams_$LI$();

MACAddressSection.MACStringCache.compressedParams_$LI$();

MACAddressSection.MACStringCache.canonicalParams_$LI$();

MACAddressSection.MACStringCache.hexPrefixedParams_$LI$();

MACAddressSection.MACStringCache.hexParams_$LI$();

MACAddressSection.MACStringCache.__static_initialize();

MACAddressSection.creators_$LI$();

MACAddressSection.MAX_VALUES_$LI$();

MACAddressSection.MAX_VALUES_LONG_$LI$();
