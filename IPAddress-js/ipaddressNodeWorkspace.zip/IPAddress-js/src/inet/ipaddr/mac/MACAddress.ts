/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressPositionException } from '../AddressPositionException';
import { AddressValueException } from '../AddressValueException';
import { HostIdentifierString } from '../HostIdentifierString';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { MACAddressString } from '../MACAddressString';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { MACAddressSection } from './MACAddressSection';
import { MACAddressSegment } from './MACAddressSegment';
import { MACAddressNetwork } from './MACAddressNetwork';
import { AddressSection } from '../AddressSection';
import { MACAddressStringParameters } from '../MACAddressStringParameters';

/**
 * Constructs a MAC address
 * 
 * @param {*} lowerValueProvider supplies the 1 byte lower values for each segment
 * @param {*} upperValueProvider supplies the 1 byte upper values for each segment
 * @param {boolean} extended
 * @class
 * @extends Address
 * @author sfoley
 */
export class MACAddress extends Address {
    static __inet_ipaddr_mac_MACAddress_serialVersionUID : number = 4;

    public static COLON_SEGMENT_SEPARATOR : string = ':';

    public static DASH_SEGMENT_SEPARATOR : string = '-';

    public static SPACE_SEGMENT_SEPARATOR : string = ' ';

    public static DOTTED_SEGMENT_SEPARATOR : string = '.';

    public static DASHED_SEGMENT_RANGE_SEPARATOR : string = '|';

    public static DASHED_SEGMENT_RANGE_SEPARATOR_STR : string; public static DASHED_SEGMENT_RANGE_SEPARATOR_STR_$LI$() : string { if(MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR_STR == null) MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR_STR = /* valueOf */new String(MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR).toString(); return MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR_STR; };

    public static BITS_PER_SEGMENT : number = 8;

    public static BYTES_PER_SEGMENT : number = 1;

    public static MEDIA_ACCESS_CONTROL_SEGMENT_COUNT : number = 6;

    public static MEDIA_ACCESS_CONTROL_BIT_COUNT : number = 48;

    public static MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT : number = 3;

    public static MEDIA_ACCESS_CONTROL_DOTTED_64_SEGMENT_COUNT : number = 4;

    public static MEDIA_ACCESS_CONTROL_DOTTED_BITS_PER_SEGMENT : number = 16;

    public static MEDIA_ACCESS_CONTROL_SINGLE_DASHED_SEGMENT_COUNT : number = 2;

    public static EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT : number; public static EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$() : number { if(MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT == null) MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT = MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT; return MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT; };

    public static EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT : number = 8;

    public static EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT : number; public static EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT_$LI$() : number { if(MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT == null) MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT = MACAddress.MEDIA_ACCESS_CONTROL_BIT_COUNT; return MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT; };

    public static EXTENDED_UNIQUE_IDENTIFIER_64_BIT_COUNT : number = 64;

    public static DEFAULT_TEXTUAL_RADIX : number = 16;

    public static MAX_VALUE_PER_SEGMENT : number = 255;

    public static MAX_VALUE_PER_DOTTED_SEGMENT : number = 65535;

    public static ORGANIZATIONAL_UNIQUE_IDENTIFIER_SEGMENT_COUNT : number = 3;

    public static ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT : number; public static ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT_$LI$() : number { if(MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT == null) MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT = MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_SEGMENT_COUNT * MACAddress.BITS_PER_SEGMENT; return MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT; };

    sectionCache : MACAddressSection.AddressCache;

    public constructor(lowerValueProvider? : any, upperValueProvider? : any, extended? : any) {
        if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof extended === 'boolean') || extended === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider, upperValueProvider, 0, extended));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let extended : any = false;
                super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider, upperValueProvider, 0, extended));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((typeof upperValueProvider === 'boolean') || upperValueProvider === null) && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let extended : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider, upperValueProvider, 0, extended));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((typeof upperValueProvider === 'boolean') || upperValueProvider === null) && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            let extended : any = __args[1];
            super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$long$int$boolean(address, 0, extended));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null && lowerValueProvider[0] instanceof <any>MACAddressSegment))) || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$inet_ipaddr_mac_MACAddressSegment_A$boolean(segments, segments.length === MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                let segCount : number = segments.length;
                if(segCount !== MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT && segCount !== MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.mac.invalid.segment.count", segCount);
                }
            })();
        } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>MACAddressSection) || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            super(section);
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                let segCount : number = section.getSegmentCount();
                if(segCount !== MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT && segCount !== MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.mac.invalid.segment.count", segCount);
                }
                if(section.addressSegmentIndex !== 0) {
                    throw new AddressPositionException(section.addressSegmentIndex);
                }
            })();
        } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>NetworkInterface) || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let ni : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let bytes : any = ni.getHardwareAddress();
                super((thisAddress) => MACAddress.createSection(<MACAddress>thisAddress, bytes));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let bytes : any = __args[0];
            super((thisAddress) => MACAddress.createSection(<MACAddress>thisAddress, bytes));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let extended : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let lowerValueProvider : any = valueProvider;
                    let upperValueProvider : any = valueProvider;
                    super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider, upperValueProvider, 0, extended));
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                }
            }
        } else if(((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && upperValueProvider === undefined && extended === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let extended : any = false;
                super((thisAddress) => (<MACAddress>thisAddress).getAddressCreator().createSection$long$int$boolean(address, 0, extended));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else throw new Error('invalid overload');
    }

    /*private*/ static createSection(addr : MACAddress, bytes : number[]) : MACAddressSection {
        let segCount : number;
        let len : number = bytes.length;
        if(len < MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
            segCount = MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT;
            if(len > MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT) {
                let i : number = 0;
                do {
                    if(bytes[i++] !== 0) {
                        segCount = MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
                        break;
                    }
                } while((--len > MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT));
            }
        } else {
            segCount = MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
        }
        return addr.getAddressCreator().createSection$byte_A$int$int$boolean(bytes, 0, segCount, segCount === MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT);
    }

    static getMessage(key : string) : string {
        return Address.getMessage(key);
    }

    /**
     * 
     * @return {MACAddressNetwork}
     */
    public getNetwork() : MACAddressNetwork {
        return Address.defaultMACNetwork();
    }

    public getIPv6Network() : IPv6AddressNetwork {
        return Address.defaultIpv6Network();
    }

    public getAddressCreator() : MACAddressNetwork.MACAddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    public isExtended() : boolean {
        return this.getSection().isExtended();
    }

    public isAllAddresses() : boolean {
        return this.getSection().isFullRange();
    }

    public getSection$() : MACAddressSection {
        return <MACAddressSection><any>super.getSection();
    }

    /**
     * 
     * @param {number} index
     * @return {MACAddressSegment}
     */
    public getDivision(index : number) : MACAddressSegment {
        return this.getSegment(index);
    }

    /**
     * 
     * @param {number} index
     * @return {MACAddressSegment}
     */
    public getSegment(index : number) : MACAddressSegment {
        return this.getSection().getSegment(index);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} index
     */
    public getSegments(start? : any, end? : any, segs? : any, index? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof index === 'number') || index === null)) {
            super.getSegments(start, end, segs, index);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(start === undefined && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    public getSegments$() : MACAddressSegment[] {
        return this.getSection().getSegments();
    }

    public static maxSegmentValue() : number {
        return MACAddress.MAX_VALUE_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getMaxSegmentValue() : number {
        return MACAddress.MAX_VALUE_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSection().getByteCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSection().getBitCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBytesPerSegment() : number {
        return MACAddress.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBitsPerSegment() : number {
        return MACAddress.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    isFromSameString(other : HostIdentifierString) : boolean {
        if(this.fromString != null && (other != null && other instanceof <any>MACAddressString)) {
            let fromString : MACAddressString = <MACAddressString><any>this.fromString;
            let otherString : MACAddressString = <MACAddressString><any>other;
            return (fromString === otherString || (/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(fromString.toString(),otherString.toString()))) && fromString.getValidationOptions().equals(otherString.getValidationOptions()));
        }
        return false;
    }

    /**
     * 
     * @param {Address} other
     * @return {boolean}
     */
    public contains(other : Address) : boolean {
        if(other === this) {
            return true;
        }
        return (other != null && other instanceof <any>MACAddress) && this.getSection().contains$inet_ipaddr_AddressSection(other.getSection());
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<MACAddress> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        return this.getSection().iterator$inet_ipaddr_mac_MACAddress(this);
    }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    public prefixBlockIterator$() : any {
        return this.getSection().prefixBlockIterator$inet_ipaddr_mac_MACAddress(this);
    }

    public segmentsIterator(excludeZeroHosts? : any) : any {
        if(excludeZeroHosts === undefined) {
            return <any>this.segmentsIterator$();
        } else throw new Error('invalid overload');
    }

    public segmentsIterator$() : any {
        return this.getSection().segmentsIterator();
    }

    /**
     * 
     * @param {number} increment
     * @return {MACAddress}
     */
    public increment(increment : number) : MACAddress {
        return this.checkIdentity(this.getSection().increment(increment));
    }

    /**
     * 
     * @param {number} increment
     * @return {MACAddress}
     */
    public incrementBoundary(increment : number) : MACAddress {
        return this.checkIdentity(this.getSection().incrementBoundary(increment));
    }

    /**
     * 
     * @return {MACAddress}
     */
    public getLower() : MACAddress {
        return this.getLowestOrHighest(true);
    }

    /**
     * 
     * @return {MACAddress}
     */
    public getUpper() : MACAddress {
        return this.getLowestOrHighest(false);
    }

    /*private*/ getLowestOrHighest(lowest : boolean) : MACAddress {
        return this.getSection().getLowestOrHighest(this, lowest);
    }

    public longValue() : number {
        return this.getSection().longValue();
    }

    public upperLongValue() : number {
        return this.getSection().upperLongValue();
    }

    public reverseBits$boolean(perByte : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().reverseBits$boolean(perByte));
    }

    /**
     * Use to produce:
     * "MSB format", "IBM format", "Token-Ring format", and "non-canonical form"
     * 
     * See RFC 2469 section 2
     * 
     * Also see https://en.wikipedia.org/wiki/MAC_address
     * 
     * @return
     * @param {boolean} perByte
     * @return {MACAddress}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else throw new Error('invalid overload');
    }

    public reverseBytes(perSegment? : any) : any {
        if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else throw new Error('invalid overload');
    }

    public reverseBytes$() : MACAddress {
        return this.checkIdentity(this.getSection().reverseBytes());
    }

    /**
     * 
     * @return {MACAddress}
     */
    public reverseBytesPerSegment() : MACAddress {
        return this;
    }

    /**
     * 
     * @return {MACAddress}
     */
    public reverseSegments() : MACAddress {
        return this.checkIdentity(this.getSection().reverseSegments());
    }

    /*private*/ checkIdentity(newSection : MACAddressSection) : MACAddress {
        let section : MACAddressSection = this.getSection();
        if(newSection === section) {
            return this;
        }
        return this.getAddressCreator().createAddress$inet_ipaddr_mac_MACAddressSection(newSection);
    }

    public removePrefixLength$() : MACAddress {
        return this.checkIdentity(this.getSection().removePrefixLength());
    }

    public removePrefixLength$boolean(zeroed : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().removePrefixLength$boolean(zeroed));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {MACAddress}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {MACAddress}
     */
    public applyPrefixLength(prefixLength : number) : MACAddress {
        return this.checkIdentity(this.getSection().applyPrefixLength(prefixLength));
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean(nextSegment));
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed));
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {MACAddress}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : MACAddress {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int(adjustment));
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int$boolean(adjustment, zeroed));
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {MACAddress}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : MACAddress {
        return this.checkIdentity(this.getSection().setPrefixLength$int(prefixLength));
    }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : MACAddress {
        return this.checkIdentity(this.getSection().setPrefixLength$int$boolean(prefixLength, zeroed));
    }

    public getSection$int(index : number) : MACAddressSection {
        return this.getSection().getSection$int(index);
    }

    public getSection$int$int(index : number, endIndex : number) : MACAddressSection {
        return this.getSection().getSection$int$int(index, endIndex);
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {MACAddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    public getODISection() : MACAddressSection {
        return this.getSection().getODISection();
    }

    public getOUISection() : MACAddressSection {
        return this.getSection().getOUISection();
    }

    /**
     * Returns an address in which the range of values match the block for the OUI (organizationally unique identifier)
     * 
     * @return
     * @return {MACAddress}
     */
    public toOUIPrefixBlock() : MACAddress {
        return this.checkIdentity(this.getSection().toOUIPrefixBlock());
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : MACAddress {
        return this.checkIdentity(this.getSection().toPrefixBlock());
    }

    /**
     * Converts to a link-local Ipv6 address.  Any MAC prefix length is ignored.  Other elements of this address section are incorporated into the conversion.
     * This will provide the latter 4 segments of an IPv6 address, to be paired with the link-local IPv6 prefix of 4 segments.
     * 
     * @return
     * @return {IPv6Address}
     */
    public toLinkLocalIPv6() : IPv6Address {
        let network : IPv6AddressNetwork = this.getIPv6Network();
        let linkLocalPrefix : IPv6AddressSection = network.getLinkLocalPrefix();
        let creator : IPv6AddressNetwork.IPv6AddressCreator = network.getAddressCreator();
        return creator.createAddress$inet_ipaddr_ipv6_IPv6AddressSection(linkLocalPrefix.append(this.toEUI64IPv6()));
    }

    /**
     * Converts to an Ipv6 address section.  Any MAC prefix length is ignored.  Other elements of this address section are incorporated into the conversion.
     * This will provide the latter 4 segments of an IPv6 address, to be paired with an IPv6 prefix of 4 segments.
     * 
     * @return
     * @return {IPv6AddressSection}
     */
    public toEUI64IPv6() : IPv6AddressSection {
        return this.getIPv6Network().getAddressCreator().createSection$inet_ipaddr_mac_MACAddress(this);
    }

    /**
     * Whether this section is consistent with an IPv6 EUI64 section,
     * which means it came from an extended 8 byte address,
     * and the corresponding segments in the middle match 0xff and 0xff/fe for MAC/not-MAC
     * 
     * @param {boolean} asMAC
     * @return
     * @return {boolean}
     */
    public isEUI64(asMAC : boolean) : boolean {
        if(this.isExtended()) {
            let section : MACAddressSection = this.getSection();
            let seg3 : MACAddressSegment = section.getSegment(3);
            let seg4 : MACAddressSegment = section.getSegment(4);
            return seg3.matches$int(255) && seg4.matches$int(asMAC?255:254);
        }
        return false;
    }

    /**
     * Convert to IPv6 EUI-64 section
     * 
     * http://standards.ieee.org/develop/regauth/tut/eui64.pdf
     * 
     * @param {boolean} asMAC if true, this address is considered MAC and the EUI-64 is extended using ff-ff, otherwise this address is considered EUI-48 and extended using ff-fe
     * Note that IPv6 treats MAC as EUI-48 and extends MAC to IPv6 addresses using ff-fe
     * @return
     * @return {MACAddress}
     */
    public toEUI64(asMAC : boolean) : MACAddress {
        if(!this.isExtended()) {
            let creator : MACAddressNetwork.MACAddressCreator = this.getAddressCreator();
            let segs : MACAddressSegment[] = creator.createSegmentArray(MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT);
            let section : MACAddressSection = this.getSection();
            section.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, 3, segs, 0);
            let ffSegment : MACAddressSegment = creator.createSegment$int(255);
            segs[3] = ffSegment;
            segs[4] = asMAC?ffSegment:creator.createSegment$int(254);
            section.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(3, 6, segs, 5);
            let prefLength : number = this.getPrefixLength();
            if(prefLength != null) {
                let resultSection : MACAddressSection = creator.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$boolean(segs, true);
                if(prefLength >= 24) {
                    prefLength += MACAddress.BITS_PER_SEGMENT << 1;
                }
                resultSection.assignPrefixLength(prefLength);
            }
            return creator.createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A(segs);
        } else {
            let section : MACAddressSection = this.getSection();
            let seg3 : MACAddressSegment = section.getSegment(3);
            let seg4 : MACAddressSegment = section.getSegment(4);
            if(seg3.matches$int(255) && seg4.matches$int(asMAC?255:254)) {
                return this;
            }
        }
        throw new IncompatibleAddressException(this, "ipaddress.mac.error.not.eui.convertible");
    }

    /**
     * Replaces segments starting from startIndex and ending before endIndex with the same number of segments starting at replacementStartIndex from the replacement section
     * 
     * @param {number} startIndex
     * @param {number} endIndex
     * @param {MACAddress} replacement
     * @param {number} replacementIndex
     * @throws IndexOutOfBoundsException
     * @return
     * @return {MACAddress}
     */
    public replace(startIndex : number, endIndex : number, replacement : MACAddress, replacementIndex : number) : MACAddress {
        return this.checkIdentity(this.getSection().replace$int$int$inet_ipaddr_mac_MACAddressSection$int$int(startIndex, endIndex, replacement.getSection(), replacementIndex, replacementIndex + (endIndex - startIndex)));
    }

    public getDottedAddress() : AddressDivisionGrouping {
        return this.getSection().getDottedGrouping();
    }

    cache(string : HostIdentifierString) {
        if(this.fromString != null && this.fromString instanceof <any>MACAddressString) {
            this.fromString = string;
        }
    }

    /**
     * 
     * @return {MACAddressString}
     */
    public toAddressString() : MACAddressString {
        if(this.fromString == null) {
            this.fromString = new MACAddressString(this);
        }
        return <MACAddressString><any>this.fromString;
    }

    public toNormalizedString(options? : any, zone? : any) : any {
        if(((options != null && options instanceof <any>AddressDivisionGrouping.StringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(options);
        } else if(options === undefined && zone === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(stringOptions : AddressDivisionGrouping.StringOptions) : string {
        return this.getSection().toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(stringOptions);
    }

    public toDottedString() : string {
        return this.getSection().toDottedString();
    }

    public toDashedString() : string {
        return this.toCanonicalString();
    }

    public toColonDelimitedString() : string {
        return this.toNormalizedString();
    }

    public toSpaceDelimitedString() : string {
        return this.getSection().toSpaceDelimitedString();
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.toNormalizedString();
    }

    public isUnicast() : boolean {
        return !this.isMulticast();
    }

    /**
     * Multicast MAC addresses have the least significant bit of the first octet set to 1.
     * @return {boolean}
     */
    public isMulticast() : boolean {
        return this.getSegment(0).matchesWithMask$int$int(1, 1);
    }

    /**
     * Universal MAC addresses have second the least significant bit of the first octet set to 0.
     * @return {boolean}
     */
    public isUniversal() : boolean {
        return !this.isLocal();
    }

    /**
     * Local MAC addresses have the second least significant bit of the first octet set to 1.
     * @return {boolean}
     */
    public isLocal() : boolean {
        return this.getSegment(0).matchesWithMask$int$int(2, 2);
    }
}
MACAddress["__class"] = "inet.ipaddr.mac.MACAddress";
MACAddress["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];





MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_BIT_COUNT_$LI$();

MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_BIT_COUNT_$LI$();

MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$();

MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR_STR_$LI$();
