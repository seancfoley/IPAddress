/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressNetwork } from '../AddressNetwork';
import { HostIdentifierString } from '../HostIdentifierString';
import { PrefixLenException } from '../PrefixLenException';
import { AddressCreator } from '../format/AddressCreator';
import { MACAddressSegment } from './MACAddressSegment';
import { MACAddress } from './MACAddress';
import { MACAddressSection } from './MACAddressSection';
import { Address } from '../Address';

export class MACAddressNetwork extends AddressNetwork<MACAddressSegment> {
    static __inet_ipaddr_mac_MACAddressNetwork_serialVersionUID : number = 4;

    static __inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration : AddressNetwork.PrefixConfiguration; public static __inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration_$LI$() : AddressNetwork.PrefixConfiguration { if(MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration == null) MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration = AddressNetwork.getDefaultPrefixConfiguration(); return MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration; };

    static EMPTY_SEGMENTS : MACAddressSegment[]; public static EMPTY_SEGMENTS_$LI$() : MACAddressSegment[] { if(MACAddressNetwork.EMPTY_SEGMENTS == null) MACAddressNetwork.EMPTY_SEGMENTS = []; return MACAddressNetwork.EMPTY_SEGMENTS; };

    createAddressCreator() : MACAddressNetwork.MACAddressCreator {
        return new MACAddressNetwork.MACAddressCreator(this);
    }

    /**
     * 
     * @return {MACAddressNetwork.MACAddressCreator}
     */
    public getAddressCreator() : MACAddressNetwork.MACAddressCreator {
        return this.creator;
    }

    /*private*/ creator : MACAddressNetwork.MACAddressCreator;

    public constructor() {
        super();
        if(this.creator===undefined) this.creator = null;
        this.creator = this.createAddressCreator();
    }

    /**
     * 
     * @return {AddressNetwork.PrefixConfiguration}
     */
    public getPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
        return MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration_$LI$();
    }

    /**
     * Sets the default prefix configuration used by this network.
     * 
     * @see #getDefaultPrefixConfiguration()
     * @see #getPrefixConfiguration()
     * @see PrefixConfiguration
     * @param {AddressNetwork.PrefixConfiguration} config
     */
    public static setDefaultPrefixConfiguration(config : AddressNetwork.PrefixConfiguration) {
        MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration = config;
    }

    /**
     * Gets the default prefix configuration used by this network.
     * 
     * @see AddressNetwork#getDefaultPrefixConfiguration()
     * @see PrefixConfiguration
     * @return {AddressNetwork.PrefixConfiguration}
     */
    public static getDefaultPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
        return MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration_$LI$();
    }
}
MACAddressNetwork["__class"] = "inet.ipaddr.mac.MACAddressNetwork";
MACAddressNetwork["__interfaces"] = ["java.io.Serializable"];



export namespace MACAddressNetwork {

    export class MACAddressCreator extends AddressCreator<MACAddress, MACAddressSection, MACAddressSection, MACAddressSegment> implements AddressNetwork.AddressSegmentCreator<MACAddressSegment> {
        static serialVersionUID : number = 4;

        ALL_RANGE_SEGMENT : MACAddressSegment;

        segmentCache : MACAddressSegment[];

        owner : MACAddressNetwork;

        constructor(owner : MACAddressNetwork) {
            super();
            if(this.ALL_RANGE_SEGMENT===undefined) this.ALL_RANGE_SEGMENT = null;
            if(this.segmentCache===undefined) this.segmentCache = null;
            if(this.owner===undefined) this.owner = null;
            this.owner = owner;
        }

        /**
         * 
         */
        public clearCaches() {
            this.segmentCache = null;
        }

        /**
         * 
         * @return {MACAddressNetwork}
         */
        public getNetwork() : MACAddressNetwork {
            return this.owner;
        }

        /**
         * 
         * @param {number} length
         * @return {Array}
         */
        public createSegmentArray(length : number) : MACAddressSegment[] {
            if(length === 0) {
                return MACAddressNetwork.EMPTY_SEGMENTS_$LI$();
            }
            return (s => { let a=[]; while(s-->0) a.push(null); return a; })(length);
        }

        public createSegment$int(value : number) : MACAddressSegment {
            if(value >= 0 && value <= MACAddress.MAX_VALUE_PER_SEGMENT) {
                let result : MACAddressSegment;
                let cache : MACAddressSegment[] = this.segmentCache;
                if(cache == null) {
                    this.segmentCache = cache = (s => { let a=[]; while(s-->0) a.push(null); return a; })(MACAddress.MAX_VALUE_PER_SEGMENT + 1);
                    cache[value] = result = new MACAddressSegment(value);
                } else {
                    result = cache[value];
                    if(result == null) {
                        cache[value] = result = new MACAddressSegment(value);
                    }
                }
                return result;
            }
            return new MACAddressSegment(value);
        }

        public createSegment$int$java_lang_Integer(value : number, segmentPrefixLength : number) : MACAddressSegment {
            if(segmentPrefixLength != null) {
                if(segmentPrefixLength < 0) {
                    throw new PrefixLenException(segmentPrefixLength);
                }
                if(segmentPrefixLength > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_BIT_COUNT) {
                    throw new PrefixLenException(segmentPrefixLength);
                }
                if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                    if(segmentPrefixLength === 0) {
                        let result : MACAddressSegment = this.ALL_RANGE_SEGMENT;
                        if(result == null) {
                            this.ALL_RANGE_SEGMENT = result = new MACAddressSegment(0, MACAddress.MAX_VALUE_PER_SEGMENT);
                        }
                        return result;
                    }
                    let mask : number = ~0 << (MACAddress.BITS_PER_SEGMENT - segmentPrefixLength);
                    let newLower : number = value & mask;
                    let newUpper : number = value | ~mask;
                    return this.createRangeSegment(newLower, newUpper);
                }
            }
            return this.createSegment$int(value);
        }

        public createRangeSegment(lower : number, upper : number) : MACAddressSegment {
            if(lower !== upper) {
                if(lower === 0 && upper === MACAddress.MAX_VALUE_PER_SEGMENT) {
                    let result : MACAddressSegment = this.ALL_RANGE_SEGMENT;
                    if(result == null) {
                        this.ALL_RANGE_SEGMENT = result = new MACAddressSegment(0, upper);
                    }
                    return result;
                }
                return new MACAddressSegment(lower, upper);
            }
            return this.createSegment$int(lower);
        }

        public createSegment$int$int$java_lang_Integer(lower : number, upper : number, segmentPrefixLength : number) : MACAddressSegment {
            if(segmentPrefixLength == null) {
                return this.createRangeSegment(lower, upper);
            }
            if(segmentPrefixLength < 0) {
                throw new PrefixLenException(segmentPrefixLength);
            }
            if(segmentPrefixLength > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_BIT_COUNT) {
                throw new PrefixLenException(segmentPrefixLength);
            }
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                if(segmentPrefixLength === 0) {
                    let result : MACAddressSegment = this.ALL_RANGE_SEGMENT;
                    if(result == null) {
                        this.ALL_RANGE_SEGMENT = result = new MACAddressSegment(0, MACAddress.MAX_VALUE_PER_SEGMENT);
                    }
                    return result;
                }
                let max : number = MACAddress.MAX_VALUE_PER_SEGMENT;
                let mask : number = (~0 << (MACAddress.BITS_PER_SEGMENT - segmentPrefixLength)) & max;
                let newLower : number = lower & mask;
                let newUpper : number = upper | (~mask & max);
                return this.createRangeSegment(newLower, newUpper);
            }
            return this.createRangeSegment(lower, upper);
        }

        /**
         * 
         * @param {number} lower
         * @param {number} upper
         * @param {number} segmentPrefixLength
         * @return {MACAddressSegment}
         */
        public createSegment(lower? : any, upper? : any, segmentPrefixLength? : any) : any {
            if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                return <any>this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                super.createSegment(lower, upper, segmentPrefixLength);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
                return <any>this.createSegment$int$java_lang_Integer(lower, upper);
            } else if(((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
                return <any>this.createSegment$int(lower);
            } else throw new Error('invalid overload');
        }

        createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(value : number, segmentPrefixLength : number, addressStr : any, originalVal : number, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number) : MACAddressSegment {
            let segment : MACAddressSegment = this.createSegment$int$java_lang_Integer(value, segmentPrefixLength);
            segment.setString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardString, lowerStringStartIndex, lowerStringEndIndex, originalVal);
            return segment;
        }

        public createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower : number, upper : number, segmentPrefixLength : number, addressStr : any, originalLower : number, originalUpper : number, isStandardString : boolean, isStandardRangeString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, upperStringEndIndex : number) : MACAddressSegment {
            let segment : MACAddressSegment = this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
            segment.setString$java_lang_CharSequence$boolean$int$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, originalLower, originalUpper);
            return segment;
        }

        /**
         * 
         * @param {number} lower
         * @param {number} upper
         * @param {number} segmentPrefixLength
         * @param {*} addressStr
         * @param {number} originalLower
         * @param {number} originalUpper
         * @param {boolean} isStandardString
         * @param {boolean} isStandardRangeString
         * @param {number} lowerStringStartIndex
         * @param {number} lowerStringEndIndex
         * @param {number} upperStringEndIndex
         * @return {MACAddressSegment}
         */
        public createSegmentInternal(lower? : any, upper? : any, segmentPrefixLength? : any, addressStr? : any, originalLower? : any, originalUpper? : any, isStandardString? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, lowerStringEndIndex? : any, upperStringEndIndex? : any) : any {
            if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                return <any>this.createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                super.createSegmentInternal(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
            } else throw new Error('invalid overload');
        }

        createSection$long$int$boolean$java_lang_Integer(bytes : number, startIndex : number, extended : boolean, prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(bytes, startIndex, extended);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        createSection$long$int$boolean(bytes : number, startIndex : number, extended : boolean) : MACAddressSection {
            return new MACAddressSection(bytes, startIndex, extended);
        }

        createSection$byte_A$int$boolean$java_lang_Integer(bytes : number[], startIndex : number, extended : boolean, prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(bytes, startIndex, extended);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        createSection$byte_A$int$boolean(bytes : number[], startIndex : number, extended : boolean) : MACAddressSection {
            return new MACAddressSection(bytes, startIndex, extended);
        }

        createSection$byte_A$int$int$boolean$java_lang_Integer(bytes : number[], startIndex : number, segmentCount : number, extended : boolean, prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(bytes, 0, bytes.length, segmentCount, startIndex, extended, true);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        createSection$byte_A$int$int$boolean(bytes : number[], startIndex : number, segmentCount : number, extended : boolean) : MACAddressSection {
            return new MACAddressSection(bytes, 0, bytes.length, segmentCount, startIndex, extended, true);
        }

        public createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean$java_lang_Integer(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, startIndex : number, extended : boolean, prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(lowerValueProvider, upperValueProvider, startIndex, extended);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        public createSection(lowerValueProvider? : any, upperValueProvider? : any, startIndex? : any, extended? : any, prefixLength? : any) : any {
            if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                return <any>this.createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean$java_lang_Integer(lowerValueProvider, upperValueProvider, startIndex, extended, prefixLength);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                return <any>this.createSection$byte_A$int$int$boolean$java_lang_Integer(lowerValueProvider, upperValueProvider, startIndex, extended, prefixLength);
            } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null) && prefixLength === undefined) {
                return <any>this.createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider, upperValueProvider, startIndex, extended);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'boolean') || startIndex === null) && ((typeof extended === 'number') || extended === null) && prefixLength === undefined) {
                return <any>this.createSection$byte_A$int$boolean$java_lang_Integer(lowerValueProvider, upperValueProvider, startIndex, extended);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null) && prefixLength === undefined) {
                return <any>this.createSection$byte_A$int$int$boolean(lowerValueProvider, upperValueProvider, startIndex, extended);
            } else if(((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'boolean') || startIndex === null) && ((typeof extended === 'number') || extended === null) && prefixLength === undefined) {
                return <any>this.createSection$long$int$boolean$java_lang_Integer(lowerValueProvider, upperValueProvider, startIndex, extended);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null && lowerValueProvider[0] instanceof <any>MACAddressSegment))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'boolean') || upperValueProvider === null) && ((typeof startIndex === 'number') || startIndex === null) && extended === undefined && prefixLength === undefined) {
                return <any>this.createSection$inet_ipaddr_mac_MACAddressSegment_A$boolean$java_lang_Integer(lowerValueProvider, upperValueProvider, startIndex);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'boolean') || startIndex === null) && extended === undefined && prefixLength === undefined) {
                return <any>this.createSection$byte_A$int$boolean(lowerValueProvider, upperValueProvider, startIndex);
            } else if(((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof startIndex === 'boolean') || startIndex === null) && extended === undefined && prefixLength === undefined) {
                return <any>this.createSection$long$int$boolean(lowerValueProvider, upperValueProvider, startIndex);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null && lowerValueProvider[0] instanceof <any>MACAddressSegment))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'boolean') || upperValueProvider === null) && startIndex === undefined && extended === undefined && prefixLength === undefined) {
                return <any>this.createSection$inet_ipaddr_mac_MACAddressSegment_A$boolean(lowerValueProvider, upperValueProvider);
            } else throw new Error('invalid overload');
        }

        createSection$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$boolean(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, startIndex : number, extended : boolean) : MACAddressSection {
            return new MACAddressSection(lowerValueProvider, upperValueProvider, startIndex, extended);
        }

        createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(segments : MACAddressSegment[]) : MACAddressSection {
            return new MACAddressSection(false, segments, 0, segments.length > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$());
        }

        public createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer$boolean(segments : MACAddressSegment[], prefixLength : number, singleOnly : boolean) : MACAddressSection {
            return this.createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments, prefixLength);
        }

        /**
         * 
         * @param {Array} segments
         * @param {number} prefixLength
         * @param {boolean} singleOnly
         * @return {MACAddressSection}
         */
        public createPrefixedSectionInternal(segments? : any, prefixLength? : any, singleOnly? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer$boolean(segments, prefixLength, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefixLength, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && ((typeof prefixLength === 'number') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments, prefixLength);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefixLength === 'number') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefixLength);
            } else throw new Error('invalid overload');
        }

        createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments : MACAddressSegment[], prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(false, segments, 0, segments.length > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$());
            result.assignPrefixLength(prefixLength);
            return result;
        }

        createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$boolean(segments : MACAddressSegment[], extended : boolean) : MACAddressSection {
            return new MACAddressSection(false, segments, 0, extended);
        }

        createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(segments : MACAddressSegment[], startIndex : number, extended : boolean) : MACAddressSection {
            return new MACAddressSection(false, segments, startIndex, extended);
        }

        createSection$inet_ipaddr_mac_MACAddressSegment_A$boolean(segments : MACAddressSegment[], extended : boolean) : MACAddressSection {
            return new MACAddressSection(segments, 0, extended);
        }

        createSection$inet_ipaddr_mac_MACAddressSegment_A$boolean$java_lang_Integer(segments : MACAddressSegment[], extended : boolean, prefixLength : number) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(segments, 0, extended);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        public createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes : number[], segmentCount : number, prefixLength : number, singleOnly : boolean) : MACAddressSection {
            let result : MACAddressSection = new MACAddressSection(bytes, segmentCount, 0, segmentCount > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$(), false);
            result.assignPrefixLength(prefixLength);
            return result;
        }

        /**
         * 
         * @param {Array} bytes
         * @param {number} segmentCount
         * @param {number} prefixLength
         * @param {boolean} singleOnly
         * @return {MACAddressSection}
         */
        public createSectionInternal(bytes? : any, segmentCount? : any, prefixLength? : any, singleOnly? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes, segmentCount, prefixLength, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefixLength, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'boolean') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'boolean') || prefixLength === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$boolean(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>MACAddressSegment))) || bytes === null) && segmentCount === undefined && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefixLength === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        public createAddressInternal(segments? : any, zone? : any, from? : any, prefix? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && ((typeof prefix === 'number') || prefix === null)) {
                super.createAddressInternal(segments, zone, from, prefix);
            } else if(((segments != null && segments instanceof <any>MACAddressSection) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_mac_MACAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(segments, zone, from);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && ((typeof zone === 'number') || zone === null) && ((typeof from === 'boolean') || from === null) && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer$boolean(segments, zone, from);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof from === 'number') || from === null) && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, zone, from);
            } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(segments, zone, from);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof zone === 'number') || zone === null) && ((typeof from === 'boolean') || from === null) && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, zone, from);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(typeof segments[0] === 'number'))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(segments, zone);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && ((typeof zone === 'number') || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments, zone);
            } else if(((segments != null && segments instanceof <any>MACAddressSection) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_mac_MACAddressSection$inet_ipaddr_HostIdentifierString(segments, zone);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof zone === 'number') || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, zone);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(typeof segments[0] === 'number'))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(segments, zone);
            } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(segments, zone);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && zone === undefined && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A(segments);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && zone === undefined && from === undefined && prefix === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(segments);
            } else throw new Error('invalid overload');
        }

        createAddressInternal$byte_A$java_lang_CharSequence(bytes : number[], zone : any) : MACAddress {
            let section : MACAddressSection = new MACAddressSection(bytes, bytes.length, 0, bytes.length > MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$(), false);
            return this.createAddress$inet_ipaddr_mac_MACAddressSection(section);
        }

        createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A(segments : MACAddressSegment[]) : MACAddress {
            return this.createAddress$inet_ipaddr_mac_MACAddressSection(this.createSectionInternal$inet_ipaddr_mac_MACAddressSegment_A(segments));
        }

        createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments : MACAddressSegment[], prefix : number) : MACAddress {
            return this.createAddress$inet_ipaddr_mac_MACAddressSection(this.createPrefixedSectionInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments, prefix));
        }

        createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer$boolean(segments : MACAddressSegment[], prefix : number, singleOnly : boolean) : MACAddress {
            return this.createAddressInternal$inet_ipaddr_mac_MACAddressSegment_A$java_lang_Integer(segments, prefix);
        }

        createAddressInternal$inet_ipaddr_mac_MACAddressSection$inet_ipaddr_HostIdentifierString(section : MACAddressSection, from : HostIdentifierString) : MACAddress {
            let result : MACAddress = this.createAddress$inet_ipaddr_mac_MACAddressSection(section);
            result.cache(from);
            return result;
        }

        createAddressInternal$inet_ipaddr_mac_MACAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(section : MACAddressSection, zone : any, from : HostIdentifierString) : MACAddress {
            let result : MACAddress = this.createAddress$inet_ipaddr_mac_MACAddressSection(section);
            result.cache(from);
            return result;
        }

        public createAddress(lowerValueProvider? : any, upperValueProvider? : any, prefix? : any, zone? : any) : any {
            if(((lowerValueProvider != null && lowerValueProvider instanceof <any>MACAddressSection) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_mac_MACAddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_AddressSection(lowerValueProvider);
            } else throw new Error('invalid overload');
        }

        public createAddress$inet_ipaddr_mac_MACAddressSection(section : MACAddressSection) : MACAddress {
            return new MACAddress(section);
        }
    }
    MACAddressCreator["__class"] = "inet.ipaddr.mac.MACAddressNetwork.MACAddressCreator";
    MACAddressCreator["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];


}




MACAddressNetwork.EMPTY_SEGMENTS_$LI$();

MACAddressNetwork.__inet_ipaddr_mac_MACAddressNetwork_defaultPrefixConfiguration_$LI$();
