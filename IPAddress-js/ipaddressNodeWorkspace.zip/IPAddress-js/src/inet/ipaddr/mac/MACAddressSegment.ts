/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressSegment } from '../AddressSegment';
import { AddressValueException } from '../AddressValueException';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { AddressDivision } from '../format/AddressDivision';
import { AddressDivisionWriter } from '../format/util/AddressDivisionWriter';
import { MACAddress } from './MACAddress';
import { MACAddressNetwork } from './MACAddressNetwork';
import { AddressNetwork } from '../AddressNetwork';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { MACAddressSection } from './MACAddressSection';

/**
 * Constructs a segment of a MAC address that represents a range of values.
 * 
 * @throws AddressValueException if value is negative or too large
 * @param {number} lower the lower value of the range of values represented by the segment.
 * @param {number} upper the upper value of the range of values represented by the segment.
 * @class
 * @extends AddressDivision
 */
export class MACAddressSegment extends AddressDivision implements AddressSegment {
    static serialVersionUID : number = 4;

    public static MAX_CHARS : number = 2;

    /*private*/ value : number;

    /*private*/ upperValue : number;

    public constructor(lower? : any, upper? : any) {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super();
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(lower > upper) {
                    let tmp : number = lower;
                    lower = upper;
                    upper = tmp;
                }
                if(lower < 0 || upper < 0 || upper > MACAddress.MAX_VALUE_PER_SEGMENT) {
                    throw new AddressValueException(lower < 0?lower:upper);
                }
                this.value = lower;
                this.upperValue = upper;
            })();
        } else if(((typeof lower === 'number') || lower === null) && upper === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            super();
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(value < 0 || value > MACAddress.MAX_VALUE_PER_SEGMENT) {
                    throw new AddressValueException(value);
                }
                this.value = this.upperValue = value;
            })();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        return [(<number>(low?this.getLowerSegmentValue():this.getUpperSegmentValue())|0)];
    }

    public isPrefixBlock(divisionValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof divisionValue === 'number') || divisionValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            super.isPrefixBlock(divisionValue, upperValue, divisionPrefixLen);
        } else if(((typeof divisionValue === 'number') || divisionValue === null) && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$int(divisionValue);
        } else throw new Error('invalid overload');
    }

    isPrefixBlock$int(segmentPrefixLength : number) : boolean {
        if(segmentPrefixLength < MACAddress.BITS_PER_SEGMENT) {
            let mask : number = ~0 << (MACAddress.BITS_PER_SEGMENT - segmentPrefixLength);
            let lower : number = this.getLowerSegmentValue();
            let newLower : number = lower & mask;
            if(lower !== newLower) {
                return false;
            }
            let upper : number = this.getUpperSegmentValue();
            return upper === (upper | ~mask);
        }
        return true;
    }

    toPrefixBlockSegment(segmentPrefixLength : number) : MACAddressSegment {
        if(segmentPrefixLength < MACAddress.BITS_PER_SEGMENT && !this.isPrefixBlock$int(segmentPrefixLength)) {
            let lower : number = this.getLowerSegmentValue();
            let upper : number = this.getUpperSegmentValue();
            let mask : number = ~0 << (MACAddress.BITS_PER_SEGMENT - segmentPrefixLength);
            lower &= mask;
            upper |= ~mask;
            return this.getSegmentCreator().createRangeSegment(lower, upper);
        }
        return this;
    }

    setPrefixedSegment(oldPrefixLength : number, segmentPrefixLength : number, zeroed : boolean) : MACAddressSegment {
        return <any>(AddressDivision.setPrefixedSegment<any>(this, oldPrefixLength, segmentPrefixLength, zeroed, this.getSegmentCreator()));
    }

    /*private*/ getSegmentCreator() : MACAddressNetwork.MACAddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    /**
     * 
     * @return {MACAddressNetwork}
     */
    public getNetwork() : MACAddressNetwork {
        return MACAddress.defaultMACNetwork();
    }

    /**
     * 
     * @return {number}
     */
    public getValueCount() : number {
        return this.getUpperSegmentValue() - this.getLowerSegmentValue() + 1;
    }

    getPrefixValueCount(segmentPrefixLength : number) : number {
        let shiftAdjustment : number = MACAddress.BITS_PER_SEGMENT - segmentPrefixLength;
        return (this.getUpperSegmentValue() >>> shiftAdjustment) - (this.getLowerSegmentValue() >>> shiftAdjustment) + 1;
    }

    /**
     * 
     * @return {number}
     */
    public getDivisionValueCount() : number {
        return this.getValueCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return MACAddress.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return MACAddress.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getMaxValue() : number {
        return MACAddress.MAX_VALUE_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getLowerValue() : number {
        return this.getLowerSegmentValue();
    }

    /**
     * 
     * @return {number}
     */
    public getUpperValue() : number {
        return this.getUpperSegmentValue();
    }

    /**
     * returns the lower value
     * @return {number}
     */
    public getLowerSegmentValue() : number {
        return this.value;
    }

    /**
     * returns the upper value
     * @return {number}
     */
    public getUpperSegmentValue() : number {
        return this.upperValue;
    }

    /*private*/ getLowestOrHighest(lowest : boolean) : MACAddressSegment {
        if(!this.isMultiple()) {
            return this;
        }
        return this.getSegmentCreator().createSegment$int(lowest?this.getLowerSegmentValue():this.getUpperSegmentValue());
    }

    /**
     * 
     * @return {MACAddressSegment}
     */
    public getLower() : MACAddressSegment {
        return this.getLowestOrHighest(true);
    }

    /**
     * 
     * @return {MACAddressSegment}
     */
    public getUpper() : MACAddressSegment {
        return this.getLowestOrHighest(false);
    }

    public reverseBits$boolean(perByte : boolean) : MACAddressSegment {
        return this.reverseBits();
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {MACAddressSegment}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else if(perByte === undefined) {
            return <any>this.reverseBits$();
        } else throw new Error('invalid overload');
    }

    public reverseBits$() : MACAddressSegment {
        if(this.isMultiple()) {
            if(AddressDivision.isReversibleRange<any>(this)) {
                return this;
            }
            throw new IncompatibleAddressException(this, "ipaddress.error.reverseRange");
        }
        let oldValue : number = this.value;
        let newValue : number = AddressDivision.reverseBits$byte((<number>oldValue|0));
        if(oldValue === newValue) {
            return this;
        }
        let creator : AddressNetwork.AddressSegmentCreator<MACAddressSegment> = this.getSegmentCreator();
        return creator['createSegment$int'](newValue);
    }

    public reverseBytes(perSegment? : any) : any {
        if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else throw new Error('invalid overload');
    }

    public reverseBytes$() : MACAddressSegment {
        return this;
    }

    /**
     * 
     * @param {number} value
     * @return {boolean}
     */
    public isBoundedBy(value : number) : boolean {
        return this.getUpperSegmentValue() < value;
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean {
        if(other != null && other instanceof <any>MACAddressSegment) {
            return this.isSameValues$inet_ipaddr_format_AddressDivision(<MACAddressSegment>other);
        }
        return false;
    }

    public isSameValues$inet_ipaddr_mac_MACAddressSegment(otherSegment : MACAddressSegment) : boolean {
        return this.value === otherSegment.value && this.upperValue === otherSegment.upperValue;
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>MACAddressSegment) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_mac_MACAddressSegment(otherSegment);
        } else if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return MACAddressSegment.hash(this.value, this.upperValue, this.getBitCount());
    }

    static hash(lower : number, upper : number, bitCount : number) : number {
        return lower | (upper << bitCount);
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public equals(other : any) : boolean {
        if(this === other) {
            return true;
        }
        return (other != null && other instanceof <any>MACAddressSegment) && this.isSameValues$inet_ipaddr_format_AddressDivision(<MACAddressSegment>other);
    }

    public contains$inet_ipaddr_mac_MACAddressSegment(other : MACAddressSegment) : boolean {
        return other.value >= this.value && other.upperValue <= this.upperValue;
    }

    /**
     * 
     * @param {MACAddressSegment} other
     * @return {boolean} whether this subnet segment contains the given address segment
     */
    public contains(other? : any) : any {
        if(((other != null && other instanceof <any>MACAddressSegment) || other === null)) {
            return <any>this.contains$inet_ipaddr_mac_MACAddressSegment(other);
        } else if(((other != null && (other["__interfaces"] != null && other["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || other.constructor != null && other.constructor["__interfaces"] != null && other.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)) || other === null)) {
            return <any>this.contains$inet_ipaddr_AddressSegment(other);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        return this.includesZero() && this.includesMax();
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return MACAddress.DEFAULT_TEXTUAL_RADIX;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        return MACAddressSegment.MAX_CHARS;
    }

    public matches$int(value : number) : boolean {
        return super.matches$long(value);
    }

    /**
     * 
     * @param {number} value
     * @return {boolean}
     */
    public matches(value? : any) : any {
        if(((typeof value === 'number') || value === null)) {
            return <any>this.matches$int(value);
        } else if(((typeof value === 'number') || value === null)) {
            return <any>this.matches$long(value);
        } else throw new Error('invalid overload');
    }

    public matchesWithMask$int$int(value : number, mask : number) : boolean {
        return super.matchesWithMask$long$long(value, mask);
    }

    public matchesWithMask$int$int$int(lowerValue : number, upperValue : number, mask : number) : boolean {
        return super.matchesWithMask$long$long$long(lowerValue, upperValue, mask);
    }

    /**
     * 
     * @param {number} lowerValue
     * @param {number} upperValue
     * @param {number} mask
     * @return {boolean}
     */
    public matchesWithMask(lowerValue? : any, upperValue? : any, mask? : any) : any {
        if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof mask === 'number') || mask === null)) {
            return <any>this.matchesWithMask$int$int$int(lowerValue, upperValue, mask);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof mask === 'number') || mask === null)) {
            return <any>this.matchesWithMask$long$long$long(lowerValue, upperValue, mask);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && mask === undefined) {
            return <any>this.matchesWithMask$int$int(lowerValue, upperValue);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && mask === undefined) {
            return <any>this.matchesWithMask$long$long(lowerValue, upperValue);
        } else throw new Error('invalid overload');
    }

    setString$java_lang_CharSequence$boolean$int$int$int(addressStr : any, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, originalLowerValue : number) {
        if(this.cachedString == null && isStandardString && originalLowerValue === this.getLowerValue()) {
            this.cachedString = /* subSequence */addressStr.substring(lowerStringStartIndex, lowerStringEndIndex).toString();
        }
    }

    public setString$java_lang_CharSequence$boolean$int$int$int$int(addressStr : any, isStandardRangeString : boolean, lowerStringStartIndex : number, upperStringEndIndex : number, rangeLower : number, rangeUpper : number) {
        if(this.cachedString == null) {
            if(this.isFullRange()) {
                this.cachedString = MACAddress.SEGMENT_WILDCARD_STR_$LI$();
            } else if(isStandardRangeString && rangeLower === this.getLowerValue() && rangeUpper === this.getUpperValue()) {
                this.cachedString = /* subSequence */addressStr.substring(lowerStringStartIndex, upperStringEndIndex).toString();
            }
        }
    }

    public setString(addressStr? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, upperStringEndIndex? : any, rangeLower? : any, rangeUpper? : any) : any {
        if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null) && ((typeof rangeLower === 'number') || rangeLower === null) && ((typeof rangeUpper === 'number') || rangeUpper === null)) {
            return <any>this.setString$java_lang_CharSequence$boolean$int$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, rangeLower, rangeUpper);
        } else if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null) && ((typeof rangeLower === 'number') || rangeLower === null) && rangeUpper === undefined) {
            return <any>this.setString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, rangeLower);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<MACAddressSegment> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        return AddressDivision.iterator<any>(this, this.getSegmentCreator(), true, null);
    }

    prefixBlockIterator(segmentPrefixLength : number) : any {
        return AddressDivision.iterator<any>(this, this.getSegmentCreator(), true, segmentPrefixLength);
    }

    /**
     * 
     * @return {number}
     */
    public getMaxSegmentValue() : number {
        return MACAddress.MAX_VALUE_PER_SEGMENT;
    }

    public contains$inet_ipaddr_AddressSegment(other : AddressSegment) : boolean {
        return (other != null && other instanceof <any>MACAddressSegment) && other.getLowerSegmentValue() >= this.value && other.getUpperSegmentValue() <= this.upperValue;
    }

    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toHexString$boolean(with0xPrefix : boolean) : string {
        return this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(with0xPrefix?MACAddressSection.MACStringCache.hexPrefixedParams_$LI$():MACAddressSection.MACStringCache.hexParams_$LI$());
    }

    public toNormalizedString(options? : any, zone? : any) : any {
        if(((options != null && options instanceof <any>AddressDivisionGrouping.StringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(options);
        } else if(options === undefined && zone === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        return this.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(MACAddressSection.MACStringCache.canonicalParams_$LI$());
    }

    public toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(options : AddressDivisionGrouping.StringOptions) : string {
        let params : AddressDivisionWriter = MACAddressSection.toParams(options);
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        return /* toString */params.appendDivision(builder, this).str;
    }
}
MACAddressSegment["__class"] = "inet.ipaddr.mac.MACAddressSegment";
MACAddressSegment["__interfaces"] = ["inet.ipaddr.AddressSegment","inet.ipaddr.AddressComponent","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];




