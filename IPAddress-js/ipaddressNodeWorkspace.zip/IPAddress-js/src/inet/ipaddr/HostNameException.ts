/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierException } from './HostIdentifierException';
import { AddressStringException } from './AddressStringException';

/**
 * 
 * @author sfoley
 * @param {string} host
 * @param {number} index
 * @param {Error} cause
 * @class
 * @extends HostIdentifierException
 */
export class HostNameException extends HostIdentifierException {
    static __inet_ipaddr_HostNameException_serialVersionUID : number = 4;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(HostNameException.errorMessage == null) HostNameException.errorMessage = this.message; return HostNameException.errorMessage; };

    public constructor(host? : any, e? : any, key? : any) {
        if(((typeof host === 'string') || host === null) && ((e != null && e instanceof <any>AddressStringException) || e === null) && ((typeof key === 'string') || key === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(host, HostNameException.errorMessage_$LI$(), key, e);
            (<any>Object).setPrototypeOf(this, HostNameException.prototype);
        } else if(((typeof host === 'string') || host === null) && ((typeof e === 'number') || e === null) && ((key != null && (key["__classes"] && key["__classes"].indexOf("java.lang.Throwable") >= 0) || key != null && key instanceof <any>Error) || key === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let index : any = __args[1];
            let cause : any = __args[2];
            super(host + " " + HostNameException.errorMessage_$LI$() + " " + this.message + ' ' + index, cause);
            (<any>Object).setPrototypeOf(this, HostNameException.prototype);
        } else if(((typeof host === 'string') || host === null) && ((typeof e === 'string') || e === null) && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[1];
            super(host, HostNameException.errorMessage_$LI$(), key);
            (<any>Object).setPrototypeOf(this, HostNameException.prototype);
        } else if(((typeof host === 'string') || host === null) && ((typeof e === 'number') || e === null) && key === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let index : any = __args[1];
            super(host + " " + HostNameException.errorMessage_$LI$() + " " + this.message + ' ' + index);
            (<any>Object).setPrototypeOf(this, HostNameException.prototype);
        } else throw new Error('invalid overload');
    }
}
HostNameException["__class"] = "inet.ipaddr.HostNameException";
HostNameException["__interfaces"] = ["java.io.Serializable"];





HostNameException.errorMessage_$LI$();
