/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressValueException } from './AddressValueException';
import { AddressStringException } from './AddressStringException';

/**
 * IPv6 and MAC address sections are not position-independent, which means they have a designated location within a full address.
 * <p>
 * This exception is thrown in places where the designated position is invalid,
 * such as constructing an address from a section not located at position 0, which is the default position for sections.
 * <p>
 * However, in most operations such as replace and append, the position of the replacement or appended section is ignored and so this exception does not apply.
 * <p>
 * IPv4 sections are position independent, so this exception does not apply to IPv4.
 * 
 * @author sfoley
 * @param {*} item
 * @param {number} position
 * @param {number} otherPosition
 * @class
 * @extends AddressValueException
 */
export class AddressPositionException extends AddressValueException {
    static __inet_ipaddr_AddressPositionException_serialVersionUID : number = 1;

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(item? : any, position? : any, otherPosition? : any) {
        if(((item != null && (item["__interfaces"] != null && item["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || item.constructor != null && item.constructor["__interfaces"] != null && item.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || item === null) && ((typeof position === 'number') || position === null) && ((typeof otherPosition === 'number') || otherPosition === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(item + ", " + position + ", " + otherPosition + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, AddressPositionException.prototype);
        } else if(((item != null && (item["__interfaces"] != null && item["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || item.constructor != null && item.constructor["__interfaces"] != null && item.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || item === null) && ((typeof position === 'number') || position === null) && otherPosition === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(item + ", " + position + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, AddressPositionException.prototype);
        } else if(((typeof item === 'number') || item === null) && position === undefined && otherPosition === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let position : any = __args[0];
            super(position + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message);
            (<any>Object).setPrototypeOf(this, AddressPositionException.prototype);
        } else throw new Error('invalid overload');
    }
}
AddressPositionException["__class"] = "inet.ipaddr.AddressPositionException";
AddressPositionException["__interfaces"] = ["java.io.Serializable"];




