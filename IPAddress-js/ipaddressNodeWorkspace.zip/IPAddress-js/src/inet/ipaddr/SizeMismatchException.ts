/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressStringException } from './AddressStringException';

export class SizeMismatchException extends Error {
    static serialVersionUID : number = 1;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(SizeMismatchException.errorMessage == null) SizeMismatchException.errorMessage = this.message; return SizeMismatchException.errorMessage; };

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(one : AddressItem, two : AddressItem) {
        super(one + ", " + two + ", " + SizeMismatchException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + two + ", " + SizeMismatchException.errorMessage_$LI$() + " " + this.message;
        (<any>Object).setPrototypeOf(this, SizeMismatchException.prototype);
    }
}
SizeMismatchException["__class"] = "inet.ipaddr.SizeMismatchException";
SizeMismatchException["__interfaces"] = ["java.io.Serializable"];





SizeMismatchException.errorMessage_$LI$();
