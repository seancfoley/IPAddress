/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressCreator } from './format/AddressCreator';
import { HostIdentifierStringValidator } from './format/validate/HostIdentifierStringValidator';
import { IPv4Address } from './ipv4/IPv4Address';
import { IPv4AddressNetwork } from './ipv4/IPv4AddressNetwork';
import { IPv6Address } from './ipv6/IPv6Address';
import { IPv6AddressNetwork } from './ipv6/IPv6AddressNetwork';
import { IPAddress } from './IPAddress';
import { IPAddressSection } from './IPAddressSection';
import { IPAddressSegment } from './IPAddressSegment';
import { AddressNetwork } from './AddressNetwork';
import { Address } from './Address';
import { HostName } from './HostName';
import { HostIdentifierString } from './HostIdentifierString';
import { PrefixLenException } from './PrefixLenException';
import { IPAddressDivisionGrouping } from './format/IPAddressDivisionGrouping';
import { IPAddressStringParameters } from './IPAddressStringParameters';
import { IPAddressString } from './IPAddressString';
import { IPv4AddressStringParameters } from './ipv4/IPv4AddressStringParameters';
import { IPv6AddressStringParameters } from './ipv6/IPv6AddressStringParameters';
import { HostNameParameters } from './HostNameParameters';

/**
 * Represents a network of addresses of a single IP version providing a collection of standard addresses components for that version, such as masks and loopbacks.
 * 
 * @author sfoley
 * @extends AddressNetwork
 * @class
 */
export abstract class IPAddressNetwork<T extends IPAddress, R extends IPAddressSection, E extends IPAddressSection, S extends IPAddressSegment, J extends InetAddress> extends AddressNetwork<S> {
    static __inet_ipaddr_IPAddressNetwork_serialVersionUID : number = 4;

    /*private*/ subnets : T[];

    /*private*/ subnetMasks : T[];

    /*private*/ hostMasks : T[];

    /*private*/ networkSegmentMasks : number[];

    /*private*/ hostSegmentMasks : number[];

    /*private*/ loopback : T;

    /*private*/ loopbackStrings : string[];

    /*private*/ creator : IPAddressNetwork.IPAddressCreator<T, R, E, S, J>;

    constructor(addressType : any) {
        super();
        if(this.subnets===undefined) this.subnets = null;
        if(this.subnetMasks===undefined) this.subnetMasks = null;
        if(this.hostMasks===undefined) this.hostMasks = null;
        if(this.networkSegmentMasks===undefined) this.networkSegmentMasks = null;
        if(this.hostSegmentMasks===undefined) this.hostSegmentMasks = null;
        if(this.loopback===undefined) this.loopback = null;
        if(this.loopbackStrings===undefined) this.loopbackStrings = null;
        if(this.creator===undefined) this.creator = null;
        let version : IPAddress.IPVersion = this.getIPVersion();
        let bitSize : number = IPAddress.getBitCount(version);
        this.subnets = <T[]>/* newInstance */new Array<any>(bitSize + 1);
        this.subnetMasks = /* clone */this.subnets.slice(0);
        this.hostMasks = /* clone */this.subnets.slice(0);
        this.creator = this.createAddressCreator();
        let segmentBitSize : number = IPAddressSegment.getBitCount(version);
        let fullMask : number = ~(~0 << segmentBitSize);
        this.networkSegmentMasks = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segmentBitSize + 1);
        this.hostSegmentMasks = /* clone */this.networkSegmentMasks.slice(0);
        for(let i : number = 0; i <= segmentBitSize; i++) {
            let networkMask : number = this.networkSegmentMasks[i] = fullMask & (fullMask << (segmentBitSize - i));
            this.hostSegmentMasks[i] = ~networkMask & fullMask;
        };
    }

    /**
     * 
     */
    public clearCaches() {
        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(this.subnets, null);
        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(this.subnetMasks, null);
        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(this.hostMasks, null);
        this.loopback = null;
        this.loopbackStrings = null;
        super.clearCaches();
    }

    public isIPv4() : boolean {
        return false;
    }

    public isIPv6() : boolean {
        return false;
    }

    public abstract getIPVersion() : IPAddress.IPVersion;

    abstract getSegmentProducer() : (p1: T, p2: number) => S;

    abstract getSectionProducer() : (p1: T) => R;

    abstract createAddressCreator() : IPAddressNetwork.IPAddressCreator<T, R, E, S, J>;

    /**
     * 
     * @return {IPAddressNetwork.IPAddressCreator}
     */
    public getAddressCreator() : IPAddressNetwork.IPAddressCreator<T, R, E, S, J> {
        return this.creator;
    }

    public getLoopback() : T {
        if(this.loopback == null) {
            {
                if(this.loopback == null) {
                    this.loopback = this.createLoopback();
                }
            };
        }
        return this.loopback;
    }

    abstract createLoopback() : T;

    public getStandardLoopbackStrings() : string[] {
        if(this.loopbackStrings == null) {
            {
                if(this.loopbackStrings == null) {
                    this.loopbackStrings = this.getLoopback().toStandardStrings();
                }
            };
        }
        return this.loopbackStrings;
    }

    public getSegmentNetworkMask(segmentPrefixLength : number) : number {
        return (<number>this.networkSegmentMasks[segmentPrefixLength]|0);
    }

    public getSegmentHostMask(segmentPrefixLength : number) : number {
        return (<number>this.hostSegmentMasks[segmentPrefixLength]|0);
    }

    public getNetworkMask(networkPrefixLength : number, withPrefixLength : boolean = true) : T {
        return this.getMask(networkPrefixLength, withPrefixLength?this.subnets:this.subnetMasks, true, withPrefixLength);
    }

    public getNetworkMaskSection(networkPrefixLength : number) : R {
        return (target => (typeof target === 'function')?target(this.getNetworkMask(networkPrefixLength, true)):(<any>target).apply(this.getNetworkMask(networkPrefixLength, true)))(this.getSectionProducer());
    }

    public getHostMask(networkPrefixLength : number) : T {
        return this.getMask(networkPrefixLength, this.hostMasks, false, false);
    }

    public getHostMaskSection(networkPrefixLength : number) : R {
        return (target => (typeof target === 'function')?target(this.getHostMask(networkPrefixLength)):(<any>target).apply(this.getHostMask(networkPrefixLength)))(this.getSectionProducer());
    }

    getMask(networkPrefixLength : number, cache : T[], network : boolean, withPrefixLength : boolean) : T {
        let bits : number = networkPrefixLength;
        let version : IPAddress.IPVersion = this.getIPVersion();
        let addressBitLength : number = IPAddress.getBitCount(version);
        if(bits < 0 || bits > addressBitLength) {
            throw new PrefixLenException(bits, version);
        }
        let cacheIndex : number = bits;
        let subnet : T = cache[cacheIndex];
        if(subnet == null) {
            let onesSubnetIndex : number;
            let zerosSubnetIndex : number;
            if(network) {
                onesSubnetIndex = addressBitLength;
                zerosSubnetIndex = 0;
            } else {
                onesSubnetIndex = 0;
                zerosSubnetIndex = addressBitLength;
            }
            let onesSubnet : T = cache[onesSubnetIndex];
            let zerosSubnet : T = cache[zerosSubnetIndex];
            if(onesSubnet == null || zerosSubnet == null) {
                {
                    let segmentCount : number = IPAddress.getSegmentCount(version);
                    let bitsPerSegment : number = IPAddress.getBitsPerSegment(version);
                    let bytesPerSegment : number = IPAddress.getBytesPerSegment(version);
                    onesSubnet = cache[onesSubnetIndex];
                    if(onesSubnet == null) {
                        let creator : IPAddressNetwork.IPAddressCreator<T, any, any, S, any> = this.getAddressCreator();
                        let newSegments : S[] = creator.createSegmentArray(segmentCount);
                        let maxSegmentValue : number = IPAddress.getMaxSegmentValue(version);
                        if(network && withPrefixLength) {
                            let segment : S = creator['createSegment$int$java_lang_Integer'](maxSegmentValue, IPAddressSection.getSegmentPrefixLength$int$int(bitsPerSegment, addressBitLength));
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, 0, newSegments.length - 1, segment);
                            let lastSegment : S = creator['createSegment$int$java_lang_Integer'](maxSegmentValue, IPAddressSection.getSegmentPrefixLength$int$int(bitsPerSegment, bitsPerSegment));
                            newSegments[newSegments.length - 1] = lastSegment;
                            onesSubnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(newSegments, addressBitLength);
                        } else {
                            let segment : S = creator['createSegment$int'](maxSegmentValue);
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, segment);
                            onesSubnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A(newSegments);
                        }
                        this.initMaskCachedValues(onesSubnet.getSection(), network, withPrefixLength, addressBitLength, onesSubnetIndex, segmentCount, bitsPerSegment, bytesPerSegment);
                        cache[onesSubnetIndex] = onesSubnet;
                    }
                    zerosSubnet = cache[zerosSubnetIndex];
                    if(zerosSubnet == null) {
                        let creator : IPAddressNetwork.IPAddressCreator<T, any, any, S, any> = this.getAddressCreator();
                        let newSegments : S[] = creator.createSegmentArray(segmentCount);
                        let seg : S;
                        if(network && withPrefixLength) {
                            seg = creator['createSegment$int$java_lang_Integer'](0, IPAddressSection.getSegmentPrefixLength$int$int(bitsPerSegment, 0));
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, seg);
                            zerosSubnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(newSegments, 0);
                        } else {
                            seg = creator['createSegment$int'](0);
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, seg);
                            zerosSubnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A(newSegments);
                        }
                        this.initMaskCachedValues(zerosSubnet.getSection(), network, withPrefixLength, addressBitLength, zerosSubnetIndex, segmentCount, bitsPerSegment, bytesPerSegment);
                        cache[zerosSubnetIndex] = zerosSubnet;
                    }
                };
            }
            {
                subnet = cache[cacheIndex];
                if(subnet == null) {
                    let segProducer : (p1: T, p2: number) => S = <any>(this.getSegmentProducer());
                    let segmentCount : number = IPAddress.getSegmentCount(version);
                    let bitsPerSegment : number = IPAddress.getBitsPerSegment(version);
                    let bytesPerSegment : number = IPAddress.getBytesPerSegment(version);
                    let prefix : number = bits;
                    let onesSegment : S = (target => (typeof target === 'function')?target(onesSubnet, 1):(<any>target).apply(onesSubnet, 1))(segProducer);
                    let zerosSegment : S = (target => (typeof target === 'function')?target(zerosSubnet, 1):(<any>target).apply(zerosSubnet, 1))(segProducer);
                    let creator : IPAddressNetwork.IPAddressCreator<T, any, any, S, any> = this.getAddressCreator();
                    let segmentList : Array<S> = <any>([]);
                    let i : number = 0;
                    for(; bits > 0; i++, bits -= bitsPerSegment) {
                        if(bits <= bitsPerSegment) {
                            let segment : S = null;
                            let offset : number = ((bits - 1) % bitsPerSegment) + 1;
                            for(let j : number = 0, entry : number = offset; j < segmentCount; j++, entry += bitsPerSegment) {
                                if(entry !== cacheIndex) {
                                    let prev : T = cache[entry];
                                    if(prev != null) {
                                        segment = (target => (typeof target === 'function')?target(prev, j):(<any>target).apply(prev, j))(segProducer);
                                        break;
                                    }
                                }
                            };
                            if(segment == null) {
                                let mask : number = this.getSegmentNetworkMask(bits);
                                if(network) {
                                    if(withPrefixLength) {
                                        segment = creator['createSegment$int$java_lang_Integer'](mask, IPAddressSection.getSegmentPrefixLength$int$int(bitsPerSegment, bits));
                                    } else {
                                        segment = creator['createSegment$int'](mask);
                                    }
                                } else {
                                    segment = creator['createSegment$int'](this.getSegmentHostMask(bits));
                                }
                            }
                            /* add */(segmentList.push(segment)>0);
                        } else {
                            /* add */(segmentList.push(network?onesSegment:zerosSegment)>0);
                        }
                    };
                    for(; i < segmentCount; i++) {
                        /* add */(segmentList.push(network?zerosSegment:onesSegment)>0);
                    };
                    let newSegments : S[] = creator.createSegmentArray(/* size */(<number>segmentList.length));
                    /* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })(newSegments, segmentList);
                    if(network && withPrefixLength) {
                        subnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(newSegments, prefix);
                    } else {
                        subnet = creator.createAddressInternal$inet_ipaddr_IPAddressSegment_A(newSegments);
                    }
                    this.initMaskCachedValues(subnet.getSection(), network, withPrefixLength, addressBitLength, prefix, segmentCount, bitsPerSegment, bytesPerSegment);
                    cache[cacheIndex] = subnet;
                }
            };
        }
        return subnet;
    }

    initMaskCachedValues(section : IPAddressSection, network : boolean, withPrefixLength : boolean, addressBitLength : number, networkPrefixLength : number, segmentCount : number, bitsPerSegment : number, bytesPerSegment : number) {
        let cachedNetworkPrefix : number;
        let cachedMinPrefix : number;
        let cachedEquivalentPrefix : number;
        let cachedCount : BigInteger;
        let zeroSegments : IPAddressDivisionGrouping.RangeList;
        let zeroRanges : IPAddressDivisionGrouping.RangeList;
        let hasZeroRanges : boolean = network?addressBitLength - networkPrefixLength >= bitsPerSegment:networkPrefixLength >= bitsPerSegment;
        let noZeros : IPAddressDivisionGrouping.RangeList = IPAddressSection.getNoZerosRange();
        if(hasZeroRanges) {
            let rangeIndex : number;
            let rangeLen : number;
            if(network) {
                let segmentIndex : number = IPAddressSection.getNetworkSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment) + 1;
                rangeIndex = segmentIndex;
                rangeLen = segmentCount - segmentIndex;
            } else {
                rangeIndex = 0;
                rangeLen = IPAddressSection.getHostSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
            }
            zeroRanges = IPAddressSection.getSingleRange(rangeIndex, rangeLen);
            zeroSegments = (network && withPrefixLength && !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getPrefixConfiguration()].prefixedSubnetsAreExplicit())?noZeros:zeroRanges;
        } else {
            zeroSegments = zeroRanges = noZeros;
        }
        if(network && withPrefixLength) {
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getPrefixConfiguration()].prefixedSubnetsAreExplicit()) {
                cachedEquivalentPrefix = cachedMinPrefix = addressBitLength;
                cachedNetworkPrefix = networkPrefixLength;
                cachedCount = BigInteger.ONE;
            } else {
                cachedEquivalentPrefix = cachedMinPrefix = cachedNetworkPrefix = networkPrefixLength;
                cachedCount = BigInteger.valueOf(2).pow(addressBitLength - networkPrefixLength);
            }
        } else {
            cachedEquivalentPrefix = cachedMinPrefix = addressBitLength;
            cachedNetworkPrefix = null;
            cachedCount = BigInteger.ONE;
        }
        section.initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(networkPrefixLength, network, cachedNetworkPrefix, cachedMinPrefix, cachedEquivalentPrefix, cachedCount, zeroSegments, zeroRanges);
    }

    public static getPrefixString(networkPrefixLength : number) : string {
        return /* toString *//* append */(sb => { sb.str = sb.str.concat(<any>networkPrefixLength); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })({ str: "", toString: function() { return this.str; } })).str;
    }
}
IPAddressNetwork["__class"] = "inet.ipaddr.IPAddressNetwork";
IPAddressNetwork["__interfaces"] = ["java.io.Serializable"];



export namespace IPAddressNetwork {

    export abstract class IPAddressCreator<T extends IPAddress, R extends IPAddressSection, E extends IPAddressSection, S extends IPAddressSegment, J extends InetAddress> extends AddressCreator<T, R, E, S> {
        static serialVersionUID : number = 4;

        owner : IPAddressNetwork<T, R, E, S, J>;

        constructor(owner : IPAddressNetwork<T, R, E, S, J>) {
            super();
            if(this.owner===undefined) this.owner = null;
            this.owner = owner;
        }

        /**
         * 
         * @return {IPAddressNetwork}
         */
        public getNetwork() : IPAddressNetwork<T, R, E, S, J> {
            return this.owner;
        }

        createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(value : number, segmentPrefixLength : number, addressStr : any, originalVal : number, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number) : S {
            let segment : S = this['createSegment$int$java_lang_Integer'](value, segmentPrefixLength);
            segment.setStandardString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardString, lowerStringStartIndex, lowerStringEndIndex, originalVal);
            segment.setWildcardString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardString, lowerStringStartIndex, lowerStringEndIndex, originalVal);
            return segment;
        }

        public createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower : number, upper : number, segmentPrefixLength : number, addressStr : any, originalLower : number, originalUpper : number, isStandardString : boolean, isStandardRangeString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, upperStringEndIndex : number) : S {
            let segment : S = this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
            segment.setStandardString$java_lang_CharSequence$boolean$boolean$int$int$int$int$int(addressStr, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex, originalLower, originalUpper);
            segment.setWildcardString$java_lang_CharSequence$boolean$int$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, originalLower, originalUpper);
            return segment;
        }

        /**
         * 
         * @param {number} lower
         * @param {number} upper
         * @param {number} segmentPrefixLength
         * @param {*} addressStr
         * @param {number} originalLower
         * @param {number} originalUpper
         * @param {boolean} isStandardString
         * @param {boolean} isStandardRangeString
         * @param {number} lowerStringStartIndex
         * @param {number} lowerStringEndIndex
         * @param {number} upperStringEndIndex
         * @return {IPAddressSegment}
         */
        public createSegmentInternal(lower? : any, upper? : any, segmentPrefixLength? : any, addressStr? : any, originalLower? : any, originalUpper? : any, isStandardString? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, lowerStringEndIndex? : any, upperStringEndIndex? : any) : any {
            if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                return <any>this.createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                super.createSegmentInternal(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
            } else throw new Error('invalid overload');
        }

        abstract createSectionArray(length : number) : R[];

        public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$byte_A$java_lang_Integer(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$inet_ipaddr_IPAddressSegment_A(segments : S[]) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public createEmbeddedSectionInternal(encompassingSection? : any, segments? : any, startIndex? : any) : any {
            if(((encompassingSection != null && encompassingSection instanceof <any>IPAddressSection) || encompassingSection === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && startIndex === undefined) {
                return <any>this.createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_IPAddressSegment_A(encompassingSection, segments);
            } else throw new Error('invalid overload');
        }

        createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_IPAddressSegment_A(encompassingSection : IPAddressSection, segments : S[]) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        /**
         * 
         * @param {Array} segments
         * @param {number} prefix
         * @param {boolean} singleOnly
         * @return {IPv4AddressSection}
         */
        public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
            } else throw new Error('invalid overload');
        }

        createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments : S[], prefix : number) : R {
            return this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, false);
        }

        createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments : S[], prefix : number, singleOnly : boolean) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public abstract createFullSectionInternal(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefix : number) : R;

        public createSection(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, prefix? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined) {
                return <any>this.createSection$byte_A$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$byte_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_IPAddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        public createSection$byte_A$int$int$java_lang_Integer(bytes : number[], byteStartIndex : number, byteEndIndex : number, prefix : number) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public createSection$byte_A$java_lang_Integer(bytes : number[], prefix : number) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public createSection$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments : S[], networkPrefixLength : number) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public createSection$inet_ipaddr_IPAddressSegment_A(segments : S[]) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        abstract createAddressArray(length : number) : T[];

        public createAddress$inet_ipaddr_IPAddressSegment_A(segments : S[]) : T {
            return this.createAddress(this.createSection$inet_ipaddr_IPAddressSegment_A(segments));
        }

        public createAddress$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments : S[], prefix : number) : T {
            return this.createAddress(this.createSection$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix));
        }

        createAddressInternal$inet_ipaddr_IPAddressSegment_A(segments : S[]) : T {
            return this.createAddress(this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(segments));
        }

        createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments : S[], prefix : number, singleOnly : boolean) : T {
            return this.createAddress(this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly));
        }

        createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments : S[], prefix : number) : T {
            return this.createAddress(this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix));
        }

        createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_CharSequence(segments : S[], zone : any) : T {
            return this.createAddressInternal(this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(segments), zone);
        }

        public createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefix : number) : T {
            return this.createAddress(this.createFullSectionInternal(lowerValueProvider, upperValueProvider, prefix));
        }

        public createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefix : number, zone : any) : T {
            return this.createAddressInternal(this.createFullSectionInternal(lowerValueProvider, upperValueProvider, prefix), zone);
        }

        public createAddress(lowerValueProvider? : any, upperValueProvider? : any, prefix? : any, zone? : any) : any {
            if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider, upperValueProvider, prefix, zone);
            } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(lowerValueProvider, upperValueProvider, prefix);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$java_net_InetAddress(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_AddressSection(lowerValueProvider);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$byte_A$java_lang_Integer(bytes : number[], prefix : number) : R {
            return this.createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes, bytes.length, prefix, false);
        }

        createAddressInternal$byte_A$java_lang_Integer(bytes : number[], prefix : number) : T {
            return this.createAddress(this.createSectionInternal$byte_A$java_lang_Integer(bytes, prefix));
        }

        createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes : number[], prefix : number, zone : any) : T {
            return this.createAddressInternal(this.createSectionInternal$byte_A$java_lang_Integer(bytes, prefix), zone);
        }

        createAddressInternal$byte_A$java_lang_CharSequence(bytes : number[], zone : any) : T {
            return this.createAddressInternal(this.createSectionInternal$byte_A$java_lang_Integer(bytes, null), zone);
        }

        public createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence$inet_ipaddr_HostName(bytes : number[], prefix : number, zone : any, fromHost : HostName) : T {
            return this.createAddressInternal(this.createSectionInternal$byte_A$java_lang_Integer(bytes, prefix), zone, fromHost);
        }

        public createAddressInternal(bytes? : any, prefix? : any, zone? : any, fromHost? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((fromHost != null && fromHost instanceof <any>HostName) || fromHost === null)) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence$inet_ipaddr_HostName(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof fromHost === 'number') || fromHost === null)) {
                super.createAddressInternal(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && zone instanceof <any>HostName) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && ((typeof zone === 'number') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes : number[], prefix : number, fromHost : HostName) : T {
            return this.createAddressInternal(this.createSectionInternal$byte_A$java_lang_Integer(bytes, prefix), fromHost);
        }

        public createAddress$byte_A$java_lang_Integer(bytes : number[], prefix : number) : T {
            return this.createAddress(this.createSection$byte_A$java_lang_Integer(bytes, prefix));
        }

        public createAddress$byte_A(bytes : number[]) : T {
            return this.createAddress(this.createSection$byte_A$java_lang_Integer(bytes, null));
        }

        createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(section : R, zone : any, from : HostIdentifierString) : T {
            let result : T = this.createAddressInternal(section, zone);
            result.cache(from);
            return result;
        }

        createAddressInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_HostIdentifierString(section : R, from : HostIdentifierString) : T {
            let result : T = this.createAddress(section);
            result.cache(from);
            return result;
        }

        createAddress$java_net_InetAddress(inetAddress : J) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence(section : R, zone : any) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public createAddress$inet_ipaddr_IPAddressSection(section : R) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }
    }
    IPAddressCreator["__class"] = "inet.ipaddr.IPAddressNetwork.IPAddressCreator";
    IPAddressCreator["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];



    /**
     * Copies the default string options but inserts the given networks.
     * Either argument can be null to use the default networks.
     * 
     * @param {IPv4AddressNetwork} ipv4Network
     * @param {IPv6AddressNetwork} ipv6Network
     * @class
     * @author sfoley
     */
    export class IPAddressGenerator {
        static serialVersionUID : number = 4;

        options : IPAddressStringParameters;

        public constructor(ipv4Network? : any, ipv6Network? : any) {
            if(((ipv4Network != null && ipv4Network instanceof <any>IPv4AddressNetwork) || ipv4Network === null) && ((ipv6Network != null && ipv6Network instanceof <any>IPv6AddressNetwork) || ipv6Network === null)) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = new IPAddressStringParameters.Builder().getIPv4AddressParametersBuilder().setNetwork(ipv4Network).getParentBuilder().getIPv6AddressParametersBuilder().setNetwork(ipv6Network).getEmbeddedIPv4AddressParametersBuilder().setNetwork(ipv4Network).getEmbeddedIPv4AddressParentBuilder().getParentBuilder().toParams();
                    if(this.options===undefined) this.options = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        if(options == null) {
                            options = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
                        }
                        this.options = options;
                    })();
                }
            } else if(((ipv4Network != null && ipv4Network instanceof <any>IPAddressStringParameters) || ipv4Network === null) && ipv6Network === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[0];
                if(this.options===undefined) this.options = null;
                if(this.options===undefined) this.options = null;
                (() => {
                    if(options == null) {
                        options = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
                    }
                    this.options = options;
                })();
            } else if(ipv4Network === undefined && ipv6Network === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = null;
                    if(this.options===undefined) this.options = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        if(options == null) {
                            options = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
                        }
                        this.options = options;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        toNormalizedString(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : string {
            if(version === IPAddress.IPVersion.IPV4) {
                let network : IPv4AddressNetwork = this.options.getIPv4Parameters().getNetwork();
                return IPv4Address.toNormalizedString$inet_ipaddr_ipv4_IPv4AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(network, lowerValueProvider, upperValueProvider, prefixLength);
            }
            if(version === IPAddress.IPVersion.IPV6) {
                let network : IPv6AddressNetwork = this.options.getIPv6Parameters().getNetwork();
                return IPv6Address.toNormalizedString$inet_ipaddr_ipv6_IPv6AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(network, lowerValueProvider, upperValueProvider, prefixLength, zone);
            }
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }

        public from$java_net_InetAddress(inetAddress : InetAddress) : IPAddress {
            if(inetAddress != null && inetAddress instanceof <any>Inet4Address) {
                return this.getIPv4Creator().createAddress$java_net_Inet4Address(<Inet4Address>inetAddress);
            } else if(inetAddress != null && inetAddress instanceof <any>Inet6Address) {
                return this.getIPv6Creator().createAddress$java_net_Inet6Address(<Inet6Address>inetAddress);
            }
            return null;
        }

        public from$byte_A(bytes : number[]) : IPAddress {
            return this.from$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, null, null);
        }

        public from$byte_A$java_lang_Integer(bytes : number[], prefixLength : number) : IPAddress {
            return this.from$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefixLength, null);
        }

        public from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number) : IPAddress {
            return this.from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, null);
        }

        getIPv4Creator() : IPv4AddressNetwork.IPv4AddressCreator {
            let network : IPv4AddressNetwork = this.options.getIPv4Parameters().getNetwork();
            let addressCreator : IPv4AddressNetwork.IPv4AddressCreator = network.getAddressCreator();
            return addressCreator;
        }

        getIPv6Creator() : IPv6AddressNetwork.IPv6AddressCreator {
            let network : IPv6AddressNetwork = this.options.getIPv6Parameters().getNetwork();
            let addressCreator : IPv6AddressNetwork.IPv6AddressCreator = network.getAddressCreator();
            return addressCreator;
        }

        public from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : IPAddress {
            if(version === IPAddress.IPVersion.IPV4) {
                return this.getIPv4Creator().createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(lowerValueProvider, upperValueProvider, prefixLength);
            }
            if(version === IPAddress.IPVersion.IPV6) {
                return this.getIPv6Creator().createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider, upperValueProvider, prefixLength, zone);
            }
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }

        public from(version? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any, zone? : any) : any {
            if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
            } else if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && zone === undefined) {
                return <any>this.from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && ((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof upperValueProvider === "string")) || upperValueProvider === null) && prefixLength === undefined && zone === undefined) {
                return <any>this.from$byte_A$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && ((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && upperValueProvider === undefined && prefixLength === undefined && zone === undefined) {
                return <any>this.from$byte_A$java_lang_Integer(version, lowerValueProvider);
            } else if(((version != null && version instanceof <any>InetAddress) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined && zone === undefined) {
                return <any>this.from$java_net_InetAddress(version);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined && zone === undefined) {
                return <any>this.from$byte_A(version);
            } else throw new Error('invalid overload');
        }

        from$byte_A$java_lang_Integer$java_lang_CharSequence(bytes : number[], prefixLength : number, zone : any) : IPAddress {
            if(bytes.length < IPv6Address.BYTE_COUNT) {
                return this.getIPv4Creator().createAddressInternal$byte_A$java_lang_Integer(bytes, prefixLength);
            }
            return this.getIPv6Creator().createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefixLength, zone);
        }
    }
    IPAddressGenerator["__class"] = "inet.ipaddr.IPAddressNetwork.IPAddressGenerator";
    IPAddressGenerator["__interfaces"] = ["java.io.Serializable"];



    /**
     * Choose a map of your choice to implement a cache of addresses and/or host names.
     * <p>
     * You can also use this class without a cache to serve as a factory of addresses or host names,
     * which can be particularly useful if you are using your own network, or if you are using your own validation options.
     * <p>
     * For long-running programs or servers that handle many addresses, the benefits of using a cache are that
     * <ul>
     * <li>the lookup can provide the same objects for different strings that identify the same host name or address</li>
     * <li>parsing and resolving repeated instances of the same address or host string is minimized.  Both IPAddressString and HostName cache their parsed and resolved addresses.</li>
     * <li>other functionality is optimized through caching, since Host Name, IPAddressString, and IPAddress also caches objects such as generated strings.  With cached objects, switching between host names, address strings and numeric addresses is constant time.</li>
     * </ul><p>
     * You choose the map of your choice to be the backing map for the cache.
     * For example, for thread-safe access to the cache, ConcurrentHashMap is a good choice.
     * For maps of bounded size, LinkedHashMap provides the removeEldestEntry method to override to implement LRU or other eviction mechanisms.
     * 
     * @author sfoley
     * 
     * @param <T> the type to be cached, typically either IPAddressString or HostName
     * @param {*} backingMap
     * @param {IPAddressStringParameters} options
     * @class
     */
    export abstract class HostIDStringAddressGenerator<T extends HostIdentifierString> {
        static serialVersionUID : number = 4;

        addressGenerator : IPAddressNetwork.IPAddressGenerator;

        backingMap : any;

        public constructor(backingMap? : any, options? : any) {
            if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                if(this.backingMap===undefined) this.backingMap = null;
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                if(this.backingMap===undefined) this.backingMap = null;
                (() => {
                    this.backingMap = backingMap;
                    this.addressGenerator = new IPAddressNetwork.IPAddressGenerator(options);
                })();
            } else if(((backingMap != null && backingMap instanceof <any>IPAddressStringParameters) || backingMap === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[0];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    (() => {
                        this.backingMap = backingMap;
                        this.addressGenerator = new IPAddressNetwork.IPAddressGenerator(options);
                    })();
                }
            } else if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    (() => {
                        this.backingMap = backingMap;
                        this.addressGenerator = new IPAddressNetwork.IPAddressGenerator(options);
                    })();
                }
            } else if(backingMap === undefined && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    let options : any = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    (() => {
                        this.backingMap = backingMap;
                        this.addressGenerator = new IPAddressNetwork.IPAddressGenerator(options);
                    })();
                }
            } else throw new Error('invalid overload');
        }

        public getBackingMap() : any {
            return this.backingMap;
        }

        public static getValueProvider$byte_A(bytes : number[]) : Address.SegmentValueProvider {
            let segmentByteCount : number = (bytes.length === IPv4Address.BYTE_COUNT)?IPv4Address.BYTES_PER_SEGMENT:IPv6Address.BYTES_PER_SEGMENT;
            return HostIDStringAddressGenerator.getValueProvider$byte_A$int(bytes, segmentByteCount);
        }

        public static getValueProvider$byte_A$int(bytes : number[], segmentByteCount : number) : Address.SegmentValueProvider {
            return { getValue : (segmentIndex) => {
                let value : number = 0;
                for(let start : number = segmentIndex * segmentByteCount, end : number = start + segmentByteCount; start < end; start++) {
                    value = (value << 8) | (255 & bytes[start]);
                };
                return value;
            } };
        }

        public static getValueProvider(bytes? : any, segmentByteCount? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentByteCount === 'number') || segmentByteCount === null)) {
                return <any>IPAddressNetwork.HostIDStringAddressGenerator.getValueProvider$byte_A$int(bytes, segmentByteCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && segmentByteCount === undefined) {
                return <any>IPAddressNetwork.HostIDStringAddressGenerator.getValueProvider$byte_A(bytes);
            } else throw new Error('invalid overload');
        }

        public get$byte_A(bytes : number[]) : T {
            let version : IPAddress.IPVersion = bytes.length === IPv4Address.BYTE_COUNT?IPAddress.IPVersion.IPV4:IPAddress.IPVersion.IPV6;
            let segmentByteCount : number = IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.BYTES_PER_SEGMENT:IPv6Address.BYTES_PER_SEGMENT;
            return this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, HostIDStringAddressGenerator.getValueProvider$byte_A$int(bytes, segmentByteCount), null, null, null);
        }

        public get$inet_ipaddr_Address_AddressProvider(addressProvider : Address.AddressProvider) : T {
            return this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(addressProvider.getSegmentCount() === IPv4Address.SEGMENT_COUNT?IPAddress.IPVersion.IPV4:IPAddress.IPVersion.IPV6, addressProvider.getValues(), addressProvider.getUpperValues(), addressProvider.getPrefixLength(), addressProvider.getZone());
        }

        public get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number) : T {
            return this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, null);
        }

        public get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : T {
            return this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(IPAddress.IPVersion.IPV6, lowerValueProvider, upperValueProvider, prefixLength, zone);
        }

        public get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : T {
            if(this.backingMap == null) {
                let addr : IPAddress = this.addressGenerator.from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
                return this.create(addr);
            }
            let key : string = this.toNormalizedString(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
            let result : T = /* get */((m,k) => m[k]===undefined?null:m[k])(this.backingMap, key);
            if(result == null) {
                let addr : IPAddress = this.addressGenerator.from$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
                addr.cacheNormalizedString(key);
                result = this.create(addr);
                let existing : T = this.backingMap.putIfAbsent(key, result);
                if(existing == null) {
                    this.added(result);
                } else {
                    result = existing;
                    this.cache(result, addr);
                }
            }
            return result;
        }

        public get(version? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any, zone? : any) : any {
            if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
            } else if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && zone === undefined) {
                return <any>this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefixLength === "string")) || prefixLength === null) && zone === undefined) {
                return <any>this.get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined && zone === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined && zone === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else throw new Error('invalid overload');
        }

        toNormalizedString(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : string {
            return this.addressGenerator.toNormalizedString(version, lowerValueProvider, upperValueProvider, prefixLength, zone);
        }

        abstract create(addr : IPAddress) : T;

        /**
         * 
         * @param {IPAddressString} result
         * @param {IPAddress} addr
         */
        public cache(result? : any, addr? : any) : any {
            if(((result != null) || result === null) && ((addr != null && addr instanceof <any>IPAddress) || addr === null)) {
                return <any>this.cache$inet_ipaddr_HostIdentifierString$inet_ipaddr_IPAddress(result, addr);
            } else throw new Error('invalid overload');
        }

        cache$inet_ipaddr_HostIdentifierString$inet_ipaddr_IPAddress(result : T, addr : IPAddress) { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        /**
         * 
         * @param {IPAddressString} added
         */
        public added(added? : any) : any {
            if(((added != null) || added === null)) {
                return <any>this.added$inet_ipaddr_HostIdentifierString(added);
            } else throw new Error('invalid overload');
        }

        added$inet_ipaddr_HostIdentifierString(added : T) { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }
    }
    HostIDStringAddressGenerator["__class"] = "inet.ipaddr.IPAddressNetwork.HostIDStringAddressGenerator";
    HostIDStringAddressGenerator["__interfaces"] = ["java.io.Serializable"];



    /**
     * Choose a map of your choice to implement a cache of address strings and their associated addresses.
     * 
     * The map will map string representations of the address to IPAddressString objects, which in turn cache any resulting IPAddress objects.
     * 
     * Those objects are all themselves thread-safe, but the cache will only be thread-safe if you choose a thread-safe map such as ConcurrentHashMap.
     * 
     * @author sfoley
     * @param {*} backingMap
     * @param {IPAddressStringParameters} options
     * @class
     * @extends AddressNetwork.HostIdentifierStringGenerator
     */
    export class IPAddressStringGenerator extends AddressNetwork.HostIdentifierStringGenerator<IPAddressString> {
        static __inet_ipaddr_IPAddressNetwork_IPAddressStringGenerator_serialVersionUID : number = 4;

        addressGenerator : IPAddressNetwork.HostIDStringAddressGenerator<IPAddressString>;

        public constructor(backingMap? : any, options? : any) {
            if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(backingMap);
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                (() => {
                    this.addressGenerator = new IPAddressStringGenerator.IPAddressStringGenerator$0(this, backingMap, options);
                })();
            } else if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = null;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    (() => {
                        this.addressGenerator = new IPAddressStringGenerator.IPAddressStringGenerator$0(this, backingMap, options);
                    })();
                }
            } else if(((backingMap != null && backingMap instanceof <any>IPAddressStringParameters) || backingMap === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[0];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    (() => {
                        this.addressGenerator = new IPAddressStringGenerator.IPAddressStringGenerator$0(this, backingMap, options);
                    })();
                }
            } else if(backingMap === undefined && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    let options : any = null;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    (() => {
                        this.addressGenerator = new IPAddressStringGenerator.IPAddressStringGenerator$0(this, backingMap, options);
                    })();
                }
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {string} addressString
         * @return {IPAddressString}
         */
        create(addressString : string) : IPAddressString {
            let options : IPAddressStringParameters = this.addressGenerator.addressGenerator.options;
            return options == null?new IPAddressString(addressString):new IPAddressString(addressString, options);
        }

        public static getValueProvider(bytes : number[]) : Address.SegmentValueProvider {
            return IPAddressNetwork.HostIDStringAddressGenerator.getValueProvider$byte_A(bytes);
        }

        public get$byte_A(bytes : number[]) : IPAddressString {
            return this.addressGenerator.get$byte_A(bytes);
        }

        public get$inet_ipaddr_Address_AddressProvider(addressProvider : Address.AddressProvider) : IPAddressString {
            return this.addressGenerator.get$inet_ipaddr_Address_AddressProvider(addressProvider);
        }

        public get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number) : IPAddressString {
            return this.addressGenerator.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
        }

        public get(version? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any) : any {
            if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                return <any>this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefixLength === "string")) || prefixLength === null)) {
                return <any>this.get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else if(((typeof version === 'string') || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$java_lang_String(version);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else throw new Error('invalid overload');
        }

        public get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : IPAddressString {
            return this.addressGenerator.get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider, upperValueProvider, prefixLength, zone);
        }
    }
    IPAddressStringGenerator["__class"] = "inet.ipaddr.IPAddressNetwork.IPAddressStringGenerator";
    IPAddressStringGenerator["__interfaces"] = ["java.io.Serializable"];



    export namespace IPAddressStringGenerator {

        export class IPAddressStringGenerator$0 extends IPAddressNetwork.HostIDStringAddressGenerator<IPAddressString> {
            public __parent: any;
            /**
             * 
             * @param {IPAddress} addr
             * @return {IPAddressString}
             */
            create(addr : IPAddress) : IPAddressString {
                return addr.toAddressString();
            }

            public cache$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress(result : IPAddressString, addr : IPAddress) {
                result.cacheAddress(addr);
            }

            /**
             * 
             * @param {IPAddressString} result
             * @param {IPAddress} addr
             */
            public cache(result? : any, addr? : any) : any {
                if(((result != null && result instanceof <any>IPAddressString) || result === null) && ((addr != null && addr instanceof <any>IPAddress) || addr === null)) {
                    return <any>this.cache$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress(result, addr);
                } else if(((result != null) || result === null) && ((addr != null && addr instanceof <any>IPAddress) || addr === null)) {
                    return <any>this.cache$inet_ipaddr_HostIdentifierString$inet_ipaddr_IPAddress(result, addr);
                } else throw new Error('invalid overload');
            }

            public added$inet_ipaddr_IPAddressString(added : IPAddressString) {
                this.added(added);
            }

            /**
             * 
             * @param {IPAddressString} added
             */
            public added(added? : any) : any {
                if(((added != null && added instanceof <any>IPAddressString) || added === null)) {
                    return <any>this.added$inet_ipaddr_IPAddressString(added);
                } else if(((added != null) || added === null)) {
                    return <any>this.added$inet_ipaddr_HostIdentifierString(added);
                } else throw new Error('invalid overload');
            }

            constructor(__parent: any, __arg0: any, __arg1: any) {
                super(__arg0, __arg1);
                this.__parent = __parent;
            }
        }
        IPAddressStringGenerator$0["__interfaces"] = ["java.io.Serializable"];


    }


    /**
     * Choose a map of your choice to implement a cache of host names and resolved addresses.
     * 
     * The map will map string representations of the host to HostName objects.
     * 
     * Those HostName objects in turn cache any resulting IPAddressString objects if the string represents an address,
     * or any IPAddress objects obtained from resolving the HostName.
     * 
     * Those objects are all themselves thread-safe, but the cache will only be thread-safe if you choose a thread-safe map such as ConcurrentHashMap.
     * 
     * @author sfoley
     * @param {*} backingMap
     * @param {HostNameParameters} options
     * @param {boolean} reverseLookup
     * @class
     * @extends AddressNetwork.HostIdentifierStringGenerator
     */
    export class HostNameGenerator extends AddressNetwork.HostIdentifierStringGenerator<HostName> {
        static __inet_ipaddr_IPAddressNetwork_HostNameGenerator_serialVersionUID : number = 4;

        addressGenerator : IPAddressNetwork.HostIDStringAddressGenerator<HostName>;

        options : HostNameParameters;

        public constructor(backingMap? : any, options? : any, reverseLookup? : any) {
            if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null) && ((typeof reverseLookup === 'boolean') || reverseLookup === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(backingMap);
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                if(this.options===undefined) this.options = null;
                if(this.addressGenerator===undefined) this.addressGenerator = null;
                if(this.options===undefined) this.options = null;
                (() => {
                    this.addressGenerator = new HostNameGenerator.HostNameGenerator$0(this, backingMap, options.addressOptions, reverseLookup);
                    this.options = options;
                })();
            } else if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null) && options === undefined && reverseLookup === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = HostName.DEFAULT_VALIDATION_OPTIONS_$LI$();
                    let reverseLookup : any = false;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        this.addressGenerator = new HostNameGenerator.HostNameGenerator$0(this, backingMap, options.addressOptions, reverseLookup);
                        this.options = options;
                    })();
                }
            } else if(((backingMap != null && backingMap instanceof <any>HostNameParameters) || backingMap === null) && options === undefined && reverseLookup === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[0];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    let reverseLookup : any = false;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        this.addressGenerator = new HostNameGenerator.HostNameGenerator$0(this, backingMap, options.addressOptions, reverseLookup);
                        this.options = options;
                    })();
                }
            } else if(backingMap === undefined && options === undefined && reverseLookup === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    let options : any = null;
                    let reverseLookup : any = false;
                    super(backingMap);
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    if(this.addressGenerator===undefined) this.addressGenerator = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        this.addressGenerator = new HostNameGenerator.HostNameGenerator$0(this, backingMap, options.addressOptions, reverseLookup);
                        this.options = options;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {string} key
         * @return {HostName}
         */
        create(key : string) : HostName {
            return this.options == null?new HostName(key):new HostName(key, this.options);
        }

        public static getValueProvider(bytes : number[]) : Address.SegmentValueProvider {
            return IPAddressNetwork.HostIDStringAddressGenerator.getValueProvider$byte_A(bytes);
        }

        public get$byte_A(bytes : number[]) : HostName {
            return this.addressGenerator.get$byte_A(bytes);
        }

        public get$inet_ipaddr_Address_AddressProvider(addressProvider : Address.AddressProvider) : HostName {
            return this.addressGenerator.get$inet_ipaddr_Address_AddressProvider(addressProvider);
        }

        public get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version : IPAddress.IPVersion, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number) : HostName {
            return this.addressGenerator.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
        }

        public get(version? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any) : any {
            if(((typeof version === 'number') || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                return <any>this.get$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || version === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefixLength === "string")) || prefixLength === null)) {
                return <any>this.get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(version, lowerValueProvider, upperValueProvider, prefixLength);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else if(((typeof version === 'string') || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$java_lang_String(version);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else throw new Error('invalid overload');
        }

        public get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : HostName {
            return this.addressGenerator.get$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(lowerValueProvider, upperValueProvider, prefixLength, zone);
        }
    }
    HostNameGenerator["__class"] = "inet.ipaddr.IPAddressNetwork.HostNameGenerator";
    HostNameGenerator["__interfaces"] = ["java.io.Serializable"];



    export namespace HostNameGenerator {

        export class HostNameGenerator$0 extends IPAddressNetwork.HostIDStringAddressGenerator<HostName> {
            public __parent: any;
            /**
             * 
             * @param {IPAddress} addr
             * @return {HostName}
             */
            create(addr : IPAddress) : HostName {
                if(this.reverseLookup) {
                    return new HostName(addr.toInetAddress().getHostName());
                }
                return new HostName(addr);
            }

            public cache$inet_ipaddr_HostName$inet_ipaddr_IPAddress(result : HostName, addr : IPAddress) {
                result.cacheAddress(addr);
            }

            /**
             * 
             * @param {HostName} result
             * @param {IPAddress} addr
             */
            public cache(result? : any, addr? : any) : any {
                if(((result != null && result instanceof <any>HostName) || result === null) && ((addr != null && addr instanceof <any>IPAddress) || addr === null)) {
                    return <any>this.cache$inet_ipaddr_HostName$inet_ipaddr_IPAddress(result, addr);
                } else if(((result != null) || result === null) && ((addr != null && addr instanceof <any>IPAddress) || addr === null)) {
                    return <any>this.cache$inet_ipaddr_HostIdentifierString$inet_ipaddr_IPAddress(result, addr);
                } else throw new Error('invalid overload');
            }

            public added$inet_ipaddr_HostName(added : HostName) {
                this.added(added);
            }

            /**
             * 
             * @param {HostName} added
             */
            public added(added? : any) : any {
                if(((added != null && added instanceof <any>HostName) || added === null)) {
                    return <any>this.added$inet_ipaddr_HostName(added);
                } else if(((added != null) || added === null)) {
                    return <any>this.added$inet_ipaddr_HostIdentifierString(added);
                } else throw new Error('invalid overload');
            }

            constructor(__parent: any, __arg0: any, __arg1: any, private reverseLookup: any) {
                super(__arg0, __arg1);
                this.__parent = __parent;
            }
        }
        HostNameGenerator$0["__interfaces"] = ["java.io.Serializable"];


    }

}



