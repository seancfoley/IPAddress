/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivisionSeries } from './format/AddressDivisionSeries';
import { IPv4AddressNetwork } from './ipv4/IPv4AddressNetwork';
import { IPv6AddressNetwork } from './ipv6/IPv6AddressNetwork';
import { MACAddressNetwork } from './mac/MACAddressNetwork';
import { AddressSegmentSeries } from './AddressSegmentSeries';
import { AddressComparator } from './AddressComparator';
import { AddressSection } from './AddressSection';
import { HostIdentifierString } from './HostIdentifierString';
import { AddressNetwork } from './AddressNetwork';
import { NetworkMismatchException } from './NetworkMismatchException';
import { HostIdentifierException } from './HostIdentifierException';
import { AddressSegment } from './AddressSegment';

/**
 * @custom.core
 * @author sfoley
 * @class
 */
export abstract class Address implements AddressSegmentSeries {
    static serialVersionUID : number = 4;

    public static HEX_PREFIX : string = "0x";

    public static OCTAL_PREFIX : string = "0";

    public static RANGE_SEPARATOR : string = '-';

    public static RANGE_SEPARATOR_STR : string; public static RANGE_SEPARATOR_STR_$LI$() : string { if(Address.RANGE_SEPARATOR_STR == null) Address.RANGE_SEPARATOR_STR = /* valueOf */new String(Address.RANGE_SEPARATOR).toString(); return Address.RANGE_SEPARATOR_STR; };

    public static ALTERNATIVE_RANGE_SEPARATOR : string = '\u009b';

    public static ALTERNATIVE_RANGE_SEPARATOR_STR : string; public static ALTERNATIVE_RANGE_SEPARATOR_STR_$LI$() : string { if(Address.ALTERNATIVE_RANGE_SEPARATOR_STR == null) Address.ALTERNATIVE_RANGE_SEPARATOR_STR = /* valueOf */new String(Address.ALTERNATIVE_RANGE_SEPARATOR).toString(); return Address.ALTERNATIVE_RANGE_SEPARATOR_STR; };

    public static SEGMENT_WILDCARD : string = '*';

    public static SEGMENT_WILDCARD_STR : string; public static SEGMENT_WILDCARD_STR_$LI$() : string { if(Address.SEGMENT_WILDCARD_STR == null) Address.SEGMENT_WILDCARD_STR = /* valueOf */new String(Address.SEGMENT_WILDCARD).toString(); return Address.SEGMENT_WILDCARD_STR; };

    public static ALTERNATIVE_SEGMENT_WILDCARD_STR : string = "\u00bf";

    public static SEGMENT_SQL_WILDCARD : string = '%';

    public static SEGMENT_SQL_WILDCARD_STR : string; public static SEGMENT_SQL_WILDCARD_STR_$LI$() : string { if(Address.SEGMENT_SQL_WILDCARD_STR == null) Address.SEGMENT_SQL_WILDCARD_STR = /* valueOf */new String(Address.SEGMENT_SQL_WILDCARD).toString(); return Address.SEGMENT_SQL_WILDCARD_STR; };

    public static SEGMENT_SQL_SINGLE_WILDCARD : string = '_';

    public static SEGMENT_SQL_SINGLE_WILDCARD_STR : string; public static SEGMENT_SQL_SINGLE_WILDCARD_STR_$LI$() : string { if(Address.SEGMENT_SQL_SINGLE_WILDCARD_STR == null) Address.SEGMENT_SQL_SINGLE_WILDCARD_STR = /* valueOf */new String(Address.SEGMENT_SQL_SINGLE_WILDCARD).toString(); return Address.SEGMENT_SQL_SINGLE_WILDCARD_STR; };

    public static DEFAULT_ADDRESS_COMPARATOR : AddressComparator; public static DEFAULT_ADDRESS_COMPARATOR_$LI$() : AddressComparator { if(Address.DEFAULT_ADDRESS_COMPARATOR == null) Address.DEFAULT_ADDRESS_COMPARATOR = new AddressComparator.CountComparator(); return Address.DEFAULT_ADDRESS_COMPARATOR; };

    static macNetwork : MACAddressNetwork = null;

    static ipv6Network : IPv6AddressNetwork = null;

    static ipv4Network : IPv4AddressNetwork = null;

    addressSection : AddressSection;

    fromString : HostIdentifierString;

    public constructor(section? : any) {
        if(((section != null && (section["__interfaces"] != null && section["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || section.constructor != null && section.constructor["__interfaces"] != null && section.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || section === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.addressSection===undefined) this.addressSection = null;
            if(this.fromString===undefined) this.fromString = null;
            if(this.addressSection===undefined) this.addressSection = null;
            if(this.fromString===undefined) this.fromString = null;
            (() => {
                this.addressSection = section;
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.getNetwork(),this.addressSection.getNetwork()))) {
                    throw new NetworkMismatchException(this.addressSection);
                }
            })();
        } else if(((typeof section === 'function' && (<any>section).length == 1) || section === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let supplier : any = __args[0];
            if(this.addressSection===undefined) this.addressSection = null;
            if(this.fromString===undefined) this.fromString = null;
            if(this.addressSection===undefined) this.addressSection = null;
            if(this.fromString===undefined) this.fromString = null;
            (() => {
                this.addressSection = (target => (typeof target === 'function')?target(this):(<any>target).apply(this))(supplier);
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.getNetwork(),this.addressSection.getNetwork()))) {
                    throw new NetworkMismatchException(this.addressSection);
                }
            })();
        } else throw new Error('invalid overload');
    }

    public static defaultIpv6Network() : IPv6AddressNetwork {
        if(Address.ipv6Network == null) {
            {
                if(Address.ipv6Network == null) {
                    Address.ipv6Network = new IPv6AddressNetwork();
                }
            };
        }
        return Address.ipv6Network;
    }

    public static defaultIpv4Network() : IPv4AddressNetwork {
        if(Address.ipv4Network == null) {
            {
                if(Address.ipv4Network == null) {
                    Address.ipv4Network = new IPv4AddressNetwork();
                }
            };
        }
        return Address.ipv4Network;
    }

    public static defaultMACNetwork() : MACAddressNetwork {
        if(Address.macNetwork == null) {
            {
                if(Address.macNetwork == null) {
                    Address.macNetwork = new MACAddressNetwork();
                }
            };
        }
        return Address.macNetwork;
    }

    static getMessage(key : string) : string {
        return HostIdentifierException.message;
    }

    /**
     * 
     * @return {number}
     */
    public getSegmentCount() : number {
        return this.getSection().getSegmentCount();
    }

    /**
     * 
     * @return {number}
     */
    public getDivisionCount() : number {
        return this.getSection().getDivisionCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSection().getBitCount();
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSection().getByteCount();
    }

    public getSection$() : AddressSection {
        return this.addressSection;
    }

    public getSegments$inet_ipaddr_AddressSegment_A(segs : AddressSegment[]) {
        this.getSection()['getSegments$inet_ipaddr_AddressSegment_A'](segs);
    }

    public getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start : number, end : number, segs : AddressSegment[], index : number) {
        this.getSection()['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](start, end, segs, index);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} index
     */
    public getSegments(start? : any, end? : any, segs? : any, index? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof index === 'number') || index === null)) {
            return <any>this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start, end, segs, index);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else throw new Error('invalid overload');
    }

    /**
     * @return {number} the maximum possible segment value for this type of address.
     * Note this is not the maximum value of the segments in this specific address.
     */
    public abstract getMaxSegmentValue() : number;

    /**
     * 
     * @return {*}
     */
    public abstract getIterable() : java.lang.Iterable<any>;

    /**
     * 
     * @return {*}
     */
    public abstract iterator() : any;

    /**
     * 
     * @return {*}
     */
    public abstract prefixBlockIterator() : any;

    /**
     * 
     * @param {number} increment
     * @return {Address}
     */
    public abstract increment(increment : number) : Address;

    /**
     * 
     * @param {number} increment
     * @return {Address}
     */
    public abstract incrementBoundary(increment : number) : Address;

    /**
     * 
     * @return {Address}
     */
    public abstract getLower() : Address;

    /**
     * 
     * @return {Address}
     */
    public abstract getUpper() : Address;

    /**
     * @return {boolean} whether this address represents more than one address.
     * Such addresses include CIDR/IP addresses (eg 1.2.3.4/11) or wildcard addresses (eg 1.2.*.4) or range addresses (eg 1.2.3-4.5)
     */
    public isMultiple() : boolean {
        return this.getSection().isMultiple();
    }

    /**
     * @return {boolean} whether this address has an associated prefix length
     */
    public isPrefixed() : boolean {
        return this.getSection().isPrefixed();
    }

    /**
     * the largest number of high bits for which this address represents all addresses with the same set of high bits
     * @return {number}
     */
    public getPrefixLength() : number {
        return this.getSection().getPrefixLength();
    }

    /**
     * Returns the smallest prefix length possible such that this includes the block of addresses for that prefix.
     * <p>
     * If the entire range can be dictated this way, then this method returns the same value as {@link #getPrefixLengthForSingleBlock()}.
     * Otherwise, this method will return the minimal possible prefix that can be paired with this address, while {@link #getPrefixLengthForSingleBlock()} will return null.
     * <p>
     * In cases where the final bit in this address division series is constant, this returns the bit length of this address division series.
     * 
     * @return {number} the prefix length
     */
    public getMinPrefixLengthForBlock() : number {
        return this.getSection().getMinPrefixLengthForBlock();
    }

    /**
     * Returns a prefix length for which the range of this address subnet matches the the block of addresses for that prefix.
     * <p>
     * If the range can be dictated this way, then this method returns the same value as {@link #getMinPrefixLengthForBlock()}.
     * <p>
     * If no such prefix exists, returns null.
     * <p>
     * If this segment grouping represents a single value, returns the bit length of this address division series.
     * <p>
     * IP address examples:
     * 1.2.3.4 returns 32
     * 1.2.*.* returns 16
     * 1.2.*.0/24 returns 16 in the case of PrefixConfiguration == ALL_PREFIXES_ARE_SUBNETS, 32 otherwise
     * 1.2.*.4 returns null
     * 1.2.252-255.* returns 22
     * 1.2.3.4/x returns x in the case of PrefixConfiguration == ALL_PREFIXES_ARE_SUBNETS, 32 otherwise
     * 1.2.0.0/16 returns 16 in the case of PrefixConfiguration == ALL_PREFIXES_ARE_SUBNETS or PREFIXED_ZERO_HOSTS_ARE_SUBNETS, 32 otherwise
     * 
     * @return {number} the prefix length or null if it does not exist
     */
    public getPrefixLengthForSingleBlock() : number {
        return this.getSection().getPrefixLengthForSingleBlock();
    }

    /**
     * Whether the MAC address or IP address or other form of address is multicast.
     * 
     * @see java.net.InetAddress#isMulticastAddress()
     * @return {boolean}
     */
    public abstract isMulticast() : boolean;

    /**
     * Gets the count of addresses that this address may represent.
     * 
     * If this address is not a subnet block of multiple addresses or has no range of values, then there is only one such address.
     * 
     * @return
     * @return {BigInteger}
     */
    public getCount() : BigInteger {
        return this.getSection().getCount();
    }

    /**
     * If this has a prefix length, the count of the range of values in the prefix.
     * 
     * If this has no prefix, returns the same value as {@link #getCount()}
     * 
     * @return
     * @return {BigInteger}
     */
    public getPrefixCount() : BigInteger {
        return this.getSection().getPrefixCount();
    }

    /**
     * 
     * @param {*} other
     * @return {number}
     */
    public isMore(other : AddressDivisionSeries) : number {
        return this.getSection().isMore(other);
    }

    public getBytes$() : number[] {
        return this.getSection().getBytes();
    }

    public getBytes$byte_A(bytes : number[]) : number[] {
        return this.getSection()['getBytes$byte_A'](bytes);
    }

    public getBytes$byte_A$int(bytes : number[], index : number) : number[] {
        return this.getSection()['getBytes$byte_A$int'](bytes, index);
    }

    /**
     * 
     * @param {Array} bytes
     * @param {number} index
     * @return {Array}
     */
    public getBytes(bytes? : any, index? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof index === 'number') || index === null)) {
            return <any>this.getBytes$byte_A$int(bytes, index);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && index === undefined) {
            return <any>this.getBytes$byte_A(bytes);
        } else if(bytes === undefined && index === undefined) {
            return <any>this.getBytes$();
        } else throw new Error('invalid overload');
    }

    public getUpperBytes$() : number[] {
        return this.getSection().getUpperBytes();
    }

    public getUpperBytes$byte_A(bytes : number[]) : number[] {
        return this.getSection()['getUpperBytes$byte_A'](bytes);
    }

    public getUpperBytes$byte_A$int(bytes : number[], index : number) : number[] {
        return this.getSection()['getUpperBytes$byte_A$int'](bytes, index);
    }

    /**
     * 
     * @param {Array} bytes
     * @param {number} index
     * @return {Array}
     */
    public getUpperBytes(bytes? : any, index? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof index === 'number') || index === null)) {
            return <any>this.getUpperBytes$byte_A$int(bytes, index);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && index === undefined) {
            return <any>this.getUpperBytes$byte_A(bytes);
        } else if(bytes === undefined && index === undefined) {
            return <any>this.getUpperBytes$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getValue() : BigInteger {
        return this.getSection().getValue();
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getUpperValue() : BigInteger {
        return this.getSection().getUpperValue();
    }

    /**
     * 
     * @return {boolean}
     */
    public isZero() : boolean {
        return this.getSection().isZero();
    }

    /**
     * 
     * @return {boolean}
     */
    public includesZero() : boolean {
        return this.getSection().includesZero();
    }

    /**
     * 
     * @return {boolean}
     */
    public isMax() : boolean {
        return this.getSection().isMax();
    }

    /**
     * 
     * @return {boolean}
     */
    public includesMax() : boolean {
        return this.getSection().includesMax();
    }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        return this.getSection().isFullRange();
    }

    /**
     * Whether the address can be considered a local address (as opposed to a global one)
     * @return
     * @return {boolean}
     */
    public abstract isLocal() : boolean;

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.getSection()));
    }

    /**
     * 
     * @param {Address} other
     * @return {number}
     */
    public compareTo(other : Address) : number {
        if(this === other) {
            return 0;
        }
        return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$()['compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries'](this, other);
    }

    abstract isFromSameString(otherString : HostIdentifierString) : boolean;

    public isSameAddress(other? : any) : any {
        if(((other != null && other instanceof <any>Address) || other === null)) {
            return <any>this.isSameAddress$inet_ipaddr_Address(other);
        } else throw new Error('invalid overload');
    }

    public isSameAddress$inet_ipaddr_Address(other : Address) : boolean {
        return other === this || /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.getSection(),other.getSection()));
    }

    /**
     * Two Address objects are equal if they represent the same set of addresses.
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>Address) {
            let other : Address = <Address>o;
            if(this.isFromSameString(other.fromString)) {
                return true;
            }
            return this.isSameAddress$inet_ipaddr_Address(other);
        }
        return false;
    }

    public abstract contains(other : Address) : boolean;

    /**
     * Returns a host identifier string representation for this address,
     * which will be already validated.
     * 
     * @return
     * @return {*}
     */
    public toAddressString() : HostIdentifierString {
        return this.fromString;
    }

    /**
     * Writes this address as a single hexadecimal value with always the exact same number of characters, with or without a preceding 0x prefix.
     * 
     * If this section represents a range of values outside of the network prefix length, then this is printed as a range of two hex values.
     * @param {boolean} with0xPrefix
     * @return {string}
     */
    public toHexString(with0xPrefix : boolean) : string {
        return this.getSection()['toHexString$boolean'](with0xPrefix);
    }

    public toNormalizedString(stringParams? : any, joinCount? : any) : any {
        if(stringParams === undefined && joinCount === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        return this.getSection().toNormalizedString();
    }

    /**
     * This produces a canonical string.
     * 
     * RFC 5952 describes canonical representations for Ipv6
     * http://en.wikipedia.org/wiki/IPv6_address#Recommended_representation_as_text
     * http://tools.ietf.org/html/rfc5952
     * 
     * Each address has a unique canonical string, not counting the prefix, which can give two equal addresses different strings.
     * @return {string}
     */
    public toCanonicalString() : string {
        return this.getSection().toCanonicalString();
    }

    /**
     * Produce short strings for the address in the usual address format.
     * 
     * Each address has a unique compressed string.
     * 
     * @return {string}
     */
    public toCompressedString() : string {
        return this.getSection().toCompressedString();
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.toCanonicalString();
    }

    /**
     * 
     * @return {Array}
     */
    public getDivisionStrings() : string[] {
        return this.getSection().getDivisionStrings();
    }

    /**
     * 
     * @return {Array}
     */
    public getSegmentStrings() : string[] {
        return this.getSection().getSegmentStrings();
    }

    /**
     * 
     * @return {Address}
     */
    public abstract reverseSegments() : Address;

    /**
     * 
     * @param {boolean} perByte
     * @return {Address}
     */
    public abstract reverseBits(perByte : boolean) : Address;

    /**
     * 
     * @return {Address}
     */
    public abstract reverseBytes() : Address;

    /**
     * 
     * @return {Address}
     */
    public abstract reverseBytesPerSegment() : Address;

    /**
     * Returns whether the address range has a prefix length and includes the block of values for its prefix length.
     * @return {boolean}
     */
    public isPrefixBlock() : boolean {
        return this.getSection().isPrefixBlock();
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {boolean}
     */
    public containsPrefixBlock(prefixLength : number) : boolean {
        return this.getSection().containsPrefixBlock(prefixLength);
    }

    /**
     * Returns whether the address range the block of values for a single prefix identified by its prefix length.
     * This is similar to {@link #isPrefixBlock()} except that it returns false when
     * the subnet has multiple prefixes.
     * 
     * For instance, 1.*.*.* /16 return false for this method and returns true for {@link #isPrefixBlock()}
     * @return {boolean}
     */
    public isSinglePrefixBlock() : boolean {
        return this.getSection().isSinglePrefixBlock();
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {boolean}
     */
    public containsSinglePrefixBlock(prefixLength : number) : boolean {
        return this.getSection().containsSinglePrefixBlock(prefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public removePrefixLength$() : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public removePrefixLength$boolean(zeroed : boolean) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} zeroed
     * @return {Address}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {Address}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {Address}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : Address { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {Address}
     */
    public abstract applyPrefixLength(networkPrefixLength : number) : Address;

    public abstract segmentsIterator(): any;
    public abstract getBytesPerSegment(): any;
    public abstract getBitsPerSegment(): any;
    public abstract getDivision(index?: any): any;
    public abstract getDivision(index?: any): any;
    public abstract getSegment(index?: any): any;
    public abstract getSection(index?: any, endIndex?: any): any;
    public abstract getNetwork(): any;}
Address["__class"] = "inet.ipaddr.Address";
Address["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



export namespace Address {

    /**
     * @custom.core
     * @author sfoley
     * @class
     */
    export interface AddressProvider {
        getSegmentCount() : number;

        getValues() : Address.SegmentValueProvider;

        getUpperValues() : Address.SegmentValueProvider;

        getPrefixLength() : number;

        getZone() : string;
    }

    /**
     * @custom.core
     * @author sfoley
     * @class
     */
    export interface SegmentValueProvider {
        getValue(segmentIndex : number) : number;
    }
}




Address.DEFAULT_ADDRESS_COMPARATOR_$LI$();

Address.SEGMENT_SQL_SINGLE_WILDCARD_STR_$LI$();

Address.SEGMENT_SQL_WILDCARD_STR_$LI$();

Address.SEGMENT_WILDCARD_STR_$LI$();

Address.ALTERNATIVE_RANGE_SEPARATOR_STR_$LI$();

Address.RANGE_SEPARATOR_STR_$LI$();
