/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivision } from './format/AddressDivision';
import { IPAddressDivision } from './format/IPAddressDivision';
import { IPAddressStringDivisionSeries } from './format/IPAddressStringDivisionSeries';
import { IPAddressStringWriter } from './format/util/IPAddressStringWriter';
import { IPv4Address } from './ipv4/IPv4Address';
import { IPv6Address } from './ipv6/IPv6Address';
import { AddressSegment } from './AddressSegment';
import { AddressValueException } from './AddressValueException';
import { AddressNetwork } from './AddressNetwork';
import { IPAddressNetwork } from './IPAddressNetwork';
import { IPAddress } from './IPAddress';
import { IPAddressSection } from './IPAddressSection';
import { PrefixLenException } from './PrefixLenException';
import { IncompatibleAddressException } from './IncompatibleAddressException';
import { IPAddressDivisionGrouping } from './format/IPAddressDivisionGrouping';

/**
 * This represents a single segment of an IP address.  For IPv4, segments are 1 byte.  For IPv6, they are two bytes.
 * 
 * IPAddressSegment objects are immutable and thus also thread-safe.
 * 
 * @author sfoley
 * @extends IPAddressDivision
 * @class
 */
export abstract class IPAddressSegment extends IPAddressDivision implements AddressSegment {
    static __inet_ipaddr_IPAddressSegment_serialVersionUID : number = 4;

    /*private*/ value : number;

    /*private*/ upperValue : number;

    public constructor(lower? : any, upper? : any, segmentPrefixLength? : any) {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(segmentPrefixLength);
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(lower < 0 || upper < 0) {
                    throw new AddressValueException(lower < 0?lower:upper);
                }
                if(lower > upper) {
                    let tmp : number = lower;
                    lower = upper;
                    upper = tmp;
                }
                segmentPrefixLength = this.getSegmentPrefixLength();
                if(segmentPrefixLength == null || segmentPrefixLength >= this.getBitCount() || !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                    this.value = lower;
                    this.upperValue = upper;
                } else {
                    let mask : number = this.getSegmentNetworkMask(segmentPrefixLength);
                    this.value = lower & mask;
                    this.upperValue = upper | this.getSegmentHostMask(segmentPrefixLength);
                }
            })();
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            let segmentPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lower : any = value;
                let upper : any = value;
                super(segmentPrefixLength);
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                (() => {
                    if(lower < 0 || upper < 0) {
                        throw new AddressValueException(lower < 0?lower:upper);
                    }
                    if(lower > upper) {
                        let tmp : number = lower;
                        lower = upper;
                        upper = tmp;
                    }
                    segmentPrefixLength = this.getSegmentPrefixLength();
                    if(segmentPrefixLength == null || segmentPrefixLength >= this.getBitCount() || !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        this.value = lower;
                        this.upperValue = upper;
                    } else {
                        let mask : number = this.getSegmentNetworkMask(segmentPrefixLength);
                        this.value = lower & mask;
                        this.upperValue = upper | this.getSegmentHostMask(segmentPrefixLength);
                    }
                })();
            }
        } else if(((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            super();
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(value < 0) {
                    throw new AddressValueException(value);
                }
                this.value = this.upperValue = value;
            })();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPAddressNetwork}
     */
    public abstract getNetwork() : IPAddressNetwork<any, any, any, any, any>;

    public isIPv4() : boolean {
        return false;
    }

    public isIPv6() : boolean {
        return false;
    }

    public abstract getIPVersion() : IPAddress.IPVersion;

    static getSplitSegmentPrefix(bitsPerSegment : number, networkPrefixLength : number, segmentIndex : number) : number {
        return IPAddressSection.getSplitSegmentPrefixLength(bitsPerSegment, networkPrefixLength, segmentIndex);
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionNetworkMask(bits : number) : number {
        return this.getSegmentNetworkMask(bits);
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionHostMask(bits : number) : number {
        return this.getSegmentHostMask(bits);
    }

    abstract getSegmentNetworkMask(bits : number) : number;

    abstract getSegmentHostMask(bits : number) : number;

    /**
     * 
     * @return {number}
     */
    public getMinPrefixLengthForBlock() : number {
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && this.isPrefixed() && this.getSegmentPrefixLength() === 0) {
            return 0;
        }
        return super.getMinPrefixLengthForBlock();
    }

    public static getMaxSegmentValue(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.MAX_VALUE_PER_SEGMENT:IPv6Address.MAX_VALUE_PER_SEGMENT;
    }

    isChangedByPrefix(bits : number, smallerOnly : boolean) : boolean {
        let hasBits : boolean = (bits != null);
        if(hasBits && (bits < 0 || bits > this.getBitCount())) {
            throw new PrefixLenException(this, bits);
        }
        if(smallerOnly) {
            if(this.isPrefixed()) {
                return hasBits && bits < this.getSegmentPrefixLength();
            }
        } else {
            if(this.isPrefixed()) {
                return !hasBits || bits !== /* intValue */(this.getSegmentPrefixLength()|0);
            }
        }
        return hasBits;
    }

    public toPrefixedSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator<S extends IPAddressSegment>(segmentPrefixLength : number, creator : AddressNetwork.AddressSegmentCreator<S>) : S {
        let lower : number = this.getLowerSegmentValue();
        let upper : number = this.getUpperSegmentValue();
        let hasBits : boolean = (segmentPrefixLength != null);
        if(lower !== upper) {
            if(!hasBits) {
                return creator['createSegment$int$int$java_lang_Integer'](lower, upper, null);
            }
            return creator['createSegment$int$int$java_lang_Integer'](lower, upper, segmentPrefixLength);
        }
        return hasBits?creator['createSegment$int$java_lang_Integer'](lower, segmentPrefixLength):creator['createSegment$int'](lower);
    }

    public toPrefixedSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            return <any>this.toPrefixedSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator(segmentPrefixLength, creator);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} segmentValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isPrefixBlock(segmentValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof segmentValue === 'number') || segmentValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            super.isPrefixBlock(segmentValue, upperValue, divisionPrefixLen);
        } else if(((typeof segmentValue === 'number') || segmentValue === null) && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$int(segmentValue);
        } else if(segmentValue === undefined && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public isPrefixBlock$() : boolean {
        return (this.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) || super.isPrefixBlock();
    }

    isNetworkChangedByPrefix(bits : number, withPrefixLength : boolean) : boolean {
        let hasBits : boolean = (bits != null);
        if(hasBits && (bits < 0 || bits > this.getBitCount())) {
            throw new PrefixLenException(this, bits);
        }
        withPrefixLength = hasBits && withPrefixLength;
        let thisHasPrefix : boolean = this.isPrefixed();
        if(withPrefixLength !== thisHasPrefix) {
            return true;
        }
        return !hasBits || !this.isPrefixBlock$int(bits);
    }

    public toNetworkSegment$java_lang_Integer(segmentPrefixLength : number) : IPAddressSegment {
        return this.toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength, true);
    }

    public toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength : number, withPrefixLength : boolean) : IPAddressSegment { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toNetworkSegment$java_lang_Integer$boolean$inet_ipaddr_AddressNetwork_AddressSegmentCreator<S extends IPAddressSegment>(segmentPrefixLength : number, withPrefixLength : boolean, creator : AddressNetwork.AddressSegmentCreator<S>) : S {
        let newLower : number = this.getLowerSegmentValue();
        let newUpper : number = this.getUpperSegmentValue();
        if(segmentPrefixLength != null) {
            let mask : number = this.getSegmentNetworkMask(segmentPrefixLength);
            newLower &= mask;
            newUpper |= this.getSegmentHostMask(segmentPrefixLength);
        }
        let hasBits : boolean = (segmentPrefixLength != null);
        withPrefixLength = hasBits && withPrefixLength;
        if(newLower !== newUpper) {
            if(!withPrefixLength) {
                return creator['createSegment$int$int$java_lang_Integer'](newLower, newUpper, null);
            }
            return creator['createSegment$int$int$java_lang_Integer'](newLower, newUpper, segmentPrefixLength);
        }
        return withPrefixLength?creator['createSegment$int$java_lang_Integer'](newLower, segmentPrefixLength):creator['createSegment$int'](newLower);
    }

    public toNetworkSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, withPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            return <any>this.toNetworkSegment$java_lang_Integer$boolean$inet_ipaddr_AddressNetwork_AddressSegmentCreator(segmentPrefixLength, withPrefixLength, creator);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null) && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength, withPrefixLength);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && withPrefixLength === undefined && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer(segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    public toHostSegment$java_lang_Integer(segmentPrefixLength : number) : IPAddressSegment { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toHostSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator<S extends IPAddressSegment>(segmentPrefixLength : number, creator : AddressNetwork.AddressSegmentCreator<S>) : S {
        let mask : number = (segmentPrefixLength == null)?0:this.getSegmentHostMask(segmentPrefixLength);
        let newLower : number = this.getLowerSegmentValue() & mask;
        let newUpper : number = this.getUpperSegmentValue() & mask;
        if(newLower !== newUpper) {
            return creator['createSegment$int$int$java_lang_Integer'](newLower, newUpper, null);
        }
        return creator['createSegment$int'](newLower);
    }

    public toHostSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            return <any>this.toHostSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator(segmentPrefixLength, creator);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && creator === undefined) {
            return <any>this.toHostSegment$java_lang_Integer(segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    isHostChangedByPrefix(bits : number) : boolean {
        let hasBits : boolean = (bits != null);
        if(hasBits && (bits < 0 || bits > this.getBitCount())) {
            throw new PrefixLenException(this, bits);
        }
        if(this.isPrefixed()) {
            return true;
        }
        let mask : number = !hasBits?0:this.getSegmentHostMask(bits);
        let value : number = this.getLowerSegmentValue();
        let upperValue : number = this.getUpperSegmentValue();
        return value !== (value & mask) || upperValue !== (upperValue & mask);
    }

    /**
     * returns a new segment masked by the given mask
     * 
     * This method applies the mask first to every address in the range, and it does not preserve any existing prefix.
     * The given prefix will be applied to the range of addresses after the mask.
     * If the combination of the two does not result in a contiguous range, then {@link IncompatibleAddressException} is thrown.
     * 
     * @param {number} maskValue
     * @param {number} segmentPrefixLength
     * @return {boolean}
     */
    isChangedByMask(maskValue : number, segmentPrefixLength : number) : boolean {
        let hasBits : boolean = (segmentPrefixLength != null);
        if(hasBits && (segmentPrefixLength < 0 || segmentPrefixLength > this.getBitCount())) {
            throw new PrefixLenException(this, segmentPrefixLength);
        }
        let value : number = this.getLowerSegmentValue();
        let upperValue : number = this.getUpperSegmentValue();
        return value !== (value & maskValue) || upperValue !== (upperValue & maskValue) || (this.isPrefixed()?!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.getSegmentPrefixLength(),segmentPrefixLength)):hasBits);
    }

    isChangedByOr(maskValue : number, segmentPrefixLength : number) : boolean {
        let hasBits : boolean = (segmentPrefixLength != null);
        if(hasBits && (segmentPrefixLength < 0 || segmentPrefixLength > this.getBitCount())) {
            throw new PrefixLenException(this, segmentPrefixLength);
        }
        let value : number = this.getLowerSegmentValue();
        let upperValue : number = this.getUpperSegmentValue();
        return value !== (value | maskValue) || upperValue !== (upperValue | maskValue) || (this.isPrefixed()?!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.getSegmentPrefixLength(),segmentPrefixLength)):hasBits);
    }

    public isMaskCompatibleWithRange(maskValue? : any, divisionPrefixLen? : any, isAutoSubnets? : any) : any {
        if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && ((typeof isAutoSubnets === 'boolean') || isAutoSubnets === null)) {
            super.isMaskCompatibleWithRange(maskValue, divisionPrefixLen, isAutoSubnets);
        } else if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && isAutoSubnets === undefined) {
            return <any>this.isMaskCompatibleWithRange$int$java_lang_Integer(maskValue, divisionPrefixLen);
        } else throw new Error('invalid overload');
    }

    public isMaskCompatibleWithRange$int$java_lang_Integer(maskValue : number, segmentPrefixLength : number) : boolean {
        if(!this.isMultiple()) {
            return true;
        }
        return super.isMaskCompatibleWithRange$long$java_lang_Integer$boolean(maskValue, segmentPrefixLength, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets());
    }

    public isBitwiseOrCompatibleWithRange(maskValue? : any, divisionPrefixLen? : any, isAutoSubnets? : any) : any {
        if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && ((typeof isAutoSubnets === 'boolean') || isAutoSubnets === null)) {
            super.isBitwiseOrCompatibleWithRange(maskValue, divisionPrefixLen, isAutoSubnets);
        } else if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && isAutoSubnets === undefined) {
            return <any>this.isBitwiseOrCompatibleWithRange$int$java_lang_Integer(maskValue, divisionPrefixLen);
        } else throw new Error('invalid overload');
    }

    public isBitwiseOrCompatibleWithRange$int$java_lang_Integer(maskValue : number, segmentPrefixLength : number) : boolean {
        return super.isBitwiseOrCompatibleWithRange$long$java_lang_Integer$boolean(maskValue, segmentPrefixLength, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets());
    }

    /**
     * If this segment represents a range of values, returns a segment representing just the lowest value in the range, otherwise returns this.
     * @return
     * @return {IPAddressSegment}
     */
    public abstract getLower() : IPAddressSegment;

    /**
     * If this segment represents a range of values, returns a segment representing just the highest value in the range, otherwise returns this.
     * @return
     * @return {IPAddressSegment}
     */
    public abstract getUpper() : IPAddressSegment;

    static getLowestOrHighest<S extends IPAddressSegment>(original : S, segmentCreator : AddressNetwork.AddressSegmentCreator<S>, lowest : boolean) : S {
        if(!original.isMultiple() && !original.isPrefixed()) {
            return original;
        }
        return segmentCreator['createSegment$int$java_lang_Integer'](lowest?original.getLowerSegmentValue():original.getUpperSegmentValue(), AddressNetwork.PrefixConfiguration["_$wrappers"][original.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:original.getSegmentPrefixLength());
    }

    /**
     * 
     * @return {*}
     */
    public abstract getIterable() : java.lang.Iterable<any>;

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * Iterates through the individual prefix blocks.
     * 
     * If the series has no prefix length, then this is equivalent to {@link #iterator()}
     * @return {*}
     */
    public abstract prefixBlockIterator() : any;

    public static getBitCount(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.BITS_PER_SEGMENT:IPv6Address.BITS_PER_SEGMENT;
    }

    public static getByteCount(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.BYTES_PER_SEGMENT:IPv6Address.BYTES_PER_SEGMENT;
    }

    public static getDefaultTextualRadix(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.DEFAULT_TEXTUAL_RADIX:IPv6Address.DEFAULT_TEXTUAL_RADIX;
    }

    public matches$int(value : number) : boolean {
        return super.matches$long(value);
    }

    /**
     * 
     * @param {number} value
     * @return {boolean}
     */
    public matches(value? : any) : any {
        if(((typeof value === 'number') || value === null)) {
            return <any>this.matches$int(value);
        } else if(((typeof value === 'number') || value === null)) {
            return <any>this.matches$long(value);
        } else throw new Error('invalid overload');
    }

    public matchesWithPrefixMask$int$java_lang_Integer(value : number, segmentPrefixLength : number) : boolean {
        return super.matchesWithPrefixMask$long$java_lang_Integer(value, segmentPrefixLength);
    }

    public matchesWithPrefixMask(value? : any, segmentPrefixLength? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            return <any>this.matchesWithPrefixMask$int$java_lang_Integer(value, segmentPrefixLength);
        } else if(((typeof value === 'number') || value === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            return <any>this.matchesWithPrefixMask$long$java_lang_Integer(value, segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    public matchesWithMask$int$int(value : number, mask : number) : boolean {
        return super.matchesWithMask$long$long(value, mask);
    }

    public matchesWithMask$int$int$int(lowerValue : number, upperValue : number, mask : number) : boolean {
        return super.matchesWithMask$long$long$long(lowerValue, upperValue, mask);
    }

    /**
     * 
     * @param {number} lowerValue
     * @param {number} upperValue
     * @param {number} mask
     * @return {boolean}
     */
    public matchesWithMask(lowerValue? : any, upperValue? : any, mask? : any) : any {
        if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof mask === 'number') || mask === null)) {
            return <any>this.matchesWithMask$int$int$int(lowerValue, upperValue, mask);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof mask === 'number') || mask === null)) {
            return <any>this.matchesWithMask$long$long$long(lowerValue, upperValue, mask);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && mask === undefined) {
            return <any>this.matchesWithMask$int$int(lowerValue, upperValue);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && mask === undefined) {
            return <any>this.matchesWithMask$long$long(lowerValue, upperValue);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getValueCount() : number {
        return this.getUpperSegmentValue() - this.getLowerSegmentValue() + 1;
    }

    /**
     * Counts the number of prefixes in this address segment.
     * <p>
     * If this segment has no prefix length, this is equivalent to {@link #getValueCount()}
     * 
     * @return
     * @return {number}
     */
    public getPrefixValueCount() : number {
        let prefixLength : number = this.getSegmentPrefixLength();
        if(prefixLength == null) {
            return this.getValueCount();
        }
        let shiftAdjustment : number = this.getBitCount() - prefixLength;
        return (this.getUpperSegmentValue() >>> shiftAdjustment) - (this.getLowerSegmentValue() >>> shiftAdjustment) + 1;
    }

    /**
     * 
     * @return {number}
     */
    public getDivisionValueCount() : number {
        return this.getValueCount();
    }

    highByte() : number {
        return IPAddressSegment.highByte(this.getLowerSegmentValue());
    }

    lowByte() : number {
        return IPAddressSegment.lowByte(this.getLowerSegmentValue());
    }

    static highByte(value : number) : number {
        return value >> 8;
    }

    static lowByte(value : number) : number {
        return value & 255;
    }

    /**
     * 
     * @return {number}
     */
    public getMaxValue() : number {
        return this.getMaxSegmentValue();
    }

    /**
     * 
     * @return {boolean}
     */
    public isMultiple() : boolean {
        return this.getLowerSegmentValue() !== this.getUpperSegmentValue();
    }

    /**
     * returns the lower value
     * @return {number}
     */
    public getLowerSegmentValue() : number {
        return this.value;
    }

    /**
     * returns the upper value
     * @return {number}
     */
    public getUpperSegmentValue() : number {
        return this.upperValue;
    }

    /**
     * returns the lower value as a long, although for individual segments {@link #getLowerSegmentValue()} provides the same value as an int
     * @return {number}
     */
    public getLowerValue() : number {
        return this.getLowerSegmentValue();
    }

    /**
     * returns the lower upper value as a long, although for individual segments {@link #getUpperSegmentValue()} provides the same value as an int
     * @return {number}
     */
    public getUpperValue() : number {
        return this.getUpperSegmentValue();
    }

    public reverseBits$boolean(perByte : boolean) : IPAddressSegment { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPAddressSegment}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPAddressSegment}
     */
    public abstract reverseBytes() : IPAddressSegment;

    public removePrefixLength$() : IPAddressSegment { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public removePrefixLength$boolean(zeroed : boolean) : IPAddressSegment { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    static removePrefix<S extends IPAddressSegment>(original : S, zeroed : boolean, creator : AddressNetwork.AddressSegmentCreator<S>) : S {
        if(original.isPrefixed()) {
            let lower : number = original.getLowerSegmentValue();
            let upper : number = original.getUpperSegmentValue();
            if(zeroed) {
                let maskBits : number = original.getSegmentNetworkMask(original.getSegmentPrefixLength());
                if(!original.isMaskCompatibleWithRange$int$java_lang_Integer(maskBits, null)) {
                    throw new IncompatibleAddressException(original, maskBits, "ipaddress.error.maskMismatch");
                }
                return creator['createSegment$int$int$java_lang_Integer'](lower & maskBits, upper & maskBits, null);
            }
            return creator['createSegment$int$int$java_lang_Integer'](lower, upper, null);
        }
        return original;
    }

    /**
     * 
     * @param {number} value
     * @return {boolean}
     */
    public isBoundedBy(value : number) : boolean {
        return this.getUpperSegmentValue() < value;
    }

    public getSegmentPrefixLength() : number {
        return this.getDivisionPrefixLength();
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean {
        if(other != null && other instanceof <any>IPAddressSegment) {
            return this.isSameValues$inet_ipaddr_format_AddressDivision(<IPAddressSegment>other);
        }
        return false;
    }

    public isSameValues$inet_ipaddr_IPAddressSegment(otherSegment : IPAddressSegment) : boolean {
        return this.getLowerSegmentValue() === otherSegment.getLowerSegmentValue() && this.getUpperSegmentValue() === otherSegment.getUpperSegmentValue();
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>IPAddressSegment) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_IPAddressSegment(otherSegment);
        } else if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return IPAddressSegment.hash(this.getLowerSegmentValue(), this.getUpperSegmentValue(), this.getBitCount());
    }

    static hash(lower : number, upper : number, bitCount : number) : number {
        return lower | (upper << bitCount);
    }

    /**
     * 
     * @param {*} other
     * @return {boolean} whether this subnet segment contains the given address segment
     */
    containsSeg(other : AddressSegment) : boolean {
        return other.getLowerSegmentValue() >= this.getLowerSegmentValue() && other.getUpperSegmentValue() <= this.getUpperSegmentValue();
    }

    /**
     * 
     * @return {boolean}
     */
    public includesZero() : boolean {
        return this.getLowerSegmentValue() === 0;
    }

    /**
     * 
     * @return {boolean}
     */
    public includesMax() : boolean {
        return this.getUpperSegmentValue() === this.getMaxSegmentValue();
    }

    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toHexString$boolean(with0xPrefix : boolean) : string {
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(with0xPrefix?IPAddressSection.IPStringCache.hexPrefixedParams_$LI$():IPAddressSection.IPStringCache.hexParams_$LI$());
    }

    public toNormalizedString$() : string {
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPAddressSection.IPStringCache.canonicalSegmentParams_$LI$());
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options : IPAddressSection.IPStringOptions) : string {
        let params : IPAddressStringWriter<IPAddressStringDivisionSeries> = IPAddressSection.toIPParams(options);
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        return /* toString */params.appendDivision(builder, this).str;
    }

    public toNormalizedString(options? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null)) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
        } else if(options === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public static toUnsignedStringLength$int$int(value : number, radix : number) : number {
        return AddressDivision.toUnsignedStringLength$long$int(value, radix);
    }

    public static toUnsignedStringLength(value? : any, radix? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>IPAddressSegment.toUnsignedStringLength$int$int(value, radix);
        } else if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>IPAddressSegment.toUnsignedStringLength$long$int(value, radix);
        } else throw new Error('invalid overload');
    }

    public static toUnsignedString(value? : any, radix? : any, choppedDigits? : any, uppercase? : any, dig? : any, appendable? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((dig != null && dig instanceof <any>Array && (dig.length==0 || dig[0] == null ||(typeof dig[0] === 'string'))) || dig === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            super.toUnsignedString(value, radix, choppedDigits, uppercase, dig, appendable);
        } else if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((uppercase != null && uppercase instanceof <any>Array && (uppercase.length==0 || uppercase[0] == null ||(typeof uppercase[0] === 'string'))) || uppercase === null) && ((dig != null && (dig instanceof Object)) || dig === null) && appendable === undefined) {
            return <any>IPAddressSegment.toUnsignedString$long$int$int$char_A$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, dig);
        } else if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((choppedDigits != null && (choppedDigits instanceof Object)) || choppedDigits === null) && uppercase === undefined && dig === undefined && appendable === undefined) {
            return <any>IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(value, radix, choppedDigits);
        } else throw new Error('invalid overload');
    }

    static toUnsignedString$int$int$java_lang_StringBuilder(value : number, radix : number, appendable : { str: string }) : { str: string } {
        return AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(value, radix, 0, false, AddressDivisionBase.DIGITS_$LI$(), appendable);
    }

    setStandardString$java_lang_CharSequence$boolean$int$int$int(addressStr : any, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, originalLowerValue : number) {
        if(this.cachedString == null && isStandardString && originalLowerValue === this.getLowerValue()) {
            this.cachedString = /* subSequence */addressStr.substring(lowerStringStartIndex, lowerStringEndIndex).toString();
        }
    }

    setWildcardString$java_lang_CharSequence$boolean$int$int$int(addressStr : any, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, lowerValue : number) {
        if(this.cachedWildcardString == null && isStandardString && lowerValue === this.getLowerValue() && lowerValue === this.getUpperValue()) {
            this.cachedWildcardString = /* subSequence */addressStr.substring(lowerStringStartIndex, lowerStringEndIndex).toString();
        }
    }

    public setStandardString$java_lang_CharSequence$boolean$boolean$int$int$int$int$int(addressStr : any, isStandardString : boolean, isStandardRangeString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, upperStringEndIndex : number, rangeLower : number, rangeUpper : number) {
        if(this.cachedString == null) {
            if(this.isSinglePrefixBlock()) {
                if(isStandardString && rangeLower === this.getLowerValue()) {
                    this.cachedString = /* subSequence */addressStr.substring(lowerStringStartIndex, lowerStringEndIndex).toString();
                }
            } else if(this.isFullRange()) {
                this.cachedString = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
            } else if(isStandardRangeString && rangeLower === this.getLowerValue()) {
                let upper : number = this.getUpperValue();
                if(this.isPrefixed()) {
                    upper &= this.getDivisionNetworkMask(this.getDivisionPrefixLength());
                }
                if(rangeUpper === upper) {
                    this.cachedString = /* subSequence */addressStr.substring(lowerStringStartIndex, upperStringEndIndex).toString();
                }
            }
        }
    }

    public setStandardString(addressStr? : any, isStandardString? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, lowerStringEndIndex? : any, upperStringEndIndex? : any, rangeLower? : any, rangeUpper? : any) : any {
        if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null) && ((typeof rangeLower === 'number') || rangeLower === null) && ((typeof rangeUpper === 'number') || rangeUpper === null)) {
            return <any>this.setStandardString$java_lang_CharSequence$boolean$boolean$int$int$int$int$int(addressStr, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex, rangeLower, rangeUpper);
        } else if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'number') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && upperStringEndIndex === undefined && rangeLower === undefined && rangeUpper === undefined) {
            return <any>this.setStandardString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex);
        } else throw new Error('invalid overload');
    }

    public setWildcardString$java_lang_CharSequence$boolean$int$int$int$int(addressStr : any, isStandardRangeString : boolean, lowerStringStartIndex : number, upperStringEndIndex : number, rangeLower : number, rangeUpper : number) {
        if(this.cachedWildcardString == null) {
            if(this.isFullRange()) {
                this.cachedWildcardString = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
            } else if(isStandardRangeString && rangeLower === this.getLowerValue() && rangeUpper === this.getUpperValue()) {
                this.cachedWildcardString = /* subSequence */addressStr.substring(lowerStringStartIndex, upperStringEndIndex).toString();
            }
        }
    }

    public setWildcardString(addressStr? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, upperStringEndIndex? : any, rangeLower? : any, rangeUpper? : any) : any {
        if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null) && ((typeof rangeLower === 'number') || rangeLower === null) && ((typeof rangeUpper === 'number') || rangeUpper === null)) {
            return <any>this.setWildcardString$java_lang_CharSequence$boolean$int$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, rangeLower, rangeUpper);
        } else if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null) && ((typeof rangeLower === 'number') || rangeLower === null) && rangeUpper === undefined) {
            return <any>this.setWildcardString$java_lang_CharSequence$boolean$int$int$int(addressStr, isStandardRangeString, lowerStringStartIndex, upperStringEndIndex, rangeLower);
        } else throw new Error('invalid overload');
    }

    public abstract contains(other?: any): any;
    public abstract compareTo(arg0?: any): any;}
IPAddressSegment["__class"] = "inet.ipaddr.IPAddressSegment";
IPAddressSegment["__interfaces"] = ["inet.ipaddr.AddressSegment","inet.ipaddr.AddressComponent","inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];




