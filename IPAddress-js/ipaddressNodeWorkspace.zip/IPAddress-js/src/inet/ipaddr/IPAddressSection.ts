/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivisionGrouping } from './format/AddressDivisionGrouping';
import { IPAddressBitsDivision } from './format/IPAddressBitsDivision';
import { IPAddressDivision } from './format/IPAddressDivision';
import { IPAddressDivisionGrouping } from './format/IPAddressDivisionGrouping';
import { IPAddressStringDivisionSeries } from './format/IPAddressStringDivisionSeries';
import { IPAddressPartConfiguredString } from './format/util/IPAddressPartConfiguredString';
import { IPAddressPartStringCollection } from './format/util/IPAddressPartStringCollection';
import { IPAddressSQLTranslator } from './format/util/sql/IPAddressSQLTranslator';
import { MySQLTranslator } from './format/util/sql/MySQLTranslator';
import { SQLStringMatcher } from './format/util/sql/SQLStringMatcher';
import { IPv6Address } from './ipv6/IPv6Address';
import { IPv6AddressSegment } from './ipv6/IPv6AddressSegment';
import { IPAddressSegmentSeries } from './IPAddressSegmentSeries';
import { AddressSection } from './AddressSection';
import { IPAddressSegment } from './IPAddressSegment';
import { IPAddressNetwork } from './IPAddressNetwork';
import { NetworkMismatchException } from './NetworkMismatchException';
import { InconsistentPrefixException } from './InconsistentPrefixException';
import { HostIdentifierException } from './HostIdentifierException';
import { IPAddress } from './IPAddress';
import { Address } from './Address';
import { AddressNetwork } from './AddressNetwork';
import { PrefixLenException } from './PrefixLenException';
import { IncompatibleAddressException } from './IncompatibleAddressException';
import { AddressSegment } from './AddressSegment';
import { SizeMismatchException } from './SizeMismatchException';
import { AddressComparator } from './AddressComparator';
import { AddressDivisionWriter } from './format/util/AddressDivisionWriter';

/**
 * A section of an IPAddress.
 * 
 * It is a series of individual address segments.
 * <p>
 * IPAddressSection objects are immutable.  Some of the derived state is created upon demand and cached.
 * 
 * This also makes them thread-safe.
 * 
 * Almost all operations that can be performed on IPAddress objects can also be performed on IPAddressSection objects and vice-versa.
 * 
 * @extends IPAddressDivisionGrouping
 * @class
 */
export abstract class IPAddressSection extends IPAddressDivisionGrouping implements IPAddressSegmentSeries, AddressSection {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!IPAddressSection.__static_initialized) { IPAddressSection.__static_initialized = true; IPAddressSection.__static_initializer_0(); } }

    static serialVersionUID : number = 4;

    static EMPTY_PARTS : IPAddressStringDivisionSeries[]; public static EMPTY_PARTS_$LI$() : IPAddressStringDivisionSeries[] { IPAddressSection.__static_initialize(); return IPAddressSection.EMPTY_PARTS; };

    static __static_initializer_0() {
        IPAddressSection.EMPTY_PARTS = [];
    }

    /*private*/ prefixCache : IPAddressSection.PrefixCache;

    /*private*/ cachedIPAddressCount : BigInteger;

    constructor(segments : IPAddressSegment[], cloneSegments : boolean, checkSegs : boolean) {
        super(cloneSegments?/* clone */segments.slice(0):segments, checkSegs);
        if(this.prefixCache===undefined) this.prefixCache = null;
        if(this.cachedIPAddressCount===undefined) this.cachedIPAddressCount = null;
        if(checkSegs) {
            let network : IPAddressNetwork<any, any, any, any, any> = this.getNetwork();
            let previousSegmentPrefix : number = null;
            for(let i : number = 0; i < segments.length; i++) {
                let segment : IPAddressSegment = segments[i];
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,segment.getNetwork()))) {
                    throw new NetworkMismatchException(segment);
                }
                let segPrefix : number = segment.getSegmentPrefixLength();
                if(previousSegmentPrefix == null) {
                    if(segPrefix != null) {
                        this.cachedPrefixLength = this.getNetworkPrefixLength$int$int(i, segPrefix);
                    }
                } else if(segPrefix == null || segPrefix !== 0) {
                    throw new InconsistentPrefixException(segments[i - 1], segment, segPrefix);
                }
                previousSegmentPrefix = segPrefix;
            };
            if(previousSegmentPrefix == null) {
                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            }
        }
    }

    /**
     * 
     * @return {number}
     */
    calculatePrefix() : number {
        let count : number = this.getSegmentCount();
        for(let i : number = 0; i < count; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            let prefix : number = div.getSegmentPrefixLength();
            if(prefix != null) {
                return this.getNetworkPrefixLength$int$int(i, prefix);
            }
        };
        return null;
    }

    public getNetworkPrefixLength$int$int(segmentIndex : number, segmentPrefix : number) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getNetworkPrefixLength(segmentIndex? : any, segmentPrefix? : any) : any {
        if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((typeof segmentPrefix === 'number') || segmentPrefix === null)) {
            return <any>this.getNetworkPrefixLength$int$int(segmentIndex, segmentPrefix);
        } else if(segmentIndex === undefined && segmentPrefix === undefined) {
            return <any>this.getNetworkPrefixLength$();
        } else throw new Error('invalid overload');
    }

    checkSegments(segs : IPv6AddressSegment[]) {
        let network : IPAddressNetwork<any, any, any, any, any> = this.getNetwork();
        for(let index126=0; index126 < segs.length; index126++) {
            let seg = segs[index126];
            {
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,seg.getNetwork()))) {
                    throw new NetworkMismatchException(seg);
                }
            }
        }
    }

    static getMessage(key : string) : string {
        return HostIdentifierException.message;
    }

    public initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(prefixLen : number, network : boolean, cachedNetworkPrefix : number, cachedMinPrefix : number, cachedEquivalentPrefix : number, cachedCount : BigInteger, zeroSegments : IPAddressDivisionGrouping.RangeList, zeroRanges : IPAddressDivisionGrouping.RangeList) {
        if(this.prefixCache == null) {
            this.prefixCache = new IPAddressSection.PrefixCache();
        }
        if(network) {
            this.setNetworkMaskPrefix(prefixLen);
        } else {
            this.setHostMaskPrefix(prefixLen);
        }
        super.initCachedValues$java_lang_Integer$java_math_BigInteger(cachedNetworkPrefix, cachedCount);
        this.prefixCache.cachedMinPrefix = cachedMinPrefix;
        this.prefixCache.cachedEquivalentPrefix = cachedEquivalentPrefix;
    }

    public initCachedValues(prefixLen? : any, network? : any, cachedNetworkPrefix? : any, cachedMinPrefix? : any, cachedEquivalentPrefix? : any, cachedCount? : any, zeroSegments? : any, zeroRanges? : any) : any {
        if(((typeof prefixLen === 'number') || prefixLen === null) && ((typeof network === 'boolean') || network === null) && ((typeof cachedNetworkPrefix === 'number') || cachedNetworkPrefix === null) && ((typeof cachedMinPrefix === 'number') || cachedMinPrefix === null) && ((typeof cachedEquivalentPrefix === 'number') || cachedEquivalentPrefix === null) && ((cachedCount != null && cachedCount instanceof <any>BigInteger) || cachedCount === null) && ((zeroSegments != null && zeroSegments instanceof <any>IPAddressDivisionGrouping.RangeList) || zeroSegments === null) && ((zeroRanges != null && zeroRanges instanceof <any>IPAddressDivisionGrouping.RangeList) || zeroRanges === null)) {
            return <any>this.initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(prefixLen, network, cachedNetworkPrefix, cachedMinPrefix, cachedEquivalentPrefix, cachedCount, zeroSegments, zeroRanges);
        } else if(((typeof prefixLen === 'number') || prefixLen === null) && ((network != null && network instanceof <any>BigInteger) || network === null) && cachedNetworkPrefix === undefined && cachedMinPrefix === undefined && cachedEquivalentPrefix === undefined && cachedCount === undefined && zeroSegments === undefined && zeroRanges === undefined) {
            return <any>this.initCachedValues$java_lang_Integer$java_math_BigInteger(prefixLen, network);
        } else throw new Error('invalid overload');
    }

    static getNoZerosRange() : IPAddressDivisionGrouping.RangeList {
        return IPAddressDivisionGrouping.getNoZerosRange();
    }

    static getSingleRange(index : number, len : number) : IPAddressDivisionGrouping.RangeList {
        return IPAddressDivisionGrouping.getSingleRange(index, len);
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSegmentCount() * this.getBitsPerSegment();
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSegmentCount() * this.getBytesPerSegment();
    }

    public static bitsPerSegment(version : IPAddress.IPVersion) : number {
        return IPAddressSegment.getBitCount(version);
    }

    public static bytesPerSegment(version : IPAddress.IPVersion) : number {
        return IPAddressSegment.getBitCount(version);
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getNonZeroHostCount() : BigInteger {
        if(this.isPrefixed() && this.getNetworkPrefixLength() < this.getBitCount()) {
            let cached : BigInteger = this.cachedIPAddressCount;
            if(cached == null) {
                this.cachedIPAddressCount = cached = this.getCountImpl$boolean(true);
            }
            return cached;
        }
        return this.getCount();
    }

    public getCountImpl$boolean(excludeZeroHosts : boolean) : BigInteger { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getCountImpl(excludeZeroHosts? : any) : any {
        if(((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>this.getCountImpl$boolean(excludeZeroHosts);
        } else if(excludeZeroHosts === undefined) {
            return <any>this.getCountImpl$();
        } else throw new Error('invalid overload');
    }

    public getCountImpl$() : BigInteger {
        return this.getCountImpl$boolean(false);
    }

    public isIPv4() : boolean {
        return false;
    }

    public isIPv6() : boolean {
        return false;
    }

    public static isPrefixSubnet$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$int$int$java_lang_Integer$inet_ipaddr_AddressNetwork_PrefixConfiguration$boolean(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, segmentCount : number, bytesPerSegment : number, bitsPerSegment : number, segmentMaxValue : number, networkPrefixLength : number, prefixConfiguration : AddressNetwork.PrefixConfiguration, fullRangeOnly : boolean) : boolean {
        if(networkPrefixLength == null || AddressNetwork.PrefixConfiguration["_$wrappers"][prefixConfiguration].prefixedSubnetsAreExplicit()) {
            return false;
        }
        if(networkPrefixLength < 0) {
            networkPrefixLength = 0;
        } else {
            let totalBitCount : number = (bitsPerSegment === 8)?segmentCount << 3:((bitsPerSegment === 16)?segmentCount << 4:segmentCount * bitsPerSegment);
            if(networkPrefixLength >= totalBitCount) {
                return false;
            }
        }
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefixConfiguration].allPrefixedAddressesAreSubnets()) {
            return true;
        }
        let prefixedSegment : number = IPAddressSection.getHostSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
        let i : number = prefixedSegment;
        if(i < segmentCount) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
            do {
                let lower : number = lowerValueProvider.getValue(i);
                if(segmentPrefixLength === 0) {
                    if(lower !== 0) {
                        return false;
                    }
                    let upper : number = upperValueProvider.getValue(i);
                    if(fullRangeOnly) {
                        if(upper !== segmentMaxValue) {
                            return false;
                        }
                    } else {
                        let upperOnes : number = javaemul.internal.IntegerHelper.numberOfTrailingZeros(~upper);
                        if(upperOnes > 0) {
                            if((upper >>> upperOnes) !== 0) {
                                return false;
                            }
                            fullRangeOnly = true;
                        } else if(upper !== 0) {
                            return false;
                        }
                    }
                } else {
                    let segHostBits : number = bitsPerSegment - segmentPrefixLength;
                    if(fullRangeOnly) {
                        let hostMask : number = ~(~0 << segHostBits);
                        if((hostMask & lower) !== 0) {
                            return false;
                        }
                        let upper : number = upperValueProvider.getValue(i);
                        if((hostMask & upper) !== hostMask) {
                            return false;
                        }
                    } else {
                        let lowerZeros : number = javaemul.internal.IntegerHelper.numberOfTrailingZeros(lower);
                        if(lowerZeros < segHostBits) {
                            return false;
                        }
                        let upper : number = upperValueProvider.getValue(i);
                        let upperOnes : number = javaemul.internal.IntegerHelper.numberOfTrailingZeros(~upper);
                        let upperZeros : number = javaemul.internal.IntegerHelper.numberOfTrailingZeros((upper | (~0 << bitsPerSegment)) >>> upperOnes);
                        if(upperOnes + upperZeros < segHostBits) {
                            return false;
                        }
                        if(upperOnes > 0) {
                            fullRangeOnly = true;
                        }
                    }
                }
                segmentPrefixLength = 0;
            } while((++i < segmentCount));
        }
        return true;
    }

    public static isPrefixSubnet(lowerValueProvider? : any, upperValueProvider? : any, segmentCount? : any, bytesPerSegment? : any, bitsPerSegment? : any, segmentMaxValue? : any, networkPrefixLength? : any, prefixConfiguration? : any, fullRangeOnly? : any) : any {
        if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((typeof fullRangeOnly === 'boolean') || fullRangeOnly === null)) {
            return <any>IPAddressSection.isPrefixSubnet$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$int$int$java_lang_Integer$inet_ipaddr_AddressNetwork_PrefixConfiguration$boolean(lowerValueProvider, upperValueProvider, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, networkPrefixLength, prefixConfiguration, fullRangeOnly);
        } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null && lowerValueProvider[0] instanceof <any>IPAddressSegment))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((segmentCount != null && segmentCount instanceof <any>IPAddressNetwork) || segmentCount === null) && ((typeof bytesPerSegment === 'boolean') || bytesPerSegment === null) && bitsPerSegment === undefined && segmentMaxValue === undefined && networkPrefixLength === undefined && prefixConfiguration === undefined && fullRangeOnly === undefined) {
            return <any>IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(lowerValueProvider, upperValueProvider, segmentCount, bytesPerSegment);
        } else throw new Error('invalid overload');
    }

    static isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(sectionSegments : IPAddressSegment[], networkPrefixLength : number, network : IPAddressNetwork<any, any, any, any, any>, fullRangeOnly : boolean) : boolean {
        let segmentCount : number = sectionSegments.length;
        if(segmentCount === 0) {
            return false;
        }
        let seg : IPAddressSegment = sectionSegments[0];
        return IPAddressSection.isPrefixSubnet$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$int$int$java_lang_Integer$inet_ipaddr_AddressNetwork_PrefixConfiguration$boolean({ getValue : (segmentIndex) => sectionSegments[segmentIndex].getLowerSegmentValue() }, { getValue : (segmentIndex) => sectionSegments[segmentIndex].getUpperSegmentValue() }, segmentCount, seg.getByteCount(), seg.getBitCount(), seg.getMaxSegmentValue(), networkPrefixLength, network.getPrefixConfiguration(), fullRangeOnly);
    }

    isNetworkSection(networkPrefixLength : number, withPrefixLength : boolean) : boolean {
        let segmentCount : number = this.getSegmentCount();
        if(segmentCount === 0) {
            return true;
        }
        let bitsPerSegment : number = this.getBitsPerSegment();
        let prefixedSegmentIndex : number = IPAddressSection.getNetworkSegmentIndex(networkPrefixLength, this.getBytesPerSegment(), bitsPerSegment);
        if(prefixedSegmentIndex + 1 < segmentCount) {
            return false;
        }
        let segPrefLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, networkPrefixLength, prefixedSegmentIndex);
        return !this.getSegment(segmentCount - 1).isNetworkChangedByPrefix(segPrefLength, withPrefixLength);
    }

    isHostSection(networkPrefixLength : number) : boolean {
        let segmentCount : number = this.getSegmentCount();
        if(segmentCount === 0) {
            return true;
        }
        if(networkPrefixLength >= this.getBitsPerSegment()) {
            return false;
        }
        return !this.getSegment(0).isHostChangedByPrefix(networkPrefixLength);
    }

    static getNetworkSegmentIndex(networkPrefixLength : number, bytesPerSegment : number, bitsPerSegment : number) : number {
        return AddressDivisionGrouping.getNetworkSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
    }

    static getHostSegmentIndex(networkPrefixLength : number, bytesPerSegment : number, bitsPerSegment : number) : number {
        return AddressDivisionGrouping.getHostSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
    }

    checkForPrefixMask(network : boolean) : number {
        let front : number;
        let back : number;
        if(network) {
            front = this.getSegment(0).getMaxSegmentValue();
            back = 0;
        } else {
            back = this.getSegment(0).getMaxSegmentValue();
            front = 0;
        }
        let prefixLen : number = 0;
        let count : number = this.getSegmentCount();
        for(let i : number = 0; i < count; i++) {
            let seg : IPAddressSegment = this.getSegment(i);
            let value : number = seg.getLowerSegmentValue();
            if(value !== front) {
                let segmentPrefixLen : number = seg.getBlockMaskPrefixLength(network);
                if(segmentPrefixLen == null) {
                    return null;
                }
                prefixLen += segmentPrefixLen;
                for(i++; i < count; i++) {
                    value = this.getSegment(i).getLowerSegmentValue();
                    if(value !== back) {
                        return null;
                    }
                };
            } else {
                prefixLen += seg.getBitCount();
            }
        };
        return prefixLen;
    }

    /**
     * If this address section is equivalent to the mask for a CIDR prefix block, it returns that prefix length.
     * Otherwise, it returns null.
     * A CIDR network mask is an address with all 1s in the network section and then all 0s in the host section.
     * A CIDR host mask is an address with all 0s in the network section and then all 1s in the host section.
     * The prefix length is the length of the network section.
     * 
     * Also, keep in mind that the prefix length returned by this method is not equivalent to the prefix length used to construct this object.
     * The prefix length used to construct indicates the network and host portion of this address.
     * The prefix length returned here indicates the whether the value of this address can be used as a mask for the network and host
     * portion of any other address.  Therefore the two values can be different values, or one can be null while the other is not.
     * 
     * This method applies only to the lower value of the range if this section represents multiple values.
     * 
     * @param {boolean} network whether to check for a network mask or a host mask
     * @return {number} the prefix length corresponding to this mask, or null if there is no such prefix length
     */
    public getBlockMaskPrefixLength(network : boolean) : number {
        let prefixLen : number;
        if(network) {
            if(this.hasNoPrefixCache() || (prefixLen = this.prefixCache.networkMaskPrefixLen) == null) {
                prefixLen = this.setNetworkMaskPrefix(this.checkForPrefixMask(network));
            }
        } else {
            if(this.hasNoPrefixCache() || (prefixLen = this.prefixCache.hostMaskPrefixLen) == null) {
                prefixLen = this.setHostMaskPrefix(this.checkForPrefixMask(network));
            }
        }
        if(prefixLen < 0) {
            return null;
        }
        return prefixLen;
    }

    setHostMaskPrefix(prefixLen : number) : number {
        if(prefixLen == null) {
            prefixLen = this.prefixCache.hostMaskPrefixLen = AddressDivisionGrouping.NO_PREFIX_LENGTH;
        } else {
            this.prefixCache.hostMaskPrefixLen = prefixLen;
            this.prefixCache.networkMaskPrefixLen = AddressDivisionGrouping.NO_PREFIX_LENGTH;
        }
        return prefixLen;
    }

    setNetworkMaskPrefix(prefixLen : number) : number {
        if(prefixLen == null) {
            prefixLen = this.prefixCache.networkMaskPrefixLen = AddressDivisionGrouping.NO_PREFIX_LENGTH;
        } else {
            this.prefixCache.networkMaskPrefixLen = prefixLen;
            this.prefixCache.hostMaskPrefixLen = AddressDivisionGrouping.NO_PREFIX_LENGTH;
        }
        return prefixLen;
    }

    static getNetworkSection<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(original : R, networkPrefixLength : number, withPrefixLength : boolean, creator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p1: number, p2: number) => S) : R {
        if(networkPrefixLength < 0 || networkPrefixLength > original.getBitCount()) {
            throw new PrefixLenException(original, networkPrefixLength);
        }
        if(original.isNetworkSection(networkPrefixLength, withPrefixLength)) {
            return original;
        }
        let bitsPerSegment : number = original.getBitsPerSegment();
        let networkSegmentCount : number = original.getNetworkSegmentCount$int(networkPrefixLength);
        let result : S[] = creator.createSegmentArray(networkSegmentCount);
        for(let i : number = 0; i < networkSegmentCount; i++) {
            let prefix : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
            result[i] = (target => (typeof target === 'function')?target(i, prefix):(<any>target).apply(i, prefix))(segProducer);
        };
        return creator.createSectionInternal$inet_ipaddr_IPAddressSegment_A(result);
    }

    public getNetworkSegmentCount$() : number {
        if(this.isPrefixed()) {
            return this.getNetworkSegmentCount$int(this.getNetworkPrefixLength());
        }
        return null;
    }

    public getNetworkSegmentCount$int(networkPrefixLength : number) : number {
        return IPAddressSection.getNetworkSegmentIndex(networkPrefixLength, this.getBytesPerSegment(), this.getBitsPerSegment()) + 1;
    }

    public getNetworkSegmentCount(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getNetworkSegmentCount$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getNetworkSegmentCount$();
        } else throw new Error('invalid overload');
    }

    static getHostSection<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(original : R, networkPrefixLength : number, hostSegmentCount : number, creator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p1: number, p2: number) => S) : R {
        if(networkPrefixLength < 0 || networkPrefixLength > original.getBitCount()) {
            throw new PrefixLenException(original, networkPrefixLength);
        }
        if(original.isHostSection(networkPrefixLength)) {
            return original;
        }
        let segmentCount : number = original.getSegmentCount();
        let result : S[] = creator.createSegmentArray(hostSegmentCount);
        if(hostSegmentCount > 0) {
            let bitsPerSegment : number = original.getBitsPerSegment();
            for(let i : number = hostSegmentCount - 1, j : number = segmentCount - 1; i >= 0; i--, j--) {
                let prefix : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, j);
                result[i] = (target => (typeof target === 'function')?target(j, prefix):(<any>target).apply(j, prefix))(segProducer);
            };
        }
        return creator.createSectionInternal$inet_ipaddr_IPAddressSegment_A(result);
    }

    public getHostSegmentCount$int(networkPrefixLength : number) : number {
        return this.getSegmentCount() - IPAddressSection.getHostSegmentIndex(networkPrefixLength, this.getBytesPerSegment(), this.getBitsPerSegment());
    }

    public getHostSegmentCount(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostSegmentCount$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostSegmentCount$();
        } else throw new Error('invalid overload');
    }

    public getHostSegmentCount$() : number {
        if(this.isPrefixed()) {
            return this.getHostSegmentCount$int(this.getNetworkPrefixLength());
        }
        return null;
    }

    public getHostBitCount$() : number {
        if(this.isPrefixed()) {
            return this.getHostBitCount$int(this.getNetworkPrefixLength());
        }
        return null;
    }

    public getHostBitCount$int(networkPrefixLength : number) : number {
        return this.getBitCount() - networkPrefixLength;
    }

    public getHostBitCount(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostBitCount$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostBitCount$();
        } else throw new Error('invalid overload');
    }

    static setPrefixLength<R extends IPAddressSection, S extends IPAddressSegment>(original : R, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, networkPrefixLength : number, withZeros : boolean, noShrink : boolean, segProducer : IPAddressSection.__inet_ipaddr_IPAddressSection_SegFunction<R, S>) : R {
        let existingPrefixLength : number = original.getNetworkPrefixLength();
        if(existingPrefixLength != null) {
            if(networkPrefixLength === existingPrefixLength) {
                return original;
            } else if(noShrink && networkPrefixLength > existingPrefixLength) {
                original.checkSubnet(networkPrefixLength);
                return original;
            }
        }
        original.checkSubnet(networkPrefixLength);
        let network : IPAddressNetwork<any, R, any, S, any> = creator.getNetwork();
        let maskBits : number;
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            if(existingPrefixLength != null) {
                if(networkPrefixLength > existingPrefixLength) {
                    if(withZeros) {
                        maskBits = existingPrefixLength;
                    } else {
                        maskBits = networkPrefixLength;
                    }
                } else if(networkPrefixLength < existingPrefixLength) {
                    maskBits = networkPrefixLength;
                } else {
                    return original;
                }
            } else {
                maskBits = networkPrefixLength;
            }
        } else {
            if(existingPrefixLength != null) {
                if(networkPrefixLength === existingPrefixLength) {
                    return original;
                }
                if(withZeros) {
                    let leftMask : R;
                    let rightMask : R;
                    if(networkPrefixLength > existingPrefixLength) {
                        leftMask = network.getNetworkMaskSection(existingPrefixLength);
                        rightMask = network.getHostMaskSection(networkPrefixLength);
                    } else {
                        leftMask = network.getNetworkMaskSection(networkPrefixLength);
                        rightMask = network.getHostMaskSection(existingPrefixLength);
                    }
                    return <any>(IPAddressSection.getSubnetSegments<any, any>(original, networkPrefixLength, creator, true, (i) => segProducer(original, i), ((leftMask,rightMask) => {
                        return (i) => {
                            let val1 : number = segProducer(leftMask, i).getLowerSegmentValue();
                            let val2 : number = segProducer(rightMask, i).getLowerSegmentValue();
                            return val1 | val2;
                        }
                    })(leftMask,rightMask), false));
                }
            }
            maskBits = original.getBitCount();
        }
        let mask : R = network.getNetworkMaskSection(maskBits);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(original, networkPrefixLength, creator, true, (i) => segProducer(original, i), ((mask) => {
            return (i) => segProducer(mask, i).getLowerSegmentValue()
        })(mask), false));
    }

    static getSubnetSegments<R extends IPAddressSection, S extends IPAddressSegment>(original : R, networkPrefixLength : number, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, verifyMask : boolean, segProducer : (p0 : number) => S, segmentMaskProducer : any, singleOnly : boolean) : R {
        if(networkPrefixLength != null && (networkPrefixLength < 0 || networkPrefixLength > original.getBitCount())) {
            throw new PrefixLenException(original, networkPrefixLength);
        }
        let bitsPerSegment : number = original.getBitsPerSegment();
        let count : number = original.getSegmentCount();
        for(let i : number = 0; i < count; i++) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
            let seg : S = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            let maskValue : number = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentMaskProducer);
            if(seg.isChangedByMask(maskValue, segmentPrefixLength)) {
                if(verifyMask && !seg.isMaskCompatibleWithRange$int$java_lang_Integer(maskValue, segmentPrefixLength)) {
                    throw new IncompatibleAddressException(seg, "ipaddress.error.maskMismatch");
                }
                let newSegments : S[] = creator.createSegmentArray(original.getSegmentCount());
                original.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, i, newSegments, 0);
                newSegments[i] = creator.createSegment$int$int$java_lang_Integer(seg.getLowerSegmentValue() & maskValue, seg.getUpperSegmentValue() & maskValue, segmentPrefixLength);
                let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][original.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && !singleOnly;
                if(isAllSubnets && segmentPrefixLength != null) {
                    if(++i < count) {
                        let zeroSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, i, count, zeroSeg);
                    }
                } else for(i++; i < count; i++) {
                    segmentPrefixLength = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
                    seg = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
                    maskValue = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentMaskProducer);
                    if(seg.isChangedByMask(maskValue, segmentPrefixLength)) {
                        if(verifyMask && !seg.isMaskCompatibleWithRange$int$java_lang_Integer(maskValue, segmentPrefixLength)) {
                            throw new IncompatibleAddressException(seg, "ipaddress.error.maskMismatch");
                        }
                        newSegments[i] = creator.createSegment$int$int$java_lang_Integer(seg.getLowerSegmentValue() & maskValue, seg.getUpperSegmentValue() & maskValue, segmentPrefixLength);
                    } else {
                        newSegments[i] = seg;
                    }
                    if(isAllSubnets && segmentPrefixLength != null) {
                        if(++i < count) {
                            let zeroSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, i, count, zeroSeg);
                        }
                        break;
                    }
                };
                return creator.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(newSegments, networkPrefixLength, singleOnly);
            }
        };
        return original;
    }

    static getOredSegments<R extends IPAddressSection, S extends IPAddressSegment>(original : R, networkPrefixLength : number, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, verifyMask : boolean, segProducer : (p0 : number) => S, segmentMaskProducer : any) : R {
        if(networkPrefixLength != null && (networkPrefixLength < 0 || networkPrefixLength > original.getBitCount())) {
            throw new PrefixLenException(original, networkPrefixLength);
        }
        let bitsPerSegment : number = original.getBitsPerSegment();
        let count : number = original.getSegmentCount();
        for(let i : number = 0; i < count; i++) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
            let seg : S = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            let maskValue : number = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentMaskProducer);
            if(seg.isChangedByOr(maskValue, segmentPrefixLength)) {
                if(verifyMask && !seg.isBitwiseOrCompatibleWithRange$int$java_lang_Integer(maskValue, segmentPrefixLength)) {
                    throw new IncompatibleAddressException(seg, "ipaddress.error.maskMismatch");
                }
                let newSegments : S[] = creator.createSegmentArray(original.getSegmentCount());
                original.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, i, newSegments, 0);
                newSegments[i] = creator.createSegment$int$int$java_lang_Integer(seg.getLowerSegmentValue() | maskValue, seg.getUpperSegmentValue() | maskValue, segmentPrefixLength);
                let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][original.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
                if(isAllSubnets && segmentPrefixLength != null) {
                    if(++i < count) {
                        let zeroSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, i, count, zeroSeg);
                    }
                } else for(i++; i < count; i++) {
                    segmentPrefixLength = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
                    seg = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
                    maskValue = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentMaskProducer);
                    if(seg.isChangedByOr(maskValue, segmentPrefixLength)) {
                        if(verifyMask && !seg.isBitwiseOrCompatibleWithRange$int$java_lang_Integer(maskValue, segmentPrefixLength)) {
                            throw new IncompatibleAddressException(seg, "ipaddress.error.maskMismatch");
                        }
                        newSegments[i] = creator.createSegment$int$int$java_lang_Integer(seg.getLowerSegmentValue() | maskValue, seg.getUpperSegmentValue() | maskValue, segmentPrefixLength);
                    } else {
                        newSegments[i] = seg;
                    }
                    if(isAllSubnets && segmentPrefixLength != null) {
                        if(++i < count) {
                            let zeroSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(newSegments, i, count, zeroSeg);
                        }
                        break;
                    }
                };
                return creator.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(newSegments, networkPrefixLength);
            }
        };
        return original;
    }

    static getSplitSegmentPrefixLength(bitsPerSegment : number, networkPrefixLength : number, segmentIndex : number) : number {
        if(networkPrefixLength != null) {
            return AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, networkPrefixLength, segmentIndex);
        }
        return null;
    }

    public static getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment : number, prefixLength : number, segmentIndex : number) : number {
        return AddressDivisionGrouping.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
    }

    /**
     * Across the address prefixes are:
     * IPv6: (null):...:(null):(1 to 16):(0):...:(0)
     * or IPv4: ...(null).(1 to 8).(0)...
     * @param {number} bitsPerSegment
     * @param {number} prefixLength
     * @param {number} segmentIndex
     * @return {number}
     */
    public static getSegmentPrefixLength(bitsPerSegment? : any, prefixLength? : any, segmentIndex? : any) : any {
        if(((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentIndex === 'number') || segmentIndex === null)) {
            return <any>IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
        } else if(((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof prefixLength === 'number') || prefixLength === null) && segmentIndex === undefined) {
            return <any>IPAddressSection.getSegmentPrefixLength$int$int(bitsPerSegment, prefixLength);
        } else throw new Error('invalid overload');
    }

    static getSegmentPrefixLength$int$int(bitsPerSegment : number, segmentPrefixedBits : number) : number {
        return AddressDivisionGrouping.getSegmentPrefixLength$int$int(bitsPerSegment, segmentPrefixedBits);
    }

    static getLowestOrHighestSection<R extends IPAddressSection, S extends IPAddressSegment>(section : R, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, nonZeroHostIteratorSupplier : () => any, segProducer : (p0 : number) => S, lowest : boolean, excludeZeroHost : boolean) : R {
        let create : boolean = true;
        let result : R = null;
        let segs : S[] = null;
        if(lowest && excludeZeroHost && section.includesZeroHost()) {
            let it : any = (target => (typeof target === 'function')?target():(<any>target).get())(nonZeroHostIteratorSupplier);
            if(!it.hasNext()) {
                create = false;
            } else {
                segs = it.next();
            }
        } else {
            segs = AddressDivisionGrouping.createSingle<any, any>(section, creator, <any>(segProducer));
        }
        if(create) {
            let prefLength : number;
            result = AddressNetwork.PrefixConfiguration["_$wrappers"][section.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() || (prefLength = section.getNetworkPrefixLength()) == null?creator.createSectionInternal$inet_ipaddr_IPAddressSegment_A(segs):creator.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segs, prefLength, true);
        }
        return result;
    }

    /**
     * 
     * @return {number}
     */
    public getSegmentCount() : number {
        return this.getDivisionCount();
    }

    /**
     * 
     * @param {number} index
     * @return {IPAddressSegment}
     */
    public getSegment(index : number) : IPAddressSegment {
        return this.getSegmentsInternal()[index];
    }

    /**
     * 
     * @param {number} index
     * @return {IPAddressSegment}
     */
    public getDivision(index : number) : IPAddressSegment {
        return this.getSegmentsInternal()[index];
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {boolean}
     */
    public containsPrefixBlock(prefixLength : number) : boolean {
        this.checkSubnet(prefixLength);
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        if(isAllSubnets && this.isPrefixed() && this.getNetworkPrefixLength() <= prefixLength) {
            return true;
        }
        let divCount : number = this.getDivisionCount();
        let bitsPerSegment : number = this.getBitsPerSegment();
        let i : number = IPAddressSection.getHostSegmentIndex(prefixLength, this.getBytesPerSegment(), bitsPerSegment);
        if(i < divCount) {
            let div : IPAddressDivision = this.getDivision(i);
            let segmentPrefixLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, prefixLength, i);
            if(!div.isPrefixBlock$int(segmentPrefixLength)) {
                return false;
            }
            if(isAllSubnets && div.isPrefixed()) {
                return true;
            }
            for(++i; i < divCount; i++) {
                div = this.getDivision(i);
                if(!div.isFullRange()) {
                    return false;
                }
                if(isAllSubnets && div.isPrefixed()) {
                    return true;
                }
            };
        }
        return true;
    }

    /**
     * @param {*} other
     * @return {boolean} whether this subnet contains the given address section
     */
    public contains(other : AddressSection) : boolean {
        if(this.getSegmentCount() !== other.getSegmentCount()) {
            return false;
        }
        let prefixIsSubnet : boolean = this.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        for(let i : number = 0; i < this.getSegmentCount(); i++) {
            let seg : IPAddressSegment = this.getSegment(i);
            if(!seg['contains$inet_ipaddr_AddressSegment'](other.getSegment(i))) {
                return false;
            }
            if(prefixIsSubnet && seg.isPrefixed()) {
                break;
            }
        };
        return true;
    }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        let divCount : number = this.getDivisionCount();
        let allPrefixedAddressesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        if(allPrefixedAddressesAreSubnets) {
            for(let i : number = 0; i < divCount; i++) {
                let div : IPAddressSegment = this.getSegment(i);
                if(!div.isFullRange()) {
                    return false;
                }
                let prefix : number = div.getSegmentPrefixLength();
                if(prefix != null) {
                    break;
                }
            };
        } else for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            if(!div.isFullRange()) {
                return false;
            }
        };
        return true;
    }

    static intersect<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(first : R, other : R, addrCreator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p0 : number) => S, otherSegProducer : (p0 : number) => S) : R {
        first.checkSectionCount(other);
        let pref : number = first.getNetworkPrefixLength();
        let otherPref : number = other.getNetworkPrefixLength();
        if(pref != null) {
            if(otherPref != null) {
                pref = Math.max(pref, otherPref);
            } else {
                pref = null;
            }
        }
        if(other.contains(first)) {
            if(Objects.equals(pref, first.getNetworkPrefixLength())) {
                return first;
            }
        } else if(!first.isMultiple()) {
            return null;
        }
        if(first.contains(other)) {
            if(Objects.equals(pref, other.getNetworkPrefixLength())) {
                return other;
            }
        } else if(!other.isMultiple()) {
            return null;
        }
        let segCount : number = first.getSegmentCount();
        for(let i : number = 0; i < segCount; i++) {
            let seg : IPAddressSegment = first.getSegment(i);
            let otherSeg : IPAddressSegment = other.getSegment(i);
            let lower : number = seg.getLowerSegmentValue();
            let higher : number = seg.getUpperSegmentValue();
            let otherLower : number = otherSeg.getLowerSegmentValue();
            let otherHigher : number = otherSeg.getUpperSegmentValue();
            if(otherLower > higher || lower > otherHigher) {
                return null;
            }
        };
        let segs : S[] = addrCreator.createSegmentArray(segCount);
        for(let i : number = 0; i < segCount; i++) {
            let seg : S = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            let otherSeg : S = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(otherSegProducer);
            let segPref : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(seg.getBitCount(), pref, i);
            if(seg['contains$inet_ipaddr_AddressSegment'](otherSeg)) {
                if(!otherSeg.isChangedByPrefix(segPref, false)) {
                    segs[i] = otherSeg;
                    continue;
                }
            }
            if(otherSeg['contains$inet_ipaddr_AddressSegment'](seg)) {
                if(!seg.isChangedByPrefix(segPref, false)) {
                    segs[i] = seg;
                    continue;
                }
            }
            let lower : number = seg.getLowerSegmentValue();
            let higher : number = seg.getUpperSegmentValue();
            let otherLower : number = otherSeg.getLowerSegmentValue();
            let otherHigher : number = otherSeg.getUpperSegmentValue();
            let newLower : number = Math.max(lower, otherLower);
            let newHigher : number = Math.min(higher, otherHigher);
            segs[i] = addrCreator.createSegment$int$int$java_lang_Integer(newLower, newHigher, segPref);
        };
        let result : R = addrCreator.createSection$inet_ipaddr_IPAddressSegment_A(segs);
        return result;
    }

    /**
     * Returns the smallest set of prefix blocks that spans both this and the supplied address or subnet.
     * @param {IPAddressSection} other
     * @return
     * @param {IPAddressSection} first
     * @param {*} getLower
     * @param {*} getUpper
     * @param {*} comparator
     * @param {*} prefixRemover
     * @param {*} arrayProducer
     * @return {Array}
     */
    static getSpanningPrefixBlocks<R extends IPAddressSection>(first : R, other : R, getLower : (p1: R) => R, getUpper : (p1: R) => R, comparator : any, prefixRemover : (p1: R) => R, arrayProducer : (p0 : number) => R[]) : R[] {
        first.checkSectionCount(other);
        let f : boolean;
        if((f = first.contains(other)) || other.contains(first)) {
            if(!f) {
                let tmp : R = first;
                first = other;
                other = tmp;
            }
            let result : R[] = (target => (typeof target === 'function')?target(1):(<any>target).apply(1))(arrayProducer);
            if(first.isPrefixed() && first.getPrefixLength() >= first.getBitCount()) {
                first = (target => (typeof target === 'function')?target(first):(<any>target).apply(first))(prefixRemover);
            }
            result[0] = first;
            return result;
        }
        let blocks : Array<IPAddressSegmentSeries> = <any>([]);
        IPAddressSection.getSpanningSeriesPrefixBlocks<any>(first, other, <any>(getLower), <any>(getUpper), <any>(comparator), <any>(prefixRemover), blocks);
        let result : R[] = /* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })((target => (typeof target === 'function')?target(/* size */(<number>blocks.length)):(<any>target).apply(/* size */(<number>blocks.length)))(arrayProducer), blocks);
        return result;
    }

    static getSpanningSeriesPrefixBlocks<R extends IPAddressSegmentSeries>(first : R, other : R, getLower : (p1: R) => R, getUpper : (p1: R) => R, comparator : any, prefixRemover : (p1: R) => R, blocks : Array<IPAddressSegmentSeries>) {
        let firstLower : R = (target => (typeof target === 'function')?target(first):(<any>target).apply(first))(getLower);
        let otherLower : R = (target => (typeof target === 'function')?target(other):(<any>target).apply(other))(getLower);
        let firstUpper : R = (target => (typeof target === 'function')?target(first):(<any>target).apply(first))(getUpper);
        let otherUpper : R = (target => (typeof target === 'function')?target(other):(<any>target).apply(other))(getUpper);
        let lower : R = comparator(firstLower, otherLower) > 0?otherLower:firstLower;
        let upper : R = comparator(firstUpper, otherUpper) < 0?otherUpper:firstUpper;
        lower = (target => (typeof target === 'function')?target(lower):(<any>target).apply(lower))(prefixRemover);
        upper = (target => (typeof target === 'function')?target(upper):(<any>target).apply(upper))(prefixRemover);
        IPAddressSection.splitRange(lower, upper, 0, 0, blocks);
    }

    static splitRange(lower : IPAddressSegmentSeries, upper : IPAddressSegmentSeries, previousSegmentBits : number, currentSegment : number, blocks : Array<IPAddressSegmentSeries>) {
        let differing : number = 0;
        let segCount : number = lower.getSegmentCount();
        let bitsPerSegment : number = lower.getBitsPerSegment();
        for(; currentSegment < segCount; currentSegment++) {
            let lowerSeg : IPAddressSegment = lower.getSegment(currentSegment);
            let upperSeg : IPAddressSegment = upper.getSegment(currentSegment);
            let lowerValue : number = lowerSeg.getLowerSegmentValue();
            let upperValue : number = upperSeg.getLowerSegmentValue();
            differing = lowerValue ^ upperValue;
            if(differing !== 0) {
                break;
            }
            previousSegmentBits += bitsPerSegment;
        };
        if(differing === 0) {
            /* add */(blocks.push(lower)>0);
            return;
        }
        let differingIsLowestBit : boolean = (differing === 1);
        if(differingIsLowestBit && currentSegment + 1 === segCount) {
            /* add */(blocks.push(lower['toPrefixBlock$int'](lower.getBitCount() - 1))>0);
            return;
        }
        let highestDifferingBitInRange : number = javaemul.internal.LongHelper.numberOfLeadingZeros(differing) - (javaemul.internal.LongHelper.SIZE - bitsPerSegment);
        let differingBitPrefixLen : number = highestDifferingBitInRange + previousSegmentBits;
        if(lower['includesZeroHost$int'](differingBitPrefixLen) && upper['includesMaxHost$int'](differingBitPrefixLen)) {
            /* add */(blocks.push(lower['toPrefixBlock$int'](differingBitPrefixLen))>0);
            return;
        }
        let lowerTop : IPAddressSegmentSeries = upper['toZeroHost$int'](differingBitPrefixLen + 1);
        let upperBottom : IPAddressSegmentSeries = lowerTop.increment(-1);
        if(differingIsLowestBit) {
            previousSegmentBits += bitsPerSegment;
            currentSegment++;
        }
        IPAddressSection.splitRange(lower, upperBottom, previousSegmentBits, currentSegment, blocks);
        IPAddressSection.splitRange(lowerTop, upper, previousSegmentBits, currentSegment, blocks);
    }

    static getMergedBlocks(first : IPAddressSegmentSeries, sections : IPAddressSegmentSeries[], checkSize : boolean) : Array<IPAddressSegmentSeries> {
        let bitCount : number = first.getBitCount();
        let bitsPerSegment : number = first.getBitsPerSegment();
        let bytesPerSegment : number = first.getBytesPerSegment();
        if(first.isMultiple()) {
            let block : IPAddressSegmentSeries = first.assignMinPrefixForBlock();
            if(block.getPrefixLength() < bitCount) {
                first = block;
            }
        } else {
            first = first['removePrefixLength$boolean'](false);
        }
        let firstSectionCount : number = first.getSegmentCount();
        for(let i : number = 0; i < sections.length; i++) {
            let section : IPAddressSegmentSeries = sections[i];
            if(checkSize && section.getSegmentCount() !== firstSectionCount) {
                throw new SizeMismatchException(first, section);
            }
            if(section.isMultiple()) {
                let block : IPAddressSegmentSeries = section.assignMinPrefixForBlock();
                if(block.getPrefixLength() < bitCount) {
                    sections[i] = block;
                }
            } else {
                sections[i] = section['removePrefixLength$boolean'](false);
            }
        };
        let valueComparator : AddressComparator.ValueComparator = new AddressComparator.ValueComparator(false);
        /* sort */((l,c) => { if((<any>c).compare) l.sort((e1,e2)=>(<any>c).compare(e1,e2)); else l.sort(<any>c); })(sections,((valueComparator) => {
            return (o1, o2) => {
                let prefix1 : number = o1.getPrefixLength();
                let prefix2 : number = o2.getPrefixLength();
                let compare : number = (prefix1 === prefix2)?0:((prefix1 == null)?-1:((prefix2 == null)?1:prefix2.compareTo(prefix1)));
                if(compare === 0) {
                    compare = valueComparator.compareSegmentLowValues(o1, o2);
                }
                return compare;
            }
        })(valueComparator));
        let list : Array<IPAddressSegmentSeries> = <any>([]);
        let firstPrefixLength : number = first.getPrefixLength();
        let addedFirst : boolean;
        if(firstPrefixLength == null) {
            addedFirst = true;
            /* add */(list.push(first)>0);
        } else if(firstPrefixLength >= bitCount) {
            addedFirst = true;
            /* add */(list.push(first.removePrefixLength())>0);
        } else {
            addedFirst = false;
        }
        for(let i : number = 0; i < sections.length; i++) {
            let section : IPAddressSegmentSeries = sections[i];
            let sectionPrefixLength : number = section.getNetworkPrefixLength();
            if(sectionPrefixLength == null) {
                /* add */(list.push(section)>0);
            } else if(sectionPrefixLength >= bitCount) {
                /* add */(list.push(section.removePrefixLength())>0);
            } else {
                if(!addedFirst && firstPrefixLength > sectionPrefixLength) {
                    addedFirst = true;
                    let iterator : any = first.prefixBlockIterator();
                    iterator.forEachRemaining((arg0) => { return list.add(arg0) });
                }
                let iterator : any = section.prefixBlockIterator();
                iterator.forEachRemaining((arg0) => { return list.add(arg0) });
            }
        };
        if(!addedFirst) {
            addedFirst = true;
            let iterator : any = first.prefixBlockIterator();
            iterator.forEachRemaining((arg0) => { return list.add(arg0) });
        }
        for(let i : number = 0; i < /* size */(<number>list.length); ) {
            let item : IPAddressSegmentSeries = /* get */list[i];
            let prefixLen : number = item.getPrefixLength();
            let bitToCheck : number = (prefixLen == null)?bitCount - 1:prefixLen - 1;
            top: for(let j : number = i + 1; ; j++) {
                if(j === /* size */(<number>list.length)) {
                    i++;
                    break;
                }
                let otherItem : IPAddressSegmentSeries = /* get */list[j];
                let otherPrefixLen : number = otherItem.getPrefixLength();
                let checkLastBit : boolean = otherPrefixLen == null || otherPrefixLen >= bitCount || (prefixLen != null && otherPrefixLen >= prefixLen);
                let matchBitIndex : number = checkLastBit?bitToCheck:otherPrefixLen;
                let lastMatchSegmentIndex : number = IPAddressSection.getNetworkSegmentIndex(matchBitIndex, bytesPerSegment, bitsPerSegment);
                let lastBitSegmentIndex : number = IPAddressSection.getHostSegmentIndex(matchBitIndex, bytesPerSegment, bitsPerSegment);
                let itemSegment : IPAddressSegment = item.getSegment(lastMatchSegmentIndex);
                let otherItemSegment : IPAddressSegment = otherItem.getSegment(lastMatchSegmentIndex);
                let itemSegmentValue : number = itemSegment.getLowerSegmentValue();
                let otherItemSegmentValue : number = otherItemSegment.getLowerSegmentValue();
                if(checkLastBit) {
                    let segmentLastBitIndex : number = bitsPerSegment - 1;
                    if(lastBitSegmentIndex === lastMatchSegmentIndex) {
                        let segmentBitToCheck : number = bitToCheck % bitsPerSegment;
                        let shift : number = segmentLastBitIndex - segmentBitToCheck;
                        itemSegmentValue >>>= shift;
                        otherItemSegmentValue >>>= shift;
                    } else {
                        let itemBitValue : number = item.getSegment(lastBitSegmentIndex).getLowerSegmentValue();
                        let otherItemBitalue : number = otherItem.getSegment(lastBitSegmentIndex).getLowerSegmentValue();
                        itemSegmentValue = (itemSegmentValue << 1) | (itemBitValue >>> segmentLastBitIndex);
                        otherItemSegmentValue = (otherItemSegmentValue << 1) | (otherItemBitalue >>> segmentLastBitIndex);
                    }
                    if(itemSegmentValue === otherItemSegmentValue) {
                        checkLastBit = false;
                    } else {
                        itemSegmentValue ^= 1;
                        if(itemSegmentValue !== otherItemSegmentValue) {
                            continue;
                        }
                    }
                } else {
                    let otherSegmentPrefixLen : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(otherItem.getBitsPerSegment(), otherPrefixLen, lastMatchSegmentIndex);
                    let shift : number = bitsPerSegment - otherSegmentPrefixLen;
                    itemSegmentValue >>>= shift;
                    otherItemSegmentValue >>>= shift;
                    if(itemSegmentValue !== otherItemSegmentValue) {
                        continue;
                    }
                }
                for(let k : number = lastMatchSegmentIndex - 1; k >= 0; k--) {
                    itemSegment = item.getSegment(k);
                    otherItemSegment = otherItem.getSegment(k);
                    let val : number = itemSegment.getLowerSegmentValue();
                    let otherVal : number = otherItemSegment.getLowerSegmentValue();
                    if(val !== otherVal) {
                        continue top;
                    }
                };
                if(checkLastBit) {
                    let joinedItem : IPAddressSegmentSeries = otherItem['toPrefixBlock$int'](bitToCheck);
                    if(j === /* size */(<number>list.length) - 1) {
                        /* set */(list[j] = joinedItem);
                    } else {
                        let k : number = j + 1;
                        for(; k < /* size */(<number>list.length); k++) {
                            let furtherItem : IPAddressSegmentSeries = /* get */list[k];
                            let furtherPrefixLen : number = furtherItem.getPrefixLength();
                            let compare : number = (furtherPrefixLen == null)?-1:bitToCheck - furtherPrefixLen;
                            if(compare === 0) {
                                compare = valueComparator.compareSegmentLowValues(joinedItem, furtherItem);
                            }
                            if(compare < 0) {
                                /* set */(list[k - 1] = furtherItem);
                            } else {
                                /* set */(list[k - 1] = joinedItem);
                                break;
                            }
                        };
                        if(k === /* size */(<number>list.length)) {
                            /* set */(list[k - 1] = joinedItem);
                        }
                    }
                }
                /* remove */list.splice(i, 1);
                break;
            };
        };
        return list;
    }

    static subtract<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(first : R, other : R, addrCreator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p0 : number) => S, prefixApplier : (p1: R, p2: number) => R) : R[] {
        first.checkSectionCount(other);
        if(!first.isMultiple()) {
            if(other.contains(first)) {
                return null;
            }
            let result : R[] = addrCreator.createSectionArray(1);
            result[0] = first;
            return result;
        }
        let segCount : number = first.getSegmentCount();
        for(let i : number = 0; i < segCount; i++) {
            let seg : IPAddressSegment = first.getSegment(i);
            let otherSeg : IPAddressSegment = other.getSegment(i);
            let lower : number = seg.getLowerSegmentValue();
            let higher : number = seg.getUpperSegmentValue();
            let otherLower : number = otherSeg.getLowerSegmentValue();
            let otherHigher : number = otherSeg.getUpperSegmentValue();
            if(otherLower > higher || lower > otherHigher) {
                let result : R[] = addrCreator.createSectionArray(1);
                result[0] = first;
                return result;
            }
        };
        let intersections : S[] = addrCreator.createSegmentArray(segCount);
        let sections : Array<R> = <any>([]);
        for(let i : number = 0; i < segCount; i++) {
            let seg : S = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            let otherSeg : IPAddressSegment = other.getSegment(i);
            let lower : number = seg.getLowerSegmentValue();
            let higher : number = seg.getUpperSegmentValue();
            let otherLower : number = otherSeg.getLowerSegmentValue();
            let otherHigher : number = otherSeg.getUpperSegmentValue();
            if(lower >= otherLower) {
                if(higher <= otherHigher) {
                    if(seg.isPrefixed()) {
                        intersections[i] = addrCreator.createSegment$int$int$java_lang_Integer(lower, higher, null);
                    } else {
                        intersections[i] = seg;
                    }
                    continue;
                }
                intersections[i] = addrCreator.createSegment$int$int$java_lang_Integer(lower, otherHigher, null);
                let section : R = <any>(IPAddressSection.createDiffSection<any, any, any>(first, otherHigher + 1, higher, i, addrCreator, <any>(segProducer), intersections));
                /* add */(sections.push(section)>0);
            } else {
                let section : R = <any>(IPAddressSection.createDiffSection<any, any, any>(first, lower, otherLower - 1, i, addrCreator, <any>(segProducer), intersections));
                /* add */(sections.push(section)>0);
                if(higher <= otherHigher) {
                    intersections[i] = addrCreator.createSegment$int$int$java_lang_Integer(otherLower, higher, null);
                } else {
                    intersections[i] = addrCreator.createSegment$int$int$java_lang_Integer(otherLower, otherHigher, null);
                    section = <any>(IPAddressSection.createDiffSection<any, any, any>(first, otherHigher + 1, higher, i, addrCreator, <any>(segProducer), intersections));
                    /* add */(sections.push(section)>0);
                }
            }
        };
        if(first.isPrefixed()) {
            let thisPrefix : number = first.getNetworkPrefixLength();
            for(let i : number = 0; i < /* size */(<number>sections.length); i++) {
                let section : R = /* get */sections[i];
                let bitCount : number = section.getBitCount();
                let totalPrefix : number = bitCount;
                for(let j : number = first.getSegmentCount() - 1; j >= 0; j--) {
                    let seg : IPAddressSegment = section.getSegment(j);
                    let segBitCount : number = seg.getBitCount();
                    let segPrefix : number = seg.getMinPrefixLengthForBlock();
                    if(segPrefix === segBitCount) {
                        break;
                    } else {
                        totalPrefix -= segBitCount;
                        if(segPrefix !== 0) {
                            totalPrefix += segPrefix;
                            break;
                        }
                    }
                };
                if(totalPrefix !== bitCount) {
                    if(totalPrefix < thisPrefix) {
                        totalPrefix = thisPrefix;
                    }
                    section = (target => (typeof target === 'function')?target(section, totalPrefix):(<any>target).apply(section, totalPrefix))(prefixApplier);
                    /* set */(sections[i] = section);
                }
            };
        }
        if(/* size */(<number>sections.length) === 0) {
            return null;
        }
        let result : R[] = addrCreator.createSectionArray(/* size */(<number>sections.length));
        /* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })(result, sections);
        return result;
    }

    static createDiffSection<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(original : R, lower : number, upper : number, diffIndex : number, addrCreator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p0 : number) => S, intersectingValues : S[]) : R {
        let segCount : number = original.getSegmentCount();
        let segments : S[] = addrCreator.createSegmentArray(segCount);
        for(let j : number = 0; j < diffIndex; j++) {
            segments[j] = intersectingValues[j];
        };
        let diff : S = addrCreator.createSegment$int$int$java_lang_Integer(lower, upper, null);
        segments[diffIndex] = diff;
        for(let j : number = diffIndex + 1; j < segCount; j++) {
            segments[j] = (target => (typeof target === 'function')?target(j):(<any>target).apply(j))(segProducer);
        };
        let section : R = addrCreator.createSectionInternal$inet_ipaddr_IPAddressSegment_A(segments);
        return section;
    }

    public toZeroHost$() : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toZeroHost$int(prefixLength : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPAddressSection}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toMaxHost$int(prefixLength : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPAddressSection}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddressSection}
     */
    public abstract applyPrefixLength(networkPrefixLength : number) : IPAddressSection;

    checkSectionCount(sec : IPAddressSection) {
        if(sec.getSegmentCount() !== this.getSegmentCount()) {
            throw new SizeMismatchException(this, sec);
        }
    }

    checkMaskSectionCount(mask : IPAddressSection) {
        if(mask.getSegmentCount() < this.getSegmentCount()) {
            throw new SizeMismatchException(this, mask);
        }
    }

    public toPrefixBlock$() : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toPrefixBlock$int(networkPrefixLength : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddressSection}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * Returns the equivalent CIDR address section with a prefix length for which the subnet block for that prefix matches the range of values in this section.
     * <p>
     * If no such prefix length exists, returns null.
     * <p>
     * If this address represents just a single address, "this" is returned.
     * 
     * @return
     * @return {IPAddressSection}
     */
    public assignPrefixForSingleBlock() : IPAddressSection {
        if(!this.isMultiple()) {
            return this;
        }
        let newPrefix : number = this.getPrefixLengthForSingleBlock();
        return newPrefix == null?null:this.setPrefixLength$int$boolean(newPrefix, false);
    }

    /**
     * Constructs an equivalent address section with the smallest CIDR prefix possible (largest network),
     * such that the range of values are a set of subnet blocks for that prefix.
     * 
     * @return
     * @return {IPAddressSection}
     */
    public assignMinPrefixForBlock() : IPAddressSection {
        return this.setPrefixLength$int$boolean(this.getMinPrefixLengthForBlock(), false);
    }

    public includesZeroHost$() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null || networkPrefixLength >= this.getBitCount()) {
            return false;
        }
        return this.includesZeroHost$int(networkPrefixLength);
    }

    public includesZeroHost$int(networkPrefixLength : number) : boolean {
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && this.isPrefixed() && this.getNetworkPrefixLength() <= networkPrefixLength) {
            return true;
        }
        let bitsPerSegment : number = this.getBitsPerSegment();
        let bytesPerSegment : number = this.getBytesPerSegment();
        let prefixedSegmentIndex : number = IPAddressSection.getHostSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
        let divCount : number = this.getSegmentCount();
        for(let i : number = prefixedSegmentIndex; i < divCount; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            let segmentPrefixLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, networkPrefixLength, i);
            if(segmentPrefixLength != null) {
                let mask : number = div.getSegmentHostMask(segmentPrefixLength);
                if((mask & div.getLowerValue()) !== 0) {
                    return false;
                }
                for(++i; i < divCount; i++) {
                    div = this.getSegment(i);
                    if(!div.includesZero()) {
                        return false;
                    }
                };
            }
        };
        return true;
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {boolean}
     */
    public includesZeroHost(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.includesZeroHost$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.includesZeroHost$();
        } else throw new Error('invalid overload');
    }

    public includesMaxHost$() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null || networkPrefixLength >= this.getBitCount()) {
            return false;
        }
        return this.includesMaxHost$int(networkPrefixLength);
    }

    public includesMaxHost$int(networkPrefixLength : number) : boolean {
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && this.isPrefixed() && this.getNetworkPrefixLength() <= networkPrefixLength) {
            return true;
        }
        let bitsPerSegment : number = this.getBitsPerSegment();
        let bytesPerSegment : number = this.getBytesPerSegment();
        let prefixedSegmentIndex : number = IPAddressSection.getHostSegmentIndex(networkPrefixLength, bytesPerSegment, bitsPerSegment);
        let divCount : number = this.getSegmentCount();
        for(let i : number = prefixedSegmentIndex; i < divCount; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            let segmentPrefixLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, networkPrefixLength, i);
            if(segmentPrefixLength != null) {
                let mask : number = div.getSegmentHostMask(segmentPrefixLength);
                if((mask & div.getUpperSegmentValue()) !== mask) {
                    return false;
                }
                for(++i; i < divCount; i++) {
                    div = this.getSegment(i);
                    if(!div.includesMax()) {
                        return false;
                    }
                };
            }
        };
        return true;
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {boolean}
     */
    public includesMaxHost(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.includesMaxHost$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.includesMaxHost$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {boolean} whether the network portion of the address, the prefix, consists of a single value
     */
    public isSingleNetwork() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null || networkPrefixLength >= this.getBitCount()) {
            return !this.isMultiple();
        }
        let prefixedSegmentIndex : number = IPAddressSection.getNetworkSegmentIndex(networkPrefixLength, this.getBytesPerSegment(), this.getBitsPerSegment());
        if(prefixedSegmentIndex < 0) {
            return true;
        }
        for(let i : number = 0; i < prefixedSegmentIndex; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            if(div.isMultiple()) {
                return false;
            }
        };
        let div : IPAddressSegment = this.getSegment(prefixedSegmentIndex);
        let differing : number = div.getLowerSegmentValue() ^ div.getUpperSegmentValue();
        if(differing === 0) {
            return true;
        }
        let bitsPerSegment : number = div.getBitCount();
        let highestDifferingBitInRange : number = javaemul.internal.IntegerHelper.numberOfLeadingZeros(differing) - (javaemul.internal.IntegerHelper.SIZE - bitsPerSegment);
        return IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, prefixedSegmentIndex) <= highestDifferingBitInRange;
    }

    /**
     * Applies the mask to this address section and then compares values with the given address section
     * 
     * @param {IPAddressSection} mask
     * @param {IPAddressSection} other
     * @return
     * @return {boolean}
     */
    public matchesWithMask(other : IPAddressSection, mask : IPAddressSection) : boolean {
        this.checkMaskSectionCount(mask);
        this.checkSectionCount(other);
        let divCount : number = this.getSegmentCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressSegment = this.getSegment(i);
            let maskSegment : IPAddressSegment = mask.getSegment(i);
            let otherSegment : IPAddressSegment = other.getSegment(i);
            if(!div.matchesWithMask$int$int$int(otherSegment.getLowerSegmentValue(), otherSegment.getUpperSegmentValue(), maskSegment.getLowerSegmentValue())) {
                return false;
            }
        };
        return true;
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPAddressSection}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public removePrefixLength$() : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    static toPrefixBlock<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(original : R, networkPrefixLength : number, creator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segProducer : (p1: number, p2: number) => S) : R {
        if(networkPrefixLength < 0 || networkPrefixLength > original.getBitCount()) {
            throw new PrefixLenException(original, networkPrefixLength);
        }
        if(original.isNetworkSubnet(networkPrefixLength)) {
            return original;
        }
        let bitsPerSegment : number = original.getBitsPerSegment();
        let segmentCount : number = original.getSegmentCount();
        let result : S[] = creator.createSegmentArray(segmentCount);
        for(let i : number = 0; i < segmentCount; i++) {
            let prefix : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, networkPrefixLength, i);
            result[i] = (target => (typeof target === 'function')?target(i, prefix):(<any>target).apply(i, prefix))(segProducer);
        };
        return creator.createSectionInternal$inet_ipaddr_IPAddressSegment_A(result);
    }

    isNetworkSubnet(networkPrefixLength : number) : boolean {
        let segmentCount : number = this.getSegmentCount();
        if(segmentCount === 0) {
            return true;
        }
        let bitsPerSegment : number = this.getBitsPerSegment();
        let prefixedSegmentIndex : number = IPAddressSection.getHostSegmentIndex(networkPrefixLength, this.getBytesPerSegment(), bitsPerSegment);
        let segPrefLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, networkPrefixLength, prefixedSegmentIndex);
        if(this.getSegment(prefixedSegmentIndex).isNetworkChangedByPrefix(segPrefLength, true)) {
            return false;
        }
        if(!AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            for(let i : number = prefixedSegmentIndex + 1; i < segmentCount; i++) {
                if(!this.getSegment(i).isFullRange()) {
                    return false;
                }
            };
        }
        return true;
    }

    static removePrefixLength<R extends IPAddressSection, S extends IPAddressSegment>(original : R, zeroed : boolean, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, segProducer : IPAddressSection.__inet_ipaddr_IPAddressSection_SegFunction<R, S>) : R {
        if(!original.isPrefixed()) {
            return original;
        }
        let network : IPAddressNetwork<any, R, any, S, any> = creator.getNetwork();
        let mask : R = network.getNetworkMaskSection(zeroed?original.getPrefixLength():original.getBitCount());
        return <any>(IPAddressSection.getSubnetSegments<any, any>(original, null, creator, zeroed, (i) => segProducer(original, i), ((mask) => {
            return (i) => segProducer(mask, i).getLowerSegmentValue()
        })(mask), false));
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPAddressSection {
        let prefix : number = this.getAdjustedPrefix$boolean$int$boolean(nextSegment, this.getBitsPerSegment(), false);
        let existing : number = this.getNetworkPrefixLength();
        if(existing == null) {
            if(nextSegment?prefix === this.getBitCount():prefix === 0) {
                return this;
            }
        } else if(existing != null && existing === prefix && prefix !== 0) {
            return this.removePrefixLength$boolean(zeroed);
        }
        return this.setPrefixLength$int$boolean(prefix, zeroed);
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPAddressSection}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixLength$int(adjustment : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPAddressSection}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    static adjustPrefixLength<R extends IPAddressSection, S extends IPAddressSegment>(original : R, adjustment : number, withZeros : boolean, creator : IPAddressNetwork.IPAddressCreator<any, R, any, S, any>, segProducer : IPAddressSection.__inet_ipaddr_IPAddressSection_SegFunction<R, S>) : IPAddressSection {
        if(adjustment === 0) {
            return original;
        }
        let prefix : number = original.getAdjustedPrefix$int$boolean$boolean(adjustment, false, false);
        if(prefix > original.getBitCount()) {
            if(!original.isPrefixed()) {
                return original;
            }
            let network : IPAddressNetwork<any, R, any, S, any> = creator.getNetwork();
            let mask : R = network.getNetworkMaskSection(withZeros?original.getPrefixLength():original.getBitCount());
            return <any>(IPAddressSection.getSubnetSegments<any, any>(original, null, creator, withZeros, (i) => segProducer(original, i), ((mask) => {
                return (i) => segProducer(mask, i).getLowerSegmentValue()
            })(mask), false));
        }
        if(prefix < 0) {
            prefix = 0;
        }
        return original.setPrefixLength$int$boolean(prefix, withZeros);
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    hasNoPrefixCache() : boolean {
        if(this.prefixCache == null) {
            {
                if(this.prefixCache == null) {
                    this.prefixCache = new IPAddressSection.PrefixCache();
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * Returns the smallest CIDR prefix length possible (largest network) for which this includes the block of address sections for that prefix.
     * 
     * @see inet.ipaddr.format.IPAddressDivision#getBlockMaskPrefixLength(boolean)
     * 
     * @return
     * @return {number}
     */
    public getMinPrefixLengthForBlock() : number {
        let result : number;
        if(this.hasNoPrefixCache() || (result = this.prefixCache.cachedMinPrefix) == null) {
            this.prefixCache.cachedMinPrefix = result = super.getMinPrefixLengthForBlock();
        }
        return result;
    }

    /**
     * Returns a prefix length for which the range of this address section matches the the block of addresses for that prefix.
     * <p>
     * If no such prefix exists, returns null
     * <p>
     * If this address section represents a single value, returns the bit length
     * <p>
     * @return {number} the prefix length or null
     */
    public getPrefixLengthForSingleBlock() : number {
        if(!this.hasNoPrefixCache()) {
            let result : number = this.prefixCache.cachedEquivalentPrefix;
            if(result != null) {
                if(result < 0) {
                    return null;
                }
                return result;
            }
        }
        let res : number = super.getPrefixLengthForSingleBlock();
        if(res == null) {
            this.prefixCache.cachedEquivalentPrefix = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            return null;
        }
        return this.prefixCache.cachedEquivalentPrefix = res;
    }

    /**
     * 
     * @return {IPAddressSection}
     */
    public abstract getLowerNonZeroHost() : IPAddressSection;

    /**
     * 
     * @return {IPAddressSection}
     */
    public abstract getLower() : IPAddressSection;

    /**
     * 
     * @return {IPAddressSection}
     */
    public abstract getUpper() : IPAddressSection;

    /**
     * 
     * @return {IPAddressSection}
     */
    public abstract reverseSegments() : IPAddressSection;

    /**
     * 
     * @param {boolean} perByte
     * @return {IPAddressSection}
     */
    public abstract reverseBits(perByte : boolean) : IPAddressSection;

    public reverseBytes(perSegment? : any) : any {
        if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else throw new Error('invalid overload');
    }

    public reverseBytes$() : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @return {IPAddressSection}
     */
    public abstract reverseBytesPerSegment() : IPAddressSection;

    getSegmentsInternal() : IPAddressSegment[] {
        return <IPAddressSegment[]>this.getDivisionsInternal();
    }

    public getSection$int(index : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getSection$int$int(index : number, endIndex : number) : IPAddressSection { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPAddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else throw new Error('invalid overload');
    }

    public getSegments$inet_ipaddr_AddressSegment_A(segs : AddressSegment[]) {
        this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, this.getDivisionCount(), segs, 0);
    }

    public getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start : number, end : number, segs : AddressSegment[], destIndex : number) {
        /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(this.getDivisionsInternal(), start, segs, destIndex, end - start);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} destIndex
     */
    public getSegments(start? : any, end? : any, segs? : any, destIndex? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof destIndex === 'number') || destIndex === null)) {
            return <any>this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(start, end, segs, destIndex);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else throw new Error('invalid overload');
    }

    static createEmbeddedSection<T extends IPAddress, R extends IPAddressSection, S extends IPAddressSegment>(creator : IPAddressNetwork.IPAddressCreator<T, R, any, S, any>, segs : S[], encompassingSection : IPAddressSection) : R {
        return creator.createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_IPAddressSegment_A(encompassingSection, segs);
    }

    /**
     * 
     * @return {*}
     */
    public abstract getIterable() : java.lang.Iterable<any>;

    /**
     * 
     * @return {*}
     */
    public abstract nonZeroHostIterator() : any;

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && ((typeof networkSegmentIndex === 'number') || networkSegmentIndex === null) && ((typeof hostSegmentIndex === 'number') || hostSegmentIndex === null) && ((typeof prefixedSegIteratorProducer === 'function' && (<any>prefixedSegIteratorProducer).length == 1) || prefixedSegIteratorProducer === null)) {
            super.iterator(segmentCreator, segSupplier, segIteratorProducer, excludeFunc, networkSegmentIndex, hostSegmentIndex, prefixedSegIteratorProducer);
        } else if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(segmentCreator, segSupplier, segIteratorProducer, excludeFunc);
        } else if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    public prefixBlockIterator$() : any { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} increment
     * @return {IPAddressSection}
     */
    public abstract increment(increment : number) : IPAddressSection;

    /**
     * 
     * @param {number} increment
     * @return {IPAddressSection}
     */
    public abstract incrementBoundary(increment : number) : IPAddressSection;

    public isEntireAddress() : boolean {
        return this.getSegmentCount() === IPAddress.getSegmentCount(this.getIPVersion());
    }

    isZeroHost<S extends IPAddressSegment>(segments : S[]) : boolean {
        if(segments.length === 0 || !this.isPrefixed()) {
            return false;
        }
        let prefLen : number = this.getNetworkPrefixLength();
        if(prefLen >= this.getBitCount()) {
            return false;
        }
        let bitsPerSegment : number = this.getBitsPerSegment();
        let prefixedSegmentIndex : number = IPAddressSection.getHostSegmentIndex(prefLen, this.getBytesPerSegment(), bitsPerSegment);
        let divCount : number = segments.length;
        for(let i : number = prefixedSegmentIndex; i < divCount; i++) {
            let segmentPrefixLength : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, prefLen, prefixedSegmentIndex);
            let div : S = segments[i];
            if(segmentPrefixLength != null) {
                let mask : number = div.getSegmentHostMask(segmentPrefixLength);
                if((mask & div.getLowerSegmentValue()) !== 0) {
                    return false;
                }
                for(++i; i < divCount; i++) {
                    div = segments[i];
                    if(div.getLowerSegmentValue() !== 0) {
                        return false;
                    }
                };
            }
        };
        return true;
    }

    toInetAddress(address : IPAddress) : InetAddress {
        let result : InetAddress;
        if(this.hasNoValueCache() || (result = this.valueCache.inetAddress) == null) {
            this.valueCache.inetAddress = result = address.toInetAddressImpl(this.getBytes());
        }
        return result;
    }

    toUpperInetAddress(address : IPAddress) : InetAddress {
        let result : InetAddress;
        if(this.hasNoValueCache() || (result = this.valueCache.upperInetAddress) == null) {
            this.valueCache.upperInetAddress = result = address.toInetAddressImpl(this.getUpperBytes());
        }
        return result;
    }

    static checkLengths(length : number, builder : { str: string }) {
        IPAddressDivisionGrouping.IPAddressStringParams.checkLengths(length, builder);
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.toNormalizedString();
    }

    /**
     * 
     * @return {Array}
     */
    public getSegmentStrings() : string[] {
        return this.getDivisionStrings();
    }

    abstract cacheNormalizedString(str : string);

    abstract getStringCache() : IPAddressSection.IPStringCache;

    abstract hasNoStringCache() : boolean;

    public toBinaryString$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().binaryString) == null) {
            let stringCache : IPAddressSection.IPStringCache = this.getStringCache();
            stringCache.binaryString = result = this.toBinaryString$java_lang_CharSequence(null);
        }
        return result;
    }

    public toBinaryString$java_lang_CharSequence(zone : any) : string {
        if(this.isDualString()) {
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(IPAddressSection.toIPParams(IPAddressSection.IPStringCache.binaryParams_$LI$()), this.getLower(), this.getUpper(), zone);
        }
        return IPAddressSection.toIPParams(IPAddressSection.IPStringCache.binaryParams_$LI$()).toString(this, zone);
    }

    public toBinaryString(zone? : any) : any {
        if(((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toBinaryString$java_lang_CharSequence(zone);
        } else if(zone === undefined) {
            return <any>this.toBinaryString$();
        } else throw new Error('invalid overload');
    }

    public toOctalString$boolean(with0Prefix : boolean) : string {
        let result : string;
        if(this.hasNoStringCache() || (result = (with0Prefix?this.getStringCache().octalStringPrefixed:this.getStringCache().octalString)) == null) {
            let stringCache : IPAddressSection.IPStringCache = this.getStringCache();
            result = this.toOctalString$boolean$java_lang_CharSequence(with0Prefix, null);
            if(with0Prefix) {
                stringCache.octalStringPrefixed = result;
            } else {
                stringCache.octalString = result;
            }
        }
        return result;
    }

    public toOctalString$boolean$java_lang_CharSequence(with0Prefix : boolean, zone : any) : string {
        if(this.isDualString()) {
            let lower : IPAddressSection = this.getLower();
            let upper : IPAddressSection = this.getUpper();
            let lowerDivs : IPAddressBitsDivision[] = lower.createNewDivisions<any>(3, (value,upperValue,bitCount,defaultRadix) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
            let lowerPart : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(lowerDivs, this.getNetwork());
            let upperDivs : IPAddressBitsDivision[] = upper.createNewDivisions<any>(3, (value,upperValue,bitCount,defaultRadix) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
            let upperPart : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(upperDivs, this.getNetwork());
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(IPAddressSection.toIPParams(with0Prefix?IPAddressSection.IPStringCache.octalPrefixedParams_$LI$():IPAddressSection.IPStringCache.octalParams_$LI$()), lowerPart, upperPart, zone);
        }
        let divs : IPAddressBitsDivision[] = this.createNewPrefixedDivisions<any>(3, null, null, (value,upperValue,bitCount,defaultRadix,network,networkPrefixLength) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix,network,networkPrefixLength) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
        let part : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(divs, this.getNetwork());
        return IPAddressSection.toIPParams(with0Prefix?IPAddressSection.IPStringCache.octalPrefixedParams_$LI$():IPAddressSection.IPStringCache.octalParams_$LI$()).toString(part, zone);
    }

    public toOctalString(with0Prefix? : any, zone? : any) : any {
        if(((typeof with0Prefix === 'boolean') || with0Prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toOctalString$boolean$java_lang_CharSequence(with0Prefix, zone);
        } else if(((typeof with0Prefix === 'boolean') || with0Prefix === null) && zone === undefined) {
            return <any>this.toOctalString$boolean(with0Prefix);
        } else throw new Error('invalid overload');
    }

    public toHexString$boolean(with0xPrefix : boolean) : string {
        let result : string;
        if(this.hasNoStringCache() || (result = (with0xPrefix?this.getStringCache().hexStringPrefixed:this.getStringCache().hexString)) == null) {
            let stringCache : IPAddressSection.IPStringCache = this.getStringCache();
            result = this.toHexString$boolean$java_lang_CharSequence(with0xPrefix, null);
            if(with0xPrefix) {
                stringCache.hexStringPrefixed = result;
            } else {
                stringCache.hexString = result;
            }
        }
        return result;
    }

    public toHexString$boolean$java_lang_CharSequence(with0xPrefix : boolean, zone : any) : string {
        if(this.isDualString()) {
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(IPAddressSection.toIPParams(with0xPrefix?IPAddressSection.IPStringCache.hexPrefixedParams_$LI$():IPAddressSection.IPStringCache.hexParams_$LI$()), this.getLower(), this.getUpper(), zone);
        }
        return IPAddressSection.toIPParams(with0xPrefix?IPAddressSection.IPStringCache.hexPrefixedParams_$LI$():IPAddressSection.IPStringCache.hexParams_$LI$()).toString(this, zone);
    }

    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toHexString$boolean$java_lang_CharSequence(with0xPrefix, zone);
        } else if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toNormalizedString(options? : any, zone? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringOptions : IPAddressSection.IPStringOptions) : string {
        return IPAddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_IPAddressStringDivisionSeries(stringOptions, this);
    }

    public static toNormalizedString(options? : any, zone? : any, part? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0)) || zone === null) && part === undefined) {
            return <any>IPAddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_IPAddressStringDivisionSeries(options, zone);
        } else throw new Error('invalid overload');
    }

    public static toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_IPAddressStringDivisionSeries(opts : IPAddressSection.IPStringOptions, section : IPAddressStringDivisionSeries) : string {
        return IPAddressSection.toIPParams(opts).toString(section);
    }

    static toParams(opts : IPAddressSection.IPStringOptions) : AddressDivisionGrouping.AddressStringParams<IPAddressStringDivisionSeries> {
        let result : AddressDivisionGrouping.AddressStringParams<IPAddressStringDivisionSeries> = <AddressDivisionGrouping.AddressStringParams<IPAddressStringDivisionSeries>><any>AddressDivisionGrouping.getCachedParams(opts);
        if(result == null) {
            result = <any>(new IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries>(opts.base, opts.separator, opts.uppercase));
            result.expandSegments(opts.expandSegments);
            result.setWildcards(opts.wildcards);
            result.setSegmentStrPrefix(opts.segmentStrPrefix);
            result.setAddressLabel(opts.addrLabel);
            result.setReverse(opts.reverse);
            result.setSplitDigits(opts.splitDigits);
            result.setRadix(opts.base);
            result.setUppercase(opts.uppercase);
            result.setSeparator(opts.separator);
            result.setZoneSeparator(opts.zoneSeparator);
            AddressDivisionGrouping.setCachedParams(opts, result);
        }
        return result;
    }

    static toIPParams(opts : IPAddressSection.IPStringOptions) : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> {
        let result : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> = <IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries>><any>AddressDivisionGrouping.getCachedParams(opts);
        if(result == null) {
            result = <any>(new IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries>(opts.base, opts.separator, opts.uppercase));
            result.expandSegments(opts.expandSegments);
            result.setWildcards(opts.wildcards);
            result.setWildcardOption(opts.wildcardOption);
            result.setSegmentStrPrefix(opts.segmentStrPrefix);
            result.setAddressSuffix(opts.addrSuffix);
            result.setAddressLabel(opts.addrLabel);
            result.setReverse(opts.reverse);
            result.setSplitDigits(opts.splitDigits);
            result.setZoneSeparator(opts.zoneSeparator);
            AddressDivisionGrouping.setCachedParams(opts, result);
        }
        return result;
    }

    /**
     * Returns at most a couple dozen string representations:
     * 
     * -mixed (1:2:3:4:5:6:1.2.3.4)
     * -upper and lower case
     * -full compressions or no compression (a:0:0:c:d:0:e:f or a::c:d:0:e:f or a:0:b:c:d::e:f)
     * -full leading zeros (000a:0000:000b:000c:000d:0000:000e:000f)
     * -combinations thereof
     * 
     * @return
     * @return {IPAddressPartStringCollection}
     */
    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this['toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions'](new IPAddressSection.IPStringBuilderOptions(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS));
    }

    /**
     * Use this method with care...  a single IPv6 address can have thousands of string representations.
     * 
     * Examples:
     * "::" has 1297 such variations, but only 9 are considered standard
     * "a:b:c:0:d:e:f:1" has 1920 variations, but only 12 are standard
     * 
     * Variations included in this method:
     * -all standard variations
     * -choosing specific segments for full leading zeros (::a:b can be ::000a:b, ::a:000b, or ::000a:000b)
     * -choosing which zero-segments to compress (0:0:a:: can be ::a:0:0:0:0:0 or 0:0:a::)
     * -mixed representation (1:2:3:4:5:6:1.2.3.4)
     * -all combinations of such variations
     * 
     * Variations omitted from this method:
     * -mixed case of a-f, which you can easily handle yourself with String.equalsIgnoreCase
     * -adding a variable number of leading zeros (::a can be ::0a, ::00a, ::000a)
     * -choosing any number of zero-segments anywhere to compress (:: can be 0:0:0::0:0)
     * 
     * @return
     * @return {IPAddressPartStringCollection}
     */
    public toAllStringCollection() : IPAddressPartStringCollection {
        return this['toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions'](new IPAddressSection.IPStringBuilderOptions(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$()));
    }

    /**
     * Returns a set of strings for search the standard string representations in a database
     * 
     * -compress the largest compressible segments or no compression (a:0:0:c:d:0:e:f or a::c:d:0:e:f)
     * -upper/lowercase is not considered because many databases are case-insensitive
     * 
     * @return
     * @return {IPAddressPartStringCollection}
     */
    public toDatabaseSearchStringCollection() : IPAddressPartStringCollection {
        return this['toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions'](new IPAddressSection.IPStringBuilderOptions());
    }

    public getParts(options? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        } else throw new Error('invalid overload');
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        if(options.includes(IPAddressSection.IPStringBuilderOptions.BASIC)) {
            return [this];
        }
        return IPAddressSection.EMPTY_PARTS_$LI$();
    }

    public getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String(builder : { str: string }, expression : string) {
        this.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, expression, new MySQLTranslator());
    }

    public getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder : { str: string }, expression : string, translator : IPAddressSQLTranslator) {
        this.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$boolean$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, expression, true, translator);
    }

    public getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$boolean$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder : { str: string }, expression : string, isFirstCall : boolean, translator : IPAddressSQLTranslator) {
        if(isFirstCall && this.isMultiple()) {
            let sectionIterator : any = this.iterator();
            /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
            let isNotFirst : boolean = false;
            while((sectionIterator.hasNext())) {
                if(isNotFirst) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>" OR "); return sb; })(builder);
                } else {
                    isNotFirst = true;
                }
                let next : IPAddressSection = sectionIterator.next();
                next.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$boolean$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, expression, false, translator);
            };
            /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
        } else if(this.getSegmentCount() > 0) {
            let createdStringCollection : IPAddressPartStringCollection = this.toDatabaseSearchStringCollection();
            let isNotFirst : boolean = false;
            if(createdStringCollection.size() > 1) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
            }
            let isEntireAddress : boolean = this.isEntireAddress();
            for(let index127=createdStringCollection.iterator();index127.hasNext();) {
                let createdStr = index127.next();
                {
                    if(isNotFirst) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>" OR "); return sb; })(builder);
                    } else {
                        isNotFirst = true;
                    }
                    let matcher : SQLStringMatcher<any, any, any> = createdStr.getNetworkStringMatcher<any>(isEntireAddress, translator);
                    /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(matcher.getSQLCondition(/* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder), expression));
                }
            }
            if(createdStringCollection.size() > 1) {
                /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
            }
        }
    }

    public getStartsWithSQLClause(builder? : any, expression? : any, isFirstCall? : any, translator? : any) : any {
        if(((builder != null && (builder instanceof Object)) || builder === null) && ((typeof expression === 'string') || expression === null) && ((typeof isFirstCall === 'boolean') || isFirstCall === null) && ((translator != null && (translator["__interfaces"] != null && translator["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0 || translator.constructor != null && translator.constructor["__interfaces"] != null && translator.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0)) || translator === null)) {
            return <any>this.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$boolean$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, expression, isFirstCall, translator);
        } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((typeof expression === 'string') || expression === null) && ((isFirstCall != null && (isFirstCall["__interfaces"] != null && isFirstCall["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0 || isFirstCall.constructor != null && isFirstCall.constructor["__interfaces"] != null && isFirstCall.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0)) || isFirstCall === null) && translator === undefined) {
            return <any>this.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, expression, isFirstCall);
        } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((typeof expression === 'string') || expression === null) && isFirstCall === undefined && translator === undefined) {
            return <any>this.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String(builder, expression);
        } else throw new Error('invalid overload');
    }

    public abstract segmentsNonZeroHostIterator(): any;
    public abstract toStringCollection(options?: any): any;
    public abstract toReverseDNSLookupString(): any;
    public abstract toPrefixLengthString(): any;
    public abstract toSQLWildcardString(): any;
    public abstract toCompressedWildcardString(): any;
    public abstract toSubnetString(): any;
    public abstract toFullString(): any;
    public abstract toNormalizedWildcardString(): any;
    public abstract toCanonicalWildcardString(): any;
    public abstract getIPVersion(): any;
    public abstract segmentsIterator(): any;
    public abstract getBytesPerSegment(): any;
    public abstract getBitsPerSegment(): any;
    public abstract toCompressedString(): any;
    public abstract toCanonicalString(): any;}
IPAddressSection["__class"] = "inet.ipaddr.IPAddressSection";
IPAddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.io.Serializable"];



export namespace IPAddressSection {

    export class PrefixCache {
        networkMaskPrefixLen : number;

        hostMaskPrefixLen : number;

        cachedMinPrefix : number;

        cachedEquivalentPrefix : number;

        constructor() {
            if(this.networkMaskPrefixLen===undefined) this.networkMaskPrefixLen = null;
            if(this.hostMaskPrefixLen===undefined) this.hostMaskPrefixLen = null;
            if(this.cachedMinPrefix===undefined) this.cachedMinPrefix = null;
            if(this.cachedEquivalentPrefix===undefined) this.cachedEquivalentPrefix = null;
        }
    }
    PrefixCache["__class"] = "inet.ipaddr.IPAddressSection.PrefixCache";


    export interface __inet_ipaddr_IPAddressSection_SegFunction<R, S> {
        (section : R, value : number) : S;
    }

    export class IPStringCache extends AddressDivisionGrouping.StringCache {
        static __static_initialized : boolean = false;
        static __static_initialize() { if(!IPStringCache.__static_initialized) { IPStringCache.__static_initialized = true; IPStringCache.__static_initializer_0(); } }

        public static hexParams : IPAddressSection.IPStringOptions; public static hexParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.hexParams; };

        public static hexPrefixedParams : IPAddressSection.IPStringOptions; public static hexPrefixedParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.hexPrefixedParams; };

        public static octalParams : IPAddressSection.IPStringOptions; public static octalParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.octalParams; };

        public static octalPrefixedParams : IPAddressSection.IPStringOptions; public static octalPrefixedParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.octalPrefixedParams; };

        public static binaryParams : IPAddressSection.IPStringOptions; public static binaryParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.binaryParams; };

        public static canonicalSegmentParams : IPAddressSection.IPStringOptions; public static canonicalSegmentParams_$LI$() : IPAddressSection.IPStringOptions { IPStringCache.__static_initialize(); return IPStringCache.canonicalSegmentParams; };

        static __static_initializer_0() {
            let allWildcards : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.ALL);
            IPStringCache.hexParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(16).setSeparator(null).setExpandedSegments(true).setWildcardOptions(allWildcards).toOptions();
            IPStringCache.hexPrefixedParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(16).setSeparator(null).setExpandedSegments(true).setWildcardOptions(allWildcards).setAddressLabel(IPAddress.HEX_PREFIX).toOptions();
            IPStringCache.octalParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(8).setSeparator(null).setExpandedSegments(true).setWildcardOptions(allWildcards).toOptions();
            IPStringCache.octalPrefixedParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(8).setSeparator(null).setExpandedSegments(true).setWildcardOptions(allWildcards).setAddressLabel(IPAddress.OCTAL_PREFIX).toOptions();
            IPStringCache.binaryParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(2).setSeparator(null).setExpandedSegments(true).setWildcardOptions(allWildcards).toOptions();
            IPStringCache.canonicalSegmentParams = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(10, ' ').toOptions();
        }

        public normalizedWildcardString : string;

        public fullString : string;

        public sqlWildcardString : string;

        public reverseDNSString : string;

        public octalStringPrefixed : string;

        public octalString : string;

        public binaryString : string;

        constructor() {
            super();
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.fullString===undefined) this.fullString = null;
            if(this.sqlWildcardString===undefined) this.sqlWildcardString = null;
            if(this.reverseDNSString===undefined) this.reverseDNSString = null;
            if(this.octalStringPrefixed===undefined) this.octalStringPrefixed = null;
            if(this.octalString===undefined) this.octalString = null;
            if(this.binaryString===undefined) this.binaryString = null;
        }
    }
    IPStringCache["__class"] = "inet.ipaddr.IPAddressSection.IPStringCache";


    export class WildcardOptions {
        public wildcardOption : WildcardOptions.WildcardOption;

        public wildcards : StringOptions.Wildcards;

        public constructor(wildcardOption? : any, wildcards? : any) {
            if(((typeof wildcardOption === 'number') || wildcardOption === null) && ((wildcards != null && wildcards instanceof <any>AddressDivisionGrouping.StringOptions.Wildcards) || wildcards === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.wildcardOption===undefined) this.wildcardOption = null;
                if(this.wildcards===undefined) this.wildcards = null;
                if(this.wildcardOption===undefined) this.wildcardOption = null;
                if(this.wildcards===undefined) this.wildcards = null;
                (() => {
                    this.wildcardOption = wildcardOption;
                    this.wildcards = wildcards;
                })();
            } else if(((typeof wildcardOption === 'number') || wildcardOption === null) && wildcards === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let wildcards : any = new StringOptions.Wildcards();
                    if(this.wildcardOption===undefined) this.wildcardOption = null;
                    if(this.wildcards===undefined) this.wildcards = null;
                    if(this.wildcardOption===undefined) this.wildcardOption = null;
                    if(this.wildcards===undefined) this.wildcards = null;
                    (() => {
                        this.wildcardOption = wildcardOption;
                        this.wildcards = wildcards;
                    })();
                }
            } else if(wildcardOption === undefined && wildcards === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let wildcardOption : any = WildcardOptions.WildcardOption.NETWORK_ONLY;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let wildcards : any = new StringOptions.Wildcards();
                        if(this.wildcardOption===undefined) this.wildcardOption = null;
                        if(this.wildcards===undefined) this.wildcards = null;
                        if(this.wildcardOption===undefined) this.wildcardOption = null;
                        if(this.wildcards===undefined) this.wildcards = null;
                        (() => {
                            this.wildcardOption = wildcardOption;
                            this.wildcards = wildcards;
                        })();
                    }
                }
            } else throw new Error('invalid overload');
        }
    }
    WildcardOptions["__class"] = "inet.ipaddr.IPAddressSection.WildcardOptions";


    export namespace WildcardOptions {

        export enum WildcardOption {
            NETWORK_ONLY, ALL
        }
    }


    /**
     * Represents a clear way to create a specific type of string.
     * 
     * @author sfoley
     * @extends AddressDivisionGrouping.StringOptions
     * @class
     */
    export class IPStringOptions extends AddressDivisionGrouping.StringOptions {
        public addrSuffix : string;

        public wildcardOption : WildcardOptions.WildcardOption;

        public zoneSeparator : string;

        constructor(base : number, expandSegments : boolean, wildcardOption : WildcardOptions.WildcardOption, wildcards : StringOptions.Wildcards, segmentStrPrefix : string, separator : string, zoneSeparator : string, label : string, suffix : string, reverse : boolean, splitDigits : boolean, uppercase : boolean) {
            super(base, expandSegments, wildcards, segmentStrPrefix, separator, label, reverse, splitDigits, uppercase);
            if(this.addrSuffix===undefined) this.addrSuffix = null;
            if(this.wildcardOption===undefined) this.wildcardOption = null;
            if(this.zoneSeparator===undefined) this.zoneSeparator = null;
            this.addrSuffix = suffix;
            this.wildcardOption = wildcardOption;
            this.zoneSeparator = zoneSeparator;
        }
    }
    IPStringOptions["__class"] = "inet.ipaddr.IPAddressSection.IPStringOptions";


    export namespace IPStringOptions {

        export class __inet_ipaddr_IPAddressSection_IPStringOptions_Builder extends AddressDivisionGrouping.StringOptions.Builder {
            addrSuffix : string = "";

            wildcardOption : WildcardOptions.WildcardOption = WildcardOptions.WildcardOption.NETWORK_ONLY;

            zoneSeparator : string = IPv6Address.ZONE_SEPARATOR;

            public constructor(base : number, separator : string = ' ') {
                super(base, separator);
            }

            /**
             * 
             * @param {AddressDivisionGrouping.StringOptions.Wildcards} wildcards
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setWildcards(wildcards : StringOptions.Wildcards) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setWildcards(wildcards);
            }

            public setAddressSuffix(suffix : string) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                this.addrSuffix = suffix;
                return this;
            }

            public setWildcardOptions(wildcardOptions : IPAddressSection.WildcardOptions) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                this.setWildcardOption(wildcardOptions.wildcardOption);
                return this.setWildcards(wildcardOptions.wildcards);
            }

            public setWildcardOption(wildcardOption : WildcardOptions.WildcardOption) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                this.wildcardOption = wildcardOption;
                return this;
            }

            /**
             * 
             * @param {boolean} reverse
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setReverse(reverse : boolean) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setReverse(reverse);
            }

            /**
             * 
             * @param {boolean} uppercase
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setUppercase(uppercase : boolean) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setUppercase(uppercase);
            }

            /**
             * 
             * @param {boolean} splitDigits
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setSplitDigits(splitDigits : boolean) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setSplitDigits(splitDigits);
            }

            /**
             * 
             * @param {boolean} expandSegments
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setExpandedSegments(expandSegments : boolean) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setExpandedSegments(expandSegments);
            }

            /**
             * 
             * @param {number} base
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setRadix(base : number) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setRadix(base);
            }

            /**
             * 
             * @param {string} separator
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setSeparator(separator : string) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setSeparator(separator);
            }

            public setZoneSeparator(separator : string) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                this.zoneSeparator = separator;
                return this;
            }

            /**
             * 
             * @param {string} label
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setAddressLabel(label : string) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setAddressLabel(label);
            }

            /**
             * 
             * @param {string} prefix
             * @return {IPAddressSection.IPStringOptions.Builder}
             */
            public setSegmentStrPrefix(prefix : string) : IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
                return <IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder>super.setSegmentStrPrefix(prefix);
            }

            /**
             * 
             * @return {IPAddressSection.IPStringOptions}
             */
            public toOptions() : IPAddressSection.IPStringOptions {
                return new IPAddressSection.IPStringOptions(this.base, this.expandSegments, this.wildcardOption, this.wildcards, this.segmentStrPrefix, this.separator, this.zoneSeparator, this.addrLabel, this.addrSuffix, this.reverse, this.splitDigits, this.uppercase);
            }
        }
        __inet_ipaddr_IPAddressSection_IPStringOptions_Builder["__class"] = "inet.ipaddr.IPAddressSection.IPStringOptions.Builder";

    }


    /**
     * This user-facing class is designed to be a clear way to create a collection of strings.
     * 
     * @author sfoley
     * @param {number} options
     * @class
     */
    export class IPStringBuilderOptions {
        public static BASIC : number = 1;

        public static LEADING_ZEROS_FULL_ALL_SEGMENTS : number = 16;

        public static LEADING_ZEROS_FULL_SOME_SEGMENTS : number; public static LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$() : number { if(IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS == null) IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS = 32 | IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS; return IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS; };

        public static LEADING_ZEROS_PARTIAL_SOME_SEGMENTS : number; public static LEADING_ZEROS_PARTIAL_SOME_SEGMENTS_$LI$() : number { if(IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS == null) IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS = 64 | IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$(); return IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS; };

        public options : number;

        public constructor(options? : any) {
            if(((typeof options === 'number') || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.options===undefined) this.options = 0;
                if(this.options===undefined) this.options = 0;
                (() => {
                    this.options = options;
                })();
            } else if(options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let options : any = IPStringBuilderOptions.BASIC;
                    if(this.options===undefined) this.options = 0;
                    if(this.options===undefined) this.options = 0;
                    (() => {
                        this.options = options;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        public includes(option : number) : boolean {
            return (option & this.options) === option;
        }

        public includesAny(option : number) : boolean {
            return (option & this.options) !== 0;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            let options : any = <any>({});
            let fields : Field[] = (<any>this.constructor).getFields();
            for(let index128=0; index128 < fields.length; index128++) {
                let field = fields[index128];
                {
                    let modifiers : number = field.getModifiers();
                    if(Modifier.isFinal(modifiers) && Modifier.isStatic(modifiers)) {
                        try {
                            let constant : number = field.getInt(null);
                            let option : string = /* getName */field.name + ": " + this.includes(constant) + java.lang.System.lineSeparator();
                            /* put */((m,k,v) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { m.entries[i].value=v; return; } m.entries.push({key:k,value:v,getKey: function() { return this.key }, getValue: function() { return this.value }}); })(<any>options, constant, option);
                        } catch(e) {
                        };
                    }
                }
            }
            let values : Array<string> = /* values */((m) => { let r=[]; if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) r.push(m.entries[i].value); return r; })(<any>options);
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            for(let index129=0; index129 < values.length; index129++) {
                let val = values[index129];
                {
                    /* append */(sb => { sb.str = sb.str.concat(<any>val); return sb; })(builder);
                }
            }
            return /* toString */builder.str;
        }
    }
    IPStringBuilderOptions["__class"] = "inet.ipaddr.IPAddressSection.IPStringBuilderOptions";

}




IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS_$LI$();

IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$();

IPAddressSection.IPStringCache.canonicalSegmentParams_$LI$();

IPAddressSection.IPStringCache.binaryParams_$LI$();

IPAddressSection.IPStringCache.octalPrefixedParams_$LI$();

IPAddressSection.IPStringCache.octalParams_$LI$();

IPAddressSection.IPStringCache.hexPrefixedParams_$LI$();

IPAddressSection.IPStringCache.hexParams_$LI$();

IPAddressSection.IPStringCache.__static_initialize();

IPAddressSection.EMPTY_PARTS_$LI$();

IPAddressSection.__static_initialize();
