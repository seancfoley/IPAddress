/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { MACAddressNetwork } from './mac/MACAddressNetwork';
import { AddressStringParameters } from './AddressStringParameters';
import { Address } from './Address';

/**
 * This class allows you to control the validation performed by the class {@link IPAddressString}.
 * 
 * The {@link IPAddressString} class uses a default permissive IPAddressStringParameters instance when you do not specify one.
 * 
 * If you wish to use parameters different from the default, then use this class.  All instances are immutable and must be constructed with the nested Builder class.
 * 
 * @author sfoley
 * @param {boolean} allowEmpty
 * @param {boolean} allowAll
 * @param {MACAddressStringParameters.AddressSize} allAddresses
 * @param {boolean} allowSingleSegment
 * @param {boolean} allowDashed
 * @param {boolean} allowSingleDashed
 * @param {boolean} allowColonDelimited
 * @param {boolean} allowDotted
 * @param {boolean} allowSpaceDelimited
 * @param {MACAddressStringParameters.MACAddressStringFormatParameters} formatOpts
 * @param {MACAddressNetwork} network
 * @class
 * @extends AddressStringParameters
 */
export class MACAddressStringParameters extends AddressStringParameters {
    static __inet_ipaddr_MACAddressStringParameters_serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_DASHED : boolean = true;

    public static DEFAULT_ALLOW_SINGLE_DASHED : boolean = true;

    public static DEFAULT_ALLOW_COLON_DELIMITED : boolean = true;

    public static DEFAULT_ALLOW_DOTTED : boolean = true;

    public static DEFAULT_ALLOW_SPACE_DELIMITED : boolean = true;

    /**
     * Whether * is considered to be MAC 6 bytes, EUI-64 8 bytes, or either one
     */
    public addressSize : MACAddressStringParameters.AddressSize;

    /**
     * Allows addresses like aa-bb-cc-dd-ee-ff
     */
    public allowDashed : boolean;

    /**
     * Allows addresses like aabbcc-ddeeff
     */
    public allowSingleDashed : boolean;

    /**
     * Allows addresses like aa:bb:cc:dd:ee:ff
     */
    public allowColonDelimited : boolean;

    /**
     * Allows addresses like aaa.bbb.ccc.ddd
     */
    public allowDotted : boolean;

    /**
     * Allows addresses like aa bb cc dd ee ff
     */
    public allowSpaceDelimited : boolean;

    /*private*/ network : MACAddressNetwork;

    /*private*/ formatOpts : MACAddressStringParameters.MACAddressStringFormatParameters;

    public constructor(allowEmpty : boolean, allowAll : boolean, allAddresses : MACAddressStringParameters.AddressSize, allowSingleSegment : boolean, allowDashed : boolean, allowSingleDashed : boolean, allowColonDelimited : boolean, allowDotted : boolean, allowSpaceDelimited : boolean, formatOpts : MACAddressStringParameters.MACAddressStringFormatParameters, network : MACAddressNetwork) {
        super(allowEmpty, allowAll, allowSingleSegment);
        if(this.addressSize===undefined) this.addressSize = null;
        if(this.allowDashed===undefined) this.allowDashed = false;
        if(this.allowSingleDashed===undefined) this.allowSingleDashed = false;
        if(this.allowColonDelimited===undefined) this.allowColonDelimited = false;
        if(this.allowDotted===undefined) this.allowDotted = false;
        if(this.allowSpaceDelimited===undefined) this.allowSpaceDelimited = false;
        if(this.network===undefined) this.network = null;
        if(this.formatOpts===undefined) this.formatOpts = null;
        this.allowDashed = allowDashed;
        this.allowSingleDashed = allowSingleDashed;
        this.allowColonDelimited = allowColonDelimited;
        this.allowDotted = allowDotted;
        this.allowSpaceDelimited = allowSpaceDelimited;
        this.formatOpts = formatOpts;
        this.addressSize = allAddresses;
        this.network = network;
    }

    public toBuilder(builder? : any) : any {
        if(((builder != null && builder instanceof <any>AddressStringParameters.BuilderBase) || builder === null)) {
            super.toBuilder(builder);
        } else if(builder === undefined) {
            return <any>this.toBuilder$();
        } else throw new Error('invalid overload');
    }

    public toBuilder$() : MACAddressStringParameters.Builder {
        let builder : MACAddressStringParameters.Builder = new MACAddressStringParameters.Builder();
        super.toBuilder$inet_ipaddr_AddressStringParameters_BuilderBase(builder);
        builder.__allowDashed = this.allowDashed;
        builder.allowSingleDashed = this.allowSingleDashed;
        builder.__allowColonDelimited = this.allowColonDelimited;
        builder.__allowDotted = this.allowDotted;
        builder.__allowSpaceDelimited = this.allowSpaceDelimited;
        builder.formatBuilder = this.formatOpts.toBuilder();
        builder.allAddresses = this.addressSize;
        builder.network = this.network;
        return builder;
    }

    public getNetwork() : MACAddressNetwork {
        if(this.network == null) {
            return Address.defaultMACNetwork();
        }
        return this.network;
    }

    public getFormatParameters() : MACAddressStringParameters.MACAddressStringFormatParameters {
        return this.formatOpts;
    }

    /**
     * 
     * @return {MACAddressStringParameters}
     */
    public clone() : MACAddressStringParameters {
        let result : MACAddressStringParameters = <MACAddressStringParameters>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
        result.formatOpts = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.formatOpts);
        return result;
    }

    public compareTo$inet_ipaddr_MACAddressStringParameters(o : MACAddressStringParameters) : number {
        let result : number = super.compareTo$inet_ipaddr_AddressStringParameters(o);
        if(result === 0) {
            result = this.formatOpts.compareTo$inet_ipaddr_MACAddressStringParameters_MACAddressStringFormatParameters(o.formatOpts);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowDashed, o.allowDashed);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.allowSingleDashed, o.allowSingleDashed);
                    if(result === 0) {
                        result = javaemul.internal.BooleanHelper.compare(this.allowColonDelimited, o.allowColonDelimited);
                        if(result === 0) {
                            result = javaemul.internal.BooleanHelper.compare(this.allowDotted, o.allowDotted);
                            if(result === 0) {
                                result = javaemul.internal.BooleanHelper.compare(this.allowSpaceDelimited, o.allowSpaceDelimited);
                                if(result === 0) {
                                    result = /* Enum.ordinal */MACAddressStringParameters.AddressSize[MACAddressStringParameters.AddressSize[this.addressSize]] - /* Enum.ordinal */MACAddressStringParameters.AddressSize[MACAddressStringParameters.AddressSize[o.addressSize]];
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * 
     * @param {MACAddressStringParameters} o
     * @return {number}
     */
    public compareTo(o? : any) : any {
        if(((o != null && o instanceof <any>MACAddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_MACAddressStringParameters(o);
        } else if(((o != null && o instanceof <any>AddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_AddressStringParameters(o);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>MACAddressStringParameters) {
            let other : MACAddressStringParameters = <MACAddressStringParameters>o;
            return super.equals(o) && this.formatOpts.equals(other.formatOpts) && this.allowDashed === other.allowDashed && this.allowSingleDashed === other.allowSingleDashed && this.allowColonDelimited === other.allowColonDelimited && this.allowDotted === other.allowDotted && this.allowSpaceDelimited === other.allowSpaceDelimited && this.addressSize === other.addressSize;
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.formatOpts));
        if(this.allowAll) {
            hash |= 128;
        }
        if(this.allowDashed) {
            hash |= 256;
        }
        if(this.allowColonDelimited) {
            hash |= 512;
        }
        if(this.allowDotted) {
            hash |= 1024;
        }
        if(this.allowSpaceDelimited) {
            hash |= 2048;
        }
        if(this.allowSingleSegment) {
            hash |= 4096;
        }
        if(this.addressSize === MACAddressStringParameters.AddressSize.MAC) {
            hash |= 8192;
        } else if(this.addressSize === MACAddressStringParameters.AddressSize.EUI64) {
            hash |= 16384;
        }
        if(this.allowSingleDashed) {
            hash |= 32768;
        }
        if(this.allowEmpty) {
            hash |= 65536;
        }
        return hash;
    }
}
MACAddressStringParameters["__class"] = "inet.ipaddr.MACAddressStringParameters";
MACAddressStringParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



export namespace MACAddressStringParameters {

    export enum AddressSize {
        MAC, EUI64, ANY
    }

    export class Builder extends AddressStringParameters.BuilderBase {
        __allowDashed : boolean = MACAddressStringParameters.DEFAULT_ALLOW_DASHED;

        allowSingleDashed : boolean = MACAddressStringParameters.DEFAULT_ALLOW_SINGLE_DASHED;

        __allowColonDelimited : boolean = MACAddressStringParameters.DEFAULT_ALLOW_COLON_DELIMITED;

        __allowDotted : boolean = MACAddressStringParameters.DEFAULT_ALLOW_DOTTED;

        __allowSpaceDelimited : boolean = MACAddressStringParameters.DEFAULT_ALLOW_SPACE_DELIMITED;

        allAddresses : MACAddressStringParameters.AddressSize;

        network : MACAddressNetwork;

        formatBuilder : MACAddressStringParameters.MACAddressStringFormatParameters.Builder;

        static DEFAULT_FORMAT_OPTS : MACAddressStringParameters.MACAddressStringFormatParameters; public static DEFAULT_FORMAT_OPTS_$LI$() : MACAddressStringParameters.MACAddressStringFormatParameters { if(Builder.DEFAULT_FORMAT_OPTS == null) Builder.DEFAULT_FORMAT_OPTS = new MACAddressStringParameters.MACAddressStringFormatParameters.Builder().toParams(); return Builder.DEFAULT_FORMAT_OPTS; };

        public constructor() {
            super();
            if(this.allAddresses===undefined) this.allAddresses = null;
            if(this.network===undefined) this.network = null;
            if(this.formatBuilder===undefined) this.formatBuilder = null;
        }

        /**
         * @see MACAddressStringParameters#allowEmpty
         * @param {boolean} allow
         * @return {MACAddressStringParameters.Builder} the builder
         */
        public allowEmpty(allow : boolean) : MACAddressStringParameters.Builder {
            return <MACAddressStringParameters.Builder>super.allowEmpty(allow);
        }

        /**
         * 
         * @param {boolean} allow
         * @return {MACAddressStringParameters.Builder}
         */
        public allowSingleSegment(allow : boolean) : MACAddressStringParameters.Builder {
            return <MACAddressStringParameters.Builder>super.allowSingleSegment(allow);
        }

        public allowDashed(bool : boolean) : MACAddressStringParameters.Builder {
            this.__allowDashed = bool;
            return this;
        }

        public allowColonDelimited(allow : boolean) : MACAddressStringParameters.Builder {
            this.__allowColonDelimited = allow;
            return this;
        }

        public allowDotted(allow : boolean) : MACAddressStringParameters.Builder {
            this.__allowDotted = allow;
            return this;
        }

        public allowSpaceDelimited(allow : boolean) : MACAddressStringParameters.Builder {
            this.__allowSpaceDelimited = allow;
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {MACAddressStringParameters.Builder}
         */
        public allowAll(allow : boolean) : MACAddressStringParameters.Builder {
            return <MACAddressStringParameters.Builder>super.allowAll(allow);
        }

        public setAllAddresses(all : MACAddressStringParameters.AddressSize) : MACAddressStringParameters.Builder {
            this.allAddresses = all;
            return this;
        }

        /**
         * @see MACAddressStringParameters#network
         * @param {MACAddressNetwork} network if null, the default network will be used
         * @return {MACAddressStringParameters.Builder} the builder
         */
        public setNetwork(network : MACAddressNetwork) : MACAddressStringParameters.Builder {
            this.network = network;
            return this;
        }

        public allowWildcardedSeparator(allow : boolean) : MACAddressStringParameters.Builder {
            this.getFormatBuilder().allowWildcardedSeparator(allow);
            return this;
        }

        public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : MACAddressStringParameters.Builder {
            this.getFormatBuilder().setRangeOptions(rangeOptions);
            return this;
        }

        /**
         * Get the sub-builder for setting format parameters.
         * @return {MACAddressStringParameters.MACAddressStringFormatParameters.Builder} the format builder
         */
        public getFormatBuilder() : MACAddressStringParameters.MACAddressStringFormatParameters.Builder {
            if(this.formatBuilder == null) {
                this.formatBuilder = new MACAddressStringParameters.MACAddressStringFormatParameters.Builder();
            }
            this.formatBuilder.parent = this;
            return this.formatBuilder;
        }

        public toParams() : MACAddressStringParameters {
            let formatOpts : MACAddressStringParameters.MACAddressStringFormatParameters;
            if(this.formatBuilder == null) {
                formatOpts = Builder.DEFAULT_FORMAT_OPTS_$LI$();
            } else {
                formatOpts = this.formatBuilder.toParams();
            }
            return new MACAddressStringParameters(this.__allowEmpty, this.__allowAll, this.allAddresses, this.__allowSingleSegment, this.__allowDashed, this.allowSingleDashed, this.__allowColonDelimited, this.__allowDotted, this.__allowSpaceDelimited, formatOpts, this.network);
        }
    }
    Builder["__class"] = "inet.ipaddr.MACAddressStringParameters.Builder";


    export class MACAddressStringFormatParameters extends AddressStringParameters.AddressStringFormatParameters {
        static __inet_ipaddr_MACAddressStringParameters_MACAddressStringFormatParameters_serialVersionUID : number = 4;

        public static DEFAULT_ALLOW_SHORT_SEGMENTS : boolean = true;

        public allowShortSegments : boolean;

        public constructor(allowShortSegments : boolean, allowLeadingZeros : boolean, allowUnlimitedLeadingZeros : boolean, rangeOptions : AddressStringParameters.RangeParameters, allowWildcardedSeparator : boolean) {
            super(allowLeadingZeros, allowUnlimitedLeadingZeros, rangeOptions, allowWildcardedSeparator);
            if(this.allowShortSegments===undefined) this.allowShortSegments = false;
            this.allowShortSegments = allowShortSegments;
        }

        public toBuilder(builder? : any) : any {
            if(((builder != null && builder instanceof <any>AddressStringParameters.AddressStringFormatParameters.BuilderBase) || builder === null)) {
                return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
            } else if(builder === undefined) {
                return <any>this.toBuilder$();
            } else throw new Error('invalid overload');
        }

        public toBuilder$() : MACAddressStringFormatParameters.Builder {
            let builder : MACAddressStringFormatParameters.Builder = new MACAddressStringFormatParameters.Builder();
            super.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
            builder.__allowShortSegments = this.allowShortSegments;
            return builder;
        }

        public compareTo$inet_ipaddr_MACAddressStringParameters_MACAddressStringFormatParameters(o : MACAddressStringParameters.MACAddressStringFormatParameters) : number {
            let result : number = super.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowShortSegments, o.allowShortSegments);
            }
            return result;
        }

        /**
         * 
         * @param {MACAddressStringParameters.MACAddressStringFormatParameters} o
         * @return {number}
         */
        public compareTo(o? : any) : any {
            if(((o != null && o instanceof <any>MACAddressStringParameters.MACAddressStringFormatParameters) || o === null)) {
                return <any>this.compareTo$inet_ipaddr_MACAddressStringParameters_MACAddressStringFormatParameters(o);
            } else if(((o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) || o === null)) {
                return <any>this.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>MACAddressStringParameters.MACAddressStringFormatParameters) {
                let other : MACAddressStringParameters.MACAddressStringFormatParameters = <MACAddressStringParameters.MACAddressStringFormatParameters>o;
                return super.equals(o) && this.allowShortSegments === other.allowShortSegments;
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
            if(this.allowShortSegments) {
                hash |= 64;
            }
            return hash;
        }

        /**
         * 
         * @return {MACAddressStringParameters.MACAddressStringFormatParameters}
         */
        public clone() : MACAddressStringParameters.MACAddressStringFormatParameters {
            try {
                return <MACAddressStringParameters.MACAddressStringFormatParameters>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
            } catch(e) {
                return null;
            };
        }
    }
    MACAddressStringFormatParameters["__class"] = "inet.ipaddr.MACAddressStringParameters.MACAddressStringFormatParameters";
    MACAddressStringFormatParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



    export namespace MACAddressStringFormatParameters {

        export class Builder extends AddressStringParameters.AddressStringFormatParameters.BuilderBase {
            __allowShortSegments : boolean = MACAddressStringFormatParameters.DEFAULT_ALLOW_SHORT_SEGMENTS;

            parent : MACAddressStringParameters.Builder;

            public getParentBuilder() : MACAddressStringParameters.Builder {
                return this.parent;
            }

            public allowShortSegments(allow : boolean) : MACAddressStringFormatParameters.Builder {
                this.__allowShortSegments = allow;
                return this;
            }

            /**
             * 
             * @param {AddressStringParameters.RangeParameters} rangeOptions
             * @return {MACAddressStringParameters.MACAddressStringFormatParameters.Builder}
             */
            public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : MACAddressStringFormatParameters.Builder {
                return <MACAddressStringFormatParameters.Builder>super.setRangeOptions(rangeOptions);
            }

            /**
             * 
             * @param {boolean} allow
             * @return {MACAddressStringParameters.MACAddressStringFormatParameters.Builder}
             */
            public allowWildcardedSeparator(allow : boolean) : MACAddressStringFormatParameters.Builder {
                return <MACAddressStringFormatParameters.Builder>super.allowWildcardedSeparator(allow);
            }

            /**
             * 
             * @param {boolean} allow
             * @return {MACAddressStringParameters.MACAddressStringFormatParameters.Builder}
             */
            public allowLeadingZeros(allow : boolean) : MACAddressStringFormatParameters.Builder {
                return <MACAddressStringFormatParameters.Builder>super.allowLeadingZeros(allow);
            }

            /**
             * 
             * @param {boolean} allow
             * @return {MACAddressStringParameters.MACAddressStringFormatParameters.Builder}
             */
            public allowUnlimitedLeadingZeros(allow : boolean) : MACAddressStringFormatParameters.Builder {
                return <MACAddressStringFormatParameters.Builder>super.allowUnlimitedLeadingZeros(allow);
            }

            toParams() : MACAddressStringParameters.MACAddressStringFormatParameters {
                return new MACAddressStringParameters.MACAddressStringFormatParameters(this.__allowShortSegments, this.__allowLeadingZeros, this.__allowUnlimitedLeadingZeros, this.rangeOptions, this.__allowWildcardedSeparator);
            }

            constructor() {
                super();
                if(this.parent===undefined) this.parent = null;
            }
        }
        Builder["__class"] = "inet.ipaddr.MACAddressStringParameters.MACAddressStringFormatParameters.Builder";

    }

}




MACAddressStringParameters.Builder.DEFAULT_FORMAT_OPTS_$LI$();
