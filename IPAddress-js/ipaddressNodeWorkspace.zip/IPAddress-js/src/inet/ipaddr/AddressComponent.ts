/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';

export interface AddressComponent extends AddressItem {
    /**
     * If this instance represents multiple address components, returns the one with the lowest numeric value.
     * 
     * @return
     * @return {*}
     */
    getLower() : AddressComponent;

    /**
     * If this instance represents multiple address components, returns the one with the highest numeric value.
     * 
     * @return
     * @return {*}
     */
    getUpper() : AddressComponent;

    /**
     * returns the number of bytes in each of the address components represented by this instance
     * 
     * @return
     * @return {number}
     */
    getByteCount() : number;

    /**
     * Useful for using an instance in a "for-each loop".  Otherwise just call {@link #iterator()} directly.
     * @return
     * @return {*}
     */
    getIterable() : java.lang.Iterable<any>;

    iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any;

    toHexString(with0xPrefix? : any, zone? : any) : any;

    toNormalizedString(options? : any, zone? : any) : any;

    /**
     * Returns a new AddressComponent with the bits reversed.
     * 
     * If this component represents a range of values that cannot be reversed, then this throws {@link IncompatibleAddressException}.  In a range the most significant bits stay constant
     * while the least significant bits range over different values, so reversing that scenario results in a series of non-consecutive values, in most cases,
     * which cannot be represented with a single AddressComponent object.
     * <p>
     * In such cases where isMultiple() is true, call iterator(), getLower(), getUpper() or some other methods to break the series down into a series representing a single value.
     * 
     * @param {boolean} perByte if true, only the bits in each byte are reversed, if false, then all bits in the component are reversed
     * @throws IncompatibleAddressException when subnet addresses cannot be reversed
     * @return
     * @return {*}
     */
    reverseBits(perByte? : any) : any;

    reverseBytes(perSegment? : any) : any;
}


