/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressCreator } from './format/AddressCreator';
import { AddressSegment } from './AddressSegment';
import { HostIdentifierString } from './HostIdentifierString';
import { Address } from './Address';

/**
 * An object representing a collection of addresses.
 * <p>
 * It also encapsulates settings for handling all addresses in the network like the prefix configuration that determines certain properties of the addresses in the network.
 * <p>
 * If your use of the IPAddress library has non-default configuration settings in this AddressNetwork class, and within the same JVM the IPAddress library
 * is being used elsewhere with different configuration settings, then you have two options available to you:
 * <p>
 * 1. Use classloaders to load the two uses of IPAddress in different classloaders, a common Java architecture that is part of the language itself to address just this issue
 * <p>
 * 2. Use your own network classes, and within them overide the configuration methods to return the values you desire.
 * <p>
 * All access to the network classes is through public virtual accessor methods getNetwork or getXNetwork in the classes XAddress, XAddressSection, XAddressSegment
 * where X is one of MAC, IPv6, or IPv4.  So you need to subclass those classes, and then override those getNetwork and getXNetwork methods to return your own network instances.
 * There are a couple of other places to consider to ensure only your own network instances are used.
 * XAddressString objects obtain their network object from the validation parameters supplied to the constructor, so you would customize those validation parameters as well.
 * The same is true for the HostName class, which uses an embedded address validation instance inside the host name parameters instance.
 * Finally, the address generator/cache classes (that are nested classes that in the network) use validation parameters as well that would be customized to your own network instances.
 * <p>
 * Generally you would use the same network object for any given address type (ie one for IPv6, one for IPv4, one for MAC), although this is not necessary.
 * However, it is necessary that the configuration is the same for any given address type.
 * <p>
 * Now suppose you wish to ensure any and all methods in this library create instances of your own subclasses of the XAddress, XAddressSection, XAddressSegment classes.
 * 
 * All internally created address components are created by the address creator instance owned by the network object.
 * So you override the getAddressCreator() in your new network classes to provide your own address creator object.
 * 
 * 
 * @author sfoley
 * @class
 */
export abstract class AddressNetwork<S extends AddressSegment> {
    static serialVersionUID : number = 4;

    public abstract getAddressCreator() : AddressCreator<any, any, any, S>;

    public clearCaches() {
        this.getAddressCreator().clearCaches();
    }

    static defaultPrefixConfiguration : AddressNetwork.PrefixConfiguration; public static defaultPrefixConfiguration_$LI$() : AddressNetwork.PrefixConfiguration { if(AddressNetwork.defaultPrefixConfiguration == null) AddressNetwork.defaultPrefixConfiguration = AddressNetwork.PrefixConfiguration.PREFIXED_ZERO_HOSTS_ARE_SUBNETS; return AddressNetwork.defaultPrefixConfiguration; };

    /**
     * This method determines the prefix configuration in use by this network.
     * <p>
     * The prefix configuration determines whether a prefixed address like 1.2.0.0/16 results in a subnet block (ie 1.2.*.*) or just a single address (1.2.0.0) with a prefix length.
     * <p>
     * If you wish to change the default behaviour, you can either call {@link inet.ipaddr.ipv4.IPv4AddressNetwork#setDefaultPrefixConfiguration(PrefixConfiguration)},
     * or {@link inet.ipaddr.ipv6.IPv6AddressNetwork#setDefaultPrefixConfiguration(PrefixConfiguration)} or you can override this method in your own network and use your own network for your addresses.
     * 
     * @see PrefixConfiguration
     * @return {AddressNetwork.PrefixConfiguration}
     */
    public abstract getPrefixConfiguration() : AddressNetwork.PrefixConfiguration;

    public static getDefaultPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
        return AddressNetwork.defaultPrefixConfiguration_$LI$();
    }

    constructor() {
    }
}
AddressNetwork["__class"] = "inet.ipaddr.AddressNetwork";
AddressNetwork["__interfaces"] = ["java.io.Serializable"];



export namespace AddressNetwork {

    export interface AddressSegmentCreator<S extends AddressSegment> {
        createSegmentArray(length : number) : S[];

        createSegment(lower? : any, upper? : any, segmentPrefixLength? : any) : any;
    }

    /**
     * Prefix Handling Configuration
     * 
     * The library is designed to treat prefixes three different ways:
     * <p>1. All prefixes are subnets.  This was the legacy behaviour for version earlier than version 4.
     * All prefixed addresses are converted to the block of addresses that share the same prefix.
     * For addresses in which prefixes are derived from the address ranges, such as MAC, prefix lengths are implicitly calculated from the range,
     * so 1:2:3:*:*:* implicitly has the prefix length of 24.  This is also the case for any address derived from the original.
     * <p>
     * 2. Addresses with zero-values hosts are treated as subnets.  More precisely, addresses whose hosts are entirely zero,
     * or addresses whose hosts start with zeros and end with the full range of values are treated as subnets.
     * So, for example, 1.2.0.0/16 is converted to 1.2.*.* which is the block of addresses with with prefix 1.2.
     * Also, 1.2.0.* /16 or 1.2.*.* /16 are also equivalent to the block of 65535 addresses 1.2.*.* associated with prefix length 16.
     * Addresses with non-zero hosts, such as 1.2.0.1/16 are treated differently. 1.2.0.1/16 is equivalent to the single address 1.2.0.1 and is not a treated as a subnet block of multiple addresses.
     * The new behaviour is akin to the typical convention used by network administrators in which the address with a host of zero is known as the network address.
     * The all-zero address 0.0.0.0 is conventionally known as INADDR_ANY (any address on the local machine), and when paired with prefix zero it is known as the default route (the route for all addresses).
     * <p>
     * The same is true on the IPv6 side, where 1:2:3:4::/64 is treated as the subnet of all addresses with prefix 1:2:3:4.
     * With IPv6 it is a common convention to depict a prefixed network as a:b:c:d::/64, with the host shown as all zeros.
     * This is also known as the subnet router anycast address in IPv6.  The all-zero address '::' is the value of IN6ADDR_ANY_INIT, the analog to the IPv4 INADDR_ANY.
     * <p>
     * In summary:<br>
     * <ul><li>A prefixed address whose host bits are all 0 is not a single host address, instead it represents a subnet, the block of all addresses with that prefix.
     * </li><li>A prefixed address whose host is non-zero is treated as a single address with the given prefix length.
     * </li></ul>
     * <p>
     * So for example, 1.2.0.0/16 will give you the subnet block 1.2.*.* /16, and once you have it, if you want just the single address 1.2.0.0/16, you can get it using {@link IPAddress#getLower()}.
     * <p>
     * This option has less meaning for other address types in which ranges are explicit, such as MAC addresses.  However, this option does allow you, using the appropriate constructor, to assign a prefix length to any address.
     * So there is no automatic fixed mapping between the range of the address values and the associated prefix length.
     * <p>
     * Additionally, when starting with an address whose prefix was calculated from its range, you can derive additionally addresses from the original, and those addresses will have the same prefix.
     * For instance, 1:2:3:*:*:* implicitly has the prefix length of 24 regardless of the prefix configuration.  But with this prefix configuration,
     * you can then construct a derived address with the same prefix, for example with new MACAddressString("1:2:3:*:*:*").getAddress().replace(MACAddressString("1:2:3:4:5:6").getSection(2));
     * <p>
     * 3. The third option is the setting for which prefixes are never automatically converted to subnets.  Any subnet must be explicitly defined,
     * such as 1.2.*.* /16
     * <p>
     * For addresses in which ranges are explicit, such as MAC addresses, this option is no different than the second option.
     * 
     * <p>
     * In summary:<ul>
     * <li>When PrefixConfiguration == ALL_PREFIXES_ARE_SUBNETS all prefixed addresses have hosts that span all possible host values.</li>
     * <li>When PrefixConfiguration == PREFIXED_ZERO_HOSTS_ARE_SUBNETS addresses constructed with zero host will have hosts that span all possible values, such as 1.2.0.0/16 which is equivalent to 1.2.*.* /16</li>
     * <li>When PrefixConfiguration == EXPLICIT_SUBNETS hosts that span all values are explicit, such as 1.2.*.* /16, while 1.2.0.0/16 is just a single address with a single host value of zero.</li>
     * </ul>
     * <p>
     * Note that when setting a non-default prefix configuration, indeterminate behaviour can result from the same addresses using different prefix configuration settings at different times, so this method must be used carefully.
     * <p>
     * Should you wish to use two different prefix configurations in the same app, it can be done safely using classloaders,
     * and it can also be done using different network instances.  To used different networks, you can override the virtual methods
     * for getting network instances in your address component classes.
     * @enum
     * @property {AddressNetwork.PrefixConfiguration} ALL_PREFIXED_ADDRESSES_ARE_SUBNETS
     * @property {AddressNetwork.PrefixConfiguration} PREFIXED_ZERO_HOSTS_ARE_SUBNETS
     * @property {AddressNetwork.PrefixConfiguration} EXPLICIT_SUBNETS
     * @class
     */
    export enum PrefixConfiguration {
        ALL_PREFIXED_ADDRESSES_ARE_SUBNETS, PREFIXED_ZERO_HOSTS_ARE_SUBNETS, EXPLICIT_SUBNETS
    }

    /** @ignore */
    export class PrefixConfiguration_$WRAPPER {
        constructor(protected _$ordinal : number, protected _$name : string) {
        }

        /**
         * @return {boolean} whether this is ALL_PREFIXED_ADDRESSES_ARE_SUBNETS
         */
        public allPrefixedAddressesAreSubnets() : boolean {
            return this._$ordinal === PrefixConfiguration.ALL_PREFIXED_ADDRESSES_ARE_SUBNETS;
        }

        /**
         * @return {boolean} whether this is PREFIXED_ZERO_HOSTS_ARE_SUBNETS
         */
        public zeroHostsAreSubnets() : boolean {
            return this._$ordinal === PrefixConfiguration.PREFIXED_ZERO_HOSTS_ARE_SUBNETS;
        }

        /**
         * @return {boolean} whether this is EXPLICIT_SUBNETS
         */
        public prefixedSubnetsAreExplicit() : boolean {
            return this._$ordinal === PrefixConfiguration.EXPLICIT_SUBNETS;
        }
        public name() : string { return this._$name; }
        public ordinal() : number { return this._$ordinal; }
    }
    PrefixConfiguration["__class"] = "inet.ipaddr.AddressNetwork.PrefixConfiguration";
    PrefixConfiguration["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

    PrefixConfiguration["_$wrappers"] = [new PrefixConfiguration_$WRAPPER(0, "ALL_PREFIXED_ADDRESSES_ARE_SUBNETS"), new PrefixConfiguration_$WRAPPER(1, "PREFIXED_ZERO_HOSTS_ARE_SUBNETS"), new PrefixConfiguration_$WRAPPER(2, "EXPLICIT_SUBNETS")];


    /**
     * Generates and caches HostIdentifierString instances.  Choose a map of your choice to implement a cache of address string identifiers.
     * <p>
     * You choose the map of your choice to be the backing map for the cache.
     * For example, for thread-safe access to the cache, ConcurrentHashMap is a good choice.
     * For maps of bounded size, LinkedHashMap provides the removeEldestEntry method to override to implement LRU or other eviction mechanisms.
     * <p>
     * @author sfoley
     * 
     * @param <T> the type to be cached, typically either IPAddressString or HostName
     * @param {*} backingMap
     * @class
     */
    export abstract class HostIdentifierStringGenerator<T extends HostIdentifierString> {
        static serialVersionUID : number = 4;

        backingMap : any;

        public constructor(backingMap? : any) {
            if(((backingMap != null && (backingMap instanceof Object)) || backingMap === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.backingMap===undefined) this.backingMap = null;
                if(this.backingMap===undefined) this.backingMap = null;
                (() => {
                    this.backingMap = backingMap;
                })();
            } else if(backingMap === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let backingMap : any = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    if(this.backingMap===undefined) this.backingMap = null;
                    (() => {
                        this.backingMap = backingMap;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        public getBackingMap() : any {
            return this.backingMap;
        }

        added(added : T) {
        }

        /**
         * Returns whether the given instance is in the cache.
         * @param {*} value
         * @return {boolean} whether the given instance of T is in the cache
         */
        public contains(value : T) : boolean {
            return this.backingMap.containsValue(value);
        }

        public get(version? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any) : any {
            if(((typeof version === 'string') || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$java_lang_String(version);
            } else if(((version != null && version instanceof <any>Array && (version.length==0 || version[0] == null ||(typeof version[0] === 'number'))) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$byte_A(version);
            } else if(((version != null && (version["__interfaces"] != null && version["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0 || version.constructor != null && version.constructor["__interfaces"] != null && version.constructor["__interfaces"].indexOf("inet.ipaddr.Address.AddressProvider") >= 0)) || version === null) && lowerValueProvider === undefined && upperValueProvider === undefined && prefixLength === undefined) {
                return <any>this.get$inet_ipaddr_Address_AddressProvider(version);
            } else throw new Error('invalid overload');
        }

        public get$java_lang_String(key : string) : T {
            if(this.backingMap == null) {
                return this.create(key);
            }
            let result : T = /* get */((m,k) => m[k]===undefined?null:m[k])(this.backingMap, key);
            if(result == null) {
                result = this.create(key);
                let normalizedKey : string = result.toNormalizedString();
                result = this.create(normalizedKey);
                let existing : T = this.backingMap.putIfAbsent(normalizedKey, result);
                if(existing == null) {
                    this.added(result);
                } else {
                    result = existing;
                }
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedKey,key))) {
                    /* put */(this.backingMap[key] = result);
                }
            }
            return result;
        }

        public get$byte_A(bytes : number[]) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        public get$inet_ipaddr_Address_AddressProvider(provider : Address.AddressProvider) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        abstract create(key : string) : T;
    }
    HostIdentifierStringGenerator["__class"] = "inet.ipaddr.AddressNetwork.HostIdentifierStringGenerator";
    HostIdentifierStringGenerator["__interfaces"] = ["java.io.Serializable"];


}




AddressNetwork.defaultPrefixConfiguration_$LI$();
