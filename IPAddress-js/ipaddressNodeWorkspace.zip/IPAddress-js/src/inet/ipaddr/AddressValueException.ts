/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressItem } from './format/AddressItem';
import { AddressStringException } from './AddressStringException';

/**
 * Thrown when an address or address component would be too large or small,
 * when a prefix length is too large or small, or when prefixes across segments are inconsistent.
 * <p>
 * These exceptions are thrown when constructing new address components.
 * They are not thrown when parsing strings to construct new address components, in which case {@link AddressStringException} is used instead.
 * 
 * @author sfoley
 * @param {*} one
 * @param {*} two
 * @param {number} count
 * @class
 * @extends Error
 */
export class AddressValueException extends Error {
    static serialVersionUID : number = 1;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(AddressValueException.errorMessage == null) AddressValueException.errorMessage = this.message; return AddressValueException.errorMessage; };

    static getMessage(key : string) : string {
        return AddressStringException.message;
    }

    public constructor(one? : any, two? : any, count? : any) {
        if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || two === null) && ((typeof count === 'number') || count === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(count + ", " + one + ", " + two + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=count + ", " + one + ", " + two + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || two === null) && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(one + ", " + two + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + two + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressItem") >= 0)) || one === null) && ((typeof two === 'string') || two === null) && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[1];
            super(one + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=one + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((typeof one === 'string') || one === null) && ((two != null && (two["__classes"] && two["__classes"].indexOf("java.lang.Throwable") >= 0) || two != null && two instanceof <any>Error) || two === null) && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let message : any = __args[0];
            let cause : any = __args[1];
            super(message); this.message=message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((typeof one === 'string') || one === null) && ((typeof two === 'number') || two === null) && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[0];
            let value : any = __args[1];
            super(value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((one != null && one instanceof <any>BigInteger) || one === null) && two === undefined && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            super(value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((typeof one === 'string') || one === null) && two === undefined && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let message : any = __args[0];
            super(message); this.message=message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else if(((typeof one === 'number') || one === null) && two === undefined && count === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            super(value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message); this.message=value + ", " + AddressValueException.errorMessage_$LI$() + " " + this.message;
            (<any>Object).setPrototypeOf(this, AddressValueException.prototype);
        } else throw new Error('invalid overload');
    }
}
AddressValueException["__class"] = "inet.ipaddr.AddressValueException";
AddressValueException["__interfaces"] = ["java.io.Serializable"];





AddressValueException.errorMessage_$LI$();
