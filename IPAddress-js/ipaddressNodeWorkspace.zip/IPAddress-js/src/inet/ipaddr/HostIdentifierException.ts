/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
 * 
 * @author sfoley
 * @param {*} str
 * @param {string} errorMessage
 * @param {string} key
 * @param {Error} cause
 * @class
 * @extends Error
 */
export class HostIdentifierException extends Error {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!HostIdentifierException.__static_initialized) { HostIdentifierException.__static_initialized = true; HostIdentifierException.__static_initializer_0(); } }

    static serialVersionUID : number = 4;

    static bundle : ResourceBundle; public static bundle_$LI$() : ResourceBundle { HostIdentifierException.__static_initialize(); return HostIdentifierException.bundle; };

    //I think you wan this: https://github.com/andyearnshaw/Intl.js
    //Note that most browsers and node have it built in, but you need to include it otherwise, see that github page
    //https://nodejs.org/api/intl.html
    //https://www.npmjs.com/package/i18n  ts: https://www.npmjs.com/package/@types/i18n
    //https://www.npmjs.com/package/node-i18n-util
    //https://webpack.js.org/loaders/i18n-loader/    this last one looks neat, but nobody uses it
    //probably the first one, that is what people use
    //https://www.npmjs.com/package/i18next seems popular too
    static __static_initializer_0() {
        let propertyFileName : string = "IPAddressResources";
        let name : string = HostIdentifierException.getPackage().getName() + '.' + propertyFileName;
        try {
            HostIdentifierException.bundle = ResourceBundle.getBundle(name);
        } catch(e) {
            console.error("bundle " + name + " is missing");
        };
    }

    public constructor(str? : any, errorMessage? : any, key? : any, cause? : any) {
        if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof errorMessage === 'string') || errorMessage === null) && ((typeof key === 'string') || key === null) && ((cause != null && (cause["__classes"] && cause["__classes"].indexOf("java.lang.Throwable") >= 0) || cause != null && cause instanceof <any>Error) || cause === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(str.toString() + ' ' + errorMessage + ' ' + this.message); this.message=str.toString() + ' ' + errorMessage + ' ' + this.message;
            (<any>Object).setPrototypeOf(this, HostIdentifierException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof errorMessage === 'string') || errorMessage === null) && ((typeof key === 'string') || key === null) && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(str.toString() + ' ' + errorMessage + ' ' + this.message); this.message=str.toString() + ' ' + errorMessage + ' ' + this.message;
            (<any>Object).setPrototypeOf(this, HostIdentifierException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((errorMessage != null && (errorMessage["__classes"] && errorMessage["__classes"].indexOf("java.lang.Throwable") >= 0) || errorMessage != null && errorMessage instanceof <any>Error) || errorMessage === null) && key === undefined && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let message : any = __args[0];
            let cause : any = __args[1];
            super(message.toString()); this.message=message.toString();
            (<any>Object).setPrototypeOf(this, HostIdentifierException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof errorMessage === 'string') || errorMessage === null) && key === undefined && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let errorMessage : any = __args[0];
            let key : any = __args[1];
            super(errorMessage.toString() + ' ' + this.message); this.message=errorMessage.toString() + ' ' + this.message;
            (<any>Object).setPrototypeOf(this, HostIdentifierException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && errorMessage === undefined && key === undefined && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let message : any = __args[0];
            super(message.toString()); this.message=message.toString();
            (<any>Object).setPrototypeOf(this, HostIdentifierException.prototype);
        } else throw new Error('invalid overload');
    }

    static getMessage(key : string) : string {
        if(HostIdentifierException.bundle_$LI$() != null) {
            try {
                return HostIdentifierException.bundle_$LI$().getString(key);
            } catch(e1) {
            };
        }
        return key;
    }
}
HostIdentifierException["__class"] = "inet.ipaddr.HostIdentifierException";
HostIdentifierException["__interfaces"] = ["java.io.Serializable"];





HostIdentifierException.bundle_$LI$();

HostIdentifierException.__static_initialize();
