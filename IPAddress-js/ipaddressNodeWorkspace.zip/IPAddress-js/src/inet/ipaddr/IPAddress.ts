/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringDivisionSeries } from './format/IPAddressStringDivisionSeries';
import { IPAddressPartStringCollection } from './format/util/IPAddressPartStringCollection';
import { IPAddressSQLTranslator } from './format/util/sql/IPAddressSQLTranslator';
import { IPAddressProvider } from './format/validate/IPAddressProvider';
import { ParsedHost } from './format/validate/ParsedHost';
import { IPv4Address } from './ipv4/IPv4Address';
import { IPv6Address } from './ipv6/IPv6Address';
import { Address } from './Address';
import { IPAddressSegmentSeries } from './IPAddressSegmentSeries';
import { IPAddressConverter } from './IPAddressConverter';
import { HostName } from './HostName';
import { IPAddressSection } from './IPAddressSection';
import { AddressSection } from './AddressSection';
import { HostIdentifierString } from './HostIdentifierString';
import { IPAddressString } from './IPAddressString';
import { AddressNetwork } from './AddressNetwork';
import { IPAddressNetwork } from './IPAddressNetwork';
import { IncompatibleAddressException } from './IncompatibleAddressException';
import { IPAddressSegment } from './IPAddressSegment';
import { IPAddressStringParameters } from './IPAddressStringParameters';
import { PrefixLenException } from './PrefixLenException';
import { AddressConversionException } from './AddressConversionException';

/**
 * A single IP address, or a subnet of multiple addresses.  Subnets have one or more segments that are a range of values.
 * <p>
 * IPAddress objects are immutable and cannot change values.  This also makes them thread-safe.
 * <p>
 * 
 * String creation:
 * <p>
 * There are several public classes used to customize IP address strings.
 * For single strings from an address or address section, you use {@link IPStringOptions} or {@link inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringOptions} along with {@link #toNormalizedString(IPAddressSection.IPStringOptions)}.
 * Or you use one of the methods like {@link #toCanonicalString()} which does the same.
 * <p>
 * For string collections from an address or address section, use {@link inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringBuilderOptions}, {@link inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringBuilderOptions}, {@link IPStringBuilderOptions} along with {@link #toStringCollection(IPAddressSection.IPStringBuilderOptions)} or {@link #toStrings(IPAddressSection.IPStringBuilderOptions)}.
 * Or you use one of the methods {@link #toStandardStringCollection()}, {@link #toAllStringCollection()}, {@link #toStandardStrings()}, {@link #toAllStrings()} which does the same.
 * <p>
 * @custom.core
 * @author sfoley
 * 
 * @extends Address
 * @class
 */
export abstract class IPAddress extends Address implements IPAddressSegmentSeries {
    static __inet_ipaddr_IPAddress_serialVersionUID : number = 4;

    public static PREFIX_LEN_SEPARATOR : string = '/';

    /**
     * The default way by which addresses are converted, initialized to an instance of {@link DefaultAddressConverter}
     */
    public static DEFAULT_ADDRESS_CONVERTER : IPAddressConverter; public static DEFAULT_ADDRESS_CONVERTER_$LI$() : IPAddressConverter { if(IPAddress.DEFAULT_ADDRESS_CONVERTER == null) IPAddress.DEFAULT_ADDRESS_CONVERTER = new IPAddressConverter.DefaultAddressConverter(); return IPAddress.DEFAULT_ADDRESS_CONVERTER; };

    fromHost : HostName;

    /*private*/ canonicalHost : HostName;

    public constructor(section? : any) {
        if(((section != null && section instanceof <any>IPAddressSection) || section === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(section);
            if(this.fromHost===undefined) this.fromHost = null;
            if(this.canonicalHost===undefined) this.canonicalHost = null;
            if(this.fromHost===undefined) this.fromHost = null;
            if(this.canonicalHost===undefined) this.canonicalHost = null;
        } else if(((typeof section === 'function' && (<any>section).length == 1) || section === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let supplier : any = __args[0];
            super(<any>(supplier));
            if(this.fromHost===undefined) this.fromHost = null;
            if(this.canonicalHost===undefined) this.canonicalHost = null;
            if(this.fromHost===undefined) this.fromHost = null;
            if(this.canonicalHost===undefined) this.canonicalHost = null;
        } else throw new Error('invalid overload');
    }

    /**
     * If this address was resolved from a host, returns that host.  Otherwise, does a reverse name lookup.
     * @return {HostName}
     */
    public toHostName() : HostName {
        let host : HostName = this.fromHost;
        if(host == null) {
            this.fromHost = host = this.toCanonicalHostName();
        }
        return host;
    }

    cache(string : HostIdentifierString) {
        if(string != null && string instanceof <any>HostName) {
            this.fromHost = <HostName><any>string;
        } else if(string != null && string instanceof <any>IPAddressString) {
            this.fromString = <IPAddressString><any>string;
        }
    }

    getProvider() : IPAddressProvider {
        if(this.isPrefixed()) {
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].prefixedSubnetsAreExplicit() || !this.isPrefixBlock()) {
                return IPAddressProvider.getProviderFor(this, this.removePrefixLength$boolean(false));
            }
            return IPAddressProvider.getProviderFor(this, this.toZeroHost());
        }
        return IPAddressProvider.getProviderFor(this, this);
    }

    /**
     * Does a reverse name lookup to get the canonical host name.
     * @return {HostName}
     */
    public toCanonicalHostName() : HostName {
        let host : HostName = this.canonicalHost;
        if(host == null) {
            if(this.isMultiple()) {
                throw new IncompatibleAddressException(this, "ipaddress.error.unavailable.numeric");
            }
            let inetAddress : InetAddress = this.toInetAddress();
            let hostStr : string = inetAddress.getCanonicalHostName();
            if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(hostStr,inetAddress.getHostAddress()))) {
                host = new HostName(hostStr, new ParsedHost(hostStr, this.getProvider()));
                host.resolvedAddress = this;
            } else {
                host = new HostName(hostStr);
            }
        }
        return host;
    }

    /**
     * 
     * @return {IPAddressNetwork}
     */
    public abstract getNetwork() : IPAddressNetwork<any, any, any, any, any>;

    public getSection$() : IPAddressSection {
        return <IPAddressSection><any>super.getSection();
    }

    public getSection$int(index : number) : IPAddressSection {
        return this.getSection().getSection$int(index);
    }

    public getSection$int$int(index : number, endIndex : number) : IPAddressSection {
        return this.getSection().getSection$int$int(index, endIndex);
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPAddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    public getParts(options? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        } else throw new Error('invalid overload');
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        return [this.getSection()];
    }

    /**
     * 
     * @return {number}
     */
    public getMaxSegmentValue() : number {
        return IPAddressSegment.getMaxSegmentValue(this.getIPVersion());
    }

    static getMaxSegmentValue(version : IPAddress.IPVersion) : number {
        return IPAddressSegment.getMaxSegmentValue(version);
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getNonZeroHostCount() : BigInteger {
        return this.getSection().getNonZeroHostCount();
    }

    /**
     * 
     * @return {number}
     */
    public getBytesPerSegment() : number {
        return IPAddressSegment.getByteCount(this.getIPVersion());
    }

    static getBytesPerSegment(version : IPAddress.IPVersion) : number {
        return IPAddressSegment.getByteCount(version);
    }

    /**
     * 
     * @return {number}
     */
    public getBitsPerSegment() : number {
        return IPAddressSegment.getBitCount(this.getIPVersion());
    }

    static getBitsPerSegment(version : IPAddress.IPVersion) : number {
        return IPAddressSegment.getBitCount(version);
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSection().getByteCount();
    }

    public static getByteCount(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.BYTE_COUNT:IPv6Address.BYTE_COUNT;
    }

    public static getSegmentCount(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.SEGMENT_COUNT:IPv6Address.SEGMENT_COUNT;
    }

    public static getBitCount(version : IPAddress.IPVersion) : number {
        return IPAddress.IPVersion["_$wrappers"][version].isIPv4()?IPv4Address.BIT_COUNT:IPv6Address.BIT_COUNT;
    }

    /**
     * 
     * @return {IPAddress}
     */
    public abstract getLowerNonZeroHost() : IPAddress;

    /**
     * 
     * @return {IPAddress}
     */
    public abstract getLower() : IPAddress;

    /**
     * 
     * @return {IPAddress}
     */
    public abstract getUpper() : IPAddress;

    /**
     * 
     * @param {boolean} perByte
     * @return {IPAddress}
     */
    public abstract reverseBits(perByte : boolean) : IPAddress;

    /**
     * 
     * @return {IPAddress}
     */
    public abstract reverseBytes() : IPAddress;

    /**
     * 
     * @return {IPAddress}
     */
    public abstract reverseBytesPerSegment() : IPAddress;

    /**
     * 
     * @return {IPAddress}
     */
    public abstract reverseSegments() : IPAddress;

    /**
     * 
     * @return {*}
     */
    public abstract iterator() : any;

    /**
     * 
     * @return {*}
     */
    public abstract nonZeroHostIterator() : any;

    /**
     * 
     * @return {*}
     */
    public abstract prefixBlockIterator() : any;

    /**
     * @return {*} an object to iterate over the individual addresses represented by this object.
     */
    public abstract getIterable() : java.lang.Iterable<any>;

    /**
     * 
     * @param {number} increment
     * @return {IPAddress}
     */
    public abstract increment(increment : number) : IPAddress;

    /**
     * 
     * @param {number} increment
     * @return {IPAddress}
     */
    public abstract incrementBoundary(increment : number) : IPAddress;

    public isIPv4() : boolean {
        return this.getSection().isIPv4();
    }

    public isIPv6() : boolean {
        return this.getSection().isIPv6();
    }

    /**
     * 
     * @return {IPAddress.IPVersion}
     */
    public getIPVersion() : IPAddress.IPVersion {
        return this.getSection().getIPVersion();
    }

    /**
     * If this address is IPv4, or can be converted to IPv4, returns that {@link IPv4Address}.  Otherwise, returns null.
     * 
     * @see #isIPv4Convertible()
     * @return {IPv4Address} the address
     */
    public toIPv4() : IPv4Address {
        return null;
    }

    /**
     * 
     * @return {IPv6Address} If this address is IPv6, or can be converted to IPv6, returns that {@link IPv6Address}.  Otherwise, returns null.
     * 
     * @see #isIPv6Convertible()
     * @return {IPv6Address} the address
     */
    public toIPv6() : IPv6Address {
        return null;
    }

    /**
     * Determines whether this address can be converted to IPv4, if not IPv4 already.
     * Override this method to convert in your own way.  If IPv6, the default behaviour
     * is to convert by IPv4 mapping, see {@link IPv6Address#isIPv4Mapped()}
     * 
     * You should also override {@link #toIPv4()} to match the conversion.
     * 
     * This method returns true for all IPv4 addresses.
     * 
     * @return
     * @return {boolean}
     */
    public abstract isIPv4Convertible() : boolean;

    /**
     * Determines whether an address can be converted to IPv6, if not IPv6 already.
     * Override this method to convert in your own way.  The default behaviour
     * is to convert by IPv4 mapping, see {@link IPv4Address#getIPv4MappedAddress()}
     * 
     * You should also override {@link #toIPv6()} to match the conversion.
     * 
     * This method returns true for all IPv6 addresses.
     * 
     * @return
     * @return {boolean}
     */
    public abstract isIPv6Convertible() : boolean;

    /**
     * Returns whether the address is link local, whether unicast or multicast.
     * 
     * @see java.net.InetAddress#isLinkLocalAddress()
     * @return {boolean}
     */
    public abstract isLinkLocal() : boolean;

    /**
     * Returns true if the address is link local, site local, organization local, administered locally, or unspecified.
     * This includes both unicast and multicast.
     * @return {boolean}
     */
    public abstract isLocal() : boolean;

    /**
     * The unspecified address is the address that is all zeros.
     * 
     * @return
     * @return {boolean}
     */
    public isUnspecified() : boolean {
        return this.isZero();
    }

    /**
     * Returns whether this address is the address which binds to any address on the local host.
     * This is the address that has the value of 0, aka the unspecfied address.
     * 
     * @see java.net.InetAddress#isAnyLocalAddress()
     * @return {boolean}
     */
    public isAnyLocal() : boolean {
        return this.isZero();
    }

    /**
     * @see java.net.InetAddress#isLoopbackAddress()
     * @return {boolean}
     */
    public abstract isLoopback() : boolean;

    /**
     * Converts the highest value of this address to an InetAddress.
     * If this consists of just a single address and not a subnet, this is equivalent to {@link #toInetAddress()}
     * @return {InetAddress}
     */
    public toUpperInetAddress() : InetAddress {
        return this.getSection().toUpperInetAddress(this);
    }

    /**
     * Converts the lowest value of this address to an InetAddress
     * @return {InetAddress}
     */
    public toInetAddress() : InetAddress {
        return this.getSection().toInetAddress(this);
    }

    toInetAddressImpl(bytes : number[]) : InetAddress {
        try {
            return InetAddress.getByAddress(bytes);
        } catch(e) {
            return null;
        };
    }

    public matches(otherString : IPAddressString) : boolean {
        if(this.isFromSameString(otherString)) {
            return true;
        }
        let otherAddr : IPAddress = otherString.getAddress();
        return otherAddr != null && this.isSameAddress$inet_ipaddr_IPAddress(otherAddr);
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    isFromSameString(other : HostIdentifierString) : boolean {
        if(this.fromString != null && (other != null && other instanceof <any>IPAddressString)) {
            let fromString : IPAddressString = <IPAddressString><any>this.fromString;
            let otherString : IPAddressString = <IPAddressString><any>other;
            return (fromString === otherString || (/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(fromString.fullAddr,otherString.fullAddr))) && Objects.equals(fromString.validationOptions, otherString.validationOptions));
        }
        return false;
    }

    public isSameAddress$inet_ipaddr_IPAddress(other : IPAddress) : boolean {
        return other === this || this.getSection().equals(other.getSection());
    }

    public isSameAddress(other? : any) : any {
        if(((other != null && other instanceof <any>IPAddress) || other === null)) {
            return <any>this.isSameAddress$inet_ipaddr_IPAddress(other);
        } else if(((other != null && other instanceof <any>Address) || other === null)) {
            return <any>this.isSameAddress$inet_ipaddr_Address(other);
        } else throw new Error('invalid overload');
    }

    /**
     * Applies the mask to this address and then compares values with the given address
     * 
     * @param {IPAddress} mask
     * @param {IPAddress} other
     * @return
     * @return {boolean}
     */
    public matchesWithMask(other : IPAddress, mask : IPAddress) : boolean {
        return this.getSection().matchesWithMask(other.getSection(), mask.getSection());
    }

    /**
     * 
     * @param {Address} other
     * @return {boolean}
     */
    public contains(other : Address) : boolean {
        if(other === this) {
            return true;
        }
        return this.getSection().contains(other.getSection());
    }

    static toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(prefixConfiguration : AddressNetwork.PrefixConfiguration, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, segmentCount : number, bytesPerSegment : number, bitsPerSegment : number, segmentMaxValue : number, separator : string, radix : number, zone : any) : string {
        let length : number = IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence$java_lang_StringBuilder(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone, null);
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence$java_lang_StringBuilder(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone, builder);
        IPAddressSection.checkLengths(length, builder);
        return /* toString */builder.str;
    }

    public static toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence$java_lang_StringBuilder(prefixConfiguration : AddressNetwork.PrefixConfiguration, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, segmentCount : number, bytesPerSegment : number, bitsPerSegment : number, segmentMaxValue : number, separator : string, radix : number, zone : any, builder : { str: string }) : number {
        let segmentIndex : number;
        let count : number;
        segmentIndex = count = 0;
        let isPrefixSubnet : boolean = IPAddressSection.isPrefixSubnet$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$int$int$java_lang_Integer$inet_ipaddr_AddressNetwork_PrefixConfiguration$boolean(lowerValueProvider, upperValueProvider, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, prefixLength, prefixConfiguration, false);
        while((true)) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
            if(isPrefixSubnet && segmentPrefixLength != null && segmentPrefixLength === 0) {
                if(builder == null) {
                    count++;
                } else {
                    /* append */(sb => { sb.str = sb.str.concat(<any>'0'); return sb; })(builder);
                }
            } else {
                let value : number = 0;
                let value2 : number = 0;
                if(lowerValueProvider == null) {
                    value = upperValueProvider.getValue(segmentIndex);
                } else {
                    value = lowerValueProvider.getValue(segmentIndex);
                    if(upperValueProvider != null) {
                        value2 = upperValueProvider.getValue(segmentIndex);
                    }
                }
                if(lowerValueProvider == null || upperValueProvider == null) {
                    if(isPrefixSubnet && segmentPrefixLength != null) {
                        value &= ~0 << (bitsPerSegment - segmentPrefixLength);
                    }
                    if(builder == null) {
                        count += IPAddressSegment.toUnsignedStringLength$int$int(value, radix);
                    } else {
                        IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(value, radix, builder);
                    }
                } else {
                    if(isPrefixSubnet && segmentPrefixLength != null) {
                        let mask : number = ~0 << (bitsPerSegment - segmentPrefixLength);
                        value &= mask;
                        value2 &= mask;
                    }
                    if(value === value2) {
                        if(builder == null) {
                            count += IPAddressSegment.toUnsignedStringLength$int$int(value, radix);
                        } else {
                            IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(value, radix, builder);
                        }
                    } else {
                        if(value > value2) {
                            let tmp : number = value2;
                            value2 = value;
                            value = tmp;
                        }
                        if(value === 0 && value2 === segmentMaxValue) {
                            if(builder == null) {
                                count += IPAddress.SEGMENT_WILDCARD_STR_$LI$().length;
                            } else {
                                /* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.SEGMENT_WILDCARD_STR_$LI$()); return sb; })(builder);
                            }
                        } else {
                            if(builder == null) {
                                count += IPAddressSegment.toUnsignedStringLength$int$int(value, radix) + IPAddressSegment.toUnsignedStringLength$int$int(value2, radix) + IPAddress.RANGE_SEPARATOR_STR_$LI$().length;
                            } else {
                                IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(value2, radix, /* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.RANGE_SEPARATOR_STR_$LI$()); return sb; })(IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(value, radix, builder)));
                            }
                        }
                    }
                }
            }
            if(++segmentIndex >= segmentCount) {
                break;
            }
            if(builder != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(builder);
            }
        };
        if(builder == null) {
            count += segmentCount - 1;
        }
        if(zone != null && zone.length > 0) {
            if(builder == null) {
                count += zone.length + 1;
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>zone); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPv6Address.ZONE_SEPARATOR); return sb; })(builder));
            }
        }
        if(prefixLength != null) {
            if(builder == null) {
                count += IPAddressSegment.toUnsignedStringLength$int$int(prefixLength, 10) + 1;
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>prefixLength); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })(builder));
            }
        }
        return count;
    }

    public static toNormalizedString(prefixConfiguration? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any, segmentCount? : any, bytesPerSegment? : any, bitsPerSegment? : any, segmentMaxValue? : any, separator? : any, radix? : any, zone? : any, builder? : any) : any {
        if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((builder != null && (builder instanceof Object)) || builder === null)) {
            return <any>IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence$java_lang_StringBuilder(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone, builder);
        } else if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && builder === undefined) {
            return <any>IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone);
        } else throw new Error('invalid overload');
    }

    /**
     * This produces a string with no compressed segments and all segments of full length,
     * which is 4 characters for IPv6 segments and 3 characters for IPv4 segments.
     * 
     * Each address has a unique full string, not counting CIDR the prefix, which can give two equal addresses different strings.
     * @return {string}
     */
    public toFullString() : string {
        return this.getSection().toFullString();
    }

    cacheNormalizedString(str : string) {
        this.getSection().cacheNormalizedString(str);
    }

    /**
     * Produces a consistent subnet string that looks like 1.2.*.* or 1:2::/16
     * 
     * In the case of IPv4, this means that wildcards are used instead of a network prefix when a network prefix has been supplied.
     * In the case of IPv6, when a network prefix has been supplied, the prefix will be shown and the host section will be compressed with ::.
     * @return {string}
     */
    public toSubnetString() : string {
        return this.getSection().toSubnetString();
    }

    /**
     * This produces a string similar to the normalized string but avoids the CIDR prefix.
     * CIDR addresses will be shown with wildcards and ranges instead of using the CIDR prefix notation.
     * @return {string}
     */
    public toNormalizedWildcardString() : string {
        return this.getSection().toNormalizedWildcardString();
    }

    /**
     * This produces a string similar to the canonical string but avoids the CIDR prefix.
     * Addresses with a network prefix length will be shown with wildcards and ranges instead of using the CIDR prefix length notation.
     * IPv6 addresses will be compressed according to the canonical representation.
     * @return {string}
     */
    public toCanonicalWildcardString() : string {
        return this.getSection().toCanonicalWildcardString();
    }

    /**
     * This is similar to toNormalizedWildcardString, avoiding the CIDR prefix, but with compression as well.
     * @return {string}
     */
    public toCompressedWildcardString() : string {
        return this.getSection().toCompressedWildcardString();
    }

    /**
     * This is the same as the string from toNormalizedWildcardString except that
     * it uses {@link IPAddress#SEGMENT_SQL_WILDCARD} instead of {@link IPAddress#SEGMENT_WILDCARD} and also uses {@link IPAddress#SEGMENT_SQL_SINGLE_WILDCARD}
     * @return {string}
     */
    public toSQLWildcardString() : string {
        return this.getSection().toSQLWildcardString();
    }

    /**
     * Returns a string with a CIDR network prefix length if this address has a network prefix length.
     * For IPv6, the host section will be compressed with ::, for IPv4 the host section will be zeros.
     * @return
     * @return {string}
     */
    public toPrefixLengthString() : string {
        return this.getSection().toPrefixLengthString();
    }

    /**
     * Returns a mixed string if it represents a convertible IPv4 address, returns the normalized string otherwise.
     * @return
     * @return {string}
     */
    public toConvertedString() : string {
        return this.toNormalizedString();
    }

    /**
     * Generates the Microsoft UNC path component for this address
     * 
     * @return
     * @return {string}
     */
    public abstract toUNCHostName() : string;

    /**
     * Generates the reverse DNS lookup string<p>
     * For 8.255.4.4 it is 4.4.255.8.in-addr.arpa<br>
     * For 2001:db8::567:89ab it is b.a.9.8.7.6.5.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.8.b.d.0.1.0.0.2.ip6.arpa
     * 
     * 
     * @throws IncompatibleAddressException if this address is a subnet
     * @return
     * @return {string}
     */
    public toReverseDNSLookupString() : string {
        return this.getSection().toReverseDNSLookupString();
    }

    /**
     * Writes this address as a single binary value with always the exact same number of characters
     * <p>
     * If this section represents a range of values not corresponding to a prefix, then this is printed as a range of two hex values.
     * @return {string}
     */
    public toBinaryString() : string {
        return this.getSection().toBinaryString();
    }

    /**
     * Writes this address as a single octal value with always the exact same number of characters, with or without a preceding 0 prefix.
     * <p>
     * If this section represents a range of values not corresponding to a prefix, then this is printed as a range of two hex values.
     * @param {boolean} with0Prefix
     * @return {string}
     */
    public toOctalString(with0Prefix : boolean) : string {
        return this.getSection().toOctalString$boolean(with0Prefix);
    }

    public toNormalizedString(stringParams? : any, joinCount? : any) : any {
        if(((stringParams != null && stringParams instanceof <any>IPAddressSection.IPStringOptions) || stringParams === null) && joinCount === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringParams);
        } else if(stringParams === undefined && joinCount === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(params : IPAddressSection.IPStringOptions) : string {
        return this.getSection().toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(params);
    }

    /**
     * Returns at most a few dozen string representations:
     * 
     * -mixed (1:2:3:4:5:6:1.2.3.4)
     * -full compressions (a:0:b:c:d:0:e:f or a::b:c:d:0:e:f or a:0:b:c:d::e:f)
     * -full leading zeros (000a:0000:000b:000c:000d:0000:000e:000f)
     * -all uppercase and all lowercase (a::a can be A::A)
     * -combinations thereof
     * 
     * @return
     * @return {Array}
     */
    public toStandardStrings() : string[] {
        return this.toStandardStringCollection().toStrings();
    }

    /**
     * Produces almost all possible string variations
     * <p>
     * Use this method with care...  a single IPv6 address can have thousands of string representations.
     * <p>
     * Examples:
     * <ul>
     * <li>"::" has 1297 such variations, but only 9 are considered standard</li>
     * <li>"a:b:c:0:d:e:f:1" has 1920 variations, but only 12 are standard</li>
     * </ul>
     * <p>
     * Variations included in this method:
     * <ul>
     * <li>all standard variations from {@link #toStandardStrings()}</li>
     * <li>adding a variable number of leading zeros (::a can be ::0a, ::00a, ::000a)</li>
     * <li>choosing any number of zero-segments to compress (:: can be 0:0:0::0:0)</li>
     * <li>mixed representation of all variations (1:2:3:4:5:6:1.2.3.4)</li>
     * <li>all uppercase and all lowercase (a::a can be A::A)</li>
     * <li>all combinations of such variations</li>
     * </ul>
     * Variations omitted from this method: mixed case of a-f, which you can easily handle yourself with String.equalsIgnoreCase
     * <p>
     * @return {Array} the strings
     */
    public toAllStrings() : string[] {
        return this.toAllStringCollection().toStrings();
    }

    /**
     * Rather than using toAllStrings or StandardStrings,
     * you can use this method to customize the list of strings produced for this address
     * @param {IPAddressSection.IPStringBuilderOptions} options
     * @return {Array}
     */
    public toStrings(options : IPAddressSection.IPStringBuilderOptions) : string[] {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options).toStrings();
    }

    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this.getSection().toStandardStringCollection();
    }

    public toAllStringCollection() : IPAddressPartStringCollection {
        return this.getSection().toAllStringCollection();
    }

    public toStringCollection(opts? : any) : any {
        if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }

    public toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressPartStringCollection {
        return this.getSection()['toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions'](options);
    }

    /**
     * Generates an IPAddressString object for this IPAddress object.
     * <p>
     * This same IPAddress object can be retrieved from the resulting IPAddressString object using {@link IPAddressString#getAddress()}
     * <p>
     * In general, users are intended to create IPAddress objects from IPAddressString objects,
     * while the reverse direction is generally not all that useful.
     * <p>
     * However, the reverse direction can be useful under certain circumstances.
     * <p>
     * Not all IPAddressString objects can be converted to IPAddress objects,
     * as is the case with IPAddressString objects corresponding to the types IPType.INVALID and IPType.EMPTY.
     * <p>
     * Not all IPAddressString objects can be converted to IPAddress objects without specifying the IP version,
     * as is the case with IPAddressString objects corresponding to the types IPType.PREFIX and  IPType.ALL.
     * <p>
     * So in the event you wish to store a collection of IPAddress objects with a collection of IPAddressString objects,
     * and not all the IPAddressString objects can be converted to IPAddress objects, then you may wish to use a collection
     * of only IPAddressString objects, in which case this method is useful.
     * 
     * @return {IPAddressString} an IPAddressString object for this IPAddress.
     */
    public toAddressString() : IPAddressString {
        if(this.fromString == null) {
            let params : IPAddressStringParameters = this.createFromStringParams();
            this.fromString = new IPAddressString(this, params);
        }
        return this.getAddressfromString();
    }

    abstract createFromStringParams() : IPAddressStringParameters;

    getAddressfromString() : IPAddressString {
        return <IPAddressString><any>this.fromString;
    }

    public static toDelimitedSQLStrs(strs : string[]) : string {
        if(strs.length === 0) {
            return "";
        }
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        for(let index125=0; index125 < strs.length; index125++) {
            let str = strs[index125];
            {
                /* append */(sb => { sb.str = sb.str.concat(<any>','); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'\''); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'\''); return sb; })(builder))));
            }
        }
        return builder.substring(0, /* length */builder.str.length - 1);
    }

    /**
     * 
     * @return {number}
     */
    public getNetworkPrefixLength() : number {
        return this.getSection().getNetworkPrefixLength();
    }

    public includesZeroHost$() : boolean {
        return this.getSection().includesZeroHost();
    }

    public includesZeroHost$int(networkPrefixLength : number) : boolean {
        return this.getSection().includesZeroHost$int(networkPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {boolean}
     */
    public includesZeroHost(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.includesZeroHost$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.includesZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toZeroHost$int(prefixLength : number) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPAddress}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toZeroHost$() : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toMaxHost$int(prefixLength : number) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPAddress}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public includesMaxHost$() : boolean {
        return this.getSection().includesMaxHost();
    }

    public includesMaxHost$int(networkPrefixLength : number) : boolean {
        return this.getSection().includesMaxHost$int(networkPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {boolean}
     */
    public includesMaxHost(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.includesMaxHost$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.includesMaxHost$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * Returns true if the network section of the address spans just a single value
     * <p>
     * For example, return true for 1.2.3.4/16 and false for 1.2-3.3.4/16
     * @return {boolean}
     */
    public isSingleNetwork() : boolean {
        return this.getSection().isSingleNetwork();
    }

    /**
     * Returns the smallest set of prefix blocks that spans both this and the supplied address or subnet.
     * @param {IPAddress} other
     * @return
     * @param {IPAddress} first
     * @param {*} getLower
     * @param {*} getUpper
     * @param {*} comparator
     * @param {*} prefixRemover
     * @param {*} arrayProducer
     * @return {Array}
     */
    static getSpanningPrefixBlocks<T extends IPAddress>(first : T, other : T, getLower : (p1: T) => T, getUpper : (p1: T) => T, comparator : any, prefixRemover : (p1: T) => T, arrayProducer : (p0 : number) => T[]) : T[] {
        let f : boolean;
        if((f = first.contains(other)) || other.contains(first)) {
            if(!f) {
                let tmp : T = first;
                first = other;
                other = tmp;
            }
            if(first.isPrefixed() && first.getPrefixLength() === first.getBitCount()) {
                first = (target => (typeof target === 'function')?target(first):(<any>target).apply(first))(prefixRemover);
            }
            let result : T[] = (target => (typeof target === 'function')?target(1):(<any>target).apply(1))(arrayProducer);
            result[0] = first;
            return result;
        }
        let blocks : Array<IPAddressSegmentSeries> = <any>([]);
        IPAddressSection.getSpanningSeriesPrefixBlocks<any>(first, other, <any>(getLower), <any>(getUpper), <any>(comparator), <any>(prefixRemover), blocks);
        return /* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })((target => (typeof target === 'function')?target(/* size */(<number>blocks.length)):(<any>target).apply(/* size */(<number>blocks.length)))(arrayProducer), blocks);
    }

    public toPrefixBlock$() : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public toPrefixBlock$int(networkPrefixLength : number) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * Returns the equivalent CIDR address with a prefix length for which the address subnet block matches the range of values in this address.
     * <p>
     * If no such prefix length exists, returns null.
     * <p>
     * 
     * Examples:<br>
     * 1.2.3.4 returns 1.2.3.4/32<br>
     * 1.2.*.* returns 1.2.0.0/16<br>
     * 1.2.*.0/24 returns 1.2.0.0/16 <br>
     * 1.2.*.4 returns null<br>
     * 1.2.252-255.* returns 1.2.252.0/22<br>
     * 1.2.3.4/x returns the same address<br>
     * 
     * @return
     * @return {IPAddress}
     */
    public assignPrefixForSingleBlock() : IPAddress {
        let newPrefix : number = this.getPrefixLengthForSingleBlock();
        return newPrefix == null?null:this.setPrefixLength$int$boolean(newPrefix, false);
    }

    /**
     * Constructs an equivalent address with the smallest CIDR prefix possible (largest network),
     * such that the range of values are a set of subnet blocks for that prefix.
     * 
     * @return
     * @return {IPAddress}
     */
    public assignMinPrefixForBlock() : IPAddress {
        return this.setPrefixLength$int$boolean(this.getMinPrefixLengthForBlock(), false);
    }

    /**
     * If this address is equivalent to the mask for a CIDR prefix block, it returns that prefix length.
     * Otherwise, it returns null.
     * A CIDR network mask is all 1s in the network section and then all 0s in the host section.
     * A CIDR host mask is all 0s in the network section and then all 1s in the host section.
     * The prefix is the length of the network section.
     * 
     * Also, keep in mind that the prefix length returned by this method is not equivalent to the prefix length used to construct this object.
     * The prefix length used to construct indicates the network and host portion of this address.
     * The prefix length returned here indicates the whether the value of this address can be used as a mask for the network and host
     * portion of any other address.  Therefore the two values can be different values, or one can be null while the other is not.
     * 
     * @param {boolean} network whether to check if we are a network mask or a host mask
     * @return {number} the prefix length corresponding to this mask, or null if there is no such prefix length
     */
    public getBlockMaskPrefixLength(network : boolean) : number {
        return this.getSection().getBlockMaskPrefixLength(network);
    }

    /**
     * Produces the list of prefix block subnets that span from this series to the given series.
     * <p>
     * If the other address is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()}
     * <p>
     * The resulting array is sorted from lowest address value to highest, regardless of the size of each prefix block.
     * 
     * @param {IPAddress} other
     * @return
     * @return {Array}
     */
    public abstract spanWithPrefixBlocks(other : IPAddress) : IPAddress[];

    /**
     * Merges this with the list of addresses to produce the smallest list of prefix blocks
     * <p>
     * If any other address in the list is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()},
     * which can result in AddressConversionException
     * <p>
     * The result is sorted from single address to smallest blocks to largest blocks.
     * 
     * @throws AddressConversionException
     * @param {Array} addresses the addresses to merge with this
     * @return
     * @return {Array}
     */
    public abstract mergePrefixBlocks(...addresses : IPAddress[]) : IPAddress[];

    static getMergedBlocks(first : IPAddressSegmentSeries, sections : IPAddressSegmentSeries[]) : Array<IPAddressSegmentSeries> {
        return IPAddressSection.getMergedBlocks(first, sections, false);
    }

    /**
     * Produces the subnet whose addresses are found in both this and the given subnet argument.
     * <p>
     * This is also known as the conjunction of the two sets of addresses.
     * <p>
     * If the address is not the same version, the default conversion will be applied using {@link #toIPv4()} or {@link #toIPv6()}, and it that fails, {@link AddressConversionException} will be thrown.
     * <p>
     * @param {IPAddress} other
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @return {IPAddress} the subnet containing the addresses found in both this and the given subnet
     */
    public abstract intersect(other : IPAddress) : IPAddress;

    /**
     * Subtract the given subnet from this subnet, returning an array of subnets for the result (the subnets will not be contiguous so an array is required).
     * <p>
     * Computes the subnet difference, the set of addresses in this address subnet but not in the provided subnet.  This is also known as the relative complement of the given argument in this subnet.
     * <p>
     * If the address is not the same version, the default conversion will be applied using {@link #toIPv4()} or {@link #toIPv6()}, and it that fails, {@link AddressConversionException} will be thrown.
     * <p>
     * @param {IPAddress} other
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @return {Array} the difference
     */
    public abstract subtract(other : IPAddress) : IPAddress[];

    public mask$inet_ipaddr_IPAddress(mask : IPAddress) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public mask$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * Applies the given mask to all addresses represented by this IPAddress.
     * The mask is applied to all individual addresses.
     * Any existing prefix length is removed beforehand.  If the retainPrefix argument is true, then the existing prefix length will be applied to the result.
     * <p>
     * If the mask is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()}
     * <p>
     * If this represents multiple addresses, and applying the mask to all addresses creates a set of addresses
     * that cannot be represented as a contiguous range within each segment, then {@link IncompatibleAddressException} is thrown.
     * <p>
     * @param {IPAddress} mask
     * @return
     * @throws IncompatibleAddressException if this is a range of addresses and applying the mask results in an address that cannot be represented as a contiguous range within each segment
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @param {boolean} retainPrefix
     * @return {IPAddress}
     */
    public mask(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.mask$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    /**
     * Applies the given mask to all addresses represented by this IPAddress while also applying the given prefix length at the same time.
     * <p>
     * Any existing prefix length is removed as the mask and new prefix length is applied to all individual addresses.
     * <p>
     * If the mask is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()}
     * <p>
     * If this represents multiple addresses, and applying the mask to all addresses creates a set of addresses
     * that cannot be represented as a contiguous range within each segment, then {@link IncompatibleAddressException} is thrown.
     * 
     * @throws IncompatibleAddressException if this is a range of addresses and applying the mask results in an address that cannot be represented as a contiguous range within each segment
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    public abstract maskNetwork(mask : IPAddress, networkPrefixLength : number) : IPAddress;

    public bitwiseOr$inet_ipaddr_IPAddress(mask : IPAddress) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public bitwiseOr$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * Does the bitwise disjunction with this address.  Useful when subnetting.
     * <p>
     * The mask is applied to all individual addresses, similar to how the method {@link #mask(IPAddress, boolean)} applies the bitwise conjunction.
     * Any existing prefix length is removed beforehand.  If the retainPrefix argument is true, then the existing prefix length will be applied to the result.
     * <p>
     * If the mask is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()}
     * <p>
     * If you wish to mask a portion of the network, use {@link #bitwiseOrNetwork(IPAddress, int)}
     * <p>
     * For instance, you can get the broadcast address for a subnet as follows:
     * <code>
     * String addrStr = "1.2.3.4/16";
     * IPAddress address = new IPAddressString(addrStr).getAddress();
     * IPAddress hostMask = address.getNetwork().getHostMask(address.getNetworkPrefixLength());//0.0.255.255
     * IPAddress broadcastAddress = address.bitwiseOr(hostMask); //1.2.255.255
     * </code>
     * 
     * @param {IPAddress} mask
     * @param {boolean} retainPrefix
     * @return
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @throws IncompatibleAddressException if this is a range of addresses and applying the mask results in an address that cannot be represented as a contiguous range within each segment
     * @return {IPAddress}
     */
    public bitwiseOr(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    /**
     * Does the bitwise disjunction with this address.  Useful when subnetting.
     * <p>
     * If the mask is a different version than this, then the default conversion is applied first using {@link #toIPv4()} or {@link #toIPv6()}
     * <p>
     * Any existing prefix length is dropped for the new prefix length and the mask is applied up to the end the new prefix length.
     * It is similar to how the {@link #maskNetwork(IPAddress, int)} method does the bitwise conjunction.
     * 
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength the new prefix length for the address
     * @return
     * @throws IncompatibleAddressException if this is a range of addresses and applying the mask results in an address that cannot be represented as a contiguous range within each segment
     * @throws AddressConversionException if the address argument could not be converted to the same address version as this
     * @return {IPAddress}
     */
    public abstract bitwiseOrNetwork(mask : IPAddress, networkPrefixLength : number) : IPAddress;

    public removePrefixLength$() : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public removePrefixLength$boolean(zeroed : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPAddress}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPAddress}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPAddress}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPAddress}
     */
    public abstract applyPrefixLength(networkPrefixLength : number) : IPAddress;

    public getMatchesSQLClause$java_lang_StringBuilder$java_lang_String(builder : { str: string }, sqlExpression : string) {
        this.getSection().getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String(builder, sqlExpression);
    }

    public getMatchesSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder : { str: string }, sqlExpression : string, translator : IPAddressSQLTranslator) {
        this.getSection().getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, sqlExpression, translator);
    }

    /**
     * Returns a clause for matching this address.
     * <p>
     * Similar to getMatchesSQLClause(StringBuilder builder, String sqlExpression) but allows you to tailor the SQL produced.
     * 
     * @param {{ str: string }} builder
     * @param {string} sqlExpression
     * @param {*} translator
     */
    public getMatchesSQLClause(builder? : any, sqlExpression? : any, translator? : any) : any {
        if(((builder != null && (builder instanceof Object)) || builder === null) && ((typeof sqlExpression === 'string') || sqlExpression === null) && ((translator != null && (translator["__interfaces"] != null && translator["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0 || translator.constructor != null && translator.constructor["__interfaces"] != null && translator.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.sql.IPAddressSQLTranslator") >= 0)) || translator === null)) {
            return <any>this.getMatchesSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, sqlExpression, translator);
        } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((typeof sqlExpression === 'string') || sqlExpression === null) && translator === undefined) {
            return <any>this.getMatchesSQLClause$java_lang_StringBuilder$java_lang_String(builder, sqlExpression);
        } else throw new Error('invalid overload');
    }

    public abstract segmentsNonZeroHostIterator(): any;
    public abstract getHostSection(): any;
    public abstract getHostSection(networkPrefixLength?: any): any;
    public abstract getNetworkSection(): any;
    public abstract getNetworkSection(networkPrefixLength?: any): any;
    public abstract getNetworkSection(networkPrefixLength?: any, withPrefixLength?: any): any;
    public abstract segmentsIterator(): any;
    public abstract getDivision(index?: any): any;
    public abstract getDivision(index?: any): any;
    public abstract getSegment(index?: any): any;
    public abstract getSegment(index?: any): any;
    public abstract getSegments(): any;
    public abstract getSegments(): any;}
IPAddress["__class"] = "inet.ipaddr.IPAddress";
IPAddress["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



export namespace IPAddress {

    /**
     * @author sfoley
     * @enum
     * @property {IPAddress.IPVersion} IPV4
     * @property {IPAddress.IPVersion} IPV6
     * @class
     */
    export enum IPVersion {
        IPV4, IPV6
    }

    /** @ignore */
    export class IPVersion_$WRAPPER {
        constructor(protected _$ordinal : number, protected _$name : string) {
        }

        public isIPv4() : boolean {
            return this._$ordinal === IPVersion.IPV4;
        }

        public isIPv6() : boolean {
            return this._$ordinal === IPVersion.IPV6;
        }
        public name() : string { return this._$name; }
        public ordinal() : number { return this._$ordinal; }
    }
    IPVersion["__class"] = "inet.ipaddr.IPAddress.IPVersion";
    IPVersion["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

    IPVersion["_$wrappers"] = [new IPVersion_$WRAPPER(0, "IPV4"), new IPVersion_$WRAPPER(1, "IPV6")];

}




IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
