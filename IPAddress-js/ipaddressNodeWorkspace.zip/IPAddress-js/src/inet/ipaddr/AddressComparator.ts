/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivision } from './format/AddressDivision';
import { AddressDivisionGrouping } from './format/AddressDivisionGrouping';
import { AddressDivisionSeries } from './format/AddressDivisionSeries';
import { IPAddressDivisionGrouping } from './format/IPAddressDivisionGrouping';
import { IPAddressJoinedSegments } from './format/IPAddressJoinedSegments';
import { IPv4AddressSection } from './ipv4/IPv4AddressSection';
import { IPv4AddressSegment } from './ipv4/IPv4AddressSegment';
import { IPv4JoinedSegments } from './ipv4/IPv4JoinedSegments';
import { IPv6Address } from './ipv6/IPv6Address';
import { IPv6AddressSection } from './ipv6/IPv6AddressSection';
import { IPv6AddressSegment } from './ipv6/IPv6AddressSegment';
import { MACAddressSection } from './mac/MACAddressSection';
import { MACAddressSegment } from './mac/MACAddressSegment';
import { Address } from './Address';
import { AddressSegmentSeries } from './AddressSegmentSeries';
import { AddressSegment } from './AddressSegment';
import { AddressSection } from './AddressSection';

export abstract class BaseComparator implements AddressComparator {
    public compare$inet_ipaddr_Address$inet_ipaddr_Address(one : Address, two : Address) : number {
        if(one === two) {
            return 0;
        }
        let result : number = this.compare$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one.getSection(), two.getSection());
        if(result === 0 && (one != null && one instanceof <any>IPv6Address)) {
            let oneIPv6 : IPv6Address = <IPv6Address>one;
            let twoIPv6 : IPv6Address = <IPv6Address>two;
            result = Objects.compare<any>(oneIPv6.getZone(), twoIPv6.getZone(), <any>(Comparator<any>((arg0) => { return String.compareTo(arg0) })));
        }
        return result;
    }

    /**
     * 
     * @param {Address} one
     * @param {Address} two
     * @return {number}
     */
    public compare(one? : any, two? : any) : any {
        if(((one != null && one instanceof <any>Address) || one === null) && ((two != null && two instanceof <any>Address) || two === null)) {
            return <any>this.compare$inet_ipaddr_Address$inet_ipaddr_Address(one, two);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || two === null)) {
            return <any>this.compare$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one, two);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || two === null)) {
            return <any>this.compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)) || two === null)) {
            return <any>this.compare$inet_ipaddr_AddressSegment$inet_ipaddr_AddressSegment(one, two);
        } else if(((one != null && one instanceof <any>AddressDivision) || one === null) && ((two != null && two instanceof <any>AddressDivision) || two === null)) {
            return <any>this.compare$inet_ipaddr_format_AddressDivision$inet_ipaddr_format_AddressDivision(one, two);
        } else throw new Error('invalid overload');
    }

    /*private*/ static mapGroupingClass(clazz : any) : number {
        if(IPv6AddressSection.isAssignableFrom(clazz)) {
            return 6;
        }
        if(IPv6AddressSection.IPv6v4MixedAddressSection.isAssignableFrom(clazz)) {
            return 5;
        }
        if(IPv4AddressSection.isAssignableFrom(clazz)) {
            return 4;
        }
        if(IPAddressDivisionGrouping.isAssignableFrom(clazz)) {
            return 3;
        }
        if(MACAddressSection.isAssignableFrom(clazz)) {
            return 3;
        }
        if(AddressDivisionGrouping.isAssignableFrom(clazz)) {
            return 1;
        }
        return 0;
    }

    /*private*/ static mapDivisionClass(clazz : any) : number {
        if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(clazz,MACAddressSegment))) {
            return 1;
        }
        if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(clazz,IPv4JoinedSegments))) {
            return 2;
        }
        if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(clazz,IPv4AddressSegment))) {
            return 3;
        }
        if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(clazz,IPv6AddressSegment))) {
            return 4;
        }
        return 0;
    }

    public compare$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one : AddressSection, two : AddressSection) : number {
        if(one === two) {
            return 0;
        }
        let oneClass : any = (<any>one.constructor);
        let twoClass : any = (<any>two.constructor);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oneClass,twoClass))) {
            let result : number = BaseComparator.mapGroupingClass(oneClass) - BaseComparator.mapGroupingClass(twoClass);
            if(result !== 0) {
                return result;
            }
        }
        if(one != null && one instanceof <any>IPv6AddressSection) {
            let o1 : IPv6AddressSection = <IPv6AddressSection><any>one;
            let o2 : IPv6AddressSection = <IPv6AddressSection><any>two;
            let result : number = o2.addressSegmentIndex - o1.addressSegmentIndex;
            if(result !== 0) {
                return result;
            }
        } else if(one != null && one instanceof <any>MACAddressSection) {
            let o1 : MACAddressSection = <MACAddressSection><any>one;
            let o2 : MACAddressSection = <MACAddressSection><any>two;
            let result : number = o2.addressSegmentIndex - o1.addressSegmentIndex;
            if(result !== 0) {
                return result;
            }
        }
        return this.compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
    }

    public compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one : AddressDivisionSeries, two : AddressDivisionSeries) : number {
        if((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) && (two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0))) {
            return this.compare$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(<AddressSection><any>one, <AddressSection><any>two);
        }
        if((one != null && one instanceof <any>Address) && (two != null && two instanceof <any>Address)) {
            return this.compare$inet_ipaddr_Address$inet_ipaddr_Address(<Address><any>one, <Address><any>two);
        }
        if(one === two) {
            return 0;
        }
        let oneClass : any = (<any>one.constructor);
        let twoClass : any = (<any>two.constructor);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oneClass,twoClass))) {
            return BaseComparator.mapGroupingClass(oneClass) - BaseComparator.mapGroupingClass(twoClass);
        }
        return this.compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
    }

    public compare$inet_ipaddr_AddressSegment$inet_ipaddr_AddressSegment(one : AddressSegment, two : AddressSegment) : number {
        if(one === two) {
            return 0;
        }
        let oneClass : any = (<any>one.constructor);
        let twoClass : any = (<any>two.constructor);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oneClass,twoClass))) {
            return BaseComparator.mapDivisionClass(oneClass) - BaseComparator.mapDivisionClass(twoClass);
        }
        return this.compareValues$long$long$long$long(one.getUpperSegmentValue(), one.getLowerSegmentValue(), two.getUpperSegmentValue(), two.getLowerSegmentValue());
    }

    public compare$inet_ipaddr_format_AddressDivision$inet_ipaddr_format_AddressDivision(one : AddressDivision, two : AddressDivision) : number {
        if((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)) && (two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0))) {
            return this.compare$inet_ipaddr_AddressSegment$inet_ipaddr_AddressSegment(<AddressSegment><any>one, <AddressSegment><any>two);
        }
        if(one === two) {
            return 0;
        }
        let oneClass : any = (<any>one.constructor);
        let twoClass : any = (<any>two.constructor);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oneClass,twoClass))) {
            return BaseComparator.mapDivisionClass(oneClass) - BaseComparator.mapDivisionClass(twoClass);
        }
        if(one != null && one instanceof <any>IPAddressJoinedSegments) {
            let o1 : IPAddressJoinedSegments = <IPAddressJoinedSegments>one;
            let o2 : IPAddressJoinedSegments = <IPAddressJoinedSegments>two;
            let result : number = o1.getJoinedCount() - o2.getJoinedCount();
            if(result !== 0) {
                return result;
            }
        }
        return BaseComparator.convertResult(this.compareValues$long$long$long$long(one.getUpperValue(), one.getLowerValue(), two.getUpperValue(), two.getLowerValue()));
    }

    compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one : AddressDivisionSeries, two : AddressDivisionSeries) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one : AddressSection, two : AddressSection) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public compareParts(one? : any, two? : any) : any {
        if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || two === null)) {
            return <any>this.compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one, two);
        } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || two === null)) {
            return <any>this.compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
        } else throw new Error('invalid overload');
    }

    compareValues$long$long$long$long(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public compareValues$int$int$int$int(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public compareValues(oneUpper? : any, oneLower? : any, twoUpper? : any, twoLower? : any) : any {
        if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
            return <any>this.compareValues$int$int$int$int(oneUpper, oneLower, twoUpper, twoLower);
        } else if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
            return <any>this.compareValues$long$long$long$long(oneUpper, oneLower, twoUpper, twoLower);
        } else throw new Error('invalid overload');
    }

    static convertResult(v : number) : number {
        return v === 0?0:(v > 0?1:-1);
    }

    constructor() {
    }
}
BaseComparator["__class"] = "inet.ipaddr.BaseComparator";
BaseComparator["__interfaces"] = ["inet.ipaddr.AddressComparator","java.util.Comparator"];



/**
 * 
 * @author sfoley
 * @class
 */
export interface AddressComparator {
    /**
     * 
     * @param {Address} one
     * @param {Address} two
     * @return {number}
     */
    compare(one? : any, two? : any) : any;
}

export namespace AddressComparator {

    /**
     * This is similar to the default comparator CountComparator in the way they treat addresses representing a single address.
     * 
     * For individual addresses, it simply compares segment to segment from high to low, so 1.2.3.4 &lt; 1.2.3.5 and 2.2.3.4 &gt; 1.2.3.5.
     * 
     * The difference is how they treat addresses representing multiple addresses (ie subnets) like 1::/8 or 1.*.*.*
     * 
     * The count comparator considers addresses which represent more individual addresses to be larger.
     * 
     * The value comparator goes by either the highest value or the lowest value in the range of represented addresses.
     * <p>
     * So, for instance, consider 1.2.3.4 and 1.0.0.*
     * 
     * With count comparator, 1.2.3.4 &lt; 1.2.3.* since the second represents more addresses (ie 1 &lt; 255)
     * 
     * With value comparator using the high value, 1.2.3.4 &lt; 1.2.3.* since 1.2.3.4 &lt; 1.2.3.255
     * 
     * With value comparator using the low value, 1.2.3.4 &gt; 1.2.3.* since 1.2.3.4 &gt; 1.2.3.0
     * 
     * @author sfoley
     * @param {boolean} compareHighValue
     * @class
     * @extends BaseComparator
     */
    export class ValueComparator extends BaseComparator {
        compareHighValue : boolean;

        public constructor(compareHighValue : boolean) {
            super();
            if(this.compareHighValue===undefined) this.compareHighValue = false;
            this.compareHighValue = compareHighValue;
        }

        compareSegmentLowValues(one : AddressSegmentSeries, two : AddressSegmentSeries) : number {
            let segCount : number = one.getSegmentCount();
            for(let i : number = 0; i < segCount; i++) {
                let segOne : AddressSegment = one.getSegment(i);
                let segTwo : AddressSegment = two.getSegment(i);
                let oneValue : number = segOne.getLowerSegmentValue();
                let twoValue : number = segTwo.getLowerSegmentValue();
                let result : number = oneValue - twoValue;
                if(result !== 0) {
                    return result;
                }
            };
            return 0;
        }

        public compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one : AddressSection, two : AddressSection) : number {
            let sizeResult : number = one.getByteCount() - two.getByteCount();
            if(sizeResult !== 0) {
                return sizeResult;
            }
            let compareHigh : boolean = this.compareHighValue;
            do {
                if(!compareHigh) {
                    let result : number = this.compareSegmentLowValues(one, two);
                    if(result !== 0) {
                        return result;
                    }
                } else {
                    let segCount : number = one.getSegmentCount();
                    for(let i : number = 0; i < segCount; i++) {
                        let segOne : AddressSegment = one.getSegment(i);
                        let segTwo : AddressSegment = two.getSegment(i);
                        let oneValue : number = segOne.getUpperSegmentValue();
                        let twoValue : number = segTwo.getUpperSegmentValue();
                        let result : number = oneValue - twoValue;
                        if(result !== 0) {
                            return result;
                        }
                    };
                }
                compareHigh = !compareHigh;
            } while((compareHigh !== this.compareHighValue));
            return 0;
        }

        /**
         * 
         * @param {*} one
         * @param {*} two
         * @return {number}
         */
        public compareParts(one? : any, two? : any) : any {
            if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || two === null)) {
                return <any>this.compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one, two);
            } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || two === null)) {
                return <any>this.compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
            } else throw new Error('invalid overload');
        }

        compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one : AddressDivisionSeries, two : AddressDivisionSeries) : number {
            let sizeResult : number = one.getBitCount() - two.getBitCount();
            if(sizeResult !== 0) {
                return sizeResult;
            }
            let compareHigh : boolean = this.compareHighValue;
            do {
                let oneBitCount : number;
                let twoBitCount : number;
                let oneIndex : number;
                let twoIndex : number;
                let oneValue : number;
                let twoValue : number;
                let oneCombo : AddressDivision;
                let twoCombo : AddressDivision;
                oneValue = twoValue = oneBitCount = twoBitCount = oneIndex = twoIndex = 0;
                while((oneIndex < one.getDivisionCount() || twoIndex < two.getDivisionCount())) {
                    if(oneBitCount === 0) {
                        oneCombo = one.getDivision(oneIndex++);
                        oneBitCount = oneCombo.getBitCount();
                        oneValue = compareHigh?oneCombo.getUpperValue():oneCombo.getLowerValue();
                    }
                    if(twoBitCount === 0) {
                        twoCombo = two.getDivision(twoIndex++);
                        twoBitCount = twoCombo.getBitCount();
                        twoValue = compareHigh?twoCombo.getUpperValue():twoCombo.getLowerValue();
                    }
                    let result : number;
                    let oneResultValue : number = oneValue;
                    let twoResultValue : number = twoValue;
                    if(twoBitCount === oneBitCount) {
                        oneBitCount = twoBitCount = 0;
                    } else {
                        let diffBits : number = twoBitCount - oneBitCount;
                        if(diffBits > 0) {
                            twoResultValue >>= diffBits;
                            twoValue &= ~(~0 << diffBits);
                            twoBitCount = diffBits;
                            oneBitCount = 0;
                        } else {
                            diffBits = -diffBits;
                            oneResultValue >>= diffBits;
                            oneValue &= ~(~0 << diffBits);
                            oneBitCount = diffBits;
                            twoBitCount = 0;
                        }
                    }
                    result = oneResultValue - twoResultValue;
                    if(result !== 0) {
                        return BaseComparator.convertResult(result);
                    }
                };
                compareHigh = !compareHigh;
            } while((compareHigh !== this.compareHighValue));
            return 0;
        }

        compareValues$long$long$long$long(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number {
            let result : number;
            if(this.compareHighValue) {
                result = oneUpper - twoUpper;
                if(result === 0) {
                    result = oneLower - twoLower;
                }
            } else {
                result = oneLower - twoLower;
                if(result === 0) {
                    result = oneUpper - twoUpper;
                }
            }
            return result;
        }

        public compareValues$int$int$int$int(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number {
            let result : number;
            if(this.compareHighValue) {
                result = oneUpper - twoUpper;
                if(result === 0) {
                    result = oneLower - twoLower;
                }
            } else {
                result = oneLower - twoLower;
                if(result === 0) {
                    result = oneUpper - twoUpper;
                }
            }
            return result;
        }

        /**
         * 
         * @param {number} oneUpper
         * @param {number} oneLower
         * @param {number} twoUpper
         * @param {number} twoLower
         * @return {number}
         */
        public compareValues(oneUpper? : any, oneLower? : any, twoUpper? : any, twoLower? : any) : any {
            if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
                return <any>this.compareValues$int$int$int$int(oneUpper, oneLower, twoUpper, twoLower);
            } else if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
                return <any>this.compareValues$long$long$long$long(oneUpper, oneLower, twoUpper, twoLower);
            } else throw new Error('invalid overload');
        }
    }
    ValueComparator["__class"] = "inet.ipaddr.AddressComparator.ValueComparator";
    ValueComparator["__interfaces"] = ["inet.ipaddr.AddressComparator","java.util.Comparator"];



    export class CountComparator extends BaseComparator {
        static compareCount(one : AddressDivisionSeries, two : AddressDivisionSeries) : number {
            return one.isMore(two);
        }

        public compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one : AddressSection, two : AddressSection) : number {
            let result : number = one.getBitCount() - two.getBitCount();
            if(result === 0) {
                result = CountComparator.compareCount(one, two);
                if(result === 0) {
                    result = this.compareEqualSizedSections(one, two);
                }
            }
            return result;
        }

        /**
         * 
         * @param {*} one
         * @param {*} two
         * @return {number}
         */
        public compareParts(one? : any, two? : any) : any {
            if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSection") >= 0)) || two === null)) {
                return <any>this.compareParts$inet_ipaddr_AddressSection$inet_ipaddr_AddressSection(one, two);
            } else if(((one != null && (one["__interfaces"] != null && one["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || one.constructor != null && one.constructor["__interfaces"] != null && one.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || one === null) && ((two != null && (two["__interfaces"] != null && two["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0 || two.constructor != null && two.constructor["__interfaces"] != null && two.constructor["__interfaces"].indexOf("inet.ipaddr.format.AddressDivisionSeries") >= 0)) || two === null)) {
                return <any>this.compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one, two);
            } else throw new Error('invalid overload');
        }

        compareParts$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries(one : AddressDivisionSeries, two : AddressDivisionSeries) : number {
            let result : number = one.getBitCount() - two.getBitCount();
            if(result === 0) {
                result = CountComparator.compareCount(one, two);
                if(result === 0) {
                    result = this.compareSegmentGroupings(one, two);
                }
            }
            return result;
        }

        compareSegmentGroupings(one : AddressDivisionSeries, two : AddressDivisionSeries) : number {
            let oneBitCount : number;
            let twoBitCount : number;
            let oneIndex : number;
            let twoIndex : number;
            let oneUpper : number;
            let oneLower : number;
            let twoUpper : number;
            let twoLower : number;
            let oneCombo : AddressDivision;
            let twoCombo : AddressDivision;
            oneUpper = oneLower = twoUpper = twoLower = oneBitCount = twoBitCount = oneIndex = twoIndex = 0;
            while((oneIndex < one.getDivisionCount() || twoIndex < two.getDivisionCount())) {
                if(oneBitCount === 0) {
                    oneCombo = one.getDivision(oneIndex++);
                    oneBitCount = oneCombo.getBitCount();
                    oneUpper = oneCombo.getUpperValue();
                    oneLower = oneCombo.getLowerValue();
                }
                if(twoBitCount === 0) {
                    twoCombo = two.getDivision(twoIndex++);
                    twoBitCount = twoCombo.getBitCount();
                    twoUpper = twoCombo.getUpperValue();
                    twoLower = twoCombo.getLowerValue();
                }
                let oneResultUpper : number = oneUpper;
                let oneResultLower : number = oneLower;
                let twoResultUpper : number = twoUpper;
                let twoResultLower : number = twoLower;
                if(twoBitCount === oneBitCount) {
                    oneBitCount = twoBitCount = 0;
                } else {
                    let diffBits : number = twoBitCount - oneBitCount;
                    if(diffBits > 0) {
                        twoResultUpper >>= diffBits;
                        twoResultLower >>= diffBits;
                        let mask : number = ~(~0 << diffBits);
                        twoUpper &= mask;
                        twoLower &= mask;
                        twoBitCount = diffBits;
                        oneBitCount = 0;
                    } else {
                        diffBits = -diffBits;
                        oneResultUpper >>= diffBits;
                        oneResultLower >>= diffBits;
                        let mask : number = ~(~0 << diffBits);
                        oneUpper &= mask;
                        oneLower &= mask;
                        oneBitCount = diffBits;
                        twoBitCount = 0;
                    }
                }
                let result : number = this.compareValues$long$long$long$long(oneResultUpper, oneResultLower, twoResultUpper, twoResultLower);
                if(result !== 0) {
                    return BaseComparator.convertResult(result);
                }
            };
            return 0;
        }

        compareEqualSizedSections(one : AddressSection, two : AddressSection) : number {
            let segCount : number = one.getSegmentCount();
            for(let i : number = 0; i < segCount; i++) {
                let segOne : AddressSegment = one.getSegment(i);
                let segTwo : AddressSegment = two.getSegment(i);
                let oneUpper : number = segOne.getUpperSegmentValue();
                let twoUpper : number = segTwo.getUpperSegmentValue();
                let oneLower : number = segOne.getLowerSegmentValue();
                let twoLower : number = segTwo.getLowerSegmentValue();
                let result : number = this.compareValues$int$int$int$int(oneUpper, oneLower, twoUpper, twoLower);
                if(result !== 0) {
                    return result;
                }
            };
            return 0;
        }

        public compareValues$int$int$int$int(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number {
            let result : number = (oneUpper - oneLower) - (twoUpper - twoLower);
            if(result === 0) {
                result = oneLower - twoLower;
            }
            return result;
        }

        /**
         * 
         * @param {number} oneUpper
         * @param {number} oneLower
         * @param {number} twoUpper
         * @param {number} twoLower
         * @return {number}
         */
        public compareValues(oneUpper? : any, oneLower? : any, twoUpper? : any, twoLower? : any) : any {
            if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
                return <any>this.compareValues$int$int$int$int(oneUpper, oneLower, twoUpper, twoLower);
            } else if(((typeof oneUpper === 'number') || oneUpper === null) && ((typeof oneLower === 'number') || oneLower === null) && ((typeof twoUpper === 'number') || twoUpper === null) && ((typeof twoLower === 'number') || twoLower === null)) {
                return <any>this.compareValues$long$long$long$long(oneUpper, oneLower, twoUpper, twoLower);
            } else throw new Error('invalid overload');
        }

        compareValues$long$long$long$long(oneUpper : number, oneLower : number, twoUpper : number, twoLower : number) : number {
            let result : number = (oneUpper - oneLower) - (twoUpper - twoLower);
            if(result === 0) {
                result = oneLower - twoLower;
            }
            return result;
        }

        constructor() {
            super();
        }
    }
    CountComparator["__class"] = "inet.ipaddr.AddressComparator.CountComparator";
    CountComparator["__interfaces"] = ["inet.ipaddr.AddressComparator","java.util.Comparator"];


}



