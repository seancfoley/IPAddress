/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressStringException } from '../AddressStringException';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { HostIdentifierString } from '../HostIdentifierString';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressSection } from '../ipv4/IPv4AddressSection';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPAddressTest } from './IPAddressTest';
import { AddressStringParameters } from '../AddressStringParameters';
import { AddressCreator } from './AddressCreator';
import { TestBase } from './TestBase';
import { IPv4AddressSegment } from '../ipv4/IPv4AddressSegment';
import { AddressNetwork } from '../AddressNetwork';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { AddressSegmentSeries } from '../AddressSegmentSeries';

export class IPAddressRangeTest extends IPAddressTest {
    static WILDCARD_AND_RANGE_ADDRESS_OPTIONS : IPAddressStringParameters; public static WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS == null) IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS = TestBase.ADDRESS_OPTIONS_$LI$().toBuilder().allowAll(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).toParams(); return IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS; };

    static WILDCARD_ONLY_ADDRESS_OPTIONS : IPAddressStringParameters; public static WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS == null) IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS = IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).toParams(); return IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS; };

    static NO_RANGE_ADDRESS_OPTIONS : IPAddressStringParameters; public static NO_RANGE_ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(IPAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS == null) IPAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS = IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$()).toParams(); return IPAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS; };

    static INET_ATON_WILDCARD_OPTS : IPAddressStringParameters; public static INET_ATON_WILDCARD_OPTS_$LI$() : IPAddressStringParameters { if(IPAddressRangeTest.INET_ATON_WILDCARD_OPTS == null) IPAddressRangeTest.INET_ATON_WILDCARD_OPTS = TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$().toBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).toParams(); return IPAddressRangeTest.INET_ATON_WILDCARD_OPTS; };

    static optionsCache : IPAddressStringParameters[][]; public static optionsCache_$LI$() : IPAddressStringParameters[][] { if(IPAddressRangeTest.optionsCache == null) IPAddressRangeTest.optionsCache = <any> (function(dims) { let allocate = function(dims) { if(dims.length==0) { return null; } else { let array = []; for(let i = 0; i < dims[0]; i++) { array.push(allocate(dims.slice(1))); } return array; }}; return allocate(dims);})([3, 3]); return IPAddressRangeTest.optionsCache; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    public testIPv4Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w : IPAddressString, ipAddr : IPAddress, normalizedString : string, normalizedWildcardString : string, sqlString : string, fullString : string, octalString : string, hexString : string, reverseDNSString : string, singleHex : string, singleOctal : string) {
        this.testStrings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, normalizedWildcardString, sqlString, fullString, normalizedString, normalizedString, normalizedWildcardString, normalizedString, normalizedWildcardString, reverseDNSString, normalizedString, singleHex, singleOctal);
        this.testIPv4OnlyStrings(w, <IPv4Address>ipAddr, octalString, hexString);
        this.testInetAtonCombos(w, <IPv4Address>ipAddr);
    }

    public testIPv4Strings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, sqlString? : any, fullString? : any, octalString? : any, hexString? : any, reverseDNSString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof octalString === 'string') || octalString === null) && ((typeof hexString === 'string') || hexString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            return <any>this.testIPv4Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, sqlString, fullString, octalString, hexString, reverseDNSString, singleHex, singleOctal);
        } else if(((typeof w === 'string') || w === null) && ((typeof ipAddr === 'string') || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof octalString === 'string') || octalString === null) && ((typeof hexString === 'string') || hexString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof singleHex === 'string') || singleHex === null) && singleOctal === undefined) {
            return <any>this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, sqlString, fullString, octalString, hexString, reverseDNSString, singleHex);
        } else throw new Error('invalid overload');
    }

    /*private*/ testIPv4OnlyStrings(w : IPAddressString, ipAddr : IPv4Address, octalString : string, hexString : string) {
        let oct : string = ipAddr.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(IPv4Address.inet_aton_radix.OCTAL);
        let hex : string = ipAddr.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(IPv4Address.inet_aton_radix.HEX);
        let octMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oct,octalString));
        if(!octMatch) {
            this.addFailure(new TestBase.Failure("failed expected: " + octalString + " actual: " + oct, w));
        } else {
            let hexMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(hex,hexString));
            if(!hexMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + hexString + " actual: " + hex, w));
            }
        }
        this.incrementTestCount();
    }

    testInetAtonCombos(w : IPAddressString, ipAddr : IPv4Address) {
        {
            let array143 = /* Enum.values */function() { let result: number[] = []; for(let val in IPv4Address.inet_aton_radix) { if(!isNaN(<any>val)) { result.push(parseInt(val,10)); } } return result; }();
            for(let index142=0; index142 < array143.length; index142++) {
                let radix = array143[index142];
                {
                    for(let i : number = 0; i < IPv4Address.SEGMENT_COUNT; i++) {
                        try {
                            let str : string = ipAddr.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix, i);
                            let parsed : IPAddressString = new IPAddressString(str, TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$());
                            try {
                                let parsedValue : IPAddress = parsed.getAddress();
                                if(!ipAddr.equals(parsedValue)) {
                                    this.addFailure(new TestBase.Failure("failed expected: " + ipAddr + " actual: " + parsedValue, w));
                                } else {
                                    let pos : number;
                                    let count : number = 0;
                                    while(((pos = str.indexOf(IPv4Address.SEGMENT_SEPARATOR)) >= 0)) {
                                        str = str.substring(pos + 1);
                                        count++;
                                    };
                                    if(IPv4Address.SEGMENT_COUNT - 1 - i !== count) {
                                        this.addFailure(new TestBase.Failure("failed expected separator count: " + (IPv4Address.SEGMENT_COUNT - 1 - i) + " actual separator count: " + count, w));
                                    }
                                }
                            } catch(e) {
                                this.addFailure(new TestBase.Failure("failed expected: " + ipAddr + " actual: " + e.message, w));
                            };
                        } catch(e) {
                            let section : IPv4AddressSection = ipAddr.getSection();
                            let verifiedIllegalJoin : boolean = false;
                            for(let j : number = section.getSegmentCount() - i - 1; j < section.getSegmentCount() - 1; j++) {
                                if(section.getSegment(j).isMultiple()) {
                                    for(j++; j < section.getSegmentCount(); j++) {
                                        if(!section.getSegment(j).isFullRange()) {
                                            verifiedIllegalJoin = true;
                                            break;
                                        }
                                    };
                                }
                            };
                            if(!verifiedIllegalJoin) {
                                this.addFailure(new TestBase.Failure("failed expected: " + ipAddr + " actual: " + e.message, w));
                            }
                        };
                        this.incrementTestCount();
                    };
                }
            }
        }
    }

    /**
     * 
     * @param {string} x
     * @return {IPAddressString}
     */
    createInetAtonAddress(x : string) : IPAddressString {
        let opts : IPAddressStringParameters;
        if(x.indexOf(IPAddress.RANGE_SEPARATOR) !== -1) {
            opts = TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$();
        } else {
            opts = IPAddressRangeTest.INET_ATON_WILDCARD_OPTS_$LI$();
        }
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, opts);
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        if(x.indexOf(IPAddress.RANGE_SEPARATOR) !== -1) {
            return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$());
        }
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$());
    }

    public createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(x : string, ipv4RangeOptions : AddressStringParameters.RangeParameters, ipv6RangeOptions : AddressStringParameters.RangeParameters) : IPAddressString {
        let validationOptions : IPAddressStringParameters = IPAddressRangeTest.getOpts$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(ipv4RangeOptions, ipv6RangeOptions);
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, validationOptions);
    }

    public createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ((ipv6RangeOptions != null && ipv6RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv6RangeOptions === null)) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions, ipv6RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>IPAddressStringParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'number') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    public static getOpts$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(ipv4RangeOptions : AddressStringParameters.RangeParameters, ipv6RangeOptions : AddressStringParameters.RangeParameters) : IPAddressStringParameters {
        let cacheIndex : number;
        let subCacheIndex : number;
        if(ipv4RangeOptions.equals(AddressStringParameters.RangeParameters.NO_RANGE_$LI$())) {
            cacheIndex = 0;
        } else if(ipv4RangeOptions.equals(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$())) {
            cacheIndex = 1;
        } else if(ipv4RangeOptions.equals(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$())) {
            cacheIndex = 2;
        } else {
            return IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getIPv4AddressParametersBuilder().setRangeOptions(ipv4RangeOptions).getParentBuilder().getIPv6AddressParametersBuilder().setRangeOptions(ipv6RangeOptions).getParentBuilder().toParams();
        }
        if(ipv6RangeOptions.equals(AddressStringParameters.RangeParameters.NO_RANGE_$LI$())) {
            subCacheIndex = 0;
        } else if(ipv6RangeOptions.equals(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$())) {
            subCacheIndex = 1;
        } else if(ipv6RangeOptions.equals(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$())) {
            subCacheIndex = 2;
        } else {
            return IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getIPv4AddressParametersBuilder().setRangeOptions(ipv4RangeOptions).getParentBuilder().getIPv6AddressParametersBuilder().setRangeOptions(ipv6RangeOptions).getParentBuilder().toParams();
        }
        let optionsSubCache : IPAddressStringParameters[] = IPAddressRangeTest.optionsCache_$LI$()[cacheIndex];
        let res : IPAddressStringParameters = optionsSubCache[subCacheIndex];
        if(res == null) {
            optionsSubCache[subCacheIndex] = res = IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getIPv4AddressParametersBuilder().setRangeOptions(ipv4RangeOptions).getParentBuilder().getIPv6AddressParametersBuilder().setRangeOptions(ipv6RangeOptions).getParentBuilder().toParams();
        }
        return res;
    }

    public static getOpts(ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ((ipv6RangeOptions != null && ipv6RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv6RangeOptions === null)) {
            return <any>IPAddressRangeTest.getOpts$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(ipv4RangeOptions, ipv6RangeOptions);
        } else if(((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>IPAddressRangeTest.getOpts$inet_ipaddr_AddressStringParameters_RangeParameters(ipv4RangeOptions);
        } else throw new Error('invalid overload');
    }

    /*private*/ static getOpts$inet_ipaddr_AddressStringParameters_RangeParameters(options : AddressStringParameters.RangeParameters) : IPAddressStringParameters {
        if(options.equals(AddressStringParameters.RangeParameters.NO_RANGE_$LI$())) {
            return IPAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS_$LI$();
        } else if(options.equals(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$())) {
            return IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$();
        } else if(options.equals(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$())) {
            return IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$();
        }
        return IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().setRangeOptions(options).toParams();
    }

    createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x : string, options : AddressStringParameters.RangeParameters) : IPAddressString {
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressRangeTest.getOpts$inet_ipaddr_AddressStringParameters_RangeParameters(options));
    }

    ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, ipv4RangeOptions : AddressStringParameters.RangeParameters, ipv6RangeOptions : AddressStringParameters.RangeParameters) {
        this.ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, false, ipv4RangeOptions, ipv6RangeOptions);
    }

    ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, rangeOptions : AddressStringParameters.RangeParameters) {
        this.ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, false, rangeOptions);
    }

    ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, rangeOptions : AddressStringParameters.RangeParameters) {
        this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, false, true, rangeOptions);
    }

    public ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, ipv4RangeOptions : AddressStringParameters.RangeParameters, ipv6RangeOptions : AddressStringParameters.RangeParameters) {
        this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, false, true, ipv4RangeOptions, ipv6RangeOptions);
    }

    public ipv4test(pass? : any, x? : any, isZero? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ((ipv6RangeOptions != null && ipv6RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv6RangeOptions === null)) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4RangeOptions, ipv6RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((isZero != null && isZero instanceof <any>AddressStringParameters.RangeParameters) || isZero === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4RangeOptions === 'boolean') || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean$boolean(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4RangeOptions === 'boolean') || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$inet_ipaddr_IPAddressString$boolean$boolean(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((isZero != null && isZero instanceof <any>AddressStringParameters.RangeParameters) || isZero === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$inet_ipaddr_IPAddressString$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, options : AddressStringParameters.RangeParameters) {
        this.ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, false, options);
    }

    ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, ipv4Options : AddressStringParameters.RangeParameters, ipv6Options : AddressStringParameters.RangeParameters) {
        this.ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, false, ipv4Options, ipv6Options);
    }

    ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, options : AddressStringParameters.RangeParameters) {
        this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, false, false, options);
    }

    public ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, ipv4Options : AddressStringParameters.RangeParameters, ipv6Options : AddressStringParameters.RangeParameters) {
        this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, false, false, ipv4Options, ipv6Options);
    }

    public ipv6test(pass? : any, x? : any, isZero? : any, ipv4Options? : any, ipv6Options? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((ipv4Options != null && ipv4Options instanceof <any>AddressStringParameters.RangeParameters) || ipv4Options === null) && ((ipv6Options != null && ipv6Options instanceof <any>AddressStringParameters.RangeParameters) || ipv6Options === null)) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4Options, ipv6Options);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((isZero != null && isZero instanceof <any>AddressStringParameters.RangeParameters) || isZero === null) && ((ipv4Options != null && ipv4Options instanceof <any>AddressStringParameters.RangeParameters) || ipv4Options === null) && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4Options);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((ipv4Options != null && ipv4Options instanceof <any>AddressStringParameters.RangeParameters) || ipv4Options === null) && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, ipv4Options);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4Options === 'boolean') || ipv4Options === null) && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean$boolean(pass, x, isZero, ipv4Options);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((isZero != null && isZero instanceof <any>AddressStringParameters.RangeParameters) || isZero === null) && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$int$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$int$java_lang_String(pass, x);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    public iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, notBoth : boolean, ipv4Test : boolean, ipv4RangeOptions : AddressStringParameters.RangeParameters, ipv6RangeOptions : AddressStringParameters.RangeParameters) {
        let addr : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions, ipv6RangeOptions);
        if(this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, addr, isZero, notBoth, ipv4Test)) {
            this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, addr, isZero, notBoth, ipv4Test);
        }
    }

    public iptest(pass? : any, x? : any, isZero? : any, notBoth? : any, ipv4Test? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof notBoth === 'boolean') || notBoth === null) && ((typeof ipv4Test === 'boolean') || ipv4Test === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ((ipv6RangeOptions != null && ipv6RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv6RangeOptions === null)) {
            return <any>this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, notBoth, ipv4Test, ipv4RangeOptions, ipv6RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof notBoth === 'boolean') || notBoth === null) && ((typeof ipv4Test === 'boolean') || ipv4Test === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass, x, isZero, notBoth, ipv4Test, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof notBoth === 'boolean') || notBoth === null) && ((typeof ipv4Test === 'boolean') || ipv4Test === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, x, isZero, notBoth, ipv4Test);
        } else throw new Error('invalid overload');
    }

    iptest$boolean$java_lang_String$boolean$boolean$boolean$inet_ipaddr_AddressStringParameters_RangeParameters(pass : boolean, x : string, isZero : boolean, notBoth : boolean, ipv4Test : boolean, rangeOptions : AddressStringParameters.RangeParameters) {
        let addr : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x, rangeOptions);
        if(this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, addr, isZero, notBoth, ipv4Test)) {
            this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, addr, isZero, notBoth, ipv4Test);
        }
    }

    public ipv6testWithZone$int$java_lang_String(pass : number, x : string) {
        return;
    }

    /**
     * 
     * @param {number} pass
     * @param {string} x
     */
    public ipv6testWithZone(pass? : any, x? : any) : any {
        if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null)) {
            return <any>this.ipv6testWithZone$int$java_lang_String(pass, x);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null)) {
            return <any>this.ipv6testWithZone$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    ipv6testWithZone$boolean$java_lang_String(pass : boolean, x : string) {
        return;
    }

    /**
     * 
     * @param {IPAddress} origAddr
     * @return {boolean}
     */
    testBytes(origAddr : IPAddress) : boolean {
        let failed : boolean = false;
        if(origAddr.isMultiple()) {
            try {
                origAddr.getBytes();
            } catch(e) {
                failed = true;
            };
        } else {
            failed = !super.testBytes(origAddr);
        }
        return !failed;
    }

    /**
     * 
     * @param {string} cidr2
     * @param {IPAddressString} w2
     */
    testMaskBytes(cidr2 : string, w2 : IPAddressString) {
        let addr : IPAddress = w2.toAddress();
        this.testBytes(addr);
    }

    testPrefixCount(original : string, number : number) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        IPAddressRangeTest.testPrefixCount(this, w, number);
    }

    static testPrefixCount(testBase : TestBase, w : HostIdentifierString, number : number) {
        let val : Address = w.getAddress();
        let isPrefixed : boolean = val.isPrefixed();
        let count : BigInteger = val.getPrefixCount();
        if(!count.equals(BigInteger.valueOf(number))) {
            testBase.addFailure(new TestBase.Failure("count was " + count + " instead of expected count " + number, w));
        } else {
            let addrIterator : any = val.prefixBlockIterator();
            let counter : number = 0;
            let set : Array<Address> = <any>([]);
            let next : Address = null;
            while((addrIterator.hasNext())) {
                next = addrIterator.next();
                if(isPrefixed?!next.isPrefixBlock():next.isPrefixBlock()) {
                    testBase.addFailure(new TestBase.Failure("not prefix block next: " + next, next));
                    break;
                }
                if(isPrefixed?!next.isSinglePrefixBlock():next.isPrefixBlock()) {
                    testBase.addFailure(new TestBase.Failure("not single prefix block next: " + next, next));
                    break;
                }
                /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, next);
                counter++;
            };
            if((number < Number.MAX_VALUE && /* size */(<number>set.length) !== number) || counter !== number) {
                testBase.addFailure(new TestBase.Failure("set count was " + /* size */(<number>set.length) + " instead of expected " + number, w));
            } else if(number < 0) {
                testBase.addFailure(new TestBase.Failure("unexpected zero count ", val));
            }
        }
        testBase.incrementTestCount();
    }

    public testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters(original : string, number : number, excludeZerosNumber : number, rangeOptions : AddressStringParameters.RangeParameters) {
        let w : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(original, rangeOptions);
        IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$long(this, w, number, excludeZerosNumber);
    }

    public testCount(original? : any, number? : any, excludeZerosNumber? : any, rangeOptions? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof number === 'number') || number === null) && ((typeof excludeZerosNumber === 'number') || excludeZerosNumber === null) && ((rangeOptions != null && rangeOptions instanceof <any>AddressStringParameters.RangeParameters) || rangeOptions === null)) {
            return <any>this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters(original, number, excludeZerosNumber, rangeOptions);
        } else if(((typeof original === 'string') || original === null) && ((number != null && number instanceof <any>BigInteger) || number === null) && ((excludeZerosNumber != null && excludeZerosNumber instanceof <any>BigInteger) || excludeZerosNumber === null) && rangeOptions === undefined) {
            return <any>this.testCount$java_lang_String$java_math_BigInteger$java_math_BigInteger(original, number, excludeZerosNumber);
        } else if(((typeof original === 'string') || original === null) && ((typeof number === 'number') || number === null) && ((typeof excludeZerosNumber === 'number') || excludeZerosNumber === null) && rangeOptions === undefined) {
            return <any>this.testCount$java_lang_String$long$long(original, number, excludeZerosNumber);
        } else throw new Error('invalid overload');
    }

    testCount$java_lang_String$long$long(original : string, number : number, excludeZerosNumber : number) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$long(this, w, number, excludeZerosNumber);
    }

    static testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$long(testBase : TestBase, w : HostIdentifierString, number : number, excludeZerosNumber : number) {
        IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$boolean(testBase, w, number, false);
        if(excludeZerosNumber >= 0) {
            IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$boolean(testBase, w, excludeZerosNumber, true);
        }
    }

    testCount$java_lang_String$java_math_BigInteger$java_math_BigInteger(original : string, number : BigInteger, excludeZerosNumber : BigInteger) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_IPAddressString$java_math_BigInteger$boolean(this, w, number, false);
        if(excludeZerosNumber.signum() !== -1) {
            IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_IPAddressString$java_math_BigInteger$boolean(this, w, excludeZerosNumber, true);
        }
    }

    public static testCount$inet_ipaddr_test_TestBase$inet_ipaddr_IPAddressString$java_math_BigInteger$boolean(testBase : TestBase, w : IPAddressString, number : BigInteger, excludeZeroHosts : boolean) {
        let val : IPAddress = w.getAddress();
        let count : BigInteger = excludeZeroHosts?val.getNonZeroHostCount():val.getCount();
        if(!count.equals(number)) {
            testBase.addFailure(new TestBase.Failure("big count was " + count, w));
        }
        testBase.incrementTestCount();
    }

    public static testCount(testBase? : any, w? : any, number? : any, excludeZeroHosts? : any) : any {
        if(((testBase != null && testBase instanceof <any>TestBase) || testBase === null) && ((w != null && w instanceof <any>IPAddressString) || w === null) && ((number != null && number instanceof <any>BigInteger) || number === null) && ((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_IPAddressString$java_math_BigInteger$boolean(testBase, w, number, excludeZeroHosts);
        } else if(((testBase != null && testBase instanceof <any>TestBase) || testBase === null) && ((w != null && (w["__interfaces"] != null && w["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || w.constructor != null && w.constructor["__interfaces"] != null && w.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || w === null) && ((typeof number === 'number') || number === null) && ((typeof excludeZeroHosts === 'number') || excludeZeroHosts === null)) {
            return <any>IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$long(testBase, w, number, excludeZeroHosts);
        } else if(((testBase != null && testBase instanceof <any>TestBase) || testBase === null) && ((w != null && (w["__interfaces"] != null && w["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || w.constructor != null && w.constructor["__interfaces"] != null && w.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || w === null) && ((typeof number === 'number') || number === null) && ((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$boolean(testBase, w, number, excludeZeroHosts);
        } else throw new Error('invalid overload');
    }

    static testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$boolean(testBase : TestBase, w : HostIdentifierString, number : number, excludeZeroHosts : boolean) {
        let val : Address = w.getAddress();
        let count : BigInteger = excludeZeroHosts?(<IPAddress>val).getNonZeroHostCount():val.getCount();
        if(!count.equals(BigInteger.valueOf(number))) {
            testBase.addFailure(new TestBase.Failure("count was " + count + " instead of expected count " + number, w));
        } else {
            let addrIterator : any = excludeZeroHosts?(<IPAddress>val).nonZeroHostIterator():val.iterator();
            let counter : number = 0;
            let set : Array<Address> = <any>([]);
            let next : Address = null;
            while((addrIterator.hasNext())) {
                next = addrIterator.next();
                if(counter === 0) {
                    let lower : Address = excludeZeroHosts?(<IPAddress>val).getLowerNonZeroHost():val.getLower();
                    if(!next.equals(lower)) {
                        testBase.addFailure(new TestBase.Failure("lowest: " + lower + " next: " + next, next));
                    }
                    if(!AddressNetwork.PrefixConfiguration["_$wrappers"][lower.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        if(!Objects.equals(next.getPrefixLength(), val.getPrefixLength())) {
                            testBase.addFailure(new TestBase.Failure("val prefix length: " + val.getPrefixLength() + " lowest prefix length: " + next.getPrefixLength(), next));
                        }
                        if(!Objects.equals(lower.getPrefixLength(), val.getPrefixLength())) {
                            testBase.addFailure(new TestBase.Failure("val prefix length: " + val.getPrefixLength() + " lowest prefix length: " + lower.getPrefixLength(), lower));
                        }
                    }
                } else if(counter === 1) {
                    if(!AddressNetwork.PrefixConfiguration["_$wrappers"][next.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        if(!Objects.equals(next.getPrefixLength(), val.getPrefixLength())) {
                            testBase.addFailure(new TestBase.Failure("val prefix length: " + val.getPrefixLength() + " next prefix length: " + next.getPrefixLength(), next));
                        }
                    }
                }
                /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, next);
                counter++;
            };
            if((number < Number.MAX_VALUE && /* size */(<number>set.length) !== number) || counter !== number) {
                testBase.addFailure(new TestBase.Failure("set count was " + /* size */(<number>set.length) + " instead of expected " + number, w));
            } else if(number > 0) {
                if(!next.equals(val.getUpper())) {
                    testBase.addFailure(new TestBase.Failure("highest: " + val.getUpper(), next));
                } else {
                    let lower : Address = excludeZeroHosts?(<IPAddress>val).getLowerNonZeroHost():val.getLower();
                    if(counter === 1 && !val.getUpper().equals(lower)) {
                        testBase.addFailure(new TestBase.Failure("highest: " + val.getUpper() + " lowest: " + val.getLower(), next));
                    }
                    if(!AddressNetwork.PrefixConfiguration["_$wrappers"][val.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        if(!Objects.equals(next.getPrefixLength(), val.getPrefixLength())) {
                            testBase.addFailure(new TestBase.Failure("val prefix length: " + val.getPrefixLength() + " upper prefix length: " + next.getPrefixLength(), next));
                        }
                        if(!Objects.equals(val.getUpper().getPrefixLength(), val.getPrefixLength())) {
                            testBase.addFailure(new TestBase.Failure("val prefix length: " + val.getPrefixLength() + " upper prefix length: " + val.getUpper().getPrefixLength(), next));
                        }
                    }
                }
            } else {
                if(excludeZeroHosts) {
                    let lower : IPAddress = (<IPAddress>val).getLowerNonZeroHost();
                    if(lower != null) {
                        testBase.addFailure(new TestBase.Failure("unexpected non-null lower: " + lower, val));
                    }
                } else {
                    testBase.addFailure(new TestBase.Failure("unexpected zero count ", val));
                }
            }
        }
        testBase.incrementTestCount();
    }

    testIPv4Wildcarded(original : string, bits : number, expected : string, expectedSQL : string) {
        this.testWildcarded(original, bits, expected, expected, expected, expected, expectedSQL);
    }

    testIPv6Wildcarded(original : string, bits : number, expectedSubnet : string, expectedNormalizedCompressedCanonical : string, expectedSQL : string) {
        let all : string = expectedNormalizedCompressedCanonical;
        this.testWildcarded(original, bits, expectedSubnet, all, all, all, expectedSQL);
    }

    testWildcarded(original : string, bits : number, expectedSubnet : string, expectedNormalized : string, expectedCanonical : string, expectedCompressed : string, expectedSQL : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let addr : IPAddress = w.getAddress();
        addr = addr.applyPrefixLength(bits);
        let string : string = addr.toCompressedWildcardString();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedCompressed))) {
            this.addFailure(new TestBase.Failure("failed expected: " + expectedCompressed + " actual: " + string, w));
        } else {
            let w2 : IPAddressString = this.createAddress$java_lang_String(original + '/' + bits);
            let addr2 : IPAddress = w2.getAddress();
            string = addr2.toCompressedWildcardString();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedCompressed))) {
                this.addFailure(new TestBase.Failure("failed expected: " + expectedCompressed + " actual: " + string, w));
            } else {
                string = addr.toNormalizedWildcardString();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedNormalized))) {
                    this.addFailure(new TestBase.Failure("failed expected: " + expectedNormalized + " actual: " + string, w));
                } else {
                    string = addr2.toNormalizedWildcardString();
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedNormalized))) {
                        this.addFailure(new TestBase.Failure("failed expected: " + expectedNormalized + " actual: " + string, w));
                    } else {
                        string = addr.toCanonicalWildcardString();
                        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedCanonical))) {
                            this.addFailure(new TestBase.Failure("failed expected: " + expectedCanonical + " actual: " + string, w));
                        } else {
                            string = addr.toSubnetString();
                            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedSubnet))) {
                                this.addFailure(new TestBase.Failure("failed expected: " + expectedSubnet + " actual: " + string, w));
                            } else {
                                string = addr2.toSubnetString();
                                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedSubnet))) {
                                    this.addFailure(new TestBase.Failure("failed expected: " + expectedSubnet + " actual: " + string, w));
                                } else {
                                    string = addr2.toSQLWildcardString();
                                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,expectedSQL))) {
                                        this.addFailure(new TestBase.Failure("failed expected: " + expectedSQL + " actual: " + string, w));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(addr : string, normalizedString : string, normalizedWildcardString : string, sqlString : string, fullString : string, octalString : string, hexString : string, reverseDNSString : string, singleHex : string, singleOctal : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(addr);
        let ipAddr : IPAddress = w.getAddress();
        this.testIPv4Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, sqlString, fullString, octalString, hexString, reverseDNSString, singleHex, singleOctal);
    }

    createList(str : IPAddressString) {
    }

    public testIPv6Strings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, compressedWildcardString? : any, mixedStringNoCompressMixed? : any, mixedStringNoCompressHost? : any, mixedStringCompressCoveredHost? : any, mixedString? : any, reverseDNSString? : any, uncHostString? : any, base85String? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof mixedStringNoCompressMixed === 'string') || mixedStringNoCompressMixed === null) && ((typeof mixedStringNoCompressHost === 'string') || mixedStringNoCompressHost === null) && ((typeof mixedStringCompressCoveredHost === 'string') || mixedStringCompressCoveredHost === null) && ((typeof mixedString === 'string') || mixedString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof base85String === 'string') || base85String === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testIPv6Strings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
        } else if(((typeof w === 'string') || w === null) && ((typeof ipAddr === 'string') || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof mixedStringNoCompressMixed === 'string') || mixedStringNoCompressMixed === null) && ((typeof mixedStringNoCompressHost === 'string') || mixedStringNoCompressHost === null) && ((typeof mixedStringCompressCoveredHost === 'string') || mixedStringCompressCoveredHost === null) && ((typeof mixedString === 'string') || mixedString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof base85String === 'string') || base85String === null) && ((typeof singleHex === 'string') || singleHex === null) && singleOctal === undefined) {
            return <any>this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex);
        } else throw new Error('invalid overload');
    }

    testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(addr : string, normalizedString : string, normalizedWildcardString : string, canonicalWildcardString : string, sqlString : string, fullString : string, compressedString : string, canonicalString : string, subnetString : string, compressedWildcardString : string, mixedStringNoCompressMixed : string, mixedStringNoCompressHost : string, mixedStringCompressCoveredHost : string, mixedString : string, reverseDNSString : string, uncHostString : string, base85String : string, singleHex : string, singleOctal : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(addr);
        let ipAddr : IPAddress = w.getAddress();
        this.testIPv6Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
    }

    testTree(start : string, parents : string[]) {
        let str : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(start, IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$());
        let originaLabelStr : IPAddressString = str;
        let labelStr : IPAddressString = str;
        let originalPrefixed : boolean = str.isPrefixed();
        if(!originalPrefixed) {
            let address : IPAddress = str.getAddress();
            address = address.assignPrefixForSingleBlock();
            str = address.toAddressString();
        }
        let original : IPAddressString = str;
        let i : number = 0;
        let last : IPAddressString;
        do {
            let label : string = IPAddressRangeTest.getLabel(labelStr);
            let expected : string = parents[i];
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(label,expected))) {
                this.addFailure(new TestBase.Failure("failed expected: " + expected + " actual: " + label, str));
                break;
            }
            last = str;
            labelStr = str = str.adjustPrefixBySegment(false);
            if(labelStr != null) {
                let labelAddr : IPAddress = labelStr.getAddress();
                if(labelAddr != null) {
                    let subnetAddr : IPAddress = labelAddr.toPrefixBlock$int(labelAddr.getNetworkPrefixLength());
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][labelAddr.getNetwork().getPrefixConfiguration()].prefixedSubnetsAreExplicit()) {
                        if(subnetAddr.isIPv4() && !originalPrefixed) {
                            labelStr = subnetAddr.toAddressString();
                        }
                    } else if(AddressNetwork.PrefixConfiguration["_$wrappers"][labelAddr.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && !labelAddr.equals(subnetAddr)) {
                        this.addFailure(new TestBase.Failure("not already a subnet " + labelAddr + " expected: " + subnetAddr, labelAddr));
                    }
                }
            }
            i++;
        } while((str != null && last !== str));
        labelStr = originaLabelStr;
        str = original;
        i = 0;
        do {
            let label : string = IPAddressRangeTest.getLabel(labelStr);
            let expected : string = parents[i];
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(label,expected))) {
                this.addFailure(new TestBase.Failure("failed expected: " + expected + " actual: " + label, str));
                break;
            }
            let labelAddr : IPAddress = str.getAddress().adjustPrefixBySegment$boolean(false);
            let subnetAddr : IPAddress = labelAddr.toPrefixBlock$int(labelAddr.getNetworkPrefixLength());
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][labelAddr.getNetwork().getPrefixConfiguration()].prefixedSubnetsAreExplicit()) {
                if(subnetAddr.isIPv4() && !originalPrefixed) {
                    labelAddr = subnetAddr;
                }
            } else if(labelAddr !== subnetAddr) {
            }
            labelStr = str = labelAddr.toAddressString();
            i++;
        } while((str.getNetworkPrefixLength() !== 0));
        this.incrementTestCount();
    }

    static getLabel(addressString : IPAddressString) : string {
        let address : IPAddress = addressString.getAddress();
        if(address == null) {
            return addressString.toString();
        }
        if(!address.isMultiple()) {
            return address.toPrefixLengthString();
        }
        return address.toSubnetString();
    }

    testTrees() {
        this.testTree("1.2.3.4", ["1.2.3.4", "1.2.3.*", "1.2.*.*", "1.*.*.*", "*.*.*.*", "*"]);
        this.testTree("1.2.3.*", ["1.2.3.*", "1.2.*.*", "1.*.*.*", "*.*.*.*", "*"]);
        this.testTree("1.2.*.*", ["1.2.*.*", "1.*.*.*", "*.*.*.*", "*"]);
        this.testTree("a:b:c:d:e:f:a:b", ["a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a::/112", "a:b:c:d:e:f::/96", "a:b:c:d:e::/80", "a:b:c:d::/64", "a:b:c::/48", "a:b::/32", "a::/16", "::/0", "*"]);
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        if(allPrefixesAreSubnets) {
            this.testTree("1.2.3.4/28", ["1.2.3.0-15", "1.2.3.*", "1.2.*.*", "1.*.*.*", "*.*.*.*", "*"]);
            this.testTree("1.2.3.4/17", ["1.2.0-127.*", "1.2.*.*", "1.*.*.*", "*.*.*.*", "*"]);
            this.testTree("a:b:c:d:e:f:a:b/97", ["a:b:c:d:e:f::/97", "a:b:c:d:e:f::/96", "a:b:c:d:e::/80", "a:b:c:d::/64", "a:b:c::/48", "a:b::/32", "a::/16", "::/0", "*"]);
            this.testTree("a:b:c:d:e:f:ffff:b/97", ["a:b:c:d:e:f:8000::/97", "a:b:c:d:e:f::/96", "a:b:c:d:e::/80", "a:b:c:d::/64", "a:b:c::/48", "a:b::/32", "a::/16", "::/0", "*"]);
            this.testTree("a:b:c:d:e:f:a:b/96", ["a:b:c:d:e:f::/96", "a:b:c:d:e::/80", "a:b:c:d::/64", "a:b:c::/48", "a:b::/32", "a::/16", "::/0", "*"]);
        } else {
            this.testTree("1.2.3.4/28", ["1.2.3.4/28", "1.2.3.4/24", "1.2.0.4/16", "1.0.0.4/8", "0.0.0.4/0"]);
            this.testTree("1.2.3.4/17", ["1.2.3.4/17", "1.2.3.4/16", "1.0.3.4/8", "0.0.3.4/0"]);
            this.testTree("a:b:c:d:e:f:a:b/97", ["a:b:c:d:e:f:a:b/97", "a:b:c:d:e:f:a:b/96", "a:b:c:d:e::a:b/80", "a:b:c:d::a:b/64", "a:b:c::a:b/48", "a:b::a:b/32", "a::a:b/16", "::a:b/0"]);
            this.testTree("a:b:c:d:e:f:ffff:b/97", ["a:b:c:d:e:f:ffff:b/97", "a:b:c:d:e:f:7fff:b/96", "a:b:c:d:e::7fff:b/80", "a:b:c:d::7fff:b/64", "a:b:c::7fff:b/48", "a:b::7fff:b/32", "a::7fff:b/16", "::7fff:b/0"]);
            this.testTree("a:b:c:d:e:f:a:b/96", ["a:b:c:d:e:f:a:b/96", "a:b:c:d:e::a:b/80", "a:b:c:d::a:b/64", "a:b:c::a:b/48", "a:b::a:b/32", "a::a:b/16", "::a:b/0"]);
        }
        this.testTree("a:b:c:d::a:b", ["a:b:c:d::a:b", "a:b:c:d:0:0:a::/112", "a:b:c:d::/96", "a:b:c:d::/80", "a:b:c:d::/64", "a:b:c::/48", "a:b::/32", "a::/16", "::/0", "*"]);
        this.testTree("::c:d:e:f:a:b", ["::c:d:e:f:a:b", "0:0:c:d:e:f:a::/112", "0:0:c:d:e:f::/96", "0:0:c:d:e::/80", "0:0:c:d::/64", "0:0:c::/48", "::/32", "::/16", "::/0", "*"]);
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testStrings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && ((typeof normalizedWildcardString === 'boolean') || normalizedWildcardString === null) && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString$boolean(w, ipAddr, normalizedString, normalizedWildcardString);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(w, ipAddr, normalizedString);
        } else if(w === undefined && ipAddr === undefined && normalizedString === undefined && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$();
        } else throw new Error('invalid overload');
    }

    testStrings$() {
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.4", "1.2.3.4", "1.2.3.4", "1.2.3.4", "001.002.003.004", "01.02.03.04", "0x1.0x2.0x3.0x4", "4.3.2.1.in-addr.arpa", "0x01020304", "000100401404");
        if(allPrefixesAreSubnets) {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.4/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
        } else {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.4/16", "1.2.3.4/16", "1.2.3.4", "1.2.3.4", "001.002.003.004/16", "01.02.03.04/16", "0x1.0x2.0x3.0x4/16", "4.3.2.1.in-addr.arpa", "0x01020304", "000100401404");
        }
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.*", "1.2.*.*", "1.2.*.*", "1.2.%.%", "001.002.000-255.000-255", "01.02.*.*", "0x1.0x2.*.*", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*", "1.2.*.*", "1.2.*.*", "1.2.%.%", "001.002.000-255.000-255", "01.02.*.*", "0x1.0x2.*.*", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
        if(isNoAutoSubnets) {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.*/16", "1.2.*.*/16", "1.2.*.*", "1.2.%.%", "001.002.000-255.000-255/16", "01.02.*.*/16", "0x1.0x2.*.*/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*/16", "1.2.*.*/16", "1.2.*.*", "1.2.%.%", "001.002.000-255.000-255/16", "01.02.*.*/16", "0x1.0x2.*.*/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.*.*/16", "1.*.*.*/16", "1.*.*.*", "1.%.%.%", "001.000-255.000-255.000-255/16", "01.*.*.*/16", "0x1.*.*.*/16", "*.*.*.1.in-addr.arpa", "0x01000000-0x01ffffff", "000100000000-000177777777");
        } else {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.*/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.*.*/16", "1.*.0.0/16", "1.*.*.*", "1.%.%.%", "001.000-255.000.000/16", "01.*.00.00/16", "0x1.*.0x0.0x0/16", "*.*.*.1.in-addr.arpa", "0x01000000-0x01ffffff", "000100000000-000177777777");
        }
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0.0.0.0", "0.0.0.0", "0.0.0.0", "0.0.0.0", "000.000.000.000", "00.00.00.00", "0x0.0x0.0x0.0x0", "0.0.0.0.in-addr.arpa", "0x00000000", "000000000000");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.127.254", "9.63.127.254", "9.63.127.254", "9.63.127.254", "009.063.127.254", "011.077.0177.0376", "0x9.0x3f.0x7f.0xfe", "254.127.63.9.in-addr.arpa", "0x093f7ffe", "001117677776");
        if(allPrefixesAreSubnets) {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.127.254/16", "9.63.0.0/16", "9.63.*.*", "9.63.%.%", "009.063.000.000/16", "011.077.00.00/16", "0x9.0x3f.0x0.0x0/16", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
        } else {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.127.254/16", "9.63.127.254/16", "9.63.127.254", "9.63.127.254", "009.063.127.254/16", "011.077.0177.0376/16", "0x9.0x3f.0x7f.0xfe/16", "254.127.63.9.in-addr.arpa", "0x093f7ffe", "001117677776");
        }
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*.*", "9.63.*.*", "9.63.*.*", "9.63.%.%", "009.063.000-255.000-255", "011.077.*.*", "0x9.0x3f.*.*", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*", "9.63.*.*", "9.63.*.*", "9.63.%.%", "009.063.000-255.000-255", "011.077.*.*", "0x9.0x3f.*.*", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
        if(isNoAutoSubnets) {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*.*/16", "9.63.*.*/16", "9.63.*.*", "9.63.%.%", "009.063.000-255.000-255/16", "011.077.*.*/16", "0x9.0x3f.*.*/16", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*/16", "9.63.*.*/16", "9.63.*.*", "9.63.%.%", "009.063.000-255.000-255/16", "011.077.*.*/16", "0x9.0x3f.*.*/16", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.*.*/16", "9.*.*.*/16", "9.*.*.*", "9.%.%.%", "009.000-255.000-255.000-255/16", "011.*.*.*/16", "0x9.*.*.*/16", "*.*.*.9.in-addr.arpa", "0x09000000-0x09ffffff", "001100000000-001177777777");
        } else {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*.*/16", "9.63.0.0/16", "9.63.*.*", "9.63.%.%", "009.063.000.000/16", "011.077.00.00/16", "0x9.0x3f.0x0.0x0/16", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.63.*/16", "9.63.0.0/16", "9.63.*.*", "9.63.%.%", "009.063.000.000/16", "011.077.00.00/16", "0x9.0x3f.0x0.0x0/16", "*.*.63.9.in-addr.arpa", "0x093f0000-0x093fffff", "001117600000-001117777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("9.*.*/16", "9.*.0.0/16", "9.*.*.*", "9.%.%.%", "009.000-255.000.000/16", "011.*.00.00/16", "0x9.*.0x0.0x0/16", "*.*.*.9.in-addr.arpa", "0x09000000-0x09ffffff", "001100000000-001177777777");
        }
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.250-255", "1.2.3.250-255", "1.2.3.250-255", "1.2.3.25_", "001.002.003.250-255", "01.02.03.0372-0377", "0x1.0x2.0x3.0xfa-0xff", "250-255.3.2.1.in-addr.arpa", "0x010203fa-0x010203ff", "000100401772-000100401777");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.200-255", "1.2.3.200-255", "1.2.3.200-255", "1.2.3.2__", "001.002.003.200-255", "01.02.03.0310-0377", "0x1.0x2.0x3.0xc8-0xff", "200-255.3.2.1.in-addr.arpa", "0x010203c8-0x010203ff", "000100401710-000100401777");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.100-199", "1.2.3.100-199", "1.2.3.100-199", "1.2.3.1__", "001.002.003.100-199", "01.02.03.0144-0307", "0x1.0x2.0x3.0x64-0xc7", "100-199.3.2.1.in-addr.arpa", "0x01020364-0x010203c7", "000100401544-000100401707");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("100-199.2.3.100-199", "100-199.2.3.100-199", "100-199.2.3.100-199", "1__.2.3.1__", "100-199.002.003.100-199", "0144-0307.02.03.0144-0307", "0x64-0xc7.0x2.0x3.0x64-0xc7", "100-199.3.2.100-199.in-addr.arpa", null, null);
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("100-199.2.3.100-198", "100-199.2.3.100-198", "100-199.2.3.100-198", "1__.2.3.100-198", "100-199.002.003.100-198", "0144-0307.02.03.0144-0306", "0x64-0xc7.0x2.0x3.0x64-0xc6", "100-198.3.2.100-199.in-addr.arpa", null, null);
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.0-99", "1.2.3.0-99", "1.2.3.0-99", "1.2.3.0-99", "001.002.003.000-099", "01.02.03.00-0143", "0x1.0x2.0x3.0x0-0x63", "0-99.3.2.1.in-addr.arpa", "0x01020300-0x01020363", "000100401400-000100401543");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.100-155", "1.2.3.100-155", "1.2.3.100-155", "1.2.3.100-155", "001.002.003.100-155", "01.02.03.0144-0233", "0x1.0x2.0x3.0x64-0x9b", "100-155.3.2.1.in-addr.arpa", "0x01020364-0x0102039b", "000100401544-000100401633");
        this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.100-255", "1.2.3.100-255", "1.2.3.100-255", "1.2.3.100-255", "001.002.003.100-255", "01.02.03.0144-0377", "0x1.0x2.0x3.0x64-0xff", "100-255.3.2.1.in-addr.arpa", "0x01020364-0x010203ff", "000100401544-000100401777");
        if(allPrefixesAreSubnets) {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.129-254.5.5/12", "1.128-240.0.0/12", "1.128-255.*.*", "1.128-255.%.%", "001.128-240.000.000/12", "01.0200-0360.00.00/12", "0x1.0x80-0xf0.0x0.0x0/12", "*.*.128-255.1.in-addr.arpa", "0x01800000-0x01ffffff", "000140000000-000177777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2__.5.5/14", "1.200-252.0.0/14", "1.200-255.*.*", "1.2__.%.%", "001.200-252.000.000/14", "01.0310-0374.00.00/14", "0x1.0xc8-0xfc.0x0.0x0/14", "*.*.200-255.1.in-addr.arpa", "0x01c80000-0x01ffffff", "000162000000-000177777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.*.5.5/12", "1.0-240.0.0/12", "1.*.*.*", "1.%.%.%", "001.000-240.000.000/12", "01.00-0360.00.00/12", "0x1.0x0-0xf0.0x0.0x0/12", "*.*.*.1.in-addr.arpa", "0x01000000-0x01ffffff", "000100000000-000177777777");
        } else {
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.129-254.5.5/12", "1.129-254.5.5/12", "1.129-254.5.5", "1.129-254.5.5", "001.129-254.005.005/12", "01.0201-0376.05.05/12", "0x1.0x81-0xfe.0x5.0x5/12", "5.5.129-254.1.in-addr.arpa", null, null);
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2__.5.5/14", "1.200-255.5.5/14", "1.200-255.5.5", "1.2__.5.5", "001.200-255.005.005/14", "01.0310-0377.05.05/14", "0x1.0xc8-0xff.0x5.0x5/14", "5.5.200-255.1.in-addr.arpa", null, null);
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.*.5.5/12", "1.*.5.5/12", "1.*.5.5", "1.%.5.5", "001.000-255.005.005/12", "01.*.05.05/12", "0x1.*.0x5.0x5/12", "5.5.*.1.in-addr.arpa", null, null);
        }
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::", "0:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:0", "::", "0:0:0:0:0:0:0:0", "0000:0000:0000:0000:0000:0000:0000:0000", "::", "::", "::", "::", "::0.0.0.0", "::", "::", "::", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-0-0-0-0-0.ipv6-literal.net", "00000000000000000000", "0x00000000000000000000000000000000", "00000000000000000000000000000000000000000000");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::2", "0:0:0:0:0:0:0:2", "0:0:0:0:0:0:0:2", "::2", "0:0:0:0:0:0:0:2", "0000:0000:0000:0000:0000:0000:0000:0002", "::2", "::2", "::2", "::2", "::0.0.0.2", "::0.0.0.2", "::0.0.0.2", "::0.0.0.2", "2.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-0-0-0-0-2.ipv6-literal.net", "00000000000000000002", "0x00000000000000000000000000000002", "00000000000000000000000000000000000000000002");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::7fff:ffff:ffff:ffff", "0:0:0:0:7fff:ffff:ffff:ffff", "0:0:0:0:7fff:ffff:ffff:ffff", "::7fff:ffff:ffff:ffff", "0:0:0:0:7fff:ffff:ffff:ffff", "0000:0000:0000:0000:7fff:ffff:ffff:ffff", "::7fff:ffff:ffff:ffff", "::7fff:ffff:ffff:ffff", "::7fff:ffff:ffff:ffff", "::7fff:ffff:ffff:ffff", "::7fff:ffff:255.255.255.255", "::7fff:ffff:255.255.255.255", "::7fff:ffff:255.255.255.255", "::7fff:ffff:255.255.255.255", "f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.7.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-0-7fff-ffff-ffff-ffff.ipv6-literal.net", "0000000000d*-h_{Y}sg", "0x00000000000000007fffffffffffffff", "00000000000000000000000777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0:0:0:1::", "0:0:0:1:0:0:0:0", "0:0:0:1:0:0:0:0", "0:0:0:1::", "0:0:0:1:0:0:0:0", "0000:0000:0000:0001:0000:0000:0000:0000", "0:0:0:1::", "0:0:0:1::", "0:0:0:1::", "0:0:0:1::", "::1:0:0:0.0.0.0", "0:0:0:1::", "0:0:0:1::", "0:0:0:1::", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-1-0-0-0-0.ipv6-literal.net", "0000000000_sw2=@*|O1", "0x00000000000000010000000000000000", "00000000000000000000002000000000000000000000");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::8fff:ffff:ffff:ffff", "0:0:0:0:8fff:ffff:ffff:ffff", "0:0:0:0:8fff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff", "0:0:0:0:8fff:ffff:ffff:ffff", "0000:0000:0000:0000:8fff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff", "::8fff:ffff:255.255.255.255", "::8fff:ffff:255.255.255.255", "::8fff:ffff:255.255.255.255", "::8fff:ffff:255.255.255.255", "f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.8.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-0-8fff-ffff-ffff-ffff.ipv6-literal.net", "0000000000i(`c)xypow", "0x00000000000000008fffffffffffffff", "00000000000000000000001077777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::8fff:ffff:ffff:ffff:ffff", "0:0:0:8fff:ffff:ffff:ffff:ffff", "0:0:0:8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff:ffff", "0:0:0:8fff:ffff:ffff:ffff:ffff", "0000:0000:0000:8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:ffff:ffff", "::8fff:ffff:ffff:255.255.255.255", "::8fff:ffff:ffff:255.255.255.255", "::8fff:ffff:ffff:255.255.255.255", "::8fff:ffff:ffff:255.255.255.255", "f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.8.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-8fff-ffff-ffff-ffff-ffff.ipv6-literal.net", "00000004&U-n{rbbza$w", "0x0000000000008fffffffffffffffffff", "00000000000000000217777777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "000a:000b:000c:000d:000e:000f:000a:000b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:0.10.0.11", "a:b:c:d:e:f:0.10.0.11", "a:b:c:d:e:f:0.10.0.11", "a:b:c:d:e:f:0.10.0.11", "b.0.0.0.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-e-f-a-b.ipv6-literal.net", "00|N0s0$ND2DCD&%D3QB", "0x000a000b000c000d000e000f000a000b", "00000240001300006000032000160000740002400013");
        if(allPrefixesAreSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:e:f:a:b/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d:*:*:*:*", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::c:d:e:f:a:b/64", "0:0:c:d:0:0:0:0/64", "0:0:c:d:*:*:*:*", "::c:d:*:*:*:*", "0:0:c:d:%:%:%:%", "0000:0000:000c:000d:0000:0000:0000:0000/64", "0:0:c:d::/64", "0:0:c:d::/64", "0:0:c:d::/64", "::c:d:*:*:*:*", "::c:d:0:0:0.0.0.0/64", "::c:d:0:0:0.0.0.0/64", "0:0:c:d::/64", "0:0:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-c-d-0-0-0-0.ipv6-literal.net/64", "0000001G~Ie?xF;x&)@P/64", "0x00000000000c000d0000000000000000-0x00000000000c000dffffffffffffffff", "00000000000000006000032000000000000000000000-00000000000000006000033777777777777777777777");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:e:f:a:b/64", "a:b:c:d:e:f:a:b/64", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", "000a:000b:000c:000d:000e:000f:000a:000b/64", "a:b:c:d:e:f:a:b/64", "a:b:c:d:e:f:a:b/64", "a:b:c:d:e:f:a:b/64", "a:b:c:d:e:f:a:b", "a:b:c:d:e:f:0.10.0.11/64", "a:b:c:d:e:f:0.10.0.11/64", "a:b:c:d:e:f:0.10.0.11/64", "a:b:c:d:e:f:0.10.0.11/64", "b.0.0.0.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-e-f-a-b.ipv6-literal.net/64", "00|N0s0$ND2DCD&%D3QB/64", "0x000a000b000c000d000e000f000a000b", "00000240001300006000032000160000740002400013");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::c:d:e:f:a:b/64", "0:0:c:d:e:f:a:b/64", "0:0:c:d:e:f:a:b", "::c:d:e:f:a:b", "0:0:c:d:e:f:a:b", "0000:0000:000c:000d:000e:000f:000a:000b/64", "::c:d:e:f:a:b/64", "::c:d:e:f:a:b/64", "::c:d:e:f:a:b/64", "::c:d:e:f:a:b", "::c:d:e:f:0.10.0.11/64", "::c:d:e:f:0.10.0.11/64", "::c:d:e:f:0.10.0.11/64", "::c:d:e:f:0.10.0.11/64", "b.0.0.0.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-c-d-e-f-a-b.ipv6-literal.net/64", "0000001G~Ie^C9jXExx>/64", "0x00000000000c000d000e000f000a000b", "00000000000000006000032000160000740002400013");
        }
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("::c:d:e:f:a:b", "0:0:c:d:e:f:a:b", "0:0:c:d:e:f:a:b", "::c:d:e:f:a:b", "0:0:c:d:e:f:a:b", "0000:0000:000c:000d:000e:000f:000a:000b", "::c:d:e:f:a:b", "::c:d:e:f:a:b", "::c:d:e:f:a:b", "::c:d:e:f:a:b", "::c:d:e:f:0.10.0.11", "::c:d:e:f:0.10.0.11", "::c:d:e:f:0.10.0.11", "::c:d:e:f:0.10.0.11", "b.0.0.0.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-c-d-e-f-a-b.ipv6-literal.net", "0000001G~Ie^C9jXExx>", "0x00000000000c000d000e000f000a000b", "00000000000000006000032000160000740002400013");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d::", "a:b:c:d:0:0:0:0", "a:b:c:d:0:0:0:0", "a:b:c:d::", "a:b:c:d:0:0:0:0", "000a:000b:000c:000d:0000:0000:0000:0000", "a:b:c:d::", "a:b:c:d::", "a:b:c:d::", "a:b:c:d::", "a:b:c:d::0.0.0.0", "a:b:c:d::", "a:b:c:d::", "a:b:c:d::", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net", "00|N0s0$ND2BxK96%Chk", "0x000a000b000c000d0000000000000000", "00000240001300006000032000000000000000000000");
        if(isNoAutoSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d::/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:0:0:0:0", "a:b:c:d::", "a:b:c:d:0:0:0:0", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000", "00000240001300006000032000000000000000000000");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d::/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d:*:*:*:*", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
        }
        if(allPrefixesAreSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*/65", "a:0:0:d:0-8000:0:0:0/65", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-8000:0000:0000:0000/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a::d:*:*:*:*", "a::d:0-8000:0:0.0.0.0/65", "a::d:0-8000:0:0.0.0.0/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0" + Address.ALTERNATIVE_RANGE_SEPARATOR + "8000-0-0-0.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt+;M72aZe}L&/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:0:0:0/65", "a:0:0:d:0-8000:0:0:0/65", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-8000:0000:0000:0000/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a::d:*:*:*:*", "a::d:0-8000:0:0.0.0.0/65", "a::d:0-8000:0:0.0.0.0/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "8000-0-0-0.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt+;M72aZe}L&/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*::/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d:*:*:*:*", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
        } else {
            if(isNoAutoSubnets) {
                this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*/65", "a:0:0:d:*:*:*:*/65", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff/65", "a::d:*:*:*:*/65", "a::d:*:*:*:*/65", "a::d:*:*:*:*/65", "a::d:*:*:*:*", "a::d:*:*:*.*.*.*/65", "a::d:*:*:*.*.*.*/65", "a::d:*:*:*.*.*.*/65", "a::d:*:*:*.*.*.*/65", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-*-*-*-*.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
                this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:0:*:*:*/65", "a:0:0:d:0:*:*:*/65", "a:0:0:d:0:*:*:*", "a::d:0:*:*:*", "a:0:0:d:0:%:%:%", "000a:0000:0000:000d:0000:0000-ffff:0000-ffff:0000-ffff/65", "a::d:0:*:*:*/65", "a::d:0:*:*:*/65", "a:0:0:d::*:*:*/65", "a::d:0:*:*:*", "a::d:0:*:*.*.*.*/65", "a::d:0:*:*.*.*.*/65", "a::d:0:*:*.*.*.*/65", "a::d:0:*:*.*.*.*/65", "*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0-*-*-*.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt+WbTO)+bn+N/65", "0x000a00000000000d0000000000000000-0x000a00000000000d0000ffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000032000007777777777777777");
            } else {
                this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*/65", "a:0:0:d:0-8000:0:0:0/65", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-8000:0000:0000:0000/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "a::d:*:*:*:*", "a::d:0-8000:0:0.0.0.0/65", "a::d:0-8000:0:0.0.0.0/65", "a:0:0:d:0-8000::/65", "a:0:0:d:0-8000::/65", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "8000-0-0-0.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt+;M72aZe}L&/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
                this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:0:*:*:*/65", "a:0:0:d:0:0:0:0/65", "a:0:0:d:0-7fff:*:*:*", "a::d:0-7fff:*:*:*", "a:0:0:d:0-7fff:%:%:%", "000a:0000:0000:000d:0000:0000:0000:0000/65", "a:0:0:d::/65", "a:0:0:d::/65", "a:0:0:d::/65", "a::d:0-7fff:*:*:*", "a::d:0:0:0.0.0.0/65", "a::d:0:0:0.0.0.0/65", "a:0:0:d::/65", "a:0:0:d::/65", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.0-7.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0-0-0-0.ipv6-literal.net/65", "00|M>t|tt+WbKhfd5~qN/65", "0x000a00000000000d0000000000000000-0x000a00000000000d7fffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000032777777777777777777777");
            }
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:0/65", "a:0:0:d:*:*:*:0/65", "a:0:0:d:*:*:*:0", "a::d:*:*:*:0", "a:0:0:d:%:%:%:0", "000a:0000:0000:000d:0000-ffff:0000-ffff:0000-ffff:0000/65", "a::d:*:*:*:0/65", "a::d:*:*:*:0/65", "a:0:0:d:*:*:*::/65", "a::d:*:*:*:0", "a::d:*:*:*.*.0.0/65", "a::d:*:*:*.*.0.0/65", "a::d:*:*:*.*.0.0/65", "a::d:*:*:*.*.0.0/65", "0.0.0.0.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-*-*-*-0.ipv6-literal.net/65", null, null, null);
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:0:*:0:*/65", "a:0:0:d:0:*:0:*/65", "a:0:0:d:0:*:0:*", "a::d:0:*:0:*", "a:0:0:d:0:%:0:%", "000a:0000:0000:000d:0000:0000-ffff:0000:0000-ffff/65", "a::d:0:*:0:*/65", "a::d:0:*:0:*/65", "a:0:0:d:0:*::*/65", "a::d:0:*:0:*", "a::d:0:*:0.0.*.*/65", "a::d:0:*:0.0.*.*/65", "a::d:0:*:0.0.*.*/65", "a::d:0:*:0.0.*.*/65", "*.*.*.*.0.0.0.0.*.*.*.*.0.0.0.0.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0-*-0-*.ipv6-literal.net/65", null, null, null);
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:0:0:0/65", "a:0:0:d:*:0:0:0/65", "a:0:0:d:*:0:0:0", "a:0:0:d:*::", "a:0:0:d:%:0:0:0", "000a:0000:0000:000d:0000-ffff:0000:0000:0000/65", "a:0:0:d:*::/65", "a:0:0:d:*::/65", "a:0:0:d:*::/65", "a:0:0:d:*::", "a::d:*:0:0.0.0.0/65", "a::d:*:0:0.0.0.0/65", "a:0:0:d:*::/65", "a:0:0:d:*::/65", "0.0.0.0.0.0.0.0.0.0.0.0.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-*-0-0-0.ipv6-literal.net/65", null, null, null);
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*::/64", "a:b:c:d:*:0:0:0/64", "a:b:c:d:*:0:0:0", "a:b:c:d:*::", "a:b:c:d:%:0:0:0", "000a:000b:000c:000d:0000-ffff:0000:0000:0000/64", "a:b:c:d:*::/64", "a:b:c:d:*::/64", "a:b:c:d:*::/64", "a:b:c:d:*::", "a:b:c:d:*::0.0.0.0/64", "a:b:c:d:*::0.0.0.0/64", "a:b:c:d:*::/64", "a:b:c:d:*::/64", "0.0.0.0.0.0.0.0.0.0.0.0.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-*-0-0-0.ipv6-literal.net/64", null, null, null);
        }
        if(isNoAutoSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:*::/64", "a:b:c:*:0:0:0:0/64", "a:b:c:*:0:0:0:0", "a:b:c:*::", "a:b:c:%:0:0:0:0", "000a:000b:000c:0000-ffff:0000:0000:0000:0000/64", "a:b:c:*::/64", "a:b:c:*::/64", "a:b:c:*::/64", "a:b:c:*::", "a:b:c:*::0.0.0.0/64", "a:b:c:*::0.0.0.0/64", "a:b:c:*::/64", "a:b:c:*::/64", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.*.*.*.*.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-*-0-0-0-0.ipv6-literal.net/64", null, null, null);
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::/64", "a:0:0:0:0:0:0:0/64", "a:0:0:0:0:0:0:0", "a::", "a:0:0:0:0:0:0:0", "000a:0000:0000:0000:0000:0000:0000:0000/64", "a::/64", "a::/64", "a::/64", "a::", "a::0.0.0.0/64", "a::0.0.0.0/64", "a::/64", "a::/64", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-0-0-0.ipv6-literal.net/64", "00|M>t|ttwH6V62lVY`A/64", "0x000a0000000000000000000000000000", "00000240000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:0:d:e:f:0:0/112", "a:0:0:d:e:f:0:0/112", "a:0:0:d:e:f:0:0", "a::d:e:f:0:0", "a:0:0:d:e:f:0:0", "000a:0000:0000:000d:000e:000f:0000:0000/112", "a::d:e:f:0:0/112", "a::d:e:f:0:0/112", "a:0:0:d:e:f::/112", "a::d:e:f:0:0", "a::d:e:f:0.0.0.0/112", "a::d:e:f:0.0.0.0/112", "a::d:e:f:0.0.0.0/112", "a:0:0:d:e:f::/112", "0.0.0.0.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-e-f-0-0.ipv6-literal.net/112", "00|M>t|tt+WcwbECb*xq/112", "0x000a00000000000d000e000f00000000", "00000240000000000000032000160000740000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/112", "a:0:c:d:e:f:0:0/112", "a:0:c:d:e:f:0:0", "a:0:c:d:e:f::", "a:0:c:d:e:f:0:0", "000a:0000:000c:000d:000e:000f:0000:0000/112", "a:0:c:d:e:f::/112", "a:0:c:d:e:f::/112", "a:0:c:d:e:f::/112", "a:0:c:d:e:f::", "a::c:d:e:f:0.0.0.0/112", "a::c:d:e:f:0.0.0.0/112", "a::c:d:e:f:0.0.0.0/112", "a:0:c:d:e:f::/112", "0.0.0.0.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`j3_$/112", "0x000a0000000c000d000e000f00000000", "00000240000000006000032000160000740000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/97", "a:0:c:d:e:f:0:0/97", "a:0:c:d:e:f:0:0", "a:0:c:d:e:f::", "a:0:c:d:e:f:0:0", "000a:0000:000c:000d:000e:000f:0000:0000/97", "a:0:c:d:e:f::/97", "a:0:c:d:e:f::/97", "a:0:c:d:e:f::/97", "a:0:c:d:e:f::", "a::c:d:e:f:0.0.0.0/97", "a::c:d:e:f:0.0.0.0/97", "a::c:d:e:f:0.0.0.0/97", "a:0:c:d:e:f::/97", "0.0.0.0.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/97", "00|M>t};s?v~hFl`j3_$/97", "0x000a0000000c000d000e000f00000000", "00000240000000006000032000160000740000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/96", "a:0:c:d:e:f:0:0/96", "a:0:c:d:e:f:0:0", "a:0:c:d:e:f::", "a:0:c:d:e:f:0:0", "000a:0000:000c:000d:000e:000f:0000:0000/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::", "a::c:d:e:f:0.0.0.0/96", "a::c:d:e:f:0.0.0.0/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "0.0.0.0.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/96", "00|M>t};s?v~hFl`j3_$/96", "0x000a0000000c000d000e000f00000000", "00000240000000006000032000160000740000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1:0", "a:0:c:d:e:f:1:0", "a:0:c:d:e:f:1:0", "000a:0000:000c:000d:000e:000f:0001:0000/112", "a::c:d:e:f:1:0/112", "a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1::/112", "a::c:d:e:f:1:0", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "0.0.0.0.1.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-1-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`jD0%/112", "0x000a0000000c000d000e000f00010000", "00000240000000006000032000160000740000200000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:0:0:1:0/112", "a:0:c:d:0:0:1:0/112", "a:0:c:d:0:0:1:0", "a:0:c:d::1:0", "a:0:c:d:0:0:1:0", "000a:0000:000c:000d:0000:0000:0001:0000/112", "a:0:c:d::1:0/112", "a:0:c:d::1:0/112", "a:0:c:d:0:0:1::/112", "a:0:c:d::1:0", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "0.0.0.0.1.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-0-0-1-0.ipv6-literal.net/112", "00|M>t};s?v}5L>MDR^a/112", "0x000a0000000c000d0000000000010000", "00000240000000006000032000000000000000200000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a:0", "a:0:c:d:e:f:a:0", "a:0:c:d:e:f:a:0", "000a:0000:000c:000d:000e:000f:000a:0000/112", "a::c:d:e:f:a:0/112", "a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a::/112", "a::c:d:e:f:a:0", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "0.0.0.0.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-a-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`k9s=/112", "0x000a0000000c000d000e000f000a0000", "00000240000000006000032000160000740002400000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:0:0:0:100/120", "a:0:c:d:0:0:0:100/120", "a:0:c:d:0:0:0:100", "a:0:c:d::100", "a:0:c:d:0:0:0:100", "000a:0000:000c:000d:0000:0000:0000:0100/120", "a:0:c:d::100/120", "a:0:c:d::100/120", "a:0:c:d::100/120", "a:0:c:d::100", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "0.0.1.0.0.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-0-0-0-100.ipv6-literal.net/120", "00|M>t};s?v}5L>MDI>a/120", "0x000a0000000c000d0000000000000100", "00000240000000006000032000000000000000000400");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-*-*-*-*.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "a:b:c:d:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-*-*-*-*.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*/64", "a:0:0:d:*:*:*:*/64", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "a::d:*:*:*:*/64", "a::d:*:*:*:*/64", "a::d:*:*:*:*/64", "a::d:*:*:*:*", "a::d:*:*:*.*.*.*/64", "a::d:*:*:*.*.*.*/64", "a::d:*:*:*.*.*.*/64", "a::d:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-*-*-*-*.ipv6-literal.net/64", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N/64", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1::/32", "1:0:0:0:0:0:0:0/32", "1:0:0:0:0:0:0:0", "1::", "1:0:0:0:0:0:0:0", "0001:0000:0000:0000:0000:0000:0000:0000/32", "1::/32", "1::/32", "1::/32", "1::", "1::0.0.0.0/32", "1::0.0.0.0/32", "1::/32", "1::/32", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.1.0.0.0.ip6.arpa", "1-0-0-0-0-0-0-0.ipv6-literal.net/32", "008JOm8Mm5*yBppL!sg1/32", "0x00010000000000000000000000000000", "00000020000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/104", "ffff:0:0:0:0:0:0:0/104", "ffff:0:0:0:0:0:0:0", "ffff::", "ffff:0:0:0:0:0:0:0", "ffff:0000:0000:0000:0000:0000:0000:0000/104", "ffff::/104", "ffff::/104", "ffff::/104", "ffff::", "ffff::0.0.0.0/104", "ffff::0.0.0.0/104", "ffff::0.0.0.0/104", "ffff::/104", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/104", "=q{+M|w0(OeO5^EGP660/104", "0xffff0000000000000000000000000000", "03777760000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/108", "ffff:0:0:0:0:0:0:0/108", "ffff:0:0:0:0:0:0:0", "ffff::", "ffff:0:0:0:0:0:0:0", "ffff:0000:0000:0000:0000:0000:0000:0000/108", "ffff::/108", "ffff::/108", "ffff::/108", "ffff::", "ffff::0.0.0.0/108", "ffff::0.0.0.0/108", "ffff::0.0.0.0/108", "ffff::/108", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^EGP660/108", "0xffff0000000000000000000000000000", "03777760000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::1000:0/108", "ffff:0:0:0:0:0:1000:0/108", "ffff:0:0:0:0:0:1000:0", "ffff::1000:0", "ffff:0:0:0:0:0:1000:0", "ffff:0000:0000:0000:0000:0000:1000:0000/108", "ffff::1000:0/108", "ffff::1000:0/108", "ffff:0:0:0:0:0:1000::/108", "ffff::1000:0", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "0.0.0.0.0.0.0.1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-1000-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^ELbE%G/108", "0xffff0000000000000000000010000000", "03777760000000000000000000000000002000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::a000:0/108", "ffff:0:0:0:0:0:a000:0/108", "ffff:0:0:0:0:0:a000:0", "ffff::a000:0", "ffff:0:0:0:0:0:a000:0", "ffff:0000:0000:0000:0000:0000:a000:0000/108", "ffff::a000:0/108", "ffff::a000:0/108", "ffff:0:0:0:0:0:a000::/108", "ffff::a000:0", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "0.0.0.0.0.0.0.a.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-a000-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^E(z82>/108", "0xffff00000000000000000000a0000000", "03777760000000000000000000000000024000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/107", "ffff:0:0:0:0:0:0:0/107", "ffff:0:0:0:0:0:0:0", "ffff::", "ffff:0:0:0:0:0:0:0", "ffff:0000:0000:0000:0000:0000:0000:0000/107", "ffff::/107", "ffff::/107", "ffff::/107", "ffff::", "ffff::0.0.0.0/107", "ffff::0.0.0.0/107", "ffff::0.0.0.0/107", "ffff::/107", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/107", "=q{+M|w0(OeO5^EGP660/107", "0xffff0000000000000000000000000000", "03777760000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("abcd::/107", "abcd:0:0:0:0:0:0:0/107", "abcd:0:0:0:0:0:0:0", "abcd::", "abcd:0:0:0:0:0:0:0", "abcd:0000:0000:0000:0000:0000:0000:0000/107", "abcd::/107", "abcd::/107", "abcd::/107", "abcd::", "abcd::0.0.0.0/107", "abcd::0.0.0.0/107", "abcd::0.0.0.0/107", "abcd::/107", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.d.c.b.a.ip6.arpa", "abcd-0-0-0-0-0-0-0.ipv6-literal.net/107", "o6)n`s#^$cP5&p^H}p=a/107", "0xabcd0000000000000000000000000000", "02536320000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::/80", "1:2:3:4:0:0:0:0/80", "1:2:3:4:0:0:0:0", "1:2:3:4::", "1:2:3:4:0:0:0:0", "0001:0002:0003:0004:0000:0000:0000:0000/80", "1:2:3:4::/80", "1:2:3:4::/80", "1:2:3:4::/80", "1:2:3:4::", "1:2:3:4::0.0.0.0/80", "1:2:3:4::0.0.0.0/80", "1:2:3:4::/80", "1:2:3:4::/80", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0.ipv6-literal.net/80", "008JQWOV7Skb)C|ve)jA/80", "0x00010002000300040000000000000000", "00000020000200001400010000000000000000000000");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/97", "a:0:c:d:e:f:0:0/97", "a:0:c:d:e:f:0-7fff:*", "a:0:c:d:e:f:0-7fff:*", "a:0:c:d:e:f:0-7fff:%", "000a:0000:000c:000d:000e:000f:0000:0000/97", "a:0:c:d:e:f::/97", "a:0:c:d:e:f::/97", "a:0:c:d:e:f::/97", "a::c:d:e:f:0-7fff:*", "a::c:d:e:f:0.0.0.0/97", "a::c:d:e:f:0.0.0.0/97", "a::c:d:e:f:0.0.0.0/97", "a:0:c:d:e:f::/97", "*.*.*.*.*.*.*.0-7.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/97", "00|M>t};s?v~hFl`j3_$/97", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000f7fffffff", "00000240000000006000032000160000740000000000-00000240000000006000032000160000757777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/96", "a:0:c:d:e:f:0:0/96", "a:0:c:d:e:f:*:*", "a:0:c:d:e:f:*:*", "a:0:c:d:e:f:%:%", "000a:0000:000c:000d:000e:000f:0000:0000/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "a::c:d:e:f:*:*", "a::c:d:e:f:0.0.0.0/96", "a::c:d:e:f:0.0.0.0/96", "a:0:c:d:e:f::/96", "a:0:c:d:e:f::/96", "*.*.*.*.*.*.*.*.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/96", "00|M>t};s?v~hFl`j3_$/96", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000fffffffff", "00000240000000006000032000160000740000000000-00000240000000006000032000160000777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1:*", "a:0:c:d:e:f:1:*", "a:0:c:d:e:f:1:%", "000a:0000:000c:000d:000e:000f:0001:0000/112", "a::c:d:e:f:1:0/112", "a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1::/112", "a::c:d:e:f:1:*", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:0.1.0.0/112", "*.*.*.*.1.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-1-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`jD0%/112", "0x000a0000000c000d000e000f00010000-0x000a0000000c000d000e000f0001ffff", "00000240000000006000032000160000740000200000-00000240000000006000032000160000740000377777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:0:0:1:0/112", "a:0:c:d:0:0:1:0/112", "a:0:c:d:0:0:1:*", "a:0:c:d::1:*", "a:0:c:d:0:0:1:%", "000a:0000:000c:000d:0000:0000:0001:0000/112", "a:0:c:d::1:0/112", "a:0:c:d::1:0/112", "a:0:c:d:0:0:1::/112", "a:0:c:d::1:*", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "a:0:c:d::0.1.0.0/112", "*.*.*.*.1.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-0-0-1-0.ipv6-literal.net/112", "00|M>t};s?v}5L>MDR^a/112", "0x000a0000000c000d0000000000010000-0x000a0000000c000d000000000001ffff", "00000240000000006000032000000000000000200000-00000240000000006000032000000000000000377777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:*::/64", "a:b:c:*:0:0:0:0/64", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:%:%:%:%:%", "000a:000b:000c:0000-ffff:0000:0000:0000:0000/64", "a:b:c:*::/64", "a:b:c:*::/64", "a:b:c:*::/64", "a:b:c:*:*:*:*:*", "a:b:c:*::0.0.0.0/64", "a:b:c:*::0.0.0.0/64", "a:b:c:*::/64", "a:b:c:*::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-*-0-0-0-0.ipv6-literal.net/64", "00|N0s0$N0-%*(tF5l-X" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0;%Z;E{Rk+ZU@X/64", "0x000a000b000c00000000000000000000-0x000a000b000cffffffffffffffffffff", "00000240001300006000000000000000000000000000-00000240001300006377777777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::/64", "a:0:0:0:0:0:0:0/64", "a:0:0:0:*:*:*:*", "a::*:*:*:*", "a:0:0:0:%:%:%:%", "000a:0000:0000:0000:0000:0000:0000:0000/64", "a::/64", "a::/64", "a::/64", "a::*:*:*:*", "a::0.0.0.0/64", "a::0.0.0.0/64", "a::/64", "a::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-0-0-0.ipv6-literal.net/64", "00|M>t|ttwH6V62lVY`A/64", "0x000a0000000000000000000000000000-0x000a000000000000ffffffffffffffff", "00000240000000000000000000000000000000000000-00000240000000000000001777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:0:d:e:f:0:0/112", "a:0:0:d:e:f:0:0/112", "a:0:0:d:e:f:0:*", "a::d:e:f:0:*", "a:0:0:d:e:f:0:%", "000a:0000:0000:000d:000e:000f:0000:0000/112", "a::d:e:f:0:0/112", "a::d:e:f:0:0/112", "a:0:0:d:e:f::/112", "a::d:e:f:0:*", "a::d:e:f:0.0.0.0/112", "a::d:e:f:0.0.0.0/112", "a::d:e:f:0.0.0.0/112", "a:0:0:d:e:f::/112", "*.*.*.*.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-e-f-0-0.ipv6-literal.net/112", "00|M>t|tt+WcwbECb*xq/112", "0x000a00000000000d000e000f00000000-0x000a00000000000d000e000f0000ffff", "00000240000000000000032000160000740000000000-00000240000000000000032000160000740000177777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:0:0/112", "a:0:c:d:e:f:0:0/112", "a:0:c:d:e:f:0:*", "a:0:c:d:e:f:0:*", "a:0:c:d:e:f:0:%", "000a:0000:000c:000d:000e:000f:0000:0000/112", "a:0:c:d:e:f::/112", "a:0:c:d:e:f::/112", "a:0:c:d:e:f::/112", "a::c:d:e:f:0:*", "a::c:d:e:f:0.0.0.0/112", "a::c:d:e:f:0.0.0.0/112", "a::c:d:e:f:0.0.0.0/112", "a:0:c:d:e:f::/112", "*.*.*.*.0.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-0-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`j3_$/112", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000f0000ffff", "00000240000000006000032000160000740000000000-00000240000000006000032000160000740000177777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a:*", "a:0:c:d:e:f:a:*", "a:0:c:d:e:f:a:%", "000a:0000:000c:000d:000e:000f:000a:0000/112", "a::c:d:e:f:a:0/112", "a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a::/112", "a::c:d:e:f:a:*", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:0.10.0.0/112", "*.*.*.*.a.0.0.0.f.0.0.0.e.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-e-f-a-0.ipv6-literal.net/112", "00|M>t};s?v~hFl`k9s=/112", "0x000a0000000c000d000e000f000a0000-0x000a0000000c000d000e000f000affff", "00000240000000006000032000160000740002400000-00000240000000006000032000160000740002577777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:0:c:d:0:0:0:100/120", "a:0:c:d:0:0:0:100/120", "a:0:c:d:0:0:0:100-1ff", "a:0:c:d::100-1ff", "a:0:c:d:0:0:0:1__", "000a:0000:000c:000d:0000:0000:0000:0100/120", "a:0:c:d::100/120", "a:0:c:d::100/120", "a:0:c:d::100/120", "a:0:c:d::100-1ff", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "a:0:c:d::0.0.1.0/120", "*.*.1.0.0.0.0.0.0.0.0.0.0.0.0.0.d.0.0.0.c.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-c-d-0-0-0-100.ipv6-literal.net/120", "00|M>t};s?v}5L>MDI>a/120", "0x000a0000000c000d0000000000000100-0x000a0000000c000d00000000000001ff", "00000240000000006000032000000000000000000400-00000240000000006000032000000000000000000777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d:*:*:*:*", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*/64", "a:b:c:d:0:0:0:0/64", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000:0000:0000:0000/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d::/64", "a:b:c:d:*:*:*:*", "a:b:c:d::0.0.0.0/64", "a:b:c:d::0.0.0.0/64", "a:b:c:d::/64", "a:b:c:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-0-0-0-0.ipv6-literal.net/64", "00|N0s0$ND2BxK96%Chk/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*/64", "a:0:0:d:0:0:0:0/64", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000:0000:0000:0000/64", "a:0:0:d::/64", "a:0:0:d::/64", "a:0:0:d::/64", "a::d:*:*:*:*", "a::d:0:0:0.0.0.0/64", "a::d:0:0:0.0.0.0/64", "a:0:0:d::/64", "a:0:0:d::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-0-0-0-0.ipv6-literal.net/64", "00|M>t|tt+WbKhfd5~qN/64", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1::/32", "1:0:0:0:0:0:0:0/32", "1:0:*:*:*:*:*:*", "1:0:*:*:*:*:*:*", "1:0:%:%:%:%:%:%", "0001:0000:0000:0000:0000:0000:0000:0000/32", "1::/32", "1::/32", "1::/32", "1::*:*:*:*:*:*", "1::0.0.0.0/32", "1::0.0.0.0/32", "1::/32", "1::/32", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.1.0.0.0.ip6.arpa", "1-0-0-0-0-0-0-0.ipv6-literal.net/32", "008JOm8Mm5*yBppL!sg1/32", "0x00010000000000000000000000000000-0x00010000ffffffffffffffffffffffff", "00000020000000000000000000000000000000000000-00000020000077777777777777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/104", "ffff:0:0:0:0:0:0:0/104", "ffff:0:0:0:0:0:0-ff:*", "ffff::0-ff:*", "ffff:0:0:0:0:0:0-ff:%", "ffff:0000:0000:0000:0000:0000:0000:0000/104", "ffff::/104", "ffff::/104", "ffff::/104", "ffff::0-ff:*", "ffff::0.0.0.0/104", "ffff::0.0.0.0/104", "ffff::0.0.0.0/104", "ffff::/104", "*.*.*.*.*.*.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/104", "=q{+M|w0(OeO5^EGP660/104", "0xffff0000000000000000000000000000-0xffff0000000000000000000000ffffff", "03777760000000000000000000000000000000000000-03777760000000000000000000000000000077777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/108", "ffff:0:0:0:0:0:0:0/108", "ffff:0:0:0:0:0:0-f:*", "ffff::0-f:*", "ffff:0:0:0:0:0:_:%", "ffff:0000:0000:0000:0000:0000:0000:0000/108", "ffff::/108", "ffff::/108", "ffff::/108", "ffff::0-f:*", "ffff::0.0.0.0/108", "ffff::0.0.0.0/108", "ffff::0.0.0.0/108", "ffff::/108", "*.*.*.*.*.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^EGP660/108", "0xffff0000000000000000000000000000-0xffff00000000000000000000000fffff", "03777760000000000000000000000000000000000000-03777760000000000000000000000000000003777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::1000:0/108", "ffff:0:0:0:0:0:1000:0/108", "ffff:0:0:0:0:0:1000-100f:*", "ffff::1000-100f:*", "ffff:0:0:0:0:0:100_:%", "ffff:0000:0000:0000:0000:0000:1000:0000/108", "ffff::1000:0/108", "ffff::1000:0/108", "ffff:0:0:0:0:0:1000::/108", "ffff::1000-100f:*", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "ffff::16.0.0.0/108", "*.*.*.*.*.0.0.1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-1000-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^ELbE%G/108", "0xffff0000000000000000000010000000-0xffff00000000000000000000100fffff", "03777760000000000000000000000000002000000000-03777760000000000000000000000000002003777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::a000:0/108", "ffff:0:0:0:0:0:a000:0/108", "ffff:0:0:0:0:0:a000-a00f:*", "ffff::a000-a00f:*", "ffff:0:0:0:0:0:a00_:%", "ffff:0000:0000:0000:0000:0000:a000:0000/108", "ffff::a000:0/108", "ffff::a000:0/108", "ffff:0:0:0:0:0:a000::/108", "ffff::a000-a00f:*", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "ffff::160.0.0.0/108", "*.*.*.*.*.0.0.a.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-a000-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^E(z82>/108", "0xffff00000000000000000000a0000000-0xffff00000000000000000000a00fffff", "03777760000000000000000000000000024000000000-03777760000000000000000000000000024003777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/107", "ffff:0:0:0:0:0:0:0/107", "ffff:0:0:0:0:0:0-1f:*", "ffff::0-1f:*", "ffff:0:0:0:0:0:0-1f:%", "ffff:0000:0000:0000:0000:0000:0000:0000/107", "ffff::/107", "ffff::/107", "ffff::/107", "ffff::0-1f:*", "ffff::0.0.0.0/107", "ffff::0.0.0.0/107", "ffff::0.0.0.0/107", "ffff::/107", "*.*.*.*.*.0-1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/107", "=q{+M|w0(OeO5^EGP660/107", "0xffff0000000000000000000000000000-0xffff00000000000000000000001fffff", "03777760000000000000000000000000000000000000-03777760000000000000000000000000000007777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("abcd::/107", "abcd:0:0:0:0:0:0:0/107", "abcd:0:0:0:0:0:0-1f:*", "abcd::0-1f:*", "abcd:0:0:0:0:0:0-1f:%", "abcd:0000:0000:0000:0000:0000:0000:0000/107", "abcd::/107", "abcd::/107", "abcd::/107", "abcd::0-1f:*", "abcd::0.0.0.0/107", "abcd::0.0.0.0/107", "abcd::0.0.0.0/107", "abcd::/107", "*.*.*.*.*.0-1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.d.c.b.a.ip6.arpa", "abcd-0-0-0-0-0-0-0.ipv6-literal.net/107", "o6)n`s#^$cP5&p^H}p=a/107", "0xabcd0000000000000000000000000000-0xabcd00000000000000000000001fffff", "02536320000000000000000000000000000000000000-02536320000000000000000000000000000007777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::/80", "1:2:3:4:0:0:0:0/80", "1:2:3:4:0:*:*:*", "1:2:3:4:0:*:*:*", "1:2:3:4:0:%:%:%", "0001:0002:0003:0004:0000:0000:0000:0000/80", "1:2:3:4::/80", "1:2:3:4::/80", "1:2:3:4::/80", "1:2:3:4::*:*:*", "1:2:3:4::0.0.0.0/80", "1:2:3:4::0.0.0.0/80", "1:2:3:4::/80", "1:2:3:4::/80", "*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0.ipv6-literal.net/80", "008JQWOV7Skb)C|ve)jA/80", "0x00010002000300040000000000000000-0x00010002000300040000ffffffffffff", "00000020000200001400010000000000000000000000-00000020000200001400010000007777777777777777");
        }
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:%:%:%:%:%", "000a:000b:000c:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "a:b:c:*:*:*:*.*.*.*", "a:b:c:*:*:*:*.*.*.*", "a:b:c:*:*:*:*.*.*.*", "a:b:c:*:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-*-*-*-*-*.ipv6-literal.net", "00|N0s0$N0-%*(tF5l-X" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0;%a&*sUa#KSGX", "0x000a000b000c00000000000000000000-0x000a000b000cffffffffffffffffffff", "00000240001300006000000000000000000000000000-00000240001300006377777777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-*-*-*-*.ipv6-literal.net", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:%:%:%:%", "000a:000b:000c:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*:*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.c.0.0.0.b.0.0.0.a.0.0.0.ip6.arpa", "a-b-c-d-*-*-*-*.ipv6-literal.net", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "00000240001300006000032000000000000000000000-00000240001300006000033777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::c:d:*", "a:0:0:0:0:c:d:*", "a:0:0:0:0:c:d:*", "a::c:d:*", "a:0:0:0:0:c:d:%", "000a:0000:0000:0000:0000:000c:000d:0000-ffff", "a::c:d:*", "a::c:d:*", "a::c:d:*", "a::c:d:*", "a::c:0.13.*.*", "a::c:0.13.*.*", "a::c:0.13.*.*", "a::c:0.13.*.*", "*.*.*.*.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-c-d-*.ipv6-literal.net", "00|M>t|ttwH6V6EEzblZ" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttwH6V6EEzkrZ", "0x000a0000000000000000000c000d0000-0x000a0000000000000000000c000dffff", "00000240000000000000000000000000600003200000-00000240000000000000000000000000600003377777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::d:*:*:*:*", "a:0:0:d:*:*:*:*", "a:0:0:d:*:*:*:*", "a::d:*:*:*:*", "a:0:0:d:%:%:%:%", "000a:0000:0000:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "a::d:*:*:*:*", "a::d:*:*:*:*", "a::d:*:*:*:*", "a::d:*:*:*:*", "a::d:*:*:*.*.*.*", "a::d:*:*:*.*.*.*", "a::d:*:*:*.*.*.*", "a::d:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.d.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-d-*-*-*-*.ipv6-literal.net", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "00000240000000000000032000000000000000000000-00000240000000000000033777777777777777777777");
        if(allPrefixesAreSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::c:d:*/64", "a:0:0:0:0:0:0:0/64", "a:0:0:0:*:*:*:*", "a::*:*:*:*", "a:0:0:0:%:%:%:%", "000a:0000:0000:0000:0000:0000:0000:0000/64", "a::/64", "a::/64", "a::/64", "a::*:*:*:*", "a::0.0.0.0/64", "a::0.0.0.0/64", "a::/64", "a::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-0-0-0.ipv6-literal.net/64", "00|M>t|ttwH6V62lVY`A/64", "0x000a0000000000000000000000000000-0x000a000000000000ffffffffffffffff", "00000240000000000000000000000000000000000000-00000240000000000000001777777777777777777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.0.4/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.0/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.0.0.0/14", "1.0.0.0/14", "1.0-3.*.*", "1.0-3.%.%", "001.000.000.000/14", "01.00.00.00/14", "0x1.0x0.0x0.0x0/14", "*.*.0-3.1.in-addr.arpa", "0x01000000-0x0103ffff", "000100000000-000100777777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.4/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.*/16", "1.2.0.0/16", "1.2.*.*", "1.2.%.%", "001.002.000.000/16", "01.02.00.00/16", "0x1.0x2.0x0.0x0/16", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.0.*.*/14", "1.0.0.0/14", "1.0-3.*.*", "1.0-3.%.%", "001.000.000.000/14", "01.00.00.00/14", "0x1.0x0.0x0.0x0/14", "*.*.0-3.1.in-addr.arpa", "0x01000000-0x0103ffff", "000100000000-000100777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/8", "ff00:0:0:0:0:0:0:0/8", "ff00-ffff:*:*:*:*:*:*:*", "ff00-ffff:*:*:*:*:*:*:*", "ff__:%:%:%:%:%:%:%", "ff00:0000:0000:0000:0000:0000:0000:0000/8", "ff00::/8", "ff00::/8", "ff00::/8", "ff00-ffff:*:*:*:*:*:*:*", "ff00::0.0.0.0/8", "ff00::0.0.0.0/8", "ff00::/8", "ff00::/8", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.f.f.ip6.arpa", "ff00-0-0-0-0-0-0-0.ipv6-literal.net/8", "=SN{mv>Qn+T=L9X}Vo30/8", "0xff000000000000000000000000000000-0xffffffffffffffffffffffffffffffff", "03770000000000000000000000000000000000000000-03777777777777777777777777777777777777777777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::eeee:eeee/108", "ffff:0:0:0:0:0:eee0:0/108", "ffff:0:0:0:0:0:eee0-eeef:*", "ffff::eee0-eeef:*", "ffff:0:0:0:0:0:eee_:%", "ffff:0000:0000:0000:0000:0000:eee0:0000/108", "ffff::eee0:0/108", "ffff::eee0:0/108", "ffff:0:0:0:0:0:eee0::/108", "ffff::eee0-eeef:*", "ffff::238.224.0.0/108", "ffff::238.224.0.0/108", "ffff::238.224.0.0/108", "ffff::238.224.0.0/108", "*.*.*.*.*.e.e.e.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-eee0-0.ipv6-literal.net/108", "=q{+M|w0(OeO5^F85=Cb/108", "0xffff00000000000000000000eee00000-0xffff00000000000000000000eeefffff", "03777760000000000000000000000000035670000000-03777760000000000000000000000000035673777777");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::c:d:*/64", "a:0:0:0:0:c:d:*/64", "a:0:0:0:0:c:d:*", "a::c:d:*", "a:0:0:0:0:c:d:%", "000a:0000:0000:0000:0000:000c:000d:0000-ffff/64", "a::c:d:*/64", "a::c:d:*/64", "a::c:d:*/64", "a::c:d:*", "a::c:0.13.*.*/64", "a::c:0.13.*.*/64", "a::c:0.13.*.*/64", "a::c:0.13.*.*/64", "*.*.*.*.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-c-d-*.ipv6-literal.net/64", "00|M>t|ttwH6V6EEzblZ" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttwH6V6EEzkrZ/64", "0x000a0000000000000000000c000d0000-0x000a0000000000000000000c000dffff", "00000240000000000000000000000000600003200000-00000240000000000000000000000000600003377777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::c:d:*/80", "a:0:0:0:0:c:d:*/80", "a:0:0:0:0:c:d:*", "a::c:d:*", "a:0:0:0:0:c:d:%", "000a:0000:0000:0000:0000:000c:000d:0000-ffff/80", "a::c:d:*/80", "a::c:d:*/80", "a::c:d:*/80", "a::c:d:*", "a::c:0.13.*.*/80", "a::c:0.13.*.*/80", "a::c:0.13.*.*/80", "a::c:0.13.*.*/80", "*.*.*.*.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-c-d-*.ipv6-literal.net/80", "00|M>t|ttwH6V6EEzblZ" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttwH6V6EEzkrZ/80", "0x000a0000000000000000000c000d0000-0x000a0000000000000000000c000dffff", "00000240000000000000000000000000600003200000-00000240000000000000000000000000600003377777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a::c:d:*/48", "a:0:0:0:0:c:d:*/48", "a:0:0:0:0:c:d:*", "a::c:d:*", "a:0:0:0:0:c:d:%", "000a:0000:0000:0000:0000:000c:000d:0000-ffff/48", "a::c:d:*/48", "a::c:d:*/48", "a::c:d:*/48", "a::c:d:*", "a::c:0.13.*.*/48", "a::c:0.13.*.*/48", "a::c:0.13.*.*/48", "a::c:0.13.*.*/48", "*.*.*.*.d.0.0.0.c.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.a.0.0.0.ip6.arpa", "a-0-0-0-0-c-d-*.ipv6-literal.net/48", "00|M>t|ttwH6V6EEzblZ" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttwH6V6EEzkrZ/48", "0x000a0000000000000000000c000d0000-0x000a0000000000000000000c000dffff", "00000240000000000000000000000000600003200000-00000240000000000000000000000000600003377777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.0.4/16", "1.2.0.4/16", "1.2.0.4", "1.2.0.4", "001.002.000.004/16", "01.02.00.04/16", "0x1.0x2.0x0.0x4/16", "4.0.2.1.in-addr.arpa", "0x01020004", "000100400004");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.0/16", "1.2.3.0/16", "1.2.3.0", "1.2.3.0", "001.002.003.000/16", "01.02.03.00/16", "0x1.0x2.0x3.0x0/16", "0.3.2.1.in-addr.arpa", "0x01020300", "000100401400");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/14", "1.2.0.0/14", "1.2.0.0", "1.2.0.0", "001.002.000.000/14", "01.02.00.00/14", "0x1.0x2.0x0.0x0/14", "0.0.2.1.in-addr.arpa", "0x01020000", "000100400000");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.4/16", "1.2.*.4/16", "1.2.*.4", "1.2.%.4", "001.002.000-255.004/16", "01.02.*.04/16", "0x1.0x2.*.0x4/16", "4.*.2.1.in-addr.arpa", null, null);
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.3.*/16", "1.2.3.*/16", "1.2.3.*", "1.2.3.%", "001.002.003.000-255/16", "01.02.03.*/16", "0x1.0x2.0x3.*/16", "*.3.2.1.in-addr.arpa", "0x01020300-0x010203ff", "000100401400-000100401777");
            this.testIPv4Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1.2.*.*/14", "1.2.*.*/14", "1.2.*.*", "1.2.%.%", "001.002.000-255.000-255/14", "01.02.*.*/14", "0x1.0x2.*.*/14", "*.*.2.1.in-addr.arpa", "0x01020000-0x0102ffff", "000100400000-000100577777");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::/8", "ffff:0:0:0:0:0:0:0/8", "ffff:0:0:0:0:0:0:0", "ffff::", "ffff:0:0:0:0:0:0:0", "ffff:0000:0000:0000:0000:0000:0000:0000/8", "ffff::/8", "ffff::/8", "ffff::/8", "ffff::", "ffff::0.0.0.0/8", "ffff::0.0.0.0/8", "ffff::/8", "ffff::/8", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-0-0.ipv6-literal.net/8", "=q{+M|w0(OeO5^EGP660/8", "0xffff0000000000000000000000000000", "03777760000000000000000000000000000000000000");
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff::eeee:eeee/108", "ffff:0:0:0:0:0:eeee:eeee/108", "ffff:0:0:0:0:0:eeee:eeee", "ffff::eeee:eeee", "ffff:0:0:0:0:0:eeee:eeee", "ffff:0000:0000:0000:0000:0000:eeee:eeee/108", "ffff::eeee:eeee/108", "ffff::eeee:eeee/108", "ffff::eeee:eeee/108", "ffff::eeee:eeee", "ffff::238.238.238.238/108", "ffff::238.238.238.238/108", "ffff::238.238.238.238/108", "ffff::238.238.238.238/108", "e.e.e.e.e.e.e.e.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.f.f.f.f.ip6.arpa", "ffff-0-0-0-0-0-eeee-eeee.ipv6-literal.net/108", "=q{+M|w0(OeO5^F87dpH/108", "0xffff00000000000000000000eeeeeeee", "03777760000000000000000000000000035673567356");
        }
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::%x%x%", "1:2:3:4:0:0:0:0%x%x%", "1:2:3:4:0:0:0:0%x%x%", "1:2:3:4::%x%x%", "1:2:3:4:0:0:0:0%x%x%", "0001:0002:0003:0004:0000:0000:0000:0000%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::0.0.0.0%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::%x%x%", "1:2:3:4::%x%x%", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0sxsxs.ipv6-literal.net", "008JQWOV7Skb)C|ve)jA\u00a7x%x%", "0x00010002000300040000000000000000%x%x%", "00000020000200001400010000000000000000000000%x%x%");
        if(allPrefixesAreSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4:5:6:7:8%a/64", "1:2:3:4:0:0:0:0%a/64", "1:2:3:4:*:*:*:*%a", "1:2:3:4:*:*:*:*%a", "1:2:3:4:%:%:%:%%a", "0001:0002:0003:0004:0000:0000:0000:0000%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4:*:*:*:*%a", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0sa.ipv6-literal.net/64", "008JQWOV7Skb)C|ve)jA\u00a7a/64", "0x00010002000300040000000000000000-0x0001000200030004ffffffffffffffff%a", "00000020000200001400010000000000000000000000-00000020000200001400011777777777777777777777%a");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4:5:6:7:8%a/64", "1:2:3:4:5:6:7:8%a/64", "1:2:3:4:5:6:7:8%a", "1:2:3:4:5:6:7:8%a", "1:2:3:4:5:6:7:8%a", "0001:0002:0003:0004:0005:0006:0007:0008%a/64", "1:2:3:4:5:6:7:8%a/64", "1:2:3:4:5:6:7:8%a/64", "1:2:3:4:5:6:7:8%a/64", "1:2:3:4:5:6:7:8%a", "1:2:3:4:5:6:0.7.0.8%a/64", "1:2:3:4:5:6:0.7.0.8%a/64", "1:2:3:4:5:6:0.7.0.8%a/64", "1:2:3:4:5:6:0.7.0.8%a/64", "8.0.0.0.7.0.0.0.6.0.0.0.5.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-5-6-7-8sa.ipv6-literal.net/64", "008JQWOV7SkcR4tS1R_a\u00a7a/64", "0x00010002000300040005000600070008%a", "00000020000200001400010000050000300001600010%a");
        }
        if(isNoAutoSubnets) {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::%a/64", "1:2:3:4:0:0:0:0%a/64", "1:2:3:4:0:0:0:0%a", "1:2:3:4::%a", "1:2:3:4:0:0:0:0%a", "0001:0002:0003:0004:0000:0000:0000:0000%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0sa.ipv6-literal.net/64", "008JQWOV7Skb)C|ve)jA\u00a7a/64", "0x00010002000300040000000000000000%a", "00000020000200001400010000000000000000000000%a");
        } else {
            this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::%a/64", "1:2:3:4:0:0:0:0%a/64", "1:2:3:4:*:*:*:*%a", "1:2:3:4:*:*:*:*%a", "1:2:3:4:%:%:%:%%a", "0001:0002:0003:0004:0000:0000:0000:0000%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "1:2:3:4:*:*:*:*%a", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::0.0.0.0%a/64", "1:2:3:4::%a/64", "1:2:3:4::%a/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0sa.ipv6-literal.net/64", "008JQWOV7Skb)C|ve)jA\u00a7a/64", "0x00010002000300040000000000000000-0x0001000200030004ffffffffffffffff%a", "00000020000200001400010000000000000000000000-00000020000200001400011777777777777777777777%a");
        }
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::%.a.a", "1:2:3:4:0:0:0:0%.a.a", "1:2:3:4:0:0:0:0%.a.a", "1:2:3:4::%.a.a", "1:2:3:4:0:0:0:0%.a.a", "0001:0002:0003:0004:0000:0000:0000:0000%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::0.0.0.0%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::%.a.a", "1:2:3:4::%.a.a", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0s.a.a.ipv6-literal.net", "008JQWOV7Skb)C|ve)jA\u00a7.a.a", "0x00010002000300040000000000000000%.a.a", "00000020000200001400010000000000000000000000%.a.a");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::*:*:*", "1:2:3:4:0:*:*:*", "1:2:3:4:0:*:*:*", "1:2:3:4:0:*:*:*", "1:2:3:4:0:%:%:%", "0001:0002:0003:0004:0000:0000-ffff:0000-ffff:0000-ffff", "1:2:3:4::*:*:*", "1:2:3:4:0:*:*:*", "1:2:3:4::*:*:*", "1:2:3:4::*:*:*", "1:2:3:4::*:*.*.*.*", "1:2:3:4::*:*.*.*.*", "1:2:3:4::*:*.*.*.*", "1:2:3:4::*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-*-*-*.ipv6-literal.net", "008JQWOV7Skb)C|ve)jA" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "008JQWOV7Skb?_P3;X#A", "0x00010002000300040000000000000000-0x00010002000300040000ffffffffffff", "00000020000200001400010000000000000000000000-00000020000200001400010000007777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4::", "1:2:3:4:0:0:0:0", "1:2:3:4:0:0:0:0", "1:2:3:4::", "1:2:3:4:0:0:0:0", "0001:0002:0003:0004:0000:0000:0000:0000", "1:2:3:4::", "1:2:3:4::", "1:2:3:4::", "1:2:3:4::", "1:2:3:4::0.0.0.0", "1:2:3:4::", "1:2:3:4::", "1:2:3:4::", "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-0-0-0.ipv6-literal.net", "008JQWOV7Skb)C|ve)jA", "0x00010002000300040000000000000000", "00000020000200001400010000000000000000000000");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:4:0:6::", "1:2:3:4:0:6:0:0", "1:2:3:4:0:6:0:0", "1:2:3:4:0:6::", "1:2:3:4:0:6:0:0", "0001:0002:0003:0004:0000:0006:0000:0000", "1:2:3:4:0:6::", "1:2:3:4:0:6::", "1:2:3:4:0:6::", "1:2:3:4:0:6::", "1:2:3:4::6:0.0.0.0", "1:2:3:4:0:6::", "1:2:3:4:0:6::", "1:2:3:4:0:6::", "0.0.0.0.0.0.0.0.6.0.0.0.0.0.0.0.4.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-4-0-6-0-0.ipv6-literal.net", "008JQWOV7Skb)D3fCrWG", "0x00010002000300040000000600000000", "00000020000200001400010000000000300000000000");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:2:3:0:0:6::", "1:2:3:0:0:6:0:0", "1:2:3:0:0:6:0:0", "1:2:3::6:0:0", "1:2:3:0:0:6:0:0", "0001:0002:0003:0000:0000:0006:0000:0000", "1:2:3::6:0:0", "1:2:3::6:0:0", "1:2:3::6:0:0", "1:2:3::6:0:0", "1:2:3::6:0.0.0.0", "1:2:3::6:0.0.0.0", "1:2:3::6:0.0.0.0", "1:2:3:0:0:6::", "0.0.0.0.0.0.0.0.6.0.0.0.0.0.0.0.0.0.0.0.3.0.0.0.2.0.0.0.1.0.0.0.ip6.arpa", "1-2-3-0-0-6-0-0.ipv6-literal.net", "008JQWOV7O(=61h*;$LC", "0x00010002000300000000000600000000", "00000020000200001400000000000000300000000000");
    }

    public testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer(original : string, prefixLength : number, minPrefix : number, equivalentPrefix : number) {
        let ipaddr : IPAddress = this.createAddress$java_lang_String(original).getAddress();
        this.testPrefix$inet_ipaddr_AddressSegmentSeries$java_lang_Integer$int$java_lang_Integer(ipaddr, prefixLength, minPrefix, equivalentPrefix);
        this.incrementTestCount();
    }

    public testPrefix(original? : any, prefixLength? : any, minPrefix? : any, equivalentPrefix? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof minPrefix === 'number') || minPrefix === null) && ((typeof equivalentPrefix === 'number') || equivalentPrefix === null)) {
            return <any>this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer(original, prefixLength, minPrefix, equivalentPrefix);
        } else if(((original != null && (original["__interfaces"] != null && original["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || original.constructor != null && original.constructor["__interfaces"] != null && original.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || original === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof minPrefix === 'number') || minPrefix === null) && ((typeof equivalentPrefix === 'number') || equivalentPrefix === null)) {
            super.testPrefix(original, prefixLength, minPrefix, equivalentPrefix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {boolean}
     */
    allowsRange() : boolean {
        return true;
    }

    /**
     * 
     */
    runTest() {
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        if(isNoAutoSubnets) {
            this.testEquivalentPrefix$java_lang_String$int("128-255.*.*.*/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("1.2-3.*.*/15", 15);
            this.testEquivalentPrefix$java_lang_String$int("1.2.*.*/16", 16);
            this.testEquivalentPrefix$java_lang_String$int("1:2:*/32", 32);
            this.testEquivalentPrefix$java_lang_String$int("8000-8fff:*/1", 4);
            this.testEquivalentPrefix$java_lang_String$int("8000-ffff:*/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("1:2-3:*/31", 31);
            this.testEquivalentPrefix$java_lang_String$int("1:2:*/34", 32);
            this.testEquivalentPrefix$java_lang_String$int("1:2:0-3fff:*/34", 34);
        }
        this.testEquivalentPrefix$java_lang_String$int("*.*.*.*", 0);
        this.testEquivalentPrefix$java_lang_String$int("0-127.*.*.*", 1);
        this.testEquivalentPrefix$java_lang_String$int("128-255.*.*.*", 1);
        this.testEquivalentPrefix$java_lang_String$int("*.*.*.*/1", 0);
        this.testEquivalentPrefix$java_lang_String$int("0.*.*.*/1", isNoAutoSubnets?8:1);
        this.testEquivalentPrefix$java_lang_String$int("128-255.*.*.*/1", 1);
        this.testEquivalentPrefix$java_lang_String$int("1.2.*.*", 16);
        this.testEquivalentPrefix$java_lang_String$int("1.2.*.*/24", 16);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.*.0/24", isNoAutoSubnets?null:16, isNoAutoSubnets?32:16);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.0-255.0/24", isNoAutoSubnets?null:16, isNoAutoSubnets?32:16);
        this.testEquivalentPrefix$java_lang_String$int("1.2.1.0/24", isNoAutoSubnets?32:24);
        this.testEquivalentPrefix$java_lang_String$int("1.2.1.*/24", 24);
        this.testEquivalentPrefix$java_lang_String$int("1.2.1.*", 24);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.*.4", null, 32);
        this.testEquivalentPrefix$java_lang_String$int("1.2.252-255.*", 22);
        this.testEquivalentPrefix$java_lang_String$int("1.2.252-255.0-255", 22);
        this.testEquivalentPrefix$java_lang_String$int("1.2.0-3.0-255", 22);
        this.testEquivalentPrefix$java_lang_String$int("1.2.128-131.0-255", 22);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.253-255.0-255", null, 24);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.252-255.0-254", null, 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.251-255.0-254", null, 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.251-255.0-255", null, 24);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1.2.1-3.*", null, 24);
        this.testEquivalentPrefix$java_lang_String$int("1.2.0-3.*", 22);
        this.testEquivalentPrefix$java_lang_String$int("*:*", 0);
        this.testEquivalentPrefix$java_lang_String$int("::/0", isNoAutoSubnets?128:0);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("0-1::/0", allPrefixesAreSubnets?0:null, allPrefixesAreSubnets?0:128);
        this.testEquivalentPrefix$java_lang_String$int("::/1", isNoAutoSubnets?128:1);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("0-1::/1", allPrefixesAreSubnets?1:null, allPrefixesAreSubnets?1:128);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("8000-ffff::/1", allPrefixesAreSubnets?1:null, allPrefixesAreSubnets?1:128);
        this.testEquivalentPrefix$java_lang_String$int("8000-ffff:*", 1);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("7fff-ffff:*", null, 16);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("7fff-ffff:*/1", allPrefixesAreSubnets?0:null, allPrefixesAreSubnets?0:16);
        this.testEquivalentPrefix$java_lang_String$int("11:8000-ffff:*/1", allPrefixesAreSubnets?1:17);
        this.testEquivalentPrefix$java_lang_String$int("11:8000-ffff:*", 17);
        this.testEquivalentPrefix$java_lang_String$int("1:2:*", 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:*:*::/64", isNoAutoSubnets?null:32, isNoAutoSubnets?128:32);
        this.testEquivalentPrefix$java_lang_String$int("1:2:*:*/64", 32);
        this.testEquivalentPrefix$java_lang_String$int("1:2:3:4:5:*:*/64", allPrefixesAreSubnets?64:80);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:*::/64", null, isNoAutoSubnets?128:64);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:*::", null, 128);
        this.testEquivalentPrefix$java_lang_String$int("1:2:8000-ffff:*", 33);
        this.testEquivalentPrefix$java_lang_String$int("1:2:0000-7fff:*", 33);
        this.testEquivalentPrefix$java_lang_String$int("1:2:c000-ffff:*", 34);
        this.testEquivalentPrefix$java_lang_String$int("1:2:0000-3fff:*", 34);
        this.testEquivalentPrefix$java_lang_String$int("1:2:8000-bfff:*", 34);
        this.testEquivalentPrefix$java_lang_String$int("1:2:4000-7fff:*", 34);
        this.testEquivalentPrefix$java_lang_String$int("1:2:fffc-ffff:*", 46);
        this.testEquivalentPrefix$java_lang_String$int("1:2:fffc-ffff:0-ffff:*", 46);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fffd-ffff:0-ffff:*", null, 48);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fffc-ffff:0-fffe:*", null, 64);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fffb-ffff:0-fffe:*", null, 64);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fffb-ffff:0-ffff:*", null, 48);
        this.testReverseHostAddress("*.*.0-240.0/20");
        this.testReverseHostAddress("*.*.0.0/16");
        this.testReverseHostAddress("*:0-f000::/20");
        this.testTrees();
        this.testStrings();
        this.testReverse$java_lang_String$boolean$boolean("1:2:*:4:5:6:a:b", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:1:1-fffe:2:3:3:3", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:1:0-fffe:1-fffe:*:1:1", false, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:80:*:ff:01:ffff", false, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:8000:fffe::7fff:0001:ffff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:8000:*:8000:1:*:01:ffff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:8118:ffff:*:1-fffe:ffff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:8181:c3c3::4224:2400:0-fffe", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:1:ff:ff:*:*", false, false);
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/16", "1.2.*.*");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/16", "1.2.*");
            this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.2.3.4/15", "1.2.*.*");
            this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.2.3.4/17", "1.2.*.*");
        } else {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/16", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/15", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/17", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.0.4/16", "1.2.0.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.0/16", "1.2.3.0");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/14", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.0.4/14", "1.2.0.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.0.0/14", "1.2.0.0");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.0.3.0/14", "1.0.3.0");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.2.0.0/16", "1.2.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.2.0.0/16", "1.2.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.4.0.0/14", "1.4-7.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.4.0.0/14", "1.4-7.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.3.4/16", "1.2.*/255.255.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.3.4/15", "1.2.3.*/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.3.4/17", "1.2.3.*/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.2.0.0/16", "1.2.*/255.255.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.*/15", "1.2.3.*/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.*/17", "1.2.3.*/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.1.3.4/15", "1.2.3.*/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.1.3.4/17", "1.2.3.*/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/32", "1:2:*:*:*:*:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/32", "1:2:*:*:*:*:*.*.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/32", "1:2:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2::/32", "1:2:*:*:*:*:3:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2::/32", "1:2:*:*:*:*:*.*.3.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2::/31", "1:2:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2::/33", "1:2::*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/32", "1:2:*:*:*:*:*:*/ffff:ffff::");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/31", "1:2:*:*:*:*:*:*/ffff:fffe::");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2::/33", "1:2:0:*:*:*:*:*/ffff:ffff:8000::");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2::/24", "1:__:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2::/28", "1:_::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2::/20", "1:___::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2::/16", "1:____::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:ffef::/24", "1:ff__::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:ffef::/24", "1:ff__:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1::/24", "1:__:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1::/28", "1:_::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1::/20", "1:___::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1::/16", "1:____::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:ff00::/24", "1:ff__::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:ff00::/24", "1:ff__:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "250-255.200-255.0-255.20-29", "25_.2__.___.2_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "150-159.100-199.0-99.10-19", "15_.1__.__.1_");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "251-255.200-255.0-255.20-29", "25_.2__.___.2_");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "150-158.100-199.0-99.10-19", "15_.1__.__.1_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "250-25f:200-2ff:0-fff:20-2f::", "25_:2__:___:2_::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "150-15f:100-1ff:0-ff:10-1f::", "15_:1__:__:1_::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "250-25f:201-2ff:0-fff:20-2f::", "25_:2__:___:2_::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "150-15f:100-1ef:0-ff:10-1f::", "15_:1__:__:1_::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "::250-25f:200-2ff:0-fff:20-2f", "::25_:2__:___:2_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "::150-15f:100-1ff:0-ff:10-1f", "::15_:1__:__:1_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "250-25f:200-2ff::0-fff:20-2f", "25_:2__::___:2_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "150-15f:100-1ff::0-ff:10-1f", "15_:1__::__:1_");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.0.4-5", "1:2:3:4:5:6:102:4-5");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.0.*", "1:2:3:4:5:6:102:0-ff");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.0._", "1:2:3:4:5:6:102:0-9");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.0.1_", "1:2:3:4:5:6:102:a-13");
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.3", "1.2.0.3", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "0x1.0x2.2-0x3.0x4", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "0x1.0x2.0x2-0x3.0x4", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "0x1.0x2.0x2-3.0x4", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.2-03.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.2-3.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.02-03.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.0x2-03.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.0x2-0x3.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.0200-0277.4", "01.02.02__.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.0x20-0x2f.4", "01.02.0x2_.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.0x10-0x1f.4", "01.02.0x1_.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.*.4", "01.02.0x__.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.0-077.4", "01.02.0__.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.2-3.4", "01.02.0x2-0x3.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "0.0.0-1.4", "00.0x0.0x00-0x000001.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.10-11.10-11.10-11", "11.012-0xb.0xa-013.012-0xB", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.10-11.*.10-11", "11.012-0xb.0x0-0xff.012-0xB", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.*", "1.*.*.0x0-0xff", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.*", "1.0-255.0-65535", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.*", "1.0-0xff.0-0xffff", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.*", "1.0x0-0xff.00-0xffff", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.0-11.*", "11.11.0-0xbff", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11-11", "11.0x00000000000000000b-0000000000000000000013", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.1-11.*/16", "11.0x10000-786431/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.1-11.*/16", "11.0x10000-0xbffff/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/128", "1:2:3:4:5:6:102:304");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.3.4/96", "1:2:3:4:5:6:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:255.2.3.4/97", "1:2:3:4:5:6:8000-ffff:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.3.4/112", "1:2:3:4:5:6:102:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.255.4/115", "1:2:3:4:5:6:102:e000-ffff");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.3.4/0", "*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.3.4/0", "*.*.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:7:8/0", "*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:7:8/0", "*:*:*:*:*:*:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.3.4/96", "1:2:3:4:5:6:102:304");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:255.2.3.4/97", "1:2:3:4:5:6:ff02:304");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.3.4/112", "1:2:3:4:5:6:102:304");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.255.4/115", "1:2:3:4:5:6:102:ff04");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1.2.3.4/0", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1.2.3.4/0", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:7:8/0", "1:2:3:4:5:6:7:8");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:7:8/0", "1:2:3:4:5:6:7:8");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2:3:4:5:6:0.0.0.0/96", "1:2:3:4:5:6:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:255.0.0.0/97", "1:2:3:4:5:6:8000-ffff:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:255.0.0.0/97", "1:2:3:4:5:6:ff00:0");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2:3:4:5:6:128.0.0.0/97", "1:2:3:4:5:6:8000-ffff:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2:3:4:5:6:1.2.0.0/112", "1:2:3:4:5:6:102:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.255.0/115", "1:2:3:4:5:6:102:e000-ffff");
        this.testMatches$boolean$java_lang_String$java_lang_String(!allPrefixesAreSubnets, "1:2:3:4:5:6:1.2.255.0/115", "1:2:3:4:5:6:102:FF00");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1:2:3:4:5:6:1.2.224.0/115", "1:2:3:4:5:6:102:e000-ffff");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "0.0.0.0/0", "*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "0.0.0.0/0", "*.*.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "::/0", "*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "::/0", "*:*:*:*:*:*:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1-02.03-4.05-06.07", "1-2.3-4.5-6.7");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1-002.003-4.005-006.007", "1-2.3-4.5-6.7");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1-2.0-0.00-00.00-0", "1-2.0.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1-2:0-0:00-00:00-0:0-000:0000-0000:0000-00:0000-0", "1-2:0:0:0:0:0:0:0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "00-0.0-0.00-00.00-0", "0.0.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "0-00:0-0:00-00:00-0:0-000:0000-0000:0000-00:0000-0", "::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "-1.22.33.4", "0-1.22.33.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "-1.22.33.4", "0-1.22.33.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "22.1-.33.4", "22.1-255.33.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "22.33.4.1-", "22.33.4.1-255");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "aa:-1:cc::d:ee:f", "aa:0-1:cc::d:ee:f");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "aa:dd-:cc::d:ee:f", "aa:dd-ffff:cc::d:ee:f");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "::1:0:0:0.0.0.0", "0:0:0:1::0.0.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::-1:16", "1::0-1:16");
        if(isNoAutoSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::-1:16/16", "1::0-1:16");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::-1:16", "1::0-1:16/16");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1::16/16", "1:0-1::16");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1::16", "1:0-1::16/16");
        } else if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1::16/32", "1:0-1:*");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1:*", "1:0-1::16/32");
        } else {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1::16/32", "1:0-1::16");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:-1::16", "1:0-1::16/32");
        }
        if(allPrefixesAreSubnets) {
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/0", "0.0.0.0/0");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/1", "0.0.0.0/1");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/4", "0.0.0.0/4");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/5", "8.0.0.0/5");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/7", "8.0.0.0/7");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/8", "9.0.0.0/8");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/9", "9.0-128.0.0/9");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/16", "9.*.0.0/16");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/30", "9.*.237.24/30");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/31", "9.*.237.26/31");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.*.237.26/32", "9.*.237.26/32");
        } else {
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/0", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/1", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/4", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/5", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/7", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/8", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/9", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/16", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/30", "9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/31", !isNoAutoSubnets?"9.*.237.26-27":"9.*.237.26", false);
            this.testCIDRSubnets$java_lang_String$java_lang_String$boolean("9.*.237.26/32", "9.*.237.26", false);
        }
        this.testSubnet("1.2-4.3.4", "255.255.254.255", 24, allPrefixesAreSubnets?"1.2-4.2.0/24":"1.2-4.2.4/24", "1.2-4.2.4", allPrefixesAreSubnets?"1.2-4.3.0/24":"1.2-4.3.4/24");
        this.testSubnet("1.2-4.3.4", "255.248.254.255", 24, allPrefixesAreSubnets?"1.0.2.0/24":"1.0.2.4/24", "1.0.2.4", allPrefixesAreSubnets?"1.2-4.3.0/24":"1.2-4.3.4/24");
        this.testSubnet("__::", "ffff::", 128, "0-ff:0:0:0:0:0:0:0/128", "0-ff:0:0:0:0:0:0:0", "0-ff:0:0:0:0:0:0:0/128");
        this.testSubnet("0-ff::", "fff0::", 128, null, null, "0-ff:0:0:0:0:0:0:0/128");
        this.testSubnet("0-ff::", "fff0::", 12, allPrefixesAreSubnets?"0-f0:0:0:0:0:0:0:0/12":"0-ff:0:0:0:0:0:0:0/12", null, allPrefixesAreSubnets?"0-f0:0:0:0:0:0:0:0/12":"0-ff:0:0:0:0:0:0:0/12");
        this.testSubnet("0-f0::", "fff0::", 12, "0-f0:0:0:0:0:0:0:0/12", "0-f0:0:0:0:0:0:0:0", "0-f0:0:0:0:0:0:0:0/12");
        this.testSubnet("0-f::*", "fff0::ffff", 12, allPrefixesAreSubnets?"0:0:0:0:0:0:0:0/12":"0-f:0:0:0:0:0:0:*/12", "0:0:0:0:0:0:0:*", allPrefixesAreSubnets?"0:0:0:0:0:0:0:0/12":"0-f:0:0:0:0:0:0:*/12");
        this.testSubnet("::1:__", "::1:ffff", 128, "0:0:0:0:0:0:1:0-ff/128", "0:0:0:0:0:0:1:0-ff", "0:0:0:0:0:0:1:0-ff/128");
        this.testSubnet("::1:__", "::1:ffff", 126, isNoAutoSubnets?"0:0:0:0:0:0:1:0-ff/126":"0:0:0:0:0:0:1:0-fc/126", "0:0:0:0:0:0:1:0-ff", isNoAutoSubnets?"0:0:0:0:0:0:1:0-ff/126":"0:0:0:0:0:0:1:0-fc/126");
        this.testSubnet("::1:0-ff", "::1:fff0", 128, null, null, "0:0:0:0:0:0:1:0-ff/128");
        this.testSubnet("::1:0-ff", "::1:fff0", 124, isNoAutoSubnets?"0:0:0:0:0:0:1:0-ff/124":"0:0:0:0:0:0:1:0-f0/124", null, isNoAutoSubnets?"0:0:0:0:0:0:1:0-ff/124":"0:0:0:0:0:0:1:0-f0/124");
        this.testSubnet("*::1:0-f", "ffff::1:fff0", 124, isNoAutoSubnets?"*:0:0:0:0:0:1:0-f/124":"*:0:0:0:0:0:1:0/124", "*:0:0:0:0:0:1:0", isNoAutoSubnets?"*:0:0:0:0:0:1:0-f/124":"*:0:0:0:0:0:1:0/124");
        this.testBitwiseOr("1.2.0.0/16", 8, "0.0.3.248", isNoAutoSubnets?"1.2.3.248":"1.2.3.248-255");
        this.testBitwiseOr("1.2.0.0/16", 7, "0.0.2.0", isNoAutoSubnets?"1.2.2.0":"1.2.2-3.*");
        this.testBitwiseOr("1.2.*.*", 7, "0.0.3.0", null);
        this.testBitwiseOr("1.2.0-3.*", 0, "0.0.3.0", "1.2.3.*");
        this.testBitwiseOr("1.2.0.0/16", 7, "0.0.3.0", isNoAutoSubnets?"1.2.3.0":"1.2.3.*");
        this.testBitwiseOr("0.0.0.0/0", 0, "128.192.224.240", isNoAutoSubnets?"128.192.224.240":"128-255.192-255.224-255.240-255");
        this.testBitwiseOr("*.*", 0, "128.192.224.240", "128-255.192-255.224-255.240-255");
        this.testBitwiseOr("0.0.0.0/0", 0, "128.192.224.64", isNoAutoSubnets?"128.192.224.64":null);
        this.testBitwiseOr("*.*", 0, "128.192.224.64", null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.3.0.0/15", 24, "0.0.255.1", allPrefixesAreSubnets?"1.2-3.255.0/24":"1.3.255.0/24", "1.3.255.1/15");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.3.0.1/15", 24, "0.0.255.1", allPrefixesAreSubnets?"1.2-3.255.0/24":"1.3.255.1/24", "1.3.255.1/15");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.3.0.1/15", 24, "0.0.255.0", allPrefixesAreSubnets?"1.2-3.255.0/24":"1.3.255.1/24", "1.3.255.1/15");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/22", 24, "0.0.3.248", "1.2.3.0/24", isNoAutoSubnets?"1.2.3.248/22":(allPrefixesAreSubnets?"1.2.0.0/22":"1.2.3.248-255/22"));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/24", 24, "0.0.3.248", "1.2.3.0/24", isNoAutoSubnets?"1.2.3.248/24":(allPrefixesAreSubnets?"1.2.3.0/24":"1.2.3.248-255/24"));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/22", 23, "0.0.3.0", "1.2.2.0/23", allPrefixesAreSubnets?"1.2.0.0/22":(isNoAutoSubnets?"1.2.3.0/22":"1.2.3.0-255/22"));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/24", 23, "0.0.3.0", "1.2.2.0/23", allPrefixesAreSubnets?"1.2.3.0/24":(isNoAutoSubnets?"1.2.3.0/24":"1.2.3.0-255/24"));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/46", 47, "0:0:3::", "1:2:2::/47", isNoAutoSubnets || allPrefixesAreSubnets?"1:2:3::/46":"1:2:3:*:*:*:*:*/46");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("0.0.0.0/16", 18, "0.0.2.8", isNoAutoSubnets?"0.0.0.0/18":"0.0.0-192.0/18", isNoAutoSubnets || allPrefixesAreSubnets?"0.0.2.8/16":null);
        this.testBitwiseOr("1:2::/32", 16, "0:0:3:fff8::", isNoAutoSubnets?"1:2:3:fff8::":"1:2:3:fff8-ffff:*");
        this.testBitwiseOr("1:2::/32", 15, "0:0:2::", isNoAutoSubnets?"1:2:2::":"1:2:2-3:*");
        this.testBitwiseOr("1:2:*", 0, "0:0:8000::", "1:2:8000-ffff:*");
        this.testBitwiseOr("1:2:*", 0, "0:0:c000::", "1:2:c000-ffff:*");
        this.testBitwiseOr("1:2::/32", 15, "0:0:3::", isNoAutoSubnets?"1:2:3::":"1:2:3:*");
        this.testBitwiseOr("::/0", 0, "8000:c000:e000:fff0::", isNoAutoSubnets?"8000:c000:e000:fff0::":"8000-ffff:c000-ffff:e000-ffff:fff0-ffff:*");
        this.testBitwiseOr("*:*", 0, "8000:c000:e000:fff0::", "8000-ffff:c000-ffff:e000-ffff:fff0-ffff:*");
        this.testBitwiseOr("::/0", 0, "8000:c000:e000:4000::", isNoAutoSubnets?"8000:c000:e000:4000::":null);
        this.testBitwiseOr("1:1::/16", 32, "0:2:3::ffff", isNoAutoSubnets?"1:2:3::ffff":"1:2:3:*:*:*:*:ffff");
        this.testBitwiseOr("1:0:0:1::/16", 32, "0:2:3::ffff", allPrefixesAreSubnets?"1:2:3:*:*:*:*:ffff":"1:2:3:1::ffff");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("::/32", 34, "0:0:2:8::", isNoAutoSubnets?"::/34":"0:0:0-c000::/34", isNoAutoSubnets || allPrefixesAreSubnets?"0:0:2:8::/32":null);
        this.testDelimitedCount("1,2-3,4:3:4,5:6:7:8:ffff:ffff", 8);
        this.testDelimitedCount("1,2::3,6:7:8:4,5-6:6,8", 16);
        this.testDelimitedCount("1:2:3:*:4::5", 1);
        this.testDelimitedCount("1:2,3,*:3:ffff:ffff:6:4:5,ff,7,8,99", 15);
        this.testDelimitedCount("0,1-2,3,5:3::6:4:5,ffff,7,8,99", 30);
        let isAutoSubnets : boolean = !isNoAutoSubnets;
        let isAllSubnets : boolean = allPrefixesAreSubnets;
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/0", "1-2.*.3.*", isAutoSubnets, false);
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("0-127.0.0.0/1", "127-127.*.3.*", false);
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0-127.0.0.0/8", "127-127.*.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "13-15.*.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0-15.*.*.*/4", "13-15.*.3.*", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "9.*.237.*/16", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "8-9.*.237.*/16", isAutoSubnets, false);
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("1-2.0.0.0/4", "9.*.237.*/16", false);
            this.testContains$java_lang_String$java_lang_String$boolean("1-2.0.0.0/4", "8-9.*.237.*/16", false);
        } else {
            this.testNotContains("1-2.0.0.0/4", "9.*.237.*/16");
            this.testNotContains("1-2.0.0.0/4", "8-9.*.237.*/16");
        }
        this.testNotContains("1-2.0.0.0/4", "9-17.*.237.*/16");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.0/5", "15.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.0/7", "8-9.*.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.0.0.0/8", "9.*.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/9", "9.128-255.*.0", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/15", "9.128-129.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.0.0/16", "9.129.3.*", isAutoSubnets, false);
        this.testNotContains("9.129.0.0/16", "9.128-129.3.*");
        this.testNotContains("9.129.0.0/16", "9.128.3.*");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24/30", "9.129.237.24-27", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24/30", "9.129.237.24-27/31", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24-27/30", "9.129.237.24-27/31", true, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("*.*.*.*/0", "9.129.237.26/0", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/0", "*.*.*.*/0", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "0-15.0.0.*/4", isAutoSubnets, isAllSubnets);
        this.testNotContains("192.0.0.0/4", "0-15.0.0.*/4");
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("0-127.129.237.26/1", "0-127.0.*.0/1", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/0", "*.*.*.*/0", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/4", "0-15.0.0.*/4", true);
            this.testContains$java_lang_String$java_lang_String$boolean("1-16.0.0.*/4", "9.129.237.26/4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/5", "8-15.0.0.0/5", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/7", "8-9.0.0.1-3/7", true);
            this.testContains$java_lang_String$java_lang_String$boolean("7-9.0.0.1-3/7", "9.129.237.26/7", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/8", "9.*.0.0/8", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/9", "9.128-255.0.0/9", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/15", "9.128-129.0.*/15", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/16", "9.129.*.*/16", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/30", "9.129.237.24-27/30", true);
        } else {
            this.testNotContains("0-127.129.237.26/1", "0-127.0.*.0/1");
            this.testNotContains("9.129.237.26/0", "*.*.*.1/0");
            this.testNotContains("9.129.237.26/4", "0-15.0.1.*/4");
            this.testNotContains("1-16.0.0.*/4", "9.129.237.26/4");
            this.testNotContains("9.129.237.26/5", "8-15.0.0.0/5");
            this.testNotContains("9.129.237.26/7", "8-9.0.0.1-3/7");
            this.testNotContains("7-9.0.0.1-3/7", "9.129.237.26/7");
            this.testNotContains("9.129.237.26/8", "9.*.0.0/8");
            this.testNotContains("9.129.237.26/9", "9.128-255.0.0/9");
            this.testNotContains("9.129.237.26/15", "9.128-129.0.*/15");
            this.testNotContains("9.129.237.26/16", "9.129.*.1/16");
            this.testNotContains("9.129.237.26/30", "9.129.237.27/30");
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.*/4", "9.129.237.26/4", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.*/5", "8-15.0.0.0/5", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.*/7", "8-9.0.0.1-3/7", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("7-9.*.*.*/7", "9.129.237.26/7", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.0.0.0/8", "9.*.0.0/8", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/9", "9.128-255.0.0/9", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/15", "9.128-129.0.*/15", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/15", "9.128.0.*/15", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.0.0/16", "9.129.*.*/16", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.*.*/15", "9.128.0.*/15", true, isAutoSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.*.*/16", "9.128.0.*/16", true, isAutoSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.*.*/16", "9.129.*.*/16", true, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.*.*/16", "9.129.*.0/16", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24/30", "9.129.237.24-27/30", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128-129.*.26/32", "9.128-129.*.26/32", true, true);
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("1-16.0.0.*/4", "9.129.237.26/4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/5", "8-15.0.0.0/5", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/7", "8-9.0.0.1-3/7", true);
            this.testContains$java_lang_String$java_lang_String$boolean("7-9.0.0.1-3/7", "9.129.237.26/7", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/8", "9.*.0.0/8", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/9", "9.128-255.0.0/9", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/15", "9.128-129.0.*/15", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/16", "9.129.*.*/16", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/30", "9.129.237.24-27/30", true);
        } else {
            this.testNotContains("1-16.0.0.*/4", "9.129.237.26/4");
            this.testNotContains("9.129.237.26/5", "8-15.0.0.0/5");
            this.testNotContains("9.129.237.26/7", "8-9.0.0.1-3/7");
            this.testNotContains("7-9.0.0.1-3/7", "9.129.237.26/7");
            this.testNotContains("9.129.237.26/8", "9.*.0.0/8");
            this.testNotContains("9.129.237.26/9", "9.128-255.0.0/9");
            this.testNotContains("9.129.237.26/15", "9.128-129.0.*/15");
            this.testNotContains("9.129.237.26/16", "9.129.*.1/16");
            this.testNotContains("9.129.237.26/16", "9.129.1.*/16");
            this.testNotContains("9.129.237.25/30", "9.129.237.26/30");
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("1-16.0.0.*/4", "9.0.0.*/4", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("1-16.0.0.0-254/4", "9.0.0.*/4", isAllSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0-16.0.0.0/4", "9.0.0.*/4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8-15.129.237.26/5", "9.129.237.26/5", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8-9.129.237.26/7", "9.129.237.26/7", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("7-9.0.0.1-3/7", "9.0.0.2/7", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.*.237.26/8", "9.*.237.26/8", true, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128-255.237.26/9", "9.129.237.26/9", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128-129.237.26/15", "9.129.237.26/15", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.*.*/16", "9.129.237.26/16", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24-27/30", "9.129.237.26/30", true, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128-129.*.26/32", "9.128-129.*.26/32", true, true);
        this.testNotContains("9.129.237.26/4", "16-17.0.0.*/4");
        this.testNotContains("9.129.237.26/7", "2.0.0.1-3/7");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("::ffff:1.*.3.4", "1.2.3.4", true, false);
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("::ffff:1.2-4.3.4/112", "1.2-3.3.*", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff:0:0:0:0:0:*:0/32", "ffff:0:ffff:1-d:e:f:*:b", false);
            this.testContains$java_lang_String$java_lang_String$boolean("fffc-ffff::ffff/30", "fffd-fffe:0:0:0:0:0:0:0/30", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff:0-d::ffff/32", "ffff:a-c:0:0:0:0:0:0/32", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/0", "a-b:0:b:0:c:d-e:*:0/0", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/1", "8000-8fff:0:0:0:0:*:a-b:0/1", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff:*::ffff/126", "ffff:*:0:0:0:0:0:fffc-ffff/126", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff:1-2::ffff/126", "ffff:1-2:0:0:0:0:0:fffc-ffff/126", true);
        } else {
            this.testNotContains("::ffff:1.2-4.3.4/112", "1.2-3.3.*");
            this.testNotContains("ffff:0:0:0:0:0:*:0/32", "ffff:0:ffff:1-d:e:f:*:b");
            this.testNotContains("fffc-ffff::ffff/30", "fffd-fffe:0:0:0:0:0:0:0/30");
            this.testNotContains("ffff:0-d::ffff/32", "ffff:a-c:0:0:0:0:0:0/32");
            this.testNotContains("ffff::ffff/0", "a-b:0:b:0:c:d-e:*:0/0");
            this.testNotContains("ffff::ffff/1", "8000-8fff:0:0:0:0:*:a-b:0/1");
            this.testNotContains("ffff:*::fffb/126", "ffff:*:0:0:0:0:0:fffc-ffff/126");
            this.testNotContains("ffff:1-2::fffb/126", "ffff:1-2:0:0:0:0:0:fffc-ffff/126");
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("::ffff:1.2-4.0.0/112", "1.2-3.3.*", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0:0:0:0:0:0:0:0/0", "a:*:c:d:e:1-ffff:a:b", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8000:0:0:0:0:0:0:0/1", "8000-8fff:b:c:d:e:f:*:b", isAutoSubnets, false);
        this.testNotContains("8000:0:0:0:0:0:0:0/1", "7fff-8fff:b:c:d:e:f:*:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:0:0:0/30", "ffff:0-3:c:d:e:f:a:b", isAutoSubnets, false);
        this.testNotContains("ffff:0:0:0:0:0:0:0/30", "ffff:0-4:c:d:e:f:a:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:0:0:0/32", "ffff:0:ffff:1-d:e:f:*:b", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("fffc-ffff::/30", "fffd-fffe:0:0:0:0:0:0:0/30", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0-d::/32", "ffff:a-c:0:0:0:0:0:0/32", true, false);
        this.testNotContains("ffff:0:0:0:0:1-2:0:0/32", "ffff:0-1:ffff:d:e:f:a:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:4-ffff:0:fffc-ffff", "ffff:0:0:0:0:4-ffff:0:fffd-ffff", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:4-ffff:0:fffc/126", "ffff:0:0:0:0:4-ffff:0:fffd-ffff", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:4-ffff:0:fffc/126", "ffff:0:0:0:0:4-ffff:0:fffc-ffff", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:*:0:0:4-ffff:0:ffff/128", "ffff:0:*:0:0:4-ffff:0:ffff", true, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:*:0:0:0:0:0:fffa-ffff/126", "ffff:*::ffff/126", true, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("::/0", "a-b:0:b:0:c:d-e:*:0/0", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8000::/1", "8000-8fff:0:0:0:0:*:a-b:0/1", isAutoSubnets, isAllSubnets);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:*::fffc/126", "ffff:*:0:0:0:0:0:fffc-ffff/126", isAutoSubnets, true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:1-2::fffc/126", "ffff:1-2:0:0:0:0:0:fffc-ffff/126", isAutoSubnets, true);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("25:51:27:*:*:*:*:*", null, 48, 48);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("25:51:27:*:*:*:*:*/48", 48, 48, 48);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("25:50-51:27::/48", 48, isAutoSubnets?48:128, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("25:50-51:27:*:*:*:*:*", null, 48, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("25:51:27:12:82:55:2:2", null, 128, 128);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:*:*", null, 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:0-fe:*", null, 112, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:0-ff:*", null, 104, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:0-ffff:*", null, 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:0-7fff:*", null, 97, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*:*:*:*:*:*:8000-ffff:*", null, 97, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("*.*.*.*", null, 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("3.*.*.*", null, 8, 8);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("3.*.*.1-3", null, 32, null);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("3.0-127.*.*", null, 9, 9);
        this.testPrefix$java_lang_String$java_lang_Integer$int$java_lang_Integer("3.128-255.*.*", null, 9, 9);
        this.ipv4test$boolean$java_lang_String(true, "1.2.*.4/1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/-1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/x");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/33");
        this.ipv6test$boolean$java_lang_String(true, "1:*::1/1");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/-1");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/x");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/129");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/1-2.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/1-2.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/**");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/**");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/*.*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/*.*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/*:*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/*:*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/*:*:*:*:*:*:*:*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/*:*:*:*:*:*:*:*");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/1.2.*.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.*.4/1.2.*.4");
        this.ipv4test$boolean$java_lang_String(true, "1.2.*.4/1.2.3.4");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/*");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/*");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/1:1-2:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/1:1-2:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/**");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/**");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/*:*");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/*:*");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/*.*");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/*.*");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/*.*.*.*");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/*.*.*.*");
        this.ipv6test$boolean$java_lang_String(false, "1:2::1/1:*::2");
        this.ipv6test$boolean$java_lang_String(false, "1:*::1/1:*::2");
        this.ipv6test$boolean$java_lang_String(true, "1:*::1/1::2");
        this.testResolved("8.*.27.26", "8.*.27.26");
        this.testResolved("2001:*:0:0:8:800:200C:417A", "2001:*:0:0:8:800:200C:417A");
        this.testNormalized$java_lang_String$java_lang_String("ABCD:EF12:*:*:***:A:*:BBBB", "abcd:ef12:*:*:*:a:*:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("ABCD:EF12:*:*:**:A:***:BBBB%g", "abcd:ef12:*:*:*:a:*:bbbb%g");
        this.testNormalized$java_lang_String$java_lang_String("1.*", "1.*.*.*");
        this.testNormalized$java_lang_String$java_lang_String("*.1.*", "*.1.*.*");
        this.testNormalized$java_lang_String$java_lang_String("*:1::*", "*:1::*");
        this.testNormalized$java_lang_String$java_lang_String("*:1:*", "*:1:*:*:*:*:*:*");
        this.testNormalized$java_lang_String$java_lang_String("001-002:0001-0002:01-2:1-02:01-02:*", "1-2:1-2:1-2:1-2:1-2:*:*:*");
        if(allPrefixesAreSubnets) {
            this.testIPv4Wildcarded("1.2.3.4", 8, "1.*.*.*", "1.%.%.%");
            this.testIPv4Wildcarded("1.2.3.4", 9, "1.0-127.*.*", "1.0-127.%.%");
            this.testIPv4Wildcarded("1.2.3.4", 15, "1.2-3.*.*", "1.2-3.%.%");
            this.testIPv4Wildcarded("1.3.3.4", 15, "1.2-3.*.*", "1.2-3.%.%");
            this.testIPv4Wildcarded("1.2.3.4", 16, "1.2.*.*", "1.2.%.%");
            this.testIPv6Wildcarded("1::1", 16, "1::/16", "1:*:*:*:*:*:*:*", "1:%:%:%:%:%:%:%");
            this.testIPv4Wildcarded("1.3.0.0", 15, "1.2-3.*.*", "1.2-3.%.%");
        } else {
            this.testIPv4Wildcarded("1.2.3.4", 8, "1.2.3.4", "1.2.3.4");
            this.testIPv4Wildcarded("1.2.3.4", 9, "1.2.3.4", "1.2.3.4");
            this.testIPv4Wildcarded("1.2.3.4", 15, "1.2.3.4", "1.2.3.4");
            this.testIPv4Wildcarded("1.3.3.4", 15, "1.3.3.4", "1.3.3.4");
            this.testIPv4Wildcarded("1.2.3.4", 16, "1.2.3.4", "1.2.3.4");
            this.testWildcarded("1::1", 16, "1::1/16", "1:0:0:0:0:0:0:1", "1::1", "1::1", "1:0:0:0:0:0:0:1");
            this.testIPv4Wildcarded("1.3.0.0", 15, "1.3.0.0", "1.3.0.0");
        }
        if(isAutoSubnets) {
            this.testIPv4Wildcarded("1.0.0.0", 8, "1.*.*.*", "1.%.%.%");
            this.testIPv4Wildcarded("1.0.0.0", 9, "1.0-127.*.*", "1.0-127.%.%");
            this.testIPv4Wildcarded("1.2.0.0", 15, "1.2-3.*.*", "1.2-3.%.%");
            this.testIPv4Wildcarded("1.2.0.0", 16, "1.2.*.*", "1.2.%.%");
            this.testWildcarded("1:0::", 32, "1::/32", "1:0:*:*:*:*:*:*", "1:0:*:*:*:*:*:*", "1::*:*:*:*:*:*", "1:0:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1::", 16, "1::/16", "1:*:*:*:*:*:*:*", "1:%:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1::", 20, "1::/20", "1:0-fff:*:*:*:*:*:*", "1:0-fff:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1:f000::", 20, "1:f000::/20", "1:f000-ffff:*:*:*:*:*:*", "1:f___:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1::", 17, "1::/17", "1:0-7fff:*:*:*:*:*:*", "1:0-7fff:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1:10::", 28, "1:10::/28", "1:10-1f:*:*:*:*:*:*", "1:1_:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1::", 28, "1::/28", "1:0-f:*:*:*:*:*:*", "1:_:%:%:%:%:%:%");
            this.testIPv6Wildcarded("1::", 31, "1::/31", "1:0-1:*:*:*:*:*:*", "1:0-1:%:%:%:%:%:%");
            this.testWildcarded("1::", 36, "1::/36", "1:0:0-fff:*:*:*:*:*", "1:0:0-fff:*:*:*:*:*", "1::0-fff:*:*:*:*:*", "1:0:0-fff:%:%:%:%:%");
            this.testWildcarded("1::", 52, "1::/52", "1:0:0:0-fff:*:*:*:*", "1::0-fff:*:*:*:*", "1::0-fff:*:*:*:*", "1:0:0:0-fff:%:%:%:%");
            this.testWildcarded("1::", 60, "1::/60", "1:0:0:0-f:*:*:*:*", "1::0-f:*:*:*:*", "1::0-f:*:*:*:*", "1:0:0:_:%:%:%:%");
        } else {
            this.testIPv4Wildcarded("1.0.0.0", 8, "1.0.0.0", "1.0.0.0");
            this.testIPv4Wildcarded("1.0.0.0", 9, "1.0.0.0", "1.0.0.0");
            this.testIPv4Wildcarded("1.2.0.0", 15, "1.2.0.0", "1.2.0.0");
            this.testIPv4Wildcarded("1.2.0.0", 16, "1.2.0.0", "1.2.0.0");
            this.testWildcarded("1:0::", 32, "1::/32", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1::", 16, "1::/16", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1::", 20, "1::/20", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1:f000::", 20, "1:f000::/20", "1:f000:0:0:0:0:0:0", "1:f000::", "1:f000::", "1:f000:0:0:0:0:0:0");
            this.testWildcarded("1::", 17, "1::/17", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1:10::", 28, "1:10::/28", "1:10:0:0:0:0:0:0", "1:10::", "1:10::", "1:10:0:0:0:0:0:0");
            this.testWildcarded("1::", 31, "1::/31", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1::", 36, "1::/36", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1::", 52, "1::/52", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
            this.testWildcarded("1::", 60, "1::/60", "1:0:0:0:0:0:0:0", "1::", "1::", "1:0:0:0:0:0:0:0");
        }
        this.testIPv4Wildcarded("1.*.*.*", 8, "1.*.*.*", "1.%.%.%");
        this.testIPv4Wildcarded("1.0-127.*.*", 9, "1.0-127.*.*", "1.0-127.%.%");
        this.testWildcarded("1:0:*", 32, isAutoSubnets?"1::/32":"1::*:*:*:*:*:*/32", "1:0:*:*:*:*:*:*", "1:0:*:*:*:*:*:*", "1::*:*:*:*:*:*", "1:0:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:*", 16, isAutoSubnets?"1::/16":"1:*:*:*:*:*:*:*/16", "1:*:*:*:*:*:*:*", "1:%:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:0-fff:*", 20, isAutoSubnets?"1::/20":"1:0-fff:*:*:*:*:*:*/20", "1:0-fff:*:*:*:*:*:*", "1:0-fff:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:f000-ffff:*", 20, isAutoSubnets?"1:f000::/20":"1:f000-ffff:*:*:*:*:*:*/20", "1:f000-ffff:*:*:*:*:*:*", "1:f___:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:8000-ffff:*", 17, isAutoSubnets?"1:8000::/17":"1:8000-ffff:*:*:*:*:*:*/17", "1:8000-ffff:*:*:*:*:*:*", "1:8000-ffff:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:10-1f:*", 28, isAutoSubnets?"1:10::/28":"1:10-1f:*:*:*:*:*:*/28", "1:10-1f:*:*:*:*:*:*", "1:1_:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:0-f:*", 28, isAutoSubnets?"1::/28":"1:0-f:*:*:*:*:*:*/28", "1:0-f:*:*:*:*:*:*", "1:_:%:%:%:%:%:%");
        this.testIPv6Wildcarded("1:0-1:*", 31, isAutoSubnets?"1::/31":"1:0-1:*:*:*:*:*:*/31", "1:0-1:*:*:*:*:*:*", "1:0-1:%:%:%:%:%:%");
        this.testWildcarded("1:0:0-fff:*", 36, isAutoSubnets?"1::/36":"1::0-fff:*:*:*:*:*/36", "1:0:0-fff:*:*:*:*:*", "1:0:0-fff:*:*:*:*:*", "1::0-fff:*:*:*:*:*", "1:0:0-fff:%:%:%:%:%");
        this.testWildcarded("1:0:0:0-fff:*", 52, isAutoSubnets?"1::/52":"1::0-fff:*:*:*:*/52", "1:0:0:0-fff:*:*:*:*", "1::0-fff:*:*:*:*", "1::0-fff:*:*:*:*", "1:0:0:0-fff:%:%:%:%");
        this.testWildcarded("1:0:0:0-f:*", 60, isAutoSubnets?"1::/60":"1::0-f:*:*:*:*/60", "1:0:0:0-f:*:*:*:*", "1::0-f:*:*:*:*", "1::0-f:*:*:*:*", "1:0:0:_:%:%:%:%");
        this.testPrefixCount("1.2.3.*/31", 128);
        this.testPrefixCount("1.2.3.*/25", 2);
        this.testPrefixCount("1.2.*.4/31", 256);
        this.testPrefixCount("1.2.*.4/23", 128);
        this.testPrefixCount("*.2.*.4/23", 128 * 256);
        this.testPrefixCount("*.2.3.*/7", 128);
        this.testPrefixCount("2-3.2.3.*/8", 2);
        this.testPrefixCount("2-3.3-4.3.*/16", 4);
        this.testPrefixCount("2-3.3-4.3.*/12", 2);
        this.testPrefixCount("2-3.3-4.3.*", 256 * 2 * 2);
        this.testPrefixCount("2-3.3-4.3.*/32", 256 * 2 * 2);
        this.testPrefixCount("192.168.0.0-8/29", 2);
        this.testPrefixCount("192.168.0.0-15/29", 2);
        this.testCount$java_lang_String$long$long("1.2.3.4", 1, 1);
        this.testCount$java_lang_String$long$long("1.2.3.4/32", 1, 1);
        this.testCount$java_lang_String$long$long("1.2.3.5/31", allPrefixesAreSubnets?2:1, 1);
        this.testCount$java_lang_String$long$long("1.2.3.4/31", isNoAutoSubnets?1:2, isNoAutoSubnets?0:1);
        this.testCount$java_lang_String$long$long("1.2.3.4/30", isNoAutoSubnets?1:4, isNoAutoSubnets?0:3);
        this.testCount$java_lang_String$long$long("1.2.3.6/30", allPrefixesAreSubnets?4:1, allPrefixesAreSubnets?3:1);
        this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1.1-2.3.4", 2, 2, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.testCount$java_lang_String$long$long("1.*.3.4", 256, 256);
        this.testCount$java_lang_String$long$long("1.2.252.0/22", isNoAutoSubnets?1:4 * 256, isNoAutoSubnets?0:(4 * 256) - 1);
        this.testCount$java_lang_String$long$long("1-2.2.252.0/22", isNoAutoSubnets?2:2 * 4 * 256, isNoAutoSubnets?0:2 * ((4 * 256) - 1));
        if(this.fullTest) {
            this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1.*.11-200.4", 190 * 256, 190 * 256, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
            this.testCount$java_lang_String$long$long("1.3.*.4/16", allPrefixesAreSubnets?256 * 256:256, allPrefixesAreSubnets?(256 * 256) - 1:256);
            this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1.2.*.1-3/25", allPrefixesAreSubnets?256 * 128:256 * 3, allPrefixesAreSubnets?(256 * 128) - 256:256 * 3, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
            this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1.2.*.0-2/25", allPrefixesAreSubnets?256 * 128:256 * 3, allPrefixesAreSubnets?(256 * 128) - 256:(256 * 3) - 256, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
            this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("11-13.*.0.0/23", !isNoAutoSubnets?3 * 256 * 2 * 256:3 * 256, !isNoAutoSubnets?((3 * 256) * (2 * 256)) - (3 * 256):0, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        }
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(true, "1.1.*.100-101", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(false, "1.2.*.101-100", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(true, "1.2.*.101-101", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(true, "1:2:4:a-ff:0-2::1", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(false, "1:2:4:ff-a:0-2::1", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(false, "1.2.*.101-100/24", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(true, "1.*.3.4", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$(), AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
        this.ipv4test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(false, "1.*.3.4", AddressStringParameters.RangeParameters.NO_RANGE_$LI$(), AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(false, "a:*::1.*.3.4", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$(), AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(true, "a:*::1.*.3.4", AddressStringParameters.RangeParameters.NO_RANGE_$LI$(), AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(false, "a:*::", AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$(), AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
        this.ipv6test$boolean$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters$inet_ipaddr_AddressStringParameters_RangeParameters(true, "a:*::", AddressStringParameters.RangeParameters.NO_RANGE_$LI$(), AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.1-255");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.1-256");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.512-65535");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.512-65536");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.65536-16777215");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.65536-16777216");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "16777216-4294967295");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "16777216-4294967296");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.0x1x");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.1x");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.0x1-0xff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.0x1-0x100");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0xfffe-0xffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0xfffe-0x10000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0x10000-0x10001");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0-0xffffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0-0x1000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0x11000000-0xffffffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0x11000000-0x100000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0x100000000-0x100ffffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.00-0377");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.00-0400");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0x100-017777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0x100-0200000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0x10000-077777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0x10000-0100000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0x1000000-03777777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0x1000000-037777777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0x1000000-040000000000");
        this.ipv4test$boolean$java_lang_String(true, "*");
        this.ipv4test$boolean$java_lang_String$boolean$boolean(false, "*%", false, true);
        this.ipv4test$boolean$java_lang_String$boolean$boolean(false, "*%x", false, true);
        this.ipv4test$boolean$java_lang_String(true, "**");
        this.ipv6test$boolean$java_lang_String(true, "*%x");
        this.ipv4test$boolean$java_lang_String(true, "*.*.*.*");
        this.ipv4test$boolean$java_lang_String(true, "1.*.3");
        this.ipv4test$boolean$java_lang_String(false, "a.*.3.4");
        this.ipv4test$boolean$java_lang_String(false, "*.a.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.*.a.4");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.a");
        this.ipv4test$boolean$java_lang_String(false, ".2.3.*");
        this.ipv4test$boolean$java_lang_String(false, "1..*.4");
        this.ipv4test$boolean$java_lang_String(false, "1.*..4");
        this.ipv4test$boolean$java_lang_String(false, "*.2.3.");
        this.ipv4test$boolean$java_lang_String(false, "256.*.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.256.*.4");
        this.ipv4test$boolean$java_lang_String(false, "*.2.256.4");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.256");
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "00.*.0.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.00.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.*.00.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "*.0.0.00", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "000.0.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.000.0.*", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "*.0.000.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.*.000", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "00.*.0.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.00.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.*.00.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "*.0.0.00", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "000.0.*.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.000.0.*", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "*.0.000.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.*.000", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "000.000.000.*", false);
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "0000.0.*.0");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "*.0000.0.0");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "0.*.0000.0");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "*.0.0.0000");
        this.ipv4test$boolean$java_lang_String(false, ".0.*.0");
        this.ipv4test$boolean$java_lang_String(false, "0..*.0");
        this.ipv4test$boolean$java_lang_String(false, "0.*..0");
        this.ipv4test$boolean$java_lang_String(false, "*.0.0.");
        this.ipv4test$boolean$java_lang_String(true, "1.*.3.4/255.1.0.0");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.4/255.1.0.0/16");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.4/255.*.0.0");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.4/255.1-2.0.0");
        this.ipv4test$boolean$java_lang_String(false, "1.*.3.4/1::1");
        this.ipv6test$boolean$java_lang_String(false, "1:*::/1.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/255.*.0.0");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/255.1-2.0.0");
        this.ipv6test$boolean$java_lang_String(false, "1:2::/1:*::");
        this.ipv6test$boolean$java_lang_String(false, "1:2::/1:1-2::");
        this.ipv4testOnly(false, "1:2:3:4:5:*:7:8");
        this.ipv4testOnly(false, "*::1");
        this.ipv6test$int$java_lang_String(1, "*");
        this.ipv6test$int$java_lang_String(1, "*%");
        this.ipv6test$int$java_lang_String(1, "*:*:*:*:*:*:*:*");
        this.ipv6test$int$java_lang_String(1, "*::1");
        if(this.fullTest) this.testCount$java_lang_String$long$long("*::1", 65535 + 1, 65535 + 1);
        this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1-3::1", 3, 3, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("0-299::1", 665 + 1, 665 + 1, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        if(this.fullTest) this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1:2:4:*:0-2::1", 3 * (65535 + 1), 3 * (65535 + 1), AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.testCount$java_lang_String$long$long$inet_ipaddr_AddressStringParameters_RangeParameters("1:2:4:0-2:0-2::1", 3 * 3, 3 * 3, AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$());
        this.testCount$java_lang_String$long$long("1::2:3", 1, 1);
        this.testCount$java_lang_String$long$long("1::2:3/128", 1, 1);
        this.testCount$java_lang_String$long$long("1::2:3/127", allPrefixesAreSubnets?2:1, 1);
        this.testPrefixCount("1::2:*/127", 32768);
        this.testPrefixCount("1::2:*/113", 2);
        this.testPrefixCount("1::2:*/112", 1);
        this.testPrefixCount("*::2:*/112", 65536);
        this.testPrefixCount("*:1-3::2:*/112", 65536 * 3);
        if(this.fullTest) {
            this.testCount$java_lang_String$long$long("1:2::fffc:0/110", isNoAutoSubnets?1:4 * 65536, isNoAutoSubnets?0:(4 * 65536) - 1);
            this.testCount$java_lang_String$long$long("1-2:2::fffc:0/110", isNoAutoSubnets?2:2 * 4 * 65536, isNoAutoSubnets?0:2 * ((4 * 65536) - 1));
            this.testCount$java_lang_String$long$long("*::", 65535 + 1, 65535 + 1);
            this.testCount$java_lang_String$long$long("::*", 65535 + 1, 65535 + 1);
            this.testCount$java_lang_String$long$long("0-199::0-199", (410) * (410), (410) * (410));
            this.testCount$java_lang_String$java_math_BigInteger$java_math_BigInteger("*:*", new BigInteger("ffffffffffffffffffffffffffffffff", 16).add(BigInteger.ONE), new BigInteger("ffffffffffffffffffffffffffffffff", 16).add(BigInteger.ONE));
            let full : BigInteger = new BigInteger("10000", 16).pow(8);
            let half : BigInteger = new BigInteger("10000", 16).pow(4);
            this.testCount$java_lang_String$java_math_BigInteger$java_math_BigInteger("*:*/64", full, full.subtract(half));
        }
        this.ipv4test$boolean$java_lang_String(true, "1.0-0.3.0");
        this.ipv4test$boolean$java_lang_String(true, "1.0-3.3.0");
        this.ipv4test$boolean$java_lang_String(true, "1.1-3.3.0");
        this.ipv6test$boolean$java_lang_String(true, "1:0-0:2:0::");
        this.ipv6test$boolean$java_lang_String(true, "1:0-3:2:0::");
        this.ipv6test$boolean$java_lang_String(true, "1:1-3:2:0::");
        this.ipv6test$int$java_lang_String$boolean(1, "::*", false);
        this.ipv6test$int$java_lang_String(1, "0:0:*:0:0:0:0:1");
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:*:0:0:0:0:0", false);
        this.ipv6test$int$java_lang_String(1, "2001:*:0:0:8:800:200C:417A");
        this.ipv6test$int$java_lang_String(1, "FF01:*:0:0:0:0:0:101");
        this.ipv6test$int$java_lang_String(1, "2001:DB8::8:800:200C:*");
        this.ipv6test$int$java_lang_String(1, "FF01::*:101");
        this.ipv6test$int$java_lang_String(0, "2001:DB8:0:0:8:*:200C:417A:221");
        this.ipv6test$int$java_lang_String(0, "FF01::101::*");
        this.ipv6test$int$java_lang_String(1, "fe80::217:f2ff:*:ed62");
        this.ipv6test$int$java_lang_String(1, "2001:*:1234:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(1, "3ffe:0b00:0000:0000:0001:0000:*:000a");
        this.ipv6test$int$java_lang_String(1, "FF02:0000:0000:0000:0000:0000:*:0001");
        this.ipv6test$int$java_lang_String(1, "*:0000:0000:0000:0000:0000:0000:0001");
        this.ipv6test$int$java_lang_String$boolean(0, "0000:0000:0000:0000:*0000:0000:0000:*0", true);
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "02001:*:1234:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "2001:0000:1234:0000:0*:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(1, "2001:0000:1234:0000:*:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "2001:0000:1234:0000:0000:C1C0*:ABCD:0876  0");
        this.ipv6test$int$java_lang_String(0, "0 2001:0000:123*:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "2001:0000:1234: 0000:0000:C1C0:*:0876");
        this.ipv6test$int$java_lang_String(1, "3ffe:0b00:*:0001:0000:0000:000a");
        this.ipv6test$int$java_lang_String(0, "3ffe:0b00:1:0001:0000:0000:000a");
        this.ipv6test$int$java_lang_String(0, "FF02:0000:0000:0000:0000:0000:0000:*:0001");
        this.ipv6test$int$java_lang_String(0, "3ffe:*::1::a");
        this.ipv6test$int$java_lang_String(0, "::1111:2222:3333:4444:5555:*::");
        this.ipv6test$int$java_lang_String(1, "2::10");
        this.ipv6test$int$java_lang_String(1, "ff02::1");
        this.ipv6test$int$java_lang_String(1, "fe80:*::");
        this.ipv6test$int$java_lang_String(1, "2002:*::");
        this.ipv6test$int$java_lang_String(1, "2001:*::");
        this.ipv6test$int$java_lang_String(1, "*:0db8:1234::");
        this.ipv6test$int$java_lang_String(1, "::ffff:*:0");
        this.ipv6test$int$java_lang_String(1, "*::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:*:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:*:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::*");
        this.ipv6test$int$java_lang_String(1, "1:2:3:*::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3::8");
        this.ipv6test$int$java_lang_String(1, "*:2::8");
        this.ipv6test$int$java_lang_String(1, "1::*");
        this.ipv6test$int$java_lang_String(1, "*::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "*::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:*");
        this.ipv6test$int$java_lang_String(1, "1::2:*:4");
        this.ipv6test$int$java_lang_String(1, "1::*:3");
        this.ipv6test$int$java_lang_String(1, "1::*");
        this.ipv6test$int$java_lang_String(1, "::*:3:4:5:6:7:8");
        this.ipv6test$int$java_lang_String(1, "*::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "::*:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "::*:3:4:5");
        this.ipv6test$int$java_lang_String(1, "::2:3:*");
        this.ipv6test$int$java_lang_String(1, "*::2:3");
        this.ipv6test$int$java_lang_String(1, "::*");
        this.ipv6test$int$java_lang_String(1, "1:*:3:4:5:6::");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:*::");
        this.ipv6test$int$java_lang_String(1, "1:2:3:*::");
        this.ipv6test$int$java_lang_String(1, "1:2:3::*");
        this.ipv6test$int$java_lang_String(1, "*:2::");
        this.ipv6test$int$java_lang_String(1, "*::");
        this.ipv6test$int$java_lang_String(1, "*:2:3:4:5::7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:3::4:5::7:*");
        this.ipv6test$int$java_lang_String(0, "12345::6:7:*");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::*:*");
        this.ipv6test$int$java_lang_String(1, "1:*:3::7:8");
        this.ipv6test$int$java_lang_String(1, "*:*::7:8");
        this.ipv6test$int$java_lang_String(1, "*::*:8");
        this.ipv6test$boolean$java_lang_String(!this.isLenient(), "fe80:0000:0000:*:0204:61ff:254.157.241.086");
        this.ipv6test$int$java_lang_String(1, "::*:192.0.128.*");
        this.ipv6test$int$java_lang_String(0, "XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1111:2222:*:4444:5555:6666:00.00.00.00");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:000.*.000.000");
        this.ipv6test$int$java_lang_String(0, "*:2222:3333:4444:5555:6666:256.256.256.256");
        this.ipv6test$int$java_lang_String(1, "*:2222:3333:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:*:3333:4444:5555::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:*:4444::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::*.*.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::123.123.*.*");
        this.ipv6test$int$java_lang_String(1, "1111:2222::123.123.123.*");
        this.ipv6test$int$java_lang_String(1, "1111::123.*.123.123");
        this.ipv6test$int$java_lang_String(1, "::123.123.123.*");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::*:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:*::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "*:2222::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::6666:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "::6666:123.123.2.123");
        this.ipv6test$int$java_lang_String(1, "1111:*:3333::5555:6666:123.*.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::*:6666:123.123.*.*");
        this.ipv6test$int$java_lang_String(1, "1111::*:6666:*.*.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::*:6666:*.0-255.123.123");
        this.ipv6test$int$java_lang_String(1, "::5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::4444:5555:*:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::4444:5555:6666:123.*.123.123");
        this.ipv6test$int$java_lang_String(1, "*::4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::*:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::2222:*:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::*:*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "*::*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*:::*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*:::*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "*::*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*::*:*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*:*:*:*:*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*:*:*:*:*:*:*::*.*.*.*");
        this.ipv6test$int$java_lang_String(0, "*:*:*:*:*:*::*:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "*:*:*:*:*:*:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "*:*:*:*:*::*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "*:*:*:*::*:*.*.*.*");
        this.ipv6test$int$java_lang_String$boolean(1, "::*", false);
        this.ipv6test$int$java_lang_String$boolean(1, "*:0:0:0:0:0:0:*", false);
        this.ipv6test$int$java_lang_String(1, "0:a:b:*:d:e:f::");
        this.ipv6test$int$java_lang_String(1, "::0:a:*:*:d:e:f");
        this.ipv6test$int$java_lang_String(1, "a:b:c:*:*:f:0::");
        this.ipv6test$int$java_lang_String(0, "\':10.*.0.1");
        this.ipv4test$boolean$java_lang_String(true, "1.*.4");
        this.ipv4test$boolean$java_lang_String(true, "1.2.*");
        this.ipv4test$boolean$java_lang_String(true, "*.1");
        this.ipv4test$boolean$java_lang_String(true, "1.*");
        this.ipv4test$boolean$java_lang_String(true, "1.*.1");
        this.ipv4test$boolean$java_lang_String(true, "1.*.*");
        this.ipv4test$boolean$java_lang_String(true, "*.*.1");
        this.ipv4test$boolean$java_lang_String(true, "*.1.*");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1.1");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1.1.1");
        this.ipv4test$boolean$java_lang_String(true, "*.1.2.*");
        this.ipv4test$boolean$java_lang_String(true, "*.1.*.2");
        this.ipv4test$boolean$java_lang_String(true, "*.*.*.2");
        this.ipv4test$boolean$java_lang_String(true, "*.*.*.*");
        this.ipv4test$boolean$java_lang_String(true, "1.*.2.*");
        this.ipv4test$boolean$java_lang_String(true, "1.2.*.*");
        this.ipv4test$boolean$java_lang_String(true, "*.*");
        this.ipv6test$boolean$java_lang_String(true, "1::1.2.*");
        this.ipv6test$boolean$java_lang_String(true, "1::1.2.**");
        this.ipv6test$boolean$java_lang_String(false, "1::1.2.**z");
        this.ipv6test$boolean$java_lang_String(true, "1::1.2.3.4");
        this.ipv6test$boolean$java_lang_String(true, "1:*:1");
        this.ipv4test$boolean$java_lang_String(true, "1.2.*");
        this.ipv4test$boolean$java_lang_String(false, "%.%");
        this.ipv6test$boolean$java_lang_String(false, "1::1.2.%");
        this.ipv6test$boolean$java_lang_String(true, "1::1.2.*%");
        this.ipv6test$boolean$java_lang_String(true, "1::1.2.*%z");
        this.ipv6test$boolean$java_lang_String(false, "1:%:1");
        this.ipv6test$boolean$java_lang_String(true, "1::%-.1");
        this.ipv6test$boolean$java_lang_String(true, "1::%-.1/16");
        this.ipv6test$boolean$java_lang_String(true, "1::%-1/16");
        this.ipv6test$boolean$java_lang_String(true, "1::-1:16");
        this.ipv6test$boolean$java_lang_String(true, "1::%-.1-16");
        this.ipv6test$boolean$java_lang_String(true, "1::%-.1/16");
        this.ipv6test$boolean$java_lang_String(false, "1::%-.1:16");
        this.ipv6test$boolean$java_lang_String(false, "1::%-.1/1a");
        this.ipv6test$boolean$java_lang_String(false, "1::%-1/1a");
        this.ipv6test$boolean$java_lang_String(true, "1::%%1");
        this.ipv6test$boolean$java_lang_String(true, "1::%%1/16");
        this.ipv6test$boolean$java_lang_String(true, "1::%%ab");
        this.ipv6test$boolean$java_lang_String(true, "1::%%ab/16");
        this.ipv6test$boolean$java_lang_String(true, "1::%$1");
        this.ipv6test$boolean$java_lang_String(true, "1::%$1/16");
        this.ipv4test$boolean$java_lang_String(true, "1.2.%");
        this.ipv6test$int$java_lang_String(1, "1:*");
        this.ipv6test$int$java_lang_String(1, "*:1:*");
        this.ipv6test$int$java_lang_String(1, "*:1");
        this.ipv6test$int$java_lang_String(1, "*:1:1.*.*");
        this.ipv6test$int$java_lang_String(1, "*:1:*.0-255.1.1");
        this.ipv6test$int$java_lang_String(1, "*:1:1.*");
        this.ipv6test$int$java_lang_String(0, "1:1:1.*.1");
        this.ipv6test$int$java_lang_String(0, "1:1:1.*.1.1");
        this.ipv6test$int$java_lang_String(1, "1:1:*.*");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:*.*");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:*.*");
        this.ipv6test$int$java_lang_String(0, "1:1:1.*");
        this.ipv6test$int$java_lang_String(1, "1::1:1.*.*");
        this.ipv6test$int$java_lang_String(1, "1::1:*.*.1.1");
        this.ipv6test$int$java_lang_String(1, "1::1:1.*");
        this.ipv6test$int$java_lang_String(1, "1:*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "1::*.*.*.*");
        this.ipv6test$int$java_lang_String(1, "1:*.*.1.2");
        this.ipv6test$int$java_lang_String(1, "1::*.*.1.2");
        this.ipv6test$int$java_lang_String(1, "1::2:*.*.1.2");
        this.ipv6test$int$java_lang_String(1, "::2:*.*.1.2");
        this.ipv6test$int$java_lang_String(0, "1:1.*.2");
        this.ipv6test$int$java_lang_String(0, "1:1.*.2.2");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "1:*:1.2");
        this.ipv6test$int$java_lang_String(1, "*:1:1.*");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "*:1:1.2.3");
        this.ipv6test$int$java_lang_String(1, "::1:1.*");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "::1:1.2.3");
        this.ipv6test$int$java_lang_String(1, "1:*:1");
        this.ipv6test$int$java_lang_String(1, "1:*:1:1.1.*");
        this.ipv6test$int$java_lang_String(1, "1:*:1:1.1.*.*");
        this.ipv6test$int$java_lang_String(1, "1:*:1:*");
        this.ipv6test$int$java_lang_String(1, "1:*:1:*.*.1.2");
        this.ipv6test$int$java_lang_String(1, "1:*:1:1.*");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "1:*:1:1.2.3");
        this.ipv6test$int$java_lang_String(0, "1:*:1:2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(0, "1:*:1:2:3:4:5:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:*:2:3:4:5:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1:*:2:3:4:5:1.2.3.4.5");
        this.ipv6test$int$java_lang_String(0, "1:1:2:3:4:5:1.2.3.4.5");
        this.ipv6test$int$java_lang_String(0, "1:1:2:3:4:5:6:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1:1:2:3:4:5:6:1.*.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:1.*.3.4");
        this.ipv4test$boolean$java_lang_String(true, "255._.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255._.4");
        this.ipv4test$boolean$java_lang_String(true, "_.2.255.4");
        this.ipv4test$boolean$java_lang_String(true, "1._.3.255");
        this.ipv4test$boolean$java_lang_String(true, "255.__.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255.__.4");
        this.ipv4test$boolean$java_lang_String(true, "__.2.255.4");
        this.ipv4test$boolean$java_lang_String(true, "1.__.3.255");
        this.ipv4test$boolean$java_lang_String(true, "255.___.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255.___.4");
        this.ipv4test$boolean$java_lang_String(true, "___.2.255.4");
        this.ipv4test$boolean$java_lang_String(true, "1.___.3.255");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "255.____.3.4");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1.255.____.4");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "____.2.255.4");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1.____.3.255");
        this.ipv4test$boolean$java_lang_String(false, "255._2_.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.255._2_.4");
        this.ipv4test$boolean$java_lang_String(false, "_2_.2.255.4");
        this.ipv4test$boolean$java_lang_String(false, "1._2_.3.255");
        this.ipv4test$boolean$java_lang_String(true, "255.2__.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255.2__.4");
        this.ipv4test$boolean$java_lang_String(true, "2__.2.255.4");
        this.ipv4test$boolean$java_lang_String(true, "1.2__.3.255");
        this.ipv4test$boolean$java_lang_String(true, "255.2_.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255.2_.4");
        this.ipv4test$boolean$java_lang_String(true, "2_.2.255.4");
        this.ipv4test$boolean$java_lang_String(true, "1.2_.3.255");
        this.ipv4test$boolean$java_lang_String(false, "255.__2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.255.__2.4");
        this.ipv4test$boolean$java_lang_String(false, "__2.2.255.4");
        this.ipv4test$boolean$java_lang_String(false, "1.__2.3.255");
        this.ipv4test$boolean$java_lang_String(true, "25_.__.3.4");
        this.ipv4test$boolean$java_lang_String(true, "1.255.2__._");
        this.ipv4test$boolean$java_lang_String(true, "2_.2_.255.__");
        this.ipv4test$boolean$java_lang_String(false, "1.2__.3__.25_");
        this.ipv4test$boolean$java_lang_String(true, "1.2__.3_.25_");
        this.ipv4test$boolean$java_lang_String(true, "1.2__.2__.25_");
        this.ipv4test$boolean$java_lang_String(false, "1.1--2.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.1-2-3.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.1-2-.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.-1-2.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.1_2_.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.1_2.1.1");
        this.ipv4test$boolean$java_lang_String(true, "1.1_.1.1");
        this.ipv6test$boolean$java_lang_String(false, "1:1--2:1:1::");
        this.ipv6test$boolean$java_lang_String(false, "1:1-2-3:1:1::");
        this.ipv6test$boolean$java_lang_String(false, "1:1-2-:1:1::");
        this.ipv6test$boolean$java_lang_String(false, "1:-1-2:1:1::");
        this.ipv6test$boolean$java_lang_String(false, "1:1_2_:1.1::");
        this.ipv6test$boolean$java_lang_String(false, "1:1_2:1:1::");
        this.ipv6test$boolean$java_lang_String(true, "1:1_:1:1::");
        this.ipv6test$int$java_lang_String(1, "::ffff:_:0");
        this.ipv6test$int$java_lang_String(1, "_::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:_:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:_:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::_");
        this.ipv6test$int$java_lang_String(1, "1:2:3:_::8");
        this.ipv6test$int$java_lang_String(1, "_:2::8");
        this.ipv6test$int$java_lang_String(1, "1::_");
        this.ipv6test$int$java_lang_String(1, "_::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "_::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:_");
        this.ipv6test$int$java_lang_String(1, "1::2:_:4");
        this.ipv6test$int$java_lang_String(1, "1::_:3");
        this.ipv6test$int$java_lang_String(1, "1::_");
        this.ipv6test$int$java_lang_String(1, "::ffff:__:0");
        this.ipv6test$int$java_lang_String(1, "__::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:__:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:__:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::__");
        this.ipv6test$int$java_lang_String(1, "1:2:3:__::8");
        this.ipv6test$int$java_lang_String(1, "__:2::8");
        this.ipv6test$int$java_lang_String(1, "1::__");
        this.ipv6test$int$java_lang_String(1, "__::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "__::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:__");
        this.ipv6test$int$java_lang_String(1, "1::2:__:4");
        this.ipv6test$int$java_lang_String(1, "1::__:3");
        this.ipv6test$int$java_lang_String(1, "1::__");
        this.ipv6test$int$java_lang_String(1, "::ffff:___:0");
        this.ipv6test$int$java_lang_String(1, "___::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:___:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:___:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::___");
        this.ipv6test$int$java_lang_String(1, "1:2:3:___::8");
        this.ipv6test$int$java_lang_String(1, "___:2::8");
        this.ipv6test$int$java_lang_String(1, "1::___");
        this.ipv6test$int$java_lang_String(1, "___::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "___::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:___");
        this.ipv6test$int$java_lang_String(1, "1::2:___:4");
        this.ipv6test$int$java_lang_String(1, "1::___:3");
        this.ipv6test$int$java_lang_String(1, "1::___");
        this.ipv6test$int$java_lang_String(1, "::ffff:____:0");
        this.ipv6test$int$java_lang_String(1, "____::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:____:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:____:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::____");
        this.ipv6test$int$java_lang_String(1, "1:2:3:____::8");
        this.ipv6test$int$java_lang_String(1, "____:2::8");
        this.ipv6test$int$java_lang_String(1, "1::____");
        this.ipv6test$int$java_lang_String(1, "____::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "____::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:____");
        this.ipv6test$int$java_lang_String(1, "1::2:____:4");
        this.ipv6test$int$java_lang_String(1, "1::____:3");
        this.ipv6test$int$java_lang_String(1, "1::____");
        this.ipv6test$int$java_lang_String(0, "::ffff:_____:0");
        this.ipv6test$int$java_lang_String(0, "_____::1");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:_____:6:7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:_____:4:5:6::8");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5::_____");
        this.ipv6test$int$java_lang_String(0, "1:2:3:_____::8");
        this.ipv6test$int$java_lang_String(0, "_____:2::8");
        this.ipv6test$int$java_lang_String(0, "1::_____");
        this.ipv6test$int$java_lang_String(0, "_____::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(0, "_____::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(0, "1::2:3:4:_____");
        this.ipv6test$int$java_lang_String(0, "1::2:_____:4");
        this.ipv6test$int$java_lang_String(0, "1::_____:3");
        this.ipv6test$int$java_lang_String(0, "1::_____");
        this.ipv6test$int$java_lang_String(0, "::ffff:ff___:0");
        this.ipv6test$int$java_lang_String(0, "f____::1");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:ffff_:6:7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:ffff_:4:5:6::8");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5::f_f__");
        this.ipv6test$int$java_lang_String(0, "1:2:3:fff__::8");
        this.ipv6test$int$java_lang_String(0, "f___f:2::8");
        this.ipv6test$int$java_lang_String(0, "1::ff_ff");
        this.ipv6test$int$java_lang_String(0, "ff_ff::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(0, "f____::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(0, "1::2:3:4:F____");
        this.ipv6test$int$java_lang_String(0, "1::2:FF___:4");
        this.ipv6test$int$java_lang_String(0, "1::FFF__:3");
        this.ipv6test$int$java_lang_String(0, "1::FFFF_");
        this.ipv6test$int$java_lang_String(0, "::ffff:_2_:0");
        this.ipv6test$int$java_lang_String(0, "_2_::1");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:_2_:6:7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:_2_:4:5:6::8");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5::_2_");
        this.ipv6test$int$java_lang_String(0, "1:2:3:_2_::8");
        this.ipv6test$int$java_lang_String(0, "_2_:2::8");
        this.ipv6test$int$java_lang_String(0, "1::_2_");
        this.ipv6test$int$java_lang_String(0, "_2_::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(0, "_2_::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(0, "1::2:3:4:_2_");
        this.ipv6test$int$java_lang_String(0, "1::2:_2_:4");
        this.ipv6test$int$java_lang_String(0, "1::_2_:3");
        this.ipv6test$int$java_lang_String(0, "1::_2_");
        this.ipv6test$int$java_lang_String(0, "::ffff:_2:0");
        this.ipv6test$int$java_lang_String(0, "_2::1");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:_2:6:7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:_2:4:5:6::8");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5::_2");
        this.ipv6test$int$java_lang_String(0, "1:2:3:_2::8");
        this.ipv6test$int$java_lang_String(0, "_2:2::8");
        this.ipv6test$int$java_lang_String(0, "1::_2");
        this.ipv6test$int$java_lang_String(0, "_2::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(0, "_2::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(0, "1::2:3:4:_2");
        this.ipv6test$int$java_lang_String(0, "1::2:_2:4");
        this.ipv6test$int$java_lang_String(0, "1::_2:3");
        this.ipv6test$int$java_lang_String(0, "1::_2");
        this.ipv6test$int$java_lang_String(1, "::ffff:2_:0");
        this.ipv6test$int$java_lang_String(1, "2_::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:2_:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:2_:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::2_");
        this.ipv6test$int$java_lang_String(1, "1:2:3:2_::8");
        this.ipv6test$int$java_lang_String(1, "2_:2::8");
        this.ipv6test$int$java_lang_String(1, "1::2_");
        this.ipv6test$int$java_lang_String(1, "2_::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "2_::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:2_");
        this.ipv6test$int$java_lang_String(1, "1::2:2_:4");
        this.ipv6test$int$java_lang_String(1, "1::2_:3");
        this.ipv6test$int$java_lang_String(1, "1::2_");
        this.ipv6test$int$java_lang_String(1, "::ffff:2___:0");
        this.ipv6test$int$java_lang_String(1, "2___::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:2___:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:2___:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::2___");
        this.ipv6test$int$java_lang_String(1, "1:2:3:2___::8");
        this.ipv6test$int$java_lang_String(1, "2___:2::8");
        this.ipv6test$int$java_lang_String(1, "1::2___");
        this.ipv6test$int$java_lang_String(1, "2___::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "2___::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:2___");
        this.ipv6test$int$java_lang_String(1, "1::2:2___:4");
        this.ipv6test$int$java_lang_String(1, "1::2___:3");
        this.ipv6test$int$java_lang_String(1, "1::2___");
        this.ipv6test$int$java_lang_String(1, "::fff_:2___:0");
        this.ipv6test$int$java_lang_String(1, "2___::_");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:2___:6_:7_:8");
        this.ipv6test$int$java_lang_String(1, "1:2:2___:4:5:6::8__");
        this.ipv6test$int$java_lang_String(1, "1:2:3_:4:5::2___");
        this.ipv6test$int$java_lang_String(1, "1:2:3:2___::8");
        this.ipv6test$int$java_lang_String(1, "2___:2::8");
        this.ipv6test$int$java_lang_String(1, "1::2___");
        this.ipv6test$int$java_lang_String(1, "2___::2_:3__:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "2___::2:3_:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4_:2___");
        this.ipv6test$int$java_lang_String(1, "1::2:2___:4f__");
        this.ipv6test$int$java_lang_String(1, "1___::2___:3___");
        this.ipv6test$int$java_lang_String(1, "1_::2___");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "*:1:1._.__");
        this.ipv6test$int$java_lang_String(1, "*:1:1._.__.___");
        this.ipv6test$int$java_lang_String(1, "*:_:1:1._.1._");
        this.ipv6test$int$java_lang_String(1, "*:_:1:_.___.1._");
        this.ipv6test$int$java_lang_String(1, "*:_:1:_.___._.___");
        this.ipv6test$int$java_lang_String(1, "1:*:1_:1:1.1_.1.1");
        this.ipv6test$int$java_lang_String(0, "1:1:1.2_.1");
        this.ipv6test$int$java_lang_String(0, "1:1:1.2__.1.1");
        this.ipv6test$int$java_lang_String(0, "1:1:_.*");
        this.ipv6test$int$java_lang_String(0, "1:1:1._");
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8/0", [0, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/0", [0, 16, 32, 48, 64, 80, 96, 112, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8", [null, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/64", [64, 64, 64, 64, 64, 64, 64, 64, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/64", [64, 64, 64, 64, 64, 80, 96, 112, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb/63", "1:2:3:4:5:6:7:8", [null, null, null, null, 63, 63, 63, 63, 63]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8", [null, null, null, null, 64, 64, 64, 64, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb/65", "1:2:3:4:5:6:7:8", [null, null, null, null, null, 65, 65, 65, 65]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8/128", [128, 128, 128, 128, 128, 128, 128, 128, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/128", [128, 128, 128, 128, 128, 128, 128, 128, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8", [null, null, null, null, null, null, null, null, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/32", "1:2:3:4:5:6:7:8/64", [64, 64, 32, 32, 32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/32", [32, 32, 32, 48, 64, 64, 64, 64, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8/64", [64, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/0", [0, 16, 32, 48, 64, 64, 64, 64, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/128", [128, 128, 128, 128, 64, 64, 64, 64, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8/64", [64, 64, 64, 64, 64, 80, 96, 112, 128]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/0", "5.6.7.8/0", [0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4", "5.6.7.8/0", [0, 8, 16, 24, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("1.2.3.4/0", "5.6.7.8", [null, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/16", "5.6.7.8/16", [16, 16, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4", "5.6.7.8/16", [16, 16, 16, 24, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("1.2.3.4/16", "5.6.7.8", [null, null, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/32", "5.6.7.8/32", [32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4", "5.6.7.8/32", [32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("1.2.3.4/31", "5.6.7.8", [null, null, null, null, 31]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("1.2.3.4/32", "5.6.7.8", [null, null, null, null, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/16", "5.6.7.8/24", [24, 24, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/24", "5.6.7.8/7", [7, 8, 16, 24, 24]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/24", "5.6.7.8/16", [16, 16, 16, 24, 24]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/0", "5.6.7.8/16", [16, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/16", "5.6.7.8/0", [0, 8, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/17", "5.6.7.8/0", [0, 8, 16, 17, 17]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/16", "5.6.7.8/32", [32, 32, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("1.2.3.4/32", "5.6.7.8/16", [16, 16, 16, 24, 32]);
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8/0");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/0");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/64");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/64");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/63", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/65", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8/128");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8/128");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/32", "1:2:3:4:5:6:7:8/64");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/32");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/0", "1:2:3:4:5:6:7:8/64");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/0");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/64", "1:2:3:4:5:6:7:8/128");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb/128", "1:2:3:4:5:6:7:8/64");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/0", "5.6.7.8/0");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4", "5.6.7.8/0");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/0", "5.6.7.8");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/16", "5.6.7.8/16");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4", "5.6.7.8/16");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/16", "5.6.7.8");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/32", "5.6.7.8/32");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4", "5.6.7.8/32");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/31", "5.6.7.8");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/32", "5.6.7.8");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/16", "5.6.7.8/24");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/24", "5.6.7.8/7");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/24", "5.6.7.8/16");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/0", "5.6.7.8/16");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/16", "5.6.7.8/0");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/17", "5.6.7.8/0");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/16", "5.6.7.8/32");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4/32", "5.6.7.8/16");
        this.testSub("1:1::/32", "1:1:1:1:1:1:1:1", isNoAutoSubnets?["1:1::/32"]:["1:1:0:0:0:0:0:0/48", "1:1:2-fffe:0:0:0:0:0/47", "1:1:1:0:0:0:0:0/64", "1:1:1:2-fffe:0:0:0:0/63", "1:1:1:1:0:0:0:0/80", "1:1:1:1:2-fffe:0:0:0/79", "1:1:1:1:1:0:0:0/96", "1:1:1:1:1:2-fffe:0:0/95", "1:1:1:1:1:1:0:0/112", "1:1:1:1:1:1:2-fffe:0/111", "1:1:1:1:1:1:1:0", "1:1:1:1:1:1:1:2-fffe/127"]);
        this.testSub("1:1::/32", "1:1::/16", allPrefixesAreSubnets || isNoAutoSubnets?null:["1:1:1-ffff:0:0:0:0:0/48", "1:1:0:1-ffff:0:0:0:0/64", "1:1:0:0:1-ffff:0:0:0/80", "1:1:0:0:0:1-ffff:0:0/96", "1:1:0:0:0:0:1-ffff:0/112", "1:1:0:0:0:0:0:1-ffff"]);
        this.testSub("1:1::/32", "1:1::/48", isNoAutoSubnets?null:["1:1:1-ffff:0:0:0:0:0/48"]);
        this.testSub("1:1::/32", "1:1::/64", isNoAutoSubnets?null:["1:1:1-ffff:0:0:0:0:0/48", "1:1:0:1-ffff:0:0:0:0/64"]);
        this.testSub("1:1::/32", "1:1:2:2::/64", isNoAutoSubnets?["1:1::/32"]:["1:1:0:0:0:0:0:0/47", "1:1:3-ffff:0:0:0:0:0/48", "1:1:2:0:0:0:0:0/63", "1:1:2:3-ffff:0:0:0:0/64"]);
        this.testSub("10.0.0.0/22", "10.0.0.0/24", isNoAutoSubnets?null:["10.0.1-3.0/24"]);
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1:1-3:1:1:1:1:1", "1:1:2-4:1:1:1:1:1", "1:1:2-3:1:1:1:1:1");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1:1-3:1:0:1:1:1", "1:1:2-4:1:1:1:1:1", null);
        this.testToPrefixBlock("1.3.*.*", "1.3.*.*");
        this.testToPrefixBlock("1.2-3.*.*", "1.2-3.*.*");
        this.testToPrefixBlock("1.3.3.4/15", "1.2-3.*.*/15");
        this.testToPrefixBlock("*.3.3.4/15", "*.2-3.*.*/15");
        this.testToPrefixBlock("1.3.3.4/16", "1.3.*.*/16");
        this.testToPrefixBlock("1:3:3:4::/15", "0-1:*/15");
        this.testToPrefixBlock("*:3:3:4::/15", isNoAutoSubnets?"*:*/15":"0-fffe::/15");
        this.testToPrefixBlock("1:3:3:4::/16", "1:*/16");
        this.testMaxHost("1.*.255.255/16", allPrefixesAreSubnets?"1.*.255.255":"1.*.255.255/16");
        this.testMaxHost("1.2.*.*/16", allPrefixesAreSubnets?"1.2.255.255":"1.2.255.255/16");
        this.testMaxHost("1.*.*.*/16", allPrefixesAreSubnets?"1.*.255.255":"1.*.255.255/16");
        this.testMaxHost("1.2.*.1/16", allPrefixesAreSubnets?"1.2.255.255":"1.2.255.255/16");
        this.testMaxHost("1.*.*.1/16", allPrefixesAreSubnets?"1.*.255.255":"1.*.255.255/16");
        this.testZeroHost("1.*.0.0/16", allPrefixesAreSubnets?"1.*.0.0":"1.*.0.0/16");
        this.testZeroHost("1.2.*.*/16", allPrefixesAreSubnets?"1.2.0.0":"1.2.0.0/16");
        this.testZeroHost("1.*.*.*/16", allPrefixesAreSubnets?"1.*.0.0":"1.*.0.0/16");
        this.testZeroHost("1.2.*.1/16", allPrefixesAreSubnets?"1.2.0.0":"1.2.0.0/16");
        this.testZeroHost("1.*.*.1/16", allPrefixesAreSubnets?"1.*.0.0":"1.*.0.0/16");
        this.testMaxHost("1:*::ffff:ffff:ffff:ffff/64", allPrefixesAreSubnets?"1:*::ffff:ffff:ffff:ffff":"1:*::ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:2::ffff:ffff:ffff:ffff/64", allPrefixesAreSubnets?"1:2::ffff:ffff:ffff:ffff":"1:2::ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:*::*:*:*:*/64", allPrefixesAreSubnets?"1:*::ffff:ffff:ffff:ffff":"1:*::ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:2::*:*:*:*/64", allPrefixesAreSubnets?"1:2::ffff:ffff:ffff:ffff":"1:2::ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:2::*:*:*:1/64", allPrefixesAreSubnets?"1:2::ffff:ffff:ffff:ffff":"1:2::ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:*:1/64", allPrefixesAreSubnets?"1:*:ffff:ffff:ffff:ffff":"1:*:ffff:ffff:ffff:ffff/64");
        this.testMaxHost("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/0", allPrefixesAreSubnets?"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/0");
        this.testMaxHost("*:*/0", allPrefixesAreSubnets?"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/0");
        this.testMaxHost("::/128", allPrefixesAreSubnets?"::":"::/128");
        this.testZeroHost("1:*::/64", allPrefixesAreSubnets?"1:*::":"1:*::/64");
        this.testZeroHost("1:2::/64", allPrefixesAreSubnets?"1:2::":"1:2::/64");
        this.testZeroHost("1:*::*:*:*:*/64", allPrefixesAreSubnets?"1:*::":"1:*::/64");
        this.testZeroHost("1:2::*:*:*:*/64", allPrefixesAreSubnets?"1:2::":"1:2::/64");
        this.testZeroHost("1:2::*:*:*:1/64", allPrefixesAreSubnets?"1:2::":"1:2::/64");
        this.testZeroHost("1:*:1/64", allPrefixesAreSubnets?"1:*:*:*::":"1:*:*:*::/64");
        this.testZeroHost("::/0", allPrefixesAreSubnets?"::":"::/0");
        this.testZeroHost("*:*/0", allPrefixesAreSubnets?"::":"::/0");
        this.testZeroHost("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128", allPrefixesAreSubnets?"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128");
        this.testZeroHost("1:2:3:4::/64", allPrefixesAreSubnets?"1:2:3:4::":"1:2:3:4::/64");
        this.testZeroHost("1:2:3:4:*/64", allPrefixesAreSubnets?"1:2:3:4::":"1:2:3:4::/64");
        this.testZeroHost("1:2:*/64", allPrefixesAreSubnets?"1:2:*:*::":"1:2:*:*::/64");
        this.testZeroHost("1:2:3:4:*:1/64", allPrefixesAreSubnets?"1:2:3:4::":"1:2:3:4::/64");
        this.testZeroHost("1:*:1/64", allPrefixesAreSubnets?"1:*:*:*::":"1:*:*:*::/64");
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.*.*", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.*", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.*.*.*", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2-3.*.*", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.128-255.*", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("*.*/0", true, true);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.*.*/16", true, true);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.*/16", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.*.*.*/16", true, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2-3.*.*/16", true, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.128-255.*/16", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.*.*", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.*", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.*.*.*", 8, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2-3.*.*", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.128-255.*", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("*.*/0", 8, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.*.*/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.*/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.*.*.*/16", 8, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2-3.*.*/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.128-255.*/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.*.*", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.*", 24, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.*.*.*", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2-3.*.*", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.128-255.*", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("*.*/0", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.*.*/16", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.*/16", 24, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.*.*.*/16", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2-3.*.*/16", 24, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.128-255.*/16", 24, true, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:*/64", true, true);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:*/64", true, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d-e:*/64", true, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:*/64", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:0-7fff:*/64", isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:8000-ffff:*/64", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:*/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:*/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d-e:*/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("*:*/64", 0, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:*/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-7fff:*/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:*/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:*/64", 63, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d-e:*/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:e-f:*/64", 63, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:*/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-7fff:*/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:*/64", 64, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:*/64", 64, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d-e:*/64", 64, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:*/64", 64, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-7fff:*/64", 64, isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:8000-ffff:*/64", 64, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:*/64", 65, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:*/64", 65, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d-e:*/64", 65, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:*/64", 65, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-7fff:*/64", 65, true, !isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:8000-ffff:*/64", 65, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-ffff:*/64", 65, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:*/64", 128, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:*/64", 128, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d-e:*/64", 128, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:*/64", 128, true, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:0-7fff:*/64", 128, true, false);
        this.testSplitBytes$java_lang_String("1.2.*.4");
        this.testSplitBytes$java_lang_String("1.2-4.3.4/16");
        this.testSplitBytes$java_lang_String("1.2.3.4-5/0");
        this.testSplitBytes$java_lang_String("1.2.*/32");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc-dddd:bbbb");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc:bbbb/64");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:*:dddd:cccc:bbbb/0");
        this.testSplitBytes$java_lang_String("*:*/128");
        this.testSplitBytes$java_lang_String("*:*");
        if(isNoAutoSubnets) {
            this.testMerge("192.168.0.0-15/28", "192.168.0.0-7/29", "192.168.0.8-15/29");
            this.testMerge("1:2:3:4:*/64", "1:2:3:4:8000-ffff:*/65", "1:2:3:4:0-3fff:*/66", "1:2:3:4:4000-7fff:*/66");
            this.testMerge("1:2:3:4:*/64", "1:2:3:4:0-3fff:*/66", "1:2:3:4:8000-ffff:*/65", "1:2:3:4:4000-7fff:*/66");
            this.testMerge("1:2:3:4:*/64", "1:2:3:4:0-3fff:*/66", "1:2:3:4:4000-7fff:*/66", "1:2:3:4:8000-ffff:*/65");
            this.testMerge("1:2:3:4:*/64", "1:2:3:4:4000-7fff:*/66", "1:2:3:4:0-3fff:*/66", "1:2:3:4:8000-ffff:*/65");
            this.testMerge("1:2:3:4-5:*/63", "1:2:3:4:0-3fff:*/66", "1:2:3:4:8000-ffff:*/65", "1:2:3:4:4000-7fff:*/66", "1:2:3:5:0-3fff:*/66", "1:2:3:5:4000-7fff:*/66", "1:2:3:5:8000-ffff:*/65");
            this.testMerge("1:2:3:4-5:*/63", "1:2:3:4-5:0-3fff:*/66", "1:2:3:4-5:8000-ffff:*/65", "1:2:3:4-5:4000-7fff:*/66");
            this.testMerge2("1:2:3:4:*/64", "1:2:3:6:*/64", "1:2:3:4:0-3fff:*/66", "1:2:3:4:8000-ffff:*/65", "1:2:3:6:0-3fff:*/66", "1:2:3:6:4000-7fff:*/66", "1:2:3:6:8000-ffff:*/65", "1:2:3:4:4000-7fff:*/66");
        } else {
            this.testMerge("192.168.0.0/28", "192.168.0.0/29", "192.168.0.8/29");
            this.testMerge("1:2:3:4::/64", "1:2:3:4:8000::/65", "1:2:3:4::/66", "1:2:3:4:4000::/66");
            this.testMerge("1:2:3:4::/64", "1:2:3:4::/66", "1:2:3:4:8000::/65", "1:2:3:4:4000::/66");
            this.testMerge("1:2:3:4::/64", "1:2:3:4::/66", "1:2:3:4:4000::/66", "1:2:3:4:8000::/65");
            this.testMerge("1:2:3:4::/64", "1:2:3:4:4000::/66", "1:2:3:4::/66", "1:2:3:4:8000::/65");
            this.testMerge("1:2:3:4::/63", "1:2:3:4:8000::/65", "1:2:3:4::/66", "1:2:3:4:4000::/66", "1:2:3:5:4000::/66", "1:2:3:5::/66", "1:2:3:5:8000::/65");
            this.testMerge("1:2:3:4::/63", "1:2:3:4-5::/66", "1:2:3:4-5:8000::/65", "1:2:3:4-5:4000::/66");
            this.testMerge2("1:2:3:4::/64", "1:2:3:6::/64", "1:2:3:4:8000::/65", "1:2:3:4::/66", "1:2:3:4:4000::/66", "1:2:3:6:4000::/66", "1:2:3:6::/66", "1:2:3:6:8000::/65");
        }
        this.testMerge(isNoAutoSubnets?"192.168.0.0-15/28":"192.168.0.0/28", "192.168.0.0", "192.168.0.1", "192.168.0.2", "192.168.0.3", "192.168.0.4", "192.168.0.5", "192.168.0.6", "192.168.0.7", "192.168.0.8", "192.168.0.9", "192.168.0.10", "192.168.0.11", "192.168.0.12", "192.168.0.13", "192.168.0.14", "192.168.0.15");
        this.testMerge(isNoAutoSubnets?"192.168.0.0-15/28":"192.168.0.0/28", "192.168.0.0/29", "192.168.0.1/29", "192.168.0.2/29", "192.168.0.3/29", "192.168.0.4/29", "192.168.0.5/29", "192.168.0.6/29", "192.168.0.7/29", "192.168.0.8/29", "192.168.0.9/29", "192.168.0.10/29", "192.168.0.11/29", "192.168.0.12/29", "192.168.0.13/29", "192.168.0.14/29", "192.168.0.15/29");
        if(isNoAutoSubnets) {
            this.testMerge("1.2.2-3.*/23", "1.2.3.*/24", "1.2.2.*/24");
            this.testMerge("1.2.3.*/24", "1.2.3.128-255/25", "1.2.3.0-127/25");
            this.testMerge("1.2.2-3.*/23", "1.2.3.*/24", "1.2.2-3.*/23");
            this.testMerge("1.2.2-3.*/23", "1.2.2-3.*/23", "1.2.3.*/24");
        } else {
            this.testMerge("1.2.2.0/23", "1.2.3.0/24", "1.2.2.0/24");
            this.testMerge("1.2.3.0/24", "1.2.3.128/25", "1.2.3.0/25");
            this.testMerge("1.2.2.0/23", "1.2.3.0/24", "1.2.2.0/23");
            this.testMerge("1.2.2.0/23", "1.2.2.0/23", "1.2.3.0/24");
            this.testMerge("1.2.0.0/16", "1.2.0.0/16", "1.2.3.0/24");
            this.testMerge("1.2.3.0/24", "1.2.3.0/24", "1.2.3.0/24");
            this.testMerge2("1.2.3.0/24", "1.1.2.0/24", "1.2.3.0/24", "1.1.2.0/24");
            this.testMerge2("1.2.3.0/24", "1.2.6.0/24", "1.2.3.0/24", "1.2.6.0/24");
            this.testMerge2("1.2.3.0/24", "1.2.7.0/24", "1.2.3.0/24", "1.2.7.0/24");
            this.testMerge2("1.2.3.128/25", "1.2.2.0/25", "1.2.3.128/25", "1.2.2.0/25");
        }
        this.testMerge("1.2.2-3.*/23", "1.2.3.*", "1.2.2.*");
        this.testMerge("1.2.3.*/24", "1.2.3.128-255", "1.2.3.0-127");
        this.testMerge("1.2.2-3.*/23", "1.2.2-3.*", "1.2.3.*/24");
        this.testMerge("1.2.*.*/16", "1.2.*.*/16", "1.2.3.*/24");
        this.testMerge("1.2.3.*/24", "1.2.3.*/24", "1.2.3.*/24");
        this.testMerge("1.2.3.*/24", "1.2.3.*", "1.2.3.*");
        this.testMerge2("1.2.3.*/24", "1.1.2.*/24", "1.2.3.*/24", "1.1.2.*/24");
        this.testMerge2("1.2.3.*/24", "1.2.6.*/24", "1.2.3.*/24", "1.2.6.*/24");
        this.testMerge2("1.2.3.*/24", "1.2.7.*/24", "1.2.3.*/24", "1.2.7.*/24");
        this.testMerge2("1.2.3.128-255/25", "1.2.2.0-127/25", "1.2.3.128-255/25", "1.2.2.0-127/25");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", 0, "1.2.0.0");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", 1, "1.2.0.1");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", 65535, "1.2.255.255");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", 65536, "1.3.0.0");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", -1, "1.1.255.255");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", -65536, "1.1.0.0");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.*.*/16", -65537, "1.0.255.255");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", 0, "ffff:ffff:ffff:ffff:ffff:1:2:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", 1, "ffff:ffff:ffff:ffff:ffff:1:3:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", 3, "ffff:ffff:ffff:ffff:ffff:2:3:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", 4, "ffff:ffff:ffff:ffff:ffff:2:4::");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", 5, "ffff:ffff:ffff:ffff:ffff:2:4:1");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:fffe-ffff:fffe-ffff:ffff", 5, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", -4295163903, "ffff:ffff:ffff:ffff:ffff::");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", -4295163904, "ffff:ffff:ffff:ffff:fffe:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", -4295163907, "ffff:ffff:ffff:ffff:fffe:ffff:ffff:fffc");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:ffff:1-2:2-3:ffff", -4295163908, "ffff:ffff:ffff:ffff:fffe:ffff:ffff:fffb");
        this.testIncrement$java_lang_String$long$java_lang_String("::1-2:2-3:ffff", -4295163904, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:3-4:ffff:ffff:ffff:1-2:2-3::", 7, "ffff:4:ffff:ffff:ffff:2:3::");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:3-4:ffff:ffff:ffff:1-2:2-3::", 9, "ffff:4:ffff:ffff:ffff:2:3:2");
        super.runTest();
    }
}
IPAddressRangeTest["__class"] = "inet.ipaddr.test.IPAddressRangeTest";




IPAddressRangeTest.optionsCache_$LI$();

IPAddressRangeTest.INET_ATON_WILDCARD_OPTS_$LI$();

IPAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS_$LI$();

IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$();

IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$();
