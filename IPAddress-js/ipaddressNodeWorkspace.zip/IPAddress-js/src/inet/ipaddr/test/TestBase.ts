/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressSection } from '../AddressSection';
import { AddressSegment } from '../AddressSegment';
import { AddressSegmentSeries } from '../AddressSegmentSeries';
import { AddressValueException } from '../AddressValueException';
import { HostIdentifierString } from '../HostIdentifierString';
import { HostName } from '../HostName';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { MACAddressString } from '../MACAddressString';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressSection } from '../ipv4/IPv4AddressSection';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressSection } from '../mac/MACAddressSection';
import { AddressNetwork } from '../AddressNetwork';
import { AddressStringParameters } from '../AddressStringParameters';
import { MACAddressTest } from './MACAddressTest';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { MACAddressNetwork } from '../mac/MACAddressNetwork';
import { IPv4AddressNetwork } from '../ipv4/IPv4AddressNetwork';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';

export abstract class TestBase {
    public static prefixConfiguration : AddressNetwork.PrefixConfiguration = null;

    static showMessage(s : string) {
        console.info(s);
    }

    static HOST_OPTIONS : HostNameParameters; public static HOST_OPTIONS_$LI$() : HostNameParameters { if(TestBase.HOST_OPTIONS == null) TestBase.HOST_OPTIONS = new HostNameParameters.Builder().allowEmpty(false).setEmptyAsLoopback(false).setNormalizeToLowercase(true).allowPort(true).allowService(true).allowBracketedIPv6(true).allowBracketedIPv4(true).getAddressOptionsBuilder().allowPrefix(true).allowMask(true).setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$()).allow_inet_aton(false).allowEmpty(false).setEmptyAsLoopback(false).allowAll(false).allowPrefixOnly(true).allowSingleSegment(false).getIPv4AddressParametersBuilder().allowLeadingZeros(true).allowUnlimitedLeadingZeros(false).allowPrefixLengthLeadingZeros(true).allowPrefixesBeyondAddressSize(false).allowWildcardedSeparator(true).getParentBuilder().getIPv6AddressParametersBuilder().allowLeadingZeros(true).allowUnlimitedLeadingZeros(false).allowPrefixLengthLeadingZeros(true).allowPrefixesBeyondAddressSize(false).allowWildcardedSeparator(true).allowMixed(true).allowZone(true).getParentBuilder().getParentBuilder().toParams(); return TestBase.HOST_OPTIONS; };

    static ADDRESS_OPTIONS : IPAddressStringParameters; public static ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(TestBase.ADDRESS_OPTIONS == null) TestBase.ADDRESS_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toAddressOptionsBuilder().toParams(); return TestBase.ADDRESS_OPTIONS; };

    static MAC_ADDRESS_OPTIONS : MACAddressStringParameters; public static MAC_ADDRESS_OPTIONS_$LI$() : MACAddressStringParameters { if(TestBase.MAC_ADDRESS_OPTIONS == null) TestBase.MAC_ADDRESS_OPTIONS = new MACAddressStringParameters.Builder().allowEmpty(false).allowAll(false).getFormatBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$()).allowLeadingZeros(true).allowUnlimitedLeadingZeros(false).allowWildcardedSeparator(true).allowShortSegments(true).getParentBuilder().toParams(); return TestBase.MAC_ADDRESS_OPTIONS; };

    static HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS : HostNameParameters; public static HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$() : HostNameParameters { if(TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS == null) TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS = new HostNameParameters.Builder().allowEmpty(false).setEmptyAsLoopback(false).setNormalizeToLowercase(true).allowBracketedIPv6(true).allowBracketedIPv4(true).getAddressOptionsBuilder().allowPrefix(true).allowMask(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).allow_inet_aton(true).allowEmpty(false).setEmptyAsLoopback(false).allowAll(true).allowPrefixOnly(false).getIPv4AddressParametersBuilder().allowPrefixLengthLeadingZeros(true).allowPrefixesBeyondAddressSize(false).allowWildcardedSeparator(true).getParentBuilder().getParentBuilder().toParams(); return TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS; };

    static INET_ATON_WILDCARD_AND_RANGE_OPTIONS : IPAddressStringParameters; public static INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$() : IPAddressStringParameters { if(TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS == null) TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS = TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$().toAddressOptionsBuilder().toParams(); return TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS; };

    static HOST_INET_ATON_OPTIONS : HostNameParameters; public static HOST_INET_ATON_OPTIONS_$LI$() : HostNameParameters { if(TestBase.HOST_INET_ATON_OPTIONS == null) TestBase.HOST_INET_ATON_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().allow_inet_aton(true).allowSingleSegment(true).getParentBuilder().toParams(); return TestBase.HOST_INET_ATON_OPTIONS; };

    fullTest : boolean = false;

    failures : TestBase.Failures = new TestBase.Failures();

    perf : TestBase.Perf = new TestBase.Perf();

    /*private*/ addressCreator : AddressCreator;

    constructor(creator : AddressCreator) {
        if(this.addressCreator===undefined) this.addressCreator = null;
        this.addressCreator = creator;
    }

    createHost$inet_ipaddr_test_TestBase_HostKey(key : TestBase.HostKey) : HostName {
        return this.addressCreator['createHost$inet_ipaddr_test_TestBase_HostKey'](key);
    }

    public createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>IPAddressStringParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, ipv4RangeOptions);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((typeof x === 'number') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(key : TestBase.IPAddressStringKey) : IPAddressString {
        return this.addressCreator['createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey'](key);
    }

    createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(key : MACAddressTest.MACAddressStringKey) : MACAddressString {
        return this.addressCreator['createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey'](key);
    }

    createAddress$byte_A(bytes : number[]) : IPAddress {
        return this.addressCreator['createAddress$byte_A'](bytes);
    }

    createAddress$int(val : number) : IPv4Address {
        return this.addressCreator['createAddress$int'](val);
    }

    createMACAddress$byte_A(bytes : number[]) : MACAddress {
        return this.addressCreator['createMACAddress$byte_A'](bytes);
    }

    createMACAddress$long$boolean(val : number, extended : boolean) : MACAddress {
        return this.addressCreator['createMACAddress$long$boolean'](val, extended);
    }

    createHost_inet_aton(x : string) : HostName {
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(new TestBase.HostKey(x, TestBase.HOST_INET_ATON_OPTIONS_$LI$()));
    }

    createHost$java_lang_String(x : string) : HostName {
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(new TestBase.HostKey(x, TestBase.HOST_OPTIONS_$LI$()));
    }

    public createHost$java_lang_String$inet_ipaddr_HostNameParameters(x : string, options : HostNameParameters) : HostName {
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(new TestBase.HostKey(x, options));
    }

    public createHost(x? : any, options? : any) : any {
        if(((typeof x === 'string') || x === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            return <any>this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, options);
        } else if(((x != null && x instanceof <any>TestBase.HostKey) || x === null) && options === undefined) {
            return <any>this.createHost$inet_ipaddr_test_TestBase_HostKey(x);
        } else if(((typeof x === 'string') || x === null) && options === undefined) {
            return <any>this.createHost$java_lang_String(x);
        } else throw new Error('invalid overload');
    }

    createInetAtonAddress(x : string) : IPAddressString {
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$());
    }

    createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x : string, opts : IPAddressStringParameters) : IPAddressString {
        let key : TestBase.IPAddressStringKey = new TestBase.IPAddressStringKey(x, opts);
        return this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(key);
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        return this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(new TestBase.IPAddressStringKey(x, TestBase.ADDRESS_OPTIONS_$LI$()));
    }

    public createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x : string, opts : MACAddressStringParameters) : MACAddressString {
        let key : MACAddressTest.MACAddressStringKey = new MACAddressTest.MACAddressStringKey(x, opts);
        return this.createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(key);
    }

    public createMACAddress(x? : any, opts? : any) : any {
        if(((typeof x === 'string') || x === null) && ((opts != null && opts instanceof <any>MACAddressStringParameters) || opts === null)) {
            return <any>this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x, opts);
        } else if(((typeof x === 'number') || x === null) && ((typeof opts === 'boolean') || opts === null)) {
            return <any>this.createMACAddress$long$boolean(x, opts);
        } else if(((x != null && x instanceof <any>MACAddressTest.MACAddressStringKey) || x === null) && opts === undefined) {
            return <any>this.createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && opts === undefined) {
            return <any>this.createMACAddress$byte_A(x);
        } else if(((typeof x === 'string') || x === null) && opts === undefined) {
            return <any>this.createMACAddress$java_lang_String(x);
        } else throw new Error('invalid overload');
    }

    createMACAddress$java_lang_String(x : string) : MACAddressString {
        return this.createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(new MACAddressTest.MACAddressStringKey(x, TestBase.MAC_ADDRESS_OPTIONS_$LI$()));
    }

    addFailure(failure : TestBase.Failure) {
        this.failures.addFailure(failure, (<any>this.constructor));
    }

    incrementTestCount() {
        this.failures.incrementTestCount();
    }

    report() {
        TestBase.showMessage(/* getSimpleName */(c => c["__class"]?c["__class"].substring(c["__class"].lastIndexOf('.')+1):c["name"].substring(c["name"].lastIndexOf('.')+1))((<any>this.constructor)));
        this.perf.report();
        this.failures.report();
        TestBase.showMessage("Done: " + /* getSimpleName */(c => c["__class"]?c["__class"].substring(c["__class"].lastIndexOf('.')+1):c["name"].substring(c["name"].lastIndexOf('.')+1))((<any>this.constructor)));
    }

    abstract runTest();

    public testPrefixes$inet_ipaddr_AddressSegmentSeries$int$int$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries(original : AddressSegmentSeries, prefix : number, adjustment : number, next : AddressSegmentSeries, previous : AddressSegmentSeries, adjusted : AddressSegmentSeries, prefixSet : AddressSegmentSeries, prefixApplied : AddressSegmentSeries) {
        let removed : AddressSegmentSeries = original.removePrefixLength();
        if(original.isPrefixed()) {
            let prefLength : number = original.getPrefixLength();
            let bitsSoFar : number = 0;
            for(let i : number = 0; i < removed.getSegmentCount(); i++) {
                let prevBitsSoFar : number = bitsSoFar;
                let seg : AddressSegment = removed.getSegment(i);
                bitsSoFar += seg.getBitCount();
                if(prefLength >= bitsSoFar) {
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(seg,original.getSegment(i)))) {
                        this.addFailure(new TestBase.Failure("removed prefix: " + removed, original));
                        break;
                    }
                } else if(prefLength <= prevBitsSoFar) {
                    if(!seg.isZero()) {
                        this.addFailure(new TestBase.Failure("removed prefix all: " + removed, original));
                        break;
                    }
                } else {
                    let segPrefix : number = prefLength - prevBitsSoFar;
                    let mask : number = ~0 << (seg.getBitCount() - segPrefix);
                    let lower : number = seg.getLowerSegmentValue();
                    let upper : number = seg.getUpperSegmentValue();
                    if((lower & mask) !== lower || (upper & mask) !== upper) {
                        removed = original.removePrefixLength();
                        this.addFailure(new TestBase.Failure("prefix app: " + removed + " " + (lower & mask) + " " + (upper & mask), original));
                        break;
                    }
                }
            };
        } else if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(removed,original))) {
            this.addFailure(new TestBase.Failure("prefix removed: " + removed, original));
        }
        let adjustedSeries : AddressSegmentSeries = original['adjustPrefixBySegment$boolean'](true);
        let nextPrefix : number = adjustedSeries.getPrefixLength();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(adjustedSeries,next))) {
            this.addFailure(new TestBase.Failure("prefix next: " + adjustedSeries, next));
        } else {
            adjustedSeries = original['adjustPrefixBySegment$boolean'](false);
            let prevPrefix : number = adjustedSeries.getPrefixLength();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(adjustedSeries,previous))) {
                this.addFailure(new TestBase.Failure("prefix previous: " + adjustedSeries, previous));
            } else {
                adjustedSeries = original['adjustPrefixLength$int'](adjustment);
                let adjustedPrefix : number = adjustedSeries.getPrefixLength();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(adjustedSeries,adjusted))) {
                    this.addFailure(new TestBase.Failure("prefix adjusted: " + adjustedSeries, adjusted));
                } else {
                    adjustedSeries = original['setPrefixLength$int'](prefix);
                    let setPrefix : number = adjustedSeries.getPrefixLength();
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(adjustedSeries,prefixSet))) {
                        this.addFailure(new TestBase.Failure("prefix set: " + adjustedSeries, prefixSet));
                    } else {
                        adjustedSeries = original.applyPrefixLength(prefix);
                        let appliedPrefix : number = adjustedSeries.getPrefixLength();
                        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(adjustedSeries,prefixApplied))) {
                            this.addFailure(new TestBase.Failure("prefix applied: " + adjustedSeries, prefixApplied));
                        } else {
                            let expected : TestBase.ExpectedPrefixes = new TestBase.ExpectedPrefixes((original != null && original instanceof <any>MACAddress), original.getPrefixLength(), original.getBitCount(), original.getBitsPerSegment(), prefix, adjustment);
                            if(!expected.compare(nextPrefix, prevPrefix, adjustedPrefix, setPrefix, appliedPrefix)) {
                                this.addFailure(new TestBase.Failure(expected.print$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer(nextPrefix, prevPrefix, adjustedPrefix, setPrefix, appliedPrefix)));
                            }
                        }
                    }
                }
            }
        }
    }

    public testPrefixes(original? : any, prefix? : any, adjustment? : any, next? : any, previous? : any, adjusted? : any, prefixSet? : any, prefixApplied? : any) : any {
        if(((original != null && (original["__interfaces"] != null && original["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || original.constructor != null && original.constructor["__interfaces"] != null && original.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || original === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof adjustment === 'number') || adjustment === null) && ((next != null && (next["__interfaces"] != null && next["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || next.constructor != null && next.constructor["__interfaces"] != null && next.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || next === null) && ((previous != null && (previous["__interfaces"] != null && previous["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || previous.constructor != null && previous.constructor["__interfaces"] != null && previous.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || previous === null) && ((adjusted != null && (adjusted["__interfaces"] != null && adjusted["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || adjusted.constructor != null && adjusted.constructor["__interfaces"] != null && adjusted.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || adjusted === null) && ((prefixSet != null && (prefixSet["__interfaces"] != null && prefixSet["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixSet.constructor != null && prefixSet.constructor["__interfaces"] != null && prefixSet.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixSet === null) && ((prefixApplied != null && (prefixApplied["__interfaces"] != null && prefixApplied["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixApplied.constructor != null && prefixApplied.constructor["__interfaces"] != null && prefixApplied.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixApplied === null)) {
            return <any>this.testPrefixes$inet_ipaddr_AddressSegmentSeries$int$int$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries(original, prefix, adjustment, next, previous, adjusted, prefixSet, prefixApplied);
        } else throw new Error('invalid overload');
    }

    public testPrefix$inet_ipaddr_AddressSegmentSeries$java_lang_Integer$int$java_lang_Integer(original : AddressSegmentSeries, prefixLength : number, minPrefix : number, equivalentPrefix : number) {
        if(!Objects.equals(original.getPrefixLength(), prefixLength)) {
            this.addFailure(new TestBase.Failure("prefix: " + original.getPrefixLength() + " expected: " + prefixLength, original));
        } else if(!Objects.equals(original.getMinPrefixLengthForBlock(), minPrefix)) {
            this.addFailure(new TestBase.Failure("min prefix: " + original.getMinPrefixLengthForBlock() + " expected: " + minPrefix, original));
        } else if(!Objects.equals(original.getPrefixLengthForSingleBlock(), equivalentPrefix)) {
            this.addFailure(new TestBase.Failure("equivalent prefix: " + original.getPrefixLengthForSingleBlock() + " expected: " + equivalentPrefix, original));
        }
    }

    public testPrefix(original? : any, prefixLength? : any, minPrefix? : any, equivalentPrefix? : any) : any {
        if(((original != null && (original["__interfaces"] != null && original["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || original.constructor != null && original.constructor["__interfaces"] != null && original.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || original === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof minPrefix === 'number') || minPrefix === null) && ((typeof equivalentPrefix === 'number') || equivalentPrefix === null)) {
            return <any>this.testPrefix$inet_ipaddr_AddressSegmentSeries$java_lang_Integer$int$java_lang_Integer(original, prefixLength, minPrefix, equivalentPrefix);
        } else throw new Error('invalid overload');
    }

    public testReverse$inet_ipaddr_AddressSegmentSeries$boolean$boolean(series : AddressSegmentSeries, bitsReversedIsSame : boolean, bitsReversedPerByteIsSame : boolean) {
        let segmentsReversed : AddressSegmentSeries = series.reverseSegments();
        for(let i : number = 0; i < series.getSegmentCount(); i++) {
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series.getSegment(i),segmentsReversed.getSegment(series.getDivisionCount() - i - 1)))) {
                this.addFailure(new TestBase.Failure("reversal: " + series, series));
            }
        };
        let bytesReversed : AddressSegmentSeries = segmentsReversed.reverseBytes().reverseBytesPerSegment();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bytesReversed))) {
            this.addFailure(new TestBase.Failure("bytes reversal: " + series, series));
        }
        let bitsReversed : AddressSegmentSeries = series['reverseBits$boolean'](false);
        if(bitsReversedIsSame?!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed)):/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed))) {
            this.addFailure(new TestBase.Failure("bit reversal 2a: " + series, series));
        }
        bitsReversed = bitsReversed['reverseBits$boolean'](false);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed))) {
            this.addFailure(new TestBase.Failure("bit reversal 2: " + series, series));
        }
        let bitsReversed2 : AddressSegmentSeries = series['reverseBits$boolean'](true);
        if(bitsReversedPerByteIsSame?!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed2)):/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed2))) {
            this.addFailure(new TestBase.Failure("bit reversal 3a: " + series, series));
        }
        bitsReversed2 = bitsReversed2['reverseBits$boolean'](true);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(series,bitsReversed2))) {
            this.addFailure(new TestBase.Failure("bit reversal 3: " + series, series));
        }
        let bytes : number[] = series.getBytes();
        let bitsReversed3 : AddressSegmentSeries = series.reverseBytes().reverseBytesPerSegment();
        for(let i : number = 0, j : number = bytes.length - 1; i < bitsReversed3.getSegmentCount(); i++) {
            let seg : AddressSegment = bitsReversed3.getSegment(i);
            let segBytes : number[] = seg.getBytes();
            for(let k : number = seg.getByteCount() - 1; k >= 0; k--) {
                if(segBytes[k] !== bytes[j--]) {
                    this.addFailure(new TestBase.Failure("reversal 4: " + series, series));
                }
            };
        };
    }

    public testReverse(series? : any, bitsReversedIsSame? : any, bitsReversedPerByteIsSame? : any) : any {
        if(((series != null && (series["__interfaces"] != null && series["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || series.constructor != null && series.constructor["__interfaces"] != null && series.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || series === null) && ((typeof bitsReversedIsSame === 'boolean') || bitsReversedIsSame === null) && ((typeof bitsReversedPerByteIsSame === 'boolean') || bitsReversedPerByteIsSame === null)) {
            return <any>this.testReverse$inet_ipaddr_AddressSegmentSeries$boolean$boolean(series, bitsReversedIsSame, bitsReversedPerByteIsSame);
        } else throw new Error('invalid overload');
    }

    public testIPv6Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w : IPAddressString, ipAddr : IPAddress, normalizedString : string, normalizedWildcardString : string, canonicalWildcardString : string, sqlString : string, fullString : string, compressedString : string, canonicalString : string, subnetString : string, compressedWildcardString : string, mixedStringNoCompressMixed : string, mixedStringNoCompressHost : string, mixedStringCompressCoveredHost : string, mixedString : string, reverseDNSString : string, uncHostString : string, base85String : string, singleHex : string, singleOctal : string) {
        this.testStrings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, subnetString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        this.testIPv6OnlyStrings(w, <IPv6Address>ipAddr, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, base85String);
    }

    public testIPv6Strings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, compressedWildcardString? : any, mixedStringNoCompressMixed? : any, mixedStringNoCompressHost? : any, mixedStringCompressCoveredHost? : any, mixedString? : any, reverseDNSString? : any, uncHostString? : any, base85String? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof mixedStringNoCompressMixed === 'string') || mixedStringNoCompressMixed === null) && ((typeof mixedStringNoCompressHost === 'string') || mixedStringNoCompressHost === null) && ((typeof mixedStringCompressCoveredHost === 'string') || mixedStringCompressCoveredHost === null) && ((typeof mixedString === 'string') || mixedString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof base85String === 'string') || base85String === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            return <any>this.testIPv6Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
        } else throw new Error('invalid overload');
    }

    testIPv6OnlyStrings(w : IPAddressString, ipAddr : IPv6Address, mixedStringNoCompressMixed : string, mixedStringNoCompressHost : string, mixedStringCompressCoveredHost : string, mixedString : string, base85String : string) {
        try {
            let base85 : string = null;
            try {
                base85 = ipAddr.toBase85String();
                let b85Match : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(base85,base85String));
                if(!b85Match) {
                    this.addFailure(new TestBase.Failure("failed expected: " + base85String + " actual: " + base85, w));
                }
            } catch(e) {
                let isMatch : boolean = base85String == null;
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected non-null, actual: " + e, w));
                }
            };
            let m : string = ipAddr.toMixedString();
            let compressOpts : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST, IPv6AddressSection.CompressOptions.MixedCompressionOptions.COVERED_BY_HOST);
            let mixedParams : IPv6AddressSection.IPv6StringOptions = new IPv6AddressSection.IPv6StringOptions.Builder().setMakeMixed$boolean(true).setCompressOptions(compressOpts).toOptions();
            let mixedCompressCoveredHost : string = ipAddr.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(mixedParams);
            compressOpts = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST, IPv6AddressSection.CompressOptions.MixedCompressionOptions.NO_HOST);
            mixedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setMakeMixed$boolean(true).setCompressOptions(compressOpts).toOptions();
            let mixedNoCompressHost : string = ipAddr.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(mixedParams);
            compressOpts = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST, IPv6AddressSection.CompressOptions.MixedCompressionOptions.NO);
            mixedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setMakeMixed$boolean(true).setCompressOptions(compressOpts).toOptions();
            let mixedNoCompressMixed : string = ipAddr.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(mixedParams);
            this.confirmAddrStrings(ipAddr, m, mixedCompressCoveredHost, mixedNoCompressHost, mixedNoCompressMixed, base85);
            let nMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(m,mixedString));
            if(!nMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + mixedString + " actual: " + m, w));
            } else {
                let mccMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(mixedCompressCoveredHost,mixedStringCompressCoveredHost));
                if(!mccMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + mixedStringCompressCoveredHost + " actual: " + mixedCompressCoveredHost, w));
                } else {
                    let msMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(mixedNoCompressHost,mixedStringNoCompressHost));
                    if(!msMatch) {
                        this.addFailure(new TestBase.Failure("failed expected: " + mixedStringNoCompressHost + " actual: " + mixedNoCompressHost, w));
                    } else {
                        let mncmMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(mixedNoCompressMixed,mixedStringNoCompressMixed));
                        if(!mncmMatch) {
                            this.addFailure(new TestBase.Failure("failed expected: " + mixedStringNoCompressMixed + " actual: " + mixedNoCompressMixed, w));
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected throw " + e.toString()));
        };
        this.incrementTestCount();
    }

    public confirmAddrStrings$inet_ipaddr_mac_MACAddress$java_lang_String_A(macAddr : MACAddress, ...strs : string[]) : boolean {
        for(let index165=0; index165 < strs.length; index165++) {
            let str = strs[index165];
            {
                let addrString : MACAddressString = new MACAddressString(str);
                let addr : MACAddress = addrString.getAddress();
                if(!macAddr.equals(addr)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, macAddr));
                    return false;
                }
            }
        }
        this.incrementTestCount();
        return true;
    }

    public confirmAddrStrings(macAddr? : any, ...strs : any[]) : any {
        if(((macAddr != null && macAddr instanceof <any>MACAddress) || macAddr === null) && ((strs != null && strs instanceof <any>Array && (strs.length==0 || strs[0] == null ||(typeof strs[0] === 'string'))) || strs === null)) {
            return <any>this.confirmAddrStrings$inet_ipaddr_mac_MACAddress$java_lang_String_A(macAddr, strs);
        } else if(((macAddr != null && macAddr instanceof <any>IPAddress) || macAddr === null) && ((strs != null && strs instanceof <any>Array && (strs.length==0 || strs[0] == null ||(typeof strs[0] === 'string'))) || strs === null)) {
            return <any>this.confirmAddrStrings$inet_ipaddr_IPAddress$java_lang_String_A(macAddr, strs);
        } else if(((macAddr != null && macAddr instanceof <any>IPAddress) || macAddr === null) && ((strs != null && strs instanceof <any>Array && (strs.length==0 || strs[0] == null ||(strs[0] != null && strs[0] instanceof <any>IPAddressString))) || strs === null)) {
            return <any>this.confirmAddrStrings$inet_ipaddr_IPAddress$inet_ipaddr_IPAddressString_A(macAddr, strs);
        } else throw new Error('invalid overload');
    }

    static DEFAULT_BASIC_VALIDATION_OPTIONS : IPAddressStringParameters; public static DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$() : IPAddressStringParameters { if(TestBase.DEFAULT_BASIC_VALIDATION_OPTIONS == null) TestBase.DEFAULT_BASIC_VALIDATION_OPTIONS = new IPAddressStringParameters.Builder().toParams(); return TestBase.DEFAULT_BASIC_VALIDATION_OPTIONS; };

    confirmAddrStrings$inet_ipaddr_IPAddress$java_lang_String_A(ipAddr : IPAddress, ...strs : string[]) : boolean {
        for(let index166=0; index166 < strs.length; index166++) {
            let str = strs[index166];
            {
                if(str == null) {
                    continue;
                }
                let addrString : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(str, TestBase.DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$());
                let addr : IPAddress = addrString.getAddress();
                if(!ipAddr.equals(addr)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
            }
        }
        this.incrementTestCount();
        return true;
    }

    confirmAddrStrings$inet_ipaddr_IPAddress$inet_ipaddr_IPAddressString_A(ipAddr : IPAddress, ...strs : IPAddressString[]) : boolean {
        for(let index167=0; index167 < strs.length; index167++) {
            let str = strs[index167];
            {
                let addr : IPAddress = str.getAddress();
                if(!ipAddr.equals(addr)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
            }
        }
        this.incrementTestCount();
        return true;
    }

    public confirmHostStrings$inet_ipaddr_IPAddress$boolean$java_lang_String_A(ipAddr : IPAddress, omitZone : boolean, ...strs : string[]) : boolean {
        for(let index168=0; index168 < strs.length; index168++) {
            let str = strs[index168];
            {
                let hostName : HostName = new HostName(str);
                let a : IPAddress = hostName.getAddress();
                if(omitZone) {
                    let ipv6Addr : IPv6Address = ipAddr.toIPv6();
                    ipAddr = new IPv6Address(ipv6Addr.getSection());
                }
                if(!ipAddr.equals(a)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
                let again : string = hostName.toNormalizedString();
                hostName = new HostName(again);
                a = hostName.getAddress();
                if(!ipAddr.equals(a)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
            }
        }
        this.incrementTestCount();
        return true;
    }

    public confirmHostStrings(ipAddr? : any, omitZone? : any, ...strs : any[]) : any {
        if(((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof omitZone === 'boolean') || omitZone === null) && ((strs != null && strs instanceof <any>Array && (strs.length==0 || strs[0] == null ||(typeof strs[0] === 'string'))) || strs === null)) {
            return <any>this.confirmHostStrings$inet_ipaddr_IPAddress$boolean$java_lang_String_A(ipAddr, omitZone, strs);
        } else if(((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((omitZone != null && omitZone instanceof <any>Array && (omitZone.length==0 || omitZone[0] == null ||(omitZone[0] != null && omitZone[0] instanceof <any>HostName))) || omitZone === null) && strs === undefined) {
            return <any>this.confirmHostStrings$inet_ipaddr_IPAddress$inet_ipaddr_HostName_A(ipAddr, omitZone);
        } else throw new Error('invalid overload');
    }

    confirmHostStrings$inet_ipaddr_IPAddress$inet_ipaddr_HostName_A(ipAddr : IPAddress, ...strs : HostName[]) : boolean {
        for(let index169=0; index169 < strs.length; index169++) {
            let str = strs[index169];
            {
                let a : IPAddress = str.getAddress();
                if(!ipAddr.equals(a)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
                let again : string = str.toNormalizedString();
                str = new HostName(again);
                a = str.getAddress();
                if(!ipAddr.equals(a)) {
                    this.addFailure(new TestBase.Failure("failed produced string: " + str, ipAddr));
                    return false;
                }
            }
        }
        this.incrementTestCount();
        return true;
    }

    public testMACStrings$inet_ipaddr_MACAddressString$inet_ipaddr_mac_MACAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w : MACAddressString, ipAddr : MACAddress, normalizedString : string, compressedString : string, canonicalString : string, dottedString : string, spaceDelimitedString : string, singleHex : string) {
        let c : string = ipAddr.toCompressedString();
        let canonical : string = ipAddr.toCanonicalString();
        let d : string = ipAddr.toDashedString();
        let n : string = ipAddr.toNormalizedString();
        let cd : string = ipAddr.toColonDelimitedString();
        let sd : string = ipAddr.toSpaceDelimitedString();
        let hex : string;
        let hexNoPrefix : string;
        try {
            hex = ipAddr.toHexString(true);
            this.confirmAddrStrings(ipAddr, hex);
        } catch(e) {
            let isMatch : boolean = singleHex == null;
            if(!isMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + singleHex + " actual: " + e, w));
            }
        };
        try {
            hexNoPrefix = ipAddr.toHexString(false);
            let isMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(singleHex,hexNoPrefix));
            if(!isMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + singleHex + " actual: " + hexNoPrefix, w));
            }
            this.confirmAddrStrings(ipAddr, hexNoPrefix);
        } catch(e) {
            let isMatch : boolean = singleHex == null;
            if(!isMatch) {
                this.addFailure(new TestBase.Failure("failed expected non-null, actual: " + e, w));
            }
        };
        this.confirmAddrStrings(ipAddr, c, canonical, d, n, cd, sd);
        let nMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedString,n));
        if(!nMatch) {
            this.addFailure(new TestBase.Failure("failed expected: " + normalizedString + " actual: " + n, w));
        } else {
            let nwMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedString,cd));
            if(!nwMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + normalizedString + " actual: " + cd, w));
            } else {
                let cawMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(spaceDelimitedString,sd));
                if(!cawMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + spaceDelimitedString + " actual: " + sd, w));
                } else {
                    let cMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(compressedString,c));
                    if(!cMatch) {
                        this.addFailure(new TestBase.Failure("failed expected: " + compressedString + " actual: " + c, w));
                    } else {
                        let sMatch : boolean;
                        let dotted : string = null;
                        try {
                            dotted = ipAddr.toDottedString();
                            this.confirmAddrStrings(ipAddr, dotted);
                            sMatch = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(dotted,dottedString));
                        } catch(e) {
                            sMatch = (dottedString == null);
                        };
                        if(!sMatch) {
                            this.addFailure(new TestBase.Failure("failed expected: " + dottedString + " actual: " + dotted, w));
                        } else {
                            let dashedMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(canonicalString,d));
                            if(!dashedMatch) {
                                this.addFailure(new TestBase.Failure("failed expected: " + canonicalString + " actual: " + d, w));
                            } else {
                                let canonicalMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(canonicalString,canonical));
                                if(!canonicalMatch) {
                                    this.addFailure(new TestBase.Failure("failed expected: " + canonicalString + " actual: " + canonical, w));
                                }
                            }
                        }
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    public testMACStrings(w? : any, ipAddr? : any, normalizedString? : any, compressedString? : any, canonicalString? : any, dottedString? : any, spaceDelimitedString? : any, singleHex? : any) : any {
        if(((w != null && w instanceof <any>MACAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>MACAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof dottedString === 'string') || dottedString === null) && ((typeof spaceDelimitedString === 'string') || spaceDelimitedString === null) && ((typeof singleHex === 'string') || singleHex === null)) {
            return <any>this.testMACStrings$inet_ipaddr_MACAddressString$inet_ipaddr_mac_MACAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, compressedString, canonicalString, dottedString, spaceDelimitedString, singleHex);
        } else throw new Error('invalid overload');
    }

    public testHostAddress(host? : any, hostExpected? : any, addrExpected? : any, portExpected? : any, expectedZone? : any, prefixLengthExpected? : any) : any {
        if(((typeof host === 'string') || host === null) && hostExpected === undefined && addrExpected === undefined && portExpected === undefined && expectedZone === undefined && prefixLengthExpected === undefined) {
            return <any>this.testHostAddress$java_lang_String(host);
        } else throw new Error('invalid overload');
    }

    testHostAddress$java_lang_String(addressStr : string) {
        let str : IPAddressString = this.createAddress$java_lang_String(addressStr);
        let address : IPAddress = str.getAddress();
        if(address != null) {
            let hostAddress : IPAddress = str.getHostAddress();
            let prefixIndex : number = addressStr.indexOf(IPAddress.PREFIX_LEN_SEPARATOR);
            if(prefixIndex < 0) {
                if(!address.equals(hostAddress) || !address.contains(hostAddress)) {
                    this.addFailure(new TestBase.Failure("failed host address with no prefix: " + hostAddress + " expected: " + address, str));
                }
            } else {
                let substr : string = addressStr.substring(0, prefixIndex);
                let str2 : IPAddressString = this.createAddress$java_lang_String(substr);
                let address2 : IPAddress = str2.getAddress();
                if(!address2.equals(hostAddress)) {
                    this.addFailure(new TestBase.Failure("failed host address: " + hostAddress + " expected: " + address2, str));
                }
            }
        }
    }

    public testStrings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w : IPAddressString, ipAddr : IPAddress, normalizedString : string, normalizedWildcardString : string, canonicalWildcardString : string, sqlString : string, fullString : string, compressedString : string, canonicalString : string, subnetString : string, cidrString : string, compressedWildcardString : string, reverseDNSString : string, uncHostString : string, singleHex : string, singleOctal : string) {
        try {
            this.testHostAddress$java_lang_String(w.toString());
            let c : string = ipAddr.toCompressedString();
            let canonical : string = ipAddr.toCanonicalString();
            let s : string = ipAddr.toSubnetString();
            let cidr : string = ipAddr.toPrefixLengthString();
            let n : string = ipAddr.toNormalizedString();
            let nw : string = ipAddr.toNormalizedWildcardString();
            let caw : string = ipAddr.toCanonicalWildcardString();
            let cw : string = ipAddr.toCompressedWildcardString();
            let sql : string = ipAddr.toSQLWildcardString();
            let full : string = ipAddr.toFullString();
            let rDNS : string = ipAddr.toReverseDNSLookupString();
            let unc : string = ipAddr.toUNCHostName();
            let hex : string;
            let hexNoPrefix : string;
            let octal : string;
            try {
                hex = ipAddr.toHexString(true);
                let isMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(singleHex,hex));
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + singleHex + " actual: " + hex, w));
                }
                this.confirmAddrStrings(ipAddr, hex);
            } catch(e) {
                let isMatch : boolean = singleHex == null;
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + singleHex + " actual: " + e, w));
                }
            };
            try {
                hexNoPrefix = ipAddr.toHexString(false);
                if(ipAddr.isIPv6()) {
                    this.confirmAddrStrings(ipAddr, hexNoPrefix);
                }
            } catch(e) {
                let isMatch : boolean = singleHex == null;
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected non-null, actual: " + e, w));
                }
            };
            try {
                octal = ipAddr.toOctalString(true);
                let isMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(singleOctal,octal));
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + singleOctal + " actual: " + octal, w));
                }
                if(ipAddr.isIPv4()) {
                    this.confirmAddrStrings(ipAddr, octal);
                }
            } catch(e) {
                let isMatch : boolean = singleOctal == null;
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + singleOctal + " actual: " + e, w));
                }
            };
            try {
                let binary : string = ipAddr.toBinaryString();
                for(let i : number = 0; i < binary.length; i++) {
                    let c2 : string = binary.charAt(i);
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == '%'.charCodeAt(0) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == '/'.charCodeAt(0)) {
                        let next : number = binary.indexOf('-', i + 1);
                        if(next >= 0) {
                            i = next + 1;
                        } else {
                            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == '/'.charCodeAt(0) && binary.length - i > 4) {
                                this.addFailure(new TestBase.Failure("failed binary prefix: " + binary, w));
                            }
                            break;
                        }
                    }
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) != '0'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) != '1'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) != '-'.charCodeAt(0)) {
                        this.addFailure(new TestBase.Failure("failed expected non-null binary string but got: " + binary, w));
                        break;
                    }
                };
            } catch(e) {
                let isMatch : boolean = singleHex == null;
                if(!isMatch) {
                    this.addFailure(new TestBase.Failure("failed expected non-null binary string but got: " + e, w));
                }
            };
            this.confirmAddrStrings(ipAddr, c, canonical, s, cidr, n, nw, caw, cw);
            if(ipAddr.isIPv6()) {
                this.confirmAddrStrings(ipAddr, full);
                this.confirmHostStrings(ipAddr, true, rDNS);
                this.confirmHostStrings(ipAddr, false, unc);
            } else {
                let params : IPAddressStringParameters = new IPAddressStringParameters.Builder().allow_inet_aton(false).toParams();
                let fullAddrString : IPAddressString = new IPAddressString(full, params);
                this.confirmAddrStrings(ipAddr, fullAddrString);
                this.confirmHostStrings(ipAddr, false, rDNS, unc);
            }
            this.confirmHostStrings(ipAddr, false, c, canonical, s, cidr, n, nw, caw, cw);
            if(ipAddr.isIPv6()) {
                this.confirmHostStrings(ipAddr, false, full);
            } else {
                let params : HostNameParameters = new HostNameParameters.Builder().getAddressOptionsBuilder().allow_inet_aton(false).getParentBuilder().toParams();
                let fullAddrString : HostName = new HostName(full, params);
                this.confirmHostStrings(ipAddr, fullAddrString);
            }
            let nMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedString,n));
            if(!nMatch) {
                this.addFailure(new TestBase.Failure("failed expected: " + normalizedString + " actual: " + n, w));
            } else {
                let nwMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedWildcardString,nw));
                if(!nwMatch) {
                    this.addFailure(new TestBase.Failure("failed expected: " + normalizedWildcardString + " actual: " + nw, w));
                } else {
                    let cawMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(canonicalWildcardString,caw));
                    if(!cawMatch) {
                        this.addFailure(new TestBase.Failure("failed expected: " + canonicalWildcardString + " actual: " + caw, w));
                    } else {
                        let cMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(compressedString,c));
                        if(!cMatch) {
                            this.addFailure(new TestBase.Failure("failed expected: " + compressedString + " actual: " + c, w));
                        } else {
                            let sMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(subnetString,s));
                            if(!sMatch) {
                                this.addFailure(new TestBase.Failure("failed expected: " + subnetString + " actual: " + s, w));
                            } else {
                                let cwMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(compressedWildcardString,cw));
                                if(!cwMatch) {
                                    this.addFailure(new TestBase.Failure("failed expected: " + compressedWildcardString + " actual: " + cw, w));
                                } else {
                                    let wMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(sqlString,sql));
                                    if(!wMatch) {
                                        this.addFailure(new TestBase.Failure("failed expected: " + sqlString + " actual: " + sql, w));
                                    } else {
                                        let cidrMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(cidrString,cidr));
                                        if(!cidrMatch) {
                                            this.addFailure(new TestBase.Failure("failed expected: " + cidrString + " actual: " + cidr, w));
                                        } else {
                                            let canonicalMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(canonicalString,canonical));
                                            if(!canonicalMatch) {
                                                this.addFailure(new TestBase.Failure("failed expected: " + canonicalString + " actual: " + canonical, w));
                                            } else {
                                                let fullMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(fullString,full));
                                                if(!fullMatch) {
                                                    this.addFailure(new TestBase.Failure("failed expected: " + fullString + " actual: " + full, w));
                                                } else {
                                                    let rdnsMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(reverseDNSString,rDNS));
                                                    if(!rdnsMatch) {
                                                        this.addFailure(new TestBase.Failure("failed expected: " + reverseDNSString + " actual: " + rDNS, w));
                                                    } else {
                                                        let uncMatch : boolean = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(uncHostString,unc));
                                                        if(!uncMatch) {
                                                            this.addFailure(new TestBase.Failure("failed expected: " + uncHostString + " actual: " + unc, w));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected throw: " + e));
        };
        this.incrementTestCount();
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            return <any>this.testStrings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else throw new Error('invalid overload');
    }

    public hostLabelsTest$java_lang_String$java_lang_String_A(x : string, labels : string[]) {
        let host : HostName = this.createHost$java_lang_String(x);
        this.hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(host, labels);
    }

    public hostLabelsTest(x? : any, labels? : any) : any {
        if(((typeof x === 'string') || x === null) && ((labels != null && labels instanceof <any>Array && (labels.length==0 || labels[0] == null ||(typeof labels[0] === 'string'))) || labels === null)) {
            return <any>this.hostLabelsTest$java_lang_String$java_lang_String_A(x, labels);
        } else if(((x != null && x instanceof <any>HostName) || x === null) && ((labels != null && labels instanceof <any>Array && (labels.length==0 || labels[0] == null ||(typeof labels[0] === 'string'))) || labels === null)) {
            return <any>this.hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(x, labels);
        } else throw new Error('invalid overload');
    }

    hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(host : HostName, labels : string[]) {
        if(host.getNormalizedLabels().length !== labels.length) {
            this.addFailure(new TestBase.Failure("normalization length " + host.getNormalizedLabels().length, host));
        } else {
            for(let i : number = 0; i < labels.length; i++) {
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(labels[i],host.getNormalizedLabels()[i]))) {
                    this.addFailure(new TestBase.Failure("normalization label " + host.getNormalizedLabels()[i] + " not expected label " + labels[i], host));
                    break;
                }
            };
        }
        this.incrementTestCount();
    }

    testCache(strs : string[], cache : AddressNetwork.HostIdentifierStringGenerator<any>, producer : (p1: string) => any, testSize : boolean, useBytes : boolean) {
        for(let index170=0; index170 < strs.length; index170++) {
            let str = strs[index170];
            {
                if(useBytes) {
                    let first : IPAddressString = <any>(target => (typeof target === 'function')?target(str):(<any>target).apply(str))(producer);
                    let firstAddr : IPAddress = first.getAddress();
                    if(firstAddr == null) {
                        cache.get$java_lang_String(str);
                    } else {
                        cache.get$inet_ipaddr_Address_AddressProvider(new TestBase.TestBase$0(this, firstAddr));
                        let second : IPAddressString = <any>(target => (typeof target === 'function')?target(str):(<any>target).apply(str))(producer);
                        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(first.toNormalizedString(),second.toNormalizedString()))) {
                            this.addFailure(new TestBase.Failure("failed normalized string mismatch: " + first.toNormalizedString() + " and " + second.toNormalizedString()));
                        }
                    }
                } else {
                    cache.get$java_lang_String(str);
                }
            }
        }
        if(testSize && !useBytes) {
            let size : number = /* size */Object.keys(cache.getBackingMap()).length;
            for(let index171=0; index171 < strs.length; index171++) {
                let str = strs[index171];
                {
                    cache.get$java_lang_String(str);
                }
            }
            if(size !== /* size */Object.keys(cache.getBackingMap()).length) {
                {
                    this.addFailure(new TestBase.Failure("failed cache size mismatch: " + size + " and " + /* size */Object.keys(cache.getBackingMap()).length));
                };
            }
        }
        for(let index172=0; index172 < strs.length; index172++) {
            let str = strs[index172];
            {
                let string : HostIdentifierString = cache.get$java_lang_String(str);
                let second : HostIdentifierString = (target => (typeof target === 'function')?target(str):(<any>target).apply(str))(producer);
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,second))) {
                    {
                        this.addFailure(new TestBase.Failure("failed cache mismatch: " + string + " and " + second, string));
                    };
                }
            }
        }
    }

    public testReplace$inet_ipaddr_Address$inet_ipaddr_Address$java_lang_String_A$java_lang_String_A$char$boolean(front : Address, back : Address, fronts : string[], backs : string[], sep : string, isMac : boolean) {
        let bitsPerSegment : number = front.getBitsPerSegment();
        let segmentCount : number = front.getSegmentCount();
        let isIpv4 : boolean = !isMac && segmentCount === IPv4Address.SEGMENT_COUNT;
        let prefixes : { str: string } = { str: "[\n", toString: function() { return this.str; } };
        for(let replaceTargetIndex : number = 0; replaceTargetIndex < fronts.length; replaceTargetIndex++) {
            if(replaceTargetIndex > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>",\n"); return sb; })(prefixes);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>"["); return sb; })(prefixes);
            for(let replaceCount : number = 0; replaceCount < fronts.length - replaceTargetIndex; replaceCount++) {
                if(replaceCount > 0) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>",\n"); return sb; })(prefixes);
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>"    ["); return sb; })(prefixes);
                let lowest : { str: string } = { str: "", toString: function() { return this.str; } };
                for(let replaceSourceIndex : number = 0; replaceSourceIndex < backs.length - replaceCount; replaceSourceIndex++) {
                    let str : { str: string } = { str: "", toString: function() { return this.str; } };
                    let k : number = 0;
                    for(; k < replaceTargetIndex; k++) {
                        if(/* length */str.str.length > 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>sep); return sb; })(str);
                        }
                        /* append */(sb => { sb.str = sb.str.concat(<any>fronts[k]); return sb; })(str);
                    };
                    let current : number = k;
                    let limit : number = replaceCount + current;
                    for(; k < limit; k++) {
                        if(/* length */str.str.length > 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>sep); return sb; })(str);
                        }
                        /* append */(sb => { sb.str = sb.str.concat(<any>backs[replaceSourceIndex + k - current]); return sb; })(str);
                    };
                    for(; k < segmentCount; k++) {
                        if(/* length */str.str.length > 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>sep); return sb; })(str);
                        }
                        /* append */(sb => { sb.str = sb.str.concat(<any>fronts[k]); return sb; })(str);
                    };
                    let prefix : number;
                    let frontPrefixed : boolean = front.isPrefixed();
                    if(frontPrefixed && front.getPrefixLength() <= replaceTargetIndex * bitsPerSegment && (isMac || replaceTargetIndex > 0)) {
                        prefix = front.getPrefixLength();
                    } else if(back.isPrefixed() && back.getPrefixLength() <= (replaceSourceIndex + replaceCount) * bitsPerSegment && (isMac || replaceCount > 0)) {
                        prefix = (replaceTargetIndex * bitsPerSegment) + Math.max(0, back.getPrefixLength() - (replaceSourceIndex * bitsPerSegment));
                    } else if(frontPrefixed) {
                        if(front.getPrefixLength() <= (replaceTargetIndex + replaceCount) * bitsPerSegment) {
                            prefix = (replaceTargetIndex + replaceCount) * bitsPerSegment;
                        } else {
                            prefix = front.getPrefixLength();
                        }
                    } else {
                        prefix = null;
                    }
                    let replaceStr : string = (isMac?"MAC":(isIpv4?"IPv4":"IPv6")) + " replacing " + replaceCount + " segments in " + front + " at index " + replaceTargetIndex + " with segments from " + back + " starting at " + replaceSourceIndex;
                    let new1 : Address;
                    let new2 : Address;
                    if(isMac) {
                        new1 = (<MACAddress>front).replace(replaceTargetIndex, replaceTargetIndex + replaceCount, <MACAddress>back, replaceSourceIndex);
                        let hostIdStr : HostIdentifierString = this.createMACAddress$java_lang_String(/* toString */str.str);
                        new2 = hostIdStr.getAddress();
                        if(prefix != null) {
                            new2 = new2.setPrefixLength$int$boolean(prefix, false);
                        }
                    } else {
                        if(prefix != null) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>prefix); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'/'); return sb; })(str));
                        }
                        let hostIdStr : HostIdentifierString = this.createAddress$java_lang_String(/* toString */str.str);
                        new2 = hostIdStr.getAddress();
                        if(isIpv4) {
                            new1 = (<IPv4Address>front).replace(replaceTargetIndex, replaceTargetIndex + replaceCount, <IPv4Address>back, replaceSourceIndex);
                        } else {
                            new1 = (<IPv6Address>front).replace(replaceTargetIndex, replaceTargetIndex + replaceCount, <IPv6Address>back, replaceSourceIndex);
                        }
                    }
                    if(!new1.equals(new2)) {
                        let failStr : string = "Replacement was " + new1 + " expected was " + new2 + " " + replaceStr;
                        this.addFailure(new TestBase.Failure(failStr, front));
                    }
                    if(/* length */lowest.str.length > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>','); return sb; })(lowest);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>prefix); return sb; })(lowest);
                };
                /* append */(sb => { sb.str = sb.str.concat(<any>']'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>lowest); return sb; })(prefixes));
            };
            /* append */(sb => { sb.str = sb.str.concat(<any>']'); return sb; })(prefixes);
        };
        /* append */(sb => { sb.str = sb.str.concat(<any>']'); return sb; })(prefixes);
    }

    public testReplace(front? : any, back? : any, fronts? : any, backs? : any, sep? : any, isMac? : any) : any {
        if(((front != null && front instanceof <any>Address) || front === null) && ((back != null && back instanceof <any>Address) || back === null) && ((fronts != null && fronts instanceof <any>Array && (fronts.length==0 || fronts[0] == null ||(typeof fronts[0] === 'string'))) || fronts === null) && ((backs != null && backs instanceof <any>Array && (backs.length==0 || backs[0] == null ||(typeof backs[0] === 'string'))) || backs === null) && ((typeof sep === 'string') || sep === null) && ((typeof isMac === 'boolean') || isMac === null)) {
            return <any>this.testReplace$inet_ipaddr_Address$inet_ipaddr_Address$java_lang_String_A$java_lang_String_A$char$boolean(front, back, fronts, backs, sep, isMac);
        } else throw new Error('invalid overload');
    }

    testAppendAndInsert(front : Address, back : Address, fronts : string[], backs : string[], sep : string, expectedPref : number[], isMac : boolean) {
        if(front.getSegmentCount() >= expectedPref.length) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }
        let extra : number = 0;
        if(isMac) {
            extra = MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT - front.getSegmentCount();
        }
        let bitsPerSegment : number = front.getBitsPerSegment();
        let isIpv4 : boolean = !isMac && front.getSegmentCount() === IPv4Address.SEGMENT_COUNT;
        for(let i : number = 0; i < fronts.length; i++) {
            let str : { str: string } = { str: "", toString: function() { return this.str; } };
            let k : number = 0;
            for(; k < i; k++) {
                if(/* length */str.str.length > 0) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>sep); return sb; })(str);
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>fronts[k]); return sb; })(str);
            };
            for(; k < fronts.length; k++) {
                if(/* length */str.str.length > 0) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>sep); return sb; })(str);
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>backs[k]); return sb; })(str);
            };
            let hostIdStr : HostIdentifierString = null;
            let frontSection : AddressSection = front['getSection$int$int'](0, i);
            let backSection : AddressSection = back['getSection$int'](i);
            let backSectionInvalid : AddressSection = null;
            let frontSectionInvalid : AddressSection = null;
            if(i - (1 + extra) >= 0 && i + 1 + extra <= front.getSegmentCount()) {
                backSectionInvalid = back['getSection$int'](i - (1 + extra));
                frontSectionInvalid = front['getSection$int$int'](0, i + 1 + extra);
            }
            let splits : Array<AddressSection[]> = <any>([]);
            for(let m : number = 0; m <= frontSection.getSegmentCount(); m++) {
                let sub1 : AddressSection = frontSection['getSection$int$int'](0, m);
                let sub2 : AddressSection = frontSection['getSection$int$int'](m, frontSection.getSegmentCount());
                /* add */(splits.push([sub1, sub2, backSection])>0);
            };
            for(let m : number = 0; m <= backSection.getSegmentCount(); m++) {
                let sub1 : AddressSection = backSection['getSection$int$int'](0, m);
                let sub2 : AddressSection = backSection['getSection$int$int'](m, backSection.getSegmentCount());
                /* add */(splits.push([frontSection, sub1, sub2])>0);
            };
            let splitsJoined : Array<Address> = <any>([]);
            try {
                let mixed : Address;
                let mixed2 : Address;
                if(isMac) {
                    hostIdStr = this.createMACAddress$java_lang_String(/* toString */str.str);
                    mixed = hostIdStr.getAddress();
                    if(front.isPrefixed() && front.getPrefixLength() <= i * bitsPerSegment) {
                        mixed = mixed.setPrefixLength$int$boolean(front.getPrefixLength(), false);
                    } else if(back.isPrefixed()) {
                        mixed = mixed.setPrefixLength$int$boolean(Math.max(i * bitsPerSegment, back.getPrefixLength()), false);
                    }
                    let sec : MACAddressSection = (<MACAddressSection><any>frontSection).append(<MACAddressSection><any>backSection);
                    mixed2 = (<MACAddress>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_mac_MACAddressSection(sec);
                    if(frontSectionInvalid != null && backSectionInvalid != null) {
                        try {
                            (<MACAddressSection><any>frontSection).append(<MACAddressSection><any>backSectionInvalid);
                            this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSection + " with " + backSectionInvalid, front));
                        } catch(e) {
                        };
                        try {
                            (<MACAddressSection><any>frontSectionInvalid).append(<MACAddressSection><any>backSection);
                            this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSectionInvalid + " with " + backSection, front));
                        } catch(e) {
                        };
                    }
                    for(let o : number = 0; o < /* size */(<number>splits.length); o++) {
                        let split : AddressSection[] = /* get */splits[o];
                        let f : AddressSection = split[0];
                        let g : AddressSection = split[1];
                        let h : AddressSection = split[2];
                        sec = (<MACAddressSection><any>f).append(<MACAddressSection><any>h);
                        if(h.isPrefixed() && h.getPrefixLength() === 0 && !f.isPrefixed()) {
                            sec = sec.appendToPrefix(<MACAddressSection><any>g);
                        } else {
                            sec = sec.insert(f.getSegmentCount(), <MACAddressSection><any>g);
                        }
                        let mixed3 : MACAddress = (<MACAddress>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_mac_MACAddressSection(sec);
                        /* add */(splitsJoined.push(mixed3)>0);
                    };
                } else {
                    if(front.isPrefixed() && front.getPrefixLength() <= i * bitsPerSegment && i > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>front.getPrefixLength()); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'/'); return sb; })(str));
                    } else if(back.isPrefixed()) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>Math.max(i * bitsPerSegment, back.getPrefixLength())); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'/'); return sb; })(str));
                    }
                    hostIdStr = this.createAddress$java_lang_String(/* toString */str.str);
                    mixed = hostIdStr.getAddress();
                    if(isIpv4) {
                        let sec : IPv4AddressSection = (<IPv4AddressSection><any>frontSection).append(<IPv4AddressSection><any>backSection);
                        mixed2 = (<IPv4Address>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_ipv4_IPv4AddressSection(sec);
                        if(frontSectionInvalid != null && backSectionInvalid != null) {
                            try {
                                (<IPv4AddressSection><any>frontSection).append(<IPv4AddressSection><any>backSectionInvalid);
                                this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSection + " with " + backSectionInvalid, front));
                            } catch(e) {
                            };
                            try {
                                (<IPv4AddressSection><any>frontSectionInvalid).append(<IPv4AddressSection><any>backSection);
                                this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSectionInvalid + " with " + backSection, front));
                            } catch(e) {
                            };
                        }
                        for(let o : number = 0; o < /* size */(<number>splits.length); o++) {
                            let split : AddressSection[] = /* get */splits[o];
                            let f : AddressSection = split[0];
                            let g : AddressSection = split[1];
                            let h : AddressSection = split[2];
                            sec = (<IPv4AddressSection><any>f).append(<IPv4AddressSection><any>h);
                            if(h.isPrefixed() && h.getPrefixLength() === 0 && !f.isPrefixed()) {
                                sec = sec.appendToNetwork(<IPv4AddressSection><any>g);
                            } else {
                                sec = sec.insert(f.getSegmentCount(), <IPv4AddressSection><any>g);
                            }
                            let mixed3 : IPv4Address = (<IPv4Address>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_ipv4_IPv4AddressSection(sec);
                            /* add */(splitsJoined.push(mixed3)>0);
                        };
                    } else {
                        let sec : IPv6AddressSection = (<IPv6AddressSection><any>frontSection).append(<IPv6AddressSection><any>backSection);
                        mixed2 = (<IPv6Address>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(sec);
                        if(frontSectionInvalid != null && backSectionInvalid != null) {
                            try {
                                (<IPv6AddressSection><any>frontSection).append(<IPv6AddressSection><any>backSectionInvalid);
                                this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSection + " with " + backSectionInvalid, front));
                            } catch(e) {
                            };
                            try {
                                (<IPv6AddressSection><any>frontSectionInvalid).append(<IPv6AddressSection><any>backSection);
                                this.addFailure(new TestBase.Failure("invalid segment length should have failed in join of " + frontSectionInvalid + " with " + backSection, front));
                            } catch(e) {
                            };
                        }
                        for(let o : number = 0; o < /* size */(<number>splits.length); o++) {
                            let split : AddressSection[] = /* get */splits[o];
                            let f : AddressSection = split[0];
                            let g : AddressSection = split[1];
                            let h : AddressSection = split[2];
                            sec = (<IPv6AddressSection><any>f).append(<IPv6AddressSection><any>h);
                            if(h.isPrefixed() && h.getPrefixLength() === 0 && !f.isPrefixed()) {
                                sec = sec.appendToNetwork(<IPv6AddressSection><any>g);
                            } else {
                                sec = sec.insert(f.getSegmentCount(), <IPv6AddressSection><any>g);
                            }
                            let mixed3 : IPv6Address = (<IPv6Address>back).getNetwork().getAddressCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(sec);
                            /* add */(splitsJoined.push(mixed3)>0);
                        };
                    }
                }
                if(!mixed.equals(mixed2)) {
                    this.addFailure(new TestBase.Failure("mixed was " + mixed + " expected was " + mixed2, mixed));
                }
                if(!Objects.equals(expectedPref[i], mixed.getPrefixLength())) {
                    this.addFailure(new TestBase.Failure("mixed prefix was " + mixed.getPrefixLength() + " expected was " + expectedPref[i], mixed));
                }
                if(!Objects.equals(expectedPref[i], mixed2.getPrefixLength())) {
                    this.addFailure(new TestBase.Failure("mixed2 prefix was " + mixed2.getPrefixLength() + " expected was " + expectedPref[i], mixed2));
                }
                for(let o : number = 0; o < /* size */(<number>splitsJoined.length); o++) {
                    let mixed3 : Address = /* get */splitsJoined[o];
                    if(!mixed.equals(mixed3)) {
                        this.addFailure(new TestBase.Failure("mixed was " + mixed3 + " expected was " + mixed, mixed3));
                    }
                    if(!mixed3.equals(mixed2)) {
                        this.addFailure(new TestBase.Failure("mixed was " + mixed3 + " expected was " + mixed2, mixed3));
                    }
                    if(!Objects.equals(expectedPref[i], mixed3.getPrefixLength())) {
                        this.addFailure(new TestBase.Failure("mixed3 prefix was " + mixed3.getPrefixLength() + " expected was " + expectedPref[i], mixed3));
                    }
                };
            } catch(__e) {
                if(__e != null && __e instanceof <any>IncompatibleAddressException) {
                    let e : IncompatibleAddressException = <IncompatibleAddressException>__e;
                    if(expectedPref[i] == null || expectedPref[i] >= 0) {
                        this.addFailure(new TestBase.Failure("expected prefix " + expectedPref[i] + ", but append failed due to prefix for " + frontSection + " and " + backSection, hostIdStr));
                    }

                }
                if(__e != null && (__e["__classes"] && __e["__classes"].indexOf("java.lang.IllegalArgumentException") >= 0)) {
                    let e : Error = <Error>__e;
                    if(expectedPref[i] == null || expectedPref[i] >= 0) {
                        this.addFailure(new TestBase.Failure("expected prefix " + expectedPref[i] + ", but append failed due to prefix for " + frontSection + " and " + backSection, hostIdStr));
                    }

                }
            };
        };
        this.incrementTestCount();
    }

    testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(orig : Address, increment : number, expectedResult : Address) {
        this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address$boolean(orig, increment, expectedResult, true);
    }

    public testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address$boolean(orig : Address, increment : number, expectedResult : Address, first : boolean) {
        try {
            let result : Address = orig.increment(increment);
            if(expectedResult == null) {
                this.addFailure(new TestBase.Failure("increment mismatch result " + result + " vs none expected", orig));
            } else {
                if(!result.equals(expectedResult)) {
                    this.addFailure(new TestBase.Failure("increment mismatch result " + result + " vs expected " + expectedResult, orig));
                }
                if(first && !orig.isMultiple() && increment > Number.MIN_VALUE) {
                    this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address$boolean(expectedResult, -increment, orig, false);
                }
            }
        } catch(e) {
            if(expectedResult != null) {
                this.addFailure(new TestBase.Failure("increment mismatch exception " + e + ", expected " + expectedResult, orig));
            }
        };
        this.incrementTestCount();
    }

    public testIncrement(orig? : any, increment? : any, expectedResult? : any, first? : any) : any {
        if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && ((typeof first === 'boolean') || first === null)) {
            return <any>this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address$boolean(orig, increment, expectedResult, first);
        } else if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && first === undefined) {
            return <any>this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(orig, increment, expectedResult);
        } else throw new Error('invalid overload');
    }
}
TestBase["__class"] = "inet.ipaddr.test.TestBase";


export namespace TestBase {

    export class Failure {
        addr : HostIdentifierString;

        addrValue : Address;

        series : AddressSegmentSeries;

        str : string;

        stack : java.lang.StackTraceElement[];

        testClass : any;

        public constructor(str? : any, addr? : any) {
            if(((typeof str === 'string') || str === null) && ((addr != null && (addr["__interfaces"] != null && addr["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || addr.constructor != null && addr.constructor["__interfaces"] != null && addr.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || addr === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.str = str;
                    this.series = addr;
                })();
            } else if(((typeof str === 'string') || str === null) && ((addr != null && (addr["__interfaces"] != null && addr["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || addr.constructor != null && addr.constructor["__interfaces"] != null && addr.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || addr === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.str = str;
                    this.addr = addr;
                })();
            } else if(((typeof str === 'string') || str === null) && ((addr != null && addr instanceof <any>Address) || addr === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.str = str;
                    this.addrValue = addr;
                })();
            } else if(((typeof str === 'boolean') || str === null) && ((addr != null && (addr["__interfaces"] != null && addr["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || addr.constructor != null && addr.constructor["__interfaces"] != null && addr.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || addr === null)) {
                let __args = Array.prototype.slice.call(arguments);
                let pass : any = __args[0];
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.addr = addr;
                })();
            } else if(((typeof str === 'boolean') || str === null) && ((addr != null && addr instanceof <any>Address) || addr === null)) {
                let __args = Array.prototype.slice.call(arguments);
                let pass : any = __args[0];
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.addrValue = addr;
                })();
            } else if(((typeof str === 'string') || str === null) && addr === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                if(this.addr===undefined) this.addr = null;
                if(this.addrValue===undefined) this.addrValue = null;
                if(this.series===undefined) this.series = null;
                if(this.str===undefined) this.str = null;
                if(this.stack===undefined) this.stack = null;
                if(this.testClass===undefined) this.testClass = null;
                (() => {
                    this.str = str;
                })();
            } else throw new Error('invalid overload');
        }

        getObjectDescriptor() : string {
            if(this.addr != null) {
                return this.addr.toString();
            }
            if(this.addrValue != null) {
                return this.addrValue.toString();
            }
            if(this.series != null) {
                return this.series.toString();
            }
            return "<unknown>";
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            if(this.str == null) {
                return this.getObjectDescriptor();
            }
            return this.str + " " + this.getObjectDescriptor();
        }
    }
    Failure["__class"] = "inet.ipaddr.test.TestBase.Failure";


    export class Failures {
        failures : Array<TestBase.Failure> = <any>([]);

        numTested : number;

        addFailure(failure : TestBase.Failure, testClass : any) {
            /* add */(this.failures.push(failure)>0);
            failure.stack = Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object'] }).getStackTrace();
            failure.testClass = testClass;
        }

        incrementTestCount() {
            this.numTested++;
        }

        add(fails : TestBase.Failures) {
            this.numTested += fails.numTested;
            /* addAll */((l1, l2) => l1.push.apply(l1, l2))(this.failures, fails.failures);
        }

        report() {
            let failurestr : string = "";
            let failurestrCount : number = 0;
            for(let index173=0; index173 < this.failures.length; index173++) {
                let f = this.failures[index173];
                {
                    let addrStrng : string = f.getObjectDescriptor();
                    failurestr += ' ';
                    if(f.str != null && f.str.length > 0) {
                        failurestr += f.str;
                        failurestr += ", ";
                    }
                    failurestr += addrStrng;
                    failurestrCount++;
                }
            }
            let numFailed : number = /* size */(<number>this.failures.length);
            TestBase.showMessage("test count: " + this.numTested);
            TestBase.showMessage("fail count: " + numFailed);
            if(failurestrCount > 0) {
                TestBase.showMessage("Failed:\n" + failurestr);
            }
        }

        constructor() {
            if(this.numTested===undefined) this.numTested = 0;
        }
    }
    Failures["__class"] = "inet.ipaddr.test.TestBase.Failures";


    export class Perf {
        runTimes : Array<number> = <any>([]);

        addTime(time : number) {
            /* add */(this.runTimes.push(time)>0);
        }

        report() {
            if(/* isEmpty */(this.runTimes.length == 0)) {
                return;
            }
            let str : string = "";
            let count : number = 0;
            for(let index174=0; index174 < this.runTimes.length; index174++) {
                let time = this.runTimes[index174];
                {
                    str += "" + ++count + ". " + ((n => n<0?Math.ceil(n):Math.floor(n))(time / 1000000)) + " milliseconds" + java.lang.System.lineSeparator();
                }
            }
            TestBase.showMessage("times:" + java.lang.System.lineSeparator() + str);
        }

        constructor() {
        }
    }
    Perf["__class"] = "inet.ipaddr.test.TestBase.Perf";


    export abstract class LookupKey<T extends java.lang.Comparable<T>> {
        static serialVersionUID : number = 4;

        keyString : string;

        options : T;

        public constructor(x? : any, opts? : any) {
            if(((typeof x === 'string') || x === null) && ((opts != null) || opts === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.keyString===undefined) this.keyString = null;
                if(this.options===undefined) this.options = null;
                if(this.keyString===undefined) this.keyString = null;
                if(this.options===undefined) this.options = null;
                (() => {
                    if(x == null) {
                        x = "";
                    }
                    this.keyString = x;
                    this.options = opts;
                })();
            } else if(((typeof x === 'string') || x === null) && opts === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let opts : any = null;
                    if(this.keyString===undefined) this.keyString = null;
                    if(this.options===undefined) this.options = null;
                    if(this.keyString===undefined) this.keyString = null;
                    if(this.options===undefined) this.options = null;
                    (() => {
                        if(x == null) {
                            x = "";
                        }
                        this.keyString = x;
                        this.options = opts;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {MACAddressStringParameters} otherOptions
         * @return {number}
         */
        public compareOptions(otherOptions? : any) : any {
            if(((otherOptions != null) || otherOptions === null)) {
                return <any>this.compareOptions$java_lang_Comparable(otherOptions);
            } else throw new Error('invalid overload');
        }

        compareOptions$java_lang_Comparable(otherOptions : T) : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

        /**
         * 
         * @param {TestBase.LookupKey} o
         * @return {number}
         */
        public compareTo(o : TestBase.LookupKey<T>) : number {
            let comparison : number = /* compareTo */this.keyString.localeCompare(o.keyString);
            if(comparison === 0) {
                comparison = this.compareOptions(o.options);
            }
            return comparison;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>TestBase.LookupKey) {
                let other : TestBase.LookupKey<any> = <TestBase.LookupKey<any>>o;
                return /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.keyString,other.keyString)) && Objects.equals(this.options, other.options);
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.keyString));
            if(this.options != null) {
                hash *= /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.options));
            }
            return hash;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            return this.keyString;
        }
    }
    LookupKey["__class"] = "inet.ipaddr.test.TestBase.LookupKey";
    LookupKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export namespace LookupKey {

        export class LookupKeyComparator<T extends java.lang.Comparable<T>> {
            /**
             * 
             * @param {*} o1
             * @param {*} o2
             * @return {number}
             */
            public compare(o1 : T, o2 : T) : number {
                return o1 == null?-1:(o2 == null?1:o1.compareTo(o2));
            }

            constructor() {
            }
        }
        LookupKeyComparator["__class"] = "inet.ipaddr.test.TestBase.LookupKey.LookupKeyComparator";
        LookupKeyComparator["__interfaces"] = ["java.util.Comparator"];


    }


    export class IPAddressKey {
        static serialVersionUID : number = 4;

        bytes : number[];

        constructor(bytes : number[]) {
            if(this.bytes===undefined) this.bytes = null;
            this.bytes = bytes;
        }

        static getIPv4Addr(addr : number[]) : number {
            return addr[3] & 255 | ((addr[2] << 8) & 65280) | ((addr[1] << 16) & 16711680) | ((addr[0] << 24) & -16777216);
        }

        /**
         * 
         * @param {TestBase.IPAddressKey} o
         * @return {number}
         */
        public compareTo(o : TestBase.IPAddressKey) : number {
            let comparison : number = this.bytes.length - o.bytes.length;
            if(comparison === 0) {
                if(this.bytes.length <= 4) {
                    comparison = IPAddressKey.getIPv4Addr(this.bytes) - IPAddressKey.getIPv4Addr(o.bytes);
                } else {
                    for(let i : number = 0; i < this.bytes.length; i++) {
                        comparison = this.bytes[i] = o.bytes[i];
                        if(comparison !== 0) {
                            break;
                        }
                    };
                }
            }
            return comparison;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>TestBase.IPAddressKey) {
                return /* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(this.bytes, (<TestBase.IPAddressKey>o).bytes);
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(Arrays));
        }
    }
    IPAddressKey["__class"] = "inet.ipaddr.test.TestBase.IPAddressKey";
    IPAddressKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class ExpectedPrefixes {
        next : number;

        previous : number;

        adjusted : number;

        set : number;

        applied : number;

        constructor(isMac : boolean, original : number, bitLength : number, segmentBitLength : number, set : number, adjustment : number) {
            if(this.next===undefined) this.next = null;
            if(this.previous===undefined) this.previous = null;
            if(this.adjusted===undefined) this.adjusted = null;
            if(this.set===undefined) this.set = null;
            if(this.applied===undefined) this.applied = null;
            if(original == null) {
                this.next = null;
                this.previous = isMac?bitLength - segmentBitLength:bitLength;
                this.adjusted = adjustment > 0?null:bitLength + adjustment;
                this.applied = this.set = set;
            } else {
                this.next = original === bitLength?null:Math.min(bitLength, (((original + segmentBitLength) / segmentBitLength|0)) * segmentBitLength);
                this.previous = Math.max(0, (((original - 1) / segmentBitLength|0)) * segmentBitLength);
                let adj : number = Math.max(0, original + adjustment);
                this.adjusted = adj > bitLength?null:adj;
                this.set = set;
                this.applied = Math.min(original, set);
            }
        }

        compare(next : number, previous : number, adjusted : number, set : number, applied : number) : boolean {
            return Objects.equals(next, this.next) && Objects.equals(previous, this.previous) && Objects.equals(adjusted, this.adjusted) && Objects.equals(set, this.set) && Objects.equals(applied, this.applied);
        }

        public print$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer(next : number, previous : number, adjusted : number, set : number, applied : number) : string {
            return this.print$java_lang_Integer$java_lang_Integer$java_lang_String(next, this.next, "next") + "\n" + this.print$java_lang_Integer$java_lang_Integer$java_lang_String(previous, this.previous, "previous") + "\n" + this.print$java_lang_Integer$java_lang_Integer$java_lang_String(adjusted, this.adjusted, "adjusted") + "\n" + this.print$java_lang_Integer$java_lang_Integer$java_lang_String(set, this.set, "set") + "\n" + this.print$java_lang_Integer$java_lang_Integer$java_lang_String(applied, this.applied, "applied");
        }

        public print(next? : any, previous? : any, adjusted? : any, set? : any, applied? : any) : any {
            if(((typeof next === 'number') || next === null) && ((typeof previous === 'number') || previous === null) && ((typeof adjusted === 'number') || adjusted === null) && ((typeof set === 'number') || set === null) && ((typeof applied === 'number') || applied === null)) {
                return <any>this.print$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_lang_Integer(next, previous, adjusted, set, applied);
            } else if(((typeof next === 'number') || next === null) && ((typeof previous === 'number') || previous === null) && ((typeof adjusted === 'string') || adjusted === null) && set === undefined && applied === undefined) {
                return <any>this.print$java_lang_Integer$java_lang_Integer$java_lang_String(next, previous, adjusted);
            } else throw new Error('invalid overload');
        }

        print$java_lang_Integer$java_lang_Integer$java_lang_String(result : number, expected : number, label : string) : string {
            return "expected " + label + ": " + expected + " result: " + result;
        }
    }
    ExpectedPrefixes["__class"] = "inet.ipaddr.test.TestBase.ExpectedPrefixes";


    export class IPAddressStringKey extends TestBase.LookupKey<IPAddressStringParameters> {
        static __inet_ipaddr_test_TestBase_IPAddressStringKey_serialVersionUID : number = 4;

        static comparator : any; public static comparator_$LI$() : any { if(IPAddressStringKey.comparator == null) IPAddressStringKey.comparator = (arg0, arg1) => { return new LookupKey.LookupKeyComparator<IPAddressStringParameters>().compare(arg0, arg1); }; return IPAddressStringKey.comparator; };

        public constructor(x : string, opts : IPAddressStringParameters = null) {
            super(x, opts);
        }

        public compareOptions$inet_ipaddr_IPAddressStringParameters(otherOptions : IPAddressStringParameters) : number {
            return Objects.compare<any>(this.options, otherOptions, <any>(IPAddressStringKey.comparator_$LI$()));
        }

        /**
         * 
         * @param {IPAddressStringParameters} otherOptions
         * @return {number}
         */
        public compareOptions(otherOptions? : any) : any {
            if(((otherOptions != null && otherOptions instanceof <any>IPAddressStringParameters) || otherOptions === null)) {
                return <any>this.compareOptions$inet_ipaddr_IPAddressStringParameters(otherOptions);
            } else if(((otherOptions != null) || otherOptions === null)) {
                return <any>this.compareOptions$java_lang_Comparable(otherOptions);
            } else throw new Error('invalid overload');
        }
    }
    IPAddressStringKey["__class"] = "inet.ipaddr.test.TestBase.IPAddressStringKey";
    IPAddressStringKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class HostKey extends TestBase.LookupKey<HostNameParameters> {
        static __inet_ipaddr_test_TestBase_HostKey_serialVersionUID : number = 4;

        static comparator : any; public static comparator_$LI$() : any { if(HostKey.comparator == null) HostKey.comparator = (arg0, arg1) => { return new LookupKey.LookupKeyComparator<HostNameParameters>().compare(arg0, arg1); }; return HostKey.comparator; };

        public constructor(x : string, opts : HostNameParameters = null) {
            super(x, opts);
        }

        public compareOptions$inet_ipaddr_HostNameParameters(otherOptions : HostNameParameters) : number {
            return Objects.compare<any>(this.options, otherOptions, <any>(HostKey.comparator_$LI$()));
        }

        /**
         * 
         * @param {HostNameParameters} otherOptions
         * @return {number}
         */
        public compareOptions(otherOptions? : any) : any {
            if(((otherOptions != null && otherOptions instanceof <any>HostNameParameters) || otherOptions === null)) {
                return <any>this.compareOptions$inet_ipaddr_HostNameParameters(otherOptions);
            } else if(((otherOptions != null) || otherOptions === null)) {
                return <any>this.compareOptions$java_lang_Comparable(otherOptions);
            } else throw new Error('invalid overload');
        }
    }
    HostKey["__class"] = "inet.ipaddr.test.TestBase.HostKey";
    HostKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class TestBase$0 implements Address.AddressProvider {
        public __parent: any;
        /**
         * 
         * @return {number}
         */
        public getSegmentCount() : number {
            return this.firstAddr.isIPv6()?IPv6Address.SEGMENT_COUNT:IPv4Address.SEGMENT_COUNT;
        }

        /**
         * 
         * @return {*}
         */
        public getValues() : Address.SegmentValueProvider {
            return IPAddressNetwork.IPAddressStringGenerator.getValueProvider(this.firstAddr.getBytes());
        }

        /**
         * 
         * @return {*}
         */
        public getUpperValues() : Address.SegmentValueProvider {
            return IPAddressNetwork.IPAddressStringGenerator.getValueProvider(this.firstAddr.getUpperBytes());
        }

        /**
         * 
         * @return {number}
         */
        public getPrefixLength() : number {
            return this.firstAddr.getPrefixLength();
        }

        /**
         * 
         * @return {string}
         */
        public getZone() : string {
            return this.firstAddr.isIPv6()?this.firstAddr.toIPv6().getZone():null;
        }

        constructor(__parent: any, private firstAddr: any) {
            this.__parent = __parent;
        }
    }
    TestBase$0["__interfaces"] = ["inet.ipaddr.Address.AddressProvider"];


}


export interface AddressCreator {
    createHost(x? : any, options? : any) : any;

    createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any;

    createMACAddress(x? : any, opts? : any) : any;
}



TestBase.HostKey.comparator_$LI$();

TestBase.IPAddressStringKey.comparator_$LI$();

TestBase.DEFAULT_BASIC_VALIDATION_OPTIONS_$LI$();

TestBase.HOST_INET_ATON_OPTIONS_$LI$();

TestBase.INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$();

TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$();

TestBase.MAC_ADDRESS_OPTIONS_$LI$();

TestBase.ADDRESS_OPTIONS_$LI$();

TestBase.HOST_OPTIONS_$LI$();
