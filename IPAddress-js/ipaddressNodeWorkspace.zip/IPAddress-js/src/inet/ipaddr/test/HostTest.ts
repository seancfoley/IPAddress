/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostName } from '../HostName';
import { HostNameException } from '../HostNameException';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { Validator } from '../format/validate/Validator';
import { IPv6Address } from '../ipv6/IPv6Address';
import { TestBase } from './TestBase';
import { AddressCreator } from './AddressCreator';
import { IPv4Address } from '../ipv4/IPv4Address';
import { AddressNetwork } from '../AddressNetwork';

export class HostTest extends TestBase {
    constructor(creator : AddressCreator) {
        super(creator);
    }

    testResolved_inet_aton(original : string, expectedResolved : string) {
        let origAddress : HostName = this.createHost_inet_aton(original);
        this.testResolved$inet_ipaddr_HostName$java_lang_String$java_lang_String(origAddress, original, expectedResolved);
    }

    testResolved$java_lang_String$java_lang_String(original : string, expectedResolved : string) {
        let origAddress : HostName = this.createHost_inet_aton(original);
        this.testResolved$inet_ipaddr_HostName$java_lang_String$java_lang_String(origAddress, original, expectedResolved);
    }

    public testResolved$inet_ipaddr_HostName$java_lang_String$java_lang_String(original : HostName, originalStr : string, expectedResolved : string) {
        try {
            let resolvedAddress : IPAddress = original.getAddress();
            let result : boolean;
            if(resolvedAddress == null && original.isAllAddresses() && expectedResolved != null) {
                let exp : IPAddressString = this.createAddress$java_lang_String(expectedResolved);
                result = original.asAddressString().equals(exp);
            } else {
                result = (resolvedAddress == null)?(expectedResolved == null):resolvedAddress.equals(this.createAddress$java_lang_String(expectedResolved).getAddress());
            }
            if(!result) {
                this.addFailure(new TestBase.Failure("resolved was " + resolvedAddress + " original was " + originalStr, original));
            } else if(resolvedAddress != null && !(resolvedAddress.isIPv6() && (<IPv6Address>resolvedAddress).hasZone())) {
                let host : HostName = resolvedAddress.toHostName();
                if(!original.equals(host)) {
                    this.addFailure(new TestBase.Failure("reverse was " + host + " original was " + original, original));
                } else if(!original.isAddress()) {
                }
            }
        } catch(__e) {
            if(__e != null && __e instanceof <any>IncompatibleAddressException) {
                let e : IncompatibleAddressException = <IncompatibleAddressException>__e;
                this.addFailure(new TestBase.Failure(e.toString(), original));

            }
            if(__e != null && (__e["__classes"] && __e["__classes"].indexOf("java.lang.RuntimeException") >= 0) || __e != null && __e instanceof <any>Error) {
                let e : Error = <Error>__e;
                this.addFailure(new TestBase.Failure(e.toString(), original));

            }
        };
        this.incrementTestCount();
    }

    public testResolved(original? : any, originalStr? : any, expectedResolved? : any) : any {
        if(((original != null && original instanceof <any>HostName) || original === null) && ((typeof originalStr === 'string') || originalStr === null) && ((typeof expectedResolved === 'string') || expectedResolved === null)) {
            return <any>this.testResolved$inet_ipaddr_HostName$java_lang_String$java_lang_String(original, originalStr, expectedResolved);
        } else if(((typeof original === 'string') || original === null) && ((typeof originalStr === 'string') || originalStr === null) && expectedResolved === undefined) {
            return <any>this.testResolved$java_lang_String$java_lang_String(original, originalStr);
        } else throw new Error('invalid overload');
    }

    testNormalizedHost(expectMatch : boolean, original : string, expected : string) {
        let w : HostName = this.createHost$java_lang_String(original);
        let normalized : string = w.toNormalizedString();
        if(!(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected)) === expectMatch)) {
            this.addFailure(new TestBase.Failure("normalization was " + normalized, w));
        }
        this.incrementTestCount();
    }

    testCanonical(original : string, expected : string) {
        let w : HostName = this.createHost$java_lang_String(original);
        let canonical : string = w.asAddress().toCanonicalString();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(canonical,expected))) {
            this.addFailure(new TestBase.Failure("canonicalization was " + canonical, w));
        }
        this.incrementTestCount();
    }

    hostTest_inet_aton(pass : boolean, x : string) {
        let addr : HostName = this.createHost_inet_aton(x);
        this.hostTestDouble(pass, addr, false);
    }

    public hostTest$boolean$java_lang_String(pass : boolean, x : string) {
        let addr : HostName = this.createHost$java_lang_String(x);
        this.hostTestDouble(pass, addr, true);
    }

    public hostTest(pass? : any, x? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null)) {
            return <any>this.hostTest$boolean$java_lang_String(pass, x);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>HostName) || x === null)) {
            return <any>this.hostTest$boolean$inet_ipaddr_HostName(pass, x);
        } else throw new Error('invalid overload');
    }

    static i : number = 0;

    hostTestDouble(pass : boolean, addr : HostName, doubleTest : boolean) {
        this.hostTest$boolean$inet_ipaddr_HostName(pass, addr);
        this.hostTest$boolean$inet_ipaddr_HostName(pass, addr);
        if(pass && doubleTest) {
            try {
                let two : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(addr.toString(), addr.getValidationOptions());
                let twoString : string;
                let oneString : string;
                if(HostTest.i++ % 2 === 0) {
                    two.getNormalizedLabels();
                    twoString = two.getHost();
                    oneString = addr.getHost();
                } else {
                    oneString = addr.getHost();
                    two.getNormalizedLabels();
                    twoString = two.getHost();
                }
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(oneString,twoString))) {
                    this.addFailure(new TestBase.Failure(oneString + ' ' + twoString, addr));
                }
            } catch(e) {
                this.addFailure(new TestBase.Failure(e.message, addr));
            };
            this.incrementTestCount();
        }
    }

    hostTest$boolean$inet_ipaddr_HostName(pass : boolean, addr : HostName) {
        if(this.isNotExpected(pass, addr)) {
            this.addFailure(new TestBase.Failure(pass, addr));
            this.isNotExpected(pass, addr);
        }
        this.incrementTestCount();
    }

    isNotExpected(expectedPass : boolean, addr : HostName) : boolean {
        try {
            addr.validate();
            return !expectedPass;
        } catch(e) {
            return expectedPass;
        };
    }

    testURL(url : string) {
        let w : HostName = this.createHost$java_lang_String(url);
        try {
            w.validate();
            this.addFailure(new TestBase.Failure("failed: " + "URL " + url, w));
        } catch(e) {
            e.message;
        };
        this.incrementTestCount();
    }

    testSelf(host : string, isSelf : boolean) {
        let w : HostName = this.createHost$java_lang_String(host);
        if(isSelf !== w.isSelf()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + isSelf, w));
        }
        this.incrementTestCount();
    }

    static conversionMatches(host1 : HostName, host2 : HostName) : boolean {
        let h1 : IPAddress = host1.asAddress();
        if(h1 != null && h1.isIPv4()) {
            let h2 : IPAddress = host2.asAddress();
            if(!h2.isIPv4()) {
                if(h2.isIPv4Convertible()) {
                    return h1.equals(h2.toIPv4());
                }
            }
        } else if(h1 != null && h1.isIPv6()) {
            let h2 : IPAddress = host2.asAddress();
            if(!h2.isIPv6()) {
                if(h2.isIPv6Convertible()) {
                    return h1.equals(h2.toIPv6());
                }
            }
        }
        return false;
    }

    testMatches$boolean$java_lang_String$java_lang_String(matches : boolean, host1 : string, host2 : string) {
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(matches, host1, host2, TestBase.HOST_OPTIONS_$LI$());
    }

    public testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(matches : boolean, host1 : string, host2 : string, options : HostNameParameters) {
        let h1 : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(host1, options);
        let h2 : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(host2, options);
        if(matches !== h1.matches(h2) && matches !== HostTest.conversionMatches(h1, h2)) {
            this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + host2, h1));
        } else {
            if(matches !== h2.matches(h1) && matches !== HostTest.conversionMatches(h2, h1)) {
                this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + host1, h2));
            } else {
                if(matches !== h1.equals(h2) && matches !== HostTest.conversionMatches(h1, h2)) {
                    this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h1, h2));
                } else {
                    this.testNormalizedMatches(h1);
                    this.testNormalizedMatches(h2);
                }
            }
        }
        this.incrementTestCount();
    }

    public testMatches(matches? : any, host1? : any, host2? : any, options? : any) : any {
        if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(matches, host1, host2, options);
        } else if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && options === undefined) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String(matches, host1, host2);
        } else throw new Error('invalid overload');
    }

    /*private*/ static translateReserved(addr : IPv6Address, str : string) : any {
        if(!addr.hasZone()) {
            return str;
        }
        let index : number = str.indexOf(IPv6Address.ZONE_SEPARATOR);
        let translated : { str: string } = { str: "", toString: function() { return this.str; } };
        /* append */(sb => { sb.str = sb.str.concat((<any>str).substr(0, index)); return sb; })(translated);
        /* append */(sb => { sb.str = sb.str.concat(<any>"%25"); return sb; })(translated);
        for(let i : number = index + 1; i < str.length; i++) {
            let c : string = str.charAt(i);
            if(Validator.isReserved(c)) {
                /* append */(sb => { sb.str = sb.str.concat(<any>javaemul.internal.IntegerHelper.toHexString(c)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'%'); return sb; })(translated));
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(translated);
            }
        };
        return translated;
    }

    /*private*/ testNormalizedMatches(h1 : HostName) {
        let normalized : string;
        if(h1.isAddress() && h1.asAddress().isPrefixed() && h1.asAddress().isIPv6()) {
            let addr : IPv6Address = h1.asAddress().getLower().removePrefixLength$boolean(false).toIPv6();
            normalized = '[' + HostTest.translateReserved(addr, addr.toNormalizedString()).toString() + "]/" + h1.asAddress().getNetworkPrefixLength();
        } else if(h1.isAddress() && h1.asAddress().isIPv6()) {
            let addr : IPv6Address = h1.asAddress().toIPv6();
            normalized = '[' + HostTest.translateReserved(addr, addr.toNormalizedWildcardString()).toString() + "]";
        } else {
            normalized = h1.toNormalizedString();
        }
        let h1Bracketed : string = h1.toNormalizedString();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(h1Bracketed,normalized))) {
            this.addFailure(new TestBase.Failure("failed: bracketed is " + normalized, h1));
        }
        this.incrementTestCount();
    }

    testHostAddressWithService(host : string, hostExpected : string, serviceExpected : string, expectedZone : string) {
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, hostExpected, null, serviceExpected, expectedZone, null);
    }

    testHostWithService(host : string, hostExpected : string, serviceExpected : string, expectedZone : string) {
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, null, null, serviceExpected, expectedZone, null);
    }

    testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host : string, hostExpected : string, portExpected : number, expectedZone : string) {
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host, hostExpected, hostExpected, portExpected, expectedZone);
    }

    testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer(host : string, hostExpected : string, portExpected : number, expectedZone : string, prefixLength : number) {
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer(host, hostExpected, hostExpected, portExpected, expectedZone, prefixLength);
    }

    testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host : string, hostExpected : string, portExpected : number, expectedZone : string) {
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, null, portExpected, null, expectedZone, null);
    }

    testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host : string, hostExpected : string, addrExpected : string, portExpected : number, expectedZone : string) {
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, null, expectedZone, null);
    }

    public testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer(host : string, hostExpected : string, addrExpected : string, portExpected : number, expectedZone : string, prefixLengthExpected : number) {
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, null, expectedZone, prefixLengthExpected);
    }

    public testHostAddress(host? : any, hostExpected? : any, addrExpected? : any, portExpected? : any, expectedZone? : any, prefixLengthExpected? : any) : any {
        if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'string') || addrExpected === null) && ((typeof portExpected === 'number') || portExpected === null) && ((typeof expectedZone === 'string') || expectedZone === null) && ((typeof prefixLengthExpected === 'number') || prefixLengthExpected === null)) {
            return <any>this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, expectedZone, prefixLengthExpected);
        } else if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'number') || addrExpected === null) && ((typeof portExpected === 'string') || portExpected === null) && ((typeof expectedZone === 'number') || expectedZone === null) && prefixLengthExpected === undefined) {
            return <any>this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, expectedZone);
        } else if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'string') || addrExpected === null) && ((typeof portExpected === 'number') || portExpected === null) && ((typeof expectedZone === 'string') || expectedZone === null) && prefixLengthExpected === undefined) {
            return <any>this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host, hostExpected, addrExpected, portExpected, expectedZone);
        } else if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'number') || addrExpected === null) && ((typeof portExpected === 'string') || portExpected === null) && expectedZone === undefined && prefixLengthExpected === undefined) {
            return <any>this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host, hostExpected, addrExpected, portExpected);
        } else if(((typeof host === 'string') || host === null) && hostExpected === undefined && addrExpected === undefined && portExpected === undefined && expectedZone === undefined && prefixLengthExpected === undefined) {
            return <any>this.testHostAddress$java_lang_String(host);
        } else throw new Error('invalid overload');
    }

    public testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host : string, hostExpected : string, addrExpected : string, portExpected : number, serviceExpected : string, expectedZone : string, prefixLengthExpected : number) {
        let hostName : HostName = this.createHost$java_lang_String(host);
        this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(hostName, hostExpected, addrExpected, portExpected, serviceExpected, expectedZone, prefixLengthExpected);
    }

    public testHost(host? : any, hostExpected? : any, addrExpected? : any, portExpected? : any, serviceExpected? : any, expectedZone? : any, prefixLengthExpected? : any) : any {
        if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'string') || addrExpected === null) && ((typeof portExpected === 'number') || portExpected === null) && ((typeof serviceExpected === 'string') || serviceExpected === null) && ((typeof expectedZone === 'string') || expectedZone === null) && ((typeof prefixLengthExpected === 'number') || prefixLengthExpected === null)) {
            return <any>this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, serviceExpected, expectedZone, prefixLengthExpected);
        } else if(((host != null && host instanceof <any>HostName) || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'string') || addrExpected === null) && ((typeof portExpected === 'number') || portExpected === null) && ((typeof serviceExpected === 'string') || serviceExpected === null) && ((typeof expectedZone === 'string') || expectedZone === null) && ((typeof prefixLengthExpected === 'number') || prefixLengthExpected === null)) {
            return <any>this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(host, hostExpected, addrExpected, portExpected, serviceExpected, expectedZone, prefixLengthExpected);
        } else if(((host != null && host instanceof <any>HostName) || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'string') || addrExpected === null) && ((typeof portExpected === 'number') || portExpected === null) && ((typeof serviceExpected === 'string') || serviceExpected === null) && ((typeof expectedZone === 'string') || expectedZone === null) && prefixLengthExpected === undefined) {
            return <any>this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(host, hostExpected, addrExpected, portExpected, serviceExpected, expectedZone);
        } else if(((typeof host === 'string') || host === null) && ((typeof hostExpected === 'string') || hostExpected === null) && ((typeof addrExpected === 'number') || addrExpected === null) && ((typeof portExpected === 'string') || portExpected === null) && serviceExpected === undefined && expectedZone === undefined && prefixLengthExpected === undefined) {
            return <any>this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(host, hostExpected, addrExpected, portExpected);
        } else throw new Error('invalid overload');
    }

    testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(hostName : HostName, hostExpected : string, addrExpected : string, portExpected : number, serviceExpected : string, expectedZone : string) {
        this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(hostName, hostExpected, addrExpected, portExpected, serviceExpected, expectedZone, null);
    }

    testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer(hostName : HostName, hostExpected : string, addrExpected : string, portExpected : number, serviceExpected : string, expectedZone : string, prefixLengthExpected : number) {
        try {
            let h : string = hostName.getHost();
            let addressExpected : IPAddress = addrExpected == null?null:this.createAddress$java_lang_String(addrExpected).getAddress();
            let addrHost : IPAddress = hostName.asAddress();
            let port : number = hostName.getPort();
            let zone : string = null;
            if(addrHost != null && addrHost.isIPv6()) {
                zone = addrHost.toIPv6().getZone();
            }
            let prefLength : number = hostName.getNetworkPrefixLength();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(h,hostExpected))) {
                this.addFailure(new TestBase.Failure("failed: host is " + h, hostName));
            } else if(!Objects.equals(port, portExpected)) {
                this.addFailure(new TestBase.Failure("failed: port is " + port, hostName));
            } else if(!Objects.equals(zone, expectedZone)) {
                this.addFailure(new TestBase.Failure("failed:  zone is " + zone, hostName));
            } else if(!Objects.equals(addrHost, addressExpected)) {
                this.addFailure(new TestBase.Failure("failed: address is " + addrHost, hostName));
            } else if(!Objects.equals(prefLength, prefixLengthExpected)) {
                this.addFailure(new TestBase.Failure("failed: prefix is " + prefLength, hostName));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure(e.message, hostName));
        };
        this.incrementTestCount();
    }

    isLenient() : boolean {
        return false;
    }

    public static runDNS : boolean = true;

    /**
     * 
     */
    runTest() {
        this.testSelf("1.2.3.4", false);
        this.testSelf("1::", false);
        this.testSelf("[1::]", false);
        this.testSelf("bla.com", false);
        this.testSelf("::1", true);
        this.testSelf("[::1]", true);
        this.testSelf("localhost", true);
        this.testSelf("127.0.0.1", true);
        this.testSelf("[127.0.0.1]", true);
        this.testSelf("[localhost]", false);
        this.testSelf("-ab-.com", false);
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "a.com", "A.cOm");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "a.comx", "a.com");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "2::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::", "1:0::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "f::", "F:0::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::", "[1:0::]");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1::]", "1:0::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "1:0:1::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "001.2.3.04");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "::ffff:1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%a", "1:2:3:4:5:6:102:304%a");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2:3:4:5:6:1.2.3.4%", "1:2:3:4:5:6:102:304%");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%%", "1:2:3:4:5:6:102:304%%");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2:3:4:5:6:1.2.3.4%25%31]", "1:2:3:4:5:6:102:304%1");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2:3:4:5:6:102:304%25%31]", "1:2:3:4:5:6:102:304%1");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%-", "1:2:3:4:5:6:102:304%-");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%-/64", "1:2:3:4:5:6:102:304%-/64");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:1.2.3.4", "1:2:3:4:5:6:1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:0.0.0.0", "1:2:3:4:5:6::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:0:0.0.0.0", "1:2:3:4:5::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2:3:4:5:6::%y]", "1:2:3:4:5:6::%y");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2:3:4:5:6::%25y]", "1:2:3:4:5:6::%y");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2:3:4:5:6::]/32", "1:2:3:4:5:6::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:2::]/32", "1:2::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:ff00::]/24", "1:ff00::/24");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[1:ffff::]/24", "1:ffff::/24");
        this.testMatches$boolean$java_lang_String$java_lang_String(isAllSubnets, "1.2.3.4/255.0.0.0", "1.0.0.0/255.0.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:1:2:3:4:5:6:7:8%y]", "1:2:3:4:5:6:7:8%y");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:1:2:3:4:5:6:7:8]", "1:2:3:4:5:6:7:8");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:1:2:3:4:5:6::]/32", "1:2:3:4:5:6::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:1:2::]/32", "1:2::/32");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:::1]", "::1");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "[IPv6:1::]", "1::");
        this.testResolved$java_lang_String$java_lang_String("a::b:c:d:1.2.3.4%x", "a::b:c:d:1.2.3.4%x");
        this.testResolved$java_lang_String$java_lang_String("[a::b:c:d:1.2.3.4%x]", "a::b:c:d:1.2.3.4%x");
        this.testResolved$java_lang_String$java_lang_String("[a::b:c:d:1.2.3.4]", "a::b:c:d:1.2.3.4");
        this.testResolved$java_lang_String$java_lang_String("2001:0000:1234:0000:0000:C1C0:ABCD:0876%x", "2001:0:1234::c1c0:abcd:876%x");
        this.testResolved$java_lang_String$java_lang_String("[2001:0000:1234:0000:0000:C1C0:ABCD:0876%x]", "2001:0:1234::c1c0:abcd:876%x");
        this.testResolved$java_lang_String$java_lang_String("[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "2001:0:1234::C1C0:abcd:876");
        this.testResolved$java_lang_String$java_lang_String("2001:0000:1234:0000:0000:C1C0:ABCD:0876", "2001:0:1234::C1C0:abcd:876");
        this.testResolved$java_lang_String$java_lang_String("1.2.3.04", "1.2.3.4");
        this.testResolved_inet_aton("1.2.3", "1.2.0.3");
        this.testResolved$java_lang_String$java_lang_String("[1.2.3.4]", "1.2.3.4");
        if(this.fullTest && HostTest.runDNS) {
            this.testResolved$java_lang_String$java_lang_String("espn.com", "199.181.132.250");
            this.testResolved$java_lang_String$java_lang_String("espn.com/24", "199.181.132.0/24");
            this.testResolved$java_lang_String$java_lang_String("instapundit.com", "72.32.173.45");
        }
        this.testResolved$java_lang_String$java_lang_String("9.32.237.26", "9.32.237.26");
        this.testResolved$java_lang_String$java_lang_String("9.70.146.84", "9.70.146.84");
        this.testResolved$java_lang_String$java_lang_String("", null);
        this.testNormalizedHost(true, "[A::b:c:d:1.2.03.4]", "[a:0:0:b:c:d:102:304]");
        this.testNormalizedHost(true, "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "[2001:0:1234:0:0:c1c0:abcd:876]");
        this.testNormalizedHost(true, "1.2.3.04", "1.2.3.4");
        this.testCanonical("[A:0::c:d:1.2.03.4]", "a::c:d:102:304");
        this.testCanonical("[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "2001:0:1234::c1c0:abcd:876");
        this.testCanonical("1.2.3.04", "1.2.3.4");
        this.testNormalizedHost(true, "WWW.ABC.COM", "www.abc.com");
        this.testNormalizedHost(true, "WWW.AB-C.COM", "www.ab-c.com");
        this.testURL("http://1.2.3.4");
        this.testURL("http://[a:a:a:a:b:b:b:b]");
        this.testURL("http://a:a:a:a:b:b:b:b");
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.two.three.four.five.six.seven.EIGHT", ["one", "two", "three", "four", "five", "six", "seven", "eight"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.two.three.four.fIVE.sIX.seven", ["one", "two", "three", "four", "five", "six", "seven"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.two.THREE.four.five.six", ["one", "two", "three", "four", "five", "six"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.two.three.four.five", ["one", "two", "three", "four", "five"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.two.three.four", ["one", "two", "three", "four"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one.Two.three", ["one", "two", "three"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("onE.two", ["one", "two"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("one", ["one"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("", this.isLenient()?["127", "0", "0", "1"]:[]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A(" ", this.isLenient()?["127", "0", "0", "1"]:[]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("1.2.3.4", ["1", "2", "3", "4"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("1:2:3:4:5:6:7:8", ["1", "2", "3", "4", "5", "6", "7", "8"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("[::]", ["0", "0", "0", "0", "0", "0", "0", "0"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("::", ["0", "0", "0", "0", "0", "0", "0", "0"]);
        this.hostTest$boolean$java_lang_String(true, "1.2.3.4/1.2.3.4");
        this.hostTest$boolean$java_lang_String(true, "1.2.3.4/255.0.0.0");
        this.hostTest$boolean$java_lang_String(true, "abc.com/255.0.0.0");
        this.hostTest$boolean$java_lang_String(true, "abc.com/::");
        this.hostTest$boolean$java_lang_String(true, "abc.com/::1");
        this.hostTest$boolean$java_lang_String(true, "abc.com/1::1");
        this.hostTest$boolean$java_lang_String(true, "abc.com/1:1");
        this.hostTest$boolean$java_lang_String(true, "abc.com/1:abc");
        this.hostTest$boolean$java_lang_String(true, "abc.com/1.2.3.4");
        this.hostTest$boolean$java_lang_String(true, "abc.com:a1-2-3-4");
        this.hostTest$boolean$java_lang_String(true, "abc.com/1::");
        this.hostTest$boolean$java_lang_String(true, "abc.com/32");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4");
        this.hostTest$boolean$java_lang_String(false, "[1:2:3:4:5:6:7:8");
        this.hostTest$boolean$java_lang_String(true, "[a::b:c:d:1.2.3.4]");
        this.hostTest$boolean$java_lang_String(true, "[a::b:c:d:1.2.3.4%x]");
        this.hostTest$boolean$java_lang_String(true, "a::b:c:d:1.2.3.4%x");
        this.hostTest$boolean$java_lang_String(false, "a:b:c:d:1.2.3.4%x");
        this.hostTest$boolean$java_lang_String(true, "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]");
        this.hostTest$boolean$java_lang_String(true, "2001:0000:1234:0000:0000:C1C0:ABCD:0876%x");
        this.hostTest$boolean$java_lang_String(true, "[2001:0000:1234:0000:0000:C1C0:ABCD:0876%x]");
        this.hostTest$boolean$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%%");
        this.hostTest$boolean$java_lang_String(false, "[1:2:3:4:5:6:1.2.3.4%%]");
        this.hostTest$boolean$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%%");
        this.hostTest$boolean$java_lang_String(true, "[1:2:3:4:5:6:1.2.3.4%25%31]");
        this.hostTest$boolean$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%25%31");
        this.hostTest$boolean$java_lang_String(true, "1.2.3.4");
        this.hostTest_inet_aton(true, "1.2.3");
        this.hostTest$boolean$java_lang_String(true, "0x1.0x2.0x3.04");
        this.hostTest$boolean$java_lang_String(true, "[1.2.3.4]");
        this.hostTest$boolean$java_lang_String(true, "a_b.com");
        this.hostTest$boolean$java_lang_String(true, "_ab.com");
        this.hostTest$boolean$java_lang_String(true, "_ab_.com");
        this.hostTest$boolean$java_lang_String(false, "-ab-.com");
        this.hostTest$boolean$java_lang_String(false, "ab-.com");
        this.hostTest$boolean$java_lang_String(false, "-ab.com");
        this.hostTest$boolean$java_lang_String(false, "ab.-com");
        this.hostTest$boolean$java_lang_String(false, "ab.com-");
        this.hostTest$boolean$java_lang_String(true, "a9b.com");
        this.hostTest$boolean$java_lang_String(true, "9ab.com");
        this.hostTest$boolean$java_lang_String(true, "999.com");
        this.hostTest$boolean$java_lang_String(true, "ab9.com");
        this.hostTest$boolean$java_lang_String(true, "ab9.com9");
        this.hostTest_inet_aton(true, "999");
        this.hostTest_inet_aton(true, "111.999");
        this.hostTest$boolean$java_lang_String(false, "999.111");
        this.hostTest$boolean$java_lang_String(false, "a*b.com");
        this.hostTest$boolean$java_lang_String(false, "*ab.com");
        this.hostTest$boolean$java_lang_String(false, "ab.com*");
        this.hostTest$boolean$java_lang_String(false, "*.ab.com");
        this.hostTest$boolean$java_lang_String(false, "ab.com.*");
        this.hostTest$boolean$java_lang_String(false, "ab.co&m");
        this.hostTest$boolean$java_lang_String(false, "#.ab.com");
        this.hostTest$boolean$java_lang_String(false, "cd.ab.com.~");
        this.hostTest$boolean$java_lang_String(false, "#x.ab.com");
        this.hostTest$boolean$java_lang_String(false, "cd.ab.com.x~");
        this.hostTest$boolean$java_lang_String(false, "x#.ab.com");
        this.hostTest$boolean$java_lang_String(false, "cd.ab.com.~x");
        this.hostTest$boolean$java_lang_String(true, "xx.ab.com.xx");
        this.hostTest$boolean$java_lang_String(true, "ab.cde.fgh.com");
        this.hostTest$boolean$java_lang_String(true, "aB.cDE.fgh.COm");
        this.hostTest$boolean$java_lang_String(true, "123-123456789-123456789-123456789-123456789-123456789-123456789.com");
        this.hostTest$boolean$java_lang_String(false, "1234-123456789-123456789-123456789-123456789-123456789-123456789.com");
        this.hostTest$boolean$java_lang_String(false, "123.123456789.123456789.123456789.123456789.123456789.123456789.123");
        this.hostTest$boolean$java_lang_String(true, "aaa.123456789.123456789.123456789.123456789.123456789.123456789.123");
        this.hostTest$boolean$java_lang_String(false, "a11-123456789-123456789-123456789-123456789-12345678.-123456789-123456789-123456789-123456789-12345678.-123456789-123456789-123456789-123456789-12345678.-123456789-123456789-123456789-123456789-12345678.-123456789-123456789-123456789-123456789-123456789");
        this.hostTest$boolean$java_lang_String(true, "a11-123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-123456789");
        this.hostTest$boolean$java_lang_String(false, "1110123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.01234567890123456789012345678901234567890123456789");
        this.hostTest$boolean$java_lang_String(true, "2220123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678f");
        this.hostTest$boolean$java_lang_String(false, "a222-123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-12345678.0123456789-123456789-123456789-123456789-123456789");
        this.hostTest$boolean$java_lang_String(true, "a33.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789");
        this.hostTest$boolean$java_lang_String(false, "4440123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.01234567890123456789012345678901234567890123456789");
        this.hostTest$boolean$java_lang_String(true, "5550123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678.0123456789012345678901234567890123456789012345678f");
        this.hostTest$boolean$java_lang_String(true, "777012345678901234567890123456789012345678901234567890123456789.123456789012345678901234567890123456789012345678901234567890123.567890123456789012345678901234567890123456789012345678901234567.901234567890123456789012345678901234567890123456789012345678f");
        this.hostTest$boolean$java_lang_String(false, "7770123456789012345678901234567890123456789012345678901234567890.23456789012345678901234567890123456789012345678901234567890123.567890123456789012345678901234567890123456789012345678901234567.901234567890123456789012345678901234567890123456789012345678f");
        this.hostTest$boolean$java_lang_String(false, "a666.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789.123456789");
        this.hostTest$boolean$java_lang_String(true, "a.9.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5");
        this.hostTest$boolean$java_lang_String(false, "a.8.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.");
        this.hostTest$boolean$java_lang_String(false, ".a.7.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5");
        this.hostTest$boolean$java_lang_String(false, "a.6.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.1.1.1.1.1.2.2.2.2.2.3.3.3.3.3.4.4.4.4.4.5.5.5.5.5.8");
        this.hostTest$boolean$java_lang_String(false, "a:b:com");
        this.hostTest$boolean$java_lang_String(true, "a:b::ccc");
        this.hostTest$boolean$java_lang_String(true, "a:b:c:d:e:f:a:b");
        this.hostTest$boolean$java_lang_String(false, ".as.b.com");
        this.hostTest$boolean$java_lang_String(false, "as.b.com.");
        this.hostTest$boolean$java_lang_String(false, "aas.b.com.");
        this.hostTest$boolean$java_lang_String(false, "as..b.com");
        this.hostTest$boolean$java_lang_String(false, "as.b..com");
        this.hostTest$boolean$java_lang_String(false, "..as.b.com");
        this.hostTest$boolean$java_lang_String(false, "as.b.com..");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-bb-cc-dd-ee-ff-aaaa-bbbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbbb", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-bb-cc-dd-ee-ff-aaaa-bbbbseth0.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbbb", "aa:bb:cc:dd:ee:ff:aaaa:bbbb%eth0", null, "eth0");
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-bb-cc-dd-ee-ff.ipv6-literal.net", "aa-bb-cc-dd-ee-ff.ipv6-literal.net", null, null);
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-Bb-cc-dd-ee-FF.ipv6-literal.net", "aa-bb-cc-dd-ee-ff.ipv6-literal.net", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-bb-cc-dd-ee-ff-aaaa-bbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbb", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("aa-Bb-cc-dd-ee-FF-aaaa-bbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbb", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.arpa", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int:45", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", 45, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int:45", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", 45, null);
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f.F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int:45", "f.f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int", 45, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("255.22.2.111.in-addr.arpa", "111.2.22.255", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("255.22.2.111.in-addr.arpa:35", "111.2.22.255", 35, null);
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("255.22.2.111.3.in-addr.arpa:35", "255.22.2.111.3.in-addr.arpa", 35, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("1.2.2.1:33", "1.2.2.1", 33, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::1]:33", "::1", 33, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::1:33", "::1:33", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::1%eth0", "::1", "::1%eth0", null, "eth0");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::1%eth0]:33", "::1", "::1%eth0", 33, "eth0");
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("bla.bla:33", "bla.bla", 33, null);
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("blA:33", "bla", 33, null);
        this.testHost$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f:33", "f", 33, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("f::33", "f::33", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::1", "::1", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::1]", "::1", null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("/16", "/16", null, null, 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("/32", "/32", null, null, 32);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("/64", isNoAutoSubnets?"ffff:ffff:ffff:ffff::":"ffff:ffff:ffff:ffff:*:*:*:*", "ffff:ffff:ffff:ffff::/64", null, null, 64);
        this.hostTest$boolean$java_lang_String(true, "255.22.2.111.3.in-addr.arpa:35");
        this.hostTest$boolean$java_lang_String(false, "[::1]x");
        this.hostTest$boolean$java_lang_String(false, "[::1x]");
        this.hostTest$boolean$java_lang_String(false, "[::x1]");
        this.hostTest$boolean$java_lang_String(false, "x[::1]");
        this.hostTest$boolean$java_lang_String(false, "[]");
        this.hostTest$boolean$java_lang_String(false, "[a]");
        this.hostTest$boolean$java_lang_String(false, "1.2.2.256:33");
        this.hostTest$boolean$java_lang_String(true, "f.F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int:45");
        this.hostTest$boolean$java_lang_String(true, "f.F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int");
        this.hostTest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee-ff-.ipv6-literal.net");
        this.hostTest$boolean$java_lang_String(true, "aa-bb-cc-dd-ge-ff.ipv6-literal.net");
        this.testHostAddressWithService("1.2.3.4:nfs", "1.2.3.4", "nfs", null);
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("[::1%eth0]:nfs", "::1", "::1%eth0", null, "nfs", "eth0", null);
        this.testHostAddressWithService("1.2.3.4:12345678901234a", "1.2.3.4", "12345678901234a", null);
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:123456789012345a");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:");
        this.testHostAddressWithService("[::1]:12345678901234a", "::1", "12345678901234a", null);
        this.testHostAddressWithService("[::1]:12345678901234x", "::1", "12345678901234x", null);
        this.testHostAddressWithService("1.2.3.4:a", "1.2.3.4", "a", null);
        this.testHostAddressWithService("1.2.3.4:a-b-c", "1.2.3.4", "a-b-c", null);
        this.testHostAddressWithService("[ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff]:a-b-c", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "a-b-c", null);
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:a-");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:-a");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:a--b");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:x-");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:-x");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:x--x");
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("a.b.c/16:nfs", "a.b.c", null, null, "nfs", null, 16);
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("a.b.c/16:80", "a.b.c", null, 80, null, null, 16);
        this.testHostWithService("a.b.c:nfs", "a.b.c", "nfs", null);
        this.hostTest$boolean$java_lang_String(false, "[a.b.com]:nfs");
        this.hostTest$boolean$java_lang_String(true, "[::]:nfs");
        this.testHostWithService("a.b.com:12345678901234a", "a.b.com", "12345678901234a", null);
        this.testHostWithService("a.b.com:12345678901234x", "a.b.com", "12345678901234x", null);
        this.testHostWithService("a.b.com:x12345678901234", "a.b.com", "x12345678901234", null);
        this.testHostWithService("a.b.com:12345x789012345", "a.b.com", "12345x789012345", null);
        this.testHostWithService("a.b.com:a", "a.b.com", "a", null);
        this.testHostWithService("a.b.com:a-b-c", "a.b.com", "a-b-c", null);
        this.testHostWithService("a.b.c:a-b-c", "a.b.c", "a-b-c", null);
        this.testHostWithService("123-123456789-123456789-123456789-123456789-123456789-123456789.com:a-b-c", "123-123456789-123456789-123456789-123456789-123456789-123456789.com", "a-b-c", null);
        this.testHostWithService("123-123456789-123456789-123456789-123456789-123456789-123456789.com:12345x789012345", "123-123456789-123456789-123456789-123456789-123456789-123456789.com", "12345x789012345", null);
        let expectPortParams : HostNameParameters = TestBase.HOST_OPTIONS_$LI$().toBuilder().expectPort(true).toParams();
        this.testHostAddressWithService("fe80::6a05:caff:fe3:nfs", "fe80::6a05:caff:fe3", "nfs", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("fe80::6a05:caff:fe3:123", "fe80::6a05:caff:fe3:123", null, null);
        let hostName : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("fe80::6a05:caff:fe3:123", expectPortParams);
        this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(hostName, "fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3", 123, null, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[1::%25%241]", "1::", "1::%$1", null, "$1");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[1::%%241]", "1::", "1::%$1", null, "$1");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[1::%25%241]:123", "1::", "1::%$1", 123, "$1");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[1::%%241]:123", "1::", "1::%$1", 123, "$1");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("1::%25%241:123", "1::", "1::%25%241", 123, "25%241");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("1::%%241:123", "1::", "1::%%241", 123, "%241");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::%%1/16", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%%1/16", null, "%1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[1::%251]/16", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1/16", null, "1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[1::%251/16]:3", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1/16", 3, "1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::%1/16:3", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1/16", 3, "1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::%%1/16:3", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%%1/16", 3, "%1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[1::/16]:3", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::/16", 3, null, 16);
        this.hostTest$boolean$java_lang_String(false, "[1::/16]/32");
        this.hostTest$boolean$java_lang_String(true, "[1::/16]/16");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4/16]/32");
        this.hostTest$boolean$java_lang_String(true, "[1.2.3.4/16]/16");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4/16]/255.255.255.0");
        this.hostTest$boolean$java_lang_String(true, "[1.2.3.4/16]/255.255.0.0");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4/255.255.255.0]/16");
        this.hostTest$boolean$java_lang_String(true, "[1.2.3.4/255.255.0.0]/16");
        this.hostTest$boolean$java_lang_String(true, "[1.2.3.4/255.255.255.0]/255.255.255.0");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4/255.255.0.0]/255.255.255.0");
        this.hostTest$boolean$java_lang_String(false, "[1.2.3.4/255.255.255.0]/255.255.0.0");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::/16:3", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::/16", 3, null, 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[1::%251/16]", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1/16", null, "1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[1::%25%241/16]", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%$1/16", null, "$1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::%1/16", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1/16", null, "1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1::%1%1/16", isNoAutoSubnets?"1::":"1:*:*:*:*:*:*:*", "1::%1%1/16", null, "1%1", 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1.2.3.4/16", !isAllSubnets?"1.2.3.4":"1.2.*.*", "1.2.3.4/16", null, null, 16);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("1.2.0.0/16", isNoAutoSubnets?"1.2.0.0":"1.2.*.*", "1.2.0.0/16", null, null, 16);
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("a.b.com/24", "a.b.com", null, null, null, null, 24);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("[fe80::%2]/64", isNoAutoSubnets?"fe80::":"fe80::*:*:*:*", "fe80::%2/64", null, "2", 64);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_Integer("fe80::%2/64", isNoAutoSubnets?"fe80::":"fe80::*:*:*:*", "fe80::%2/64", null, "2", 64);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::123%25%25%25aaa%25]", "::123", "::123%%%aaa%", null, "%%aaa%");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::123%25%25%25%24aa%25]", "::123", "::123%%%$aa%", null, "%%$aa%");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::123%25%24%25%24aa%25]", "::123", "::123%$%$aa%", null, "$%$aa%");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::123%%%", "::123", "::123%%%", null, "%%");
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("fe80:0:0:0:0:6a05:caff:fe3%x:123", "fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x", 123, "x");
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("fe80:0:0:0:0:6a05:caff:fe3%x:abc", "fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x", null, "abc", "x", null);
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("fe80:0:0:0:0:6a05:caff:fe3%x/64:abc", isAllSubnets?"fe80::*:*:*:*":"fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x/64", null, "abc", "x", 64);
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("[fe80:0:0:0:0:6a05:caff:fe3%x/64]:abc", isAllSubnets?"fe80::*:*:*:*":"fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x/64", null, "abc", "x", 64);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("fe80::6a05:caff:fe3%x:123", "fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x", 123, "x");
        this.testHost$java_lang_String$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_Integer("fe80::6a05:caff:fe3%x:abc", "fe80::6a05:caff:fe3", "fe80::6a05:caff:fe3%x", null, "abc", "x", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("fe80:0:0:0:0:6a05:caff:fe3", "fe80::6a05:caff:fe3", null, null);
        this.testHostAddressWithService("fe80:0:0:0:0:0:6a05:caff:fe3", "fe80::6a05:caff", "fe3", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("fe80:0:0:0:0:6a05:caff:fe3:123", "fe80::6a05:caff:fe3", 123, null);
        this.testHostAddressWithService("fe80:0:0:0:0:6a05:caff:fe3:*", "fe80::6a05:caff:fe3", "*", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::1:8888", "::1:8888", null, null);
        this.testHostAddressWithService("::1:88g8", "::1", "88g8", null);
        this.testHostAddressWithService("::1:88a8", "::1:88a8", null, null);
        hostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("::1:88a8", expectPortParams);
        this.testHost$inet_ipaddr_HostName$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(hostName, "::1", "::1", null, "88a8", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("::1:48888", "::1", 48888, null);
        this.testHostAddressWithService("::1:nfs", "::1", "nfs", null);
        this.testHostAddressWithService(":::*", "::", "*", null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(":::1", "::", 1, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String(":::123", "::", 123, null);
        this.testHostAddress$java_lang_String$java_lang_String$java_lang_Integer$java_lang_String("[::]:123", "::", 123, null);
        this.hostTest$boolean$java_lang_String(false, "::1:88888");
        this.hostTest$boolean$java_lang_String(false, "::1:88-8");
        this.hostTest$boolean$java_lang_String(true, "::1:8888");
        this.hostTest$boolean$java_lang_String(true, "::1:58888");
        this.hostTest$boolean$java_lang_String(true, "::1:8a-8");
        this.hostTest$boolean$java_lang_String(this.isLenient(), "::1:-8a88");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4:-8a8");
        this.hostTest$boolean$java_lang_String(true, "1.2.3.4:8-a8");
        this.hostTest$boolean$java_lang_String(this.isLenient(), "::1:8a8-:2");
        this.hostTest$boolean$java_lang_String(this.isLenient(), "::1:-8a8:2");
        this.hostTest$boolean$java_lang_String(this.isLenient(), "::1:8a8-");
        this.hostTest$boolean$java_lang_String(this.isLenient(), "::1:-8a8");
    }
}
HostTest["__class"] = "inet.ipaddr.test.HostTest";



