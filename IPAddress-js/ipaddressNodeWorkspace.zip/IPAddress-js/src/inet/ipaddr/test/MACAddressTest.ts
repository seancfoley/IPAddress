/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressStringException } from '../AddressStringException';
import { AddressValueException } from '../AddressValueException';
import { IPAddressString } from '../IPAddressString';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { MACAddressString } from '../MACAddressString';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { IPv6AddressSegment } from '../ipv6/IPv6AddressSegment';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressSection } from '../mac/MACAddressSection';
import { MACAddressSegment } from '../mac/MACAddressSegment';
import { TestBase } from './TestBase';
import { AddressCreator } from './AddressCreator';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { IPAddress } from '../IPAddress';
import { AddressNetwork } from '../AddressNetwork';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { Address } from '../Address';
import { AddressSegmentSeries } from '../AddressSegmentSeries';

export class MACAddressTest extends TestBase {
    constructor(creator : AddressCreator) {
        super(creator);
    }

    testNormalized(original : string, expected : string) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        let val : MACAddress = w.getAddress();
        if(val == null) {
            this.addFailure(new TestBase.Failure("normalization was null", w));
        } else {
            let normalized : string = val.toNormalizedString();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(expected,normalized))) {
                this.addFailure(new TestBase.Failure("mac normalization was " + normalized, w));
            }
        }
        this.incrementTestCount();
    }

    testCanonical(original : string, expected : string) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        let val : MACAddress = w.getAddress();
        if(val == null) {
            this.addFailure(new TestBase.Failure("normalization was null", w));
        } else {
            let normalized : string = val.toCanonicalString();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(expected,normalized))) {
                this.addFailure(new TestBase.Failure("canonical was " + normalized, w));
            }
        }
        this.incrementTestCount();
    }

    testRadices(original : string, expected : string, radix : number) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        let val : MACAddress = w.getAddress();
        let options : AddressDivisionGrouping.StringOptions = new MACAddressSection.MACStringOptions.__inet_ipaddr_mac_MACAddressSection_MACStringOptions_Builder().setRadix(radix).toOptions();
        let normalized : string = val.toNormalizedString$inet_ipaddr_format_AddressDivisionGrouping_StringOptions(options);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
            this.addFailure(new TestBase.Failure("string was " + normalized + " expected was " + expected, w));
        }
        this.incrementTestCount();
    }

    testOUIPrefixed(original : string, expected : string, expectedPref : number) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        let val : MACAddress = w.getAddress();
        let w2 : MACAddressString = this.createMACAddress$java_lang_String(expected);
        let expectedAddress : MACAddress = w2.getAddress();
        let prefixed : MACAddress = val.toOUIPrefixBlock();
        if(!prefixed.equals(expectedAddress)) {
            this.addFailure(new TestBase.Failure("oui prefixed was " + prefixed + " expected was " + expected, w));
        }
        if(expectedPref !== /* intValue */(prefixed.getPrefixLength()|0)) {
            this.addFailure(new TestBase.Failure("oui prefix was " + prefixed.getPrefixLength() + " expected was " + expectedPref, w));
        }
        this.incrementTestCount();
    }

    public mactest$boolean$inet_ipaddr_MACAddressString$boolean(pass : boolean, addr : MACAddressString, isZero : boolean) : boolean {
        let failed : boolean = false;
        try {
            if(this.isNotExpected(pass, addr)) {
                failed = true;
                this.addFailure(new TestBase.Failure(pass, addr));
            } else {
                let zeroPass : boolean = pass && !isZero;
                if(this.isNotExpectedNonZero(zeroPass, addr)) {
                    failed = true;
                    this.addFailure(new TestBase.Failure(zeroPass, addr));
                } else {
                    if(pass && addr.toString().length > 0 && addr.getAddress() != null) {
                        failed = !this.testBytes(addr.getAddress());
                    }
                }
            }
        } catch(__e) {
            if(__e != null && __e instanceof <any>IncompatibleAddressException) {
                let e : IncompatibleAddressException = <IncompatibleAddressException>__e;
                failed = true;
                this.addFailure(new TestBase.Failure(e.toString(), addr));

            }
            if(__e != null && (__e["__classes"] && __e["__classes"].indexOf("java.lang.RuntimeException") >= 0) || __e != null && __e instanceof <any>Error) {
                let e : Error = <Error>__e;
                failed = true;
                this.addFailure(new TestBase.Failure(e.toString(), addr));

            }
        };
        this.incrementTestCount();
        return !failed;
    }

    public mactest(pass? : any, addr? : any, isZero? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((addr != null && addr instanceof <any>MACAddressString) || addr === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.mactest$boolean$inet_ipaddr_MACAddressString$boolean(pass, addr, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof addr === 'string') || addr === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.mactest$boolean$java_lang_String$boolean(pass, addr, isZero);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof addr === 'string') || addr === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.mactest$int$java_lang_String$boolean(pass, addr, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof addr === 'string') || addr === null) && isZero === undefined) {
            return <any>this.mactest$boolean$java_lang_String(pass, addr);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof addr === 'string') || addr === null) && isZero === undefined) {
            return <any>this.mactest$int$java_lang_String(pass, addr);
        } else throw new Error('invalid overload');
    }

    testBytes(addr : MACAddress) : boolean {
        let failed : boolean = false;
        let bytes : number[] = addr.getBytes();
        let another : MACAddress = this.createMACAddress$byte_A(bytes);
        if(!addr.equals(another)) {
            this.addFailure(new TestBase.Failure(addr.toString(), addr));
        }
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        /* append */(sb => { sb.str = sb.str.concat(<any>addr.toColonDelimitedString()); return sb; })(builder);
        if(addr.getSegmentCount() < 8) {
            /* append */(sb => { sb.str = sb.str.concat(<any>"::"); return sb; })(builder);
        }
        try {
            let inetAddress : InetAddress = InetAddress.getByName(/* toString */builder.str);
            let ipv6Bytes : number[] = inetAddress.getAddress();
            let macBytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(bytes.length);
            for(let i : number = 0; i < macBytes.length; i++) {
                macBytes[i] = ipv6Bytes[(i << 1) + 1];
            };
            if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(macBytes, bytes)) {
                failed = true;
                this.addFailure(new TestBase.Failure("bytes on addr " + inetAddress, addr));
            }
        } catch(e) {
            failed = true;
            this.addFailure(new TestBase.Failure("bytes on addr " + e, addr));
        };
        return !failed;
    }

    testFromBytes(bytes : number[], expected : string) {
        let addr : MACAddress = this.createMACAddress$byte_A(bytes);
        let addr2 : MACAddressString = this.createMACAddress$java_lang_String(expected);
        let result : boolean = addr.equals(addr2.getAddress());
        if(!result) {
            this.addFailure(new TestBase.Failure("created was " + addr + " expected was " + addr2, addr));
        } else {
            let val : number = 0;
            for(let i : number = 0; i < bytes.length; i++) {
                val <<= 8;
                val |= 255 & bytes[i];
            };
            addr = this.createMACAddress$long$boolean(val, bytes.length > 6);
            result = addr.equals(addr2.getAddress());
            if(!result) {
                this.addFailure(new TestBase.Failure("created was " + addr + " expected was " + addr2, addr));
            }
        }
        this.incrementTestCount();
    }

    isNotExpected(expectedPass : boolean, addr : MACAddressString) : boolean {
        try {
            addr.validate();
            return !expectedPass;
        } catch(e) {
            return expectedPass;
        };
    }

    isNotExpectedNonZero(expectedPass : boolean, addr : MACAddressString) : boolean {
        if(!addr.isValid()) {
            return expectedPass;
        }
        if(addr.getAddress() != null && addr.getAddress().isZero()) {
            return expectedPass;
        }
        return !expectedPass;
    }

    mactest$boolean$java_lang_String(pass : boolean, x : string) {
        this.mactest$boolean$java_lang_String$boolean(pass, x, false);
    }

    mactest$boolean$java_lang_String$boolean(pass : boolean, x : string, isZero : boolean) {
        this.mactest$boolean$inet_ipaddr_MACAddressString$boolean(pass, this.createMACAddress$java_lang_String(x), isZero);
    }

    mactest$int$java_lang_String(pass : number, x : string) {
        this.mactest$boolean$java_lang_String(pass === 0?false:true, x);
    }

    mactest$int$java_lang_String$boolean(pass : number, x : string, isZero : boolean) {
        this.mactest$boolean$java_lang_String$boolean(pass === 0?false:true, x, isZero);
    }

    testContains(addr1 : string, addr2 : string, equal : boolean) {
        try {
            let w : MACAddress = this.createMACAddress$java_lang_String(addr1).toAddress();
            let w2 : MACAddress = this.createMACAddress$java_lang_String(addr2).toAddress();
            if(!w.contains(w2)) {
                this.addFailure(new TestBase.Failure("failed " + w2, w));
            } else {
                if(equal?!w2.contains(w):w2.contains(w)) {
                    this.addFailure(new TestBase.Failure("failed " + w, w2));
                    if(equal) {
                        console.info("containment: " + !w2.contains(w));
                    } else {
                        console.info("containment: " + w2.contains(w));
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e));
        };
        this.incrementTestCount();
    }

    testNotContains(cidr1 : string, cidr2 : string) {
        try {
            let w : MACAddress = this.createMACAddress$java_lang_String(cidr1).toAddress();
            let w2 : MACAddress = this.createMACAddress$java_lang_String(cidr2).toAddress();
            if(w.contains(w2)) {
                this.addFailure(new TestBase.Failure("failed " + w2, w));
            } else if(w2.contains(w)) {
                this.addFailure(new TestBase.Failure("failed " + w, w2));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e, new MACAddressString(cidr1)));
        };
        this.incrementTestCount();
    }

    static prefixAdjust(existing : number, max : number, adj : number) : number {
        if(existing == null) {
            return null;
        }
        if(existing > max) {
            return null;
        }
        return Math.max(0, existing + adj);
    }

    static allEquals$java_lang_Object$java_lang_Object(one : any, two : any) : boolean {
        return Objects.equals(one, two);
    }

    public static allEquals$java_lang_Object$java_lang_Object$java_lang_Object(one : any, two : any, three : any) : boolean {
        return MACAddressTest.allEquals$java_lang_Object$java_lang_Object(one, two) && MACAddressTest.allEquals$java_lang_Object$java_lang_Object(one, three);
    }

    public static allEquals(one? : any, two? : any, three? : any) : any {
        if(((one != null) || one === null) && ((two != null) || two === null) && ((three != null) || three === null)) {
            return <any>MACAddressTest.allEquals$java_lang_Object$java_lang_Object$java_lang_Object(one, two, three);
        } else if(((one != null) || one === null) && ((two != null) || two === null) && three === undefined) {
            return <any>MACAddressTest.allEquals$java_lang_Object$java_lang_Object(one, two);
        } else throw new Error('invalid overload');
    }

    testSections(addrString : string) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(addrString);
        let v : MACAddress = w.getAddress();
        let odiSection : MACAddressSection = v.getODISection();
        let ouiSection : MACAddressSection = v.getOUISection();
        let front : MACAddressSection = v.getSection$int$int(0, 3);
        let back : MACAddressSection = v.getSection$int(front.getSegmentCount());
        let first : boolean;
        if((first = !ouiSection.equals(front)) || !MACAddressTest.allEquals$java_lang_Object$java_lang_Object$java_lang_Object(ouiSection.getPrefixLength(), front.getPrefixLength(), MACAddressTest.prefixAdjust(v.getPrefixLength(), 24, 0))) {
            if(first) {
                this.addFailure(new TestBase.Failure("failed oui " + ouiSection + " expected " + front, w));
            } else {
                this.addFailure(new TestBase.Failure("failed oui pref " + ouiSection.getPrefixLength() + " expected " + MACAddressTest.prefixAdjust(v.getPrefixLength(), 24, 0) + " for " + front, w));
            }
        } else if((first = !odiSection.equals(back)) || !MACAddressTest.allEquals$java_lang_Object$java_lang_Object$java_lang_Object(odiSection.getPrefixLength(), back.getPrefixLength(), MACAddressTest.prefixAdjust(v.getPrefixLength(), 64, -24))) {
            if(first) {
                this.addFailure(new TestBase.Failure("failed odi " + odiSection + " expected " + back, w));
            } else {
                this.addFailure(new TestBase.Failure("failed odi pref " + odiSection.getPrefixLength() + " expected " + MACAddressTest.prefixAdjust(v.getPrefixLength(), 64, -24) + " for " + back, w));
            }
        } else {
            let middle : MACAddressSection = v.getSection$int$int(1, 5);
            let odiSection2 : MACAddressSection = odiSection.getSection$int$int(0, 5 - ouiSection.getSegmentCount());
            let ouiSection2 : MACAddressSection = ouiSection.getSection$int(1);
            odiSection = middle.getODISection();
            ouiSection = middle.getOUISection();
            if(!ouiSection.equals(ouiSection2) || !MACAddressTest.allEquals$java_lang_Object$java_lang_Object(ouiSection.getPrefixLength(), ouiSection2.getPrefixLength())) {
                this.addFailure(new TestBase.Failure("failed odi " + ouiSection + " expected " + ouiSection2, w));
            } else if(!odiSection.equals(odiSection2) || !MACAddressTest.allEquals$java_lang_Object$java_lang_Object(odiSection.getPrefixLength(), odiSection2.getPrefixLength())) {
                this.addFailure(new TestBase.Failure("failed odi " + odiSection + " expected " + odiSection2, w));
            } else if(ouiSection.getSegmentCount() !== 2 || ouiSection2.getSegmentCount() !== 2) {
                this.addFailure(new TestBase.Failure("failed oui count " + ouiSection.getSegmentCount() + " expected " + 2, w));
            } else if(odiSection.getSegmentCount() !== 2 || odiSection2.getSegmentCount() !== 2) {
                this.addFailure(new TestBase.Failure("failed oui count " + odiSection.getSegmentCount() + " expected " + 2, w));
            } else {
                let odiEmpty : MACAddressSection = odiSection.getSection$int$int(0, 0);
                let ouiEmpty : MACAddressSection = ouiSection.getSection$int$int(0, 0);
                if(odiEmpty.equals(ouiEmpty) || odiEmpty.getSegmentCount() > 0 || ouiEmpty.getSegmentCount() > 0) {
                    this.addFailure(new TestBase.Failure("failed odi empty " + odiEmpty + " oui empty " + ouiEmpty, w));
                } else {
                    let midEmpty : MACAddressSection = middle.getSection$int$int(0, 0);
                    if(!ouiEmpty.equals(midEmpty) || midEmpty.getSegmentCount() !== 0) {
                        this.addFailure(new TestBase.Failure("failed odi empty " + midEmpty + " expected " + ouiEmpty, w));
                    } else {
                        let midEmpty2 : MACAddressSection = middle.getSection$int$int(1, 1);
                        if(ouiEmpty.equals(midEmpty2) || midEmpty2.getSegmentCount() !== 0) {
                            this.addFailure(new TestBase.Failure("failed odi empty " + midEmpty2 + " expected " + ouiEmpty, w));
                        }
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    testMatches(matches : boolean, host1Str : string, host2Str : string) {
        let h1 : MACAddressString = this.createMACAddress$java_lang_String(host1Str);
        let h2 : MACAddressString = this.createMACAddress$java_lang_String(host2Str);
        if(matches !== h1.equals(h2)) {
            this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h2, h1));
        } else {
            if(matches !== h2.equals(h1)) {
                this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h1, h2));
            } else {
                if(matches?(h1.compareTo(h2) !== 0):(h1.compareTo(h2) === 0)) {
                    this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h1, h2));
                } else {
                    if(matches?(h2.compareTo(h1) !== 0):(h2.compareTo(h1) === 0)) {
                        this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h2, h1));
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    public testReverse$java_lang_String$boolean$boolean(addressStr : string, bitsReversedIsSame : boolean, bitsReversedPerByteIsSame : boolean) {
        let str : MACAddressString = this.createMACAddress$java_lang_String(addressStr);
        try {
            this.testReverse$inet_ipaddr_AddressSegmentSeries$boolean$boolean(str.getAddress(), bitsReversedIsSame, bitsReversedPerByteIsSame);
        } catch(e) {
            this.addFailure(new TestBase.Failure("reversal: " + addressStr));
        };
        this.incrementTestCount();
    }

    public testReverse(addressStr? : any, bitsReversedIsSame? : any, bitsReversedPerByteIsSame? : any) : any {
        if(((typeof addressStr === 'string') || addressStr === null) && ((typeof bitsReversedIsSame === 'boolean') || bitsReversedIsSame === null) && ((typeof bitsReversedPerByteIsSame === 'boolean') || bitsReversedPerByteIsSame === null)) {
            return <any>this.testReverse$java_lang_String$boolean$boolean(addressStr, bitsReversedIsSame, bitsReversedPerByteIsSame);
        } else if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || addressStr === null) && ((typeof bitsReversedIsSame === 'boolean') || bitsReversedIsSame === null) && ((typeof bitsReversedPerByteIsSame === 'boolean') || bitsReversedPerByteIsSame === null)) {
            super.testReverse(addressStr, bitsReversedIsSame, bitsReversedPerByteIsSame);
        } else throw new Error('invalid overload');
    }

    public testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(original : string, prefix : number, adjustment : number, next : string, previous : string, adjusted : string, prefixSet : string, prefixApplied : string) {
        this.testPrefixes$inet_ipaddr_AddressSegmentSeries$int$int$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries(this.createMACAddress$java_lang_String(original).getAddress(), prefix, adjustment, this.createMACAddress$java_lang_String(next).getAddress(), this.createMACAddress$java_lang_String(previous).getAddress(), this.createMACAddress$java_lang_String(adjusted).getAddress(), this.createMACAddress$java_lang_String(prefixSet).getAddress(), this.createMACAddress$java_lang_String(prefixApplied).getAddress());
        this.incrementTestCount();
    }

    public testPrefixes(original? : any, prefix? : any, adjustment? : any, next? : any, previous? : any, adjusted? : any, prefixSet? : any, prefixApplied? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof adjustment === 'number') || adjustment === null) && ((typeof next === 'string') || next === null) && ((typeof previous === 'string') || previous === null) && ((typeof adjusted === 'string') || adjusted === null) && ((typeof prefixSet === 'string') || prefixSet === null) && ((typeof prefixApplied === 'string') || prefixApplied === null)) {
            return <any>this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(original, prefix, adjustment, next, previous, adjusted, prefixSet, prefixApplied);
        } else if(((original != null && (original["__interfaces"] != null && original["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || original.constructor != null && original.constructor["__interfaces"] != null && original.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || original === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof adjustment === 'number') || adjustment === null) && ((next != null && (next["__interfaces"] != null && next["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || next.constructor != null && next.constructor["__interfaces"] != null && next.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || next === null) && ((previous != null && (previous["__interfaces"] != null && previous["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || previous.constructor != null && previous.constructor["__interfaces"] != null && previous.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || previous === null) && ((adjusted != null && (adjusted["__interfaces"] != null && adjusted["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || adjusted.constructor != null && adjusted.constructor["__interfaces"] != null && adjusted.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || adjusted === null) && ((prefixSet != null && (prefixSet["__interfaces"] != null && prefixSet["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixSet.constructor != null && prefixSet.constructor["__interfaces"] != null && prefixSet.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixSet === null) && ((prefixApplied != null && (prefixApplied["__interfaces"] != null && prefixApplied["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixApplied.constructor != null && prefixApplied.constructor["__interfaces"] != null && prefixApplied.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixApplied === null)) {
            super.testPrefixes(original, prefix, adjustment, next, previous, adjusted, prefixSet, prefixApplied);
        } else throw new Error('invalid overload');
    }

    public testPrefix(original? : any, prefixLength? : any, minPrefix? : any, equivalentPrefix? : any) : any {
        if(((original != null && (original["__interfaces"] != null && original["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || original.constructor != null && original.constructor["__interfaces"] != null && original.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || original === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof minPrefix === 'number') || minPrefix === null) && ((typeof equivalentPrefix === 'number') || equivalentPrefix === null)) {
            super.testPrefix(original, prefixLength, minPrefix, equivalentPrefix);
        } else if(((typeof original === 'string') || original === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof minPrefix === 'number') || minPrefix === null) && equivalentPrefix === undefined) {
            return <any>this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer(original, prefixLength, minPrefix);
        } else throw new Error('invalid overload');
    }

    testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer(original : string, prefixLength : number, equivalentPrefix : number) {
        let mac : MACAddress = this.createMACAddress$java_lang_String(original).getAddress();
        this.testPrefix$inet_ipaddr_AddressSegmentSeries$java_lang_Integer$int$java_lang_Integer(mac, prefixLength, prefixLength == null?mac.getBitCount():prefixLength, equivalentPrefix);
        this.incrementTestCount();
    }

    testDelimitedCount(str : string, expectedCount : number) {
        let strings : any = MACAddressString.parseDelimitedSegments(str);
        let set : Array<MACAddress> = <any>([]);
        let count : number = 0;
        try {
            while((strings.hasNext())) {
                /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, this.createMACAddress$java_lang_String(strings.next()).toAddress());
                count++;
            };
            if(count !== expectedCount || /* size */(<number>set.length) !== count || count !== MACAddressString.countDelimitedAddresses(str)) {
                this.addFailure(new TestBase.Failure("count mismatch, count: " + count + " set count: " + /* size */(<number>set.length) + " calculated count: " + IPAddressString.countDelimitedAddresses(str) + " expected: " + expectedCount));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("threw unexpectedly " + str));
        };
        this.incrementTestCount();
    }

    testLongShort$java_lang_String$java_lang_String(longAddr : string, shortAddr : string) {
        this.testLongShort$java_lang_String$java_lang_String$boolean(longAddr, shortAddr, false);
    }

    public testLongShort$java_lang_String$java_lang_String$boolean(longAddr : string, shortAddr : string, shortCanBeLong : boolean) {
        let params : MACAddressStringParameters = new MACAddressStringParameters.Builder().setAllAddresses(MACAddressStringParameters.AddressSize.MAC).toParams();
        let longString : MACAddressString = new MACAddressString(longAddr, params);
        let shortString : MACAddressString = new MACAddressString(shortAddr, params);
        if(!shortString.isValid()) {
            this.addFailure(new TestBase.Failure("short not valid " + shortString, shortString));
        }
        if(longString.isValid()) {
            this.addFailure(new TestBase.Failure("long valid " + longString, longString));
        }
        params = new MACAddressStringParameters.Builder().setAllAddresses(MACAddressStringParameters.AddressSize.EUI64).toParams();
        longString = new MACAddressString(longAddr, params);
        shortString = new MACAddressString(shortAddr, params);
        if(shortCanBeLong?!shortString.isValid():shortString.isValid()) {
            this.addFailure(new TestBase.Failure("short valid " + shortString, shortString));
        }
        if(!longString.isValid()) {
            this.addFailure(new TestBase.Failure("long not valid " + longString, longString));
        }
        if(longString.getAddress().getSegmentCount() !== MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
            this.addFailure(new TestBase.Failure("long not enough segments " + longString, longString));
        }
        if(shortCanBeLong && shortString.getAddress().getSegmentCount() !== MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
            this.addFailure(new TestBase.Failure("also not enough segments " + shortString, shortString));
        }
        params = new MACAddressStringParameters.Builder().setAllAddresses(MACAddressStringParameters.AddressSize.ANY).toParams();
        longString = new MACAddressString(longAddr, params);
        shortString = new MACAddressString(shortAddr, params);
        if(!shortString.isValid()) {
            this.addFailure(new TestBase.Failure("short not valid " + shortString, shortString));
        }
        if(!longString.isValid()) {
            this.addFailure(new TestBase.Failure("long not valid " + longString, longString));
        }
        this.incrementTestCount();
    }

    public testLongShort(longAddr? : any, shortAddr? : any, shortCanBeLong? : any) : any {
        if(((typeof longAddr === 'string') || longAddr === null) && ((typeof shortAddr === 'string') || shortAddr === null) && ((typeof shortCanBeLong === 'boolean') || shortCanBeLong === null)) {
            return <any>this.testLongShort$java_lang_String$java_lang_String$boolean(longAddr, shortAddr, shortCanBeLong);
        } else if(((typeof longAddr === 'string') || longAddr === null) && ((typeof shortAddr === 'string') || shortAddr === null) && shortCanBeLong === undefined) {
            return <any>this.testLongShort$java_lang_String$java_lang_String(longAddr, shortAddr);
        } else throw new Error('invalid overload');
    }

    public testMACStrings(w? : any, ipAddr? : any, normalizedString? : any, compressedString? : any, canonicalString? : any, dottedString? : any, spaceDelimitedString? : any, singleHex? : any) : any {
        if(((w != null && w instanceof <any>MACAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>MACAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof dottedString === 'string') || dottedString === null) && ((typeof spaceDelimitedString === 'string') || spaceDelimitedString === null) && ((typeof singleHex === 'string') || singleHex === null)) {
            super.testMACStrings(w, ipAddr, normalizedString, compressedString, canonicalString, dottedString, spaceDelimitedString, singleHex);
        } else if(((typeof w === 'string') || w === null) && ((typeof ipAddr === 'string') || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof dottedString === 'string') || dottedString === null) && ((typeof spaceDelimitedString === 'string') || spaceDelimitedString === null) && singleHex === undefined) {
            return <any>this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, compressedString, canonicalString, dottedString, spaceDelimitedString);
        } else throw new Error('invalid overload');
    }

    testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(addr : string, normalizedString : string, compressedString : string, canonicalString : string, dottedString : string, spaceDelimitedString : string, singleHex : string) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(addr);
        let ipAddr : MACAddress = w.getAddress();
        this.testMACStrings$inet_ipaddr_MACAddressString$inet_ipaddr_mac_MACAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, compressedString, canonicalString, dottedString, spaceDelimitedString, singleHex);
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testStrings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else if(w === undefined && ipAddr === undefined && normalizedString === undefined && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$();
        } else throw new Error('invalid overload');
    }

    testStrings$() {
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:e:f:a:b", "0a:0b:0c:0d:0e:0f:0a:0b", "a:b:c:d:e:f:a:b", "0a-0b-0c-0d-0e-0f-0a-0b", "0a0b.0c0d.0e0f.0a0b", "0a 0b 0c 0d 0e 0f 0a 0b", "0a0b0c0d0e0f0a0b");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ab:ab:bc:cd:De:ef", "ab:ab:bc:cd:de:ef", "ab:ab:bc:cd:de:ef", "ab-ab-bc-cd-de-ef", "abab.bccd.deef", "ab ab bc cd de ef", "ababbccddeef");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ab:AB:bc:cd:de:ef:aB:aB", "ab:ab:bc:cd:de:ef:ab:ab", "ab:ab:bc:cd:de:ef:ab:ab", "ab-ab-bc-cd-de-ef-ab-ab", "abab.bccd.deef.abab", "ab ab bc cd de ef ab ab", "ababbccddeefabab");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:0:0", "0a:0b:0c:0d:00:00", "a:b:c:d:0:0", "0a-0b-0c-0d-00-00", "0a0b.0c0d.0000", "0a 0b 0c 0d 00 00", "0a0b0c0d0000");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ff:00:10:01:10:11", "ff:00:10:01:10:11", "ff:0:10:1:10:11", "ff-00-10-01-10-11", "ff00.1001.1011", "ff 00 10 01 10 11", "ff0010011011");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0aa0bbb00cff", "0a:a0:bb:b0:0c:ff", "a:a0:bb:b0:c:ff", "0a-a0-bb-b0-0c-ff", "0aa0.bbb0.0cff", "0a a0 bb b0 0c ff", "0aa0bbb00cff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0aa0bb-b00cff", "0a:a0:bb:b0:0c:ff", "a:a0:bb:b0:c:ff", "0a-a0-bb-b0-0c-ff", "0aa0.bbb0.0cff", "0a a0 bb b0 0c ff", "0aa0bbb00cff");
    }

    testMACIPv6(ipv6 : string, mac : string) {
        let ipv6Str : IPAddressString = this.createAddress$java_lang_String(ipv6);
        let macStr : MACAddressString = this.createMACAddress$java_lang_String(mac);
        let addr : IPv6Address = ipv6Str.getAddress().toIPv6();
        let back : IPv6AddressSection = addr.getHostSection$int(64);
        if(!back.isEUI64()) {
            this.addFailure(new TestBase.Failure("eui 64 check " + back, back));
        } else {
            let macAddr : MACAddress = macStr.getAddress();
            let macBack : IPv6AddressSection = macAddr.toEUI64IPv6();
            let linkLocal : IPv6Address = macAddr.toLinkLocalIPv6();
            if(!linkLocal.isLinkLocal()) {
                this.addFailure(new TestBase.Failure("eui 64 conv link local " + macAddr, linkLocal));
            } else {
                if(!macBack.equals(back)) {
                    this.addFailure(new TestBase.Failure("eui 64 conv " + back, macBack));
                } else {
                    let macAddr64 : MACAddress = macAddr.toEUI64(false);
                    if(macAddr.isEUI64(true) || macAddr.isEUI64(false) || !macAddr64.isEUI64(false)) {
                        this.addFailure(new TestBase.Failure("mac eui test " + macAddr64, macAddr));
                    } else {
                        let backFromMac64 : IPv6AddressSection = new IPv6AddressSection(macAddr64);
                        if(!backFromMac64.equals(back)) {
                            this.addFailure(new TestBase.Failure("eui 64 conv 2" + back, backFromMac64));
                        } else {
                            let backFromMac : IPv6AddressSection = new IPv6AddressSection(macAddr);
                            if(!backFromMac.equals(back)) {
                                this.addFailure(new TestBase.Failure("eui 64 conv 3" + back, backFromMac));
                            } else {
                                let withPrefix : boolean = false;
                                do {
                                    let frontIpv6 : IPv6AddressSection = addr.getNetworkSection$int$boolean(64, withPrefix);
                                    if(withPrefix) {
                                        addr = addr.setPrefixLength$int$boolean(64, false);
                                    }
                                    let backLinkLocal : IPv6AddressSection = linkLocal.getHostSection$int(64);
                                    let backIpv6 : IPv6AddressSection = addr.getHostSection$int(64);
                                    let splitJoined1 : IPv6Address = new IPv6Address(frontIpv6, backIpv6.toEUI(true));
                                    let splitJoined2 : IPv6Address = new IPv6Address(frontIpv6, backIpv6.toEUI(false));
                                    let splitJoined3 : IPv6Address = new IPv6Address(frontIpv6.append(backIpv6));
                                    let other : MACAddressSection = new MACAddressSection(new MACAddressSegment(238));
                                    for(let j : number = 0; j < 2; j++) {
                                        let m : MACAddress;
                                        if(j === 0) {
                                            m = macAddr64;
                                        } else {
                                            m = macAddr;
                                        }
                                        for(let i : number = 0; i <= m.getSegmentCount(); i++) {
                                            let backSec : MACAddressSection = m.getSection$int$int(i, m.getSegmentCount());
                                            let frontSec : MACAddressSection = m.getSection$int$int(0, i);
                                            if(j === 1) {
                                                if(backSec.isEUI64$boolean(true) || backSec.isEUI64$boolean(false) || frontSec.isEUI64$boolean(true) || frontSec.isEUI64$boolean(false)) {
                                                    this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                }
                                                if(i >= 3) {
                                                    let frontSec2 : MACAddressSection = frontSec.toEUI64(false);
                                                    if(!frontSec2.isEUI64$boolean(false)) {
                                                        this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                    }
                                                }
                                                if(i <= 3) {
                                                    let backSec2 : MACAddressSection = backSec.toEUI64(false);
                                                    if(!backSec2.isEUI64$boolean(false)) {
                                                        this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                    }
                                                }
                                            } else {
                                                if(i < 4) {
                                                    if(backSec.isEUI64$boolean(true) || !backSec.isEUI64$boolean(false) || frontSec.isEUI64$boolean(true) || frontSec.isEUI64$boolean(false)) {
                                                        this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                    } else {
                                                        let backSec2 : MACAddressSection = backSec.replace$int$inet_ipaddr_mac_MACAddressSection(3 - i, other);
                                                        if(backSec2.isEUI64$boolean(false)) {
                                                            this.addFailure(new TestBase.Failure("eui 64 test " + backSec2, backSec2));
                                                        }
                                                    }
                                                } else if(i === 4) {
                                                    if(backSec.isEUI64$boolean(true) || backSec.isEUI64$boolean(false) || !backSec.isEUI64$boolean$boolean(false, true) || frontSec.isEUI64$boolean(true) || frontSec.isEUI64$boolean(false) || !frontSec.isEUI64$boolean$boolean(false, true)) {
                                                        this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                    } else {
                                                        backSec = backSec.toEUI64(false);
                                                        frontSec = frontSec.toEUI64(false);
                                                        if(!backSec.isEUI64$boolean$boolean(false, true) || backSec.isEUI64$boolean(false) || !frontSec.isEUI64$boolean$boolean(false, true) || frontSec.isEUI64$boolean(false)) {
                                                            this.addFailure(new TestBase.Failure("eui 64 test " + backSec, frontSec));
                                                        } else {
                                                            let frontSec2 : MACAddressSection = frontSec.replace$int$inet_ipaddr_mac_MACAddressSection(3, other);
                                                            let backSec2 : MACAddressSection = backSec.replace$int$inet_ipaddr_mac_MACAddressSection(4 - i, other);
                                                            if(backSec2.isEUI64$boolean$boolean(false, true) || frontSec2.isEUI64$boolean$boolean(false, true)) {
                                                                this.addFailure(new TestBase.Failure("eui 64 test " + backSec2, frontSec2));
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if(backSec.isEUI64$boolean(true) || backSec.isEUI64$boolean(false) || frontSec.isEUI64$boolean(true) || !frontSec.isEUI64$boolean(false)) {
                                                        this.addFailure(new TestBase.Failure("eui 64 test " + backSec, backSec));
                                                    } else {
                                                        let frontSec2 : MACAddressSection = frontSec.replace$int$inet_ipaddr_mac_MACAddressSection(4, other);
                                                        if(frontSec2.isEUI64$boolean(false)) {
                                                            this.addFailure(new TestBase.Failure("eui 64 test " + frontSec2, frontSec2));
                                                        }
                                                    }
                                                }
                                            }
                                            let backIpv6Sec : IPv6AddressSection = new IPv6AddressSection(backSec);
                                            let frontIpv6Sec : IPv6AddressSection = new IPv6AddressSection(frontSec);
                                            let both1 : IPv6AddressSection;
                                            let both2 : IPv6AddressSection;
                                            if((i % 2 === 0) || ((j === 1) && (i === 3))) {
                                                both1 = frontIpv6Sec.append(backIpv6Sec);
                                                both2 = frontIpv6Sec.append(backIpv6Sec);
                                            } else {
                                                let frontCount : number = frontIpv6Sec.getSegmentCount();
                                                let lastFront : IPv6AddressSection = frontIpv6Sec.getSection$int$int(frontCount - 1, frontCount);
                                                let frontBack : IPv6AddressSection = backIpv6Sec.getSection$int$int(0, 1);
                                                if(frontBack.isMultiple()) {
                                                    continue;
                                                }
                                                if(i === 1 && frontSec.getSegment(0).matchesWithMask$int$int(2, 2)) {
                                                    frontBack = frontBack.mask$inet_ipaddr_ipv6_IPv6AddressSection(new IPv6AddressSection(new IPv6AddressSegment(65023)));
                                                }
                                                let merged : IPv6AddressSection = lastFront.bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection(frontBack);
                                                let mergedAll : IPv6AddressSection = frontIpv6Sec.replace$int$inet_ipaddr_ipv6_IPv6AddressSection(frontCount - 1, merged);
                                                let backRes : IPv6AddressSection = backIpv6Sec.getSection$int$int(1, backIpv6Sec.getSegmentCount());
                                                both1 = mergedAll.append(backRes);
                                                both2 = mergedAll.append(backRes);
                                            }
                                            let both3 : IPv6AddressSection = backFromMac;
                                            let all : IPv6Address[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(14);
                                            all[0] = new IPv6Address(addr.getSection().replace$int$inet_ipaddr_ipv6_IPv6AddressSection(4, both1));
                                            all[1] = new IPv6Address(addr.getSection().replace$int$inet_ipaddr_ipv6_IPv6AddressSection(4, both2));
                                            all[2] = new IPv6Address(addr.getSection().replace$int$inet_ipaddr_ipv6_IPv6AddressSection(4, both3));
                                            all[3] = new IPv6Address(frontIpv6.append(both1));
                                            all[4] = new IPv6Address(frontIpv6.append(both2));
                                            all[5] = new IPv6Address(frontIpv6.append(both3));
                                            all[6] = new IPv6Address(frontIpv6.append(both1));
                                            all[7] = new IPv6Address(frontIpv6.append(both2));
                                            all[8] = new IPv6Address(frontIpv6.append(both3));
                                            all[9] = splitJoined1;
                                            all[10] = splitJoined2;
                                            all[11] = splitJoined3;
                                            all[12] = new IPv6Address(addr.getSection().replace$int$inet_ipaddr_ipv6_IPv6AddressSection(4, backLinkLocal));
                                            all[13] = new IPv6Address(frontIpv6.append(backLinkLocal));
                                            let set : Array<IPv6Address> = <any>([]);
                                            let prefix : number = all[0].getNetworkPrefixLength();
                                            for(let index163=0; index163 < all.length; index163++) {
                                                let one = all[index163];
                                                {
                                                    if(!Objects.equals(prefix, one.getNetworkPrefixLength())) {
                                                        this.addFailure(new TestBase.Failure("eui 64 conv set prefix is " + one.getNetworkPrefixLength() + " previous was " + prefix, one));
                                                    }
                                                    /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, one);
                                                }
                                            }
                                            if(/* size */(<number>set.length) !== 1) {
                                                this.addFailure(new TestBase.Failure("eui 64 conv set " + /* size */(<number>set.length) + ' ' + /* toString */('['+set.join(', ')+']')));
                                            }
                                            let treeSet : Array<IPv6Address> = <any>([]);
                                            for(let index164=0; index164 < all.length; index164++) {
                                                let one = all[index164];
                                                {
                                                    /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(treeSet, one);
                                                }
                                            }
                                            if(/* size */(<number>treeSet.length) !== 1) {
                                                this.addFailure(new TestBase.Failure("eui 64 conv set " + /* size */(<number>treeSet.length) + ' ' + /* toString */('['+treeSet.join(', ')+']')));
                                            }
                                        };
                                    };
                                    if(withPrefix || AddressNetwork.PrefixConfiguration["_$wrappers"][addr.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                                        break;
                                    }
                                    withPrefix = true;
                                } while((true));
                            }
                        }
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    public testInsertAndAppend$java_lang_String$java_lang_String$int_A(front : string, back : string, expectedPref : number[]) {
        let is : number[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(expectedPref.length);
        for(let i : number = 0; i < expectedPref.length; i++) {
            is[i] = expectedPref[i];
        };
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front, back, is);
    }

    public testInsertAndAppend(front? : any, back? : any, expectedPref? : any) : any {
        if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && ((expectedPref != null && expectedPref instanceof <any>Array && (expectedPref.length==0 || expectedPref[0] == null ||(typeof expectedPref[0] === 'number'))) || expectedPref === null)) {
            return <any>this.testInsertAndAppend$java_lang_String$java_lang_String$int_A(front, back, expectedPref);
        } else if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && ((expectedPref != null && expectedPref instanceof <any>Array && (expectedPref.length==0 || expectedPref[0] == null ||(typeof expectedPref[0] === 'number'))) || expectedPref === null)) {
            return <any>this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front, back, expectedPref);
        } else throw new Error('invalid overload');
    }

    testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front : string, back : string, expectedPref : number[]) {
        let f : MACAddress = this.createMACAddress$java_lang_String(front).getAddress();
        let b : MACAddress = this.createMACAddress$java_lang_String(back).getAddress();
        this.testAppendAndInsert(f, b, f.getSegmentStrings(), b.getSegmentStrings(), MACAddress.COLON_SEGMENT_SEPARATOR, expectedPref, true);
    }

    public testReplace(front? : any, back? : any, fronts? : any, backs? : any, sep? : any, isMac? : any) : any {
        if(((front != null && front instanceof <any>Address) || front === null) && ((back != null && back instanceof <any>Address) || back === null) && ((fronts != null && fronts instanceof <any>Array && (fronts.length==0 || fronts[0] == null ||(typeof fronts[0] === 'string'))) || fronts === null) && ((backs != null && backs instanceof <any>Array && (backs.length==0 || backs[0] == null ||(typeof backs[0] === 'string'))) || backs === null) && ((typeof sep === 'string') || sep === null) && ((typeof isMac === 'boolean') || isMac === null)) {
            super.testReplace(front, back, fronts, backs, sep, isMac);
        } else if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && fronts === undefined && backs === undefined && sep === undefined && isMac === undefined) {
            return <any>this.testReplace$java_lang_String$java_lang_String(front, back);
        } else throw new Error('invalid overload');
    }

    testReplace$java_lang_String$java_lang_String(front : string, back : string) {
        let f : MACAddress = this.createMACAddress$java_lang_String(front).getAddress();
        let b : MACAddress = this.createMACAddress$java_lang_String(back).getAddress();
        this.testReplace$inet_ipaddr_Address$inet_ipaddr_Address$java_lang_String_A$java_lang_String_A$char$boolean(f, b, f.getSegmentStrings(), b.getSegmentStrings(), MACAddress.COLON_SEGMENT_SEPARATOR, true);
    }

    testInvalidMACValues() {
        try {
            let bytes : number[] = [0, 0, 0, 0, 0, 0, 0, 0, 0];
            bytes[0] = 1;
            let addr : MACAddress = new MACAddress(bytes);
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new MACAddress([0, 0, 0, 0, 0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new MACAddress([0, 0, 0, 0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new MACAddress([0, 0, 0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new MACAddress([0, 0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new MACAddress([0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            let addr : MACAddress = new MACAddress(new MACAddressTest.MACAddressTest$0(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            let addr : MACAddress = new MACAddress(new MACAddressTest.MACAddressTest$1(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new MACAddress(new MACAddressTest.MACAddressTest$2(this));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
    }

    testMACValues$int_A$java_lang_String(segs : number[], decimal : string) {
        this.testMACValues$int_A$java_lang_String$java_lang_String(segs, decimal, null);
    }

    public testMACValues$int_A$java_lang_String$java_lang_String(segs : number[], decimal : string, negativeDecimal : string) {
        let vals : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segs.length);
        let strb : { str: string } = { str: "", toString: function() { return this.str; } };
        let longval : number = 0;
        let bigInteger : BigInteger = BigInteger.ZERO;
        let bitsPerSegment : number = MACAddress.BITS_PER_SEGMENT;
        for(let i : number = 0; i < segs.length; i++) {
            let seg : number = segs[i];
            if(/* length */strb.str.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>':'); return sb; })(strb);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>javaemul.internal.IntegerHelper.toHexString(seg)); return sb; })(strb);
            vals[i] = (<number>seg|0);
            longval = (longval << bitsPerSegment) | seg;
            bigInteger = bigInteger.shiftLeft(bitsPerSegment).add(BigInteger.valueOf(seg));
        };
        let addr : MACAddress[] = [null, null, null];
        let i : number = 0;
        addr[i++] = this.createMACAddress$byte_A(vals);
        addr[i++] = this.createMACAddress$java_lang_String(/* toString */strb.str).getAddress();
        addr[i++] = this.createMACAddress$long$boolean(longval, segs.length === 8);
        for(let j : number = 0; j < addr.length; j++) {
            for(let k : number = j; k < addr.length; k++) {
                if(!addr[k].equals(addr[j]) || !addr[j].equals(addr[k])) {
                    this.addFailure(new TestBase.Failure("failed equals: " + addr[k] + " and " + addr[j]));
                }
            };
        };
        if(decimal != null) {
            for(i = 0; i < addr.length; i++) {
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(decimal,addr[i].getValue().toString()))) {
                    this.addFailure(new TestBase.Failure("failed equals: " + addr[i].getValue() + " and " + decimal));
                }
                let longVal : number = addr[i].longValue();
                if(longVal < 0) {
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(/* valueOf */new String(longVal).toString(),negativeDecimal))) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[i].longValue() + " and " + decimal));
                    }
                } else if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(decimal,/* valueOf */new String(longVal).toString()))) {
                    this.addFailure(new TestBase.Failure("failed equals: " + addr[i].longValue() + " and " + decimal));
                }
            };
        }
    }

    public testMACValues(segs? : any, decimal? : any, negativeDecimal? : any) : any {
        if(((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(typeof segs[0] === 'number'))) || segs === null) && ((typeof decimal === 'string') || decimal === null) && ((typeof negativeDecimal === 'string') || negativeDecimal === null)) {
            return <any>this.testMACValues$int_A$java_lang_String$java_lang_String(segs, decimal, negativeDecimal);
        } else if(((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(typeof segs[0] === 'number'))) || segs === null) && ((typeof decimal === 'string') || decimal === null) && negativeDecimal === undefined) {
            return <any>this.testMACValues$int_A$java_lang_String(segs, decimal);
        } else throw new Error('invalid overload');
    }

    public testIncrement(orig? : any, increment? : any, expectedResult? : any, first? : any) : any {
        if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && ((typeof first === 'boolean') || first === null)) {
            super.testIncrement(orig, increment, expectedResult, first);
        } else if(((typeof orig === 'string') || orig === null) && ((typeof increment === 'number') || increment === null) && ((typeof expectedResult === 'string') || expectedResult === null) && first === undefined) {
            return <any>this.testIncrement$java_lang_String$long$java_lang_String(orig, increment, expectedResult);
        } else if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && first === undefined) {
            return <any>this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(orig, increment, expectedResult);
        } else throw new Error('invalid overload');
    }

    testIncrement$java_lang_String$long$java_lang_String(originalStr : string, increment : number, resultStr : string) {
        this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(this.createMACAddress$java_lang_String(originalStr).getAddress(), increment, resultStr == null?null:this.createMACAddress$java_lang_String(resultStr).getAddress());
    }

    isLenient() : boolean {
        return false;
    }

    allowsRange() : boolean {
        return false;
    }

    /**
     * 
     */
    runTest() {
        this.mactest$boolean$java_lang_String(true, "aa:b:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aaa:b:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:bbb:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:bb:ccc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:ddd:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:eee:f");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:fff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:ff:eee:aa");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:ff:ee:aaa");
        this.mactest$boolean$java_lang_String(true, "aa:bb:cc:dd:ee:ff:ee:aa");
        this.mactest$boolean$java_lang_String(false, "0xaa:b:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:0xb:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:b:0xcc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:b:cx:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:b:cx:d:ee:fg");
        this.mactest$boolean$java_lang_String(true, "aa-b-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aaa-b-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-bbb-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-bb-ccc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-ddd-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-eee-f");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee-fff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee-ff-eee-aa");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee-ff-ee-aaa");
        this.mactest$boolean$java_lang_String(true, "aa-bb-cc-dd-ee-ff-ee-aa");
        this.mactest$boolean$java_lang_String(false, "0xaa-b-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "xaa-b-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-b-cc-d-ee-0xf");
        this.mactest$boolean$java_lang_String(false, "aa-b-cc-d-ee-0xff");
        this.mactest$boolean$java_lang_String(false, "aa-0xb-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-b-cx-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-b-0xc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-b-cx-d-ee-fg");
        this.mactest$boolean$java_lang_String(true, "aabb.ccdd.eeff");
        this.mactest$boolean$java_lang_String(false, "aabbc.ccdd.eeff");
        this.mactest$boolean$java_lang_String(false, "aabb.ccddc.eeff");
        this.mactest$boolean$java_lang_String(false, "aabb.ccdd.eeffc");
        this.mactest$boolean$java_lang_String(false, "aabb.ccdd.eeff.ccdde");
        this.mactest$boolean$java_lang_String(true, "aabb.ccdd.eeff.ccde");
        this.mactest$boolean$java_lang_String(false, "aabb.ccdd.eeff.0xccdd");
        this.mactest$boolean$java_lang_String(false, "0xaabb.ccdd.eeff.ccdd");
        this.mactest$boolean$java_lang_String(false, "aabb.0xccdd.eeff.ccdd");
        this.mactest$boolean$java_lang_String(false, "aabb.ccgd.eeff.ccdd");
        this.mactest$boolean$java_lang_String(true, "1:2:3:4:5:6");
        this.mactest$boolean$java_lang_String(true, "11:22:33:44:55:66");
        this.mactest$boolean$java_lang_String(false, "11:22:33:444:55:66");
        this.mactest$boolean$java_lang_String(false, "aa:x:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(false, "aa:g:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:-1:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:-dd:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:1-:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "-1:aa:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "1-:aa:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:cc:d:ee:f:1-");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:0-1:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa:1-ff:cc:d:ee:f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-|1-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "|1-aa-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-1|-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "1|-aa-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-0|1-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-1|ff-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-ff-cc|dd-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-||1-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(false, "aa-1||-cc-d-ee-f");
        this.mactest$boolean$java_lang_String(true, "a:bb:c:dd:e:ff");
        this.mactest$boolean$java_lang_String(true, "aa:bb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd::ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb::dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb-cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(true, "aabbcc-ddeeff");
        this.mactest$boolean$java_lang_String(false, "aaabbcc-ddeeff");
        this.mactest$boolean$java_lang_String(false, "aabbcc-ddeefff");
        this.mactest$boolean$java_lang_String(false, "aabbcc-ddeeffff");
        this.mactest$boolean$java_lang_String(false, "aabbcc-ddeefffff");
        this.mactest$boolean$java_lang_String(true, "aabbcc-ddeeffffff");
        this.mactest$boolean$java_lang_String(false, "aaabbcc-ddeeffffff");
        this.mactest$boolean$java_lang_String(false, "aaaabbcc-ddeeffffff");
        this.mactest$boolean$java_lang_String(false, "aaaaaabbcc-ddeeffffff");
        this.mactest$boolean$java_lang_String(false, "aaabbcc-ddeeffff");
        this.mactest$boolean$java_lang_String(false, "aabbcc.ddeeff");
        this.mactest$boolean$java_lang_String(false, "aabbcc:ddeeff");
        this.mactest$boolean$java_lang_String(false, "aabbcc ddeeff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc dd-ee-ff");
        this.mactest$boolean$java_lang_String(false, "aa bb cc dd ee-ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa bb cc dd ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc:dd-ee-ff");
        this.mactest$boolean$java_lang_String(false, "aa.b.cc.d.ee.f");
        this.mactest$boolean$java_lang_String(false, "aa.bb.cc.dd.ee.ff");
        this.mactest$boolean$java_lang_String(false, "aa.bb.cc dd.ee.ff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd:ee-ff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee:-ff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd-ee--ff");
        this.mactest$boolean$java_lang_String(false, "aa-bb-cc-dd--ee");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:ff:");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:ff:aa");
        this.mactest$boolean$java_lang_String(false, "ff:aa:bb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(true, "aa:bb:cc:dd:ee:ff:aa:bb");
        this.mactest$boolean$java_lang_String(true, "ee:ff:aa:bb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, ":aa:bb:cc:dd:ee:ff:aa:bb");
        this.mactest$boolean$java_lang_String(false, "ee:ff:aa:bb:cc:dd:ee:ff:");
        this.mactest$boolean$java_lang_String(false, "aa:aa:bb:cc:dd:ee:ff:aa:bb");
        this.mactest$boolean$java_lang_String(false, "ee:ff:aa:bb:cc:dd:ee:ff:ee");
        this.mactest$boolean$java_lang_String(false, ":aa:bb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd.ee:ff");
        this.mactest$boolean$java_lang_String(false, "aaa:bb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bbb:cc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:ccc:dd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:ddd:ee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:eee:ff");
        this.mactest$boolean$java_lang_String(false, "aa:bb:cc:dd:ee:fff");
        this.testNormalized("A:B:C:D:E:F:A:B", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("AB:AB:CC:Dd:Ee:fF:aA:Bb", "ab:ab:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12:CD:CC:dd:Ee:fF:AA:Bb", "12:cd:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12:CD:CC:dd:Ee:fF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("0:0:0:0:0:0:0:0", "00:00:00:00:00:00:00:00");
        this.testNormalized("0:0:0:0:0:0", "00:00:00:00:00:00");
        this.testNormalized("0:1:0:2:0:3:0:0", "00:01:00:02:00:03:00:00");
        this.testNormalized("0:1:0:2:0:3", "00:01:00:02:00:03");
        this.testNormalized("A-B-C-D-E-F-A-B", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("AB-AB-CC-Dd-Ee-fF-aA-Bb", "ab:ab:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12-CD-CC-dd-Ee-fF-AA-Bb", "12:cd:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12-CD-CC-dd-Ee-fF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("0-0-0-0-0-0-0-0", "00:00:00:00:00:00:00:00");
        this.testNormalized("0-0-0-0-0-0", "00:00:00:00:00:00");
        this.testNormalized("0-1-0-2-0-3-0-0", "00:01:00:02:00:03:00:00");
        this.testNormalized("0-1-0-2-0-3", "00:01:00:02:00:03");
        this.testNormalized("A B C D E F A B", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("AB AB CC Dd Ee fF aA Bb", "ab:ab:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12 CD CC dd Ee fF AA Bb", "12:cd:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12 CD CC dd Ee fF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("0 0 0 0 0 0 0 0", "00:00:00:00:00:00:00:00");
        this.testNormalized("0 0 0 0 0 0", "00:00:00:00:00:00");
        this.testNormalized("0 1 0 2 0 3 0 0", "00:01:00:02:00:03:00:00");
        this.testNormalized("0 1 0 2 0 3", "00:01:00:02:00:03");
        this.testNormalized("0A0B.0C0D.0E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("A0B.C0D.E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("AB.C00.DE0F", "00:ab:0c:00:de:0f");
        this.testNormalized("A0.B00.c00d", "00:a0:0b:00:c0:0d");
        this.testNormalized("0A0B.0C0D.0E0F.0a0b", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("A0B.C0D.E0F.1234", "0a:0b:0c:0d:0e:0f:12:34");
        this.testNormalized("AB.C00.DE0F.123", "00:ab:0c:00:de:0f:01:23");
        this.testNormalized("A0.B00.c00d.4", "00:a0:0b:00:c0:0d:00:04");
        this.testNormalized("12CD.CCdd.EefF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("0000.0000.0000", "00:00:00:00:00:00");
        this.testNormalized("0002.0003.0003", "00:02:00:03:00:03");
        this.testNormalized("0A0B0C-0D0E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("0A0B0C-0D0E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("0A0B0C-0D0E0F0A0B", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("ABABCC-DdEefFaABb", "ab:ab:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12CDCC-ddEefFAABb", "12:cd:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12CDCC-ddEefF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("aaaabb-bbcccc", "aa:aa:bb:bb:cc:cc");
        this.testNormalized("010233045506", "01:02:33:04:55:06");
        this.testNormalized("000000-0000000000", "00:00:00:00:00:00:00:00");
        this.testNormalized("000000-000000", "00:00:00:00:00:00");
        this.testNormalized("000100-0200030000", "00:01:00:02:00:03:00:00");
        this.testNormalized("000100-020003", "00:01:00:02:00:03");
        this.testNormalized("0A0B0C0D0E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("0x0A0B0C0D0E0F", "0a:0b:0c:0d:0e:0f");
        this.testNormalized("0A0B0C0D0E0F0A0B", "0a:0b:0c:0d:0e:0f:0a:0b");
        this.testNormalized("ABABCCDdEefFaABb", "ab:ab:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12CDCCddEefFAABb", "12:cd:cc:dd:ee:ff:aa:bb");
        this.testNormalized("12CDCCddEefF", "12:cd:cc:dd:ee:ff");
        this.testNormalized("0000000000000000", "00:00:00:00:00:00:00:00");
        this.testNormalized("000000000000", "00:00:00:00:00:00");
        this.testNormalized("0001000200030000", "00:01:00:02:00:03:00:00");
        this.testNormalized("000100020003", "00:01:00:02:00:03");
        this.testCanonical("A:B:C:D:E:F:A:B", "0a-0b-0c-0d-0e-0f-0a-0b");
        this.testCanonical("AB:AB:CC:Dd:Ee:fF:aA:Bb", "ab-ab-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12:CD:CC:dd:Ee:fF:AA:Bb", "12-cd-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12:CD:CC:dd:Ee:fF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("0:0:0:0:0:0:0:0", "00-00-00-00-00-00-00-00");
        this.testCanonical("0:0:0:0:0:0", "00-00-00-00-00-00");
        this.testCanonical("0:1:0:2:0:3:0:0", "00-01-00-02-00-03-00-00");
        this.testCanonical("0:1:0:2:0:3", "00-01-00-02-00-03");
        this.testCanonical("A-B-C-D-E-F-A-B", "0a-0b-0c-0d-0e-0f-0a-0b");
        this.testCanonical("AB-AB-CC-Dd-Ee-fF-aA-Bb", "ab-ab-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12-CD-CC-dd-Ee-fF-AA-Bb", "12-cd-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12-CD-CC-dd-Ee-fF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("0-0-0-0-0-0-0-0", "00-00-00-00-00-00-00-00");
        this.testCanonical("0-0-0-0-0-0", "00-00-00-00-00-00");
        this.testCanonical("0-1-0-2-0-3-0-0", "00-01-00-02-00-03-00-00");
        this.testCanonical("0-1-0-2-0-3", "00-01-00-02-00-03");
        this.testCanonical("A B C D E F A B", "0a-0b-0c-0d-0e-0f-0a-0b");
        this.testCanonical("AB AB CC Dd Ee fF aA Bb", "ab-ab-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12 CD CC dd Ee fF AA Bb", "12-cd-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12 CD CC dd Ee fF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("0 0 0 0 0 0 0 0", "00-00-00-00-00-00-00-00");
        this.testCanonical("0 0 0 0 0 0", "00-00-00-00-00-00");
        this.testCanonical("0 1 0 2 0 3 0 0", "00-01-00-02-00-03-00-00");
        this.testCanonical("0 1 0 2 0 3", "00-01-00-02-00-03");
        this.testCanonical("0A0B.0C0D.0E0F", "0a-0b-0c-0d-0e-0f");
        this.testCanonical("BA0B.DC0D.FE0F", "ba-0b-dc-0d-fe-0f");
        this.testCanonical("A0B.C0D.E0F", "0a-0b-0c-0d-0e-0f");
        this.testCanonical("AB.C00.DE0F", "00-ab-0c-00-de-0f");
        this.testCanonical("A.B.c", "00-0a-00-0b-00-0c");
        this.testCanonical("12CD.CCdd.EefF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("0000.0000.0000", "00-00-00-00-00-00");
        this.testCanonical("0002.0003.0003", "00-02-00-03-00-03");
        this.testCanonical("0020.0030.0030", "00-20-00-30-00-30");
        this.testCanonical("0A0B0C-0D0E0F", "0a-0b-0c-0d-0e-0f");
        this.testCanonical("0A0B0C-0D0E0F0A0B", "0a-0b-0c-0d-0e-0f-0a-0b");
        this.testCanonical("ABABCC-DdEefFaABb", "ab-ab-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12CDCC-ddEefFAABb", "12-cd-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12CDCC-ddEefF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("000000-0000000000", "00-00-00-00-00-00-00-00");
        this.testCanonical("000000-000000", "00-00-00-00-00-00");
        this.testCanonical("000100-0200030000", "00-01-00-02-00-03-00-00");
        this.testCanonical("000100-020003", "00-01-00-02-00-03");
        this.testCanonical("0A0B0C0D0E0F", "0a-0b-0c-0d-0e-0f");
        this.testCanonical("0A0B0C0D0E0F0A0B", "0a-0b-0c-0d-0e-0f-0a-0b");
        this.testCanonical("ABABCCDdEefFaABb", "ab-ab-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12CDCCddEefFAABb", "12-cd-cc-dd-ee-ff-aa-bb");
        this.testCanonical("12CDCCddEefF", "12-cd-cc-dd-ee-ff");
        this.testCanonical("0000000000000000", "00-00-00-00-00-00-00-00");
        this.testCanonical("000000000000", "00-00-00-00-00-00");
        this.testCanonical("0001000200030000", "00-01-00-02-00-03-00-00");
        this.testCanonical("000100020003", "00-01-00-02-00-03");
        this.testMatches(true, "0A0B0C0D0E0F", "0a0b0c-0d0e0f");
        this.testMatches(true, "0A0B0C0D0E0F", "0a:0b:0c:0d:0e:0f");
        this.testMatches(true, "0A 0B 0C 0D 0E 0F", "0a:0b:0c:0d:0e:0f");
        this.testMatches(true, "0A 0B 0C 0D 0E 0F", "0a-0b-0c-0d-0e-0f");
        this.testMatches(true, "0A 0B 0C 0D 0E 0F", "a-b-c-d-e-f");
        this.testMatches(false, "0A 0B 0C 0D 0E 0F", "a-b-c-d-e-f-a-b");
        this.testMatches(true, "0A0B.0C0D.0E0F", "0a:0b:0c:0d:0e:0f");
        this.testMatches(false, "0A0B.1C0D.0E0F", "0a:0b:0c:0d:0e:0f");
        this.testMatches(false, "0A0B.1C0D.0E0F", "aa:bb:0a:0b:0c:0d:0e:0f");
        this.testReverse$java_lang_String$boolean$boolean("1:2:3:4:5:6", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:2:2:3:3", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:1:1:1:1", false, false);
        this.testReverse$java_lang_String$boolean$boolean("0:0:0:0:0:0", true, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:ff:ff:ff:ff:ff", true, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:ff:ff:ff:ff:ff:ff:ff", true, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:80:ff:ff:01:ff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ff:81:ff:ff:ff:ff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:81:c3:42:24:ff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:1:ff:ff:ff:ff", false, false);
        this.testReverse$java_lang_String$boolean$boolean("11:22:33:44:55:66", false, false);
        this.testReverse$java_lang_String$boolean$boolean("11:11:22:22:33:33", false, false);
        this.testReverse$java_lang_String$boolean$boolean("11:11:22:22:33:33:44:55", false, false);
        this.testReverse$java_lang_String$boolean$boolean("11:11:11:11:11:11:11:11", false, false);
        this.testReverse$java_lang_String$boolean$boolean("0:0:0:0:0:0:00:00", true, true);
        this.testDelimitedCount("1,2-3-4,5-6-7-8", 4);
        this.testDelimitedCount("1,2-3,6-7-8-4,5-6,8", 16);
        this.testDelimitedCount("1:2:3:6:4:5", 1);
        this.testDelimitedCount("1:2,3,4:3:6:4:5,ff,7,8,99", 15);
        this.testLongShort$java_lang_String$java_lang_String("ff:ff:ff:ff:ff:ff:ff:ff", "ff:ff:ff:ff:ff:ff");
        this.testLongShort$java_lang_String$java_lang_String("12-cd-cc-dd-ee-ff-aa-bb", "12-cd-cc-dd-ee-ff");
        this.testLongShort$java_lang_String$java_lang_String("12CD.CCdd.EefF.a", "12CD.EefF.a");
        this.testLongShort$java_lang_String$java_lang_String("0A0B0C-0D0E0F0A0B", "0A0B0C-0D0E0F");
        this.testLongShort$java_lang_String$java_lang_String("ee:ff:aa:bb:cc:dd:ee:ff", "ee:ff:aa:bb:cc:dd");
        this.testLongShort$java_lang_String$java_lang_String("e:f:a:b:c:d:e:f", "e:f:a:b:c:d");
        this.mactest$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "00:0:0:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0:00:0:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0:0:00:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0:0:0:00:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0:0:0:0:00:0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0:0:0:0:0:00", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "000:0:0:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:000:0:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:000:0:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:000:0:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:000:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:000", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:000:0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:0:000", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "000:000:000:000", true);
        this.mactest$boolean$java_lang_String$boolean(true, "00.0.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.00.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.0.00", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.0.0.00", true);
        this.mactest$boolean$java_lang_String$boolean(true, "000.0.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.000.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.00.000", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0000.0.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.0000.0", true);
        this.mactest$boolean$java_lang_String$boolean(true, "0.00.0000", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "00000.0.0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0.00000.0", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "0.0.00000", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "00000.00000.00000", true);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "00000.00000.00000.00000", true);
        this.mactest$boolean$java_lang_String$boolean(true, "3:3:3:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "33:3:3:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3:33:3:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3:3:33:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3:3:3:33:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3:3:3:3:33:3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3:3:3:3:3:33", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "033:3:3:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:033:3:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:033:3:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:3:033:3:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:3:3:033:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:3:3:3:033", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:3:3:3:3:033:3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3:3:3:3:3:3:3:033", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "033:033:033:033", false);
        this.mactest$boolean$java_lang_String$boolean(true, "33.3.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.33.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.3.33", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.3.3.33", false);
        this.mactest$boolean$java_lang_String$boolean(true, "333.3.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.333.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.33.333", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3333.3.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.3333.3", false);
        this.mactest$boolean$java_lang_String$boolean(true, "3.33.3333", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "03333.3.3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3.03333.3", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "3.3.03333", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "03333.03333.03333", false);
        this.mactest$boolean$java_lang_String$boolean(this.isLenient(), "03333.03333.03333.03333", false);
        this.testMACIPv6("aaaa:bbbb:cccc:dddd:0221:2fff:feb5:6e10", "00:21:2f:b5:6e:10");
        this.testMACIPv6("fe80::0e3a:bbff:fe2a:cd23", "0c:3a:bb:2a:cd:23");
        this.testMACIPv6("ffff:ffff:ffff:ffff:3BA7:94FF:FE07:CBD0", "39-A7-94-07-CB-D0");
        this.testMACIPv6("FE80::212:7FFF:FEEB:6B40", "0012.7feb.6b40");
        this.testMACIPv6("2001:DB8::212:7FFF:FEEB:6B40", "0012.7feb.6b40");
        this.testContains("1.2.3.4", "1.2.3.4", true);
        this.testContains("1111.2222.3333", "1111.2222.3333", true);
        this.testNotContains("1111.2222.3333", "1111.2222.3233");
        this.testContains("a:b:c:d:e:f:a:b", "a:b:c:d:e:f:a:b", true);
        this.testFromBytes([-1, -1, -1, -1, -1, -1], "ff:ff:ff:ff:ff:ff");
        this.testFromBytes([1, 2, 3, 4, 5, 6], "1:2:3:4:5:6");
        this.testFromBytes([18, 127, 15, 127, 122, 123], "12:7f:f:7f:7a:7b");
        this.testFromBytes([0, 0, 0, 0, 0, 0, 0, 0], "0-0-0-0-0-0-0-0");
        this.testFromBytes([0, 0, 0, 1, 0, 0, 0, 1], "0-0-0-1-0-0-0-1");
        this.testFromBytes([10, 11, 12, 13, 14, 15, 1, 2], "a:b:c:d:e:f:1:2");
        this.testSections("00:21:2f:b5:6e:10");
        this.testSections("39-A7-94-07-CB-D0");
        this.testSections("0012.7feb.6b40");
        this.testSections("fe:ef:00:21:2f:b5:6e:10");
        this.testSections("fe-ef-39-A7-94-07-CB-D0");
        this.testSections("1234.0012.7feb.6b40");
        this.testRadices("11:10:ff:7f:f3:2", "10001:10000:11111111:1111111:11110011:10", 2);
        this.testRadices("2:fe:7f:ff:10:11", "10:11111110:1111111:11111111:10000:10001", 2);
        this.testRadices("5:10:5:10:5:10", "101:10000:101:10000:101:10000", 2);
        this.testRadices("0:1:0:1:0:1:0:1", "0:1:0:1:0:1:0:1", 2);
        this.testRadices("1:0:1:0:1:0:1:0", "1:0:1:0:1:0:1:0", 2);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 2);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 2);
        this.testRadices("ff:7f:fe:2:7f:fe", "ff:7f:fe:2:7f:fe", 16);
        this.testRadices("2:fe:7f:ff:7f:fe", "2:fe:7f:ff:7f:fe", 16);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 16);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 16);
        this.testRadices("ff:7f:fe:2:7f:fe", "255:127:254:2:127:254", 10);
        this.testRadices("2:fe:7f:ff:7f:fe", "2:254:127:255:127:254", 10);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 10);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 10);
        this.testRadices("ff:7f:fe:2:7f:fe", "513:241:512:2:241:512", 7);
        this.testRadices("2:fe:7f:ff:7f:fe", "2:512:241:513:241:512", 7);
        this.testRadices("0:1:0:1:0:1:0:1", "0:1:0:1:0:1:0:1", 7);
        this.testRadices("1:0:1:0:1:0:1:0", "1:0:1:0:1:0:1:0", 7);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 7);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 7);
        this.testRadices("ff:7f:fe:2:7f:fe", "377:177:376:2:177:376", 8);
        this.testRadices("2:fe:7f:ff:7f:fe", "2:376:177:377:177:376", 8);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 8);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 8);
        this.testRadices("ff:7f:fe:2:7f:fe", "120:87:11e:2:87:11e", 15);
        this.testRadices("2:fe:7f:ff:7f:fe", "2:11e:87:120:87:11e", 15);
        this.testRadices("0:1:0:1:0:1", "0:1:0:1:0:1", 15);
        this.testRadices("1:0:1:0:1:0", "1:0:1:0:1:0", 15);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8", [null, null, null, null, null, null, null, null, null]);
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8");
        this.testStrings();
        this.testInvalidMACValues();
        this.testMACValues$int_A$java_lang_String([1, 2, 3, 4, 5, 6], "1108152157446");
        this.testMACValues$int_A$java_lang_String([1, 2, 3, 4, 5, 6, 7, 8], "72623859790382856");
        this.testMACValues$int_A$java_lang_String([0, 0, 0, 0, 0, 0, 0, 0], "0");
        this.testMACValues$int_A$java_lang_String([0, 0, 0, 0, 0, 0], "0");
        this.testMACValues$int_A$java_lang_String([255, 255, 255, 255, 255, 255], /* valueOf */new String(281474976710655).toString());
        let thirtyTwo : BigInteger = BigInteger.valueOf(4294967295);
        let sixty4 : BigInteger = thirtyTwo.shiftLeft(32).or(thirtyTwo);
        this.testMACValues$int_A$java_lang_String$java_lang_String([255, 255, 255, 255, 255, 255, 255, 255], sixty4.toString(), /* valueOf */new String(-1).toString());
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:f0:0:0:0", 1, "ff:ff:ff:ff:f0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:f0:0:0:0", -1, "ff:ff:ff:ff:ef:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:f0:0:0:0", 1, "ff:ff:f0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:f0:0:0:0", -1, "ff:ff:ef:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("80:0:0:0:0:0:0:0", Number.MIN_VALUE, "0:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("7f:ff:ff:ff:ff:ff:ff:ff", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("7f:ff:ff:ff:ff:ff:ff:fe", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:80:0:0:0", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("80:0:0:0:0:0:0:0", Number.MAX_VALUE, "ff:ff:ff:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("80:0:0:0:0:0:0:1", Number.MAX_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:80:0:0:0", -2147483648, "ff:ff:ff:ff:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:7f:ff:ff:ff", -2147483648, "ff:ff:ff:fe:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:7f:ff:ff:fe", -2147483648, "ff:ff:ff:fe:ff:ff:ff:fe");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:80:0:0:0", -2147483648, "0:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:7f:ff:ff:ff", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:7f:ff:ff:ff", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:7f:ff:ff:fe", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:80:0:0:0", 2147483647, "ff:ff:ff:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:80:0:0:1", 2147483647, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:80:0:0:0", -2147483648, "ff:ff:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:7f:ff:ff:ff", -2147483648, "ff:fe:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:7f:ff:ff:fe", -2147483648, "ff:fe:ff:ff:ff:fe");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:80:0:0:0", -2147483648, "0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:7f:ff:ff:ff", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:7f:ff:ff:ff", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:7f:ff:ff:fe", -2147483648, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:80:0:0:0", 2147483647, "ff:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:80:0:0:1", 2147483647, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:1", 1, "0:0:0:0:0:0:0:2");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:1", 0, "0:0:0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:1", -1, "0:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:1", -2, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:2", 1, "0:0:0:0:0:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:2", -1, "0:0:0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:2", -2, "0:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:2", -3, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:1", 1, "0:0:0:0:0:2");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:1", 0, "0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:1", -1, "0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:1", -2, null);
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:2", 1, "0:0:0:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:2", -1, "0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:2", -2, "0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:2", -3, null);
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:1", 0, "1:0:0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:1", 1, "1:0:0:0:0:0:0:2");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:1", -1, "1:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:1", -2, "0:ff:ff:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:2", 1, "1:0:0:0:0:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:2", -1, "1:0:0:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:2", -2, "1:0:0:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:0:0:2", -3, "0:ff:ff:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:1", 0, "1:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:1", 1, "1:0:0:0:0:2");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:1", -1, "1:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:1", -2, "0:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:2", 1, "1:0:0:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:2", -1, "1:0:0:0:0:1");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:2", -2, "1:0:0:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("1:0:0:0:0:2", -3, "0:ff:ff:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:fe", 2, "0:0:0:0:0:0:1:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:0:ff", 2, "0:0:0:0:0:0:1:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:1:ff", 2, "0:0:0:0:0:0:2:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:1:ff", -2, "0:0:0:0:0:0:1:fd");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:1:ff", -256, "0:0:0:0:0:0:0:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:0:1:ff", -257, "0:0:0:0:0:0:0:fe");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:fe", 2, "0:0:0:0:1:0");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:ff", 2, "0:0:0:0:1:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:1:ff", 2, "0:0:0:0:2:1");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:1:ff", -2, "0:0:0:0:1:fd");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:1:ff", -256, "0:0:0:0:0:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:1:ff", -257, "0:0:0:0:0:fe");
    }
}
MACAddressTest["__class"] = "inet.ipaddr.test.MACAddressTest";


export namespace MACAddressTest {

    export class MACAddressStringKey extends TestBase.LookupKey<MACAddressStringParameters> {
        static __inet_ipaddr_test_MACAddressTest_MACAddressStringKey_serialVersionUID : number = 4;

        static comparator : any; public static comparator_$LI$() : any { if(MACAddressStringKey.comparator == null) MACAddressStringKey.comparator = (arg0, arg1) => { return new LookupKey.LookupKeyComparator<MACAddressStringParameters>().compare(arg0, arg1); }; return MACAddressStringKey.comparator; };

        public constructor(x : string, opts : MACAddressStringParameters = null) {
            super(x, opts);
        }

        public compareOptions$inet_ipaddr_MACAddressStringParameters(otherOptions : MACAddressStringParameters) : number {
            return Objects.compare<any>(this.options, otherOptions, <any>(MACAddressStringKey.comparator_$LI$()));
        }

        /**
         * 
         * @param {MACAddressStringParameters} otherOptions
         * @return {number}
         */
        public compareOptions(otherOptions? : any) : any {
            if(((otherOptions != null && otherOptions instanceof <any>MACAddressStringParameters) || otherOptions === null)) {
                return <any>this.compareOptions$inet_ipaddr_MACAddressStringParameters(otherOptions);
            } else if(((otherOptions != null) || otherOptions === null)) {
                return <any>this.compareOptions$java_lang_Comparable(otherOptions);
            } else throw new Error('invalid overload');
        }
    }
    MACAddressStringKey["__class"] = "inet.ipaddr.test.MACAddressTest.MACAddressStringKey";
    MACAddressStringKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class MACAddressLongKey {
        static serialVersionUID : number = 4;

        val : number;

        extended : boolean;

        constructor(val : number, extended : boolean) {
            if(this.val===undefined) this.val = 0;
            if(this.extended===undefined) this.extended = false;
            this.val = val;
            this.extended = extended;
        }

        /**
         * 
         * @param {MACAddressTest.MACAddressLongKey} o
         * @return {number}
         */
        public compareTo(o : MACAddressTest.MACAddressLongKey) : number {
            let res : number = javaemul.internal.BooleanHelper.compare(this.extended, o.extended);
            if(res === 0) {
                res = /* compare */(this.val - o.val);
            }
            return res;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>MACAddressTest.MACAddressLongKey) {
                return this.val === (<MACAddressTest.MACAddressLongKey>o).val && this.extended === (<MACAddressTest.MACAddressLongKey>o).extended;
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            return javaemul.internal.LongHelper.hashCode(this.val);
        }
    }
    MACAddressLongKey["__class"] = "inet.ipaddr.test.MACAddressTest.MACAddressLongKey";
    MACAddressLongKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class MACAddressKey {
        static serialVersionUID : number = 4;

        bytes : number[];

        constructor(bytes : number[]) {
            if(this.bytes===undefined) this.bytes = null;
            this.bytes = bytes;
        }

        /**
         * 
         * @param {MACAddressTest.MACAddressKey} o
         * @return {number}
         */
        public compareTo(o : MACAddressTest.MACAddressKey) : number {
            let comparison : number = this.bytes.length - this.bytes.length;
            if(comparison === 0) {
                for(let i : number = 0; i < this.bytes.length; i++) {
                    comparison = this.bytes[i] = o.bytes[i];
                    if(comparison !== 0) {
                        break;
                    }
                };
            }
            return comparison;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>MACAddressTest.MACAddressKey) {
                return /* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(this.bytes, (<MACAddressTest.MACAddressKey>o).bytes);
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(Arrays));
        }
    }
    MACAddressKey["__class"] = "inet.ipaddr.test.MACAddressTest.MACAddressKey";
    MACAddressKey["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class MACAddressTest$0 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 256;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    MACAddressTest$0["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class MACAddressTest$1 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return -1;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    MACAddressTest$1["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class MACAddressTest$2 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 255;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    MACAddressTest$2["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];


}




MACAddressTest.MACAddressStringKey.comparator_$LI$();
