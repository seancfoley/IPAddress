/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressSegmentSeries } from '../AddressSegmentSeries';
import { AddressStringException } from '../AddressStringException';
import { AddressValueException } from '../AddressValueException';
import { HostIdentifierString } from '../HostIdentifierString';
import { IPAddress } from '../IPAddress';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressSection } from '../IPAddressSection';
import { IPAddressSegment } from '../IPAddressSegment';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { IPAddressStringDivisionSeries } from '../format/IPAddressStringDivisionSeries';
import { IPAddressPartStringCollection } from '../format/util/IPAddressPartStringCollection';
import { MySQLTranslator } from '../format/util/sql/MySQLTranslator';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressNetwork } from '../ipv4/IPv4AddressNetwork';
import { IPv4AddressSection } from '../ipv4/IPv4AddressSection';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { IPv6AddressSegment } from '../ipv6/IPv6AddressSegment';
import { TestBase } from './TestBase';
import { AddressCreator } from './AddressCreator';
import { HostName } from '../HostName';
import { IPv4AddressStringParameters } from '../ipv4/IPv4AddressStringParameters';
import { IPv6AddressStringParameters } from '../ipv6/IPv6AddressStringParameters';
import { AddressNetwork } from '../AddressNetwork';
import { Address } from '../Address';
import { AddressSegment } from '../AddressSegment';
import { HostTest } from './HostTest';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressSection } from '../mac/MACAddressSection';

export class IPAddressTest extends TestBase {
    constructor(creator : AddressCreator) {
        super(creator);
        if(this.secondTry===undefined) this.secondTry = false;
    }

    testResolved(original : string, expected : string) {
        let origAddress : IPAddressString = this.createAddress$java_lang_String(original);
        let resolvedAddress : IPAddress = origAddress.isIPAddress()?origAddress.getAddress():this.createHost$java_lang_String(original).getAddress();
        let expectedAddress : IPAddressString = this.createAddress$java_lang_String(expected);
        let result : boolean = (resolvedAddress == null)?(expected == null):resolvedAddress.equals(expectedAddress.getAddress());
        if(!result) {
            this.addFailure(new TestBase.Failure("resolved was " + resolvedAddress + " original was " + original, origAddress));
        }
        this.incrementTestCount();
    }

    testNormalized$java_lang_String$java_lang_String(original : string, expected : string) {
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean(original, expected, false, true);
    }

    testMask(original : string, mask : string, expected : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let orig : IPAddress = w.getAddress();
        let maskString : IPAddressString = this.createAddress$java_lang_String(mask);
        let maskAddr : IPAddress = maskString.getAddress();
        let masked : IPAddress = orig.mask$inet_ipaddr_IPAddress(maskAddr);
        let expectedStr : IPAddressString = this.createAddress$java_lang_String(expected);
        let expectedAddr : IPAddress = expectedStr.getAddress();
        if(!masked.equals(expectedAddr)) {
            this.addFailure(new TestBase.Failure("mask was " + mask + " and masked was " + masked, w));
        }
        this.incrementTestCount();
    }

    public testNormalized$java_lang_String$java_lang_String$boolean$boolean(original : string, expected : string, keepMixed : boolean, compress : boolean) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let normalized : string;
        if(w.isIPv6()) {
            let val : IPv6Address = <IPv6Address>w.getAddress();
            let params : IPv6AddressSection.IPv6StringOptions;
            if(compress) {
                let opts : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST);
                params = new IPv6AddressSection.IPv6StringOptions.Builder().setCompressOptions(opts).toOptions();
            } else {
                params = new IPv6AddressSection.IPv6StringOptions.Builder().toOptions();
            }
            normalized = val.toNormalizedString$boolean$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(keepMixed, params);
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
                this.addFailure(new TestBase.Failure("normalization 1 was " + normalized, w));
            }
        } else if(w.isIPv4()) {
            let val : IPv4Address = <IPv4Address>w.getAddress();
            normalized = val.toNormalizedString();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
                this.addFailure(new TestBase.Failure("normalization 2 was " + normalized, w));
            }
        } else {
            this.addFailure(new TestBase.Failure("normalization failed on " + original, w));
        }
        this.incrementTestCount();
    }

    public testNormalized(original? : any, expected? : any, keepMixed? : any, compress? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof expected === 'string') || expected === null) && ((typeof keepMixed === 'boolean') || keepMixed === null) && ((typeof compress === 'boolean') || compress === null)) {
            return <any>this.testNormalized$java_lang_String$java_lang_String$boolean$boolean(original, expected, keepMixed, compress);
        } else if(((typeof original === 'string') || original === null) && ((typeof expected === 'string') || expected === null) && keepMixed === undefined && compress === undefined) {
            return <any>this.testNormalized$java_lang_String$java_lang_String(original, expected);
        } else throw new Error('invalid overload');
    }

    testCompressed(original : string, expected : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let normalized : string;
        if(w.isIPAddress()) {
            let val : IPAddress = w.getAddress();
            normalized = val.toCompressedString();
        } else {
            normalized = w.toString();
        }
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
            this.addFailure(new TestBase.Failure("canonical was " + normalized, w));
        }
        this.incrementTestCount();
    }

    testCanonical(original : string, expected : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let addr : IPAddress = w.getAddress();
        let normalized : string = addr.toCanonicalString();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
            this.addFailure(new TestBase.Failure("canonical was " + normalized, w));
        }
        this.incrementTestCount();
    }

    testMixed$java_lang_String$java_lang_String(original : string, expected : string) {
        this.testMixed$java_lang_String$java_lang_String$java_lang_String(original, expected, expected);
    }

    public testMixed$java_lang_String$java_lang_String$java_lang_String(original : string, expected : string, expectedNoCompression : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let val : IPv6Address = <IPv6Address>w.getAddress();
        let normalized : string = val.toMixedString();
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
            this.addFailure(new TestBase.Failure("mixed was " + normalized + " expected was " + expected, w));
        } else {
            let opts : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST, IPv6AddressSection.CompressOptions.MixedCompressionOptions.NO);
            normalized = val.toNormalizedString$boolean$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(false, new IPv6AddressSection.IPv6StringOptions.Builder().setMakeMixed$boolean(true).setCompressOptions(opts).toOptions());
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expectedNoCompression))) {
                this.addFailure(new TestBase.Failure("mixed was " + normalized + " expected was " + expectedNoCompression, w));
            }
        }
        this.incrementTestCount();
    }

    public testMixed(original? : any, expected? : any, expectedNoCompression? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof expected === 'string') || expected === null) && ((typeof expectedNoCompression === 'string') || expectedNoCompression === null)) {
            return <any>this.testMixed$java_lang_String$java_lang_String$java_lang_String(original, expected, expectedNoCompression);
        } else if(((typeof original === 'string') || original === null) && ((typeof expected === 'string') || expected === null) && expectedNoCompression === undefined) {
            return <any>this.testMixed$java_lang_String$java_lang_String(original, expected);
        } else throw new Error('invalid overload');
    }

    testRadices(original : string, expected : string, radix : number) {
        let w : IPAddressString = this.createAddress$java_lang_String(original);
        let val : IPAddress = w.getAddress();
        let options : IPAddressSection.IPStringOptions = new IPv4AddressSection.IPv4StringOptions.Builder().setRadix(radix).toOptions();
        let normalized : string = val.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalized,expected))) {
            this.addFailure(new TestBase.Failure("string was " + normalized + " expected was " + expected, w));
        }
        this.incrementTestCount();
    }

    public prefixtest$boolean$java_lang_String$boolean(pass : boolean, x : string, isZero : boolean) {
        let addr : IPAddressString = this.createAddress$java_lang_String(x);
        if(this.prefixtest$boolean$inet_ipaddr_IPAddressString$boolean(pass, addr, isZero)) {
            this.prefixtest$boolean$inet_ipaddr_IPAddressString$boolean(pass, addr, isZero);
        }
    }

    public prefixtest(pass? : any, x? : any, isZero? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.prefixtest$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.prefixtest$boolean$inet_ipaddr_IPAddressString$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined) {
            return <any>this.prefixtest$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    evenOdd : number = 0;

    prefixtest$boolean$inet_ipaddr_IPAddressString$boolean(pass : boolean, addr : IPAddressString, isZero : boolean) : boolean {
        let failed : boolean = false;
        let isNotExpected : boolean;
        let oneWay : boolean = ((this.evenOdd & 1) === 0);
        if(oneWay) {
            isNotExpected = this.isNotExpectedForPrefix(pass, addr) || this.isNotExpectedForPrefixConversion(pass, addr);
        } else {
            isNotExpected = this.isNotExpectedForPrefixConversion(pass, addr) || this.isNotExpectedForPrefix(pass, addr);
        }
        this.evenOdd++;
        if(isNotExpected) {
            failed = true;
            this.addFailure(new TestBase.Failure(pass, addr));
            if(this.isNotExpectedForPrefix(pass, addr)) {
                this.isNotExpectedForPrefix(pass, addr);
            } else {
                this.isNotExpectedForPrefixConversion(pass, addr);
            }
        } else {
            let zeroPass : boolean = pass && !isZero;
            if(this.isNotExpectedNonZeroPrefix(zeroPass, addr)) {
                failed = true;
                this.addFailure(new TestBase.Failure(zeroPass, addr));
            }
        }
        this.incrementTestCount();
        return !failed;
    }

    public iptest(pass? : any, x? : any, isZero? : any, notBoth? : any, ipv4Test? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof notBoth === 'boolean') || notBoth === null) && ((typeof ipv4Test === 'boolean') || ipv4Test === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, x, isZero, notBoth, ipv4Test);
        } else throw new Error('invalid overload');
    }

    iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass : boolean, addr : IPAddressString, isZero : boolean, notBothTheSame : boolean, ipv4Test : boolean) : boolean {
        let failed : boolean = false;
        let pass2 : boolean = notBothTheSame?!pass:pass;
        try {
            if(this.isNotExpected(pass, addr, ipv4Test, !ipv4Test) || this.isNotExpected(pass2, addr)) {
                failed = true;
                this.addFailure(new TestBase.Failure(pass, addr));
                if(this.isNotExpected(pass, addr, ipv4Test, !ipv4Test)) {
                    this.isNotExpected(pass, addr, ipv4Test, !ipv4Test);
                } else {
                    this.isNotExpected(pass2, addr);
                }
            } else {
                let zeroPass : boolean;
                if(notBothTheSame) {
                    zeroPass = !isZero;
                } else {
                    zeroPass = pass && !isZero;
                }
                if(this.isNotExpectedNonZero(zeroPass, addr)) {
                    failed = true;
                    this.addFailure(new TestBase.Failure(zeroPass, addr));
                } else {
                    if(pass && addr.toString().length > 0 && addr.getAddress() != null && !(addr.getAddress().isIPv6() && addr.getAddress().toIPv6().hasZone()) && !addr.isPrefixed()) {
                        failed = !this.testBytes(addr.getAddress());
                    }
                }
            }
        } catch(__e) {
            if(__e != null && __e instanceof <any>IncompatibleAddressException) {
                let e : IncompatibleAddressException = <IncompatibleAddressException>__e;
                failed = true;
                this.addFailure(new TestBase.Failure(e.toString(), addr));

            }
            if(__e != null && (__e["__classes"] && __e["__classes"].indexOf("java.lang.RuntimeException") >= 0) || __e != null && __e instanceof <any>Error) {
                let e : Error = <Error>__e;
                failed = true;
                this.addFailure(new TestBase.Failure(e.toString(), addr));

            }
        };
        this.incrementTestCount();
        return !failed;
    }

    testBytes(addr : IPAddress) : boolean {
        let failed : boolean = false;
        try {
            let addrString : string = addr.toString();
            let index : number = addrString.indexOf('/');
            if(index >= 0) {
                addrString = addrString.substring(0, index);
            }
            let inetAddress : InetAddress = InetAddress.getByName(addrString);
            let b : number[] = inetAddress.getAddress();
            let b2 : number[] = addr.getBytes();
            if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(b, b2)) {
                let b3 : number[] = addr.isIPv4()?addr.getSection().getBytes():addr.toIPv6().toMappedIPv4Segments().getBytes();
                if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(b, b3)) {
                    failed = true;
                    this.addFailure(new TestBase.Failure("bytes on addr " + inetAddress, addr));
                }
            }
        } catch(e) {
            failed = true;
            this.addFailure(new TestBase.Failure("bytes on addr " + e, addr));
        };
        return !failed;
    }

    testMaskBytes(cidr2 : string, w2 : IPAddressString) {
        let index : number = cidr2.indexOf('/');
        if(index < 0) {
            index = cidr2.length;
        }
        let w3 : IPAddressString = this.createAddress$java_lang_String(cidr2.substring(0, index));
        try {
            let inetAddress : InetAddress = null;
            inetAddress = InetAddress.getByName(w3.toString());
            let b : number[] = inetAddress.getAddress();
            let b2 : number[] = w3.toAddress().getBytes();
            if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(b, b2)) {
                this.addFailure(new TestBase.Failure("bytes on addr " + inetAddress, w3));
            } else {
                let b3 : number[] = w2.toAddress().getBytes();
                if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(b3, b2)) {
                    this.addFailure(new TestBase.Failure("bytes on addr " + w3, w2));
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("bytes on addr " + w3, w3));
        };
    }

    testFromBytes(bytes : number[], expected : string) {
        let addr : IPAddress = this.createAddress$byte_A(bytes);
        let addr2 : IPAddressString = this.createAddress$java_lang_String(expected);
        let result : boolean = addr.equals(addr2.getAddress());
        if(!result) {
            this.addFailure(new TestBase.Failure("created was " + addr + " expected was " + addr2, addr));
        } else {
            if(addr.isIPv4()) {
                let val : number = 0;
                for(let i : number = 0; i < bytes.length; i++) {
                    val <<= 8;
                    val |= 255 & bytes[i];
                };
                addr = this.createAddress$int(val);
                result = addr.equals(addr2.getAddress());
                if(!result) {
                    this.addFailure(new TestBase.Failure("created was " + addr + " expected was " + addr2, addr));
                }
            }
        }
        this.incrementTestCount();
    }

    createSets(bytes : number[], segmentByteSize : number) : number[][][] {
        let segmentLength : number = (bytes.length / segmentByteSize|0);
        let sets : number[][][] = [[(s => { let a=[]; while(s-->0) a.push(0); return a; })(((segmentLength / 2|0)) * segmentByteSize), (s => { let a=[]; while(s-->0) a.push(0); return a; })((segmentLength - (segmentLength / 2|0)) * segmentByteSize)], [(s => { let a=[]; while(s-->0) a.push(0); return a; })(((segmentLength / 3|0)) * segmentByteSize), (s => { let a=[]; while(s-->0) a.push(0); return a; })(((segmentLength / 3|0)) * segmentByteSize), (s => { let a=[]; while(s-->0) a.push(0); return a; })((segmentLength - 2 * ((segmentLength / 3|0))) * segmentByteSize)]];
        for(let index144=0; index144 < sets.length; index144++) {
            let set = sets[index144];
            {
                for(let i : number = 0, ind : number = 0; i < set.length; i++) {
                    let part : number[] = set[i];
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(bytes, ind, part, 0, part.length);
                    ind += part.length;
                };
            }
        }
        return sets;
    }

    public testSplitBytes$java_lang_String(addressStr : string) {
        let addr : IPAddress = this.createAddress$java_lang_String(addressStr).getAddress();
        this.testSplitBytes$inet_ipaddr_IPAddress(addr);
    }

    public testSplitBytes(addressStr? : any) : any {
        if(((typeof addressStr === 'string') || addressStr === null)) {
            return <any>this.testSplitBytes$java_lang_String(addressStr);
        } else if(((addressStr != null && addressStr instanceof <any>IPAddress) || addressStr === null)) {
            return <any>this.testSplitBytes$inet_ipaddr_IPAddress(addressStr);
        } else throw new Error('invalid overload');
    }

    testSplitBytes$inet_ipaddr_IPAddress(addr : IPAddress) {
        let bytes : number[] = addr.getBytes();
        let addresses : Array<IPAddress> = this.reconstitute<any>(addr, bytes, addr.getBytesPerSegment());
        if(addr.isMultiple()) {
            for(let index145=0; index145 < addresses.length; index145++) {
                let addrNext = addresses[index145];
                {
                    if(!addr.getLower().equals(addrNext)) {
                        this.addFailure(new TestBase.Failure("lower reconstitute failure: " + addrNext, addr));
                    }
                }
            }
            bytes = addr.getUpperBytes();
            addresses = this.reconstitute<any>(addr, bytes, addr.getBytesPerSegment());
            for(let index146=0; index146 < addresses.length; index146++) {
                let addrNext = addresses[index146];
                {
                    if(!addr.getUpper().equals(addrNext)) {
                        this.addFailure(new TestBase.Failure("upper reconstitute failure: " + addrNext, addr));
                    }
                }
            }
        } else {
            for(let index147=0; index147 < addresses.length; index147++) {
                let addrNext = addresses[index147];
                {
                    if(!addr.equals(addrNext)) {
                        this.addFailure(new TestBase.Failure("reconstitute failure: " + addrNext, addr));
                    }
                }
            }
        }
    }

    reconstitute<S extends IPAddressSegment>(originalAddress : IPAddress, bytes : number[], segmentByteSize : number) : Array<IPAddress> {
        let creator : IPAddressNetwork.IPAddressCreator<any, any, any, S, any> = <IPAddressNetwork.IPAddressCreator<any, any, any, S, any>>originalAddress.getNetwork().getAddressCreator();
        let addresses : Array<IPAddress> = <any>([]);
        let sets : number[][][] = this.createSets(bytes, segmentByteSize);
        for(let index148=0; index148 < sets.length; index148++) {
            let set = sets[index148];
            {
                let segments : Array<S> = <any>([]);
                let segments2 : Array<S> = <any>([]);
                for(let i : number = 0, ind : number = 0; i < set.length; i++) {
                    let setBytes : number[] = set[i];
                    let segs : S[] = <S[]>creator.createSection$byte_A$java_lang_Integer(setBytes, null).getSegments();
                    let segs2 : S[] = <S[]>creator.createSection$byte_A$int$int$java_lang_Integer(bytes, ind, ind + setBytes.length, null).getSegments();
                    let one : S[];
                    let two : S[];
                    if(i % 2 === 0) {
                        one = segs;
                        two = segs2;
                    } else {
                        one = segs2;
                        two = segs;
                    }
                    ind += setBytes.length;
                    /* addAll */((l1, l2) => l1.push.apply(l1, l2))(segments, /* asList */one.slice(0));
                    /* addAll */((l1, l2) => l1.push.apply(l1, l2))(segments2, /* asList */two.slice(0));
                };
                let segs : S[] = creator.createSegmentArray(/* size */(<number>segments.length));
                let addr1 : IPAddress = creator.createAddress$inet_ipaddr_IPAddressSegment_A(/* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })(segs, segments));
                let addr2 : IPAddress = creator.createAddress$inet_ipaddr_IPAddressSegment_A(/* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })(segs, segments2));
                /* add */(addresses.push(addr1)>0);
                /* add */(addresses.push(addr2)>0);
            }
        }
        return addresses;
    }

    public isNotExpected(expectedPass : boolean, addr : IPAddressString, isIPv4 : boolean = false, isIPv6 : boolean = false) : boolean {
        try {
            if(isIPv4) {
                addr.validateIPv4();
                addr.toAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV4);
            } else if(isIPv6) {
                addr.validateIPv6();
                addr.toAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV6);
            } else {
                addr.validate();
            }
            return !expectedPass;
        } catch(e) {
            return expectedPass;
        };
    }

    isNotExpectedForPrefix(expectedPass : boolean, addr : IPAddressString) : boolean {
        try {
            addr.validate();
            return !expectedPass;
        } catch(e) {
            return expectedPass;
        };
    }

    public convertToMask(str : IPAddressString, version : IPAddress.IPVersion) : string {
        let address : IPAddress = str.toAddress$inet_ipaddr_IPAddress_IPVersion(version);
        if(address != null) {
            return address.toNormalizedString();
        }
        return null;
    }

    isNotExpectedForPrefixConversion(expectedPass : boolean, addr : IPAddressString) : boolean {
        try {
            let ip1 : IPAddress = addr.toAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV6);
            let str1 : string = this.convertToMask(addr, IPAddress.IPVersion.IPV6);
            if(ip1 == null || !ip1.isIPv6() || str1 == null) {
                return expectedPass;
            }
            let integ : number = ip1.getNetworkPrefixLength();
            if(integ != null && /* intValue */(integ|0) > 32 && expectedPass) {
                expectedPass = false;
            }
            let ip2 : IPAddress = addr.toAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV4);
            let str2 : string = this.convertToMask(addr, IPAddress.IPVersion.IPV4);
            if(ip2 == null || !ip2.isIPv4() || str2 == null) {
                return expectedPass;
            }
            return !expectedPass;
        } catch(e) {
            return expectedPass;
        };
    }

    isNotExpectedNonZero(expectedPass : boolean, addr : IPAddressString) : boolean {
        if(!addr.isIPAddress() && !addr.isPrefixOnly() && !addr.isAllAddresses()) {
            return expectedPass;
        }
        if(addr.getAddress() != null && addr.getAddress().isZero()) {
            return expectedPass;
        }
        return !expectedPass;
    }

    isNotExpectedNonZeroPrefix(expectedPass : boolean, addr : IPAddressString) : boolean {
        if(!addr.isPrefixOnly()) {
            if(!addr.isValid()) {
                return expectedPass;
            }
            if(addr.getNetworkPrefixLength() <= IPv4Address.BIT_COUNT) {
                return expectedPass;
            }
        }
        if(addr.getAddress() != null && addr.getAddress().isZero()) {
            return expectedPass;
        }
        return !expectedPass;
    }

    ipv4testOnly(pass : boolean, x : string) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, this.createAddress$java_lang_String(x), false, true, true);
    }

    public ipv4test(pass? : any, x? : any, isZero? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4RangeOptions === 'boolean') || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean$boolean(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4RangeOptions === 'boolean') || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$inet_ipaddr_IPAddressString$boolean$boolean(pass, x, isZero, ipv4RangeOptions);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((x != null && x instanceof <any>IPAddressString) || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$inet_ipaddr_IPAddressString$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.ipv4test$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    ipv4test$boolean$java_lang_String(pass : boolean, x : string) {
        this.ipv4test$boolean$java_lang_String$boolean(pass, x, false);
    }

    ipv4_inet_aton_test$boolean$java_lang_String(pass : boolean, x : string) {
        this.ipv4_inet_aton_test$boolean$java_lang_String$boolean(pass, x, false);
    }

    public ipv4_inet_aton_test$boolean$java_lang_String$boolean(pass : boolean, x : string, isZero : boolean) {
        let addr : IPAddressString = this.createInetAtonAddress(x);
        this.ipv4test$boolean$inet_ipaddr_IPAddressString$boolean(pass, addr, isZero);
    }

    public ipv4_inet_aton_test(pass? : any, x? : any, isZero? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null)) {
            return <any>this.ipv4_inet_aton_test$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined) {
            return <any>this.ipv4_inet_aton_test$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    ipv4test$boolean$java_lang_String$boolean(pass : boolean, x : string, isZero : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, this.createAddress$java_lang_String(x), isZero, false, true);
    }

    ipv4test$boolean$inet_ipaddr_IPAddressString$boolean(pass : boolean, x : IPAddressString, isZero : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, x, isZero, false, true);
    }

    ipv4test$boolean$java_lang_String$boolean$boolean(pass : boolean, x : string, isZero : boolean, notBothTheSame : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, this.createAddress$java_lang_String(x), isZero, notBothTheSame, true);
    }

    ipv4test$boolean$inet_ipaddr_IPAddressString$boolean$boolean(pass : boolean, x : IPAddressString, isZero : boolean, notBothTheSame : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, x, isZero, notBothTheSame, true);
    }

    ipv6testOnly(pass : number, x : string) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass === 0?false:true, this.createAddress$java_lang_String(x), false, true, false);
    }

    public ipv6testWithZone$int$java_lang_String(pass : number, x : string) {
        this.ipv6test$int$java_lang_String(pass, x);
    }

    public ipv6testWithZone(pass? : any, x? : any) : any {
        if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null)) {
            return <any>this.ipv6testWithZone$int$java_lang_String(pass, x);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null)) {
            return <any>this.ipv6testWithZone$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    public ipv6test(pass? : any, x? : any, isZero? : any, ipv4Options? : any, ipv6Options? : any) : any {
        if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ((typeof ipv4Options === 'boolean') || ipv4Options === null) && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean$boolean(pass, x, isZero, ipv4Options);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$int$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && ((typeof isZero === 'boolean') || isZero === null) && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String$boolean(pass, x, isZero);
        } else if(((typeof pass === 'number') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$int$java_lang_String(pass, x);
        } else if(((typeof pass === 'boolean') || pass === null) && ((typeof x === 'string') || x === null) && isZero === undefined && ipv4Options === undefined && ipv6Options === undefined) {
            return <any>this.ipv6test$boolean$java_lang_String(pass, x);
        } else throw new Error('invalid overload');
    }

    ipv6test$int$java_lang_String(pass : number, x : string) {
        this.ipv6test$boolean$java_lang_String(pass === 0?false:true, x);
    }

    ipv6testWithZone$boolean$java_lang_String(pass : boolean, x : string) {
        this.ipv6test$boolean$java_lang_String(pass, x);
    }

    prefixtest$boolean$java_lang_String(pass : boolean, x : string) {
        this.prefixtest$boolean$java_lang_String$boolean(pass, x, false);
    }

    ipv6test$boolean$java_lang_String(pass : boolean, x : string) {
        this.ipv6test$boolean$java_lang_String$boolean(pass, x, false);
    }

    ipv6test$int$java_lang_String$boolean(pass : number, x : string, isZero : boolean) {
        this.ipv6test$boolean$java_lang_String$boolean(pass === 0?false:true, x, isZero);
    }

    ipv6test$boolean$java_lang_String$boolean(pass : boolean, x : string, isZero : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, this.createAddress$java_lang_String(x), isZero, false, false);
    }

    ipv6test$boolean$java_lang_String$boolean$boolean(pass : boolean, x : string, isZero : boolean, notBothTheSame : boolean) {
        this.iptest$boolean$inet_ipaddr_IPAddressString$boolean$boolean$boolean(pass, this.createAddress$java_lang_String(x), isZero, notBothTheSame, false);
    }

    /**
     * Returns just a few string representations:
     * 
     * <ul>
     * <li>either compressed or not - when compressing it uses the canonical string representation or it compresses the leftmost zero-segment if the canonical representation has no compression.
     * <li>either lower or upper case
     * <li>combinations thereof
     * </ul>
     * 
     * So the maximum number of strings returned for IPv6 is 4, while for IPv4 it is 1.
     * 
     * @return
     * @param {IPAddress} addr
     * @return {Array}
     */
    getBasicStrings(addr : IPAddress) : string[] {
        let opts : IPAddressSection.IPStringBuilderOptions;
        if(addr.isIPv6()) {
            opts = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_SINGLE_$LI$());
        } else {
            opts = new IPAddressSection.IPStringBuilderOptions();
        }
        return addr.toStrings(opts);
    }

    public testVariantCounts$java_lang_String$int$int$int$int$int$int(addr : string, expectedPartCount : number, expectedBasic : number, expectedStandard : number, expectedAll : number, expectedAllNoConverted : number, expectedAllNoOctalHex : number) {
        let address : IPAddressString = this.createAddress$java_lang_String(addr);
        let ad : IPAddress = address.getAddress();
        let basicStrs : string[] = this.getBasicStrings(ad);
        this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(basicStrs, expectedBasic, address);
        let standardCollection : IPAddressPartStringCollection = ad.toStandardStringCollection();
        let standardStrs : string[] = standardCollection.toStrings();
        this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(standardStrs, expectedStandard, address);
        let parts : IPAddressStringDivisionSeries[] = ad.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(ad.isIPv6()?IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$():IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$());
        if(parts.length !== expectedPartCount) {
            this.addFailure(new TestBase.Failure("Part count " + parts.length + " does not match expected " + expectedPartCount, ad));
        }
        this.incrementTestCount();
        try {
            let convertIPv6Opts : IPv4AddressSection.IPv4StringBuilderOptions = new IPv4AddressSection.IPv4StringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.IPV6_CONVERSIONS);
            let convertIPv4Opts : IPv6AddressSection.IPv6StringBuilderOptions = new IPv6AddressSection.IPv6StringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.IPV4_CONVERSIONS);
            if(ad.isIPv4()) {
                let partsConverted : IPAddressStringDivisionSeries[] = ad.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(convertIPv6Opts);
                if(partsConverted.length === 0) {
                    this.addFailure(new TestBase.Failure("converted count does not match expected", ad));
                } else {
                    let converted : IPv6AddressSection = <IPv6AddressSection><any>partsConverted[0];
                    partsConverted = new IPv6Address(converted).getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(convertIPv4Opts);
                    let convertedBack : IPv4AddressSection = <IPv4AddressSection><any>partsConverted[0];
                    if(!ad.getSection().equals(convertedBack)) {
                        this.addFailure(new TestBase.Failure("converted " + convertedBack + " does not match expected", ad));
                    }
                }
            } else {
                if(ad.isIPv4Convertible()) {
                    let partsConverted : IPAddressStringDivisionSeries[] = ad.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(convertIPv4Opts);
                    if(partsConverted.length === 0) {
                        this.addFailure(new TestBase.Failure("converted count does not match expected", ad));
                    } else {
                        let converted : IPv4AddressSection = <IPv4AddressSection><any>partsConverted[0];
                        partsConverted = new IPv4Address(converted).getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(convertIPv6Opts);
                        let convertedBack : IPv6AddressSection = <IPv6AddressSection><any>partsConverted[0];
                        if(!ad.getSection().equals(convertedBack)) {
                            this.addFailure(new TestBase.Failure("converted " + convertedBack + " does not match expected", ad));
                        }
                    }
                } else {
                    let partsConverted : IPAddressStringDivisionSeries[] = ad.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(convertIPv4Opts);
                    if(partsConverted.length > 0) {
                        this.addFailure(new TestBase.Failure("converted count does not match expected", ad));
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure(e.toString()));
        };
        this.incrementTestCount();
        if(this.fullTest || expectedAll < 100) {
            let allCollection : IPAddressPartStringCollection = ad.toAllStringCollection();
            let collParts : IPAddressStringDivisionSeries[] = allCollection.getParts((s => { let a=[]; while(s-->0) a.push(null); return a; })(allCollection.getPartCount()));
            if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(/* asList */parts.slice(0).slice(0), /* asList */collParts.slice(0).slice(0))) {
                this.addFailure(new TestBase.Failure("Parts " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */parts.slice(0)) + " and collection parts " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */collParts.slice(0)) + " not the same ", ad));
            } else {
                this.incrementTestCount();
            }
            let allStrs : string[] = allCollection.toStrings();
            this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(allStrs, expectedAll, address);
        }
        if(this.fullTest || expectedAllNoConverted < 100) {
            let allStrs : string[];
            let opts : IPAddressSection.IPStringBuilderOptions;
            if(address.isIPv4()) {
                opts = new IPv4AddressSection.IPv4StringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$().options & ~IPv4AddressSection.IPv4StringBuilderOptions.IPV6_CONVERSIONS);
            } else {
                opts = new IPv6AddressSection.IPv6StringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$().options & ~IPv6AddressSection.IPv6StringBuilderOptions.IPV4_CONVERSIONS, IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$().mixedOptions);
            }
            allStrs = address.getAddress().toStrings(opts);
            this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(allStrs, expectedAllNoConverted, address);
        }
        if(this.fullTest || expectedAllNoOctalHex < 100) {
            if(address.isIPv4()) {
                let allStrs : string[] = address.getAddress().toStrings(new IPv4AddressSection.IPv4StringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$().options & ~(IPv4AddressSection.IPv4StringBuilderOptions.IPV6_CONVERSIONS | IPv4AddressSection.IPv4StringBuilderOptions.ALL_JOINS_$LI$() | IPv4AddressSection.IPv4StringBuilderOptions.HEX | IPv4AddressSection.IPv4StringBuilderOptions.OCTAL)));
                this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(allStrs, expectedAllNoOctalHex, address);
            }
        }
    }

    public testVariantCounts(addr? : any, expectedPartCount? : any, expectedBasic? : any, expectedStandard? : any, expectedAll? : any, expectedAllNoConverted? : any, expectedAllNoOctalHex? : any) : any {
        if(((typeof addr === 'string') || addr === null) && ((typeof expectedPartCount === 'number') || expectedPartCount === null) && ((typeof expectedBasic === 'number') || expectedBasic === null) && ((typeof expectedStandard === 'number') || expectedStandard === null) && ((typeof expectedAll === 'number') || expectedAll === null) && ((typeof expectedAllNoConverted === 'number') || expectedAllNoConverted === null) && ((typeof expectedAllNoOctalHex === 'number') || expectedAllNoOctalHex === null)) {
            return <any>this.testVariantCounts$java_lang_String$int$int$int$int$int$int(addr, expectedPartCount, expectedBasic, expectedStandard, expectedAll, expectedAllNoConverted, expectedAllNoOctalHex);
        } else if(((typeof addr === 'string') || addr === null) && ((typeof expectedPartCount === 'number') || expectedPartCount === null) && ((typeof expectedBasic === 'number') || expectedBasic === null) && ((typeof expectedStandard === 'number') || expectedStandard === null) && ((typeof expectedAll === 'number') || expectedAll === null) && ((typeof expectedAllNoConverted === 'number') || expectedAllNoConverted === null) && expectedAllNoOctalHex === undefined) {
            return <any>this.testVariantCounts$java_lang_String$int$int$int$int$int(addr, expectedPartCount, expectedBasic, expectedStandard, expectedAll, expectedAllNoConverted);
        } else if(((typeof addr === 'string') || addr === null) && ((typeof expectedPartCount === 'number') || expectedPartCount === null) && ((typeof expectedBasic === 'number') || expectedBasic === null) && ((typeof expectedStandard === 'number') || expectedStandard === null) && ((typeof expectedAll === 'number') || expectedAll === null) && expectedAllNoConverted === undefined && expectedAllNoOctalHex === undefined) {
            return <any>this.testVariantCounts$java_lang_String$int$int$int$int(addr, expectedPartCount, expectedBasic, expectedStandard, expectedAll);
        } else throw new Error('invalid overload');
    }

    testVariantCounts$java_lang_String$int$int$int$int$int(addr : string, expectedPartCount : number, expectedBasic : number, expectedStandard : number, expectedAll : number, expectedAllNoConverted : number) {
        this.testVariantCounts$java_lang_String$int$int$int$int$int$int(addr, expectedPartCount, expectedBasic, expectedStandard, expectedAll, expectedAllNoConverted, expectedAllNoConverted);
    }

    testVariantCounts$java_lang_String$int$int$int$int(addr : string, expectedPartCount : number, expectedBasic : number, expectedStandard : number, expectedAll : number) {
        this.testVariantCounts$java_lang_String$int$int$int$int$int(addr, expectedPartCount, expectedBasic, expectedStandard, expectedAll, expectedAll);
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testStrings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && ((typeof normalizedWildcardString === 'boolean') || normalizedWildcardString === null) && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString$boolean(w, ipAddr, normalizedString, normalizedWildcardString);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(w, ipAddr, normalizedString);
        } else throw new Error('invalid overload');
    }

    testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(strs : string[], expectedCount : number, addr : IPAddressString) {
        this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString$boolean(strs, expectedCount, addr, false);
    }

    testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString$boolean(strs : string[], expectedCount : number, addr : IPAddressString, writeList : boolean) {
        if(writeList) {
            this.listVariants(strs);
        }
        if(expectedCount !== strs.length) {
            this.addFailure(new TestBase.Failure("String count " + strs.length + " doesn\'t match expected count " + expectedCount, addr));
            this.incrementTestCount();
        }
        let set : Array<string> = <any>([]);
        Collections.addAll<any>(set, strs);
        if(/* size */(<number>set.length) !== strs.length) {
            this.addFailure(new TestBase.Failure((strs.length - /* size */(<number>set.length)) + " duplicates for " + addr, addr));
            /* clear */(set.length = 0);
            for(let index149=0; index149 < strs.length; index149++) {
                let str = strs[index149];
                {
                    if(/* contains */(set.indexOf(<any>(str)) >= 0)) {
                        console.info("dup " + str);
                    }
                    /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, str);
                }
            }
        } else for(let index150=0; index150 < strs.length; index150++) {
            let str = strs[index150];
            {
                if(str.length > 45) {
                    this.addFailure(new TestBase.Failure("excessive length " + str + " for " + addr, addr));
                    break;
                }
            }
        }
        this.incrementTestCount();
    }

    listVariants(strs : string[]) {
        console.info("list count is " + strs.length);
        for(let index151=0; index151 < strs.length; index151++) {
            let str = strs[index151];
            {
                console.info(str);
            }
        }
        console.info();
    }

    public checkNotMask$inet_ipaddr_IPAddress$boolean(address : IPAddress, network : boolean) : boolean {
        let maskPrefix : number = address.getBlockMaskPrefixLength(network);
        let otherMaskPrefix : number = address.getBlockMaskPrefixLength(!network);
        if(maskPrefix != null || otherMaskPrefix != null) {
            this.addFailure(new TestBase.Failure("failed not mask", address));
            return false;
        }
        this.incrementTestCount();
        return true;
    }

    public checkNotMask(address? : any, network? : any) : any {
        if(((address != null && address instanceof <any>IPAddress) || address === null) && ((typeof network === 'boolean') || network === null)) {
            return <any>this.checkNotMask$inet_ipaddr_IPAddress$boolean(address, network);
        } else if(((typeof address === 'string') || address === null) && network === undefined) {
            return <any>this.checkNotMask$java_lang_String(address);
        } else throw new Error('invalid overload');
    }

    checkNotMask$java_lang_String(addr : string) {
        let addressStr : IPAddressString = this.createAddress$java_lang_String(addr);
        let address : IPAddress = addressStr.getAddress();
        let val : boolean = ((address.getBytes()[0] & 1) === 0);
        if(this.checkNotMask$inet_ipaddr_IPAddress$boolean(address, val)) {
            this.checkNotMask$inet_ipaddr_IPAddress$boolean(address, !val);
        }
    }

    secondTry : boolean;

    checkMask(address : IPAddress, prefixBits : number, network : boolean) : boolean {
        let maskPrefix : number = address.getBlockMaskPrefixLength(network);
        let otherMaskPrefix : number = address.getBlockMaskPrefixLength(!network);
        if(maskPrefix !== Math.min(prefixBits, address.getBitCount()) || otherMaskPrefix != null) {
            this.addFailure(new TestBase.Failure("failed mask", address));
            return false;
        }
        if(network) {
            try {
                let originalPrefixStr : string = "/" + prefixBits;
                let originalChoppedStr : string = prefixBits <= address.getBitCount()?originalPrefixStr:"/" + address.getBitCount();
                let prefix : IPAddressString = this.createAddress$java_lang_String(originalPrefixStr);
                let maskStr : string = this.convertToMask(prefix, address.getIPVersion());
                let prefixExtra : string = originalPrefixStr;
                let addressWithNoPrefix : IPAddress;
                if(address.isPrefixed()) {
                    addressWithNoPrefix = address.mask$inet_ipaddr_IPAddress(address.getNetwork().getNetworkMask(address.getNetworkPrefixLength()));
                } else {
                    addressWithNoPrefix = address;
                }
                let ipForNormalizeMask : string = addressWithNoPrefix.toString();
                let maskStrx2 : string = IPAddressTest.normalizeMask(originalPrefixStr, ipForNormalizeMask) + prefixExtra;
                let maskStrx3 : string = IPAddressTest.normalizeMask("" + prefixBits, ipForNormalizeMask) + prefixExtra;
                let normalStr : string = address.toNormalizedString();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(maskStr,normalStr)) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(maskStrx2,normalStr)) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(maskStrx3,normalStr))) {
                    this.addFailure(new TestBase.Failure("failed prefix conversion " + maskStr, prefix));
                    return false;
                } else {
                    let maskStr2 : IPAddressString = this.createAddress$java_lang_String(maskStr);
                    let prefixStr : string = maskStr2.convertToPrefixLength();
                    if(prefixStr == null || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixStr,originalChoppedStr))) {
                        maskStr2 = this.createAddress$java_lang_String(maskStr);
                        maskStr2.convertToPrefixLength();
                        this.addFailure(new TestBase.Failure("failed mask converstion " + prefixStr, maskStr2));
                        return false;
                    }
                }
            } catch(e) {
                this.addFailure(new TestBase.Failure("failed conversion: " + e.message, address));
                return false;
            };
        }
        this.incrementTestCount();
        if(!this.secondTry) {
            this.secondTry = true;
            let bytes : number[] = address.getBytes();
            let params : IPAddressStringParameters.IPAddressStringFormatParameters = address.isIPv4()?TestBase.ADDRESS_OPTIONS_$LI$().getIPv4Parameters():TestBase.ADDRESS_OPTIONS_$LI$().getIPv6Parameters();
            let addressNetwork : IPAddressNetwork<any, any, any, any, any> = params.getNetwork();
            let creator : IPAddressNetwork.IPAddressCreator<any, any, any, any, any> = addressNetwork.getAddressCreator();
            let another : IPAddress = network?creator.createAddress$byte_A$java_lang_Integer(bytes, prefixBits):creator.createAddress$byte_A(bytes);
            let result : boolean = this.checkMask(another, prefixBits, network);
            this.secondTry = false;
            if(result) {
                let prefixBitsMismatch : boolean = false;
                let addrPrefixBits : number = address.getNetworkPrefixLength();
                if(!network) {
                    prefixBitsMismatch = addrPrefixBits != null;
                } else {
                    prefixBitsMismatch = addrPrefixBits == null || (prefixBits !== addrPrefixBits);
                }
                if(prefixBitsMismatch) {
                    this.addFailure(new TestBase.Failure("prefix incorrect", address));
                    return false;
                }
            }
        }
        return true;
    }

    public static normalizeMask(maskString : string, ipString : string) : string {
        if(ipString != null && ipString.trim().length > 0 && maskString != null && maskString.trim().length > 0) {
            maskString = maskString.trim();
            if(/* startsWith */((str, searchString, position = 0) => str.substr(position, searchString.length) === searchString)(maskString, "/")) {
                maskString = maskString.substring(1);
            }
            let addressString : IPAddressString = new IPAddressString(ipString);
            if(addressString.isIPAddress()) {
                try {
                    let version : IPAddress.IPVersion = addressString.getIPVersion();
                    let prefix : number = IPAddressString.validateNetworkPrefixLength(version, maskString);
                    let maskAddress : IPAddress = addressString.getAddress().getNetwork().getNetworkMask(prefix, false);
                    return maskAddress.toNormalizedString();
                } catch(e) {
                };
            }
        }
        return maskString;
    }

    testMasksAndPrefixes() {
        for(let i : number = 0; i <= 128; i++) {
            let network : IPv6AddressNetwork = TestBase.ADDRESS_OPTIONS_$LI$().getIPv6Parameters().getNetwork();
            let ipv6HostMask : IPv6Address = network.getHostMask(i);
            if(this.checkMask(ipv6HostMask, i, false)) {
                let ipv6NetworkMask : IPv6Address = network.getNetworkMask(i);
                if(this.checkMask(ipv6NetworkMask, i, true)) {
                    if(i <= 32) {
                        let ipv4network : IPv4AddressNetwork = TestBase.ADDRESS_OPTIONS_$LI$().getIPv4Parameters().getNetwork();
                        let ipv4HostMask : IPv4Address = ipv4network.getHostMask(i);
                        if(this.checkMask(ipv4HostMask, i, false)) {
                            let ipv4NetworkMask : IPv4Address = ipv4network.getNetworkMask(i);
                            this.checkMask(ipv4NetworkMask, i, true);
                        }
                    }
                }
            }
        };
    }

    testCIDRSubnets$java_lang_String$java_lang_String(cidr1 : string, normalizedString : string) {
        this.testCIDRSubnets$java_lang_String$java_lang_String$boolean(cidr1, normalizedString, true);
    }

    public testCIDRSubnets$java_lang_String$java_lang_String$boolean(cidr1 : string, normalizedString : string, testString : boolean) {
        let w : IPAddressString = this.createAddress$java_lang_String(cidr1);
        let w2 : IPAddressString = this.createAddress$java_lang_String(normalizedString);
        try {
            let first : boolean = w.equals(w2);
            let v : IPAddress = w.toAddress();
            let v2 : IPAddress = w2.toAddress();
            let second : boolean = v.equals(v2);
            if(!first || !second) {
                this.addFailure(new TestBase.Failure("failed " + w2, w));
            } else {
                let str : string = v2.toNormalizedString();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(normalizedString,str))) {
                    this.addFailure(new TestBase.Failure("failed " + str, w2));
                } else {
                    this.testMaskBytes(normalizedString, w2);
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + w2, w));
        };
        this.incrementTestCount();
    }

    public testCIDRSubnets(cidr1? : any, normalizedString? : any, testString? : any) : any {
        if(((typeof cidr1 === 'string') || cidr1 === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof testString === 'boolean') || testString === null)) {
            return <any>this.testCIDRSubnets$java_lang_String$java_lang_String$boolean(cidr1, normalizedString, testString);
        } else if(((typeof cidr1 === 'string') || cidr1 === null) && ((typeof normalizedString === 'string') || normalizedString === null) && testString === undefined) {
            return <any>this.testCIDRSubnets$java_lang_String$java_lang_String(cidr1, normalizedString);
        } else throw new Error('invalid overload');
    }

    static conversionContains(h1 : IPAddress, h2 : IPAddress) : boolean {
        if(h1.isIPv4()) {
            if(!h2.isIPv4()) {
                if(h2.isIPv4Convertible()) {
                    return h1.contains(h2.toIPv4());
                }
            }
        } else if(h1.isIPv6()) {
            if(!h2.isIPv6()) {
                if(h2.isIPv6Convertible()) {
                    return h1.contains(h2.toIPv6());
                }
            }
        }
        return false;
    }

    testContains$java_lang_String$java_lang_String$boolean(cidr1 : string, cidr2 : string, equal : boolean) {
        this.testContains$java_lang_String$java_lang_String$boolean$boolean(cidr1, cidr2, true, equal);
    }

    public testContains$java_lang_String$java_lang_String$boolean$boolean(cidr1 : string, cidr2 : string, result : boolean, equal : boolean) {
        try {
            let w : IPAddress = this.createAddress$java_lang_String(cidr1).toAddress();
            let w2 : IPAddress = this.createAddress$java_lang_String(cidr2).toAddress();
            if(!w.contains(w2) && !IPAddressTest.conversionContains(w, w2)) {
                if(result) {
                    this.addFailure(new TestBase.Failure("containment failed " + w2, w));
                }
            } else {
                if(!result) {
                    this.addFailure(new TestBase.Failure("containment passed " + w2, w));
                } else if(equal?!(w2.contains(w) || IPAddressTest.conversionContains(w2, w)):(w2.contains(w) || IPAddressTest.conversionContains(w2, w))) {
                    this.addFailure(new TestBase.Failure("failed " + w, w2));
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e));
        };
        this.incrementTestCount();
    }

    public testContains(cidr1? : any, cidr2? : any, result? : any, equal? : any) : any {
        if(((typeof cidr1 === 'string') || cidr1 === null) && ((typeof cidr2 === 'string') || cidr2 === null) && ((typeof result === 'boolean') || result === null) && ((typeof equal === 'boolean') || equal === null)) {
            return <any>this.testContains$java_lang_String$java_lang_String$boolean$boolean(cidr1, cidr2, result, equal);
        } else if(((typeof cidr1 === 'string') || cidr1 === null) && ((typeof cidr2 === 'string') || cidr2 === null) && ((typeof result === 'boolean') || result === null) && equal === undefined) {
            return <any>this.testContains$java_lang_String$java_lang_String$boolean(cidr1, cidr2, result);
        } else throw new Error('invalid overload');
    }

    testNotContains(cidr1 : string, cidr2 : string) {
        try {
            let w : IPAddress = this.createAddress$java_lang_String(cidr1).toAddress();
            let w2 : IPAddress = this.createAddress$java_lang_String(cidr2).toAddress();
            if(w.contains(w2)) {
                this.addFailure(new TestBase.Failure("failed " + w2, w));
            } else if(w2.contains(w)) {
                this.addFailure(new TestBase.Failure("failed " + w, w2));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e));
        };
        this.incrementTestCount();
    }

    printStrings(section : IPAddressSection) {
        let strs : string[] = section.toStandardStringCollection().toStrings();
        let count : number = 0;
        console.info("listing strings for " + section);
        for(let index152=0; index152 < strs.length; index152++) {
            let str = strs[index152];
            {
                console.info("\t" + ++count + ": " + str);
            }
        }
    }

    testSplit(address : string, bits : number, network : string, networkNoRange : string, networkWithPrefix : string, networkStringCount : number, host : string, hostStringCount : number) {
        try {
            let w : IPAddressString = this.createAddress$java_lang_String(address);
            let v : IPAddress = w.getAddress();
            let section : IPAddressSection = v['getNetworkSection$int$boolean'](bits, false);
            let sectionStr : string = section.toNormalizedString();
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(sectionStr,network))) {
                this.addFailure(new TestBase.Failure("failed got " + sectionStr + " expected " + network, w));
            } else {
                let sectionWithPrefix : IPAddressSection = v['getNetworkSection$int'](bits);
                let sectionStrWithPrefix : string = sectionWithPrefix.toNormalizedString();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(sectionStrWithPrefix,networkWithPrefix))) {
                    this.addFailure(new TestBase.Failure("failed got " + sectionStrWithPrefix + " expected " + networkWithPrefix, w));
                } else {
                    let s : IPAddressSection = section.isPrefixed()?section.removePrefixLength():section.getLower();
                    let sectionStrNoRange : string = s.toNormalizedString();
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(sectionStrNoRange,networkNoRange)) || s.getCount().intValue() !== 1) {
                        this.addFailure(new TestBase.Failure("failed got " + sectionStrNoRange + " expected " + networkNoRange, w));
                    } else {
                        let coll : IPAddressPartStringCollection = sectionWithPrefix.toStandardStringCollection();
                        let standards : string[] = coll.toStrings();
                        if(standards.length !== networkStringCount) {
                            this.addFailure(new TestBase.Failure("failed " + section + " expected count " + networkStringCount + " was " + standards.length, w));
                        } else {
                            section = v['getHostSection$int'](bits);
                            sectionStr = section.toNormalizedString();
                            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(sectionStr,host))) {
                                this.addFailure(new TestBase.Failure("failed " + section + " expected " + host, w));
                            } else {
                                let standardStrs : string[] = section.toStandardStringCollection().toStrings();
                                if(standardStrs.length !== hostStringCount) {
                                    this.addFailure(new TestBase.Failure("failed " + section + " expected count " + hostStringCount + " was " + standardStrs.length, w));
                                }
                            }
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected throw: " + e));
        };
        this.incrementTestCount();
    }

    static isSameAllAround(supplied : IPAddress, internal : IPAddress) : boolean {
        return supplied.equals(internal) && internal.equals(supplied) && Objects.equals(internal.getNetworkPrefixLength(), supplied.getNetworkPrefixLength()) && internal.getMinPrefixLengthForBlock() === supplied.getMinPrefixLengthForBlock() && Objects.equals(internal.getPrefixLengthForSingleBlock(), supplied.getPrefixLengthForSingleBlock()) && internal.getCount().equals(supplied.getCount());
    }

    testNetmasks(prefix : number, ipv4NetworkAddress : string, ipv4NetworkAddressNoPrefix : string, ipv4HostAddress : string, ipv6NetworkAddress : string, ipv6NetworkAddressNoPrefix : string, ipv6HostAddress : string) {
        let ipv6Addr : IPAddressString = this.createAddress$java_lang_String(ipv6NetworkAddress);
        let ipv4Addr : IPAddressString = this.createAddress$java_lang_String(ipv4NetworkAddress);
        if(prefix <= IPv6Address.BIT_COUNT) {
            let w2NoPrefix : IPAddressString = this.createAddress$java_lang_String(ipv6NetworkAddressNoPrefix);
            try {
                IPAddressString.validateNetworkPrefixLength(IPAddress.IPVersion.IPV6, "" + prefix);
                let ipv6AddrValue : IPAddress = ipv6Addr.toAddress();
                let ipv6network : IPAddressNetwork<any, any, any, any, any> = ipv6AddrValue.getNetwork();
                let addr6 : IPAddress = ipv6network.getNetworkMask(prefix);
                let addr6NoPrefix : IPAddress = ipv6network.getNetworkMask(prefix, false);
                let w2ValueNoPrefix : IPAddress = w2NoPrefix.toAddress();
                let one : boolean;
                if((one = !IPAddressTest.isSameAllAround(ipv6AddrValue, addr6)) || !IPAddressTest.isSameAllAround(w2ValueNoPrefix, addr6NoPrefix)) {
                    one = !IPAddressTest.isSameAllAround(ipv6AddrValue, addr6);
                    IPAddressTest.isSameAllAround(w2ValueNoPrefix, addr6NoPrefix);
                    this.addFailure(one?new TestBase.Failure("failed " + addr6, ipv6AddrValue):new TestBase.Failure("failed " + addr6NoPrefix, w2ValueNoPrefix));
                } else {
                    addr6 = ipv6network.getHostMask(prefix);
                    ipv6Addr = this.createAddress$java_lang_String(ipv6HostAddress);
                    try {
                        ipv6AddrValue = ipv6Addr.toAddress();
                        if(!IPAddressTest.isSameAllAround(ipv6AddrValue, addr6)) {
                            this.addFailure(new TestBase.Failure("failed " + addr6, ipv6Addr));
                        } else if(prefix <= IPv4Address.BIT_COUNT) {
                            let wNoPrefix : IPAddressString = this.createAddress$java_lang_String(ipv4NetworkAddressNoPrefix);
                            try {
                                IPAddressString.validateNetworkPrefixLength(IPAddress.IPVersion.IPV4, "" + prefix);
                                let wValue : IPAddress = ipv4Addr.toAddress();
                                let ipv4network : IPAddressNetwork<any, any, any, any, any> = wValue.getNetwork();
                                let addr4 : IPAddress = ipv4network.getNetworkMask(prefix);
                                let addr4NoPrefix : IPAddress = ipv4network.getNetworkMask(prefix, false);
                                let wValueNoPrefix : IPAddress = wNoPrefix.toAddress();
                                if((one = !IPAddressTest.isSameAllAround(wValue, addr4)) || !IPAddressTest.isSameAllAround(wValueNoPrefix, addr4NoPrefix)) {
                                    this.addFailure(one?new TestBase.Failure("failed " + addr4, wValue):new TestBase.Failure("failed " + addr4NoPrefix, wValueNoPrefix));
                                } else {
                                    addr4 = ipv4network.getHostMask(prefix);
                                    ipv4Addr = this.createAddress$java_lang_String(ipv4HostAddress);
                                    try {
                                        wValue = ipv4Addr.toAddress();
                                        if(!IPAddressTest.isSameAllAround(wValue, addr4)) {
                                            this.addFailure(new TestBase.Failure("failed " + addr4, ipv4Addr));
                                        }
                                    } catch(e) {
                                        this.addFailure(new TestBase.Failure("failed " + addr4, ipv4Addr));
                                    };
                                }
                            } catch(e) {
                                this.addFailure(new TestBase.Failure("failed prefix val", ipv4Addr));
                            };
                        } else {
                            try {
                                ipv4Addr.toAddress();
                                this.addFailure(new TestBase.Failure("succeeded with invalid prefix", ipv4Addr));
                            } catch(e) {
                            };
                        }
                    } catch(e) {
                        this.addFailure(new TestBase.Failure("failed " + addr6, ipv6Addr));
                    };
                }
            } catch(e) {
                this.addFailure(new TestBase.Failure("failed prefix val", ipv6Addr));
            };
        } else {
            try {
                ipv6Addr.toAddress();
                this.addFailure(new TestBase.Failure("succeeded with invalid prefix", ipv6Addr));
            } catch(e) {
                try {
                    ipv4Addr.toAddress();
                    this.addFailure(new TestBase.Failure("succeeded with invalid prefix", ipv4Addr));
                } catch(e4) {
                };
            };
        }
        this.incrementTestCount();
    }

    static count(str : string, match : string) : number {
        let count : number = 0;
        for(let index : number = -1; (index = str.indexOf(match, index + 1)) >= 0; count++) ;
        return count;
    }

    testURL(url : string) {
        let w : IPAddressString = this.createAddress$java_lang_String(url);
        try {
            w.toAddress();
            this.addFailure(new TestBase.Failure("failed: " + "URL " + url, w));
        } catch(e) {
            e.message;
        };
    }

    testSections(address : string, bits : number, count : number) {
        let w : IPAddressString = this.createAddress$java_lang_String(address);
        let v : IPAddress = w.getAddress();
        let section : IPAddressSection = v['getNetworkSection$int$boolean'](bits, false);
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        section.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String(builder, "XXX");
        let clause : string = /* toString */builder.str;
        let found : number = IPAddressTest.count(clause, "OR") + 1;
        if(found !== count) {
            this.addFailure(new TestBase.Failure("failed: " + "Finding first " + ((bits / v.getBitsPerSegment()|0)) + " segments of " + v, w));
        }
        this.incrementTestCount();
    }

    static conversionCompare(h1 : IPAddressString, h2 : IPAddressString) : number {
        if(h1.isIPv4()) {
            if(!h2.isIPv4()) {
                if(h2.getAddress() != null && h2.getAddress().isIPv4Convertible()) {
                    return h1.getAddress().compareTo(h2.getAddress().toIPv4());
                }
            }
        } else if(h1.isIPv6()) {
            if(!h2.isIPv6()) {
                if(h2.getAddress() != null && h2.getAddress().isIPv6Convertible()) {
                    return h1.getAddress().compareTo(h2.getAddress().toIPv6());
                }
            }
        }
        return -1;
    }

    static conversionMatches(h1 : IPAddressString, h2 : IPAddressString) : boolean {
        if(h1.isIPv4()) {
            if(!h2.isIPv4()) {
                if(h2.getAddress() != null && h2.getAddress().isIPv4Convertible()) {
                    return h1.getAddress().equals(h2.getAddress().toIPv4());
                }
            }
        } else if(h1.isIPv6()) {
            if(!h2.isIPv6()) {
                if(h2.getAddress() != null && h2.getAddress().isIPv6Convertible()) {
                    return h1.getAddress().equals(h2.getAddress().toIPv6());
                }
            }
        }
        return false;
    }

    testMatches$boolean$java_lang_String$java_lang_String(matches : boolean, host1Str : string, host2Str : string) {
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(matches, host1Str, host2Str, false);
    }

    public testMatches$boolean$java_lang_String$java_lang_String$boolean(matches : boolean, host1Str : string, host2Str : string, inet_aton : boolean) {
        let h1 : IPAddressString = inet_aton?this.createInetAtonAddress(host1Str):this.createAddress$java_lang_String(host1Str);
        let h2 : IPAddressString = inet_aton?this.createInetAtonAddress(host2Str):this.createAddress$java_lang_String(host2Str);
        if(matches !== h1.equals(h2) && matches !== IPAddressTest.conversionMatches(h1, h2)) {
            this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h2, h1));
        } else {
            if(matches !== h2.equals(h1) && matches !== IPAddressTest.conversionMatches(h2, h1)) {
                this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h1, h2));
            } else {
                if(matches?(h1.compareTo(h2) !== 0 && IPAddressTest.conversionCompare(h1, h2) !== 0):(h1.compareTo(h2) === 0)) {
                    this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h1, h2));
                } else {
                    if(matches?(h2.compareTo(h1) !== 0 && IPAddressTest.conversionCompare(h2, h1) !== 0):(h2.compareTo(h1) === 0)) {
                        this.addFailure(new TestBase.Failure("failed: match " + (matches?"fails":"passes") + " with " + h2, h1));
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    public testMatches(matches? : any, host1Str? : any, host2Str? : any, inet_aton? : any) : any {
        if(((typeof matches === 'boolean') || matches === null) && ((typeof host1Str === 'string') || host1Str === null) && ((typeof host2Str === 'string') || host2Str === null) && ((typeof inet_aton === 'boolean') || inet_aton === null)) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String$boolean(matches, host1Str, host2Str, inet_aton);
        } else if(((typeof matches === 'boolean') || matches === null) && ((typeof host1Str === 'string') || host1Str === null) && ((typeof host2Str === 'string') || host2Str === null) && inet_aton === undefined) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String(matches, host1Str, host2Str);
        } else throw new Error('invalid overload');
    }

    testSQL(addr : string, matches : IPAddressTest.ExpectedMatch[]) {
        try {
            let w : IPAddress = this.createAddress$java_lang_String(addr).toAddress();
            let network : IPAddressSection;
            if(w.isPrefixed()) {
                network = w['getNetworkSection$int$boolean'](w.getNetworkPrefixLength(), false);
            } else {
                network = w.getSection();
            }
            let translator : IPAddressTest.TestSQLTranslator = new IPAddressTest.TestSQLTranslator();
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            network.getStartsWithSQLClause$java_lang_StringBuilder$java_lang_String$inet_ipaddr_format_util_sql_IPAddressSQLTranslator(builder, "COLUMN", translator);
            let expectedConditions : any = <any>({});
            for(let index153=0; index153 < matches.length; index153++) {
                let match = matches[index153];
                {
                    /* put */(expectedConditions[match.networkString] = match.conditions);
                }
            }
            if(!translator.test(expectedConditions)) {
                this.addFailure(new TestBase.Failure("failed got:\n" + builder + "\nexpected:\n" + translator.expected("COLUMN", expectedConditions, w.isIPv4()), w));
            } else {
                let actual : string = /* toString */builder.str;
                let expected : string = translator.expected("COLUMN", expectedConditions, w.isIPv4());
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(actual,expected))) {
                    this.addFailure(new TestBase.Failure("failed got string:\n" + builder + "\nexpected:\n" + translator.expected("COLUMN", expectedConditions, w.isIPv4()), w));
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e));
        };
        this.incrementTestCount();
    }

    testSQLMatching() {
        this.testSQL("1.2.3.4/16", [new IPAddressTest.ExpectedMatch("1.2", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1.2")))]);
        this.testSQL("1.2.3.4/8", [new IPAddressTest.ExpectedMatch("1", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(1, "1")))]);
        this.testSQL("1.2.3.4", [new IPAddressTest.ExpectedMatch("1.2.3.4", new IPAddressTest.MatchConditions("1.2.3.4"))]);
        this.testSQL("a::/64", [new IPAddressTest.ExpectedMatch("a:0:0:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(4, "a:0:0:0"))), new IPAddressTest.ExpectedMatch("a::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "a:"), null, 5))]);
        this.testSQL("1:a::/32", [new IPAddressTest.ExpectedMatch("1:a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1:a")))]);
        this.testSQL("0:a::/32", [new IPAddressTest.ExpectedMatch("0:a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "0:a"))), new IPAddressTest.ExpectedMatch("::a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "::a"), 8, null))]);
        this.testSQL("0:a::/48", [new IPAddressTest.ExpectedMatch("0:a:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "0:a:0"))), new IPAddressTest.ExpectedMatch("::a:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(4, "::a:0"), 8, null)), new IPAddressTest.ExpectedMatch("0:a::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "0:a:"), null, 7))]);
        this.testSQL("1:a::/48", [new IPAddressTest.ExpectedMatch("1:a:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "1:a:0"))), new IPAddressTest.ExpectedMatch("1:a::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "1:a:"), null, 7))]);
        this.testSQL("1:a::/64", [new IPAddressTest.ExpectedMatch("1:a:0:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(4, "1:a:0:0"))), new IPAddressTest.ExpectedMatch("1:a::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "1:a:"), null, 6))]);
        this.testSQL("1:1:a::/48", [new IPAddressTest.ExpectedMatch("1:1:a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "1:1:a")))]);
        this.testSQL("0:0:a::/48", [new IPAddressTest.ExpectedMatch("0:0:a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "0:0:a"))), new IPAddressTest.ExpectedMatch("::a", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "::a"), 7, null))]);
        this.testSQL("0:0:a::/64", [new IPAddressTest.ExpectedMatch("0:0:a:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(4, "0:0:a:0"))), new IPAddressTest.ExpectedMatch("::a:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(4, "::a:0"), 7, null))]);
        this.testSQL("0:0:a::/128", [new IPAddressTest.ExpectedMatch("0:0:a:0:0:0:0:0", new IPAddressTest.MatchConditions("0:0:a:0:0:0:0:0")), new IPAddressTest.ExpectedMatch("0:0:a::", new IPAddressTest.MatchConditions("0:0:a::"))]);
        this.testSQL("0:0:a::", [new IPAddressTest.ExpectedMatch("0:0:a:0:0:0:0:0", new IPAddressTest.MatchConditions("0:0:a:0:0:0:0:0")), new IPAddressTest.ExpectedMatch("0:0:a::", new IPAddressTest.MatchConditions("0:0:a::"))]);
        this.testSQL("1::3:b/0", []);
        this.testSQL("1::3:b/16", [new IPAddressTest.ExpectedMatch("1", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(1, "1")))]);
        this.testSQL("1::3:b/32", [new IPAddressTest.ExpectedMatch("1:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1:0"))), new IPAddressTest.ExpectedMatch("1::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1:"), null, 7))]);
        this.testSQL("1::3:b/80", [new IPAddressTest.ExpectedMatch("1:0:0:0:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(5, "1:0:0:0:0"))), new IPAddressTest.ExpectedMatch("1::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1:"), null, 4))]);
        this.testSQL("1::3:b/96", [new IPAddressTest.ExpectedMatch("1:0:0:0:0:0", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(6, "1:0:0:0:0:0"))), new IPAddressTest.ExpectedMatch("1::", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(2, "1:"), null, 3))]);
        this.testSQL("1::3:b/112", [new IPAddressTest.ExpectedMatch("1:0:0:0:0:0:3", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(7, "1:0:0:0:0:0:3"))), new IPAddressTest.ExpectedMatch("1::3", new IPAddressTest.MatchConditions(new IPAddressTest.SubMatch(3, "1::3"), 3, null))]);
        this.testSQL("1::3:b/128", [new IPAddressTest.ExpectedMatch("1:0:0:0:0:0:3:b", new IPAddressTest.MatchConditions("1:0:0:0:0:0:3:b")), new IPAddressTest.ExpectedMatch("1::3:b", new IPAddressTest.MatchConditions("1::3:b"))]);
    }

    testEquivalentPrefix$java_lang_String$int(host : string, prefix : number) {
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host, prefix, prefix);
    }

    public testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host : string, equivPrefix : number, minPrefix : number) {
        let str : IPAddressString = this.createAddress$java_lang_String(host);
        try {
            let h1 : IPAddress = str.toAddress();
            let equiv : number = h1.getPrefixLengthForSingleBlock();
            if(equiv == null?(equivPrefix != null):(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(equivPrefix,equiv)))) {
                equiv = h1.getPrefixLengthForSingleBlock();
                this.addFailure(new TestBase.Failure("failed: prefix expected: " + equivPrefix + " prefix got: " + equiv, h1));
            } else {
                let prefixed : IPAddress = h1.assignPrefixForSingleBlock();
                let bareHost : string;
                let index : number = host.indexOf('/');
                if(index === -1) {
                    bareHost = host;
                } else {
                    bareHost = host.substring(0, index);
                }
                let direct : IPAddressString = this.createAddress$java_lang_String(bareHost + '/' + equivPrefix);
                let directAddress : IPAddress = direct.getAddress();
                let zeroSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].zeroHostsAreSubnets();
                if(equivPrefix != null && h1.isPrefixed() && zeroSubnets && h1.isPrefixBlock()) {
                    directAddress = this.makePrefixSubnet(directAddress);
                }
                if(equiv == null?prefixed != null:!directAddress.equals(prefixed)) {
                    this.addFailure(new TestBase.Failure("failed: prefix expected: " + direct, prefixed));
                } else {
                    let minPref : number = h1.getMinPrefixLengthForBlock();
                    if(minPref !== minPrefix) {
                        this.addFailure(new TestBase.Failure("failed: prefix expected: " + minPrefix + " prefix got: " + minPref, h1));
                    } else {
                        let minPrefixed : IPAddress = h1.assignMinPrefixForBlock();
                        index = host.indexOf('/');
                        if(index === -1) {
                            bareHost = host;
                        } else {
                            bareHost = host.substring(0, index);
                        }
                        direct = this.createAddress$java_lang_String(bareHost + '/' + minPrefix);
                        directAddress = direct.getAddress();
                        if(h1.isPrefixed() && zeroSubnets && h1.isPrefixBlock()) {
                            directAddress = this.makePrefixSubnet(directAddress);
                        }
                        if(!directAddress.equals(minPrefixed)) {
                            this.addFailure(new TestBase.Failure("failed: prefix expected: " + direct, minPrefixed));
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed " + e, str));
        };
        this.incrementTestCount();
    }

    public testEquivalentPrefix(host? : any, equivPrefix? : any, minPrefix? : any) : any {
        if(((typeof host === 'string') || host === null) && ((typeof equivPrefix === 'number') || equivPrefix === null) && ((typeof minPrefix === 'number') || minPrefix === null)) {
            return <any>this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host, equivPrefix, minPrefix);
        } else if(((typeof host === 'string') || host === null) && ((typeof equivPrefix === 'number') || equivPrefix === null) && minPrefix === undefined) {
            return <any>this.testEquivalentPrefix$java_lang_String$int(host, equivPrefix);
        } else throw new Error('invalid overload');
    }

    makePrefixSubnet(directAddress : IPAddress) : IPAddress {
        let segs : IPAddressSegment[] = directAddress.getSegments();
        let pref : number = directAddress.getPrefixLength();
        let prefSeg : number = (pref / directAddress.getBitsPerSegment()|0);
        if(prefSeg < segs.length) {
            let network : IPAddressNetwork<any, any, any, any, any> = directAddress.getNetwork();
            let creator : IPAddressNetwork.IPAddressCreator<any, any, any, any, any> = network.getAddressCreator();
            if(directAddress.getPrefixCount().equals(BigInteger.ONE)) {
                let origSeg : IPAddressSegment = segs[prefSeg];
                let mask : number = network.getSegmentNetworkMask(pref % directAddress.getBitsPerSegment());
                segs[prefSeg] = creator.createSegment$int$int$java_lang_Integer(origSeg.getLowerSegmentValue() & mask, origSeg.getUpperSegmentValue() & mask, origSeg.getSegmentPrefixLength());
                for(let ps : number = prefSeg + 1; ps < segs.length; ps++) {
                    segs[ps] = creator['createSegment$int$java_lang_Integer'](0, 0);
                };
                let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(directAddress.getByteCount());
                let bytesPerSegment : number = directAddress.getBytesPerSegment();
                for(let i : number = 0, j : number = 0; i < segs.length; i++, j += bytesPerSegment) {
                    segs[i].getBytes$byte_A$int(bytes, j);
                };
                directAddress = creator.createAddress$byte_A$java_lang_Integer(bytes, pref);
            } else {
                let origSeg : IPAddressSegment = segs[prefSeg];
                let mask : number = network.getSegmentNetworkMask(pref % directAddress.getBitsPerSegment());
                let maxValue : number = directAddress.getMaxSegmentValue();
                directAddress = creator.createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(new IPAddressTest.IPAddressTest$0(this, prefSeg, segs, origSeg, mask), new IPAddressTest.IPAddressTest$1(this, prefSeg, segs, origSeg, mask, maxValue), pref);
            }
        }
        return directAddress;
    }

    testSubnet(addressStr : string, maskStr : string, prefix : number, normalizedPrefixSubnetString : string, normalizedSubnetString : string, normalizedPrefixString : string) {
        this.testHostAddress$java_lang_String(addressStr);
        let isValidWithPrefix : boolean = normalizedPrefixSubnetString != null;
        let isValidMask : boolean = normalizedSubnetString != null;
        let str : IPAddressString = this.createAddress$java_lang_String(addressStr);
        let maskString : IPAddressString = this.createAddress$java_lang_String(maskStr);
        try {
            let value : IPAddress = str.toAddress();
            let originalPrefix : number = value.getNetworkPrefixLength();
            try {
                let mask : IPAddress = maskString.toAddress();
                let subnet3 : IPAddress = value.applyPrefixLength(prefix);
                let string3 : string = subnet3.toNormalizedString();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string3,normalizedPrefixString))) {
                    this.addFailure(new TestBase.Failure("testSubnet failed normalizedPrefixString: " + string3 + " expected: " + normalizedPrefixString, subnet3));
                } else {
                    try {
                        let subnet : IPAddress = value.maskNetwork(mask, prefix);
                        if(!isValidWithPrefix) {
                            this.addFailure(new TestBase.Failure("testSubnet failed to throw with mask " + mask + " and prefix " + prefix, value));
                        } else {
                            let string : string = subnet.toNormalizedString();
                            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string,normalizedPrefixSubnetString))) {
                                this.addFailure(new TestBase.Failure("testSubnet failed: " + string + " expected: " + normalizedPrefixSubnetString, subnet));
                            } else {
                                try {
                                    let subnet2 : IPAddress = value.mask$inet_ipaddr_IPAddress(mask);
                                    if(!isValidMask) {
                                        this.addFailure(new TestBase.Failure("testSubnet failed to throw with mask " + mask, value));
                                    } else {
                                        let string2 : string = subnet2.toNormalizedString();
                                        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string2,normalizedSubnetString))) {
                                            this.addFailure(new TestBase.Failure("testSubnet failed: " + string2 + " expected: " + normalizedSubnetString, subnet2));
                                        } else {
                                            if(subnet2.getNetworkPrefixLength() != null) {
                                                this.addFailure(new TestBase.Failure("testSubnet failed, expected null prefix, got: " + subnet2.getNetworkPrefixLength(), subnet2));
                                            } else {
                                                let subnet4 : IPAddress = value.mask$inet_ipaddr_IPAddress$boolean(mask, true);
                                                if(!Objects.equals(subnet4.getNetworkPrefixLength(), originalPrefix)) {
                                                    this.addFailure(new TestBase.Failure("testSubnet failed, expected " + originalPrefix + " prefix, got: " + subnet4.getNetworkPrefixLength(), subnet2));
                                                } else {
                                                    if(originalPrefix != null) {
                                                        let addr : IPAddress = subnet2.setPrefixLength$int$boolean(originalPrefix, false);
                                                        if(!subnet4.equals(addr)) {
                                                            this.addFailure(new TestBase.Failure("testSubnet failed: " + subnet4 + " expected: " + addr, subnet4));
                                                        }
                                                    } else {
                                                        if(!subnet4.equals(subnet2)) {
                                                            this.addFailure(new TestBase.Failure("testSubnet failed: " + subnet4 + " expected: " + subnet2, subnet4));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } catch(e) {
                                    if(isValidMask) {
                                        this.addFailure(new TestBase.Failure("testSubnet failed with mask " + mask + " " + e, value));
                                    }
                                };
                            }
                        }
                    } catch(e) {
                        if(isValidWithPrefix) {
                            this.addFailure(new TestBase.Failure("testSubnet failed with mask " + mask + " and prefix " + prefix + ": " + e, value));
                        } else {
                            try {
                                let subnet2 : IPAddress = value.mask$inet_ipaddr_IPAddress(mask);
                                if(!isValidMask) {
                                    this.addFailure(new TestBase.Failure("testSubnet failed to throw with mask " + mask, value));
                                } else {
                                    let string2 : string = subnet2.toNormalizedString();
                                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(string2,normalizedSubnetString))) {
                                        this.addFailure(new TestBase.Failure("testSubnet failed: " + normalizedSubnetString + " expected: " + string2, subnet2));
                                    }
                                }
                            } catch(e2) {
                                if(isValidMask) {
                                    this.addFailure(new TestBase.Failure("testSubnet failed with mask " + mask + " " + e2, value));
                                }
                            };
                        }
                    };
                }
            } catch(e) {
                this.addFailure(new TestBase.Failure("testSubnet failed " + e, maskString));
            };
        } catch(e) {
            this.addFailure(new TestBase.Failure("testSubnet failed " + e, str));
        };
        this.incrementTestCount();
    }

    public testReverse$java_lang_String$boolean$boolean(addressStr : string, bitsReversedIsSame : boolean, bitsReversedPerByteIsSame : boolean) {
        let str : IPAddressString = this.createAddress$java_lang_String(addressStr);
        try {
            this.testReverse$inet_ipaddr_AddressSegmentSeries$boolean$boolean(str.getAddress(), bitsReversedIsSame, bitsReversedPerByteIsSame);
        } catch(e) {
            this.addFailure(new TestBase.Failure("reversal: " + addressStr));
        };
        this.incrementTestCount();
    }

    public testReverse(addressStr? : any, bitsReversedIsSame? : any, bitsReversedPerByteIsSame? : any) : any {
        if(((typeof addressStr === 'string') || addressStr === null) && ((typeof bitsReversedIsSame === 'boolean') || bitsReversedIsSame === null) && ((typeof bitsReversedPerByteIsSame === 'boolean') || bitsReversedPerByteIsSame === null)) {
            return <any>this.testReverse$java_lang_String$boolean$boolean(addressStr, bitsReversedIsSame, bitsReversedPerByteIsSame);
        } else if(((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || addressStr === null) && ((typeof bitsReversedIsSame === 'boolean') || bitsReversedIsSame === null) && ((typeof bitsReversedPerByteIsSame === 'boolean') || bitsReversedPerByteIsSame === null)) {
            super.testReverse(addressStr, bitsReversedIsSame, bitsReversedPerByteIsSame);
        } else throw new Error('invalid overload');
    }

    public testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(orig : string, prefix : number, adjustment : number, next : string, previous : string, adjusted : string, prefixSet : string, prefixApplied : string) {
        let original : IPAddress = this.createAddress$java_lang_String(orig).getAddress();
        if(original.isPrefixed()) {
            let removed : AddressSegmentSeries = original.removePrefixLength$boolean(false);
            for(let i : number = 0; i < removed.getSegmentCount(); i++) {
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(removed.getSegment(i),original.getSegment(i)))) {
                    this.addFailure(new TestBase.Failure("removed prefix: " + removed, original));
                    break;
                }
            };
        }
        this.testPrefixes$inet_ipaddr_AddressSegmentSeries$int$int$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries$inet_ipaddr_AddressSegmentSeries(original, prefix, adjustment, this.createAddress$java_lang_String(next).getAddress(), this.createAddress$java_lang_String(previous).getAddress(), this.createAddress$java_lang_String(adjusted).getAddress(), this.createAddress$java_lang_String(prefixSet).getAddress(), this.createAddress$java_lang_String(prefixApplied).getAddress());
        this.incrementTestCount();
    }

    public testPrefixes(orig? : any, prefix? : any, adjustment? : any, next? : any, previous? : any, adjusted? : any, prefixSet? : any, prefixApplied? : any) : any {
        if(((typeof orig === 'string') || orig === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof adjustment === 'number') || adjustment === null) && ((typeof next === 'string') || next === null) && ((typeof previous === 'string') || previous === null) && ((typeof adjusted === 'string') || adjusted === null) && ((typeof prefixSet === 'string') || prefixSet === null) && ((typeof prefixApplied === 'string') || prefixApplied === null)) {
            return <any>this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(orig, prefix, adjustment, next, previous, adjusted, prefixSet, prefixApplied);
        } else if(((orig != null && (orig["__interfaces"] != null && orig["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || orig.constructor != null && orig.constructor["__interfaces"] != null && orig.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || orig === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof adjustment === 'number') || adjustment === null) && ((next != null && (next["__interfaces"] != null && next["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || next.constructor != null && next.constructor["__interfaces"] != null && next.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || next === null) && ((previous != null && (previous["__interfaces"] != null && previous["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || previous.constructor != null && previous.constructor["__interfaces"] != null && previous.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || previous === null) && ((adjusted != null && (adjusted["__interfaces"] != null && adjusted["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || adjusted.constructor != null && adjusted.constructor["__interfaces"] != null && adjusted.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || adjusted === null) && ((prefixSet != null && (prefixSet["__interfaces"] != null && prefixSet["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixSet.constructor != null && prefixSet.constructor["__interfaces"] != null && prefixSet.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixSet === null) && ((prefixApplied != null && (prefixApplied["__interfaces"] != null && prefixApplied["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0 || prefixApplied.constructor != null && prefixApplied.constructor["__interfaces"] != null && prefixApplied.constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegmentSeries") >= 0)) || prefixApplied === null)) {
            super.testPrefixes(orig, prefix, adjustment, next, previous, adjusted, prefixSet, prefixApplied);
        } else throw new Error('invalid overload');
    }

    testPrefixBlocks$java_lang_String$boolean$boolean(orig : string, isPrefixBlock : boolean, isSinglePrefixBlock : boolean) {
        let original : IPAddress = this.createAddress$java_lang_String(orig).getAddress();
        if(isPrefixBlock !== original.isPrefixBlock()) {
            this.addFailure(new TestBase.Failure("is prefix block: " + original.isPrefixBlock() + " expected: " + isPrefixBlock, original));
        } else if(isSinglePrefixBlock !== original.isSinglePrefixBlock()) {
            this.addFailure(new TestBase.Failure("is single prefix block: " + original.isSinglePrefixBlock() + " expected: " + isSinglePrefixBlock, original));
        }
        this.incrementTestCount();
    }

    public testPrefixBlocks$java_lang_String$int$boolean$boolean(orig : string, prefix : number, containsPrefixBlock : boolean, containsSinglePrefixBlock : boolean) {
        let original : IPAddress = this.createAddress$java_lang_String(orig).getAddress();
        if(containsPrefixBlock !== original.containsPrefixBlock(prefix)) {
            this.addFailure(new TestBase.Failure("contains prefix block: " + original.containsPrefixBlock(prefix) + " expected: " + containsPrefixBlock, original));
        } else if(containsSinglePrefixBlock !== original.containsSinglePrefixBlock(prefix)) {
            this.addFailure(new TestBase.Failure("contains single prefix block: " + original.containsSinglePrefixBlock(prefix) + " expected: " + containsPrefixBlock, original));
        }
        this.incrementTestCount();
    }

    public testPrefixBlocks(orig? : any, prefix? : any, containsPrefixBlock? : any, containsSinglePrefixBlock? : any) : any {
        if(((typeof orig === 'string') || orig === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof containsPrefixBlock === 'boolean') || containsPrefixBlock === null) && ((typeof containsSinglePrefixBlock === 'boolean') || containsSinglePrefixBlock === null)) {
            return <any>this.testPrefixBlocks$java_lang_String$int$boolean$boolean(orig, prefix, containsPrefixBlock, containsSinglePrefixBlock);
        } else if(((typeof orig === 'string') || orig === null) && ((typeof prefix === 'boolean') || prefix === null) && ((typeof containsPrefixBlock === 'boolean') || containsPrefixBlock === null) && containsSinglePrefixBlock === undefined) {
            return <any>this.testPrefixBlocks$java_lang_String$boolean$boolean(orig, prefix, containsPrefixBlock);
        } else throw new Error('invalid overload');
    }

    testBitwiseOr(orig : string, prefixAdjustment : number, or : string, expectedResult : string) {
        let original : IPAddress = this.createAddress$java_lang_String(orig).getAddress();
        let orAddr : IPAddress = this.createAddress$java_lang_String(or).getAddress();
        if(prefixAdjustment != null) {
            original = original.adjustPrefixLength$int(prefixAdjustment);
        }
        try {
            let result : IPAddress = original.bitwiseOr$inet_ipaddr_IPAddress(orAddr);
            if(expectedResult == null) {
                original.bitwiseOr$inet_ipaddr_IPAddress(orAddr);
                this.addFailure(new TestBase.Failure("ored expected throw " + original + " orAddr: " + orAddr + " result: " + result, original));
            } else {
                let expectedResultAddr : IPAddress = this.createAddress$java_lang_String(expectedResult).getAddress();
                if(!expectedResultAddr.equals(result)) {
                    this.addFailure(new TestBase.Failure("ored expected: " + expectedResultAddr + " actual: " + result, original));
                }
                if(result.getPrefixLength() != null) {
                    this.addFailure(new TestBase.Failure("ored expected null prefix: " + expectedResultAddr + " actual: " + result.getPrefixLength(), original));
                }
            }
        } catch(e) {
            if(expectedResult != null) {
                this.addFailure(new TestBase.Failure("ored threw unexpectedly " + original + " orAddr: " + orAddr, original));
            }
        };
        this.incrementTestCount();
    }

    testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(orig : string, prefix : number, or : string, expectedNetworkResult : string) {
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String(orig, prefix, or, expectedNetworkResult, null);
    }

    public testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String(orig : string, prefix : number, or : string, expectedNetworkResult : string, expectedFullResult : string) {
        let original : IPAddress = this.createAddress$java_lang_String(orig).getAddress();
        let orAddr : IPAddress = this.createAddress$java_lang_String(or).getAddress();
        try {
            let result : IPAddress = original.bitwiseOrNetwork(orAddr, prefix);
            if(expectedNetworkResult == null) {
                this.addFailure(new TestBase.Failure("ored network expected throw " + original + " orAddr: " + orAddr + " result: " + result, original));
            } else {
                let expected : IPAddressString = this.createAddress$java_lang_String(expectedNetworkResult);
                let expectedResultAddr : IPAddress = expected.getAddress();
                if(!expectedResultAddr.equals(result) || !Objects.equals(expectedResultAddr.getPrefixLength(), result.getPrefixLength())) {
                    result = original.bitwiseOrNetwork(orAddr, prefix);
                    this.addFailure(new TestBase.Failure("ored network expected: " + expectedResultAddr + " actual: " + result, original));
                }
            }
        } catch(e) {
            if(expectedNetworkResult != null) {
                this.addFailure(new TestBase.Failure("ored threw unexpectedly " + original + " orAddr: " + orAddr, original));
            }
        };
        try {
            let result : IPAddress = original.bitwiseOr$inet_ipaddr_IPAddress$boolean(orAddr, true);
            if(expectedFullResult == null) {
                this.addFailure(new TestBase.Failure("ored expected throw " + original + " orAddr: " + orAddr + " result: " + result, original));
            } else {
                let expected : IPAddressString = this.createAddress$java_lang_String(expectedFullResult);
                let expectedResultAddr : IPAddress = expected.getAddress();
                if(!expectedResultAddr.equals(result) || !Objects.equals(expectedResultAddr.getPrefixLength(), result.getPrefixLength())) {
                    result = original.bitwiseOr$inet_ipaddr_IPAddress$boolean(orAddr, true);
                    this.addFailure(new TestBase.Failure("ored expected: " + expectedResultAddr + " actual: " + result, original));
                }
            }
        } catch(e) {
            if(expectedFullResult != null) {
                this.addFailure(new TestBase.Failure("ored threw unexpectedly " + original + " orAddr: " + orAddr, original));
            }
        };
        this.incrementTestCount();
    }

    public testPrefixBitwiseOr(orig? : any, prefix? : any, or? : any, expectedNetworkResult? : any, expectedFullResult? : any) : any {
        if(((typeof orig === 'string') || orig === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof or === 'string') || or === null) && ((typeof expectedNetworkResult === 'string') || expectedNetworkResult === null) && ((typeof expectedFullResult === 'string') || expectedFullResult === null)) {
            return <any>this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String(orig, prefix, or, expectedNetworkResult, expectedFullResult);
        } else if(((typeof orig === 'string') || orig === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof or === 'string') || or === null) && ((typeof expectedNetworkResult === 'string') || expectedNetworkResult === null) && expectedFullResult === undefined) {
            return <any>this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String(orig, prefix, or, expectedNetworkResult);
        } else throw new Error('invalid overload');
    }

    testDelimitedCount(str : string, expectedCount : number) {
        let strings : any = IPAddressString.parseDelimitedSegments(str);
        let set : Array<IPAddress> = <any>([]);
        let count : number = 0;
        try {
            while((strings.hasNext())) {
                /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, this.createAddress$java_lang_String(strings.next()).toAddress());
                count++;
            };
            if(count !== expectedCount || /* size */(<number>set.length) !== count || count !== IPAddressString.countDelimitedAddresses(str)) {
                this.addFailure(new TestBase.Failure("count mismatch, count: " + count + " set count: " + /* size */(<number>set.length) + " calculated count: " + IPAddressString.countDelimitedAddresses(str) + " expected: " + expectedCount));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("threw unexpectedly " + str));
        };
        this.incrementTestCount();
    }

    testReverseHostAddress(str : string) {
        let addrStr : IPAddressString = this.createAddress$java_lang_String(str);
        let addr : IPAddress = addrStr.getAddress();
        let hostAddr : IPAddress = addrStr.getHostAddress();
        let hostAddr2 : IPAddress;
        if(addr.isIPv6()) {
            let newAddr : IPAddress = new IPv6Address(addr.toIPv6().getSection());
            let newAddrString : IPAddressString = newAddr.toAddressString();
            hostAddr2 = newAddrString.getHostAddress();
        } else {
            let newAddr : IPAddress = new IPv4Address(addr.toIPv4().getSection());
            let newAddrString : IPAddressString = newAddr.toAddressString();
            hostAddr2 = newAddrString.getHostAddress();
        }
        if(!hostAddr.equals(hostAddr2)) {
            this.addFailure(new TestBase.Failure("expected " + hostAddr + " got " + hostAddr2, hostAddr2));
        }
        this.incrementTestCount();
    }

    public testInsertAndAppend$java_lang_String$java_lang_String$int_A(front : string, back : string, expectedPref : number[]) {
        let is : number[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(expectedPref.length);
        for(let i : number = 0; i < expectedPref.length; i++) {
            is[i] = expectedPref[i];
        };
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front, back, is);
    }

    public testInsertAndAppend(front? : any, back? : any, expectedPref? : any) : any {
        if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && ((expectedPref != null && expectedPref instanceof <any>Array && (expectedPref.length==0 || expectedPref[0] == null ||(typeof expectedPref[0] === 'number'))) || expectedPref === null)) {
            return <any>this.testInsertAndAppend$java_lang_String$java_lang_String$int_A(front, back, expectedPref);
        } else if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && ((expectedPref != null && expectedPref instanceof <any>Array && (expectedPref.length==0 || expectedPref[0] == null ||(typeof expectedPref[0] === 'number'))) || expectedPref === null)) {
            return <any>this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front, back, expectedPref);
        } else throw new Error('invalid overload');
    }

    testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A(front : string, back : string, expectedPref : number[]) {
        let f : IPAddress = this.createAddress$java_lang_String(front).getAddress();
        let b : IPAddress = this.createAddress$java_lang_String(back).getAddress();
        this.testAppendAndInsert(f, b, f.getSegmentStrings(), b.getSegmentStrings(), f.isIPv4()?IPv4Address.SEGMENT_SEPARATOR:IPv6Address.SEGMENT_SEPARATOR, expectedPref, false);
    }

    public testReplace(front? : any, back? : any, fronts? : any, backs? : any, sep? : any, isMac? : any) : any {
        if(((front != null && front instanceof <any>Address) || front === null) && ((back != null && back instanceof <any>Address) || back === null) && ((fronts != null && fronts instanceof <any>Array && (fronts.length==0 || fronts[0] == null ||(typeof fronts[0] === 'string'))) || fronts === null) && ((backs != null && backs instanceof <any>Array && (backs.length==0 || backs[0] == null ||(typeof backs[0] === 'string'))) || backs === null) && ((typeof sep === 'string') || sep === null) && ((typeof isMac === 'boolean') || isMac === null)) {
            super.testReplace(front, back, fronts, backs, sep, isMac);
        } else if(((typeof front === 'string') || front === null) && ((typeof back === 'string') || back === null) && fronts === undefined && backs === undefined && sep === undefined && isMac === undefined) {
            return <any>this.testReplace$java_lang_String$java_lang_String(front, back);
        } else throw new Error('invalid overload');
    }

    testReplace$java_lang_String$java_lang_String(front : string, back : string) {
        let f : IPAddress = this.createAddress$java_lang_String(front).getAddress();
        let b : IPAddress = this.createAddress$java_lang_String(back).getAddress();
        this.testReplace$inet_ipaddr_Address$inet_ipaddr_Address$java_lang_String_A$java_lang_String_A$char$boolean(f, b, f.getSegmentStrings(), b.getSegmentStrings(), f.isIPv4()?IPv4Address.SEGMENT_SEPARATOR:IPv6Address.SEGMENT_SEPARATOR, false);
    }

    testInvalidIpv4Values() {
        try {
            let bytes : number[] = [0, 0, 0, 0, 0];
            bytes[0] = 1;
            let addr : IPv4Address = new IPv4Address(bytes);
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new IPv4Address([0, 0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv4Address([0, 0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv4Address([0, 0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv4Address([0, 0]);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            let addr : IPv4Address = new IPv4Address(new IPAddressTest.IPAddressTest$2(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            let addr : IPv4Address = new IPv4Address(new IPAddressTest.IPAddressTest$3(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new IPv4Address(new IPAddressTest.IPAddressTest$4(this));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
    }

    testIPv4Values(segs : number[], decimal : string) {
        let vals : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segs.length);
        let strb : { str: string } = { str: "", toString: function() { return this.str; } };
        let longval : number = 0;
        let intval : number = 0;
        let bigInteger : BigInteger = BigInteger.ZERO;
        let bitsPerSegment : number = IPv4Address.BITS_PER_SEGMENT;
        for(let i : number = 0; i < segs.length; i++) {
            let seg : number = segs[i];
            if(/* length */strb.str.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'.'); return sb; })(strb);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>seg); return sb; })(strb);
            vals[i] = (<number>seg|0);
            longval = (longval << bitsPerSegment) | seg;
            intval = (intval << bitsPerSegment) | seg;
            bigInteger = bigInteger.shiftLeft(bitsPerSegment).add(BigInteger.valueOf(seg));
        };
        try {
            let addr : IPv4Address[] = [null, null, null, null, null, null, null];
            let i : number = 0;
            addr[i++] = this.createAddress$byte_A(vals).toIPv4();
            addr[i++] = this.createAddress$java_lang_String(/* toString */strb.str).getAddress().toIPv4();
            addr[i++] = this.createAddress$int(intval).toIPv4();
            let inetAddress1 : InetAddress = InetAddress.getByName(/* toString */strb.str);
            let inetAddress2 : InetAddress = InetAddress.getByAddress(vals);
            addr[i++] = new IPv4Address(<Inet4Address>inetAddress1);
            addr[i++] = new IPv4Address(<Inet4Address>inetAddress2);
            addr[i++] = new IPv4Address((<number>longval|0));
            addr[i++] = new IPv4Address(bigInteger.intValue());
            for(let j : number = 0; j < addr.length; j++) {
                for(let k : number = j; k < addr.length; k++) {
                    if(!addr[k].equals(addr[j]) || !addr[j].equals(addr[k])) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[k] + " and " + addr[j]));
                    }
                };
            };
            if(decimal != null) {
                for(i = 0; i < addr.length; i++) {
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(decimal,addr[i].getValue().toString()))) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[i].getValue() + " and " + decimal));
                    }
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(decimal,/* valueOf */new String(addr[i].longValue()).toString()))) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[i].longValue() + " and " + decimal));
                    }
                };
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed unexpected: " + e));
        };
    }

    testIPv6Values(segs : number[], decimal : string) {
        let vals : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segs.length * IPv6Address.BYTES_PER_SEGMENT);
        let strb : { str: string } = { str: "", toString: function() { return this.str; } };
        let bigInteger : BigInteger = BigInteger.ZERO;
        let bitsPerSegment : number = IPv6Address.BITS_PER_SEGMENT;
        for(let i : number = 0; i < segs.length; i++) {
            let seg : number = segs[i];
            if(/* length */strb.str.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>':'); return sb; })(strb);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>javaemul.internal.IntegerHelper.toHexString(seg)); return sb; })(strb);
            vals[i << 1] = (<number>(seg >>> 8)|0);
            vals[(i << 1) + 1] = (<number>seg|0);
            bigInteger = bigInteger.shiftLeft(bitsPerSegment).add(BigInteger.valueOf(seg));
        };
        try {
            let addr : IPv6Address[] = [null, null, null, null, null];
            let i : number = 0;
            addr[i++] = this.createAddress$byte_A(vals).toIPv6();
            addr[i++] = this.createAddress$java_lang_String(/* toString */strb.str).getAddress().toIPv6();
            let inetAddress1 : InetAddress = InetAddress.getByName(/* toString */strb.str);
            let inetAddress2 : InetAddress = InetAddress.getByAddress(vals);
            addr[i++] = new IPv6Address(<Inet6Address>inetAddress1);
            addr[i++] = new IPv6Address(<Inet6Address>inetAddress2);
            addr[i++] = new IPv6Address(bigInteger);
            for(let j : number = 0; j < addr.length; j++) {
                for(let k : number = j; k < addr.length; k++) {
                    if(!addr[k].equals(addr[j]) || !addr[j].equals(addr[k])) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[k] + " and " + addr[j]));
                    }
                };
            };
            if(decimal != null) {
                for(i = 0; i < addr.length; i++) {
                    if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(decimal,addr[i].getValue().toString()))) {
                        this.addFailure(new TestBase.Failure("failed equals: " + addr[i].getValue() + " and " + decimal));
                    }
                };
            }
        } catch(__e) {
            if(__e != null && __e instanceof <any>AddressValueException) {
                let e : AddressValueException = <AddressValueException>__e;
                this.addFailure(new TestBase.Failure("failed unexpected: " + e));

            }
            if(__e != null && (__e["__classes"] && __e["__classes"].indexOf("java.net.UnknownHostException") >= 0)) {
                let e : Error = <Error>__e;
                this.addFailure(new TestBase.Failure("failed unexpected: " + e));

            }
        };
    }

    testInvalidIpv6Values() {
        try {
            let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(17);
            bytes[0] = 1;
            let addr : IPv6Address = new IPv6Address(bytes);
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new IPv6Address((s => { let a=[]; while(s-->0) a.push(0); return a; })(17));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv6Address((s => { let a=[]; while(s-->0) a.push(0); return a; })(16));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv6Address((s => { let a=[]; while(s-->0) a.push(0); return a; })(15));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv6Address((s => { let a=[]; while(s-->0) a.push(0); return a; })(14));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            new IPv6Address(BigInteger.valueOf(-1));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        let thirtyTwo : BigInteger = BigInteger.valueOf(4294967295);
        let one28 : BigInteger = thirtyTwo.shiftLeft(96).or(thirtyTwo.shiftLeft(64).or(thirtyTwo.shiftLeft(32).or(thirtyTwo)));
        try {
            new IPv6Address(one28);
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
        try {
            let addr : IPv6Address = new IPv6Address(one28.add(BigInteger.ONE));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new IPv6Address(BigInteger.valueOf(4294967295));
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed unexpected: " + e));
        };
        try {
            let addr : IPv6Address = new IPv6Address(new IPAddressTest.IPAddressTest$5(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            let addr : IPv6Address = new IPv6Address(new IPAddressTest.IPAddressTest$6(this));
            this.addFailure(new TestBase.Failure("failed expected exception for " + addr, addr));
        } catch(e) {
        };
        try {
            new IPv6Address(new IPAddressTest.IPAddressTest$7(this));
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected exception " + e));
        };
    }

    public testSub(one : string, two : string, resultStrings : string[]) {
        let string : IPAddressString = this.createAddress$java_lang_String(one);
        let sub : IPAddressString = this.createAddress$java_lang_String(two);
        let addr : IPAddress = string.getAddress();
        let subAddr : IPAddress = sub.getAddress();
        try {
            let res : IPAddress[] = addr.subtract(subAddr);
            if(resultStrings == null) {
                if(res != null) {
                    this.addFailure(new TestBase.Failure("non-null subtraction with " + addr, subAddr));
                }
            } else {
                if(resultStrings.length !== res.length) {
                    this.addFailure(new TestBase.Failure("length mismatch " + Arrays.toString(res) + " with " + Arrays.toString(resultStrings)));
                } else {
                    let results : IPAddress[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(resultStrings.length);
                    for(let i : number = 0; i < resultStrings.length; i++) {
                        results[i] = this.createAddress$java_lang_String(resultStrings[i]).getAddress();
                    };
                    for(let index154=0; index154 < res.length; index154++) {
                        let r = res[index154];
                        {
                            let found : boolean = false;
                            for(let index155=0; index155 < results.length; index155++) {
                                let result = results[index155];
                                {
                                    if(r.equals(result) && Objects.equals(r.getNetworkPrefixLength(), result.getNetworkPrefixLength())) {
                                        found = true;
                                        break;
                                    }
                                }
                            }
                            if(!found) {
                                this.addFailure(new TestBase.Failure("mismatch with " + Arrays.toString(resultStrings), r));
                            }
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("threw " + e + " when subtracting " + subAddr, addr));
        };
        this.incrementTestCount();
    }

    public testIntersect$java_lang_String$java_lang_String$java_lang_String(one : string, two : string, resultString : string) {
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String$boolean(one, two, resultString, false);
    }

    public testIntersect$java_lang_String$java_lang_String$java_lang_String$boolean(one : string, two : string, resultString : string, lowest : boolean) {
        let string : IPAddressString = this.createAddress$java_lang_String(one);
        let string2 : IPAddressString = this.createAddress$java_lang_String(two);
        let addr : IPAddress = string.getAddress();
        let addr2 : IPAddress = string2.getAddress();
        let r : IPAddress = addr.intersect(addr2);
        if(resultString == null) {
            if(r != null) {
                this.addFailure(new TestBase.Failure("non-null intersection with " + addr, addr2));
            }
        } else {
            let result : IPAddress = this.createAddress$java_lang_String(resultString).getAddress();
            if(lowest) {
                result = result.getLower();
            }
            if(!r.equals(result) || !Objects.equals(r.getNetworkPrefixLength(), result.getNetworkPrefixLength())) {
                this.addFailure(new TestBase.Failure("mismatch with " + result, r));
            }
        }
        this.incrementTestCount();
    }

    public testIntersect(one? : any, two? : any, resultString? : any, lowest? : any) : any {
        if(((typeof one === 'string') || one === null) && ((typeof two === 'string') || two === null) && ((typeof resultString === 'string') || resultString === null) && ((typeof lowest === 'boolean') || lowest === null)) {
            return <any>this.testIntersect$java_lang_String$java_lang_String$java_lang_String$boolean(one, two, resultString, lowest);
        } else if(((typeof one === 'string') || one === null) && ((typeof two === 'string') || two === null) && ((typeof resultString === 'string') || resultString === null) && lowest === undefined) {
            return <any>this.testIntersect$java_lang_String$java_lang_String$java_lang_String(one, two, resultString);
        } else throw new Error('invalid overload');
    }

    public testToPrefixBlock(addrString : string, subnetString : string) {
        let string : IPAddressString = this.createAddress$java_lang_String(addrString);
        let string2 : IPAddressString = this.createAddress$java_lang_String(subnetString);
        let addr : IPAddress = string.getAddress();
        let subnet : IPAddress = string2.getAddress();
        let prefixBlock : IPAddress = addr.toPrefixBlock();
        if(!subnet.equals(prefixBlock)) {
            this.addFailure(new TestBase.Failure("prefix block mismatch " + subnet + " with block " + prefixBlock, addr));
        } else if(!Objects.equals(subnet.getNetworkPrefixLength(), prefixBlock.getNetworkPrefixLength())) {
            this.addFailure(new TestBase.Failure("prefix block length mismatch " + subnet.getNetworkPrefixLength() + " and " + prefixBlock.getNetworkPrefixLength(), addr));
        }
        this.incrementTestCount();
    }

    public testZeroHost(addrString : string, zeroHostString : string) {
        let string : IPAddressString = this.createAddress$java_lang_String(addrString);
        let string2 : IPAddressString = this.createAddress$java_lang_String(zeroHostString);
        let addr : IPAddress = string.getAddress();
        let specialHost : IPAddress = string2.getAddress();
        let transformedHost : IPAddress = addr.toZeroHost();
        if(!AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].zeroHostsAreSubnets() && !specialHost.equals(transformedHost)) {
            this.addFailure(new TestBase.Failure("mismatch " + specialHost + " with host " + transformedHost, addr));
        }
        if(!AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()) {
            let hostSection : IPAddressSection = transformedHost.getHostSection();
            if(hostSection.getSegmentCount() > 0 && !hostSection.isZero()) {
                this.addFailure(new TestBase.Failure("non-zero host " + hostSection, addr));
            }
        }
        if(!Objects.equals(transformedHost.getNetworkPrefixLength(), specialHost.getNetworkPrefixLength())) {
            this.addFailure(new TestBase.Failure("prefix length mismatch " + transformedHost.getNetworkPrefixLength() + " and " + specialHost.getNetworkPrefixLength(), addr));
        }
        this.incrementTestCount();
    }

    public testMaxHost(addrString : string, maxHostString : string) {
        let string : IPAddressString = this.createAddress$java_lang_String(addrString);
        let string2 : IPAddressString = this.createAddress$java_lang_String(maxHostString);
        let addr : IPAddress = string.getAddress();
        let specialHost : IPAddress = string2.getAddress();
        let transformedHost : IPAddress = addr.toMaxHost();
        if(!specialHost.equals(transformedHost)) {
            this.addFailure(new TestBase.Failure("mismatch " + specialHost + " with host " + transformedHost, addr));
        } else if(!Objects.equals(transformedHost.getNetworkPrefixLength(), specialHost.getNetworkPrefixLength())) {
            this.addFailure(new TestBase.Failure("prefix length mismatch " + transformedHost.getNetworkPrefixLength() + " and " + specialHost.getNetworkPrefixLength(), addr));
        }
        this.incrementTestCount();
    }

    static toList(bytes : number[]) : Array<number> {
        let newBytes : number[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(bytes.length);
        for(let i : number = 0; i < bytes.length; i++) {
            newBytes[i] = bytes[i];
        };
        return /* asList */newBytes.slice(0);
    }

    public testByteExtension(addrString : string, byteRepresentations : number[][]) {
        let addr : IPAddress = this.createAddress$java_lang_String(addrString).getAddress();
        let all : Array<IPAddress> = <any>([]);
        if(addr.isIPv4()) {
            for(let index156=0; index156 < byteRepresentations.length; index156++) {
                let byteRepresentation = byteRepresentations[index156];
                {
                    let ipv4Addr : IPv4Address = new IPv4Address(byteRepresentation);
                    /* add */(all.push(ipv4Addr)>0);
                    let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(48);
                    /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(bytes, (<number>5|0));
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(byteRepresentation, 0, bytes, 5, byteRepresentation.length);
                    ipv4Addr = new IPv4Address(bytes, 5, 5 + byteRepresentation.length);
                    /* add */(all.push(ipv4Addr)>0);
                }
            }
            /* add */(all.push(addr)>0);
            let lastBytes : number[] = null;
            for(let i : number = 0; i < /* size */(<number>all.length); i++) {
                let bytes : number[] = /* get */all[i].getBytes();
                if(lastBytes == null) {
                    lastBytes = bytes;
                    if(bytes.length !== IPv4Address.BYTE_COUNT) {
                        this.addFailure(new TestBase.Failure("bytes length for " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(bytes)), addr));
                    }
                    let ipv4Addr : IPv4Address = new IPv4Address(bytes);
                    /* add */(all.push(ipv4Addr)>0);
                    ipv4Addr = new IPv4Address(new BigInteger(bytes).intValue());
                    /* add */(all.push(ipv4Addr)>0);
                } else if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(lastBytes, bytes)) {
                    this.addFailure(new TestBase.Failure("generated addr bytes mismatch " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(bytes)) + " and " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(lastBytes)), addr));
                }
            };
        } else {
            for(let index157=0; index157 < byteRepresentations.length; index157++) {
                let byteRepresentation = byteRepresentations[index157];
                {
                    let ipv6Addr : IPv6Address = new IPv6Address(byteRepresentation);
                    /* add */(all.push(ipv6Addr)>0);
                    let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(48);
                    /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(bytes, (<number>5|0));
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(byteRepresentation, 0, bytes, 5, byteRepresentation.length);
                    ipv6Addr = new IPv6Address(bytes, 5, 5 + byteRepresentation.length);
                    /* add */(all.push(ipv6Addr)>0);
                }
            }
            /* add */(all.push(addr)>0);
            let lastBytes : number[] = null;
            for(let i : number = 0; i < /* size */(<number>all.length); i++) {
                let bytes : number[] = /* get */all[i].getBytes();
                if(lastBytes == null) {
                    lastBytes = bytes;
                    if(bytes.length !== IPv6Address.BYTE_COUNT) {
                        this.addFailure(new TestBase.Failure("bytes length for " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(bytes)), addr));
                    }
                    let ipv6Addr : IPv6Address = new IPv6Address(bytes);
                    /* add */(all.push(ipv6Addr)>0);
                    let b : BigInteger = new BigInteger(bytes);
                    ipv6Addr = new IPv6Address(b);
                    /* add */(all.push(ipv6Addr)>0);
                    let bs : number[] = b.toByteArray();
                    ipv6Addr = new IPv6Address(bs);
                    /* add */(all.push(ipv6Addr)>0);
                } else if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(lastBytes, bytes)) {
                    this.addFailure(new TestBase.Failure("addr bytes mismatch " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(bytes)) + " and " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(IPAddressTest.toList(lastBytes)), addr));
                }
            };
        }
        let allBytes : Array<number[]> = <any>([]);
        for(let i : number = 0; i < /* size */(<number>all.length); i++) {
            /* add */(allBytes.push(/* get */all[i].getBytes())>0);
        };
        for(let i : number = 0; i < /* size */(<number>all.length); i++) {
            for(let j : number = i; j < /* size */(<number>all.length); j++) {
                if(!/* get */all[i].equals(/* get */all[j])) {
                    this.addFailure(new TestBase.Failure("addr mismatch " + /* get */all[i] + " and " + /* get */all[j], addr));
                }
                if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(/* get */allBytes[i], /* get */allBytes[j])) {
                    this.addFailure(new TestBase.Failure("addr bytes mismatch " + /* get */allBytes[i] + " and " + /* get */allBytes[j], addr));
                }
            };
        };
        this.incrementTestCount();
    }

    testSpanAndMerge(address1 : string, address2 : string, count : number) {
        let string1 : IPAddressString = this.createAddress$java_lang_String(address1);
        let string2 : IPAddressString = this.createAddress$java_lang_String(address2);
        let addr1 : IPAddress = string1.getAddress();
        let addr2 : IPAddress = string2.getAddress();
        let result : IPAddress[] = addr1.spanWithPrefixBlocks(addr2);
        if(count !== result.length) {
            this.addFailure(new TestBase.Failure("merge mismatch merging " + addr1 + " and " + addr2 + " into " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */result.slice(0)) + " expected count of " + count, addr1));
        }
        let backAgain : IPAddress[] = (o => o.mergePrefixBlocks.apply(o, result))(result[0]);
        let matches : boolean = /* deepEquals */(JSON.stringify(result) === JSON.stringify(backAgain));
        if(!matches) {
            /* deepEquals */(JSON.stringify(result) === JSON.stringify(backAgain));
            this.addFailure(new TestBase.Failure("merge mismatch merging " + addr1 + " and " + addr2 + " into " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */result.slice(0)) + " and " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */backAgain.slice(0)), addr1));
        }
        this.incrementTestCount();
    }

    testMerge(result : string, ...addresses : string[]) {
        let resultStr : IPAddressString = this.createAddress$java_lang_String(result);
        let string2 : IPAddressString = this.createAddress$java_lang_String(addresses[0]);
        let resultAddr : IPAddress = resultStr.getAddress();
        let addr2 : IPAddress = string2.getAddress();
        let mergers : IPAddress[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(addresses.length - 1);
        for(let i : number = 0; i < mergers.length; i++) {
            mergers[i] = this.createAddress$java_lang_String(addresses[i + 1]).getAddress();
        };
        let merged : IPAddress[] = (o => o.mergePrefixBlocks.apply(o, mergers))(addr2);
        if(!resultAddr.equals(merged[0])) {
            this.addFailure(new TestBase.Failure("merge mismatch merging " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */addresses.slice(0)) + " expected " + result + " got " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */merged.slice(0)), resultAddr));
        }
        this.incrementTestCount();
    }

    testMerge2(result : string, result2 : string, ...addresses : string[]) {
        let resultStr : IPAddressString = this.createAddress$java_lang_String(result);
        let resultStr2 : IPAddressString = this.createAddress$java_lang_String(result2);
        let string2 : IPAddressString = this.createAddress$java_lang_String(addresses[0]);
        let resultAddr : IPAddress = resultStr.getAddress();
        let resultAddr2 : IPAddress = resultStr2.getAddress();
        let addr2 : IPAddress = string2.getAddress();
        let mergers : IPAddress[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(addresses.length - 1);
        for(let i : number = 0; i < mergers.length; i++) {
            mergers[i] = this.createAddress$java_lang_String(addresses[i + 1]).getAddress();
        };
        let merged : IPAddress[] = (o => o.mergePrefixBlocks.apply(o, mergers))(addr2);
        let all : Array<IPAddress> = <any>(/* asList */merged.slice(0).slice(0));
        let expected : Array<IPAddress> = <any>([]);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(expected, resultAddr);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(expected, resultAddr2);
        if(!/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(all, expected)) {
            this.addFailure(new TestBase.Failure("merge mismatch merging " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(/* asList */addresses.slice(0)) + " expected " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(expected) + " got " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(all), resultAddr));
        }
        this.incrementTestCount();
    }

    public testIncrement(orig? : any, increment? : any, expectedResult? : any, first? : any) : any {
        if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && ((typeof first === 'boolean') || first === null)) {
            super.testIncrement(orig, increment, expectedResult, first);
        } else if(((typeof orig === 'string') || orig === null) && ((typeof increment === 'number') || increment === null) && ((typeof expectedResult === 'string') || expectedResult === null) && first === undefined) {
            return <any>this.testIncrement$java_lang_String$long$java_lang_String(orig, increment, expectedResult);
        } else if(((orig != null && orig instanceof <any>Address) || orig === null) && ((typeof increment === 'number') || increment === null) && ((expectedResult != null && expectedResult instanceof <any>Address) || expectedResult === null) && first === undefined) {
            return <any>this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(orig, increment, expectedResult);
        } else throw new Error('invalid overload');
    }

    testIncrement$java_lang_String$long$java_lang_String(originalStr : string, increment : number, resultStr : string) {
        this.testIncrement$inet_ipaddr_Address$long$inet_ipaddr_Address(this.createAddress$java_lang_String(originalStr).getAddress(), increment, resultStr == null?null:this.createAddress$java_lang_String(resultStr).getAddress());
    }

    static myIPv6Network : IPv6AddressNetwork; public static myIPv6Network_$LI$() : IPv6AddressNetwork { if(IPAddressTest.myIPv6Network == null) IPAddressTest.myIPv6Network = new IPAddressTest.IPAddressTest$8(); return IPAddressTest.myIPv6Network; };

    testCustomNetwork$inet_ipaddr_AddressNetwork_PrefixConfiguration(prefixConfiguration : AddressNetwork.PrefixConfiguration) {
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(16);
        bytes[0] = bytes[15] = 1;
        let myAddr1 : IPv6Address = new IPAddressTest.MyIPv6Address(bytes, 64);
        let regAddr1 : IPv6Address = new IPv6Address(bytes, 64);
        bytes[15] = 0;
        let regAddrNet1 : IPv6Address = new IPv6Address(bytes, 64);
        this.testCustomNetwork$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address(myAddr1, regAddr1, regAddrNet1);
        let params : IPAddressStringParameters = new IPAddressStringParameters.Builder().getIPv6AddressParametersBuilder().setNetwork(IPAddressTest.myIPv6Network_$LI$()).getParentBuilder().toParams();
        let myAddr : IPv6Address = new IPAddressString("1::1/64", params).getAddress().toIPv6();
        let regAddr : IPv6Address = new IPAddressString("1::1/64").getAddress().toIPv6();
        let regAddrNet : IPv6Address = new IPAddressString("1::/64").getAddress().toIPv6();
        this.testCustomNetwork$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address(myAddr, regAddr, regAddrNet);
    }

    public testCustomNetwork$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address(myAddr : IPv6Address, regAddr : IPv6Address, regAddrNet : IPv6Address) {
        if(!regAddr.getCount().equals(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()?myAddr.getCount():BigInteger.ONE)) {
            this.addFailure(new TestBase.Failure("invalid count " + regAddr.getCount(), myAddr));
        }
        if(myAddr.getCount().equals(BigInteger.ONE)) {
            this.addFailure(new TestBase.Failure("invalid count " + myAddr.getCount(), myAddr));
        }
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit()) {
            if(!regAddrNet.getCount().equals(BigInteger.ONE)) {
                this.addFailure(new TestBase.Failure("invalid count " + regAddrNet.getCount(), myAddr));
            }
        } else if(!myAddr.getCount().equals(regAddrNet.getCount())) {
            this.addFailure(new TestBase.Failure("invalid count matching " + myAddr.getCount() + " and " + regAddrNet.getCount(), myAddr));
        }
        this.incrementTestCount();
    }

    public testCustomNetwork(myAddr? : any, regAddr? : any, regAddrNet? : any) : any {
        if(((myAddr != null && myAddr instanceof <any>IPv6Address) || myAddr === null) && ((regAddr != null && regAddr instanceof <any>IPv6Address) || regAddr === null) && ((regAddrNet != null && regAddrNet instanceof <any>IPv6Address) || regAddrNet === null)) {
            return <any>this.testCustomNetwork$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_ipv6_IPv6Address(myAddr, regAddr, regAddrNet);
        } else if(((typeof myAddr === 'number') || myAddr === null) && regAddr === undefined && regAddrNet === undefined) {
            return <any>this.testCustomNetwork$inet_ipaddr_AddressNetwork_PrefixConfiguration(myAddr);
        } else throw new Error('invalid overload');
    }

    isLenient() : boolean {
        return false;
    }

    allowsRange() : boolean {
        return false;
    }

    /**
     * 
     */
    runTest() {
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        let isAutoSubnets : boolean = !isNoAutoSubnets;
        this.testEquivalentPrefix$java_lang_String$int("1.2.3.4", 32);
        if(isNoAutoSubnets) {
            this.testEquivalentPrefix$java_lang_String$int("0.0.0.0/1", 32);
            this.testEquivalentPrefix$java_lang_String$int("128.0.0.0/1", 32);
            this.testEquivalentPrefix$java_lang_String$int("1.2.0.0/15", 32);
            this.testEquivalentPrefix$java_lang_String$int("1.2.0.0/16", 32);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/32", 128);
            this.testEquivalentPrefix$java_lang_String$int("8000::/1", 128);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/31", 128);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/34", 128);
        } else {
            this.testEquivalentPrefix$java_lang_String$int("0.0.0.0/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("128.0.0.0/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("1.2.0.0/15", 15);
            this.testEquivalentPrefix$java_lang_String$int("1.2.0.0/16", 16);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/32", 32);
            this.testEquivalentPrefix$java_lang_String$int("8000::/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/31", 31);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/34", 34);
        }
        this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/32", 32);
        if(allPrefixesAreSubnets) {
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/1", 1);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/15", 15);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/16", 16);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/32", 32);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/1", 1);
        } else {
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/1", 32);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/15", 32);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/16", 32);
            this.testEquivalentPrefix$java_lang_String$int("1.2.3.4/32", 32);
            this.testEquivalentPrefix$java_lang_String$int("1:2::/1", 128);
        }
        this.testEquivalentPrefix$java_lang_String$int("1:2::/128", 128);
        this.testReverse$java_lang_String$boolean$boolean("255.127.128.255", false, false);
        this.testReverse$java_lang_String$boolean$boolean("255.127.128.255/16", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1.2.3.4", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1.1.2.2", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1.1.1.1", false, false);
        this.testReverse$java_lang_String$boolean$boolean("0.0.0.0", true, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", true, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:1:ffff:ffff:ffff:ffff:ffff", false, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:8181:ffff:ffff:ffff:ffff:ffff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:c3c3:ffff:ffff:ffff:ffff:ffff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:4242:c3c3:2424:ffff:ffff:ffff:ffff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:8000:ffff:ffff:0001:ffff:ffff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ffff:ffff:1:ffff:ffff:ffff:ffff:ffff/64", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:2:3:4:5:6:7:8", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:2:2:3:3:4:4", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:1:1:1:1:1:1", false, false);
        this.testReverse$java_lang_String$boolean$boolean("::", true, true);
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.128.255", 16, -5, "255.127.128.255", "255.127.128.255/32", allPrefixesAreSubnets?"255.127.128.224/27":"255.127.128.255/27", allPrefixesAreSubnets?"255.127.0.0/16":"255.127.128.255/16", allPrefixesAreSubnets?"255.127.0.0/16":"255.127.128.255/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.0.0/16", 16, -5, "255.127.0.0/24", "255.0.0.0/8", "255.96.0.0/11", "255.127.0.0/16", "255.127.0.0/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.128.255/32", 16, -5, "255.127.128.255", "255.127.128.0/24", "255.127.128.224/27", "255.127.0.0/16", "255.127.0.0/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.0.0/17", 16, -17, "255.127.0.0/24", "255.127.0.0/16", "0.0.0.0/0", "255.127.0.0/16", "255.127.0.0/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.0.0/16", 18, 17, "255.127.0.0/24", "255.0.0.0/8", "255.127.0.0", "255.127.0.0/18", "255.127.0.0/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("255.127.0.0/16", 18, 16, "255.127.0.0/24", "255.0.0.0/8", "255.127.0.0/32", "255.127.0.0/18", "255.127.0.0/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("254.0.0.0/7", 18, 17, "254.0.0.0/8", "0.0.0.0/0", "254.0.0.0/24", "254.0.0.0/18", "254.0.0.0/7");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("254.255.127.128/7", 18, 17, allPrefixesAreSubnets?"254.0.0.0/8":"254.255.127.128/8", allPrefixesAreSubnets?"0.0.0.0/0":"0.255.127.128/0", allPrefixesAreSubnets?"254.0.0.0/24":"254.0.0.128/24", allPrefixesAreSubnets?"254.0.0.0/18":"254.0.63.128/18", allPrefixesAreSubnets?"254.0.0.0/7":"254.255.127.128/7");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("254.255.127.128/23", 18, 17, allPrefixesAreSubnets?"254.255.126.0/24":"254.255.126.128/24", allPrefixesAreSubnets?"254.255.0.0/16":"254.255.1.128/16", allPrefixesAreSubnets?"254.255.126.0/32":"254.255.126.0/32", allPrefixesAreSubnets?"254.255.64.0/18":"254.255.65.128/18", allPrefixesAreSubnets?"254.255.64.0/18":"254.255.65.128/18");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", 16, -5, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128", allPrefixesAreSubnets?"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffe0/123":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/123", allPrefixesAreSubnets?"ffff::/16":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/16", allPrefixesAreSubnets?"ffff::/16":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128", 16, -5, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:0/112", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffe0/123", "ffff::/16", "ffff::/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", 15, 1, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", allPrefixesAreSubnets?"fffe::/15":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/15", allPrefixesAreSubnets?"fffe::/15":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/15");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/64", 16, -5, "ffff:ffff:1:ffff::/80", "ffff:ffff:1::/48", "ffff:ffff:1:ffe0::/59", "ffff::/16", "ffff::/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff:ffff:ffff:1:ffff/64", 16, -5, allPrefixesAreSubnets?"ffff:ffff:1:ffff::/80":"ffff:ffff:1:ffff:0:ffff:1:ffff/80", allPrefixesAreSubnets?"ffff:ffff:1::/48":"ffff:ffff:1::ffff:ffff:1:ffff/48", allPrefixesAreSubnets?"ffff:ffff:1:ffe0::/59":"ffff:ffff:1:ffe0:ffff:ffff:1:ffff/59", allPrefixesAreSubnets?"ffff::/16":"ffff::ffff:ffff:1:ffff/16", allPrefixesAreSubnets?"ffff::/16":"ffff::ffff:ffff:1:ffff/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/64", 16, 1, "ffff:ffff:1:ffff::/80", "ffff:ffff:1::/48", "ffff:ffff:1:ffff::/65", "ffff::/16", "ffff::/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/63", 16, -5, "ffff:ffff:1:fffe::/64", allPrefixesAreSubnets?"ffff:ffff:1::/48":"ffff:ffff:1:1::/48", allPrefixesAreSubnets?"ffff:ffff:1:ffc0::/58":"ffff:ffff:1:ffc1::/58", allPrefixesAreSubnets?"ffff::/16":"ffff:0:0:1::/16", allPrefixesAreSubnets?"ffff::/16":"ffff:0:0:1::/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/63", 17, -64, "ffff:ffff:1:fffe::/64", allPrefixesAreSubnets?"ffff:ffff:1::/48":"ffff:ffff:1:1::/48", allPrefixesAreSubnets?"::/0":"0:0:0:1::/0", allPrefixesAreSubnets?"ffff:8000::/17":"ffff:8000:0:1::/16", allPrefixesAreSubnets?"ffff:8000::/17":"ffff:8000:0:1::/16");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/63", 15, -63, "ffff:ffff:1:fffe::/64", allPrefixesAreSubnets?"ffff:ffff:1::/48":"ffff:ffff:1:1::/48", allPrefixesAreSubnets?"::/0":"0:0:0:1::/0", allPrefixesAreSubnets?"fffe::/15":"fffe:0:0:1::/15", allPrefixesAreSubnets?"fffe::/15":"fffe:0:0:1::/15");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff::/63", 65, 1, "ffff:ffff:1:fffe::/64", allPrefixesAreSubnets?"ffff:ffff:1::/48":"ffff:ffff:1:1::/48", "ffff:ffff:1:fffe::/64", "ffff:ffff:1:fffe::/65", allPrefixesAreSubnets?"ffff:ffff:1:fffe::/63":"ffff:ffff:1:ffff::/63");
        this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ffff:ffff:1:ffff:ffff:ffff:ffff:ffff/128", 127, 1, "ffff:ffff:1:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:1:ffff:ffff:ffff:ffff::/112", "ffff:ffff:1:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:1:ffff:ffff:ffff:ffff:fffe/127", "ffff:ffff:1:ffff:ffff:ffff:ffff:fffe/127");
        this.testBitwiseOr("1.2.0.0", null, "0.0.3.4", "1.2.3.4");
        this.testBitwiseOr("1.2.0.0", null, "0.0.0.0", "1.2.0.0");
        this.testBitwiseOr("1.2.0.0", null, "255.255.255.255", "255.255.255.255");
        this.testBitwiseOr("1.0.0.0/8", 16, "0.2.3.0", "1.2.3.0/24");
        this.testBitwiseOr("1.2.0.0/16", 8, "0.0.3.0", "1.2.3.0/24");
        this.testBitwiseOr("0.0.0.0", null, "1.2.3.4", "1.2.3.4");
        this.testBitwiseOr("0.0.0.0", 1, "1.2.3.4", "1.2.3.4");
        this.testBitwiseOr("0.0.0.0", -1, "1.2.3.4", "1.2.3.4/31");
        this.testBitwiseOr("0.0.0.0", 0, "1.2.3.4", "1.2.3.4");
        this.testBitwiseOr("0.0.0.0/0", -1, "1.2.3.4", isNoAutoSubnets?"1.2.3.4":null);
        this.testBitwiseOr("0.0.0.0/16", null, "0.0.255.255", "0.0.255.255");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("0.0.0.0/16", 18, "0.0.98.8", isNoAutoSubnets?"0.0.64.0/18":null, isNoAutoSubnets || allPrefixesAreSubnets?"0.0.98.8/16":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("0.0.0.0/16", 18, "0.0.194.8", "0.0.192.0/18", isNoAutoSubnets || allPrefixesAreSubnets?"0.0.194.8/16":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("0.0.0.1/16", 18, "0.0.194.8", allPrefixesAreSubnets?"0.0.192.0/18":"0.0.192.1/18", allPrefixesAreSubnets?"0.0.0.0/16":"0.0.194.9/16");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/16", 24, "0.0.3.248", !isNoAutoSubnets?null:"1.2.3.0/24", isNoAutoSubnets?"1.2.3.248/16":(allPrefixesAreSubnets?"1.2.0.0/16":null));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0/16", 23, "0.0.3.0", !isNoAutoSubnets?null:"1.2.2.0/23", isNoAutoSubnets?"1.2.3.0/16":(allPrefixesAreSubnets?"1.2.0.0/16":null));
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0", 24, "0.0.3.248", "1.2.3.0/24", "1.2.3.248");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0", 24, "0.0.3.0", "1.2.3.0/24", "1.2.3.0");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1.2.0.0", 23, "0.0.3.0", "1.2.2.0/23", "1.2.3.0");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("::/32", 36, "0:0:6004:8::", isNoAutoSubnets?"0:0:6000::/36":null, isNoAutoSubnets || allPrefixesAreSubnets?"0:0:6004:8::/32":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("::/32", 36, "0:0:f000:8::", isNoAutoSubnets?"0:0:f000::/36":"0:0:f000::/36", isNoAutoSubnets || allPrefixesAreSubnets?"0:0:f000:8::/32":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/32", 48, "0:0:3:effe::", isNoAutoSubnets?"1:2:3::/48":null, isNoAutoSubnets || allPrefixesAreSubnets?"1:2:3:effe::/32":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/32", 47, "0:0:3::", isNoAutoSubnets?"1:2:2::/47":null, isNoAutoSubnets || allPrefixesAreSubnets?"1:2:3::/32":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/46", 48, "0:0:3:248::", "1:2:3::/48", isNoAutoSubnets || allPrefixesAreSubnets?"1:2:3:248::/46":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/48", 48, "0:0:3:248::", "1:2:3::/48", isNoAutoSubnets || allPrefixesAreSubnets?"1:2:3:248::/48":null);
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::/48", 47, "0:0:3::", "1:2:2::/47", "1:2:3::/48");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::", 48, "0:0:3:248::", "1:2:3::/48", "1:2:3:248::");
        this.testPrefixBitwiseOr$java_lang_String$java_lang_Integer$java_lang_String$java_lang_String$java_lang_String("1:2::", 47, "0:0:3::", "1:2:2::/47", "1:2:3::");
        this.testBitwiseOr("1:2::", null, "0:0:3:4::", "1:2:3:4::");
        this.testBitwiseOr("1:2::", null, "::", "1:2::");
        this.testBitwiseOr("1:2::", null, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testBitwiseOr("1:2::", null, "fffe:fffd:ffff:ffff:ffff:ffff:ff0f:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ff0f:ffff");
        this.testBitwiseOr("1::/16", 32, "0:2:3::", "1:2:3::/48");
        this.testBitwiseOr("1:2::/32", 16, "0:0:3::", "1:2:3::/48");
        this.testBitwiseOr("::", null, "::1:2:3:4", "::1:2:3:4");
        this.testBitwiseOr("::", 1, "::1:2:3:4", "::1:2:3:4");
        this.testBitwiseOr("::", -1, "::1:2:3:4", "::1:2:3:4/127");
        this.testBitwiseOr("::", 0, "::1:2:3:4", "::1:2:3:4");
        this.testBitwiseOr("::/0", -1, "::1:2:3:4", isNoAutoSubnets?"::1:2:3:4":null);
        this.testBitwiseOr("::/32", null, "::ffff:ffff:ffff:ffff:ffff:ffff", "::ffff:ffff:ffff:ffff:ffff:ffff");
        this.testDelimitedCount("1,2.3.4,5.6", 4);
        this.testDelimitedCount("1,2.3,6.4,5.6,8", 16);
        this.testDelimitedCount("1:2:3:6:4:5:6:8", 1);
        this.testDelimitedCount("1:2,3,4:3:6:4:5,6fff,7,8,99:6:8", 15);
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:-1:cc::d:ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:-dd:cc::d:ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:1-:cc:d::ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "-1:aa:cc:d::ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "1-:aa:cc:d::ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:cc:d::ee:f:1-");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:0-1:cc:d::ee:f");
        this.ipv6test$boolean$java_lang_String(this.allowsRange(), "aa:1-ff:cc:d::ee:f");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "1.-1.33.4");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "-1.22.33.4");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "22.1-.33.4");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "22.33.4.1-");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "1-.22.33.4");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "22.0-1.33.4");
        this.ipv4test$boolean$java_lang_String(this.allowsRange(), "22.1-22.33.4");
        this.ipv4test$boolean$java_lang_String(false, "1.+1.33.4");
        this.ipv4test$boolean$java_lang_String(false, "+1.22.33.4");
        this.ipv4test$boolean$java_lang_String(false, "22.1+.33.4");
        this.ipv4test$boolean$java_lang_String(false, "22.33.4.1+");
        this.ipv4test$boolean$java_lang_String(false, "1+.22.33.4");
        this.ipv4test$boolean$java_lang_String(false, "22.0+1.33.4");
        this.ipv4test$boolean$java_lang_String(false, "22.1+22.33.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "2::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::", "1:0::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "f::", "F:0::");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::", "1:0:1::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "001.2.3.04");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4", "::ffff:1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/32", "1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.3", "1.2.0.3", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.3.4", "0x1.0x2.0x3.0x4", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "1.2.3.4", "01.02.03.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "0.0.0.4", "00.0x0.0x00.04", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.11.11", "11.0xb.013.0xB", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.0.11", "11.0xb.0xB", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.0.11", "11.0x00000000000000000b.0000000000000000000013", true);
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.0.11/16", "11.720896/16", true);
            this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "184549376/16", true);
            this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "0xb000000/16", true);
            this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "01300000000/16", true);
        }
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.11.0.11/16", "11.720907/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "184549387/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "0xb00000b/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String$boolean(true, "11.0.0.11/16", "01300000013/16", true);
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2::/32", "1:2::/ffff:ffff::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2::/1", "1:2::/8000::");
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2::", "1:2::/ffff:ffff::1");
        } else {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2::/1", "1:2::/ffff:ffff::1");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2::/31", "1:2::/ffff:fffe::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "0.2.3.0", "1.2.3.4/0.255.255.0");
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/16", "1.2.3.4/255.255.0.0");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/15", "1.2.3.4/255.254.0.0");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/17", "1.2.3.4/255.255.128.0");
        } else {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.128.0/16", "1.2.128.4/255.255.254.1");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.2.0/15", "1.2.3.4/255.254.2.3");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.0.4/17", "1.2.3.4/255.255.128.5");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.0.0/16", "1.2.3.4/255.255.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.0.0/15", "1.2.3.4/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(allPrefixesAreSubnets, "1.2.0.0/17", "1.2.3.4/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/16", "1.2.3.4/255.255.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/15", "1.2.3.4/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/17", "1.2.3.4/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.1.3.4/15", "1.2.3.4/255.254.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.1.3.4/17", "1.2.3.4/255.255.128.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "0.2.3.4", "1.2.3.4/0.255.255.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.2.3.0", "1.2.3.4/0.255.255.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.2.3.4", "1.2.3.4/0.255.255.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.1.3.4/16", "1.2.3.4/255.255.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:1.2.3.4", "1:2:3:4:5:6:1.2.3.4");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:0.0.0.0", "1:2:3:4:5:6::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:0:0.0.0.0", "1:2:3:4:5::");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%12", "1:2:3:4:5:6:102:304%12");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%a", "1:2:3:4:5:6:102:304%a");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%", "1:2:3:4:5:6:102:304%");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%%", "1:2:3:4:5:6:102:304%%");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1:2:3:4:5:6:1.2.3.4%a", "1:2:3:4:5:6:102:304");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%", "1:2:3:4:5:6:102:304%");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4%-a-", "1:2:3:4:5:6:102:304%-a-");
        if(isNoAutoSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::%-.1/16", "1::%-.1");
            this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::/16", "1::%-.1");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::%-1/16", "1::%-1");
            this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::/16", "1::%-1");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1::0.0.0.0%-1", "1::%-1");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::0.0.0.0", "1::%-1");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1::0.0.0.0%-1", "1::");
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/64", "1:2:3:4::/64");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/96", "1:2:3:4:5:6::/96");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:255.2.3.4/97", "1:2:3:4:5:6:8000::/97");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/112", "1:2:3:4:5:6:102::/112");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.255.4/115", "1:2:3:4:5:6:102:e000/115");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4::0.0.0.0/64", "1:2:3:4::/64");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:0.0.0.0/96", "1:2:3:4:5:6::/96");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:128.0.0.0/97", "1:2:3:4:5:6:8000::/97");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.0.0/112", "1:2:3:4:5:6:102::/112");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.224.0/115", "1:2:3:4:5:6:102:e000/115");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1:2:3:4:5:6:1.2.3.4/128", "1:2:3:4:5:6:102:304/128");
        this.ipv4test$boolean$java_lang_String(true, "1.2.3.4/255.1.0.0");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/1::1");
        this.ipv6test$boolean$java_lang_String(true, "1:2::/1:2::");
        this.ipv6test$boolean$java_lang_String(false, "1:2::/1:2::/16");
        this.ipv6test$boolean$java_lang_String(false, "1:2::/1.2.3.4");
        if(allPrefixesAreSubnets) {
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/0", "0.0.0.0/0");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/1", "0.0.0.0/1");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/4", "0.0.0.0/4");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/5", "8.0.0.0/5");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/7", "8.0.0.0/7");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/8", "9.0.0.0/8");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/9", "9.128.0.0/9");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/15", "9.128.0.0/15");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/16", "9.129.0.0/16");
            this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/30", "9.129.237.24/30");
        }
        this.testCIDRSubnets$java_lang_String$java_lang_String("9.129.237.26/32", "9.129.237.26/32");
        if(allPrefixesAreSubnets) {
            this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/0", "0:0:0:0:0:0:0:0/0");
            this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/1", "8000:0:0:0:0:0:0:0/1");
            this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/30", "ffff:0:0:0:0:0:0:0/30");
            this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/32", "ffff:0:0:0:0:0:0:0/32");
            this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/126", "ffff:0:0:0:0:0:0:fffc/126");
        }
        this.testCIDRSubnets$java_lang_String$java_lang_String("ffff::ffff/128", "ffff:0:0:0:0:0:0:ffff/128");
        this.testMasksAndPrefixes();
        if(allPrefixesAreSubnets) {
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/0", "1.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/1", "127.2.3.4", false);
            this.testNotContains("9.129.237.26/1", "128.2.3.4");
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/4", "15.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/4", "9.129.237.26/16", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/5", "15.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/7", "9.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/8", "9.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/9", "9.255.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/15", "9.128.3.4", false);
            this.testNotContains("9.129.237.26/15", "10.128.3.4");
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/16", "9.129.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/30", "9.129.237.27", false);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/30", "9.129.237.27/31", false);
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/0", "1.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/1", "127.2.3.4", isAutoSubnets, false);
        this.testNotContains("0.0.0.0/1", "128.2.3.4");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "15.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0.0.0.0/4", "9.129.0.0/16", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.0/5", "15.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8.0.0.0/7", "9.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.0.0.0/8", "9.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/9", "9.255.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.128.0.0/15", "9.128.3.4", isAutoSubnets, false);
        this.testNotContains("9.128.0.0/15", "10.128.3.4");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.0.0/16", "9.129.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24/30", "9.129.237.27", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("9.129.237.24/30", "9.129.237.26/31", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/32", "9.129.237.26", true);
        this.testNotContains("9.129.237.26/32", "9.128.237.26");
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()) {
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/0", "0.0.0.0/0", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/1", "0.0.0.0/1", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/4", "0.0.0.0/4", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/5", "8.0.0.0/5", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/7", "8.0.0.0/7", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/8", "9.0.0.0/8", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/9", "9.128.0.0/9", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/15", "9.128.0.0/15", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/16", "9.129.0.0/16", true);
            this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/30", "9.129.237.24/30", true);
        }
        this.testContains$java_lang_String$java_lang_String$boolean("0.0.0.0/0", "0.0.0.0/0", true);
        this.testContains$java_lang_String$java_lang_String$boolean("0.0.0.0/1", "0.0.0.0/1", true);
        this.testContains$java_lang_String$java_lang_String$boolean("0.0.0.0/4", "0.0.0.0/4", true);
        this.testContains$java_lang_String$java_lang_String$boolean("8.0.0.0/5", "8.0.0.0/5", true);
        this.testContains$java_lang_String$java_lang_String$boolean("8.0.0.0/7", "8.0.0.0/7", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.0.0.0/8", "9.0.0.0/8", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.128.0.0/9", "9.128.0.0/9", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.128.0.0/15", "9.128.0.0/15", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.129.0.0/16", "9.129.0.0/16", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.24/30", "9.129.237.24/30", true);
        this.testContains$java_lang_String$java_lang_String$boolean("9.129.237.26/32", "9.129.237.26/32", true);
        this.testContains$java_lang_String$java_lang_String$boolean("::ffff:1.2.3.4", "1.2.3.4", true);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()) {
            this.testContains$java_lang_String$java_lang_String$boolean("::ffff:1.2.3.4/112", "1.2.3.4", false);
            this.testContains$java_lang_String$java_lang_String$boolean("::ffff:1.2.3.4/112", "1.2.3.4/16", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/0", "a:b:c:d:e:f:a:b", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/1", "8aaa:b:c:d:e:f:a:b", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/30", "ffff:3:c:d:e:f:a:b", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/32", "ffff:0:ffff:d:e:f:a:b", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/126", "ffff:0:0:0:0:0:0:ffff", false);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/128", "ffff:0:0:0:0:0:0:ffff", true);
        }
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("::ffff:1.2.0.0/112", "1.2.3.4", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean("::ffff:1.2.0.0/112", "1.2.0.0/16", true);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("0:0:0:0:0:0:0:0/0", "a:b:c:d:e:f:a:b", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("8000:0:0:0:0:0:0:0/1", "8aaa:b:c:d:e:f:a:b", isAutoSubnets, false);
        this.testNotContains("8000:0:0:0:0:0:0:0/1", "aaa:b:c:d:e:f:a:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:0:0:0/30", "ffff:3:c:d:e:f:a:b", isAutoSubnets, false);
        this.testNotContains("ffff:0:0:0:0:0:0:0/30", "ffff:4:c:d:e:f:a:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:0:0:0/32", "ffff:0:ffff:d:e:f:a:b", isAutoSubnets, false);
        this.testNotContains("ffff:0:0:0:0:0:0:0/32", "ffff:1:ffff:d:e:f:a:b");
        this.testContains$java_lang_String$java_lang_String$boolean$boolean("ffff:0:0:0:0:0:0:fffc/126", "ffff:0:0:0:0:0:0:ffff", isAutoSubnets, false);
        this.testContains$java_lang_String$java_lang_String$boolean("ffff:0:0:0:0:0:0:ffff/128", "ffff:0:0:0:0:0:0:ffff", true);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()) {
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/0", "0:0:0:0:0:0:0:0/0", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/1", "8000:0:0:0:0:0:0:0/1", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/30", "ffff:0:0:0:0:0:0:0/30", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/32", "ffff:0:0:0:0:0:0:0/32", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/126", "ffff:0:0:0:0:0:0:fffc/126", true);
            this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/128", "ffff:0:0:0:0:0:0:ffff/128", true);
        }
        this.testContains$java_lang_String$java_lang_String$boolean("::/0", "0:0:0:0:0:0:0:0/0", true);
        this.testContains$java_lang_String$java_lang_String$boolean("8000::/1", "8000:0:0:0:0:0:0:0/1", true);
        this.testContains$java_lang_String$java_lang_String$boolean("ffff::/30", "ffff:0:0:0:0:0:0:0/30", true);
        this.testContains$java_lang_String$java_lang_String$boolean("ffff::/32", "ffff:0:0:0:0:0:0:0/32", true);
        this.testContains$java_lang_String$java_lang_String$boolean("ffff::fffc/126", "ffff:0:0:0:0:0:0:fffc/126", true);
        this.testContains$java_lang_String$java_lang_String$boolean("ffff::ffff/128", "ffff:0:0:0:0:0:0:ffff/128", true);
        this.prefixtest$boolean$java_lang_String(true, "/24");
        this.prefixtest$boolean$java_lang_String(true, "/33");
        this.prefixtest$boolean$java_lang_String(false, "/129");
        this.prefixtest$boolean$java_lang_String(false, "/2 4");
        this.prefixtest$boolean$java_lang_String(false, "/ 24");
        this.prefixtest$boolean$java_lang_String(false, "/-24");
        this.prefixtest$boolean$java_lang_String(false, "/+24");
        this.prefixtest$boolean$java_lang_String(false, "/x");
        this.prefixtest$boolean$java_lang_String(false, "/1.2.3.4");
        this.prefixtest$boolean$java_lang_String(false, "/1::1");
        this.ipv4test$boolean$java_lang_String(true, "1.2.3.4/1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/ 1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/-1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/+1");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/");
        this.ipv4test$boolean$java_lang_String(true, "1.2.3.4/1.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/x");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/33");
        this.ipv6test$boolean$java_lang_String(true, "1::1/1");
        this.ipv6test$boolean$java_lang_String(false, "1::1/-1");
        this.ipv6test$boolean$java_lang_String(false, "1::1/");
        this.ipv6test$boolean$java_lang_String(false, "1::1/x");
        this.ipv6test$boolean$java_lang_String(false, "1::1/129");
        this.ipv6test$boolean$java_lang_String(true, "1::1/1::1");
        this.testNetmasks(0, "0.0.0.0/0", "0.0.0.0", "255.255.255.255", "::/0", "::", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(1, "128.0.0.0/1", "128.0.0.0", "127.255.255.255", "8000::/1", "8000::", "7fff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(15, "255.254.0.0/15", "255.254.0.0", "0.1.255.255", "fffe::/15", "fffe::", "1:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(16, "255.255.0.0/16", "255.255.0.0", "0.0.255.255", "ffff::/16", "ffff::", "::ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(17, "255.255.128.0/17", "255.255.128.0", "0.0.127.255", "ffff:8000::/17", "ffff:8000::", "::7fff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(31, "255.255.255.254/31", "255.255.255.254", "0.0.0.1", "ffff:fffe::/31", "ffff:fffe::", "::1:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(32, "255.255.255.255/32", "255.255.255.255", "0.0.0.0", "ffff:ffff::/32", "ffff:ffff::", "::ffff:ffff:ffff:ffff:ffff:ffff");
        this.testNetmasks(127, "255.255.255.255/127", null, "0.0.0.0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:fffe/127", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:fffe", "::1");
        this.testNetmasks(128, "255.255.255.255/128", null, "0.0.0.0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/128", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "::");
        this.testNetmasks(129, "255.255.255.255/129", null, "0.0.0.0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/129", null, "::");
        this.checkNotMask$java_lang_String("254.255.0.0");
        this.checkNotMask$java_lang_String("255.255.0.1");
        this.checkNotMask$java_lang_String("0.1.0.0");
        this.checkNotMask$java_lang_String("0::10");
        this.checkNotMask$java_lang_String("1::0");
        this.testSubnet("1.2.0.0", "0.0.255.255", 16, "0.0.0.0/16", "0.0.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0", "0.0.255.255", 17, "0.0.0.0/17", "0.0.0.0", "1.2.0.0/17");
        this.testSubnet("1.2.128.0", "0.0.255.255", 17, "0.0.128.0/17", "0.0.128.0", "1.2.128.0/17");
        this.testSubnet("1.2.0.0", "0.0.255.255", 15, "0.0.0.0/15", "0.0.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0", "0.0.255.255", 15, "0.0.0.0/15", "0.0.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "0.0.255.255", 16, "0.0.0.0/16", isNoAutoSubnets?"0.0.0.0":"0.0.*.*", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "0.0.255.255", 15, "0.0.0.0/15", isNoAutoSubnets?"0.0.0.0":"0.0.*.*", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "0.0.255.255", 15, "0.0.0.0/15", isNoAutoSubnets?"0.0.0.0":"0.0.*.*", "1.2.0.0/15");
        this.testSubnet("1.0.0.0/15", "0.1.255.255", 15, "0.0.0.0/15", isNoAutoSubnets?"0.0.0.0":"0.0-1.*.*", "1.0.0.0/15");
        this.testSubnet("1.2.0.0/17", "0.0.255.255", 16, "0.0.0.0/16", isNoAutoSubnets?"0.0.0.0":"0.0.0-127.*", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/17", "0.0.255.255", 17, "0.0.0.0/17", isNoAutoSubnets?"0.0.0.0":"0.0.0-127.*", "1.2.0.0/17");
        this.testSubnet("1.2.128.0/17", "0.0.255.255", 17, "0.0.128.0/17", isNoAutoSubnets?"0.0.128.0":"0.0.128-255.*", "1.2.128.0/17");
        this.testSubnet("1.2.0.0/17", "0.0.255.255", 15, "0.0.0.0/15", isNoAutoSubnets?"0.0.0.0":"0.0.0-127.*", "1.2.0.0/15");
        this.testSubnet("1.3.128.0/17", "0.0.255.255", 15, allPrefixesAreSubnets?"0.0.0.0/15":(isNoAutoSubnets?"0.1.128.0/15":"0.1.128-255.*/15"), isNoAutoSubnets?"0.0.128.0":"0.0.128-255.*", "1.2.0.0/15");
        this.testSubnet("1.3.128.0/17", "255.255.255.255", 15, allPrefixesAreSubnets?"1.2.0.0/15":(isNoAutoSubnets?"1.3.128.0/15":"1.3.128-255.*/15"), isNoAutoSubnets?"1.3.128.0":"1.3.128-255.*", "1.2.0.0/15");
        this.testSubnet("1.3.0.0/16", "255.255.255.255", 8, allPrefixesAreSubnets?"1.0.0.0/8":(isNoAutoSubnets?"1.3.0.0/8":"1.3.*.*/8"), isNoAutoSubnets?"1.3.0.0":"1.3.*.*", "1.0.0.0/8");
        this.testSubnet("1.0.0.0/16", "255.255.255.255", 8, "1.0.0.0/8", isNoAutoSubnets?"1.0.0.0":"1.0.*.*", "1.0.0.0/8");
        this.testSubnet("1.0.0.0/18", "255.255.255.255", 16, "1.0.0.0/16", isNoAutoSubnets?"1.0.0.0":"1.0.0-63.*", "1.0.0.0/16");
        this.testSubnet("1.2.0.0", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/17");
        this.testSubnet("1.2.128.0", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.128.0/17");
        this.testSubnet("1.2.128.0", "255.255.128.0", 17, "1.2.128.0/17", "1.2.128.0", "1.2.128.0/17");
        this.testSubnet("1.2.0.0", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/17", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/17", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/17");
        this.testSubnet("1.2.128.0/17", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.128.0/17");
        this.testSubnet("1.2.128.0/17", "255.255.128.0", 17, "1.2.128.0/17", "1.2.128.0", "1.2.128.0/17");
        this.testSubnet("1.2.0.0/17", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/16", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.128.0", 17, isNoAutoSubnets?"1.2.0.0/17":"1.2.0-128.0/17", isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.0.0", 16, isNoAutoSubnets?"1.2.0.0/16":"1.2-3.0.0/16", isNoAutoSubnets?"1.2.0.0":"1.2-3.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.0.0", 17, isNoAutoSubnets?"1.2.0.0/17":"1.2-3.0.0/17", isNoAutoSubnets?"1.2.0.0":"1.2-3.0.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.128.0", 17, isNoAutoSubnets?"1.2.0.0/17":"1.2-3.0-128.0/17", isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.128.0", 18, isNoAutoSubnets?"1.2.0.0/18":null, isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.192.0", 18, isNoAutoSubnets?"1.2.0.0/18":"1.2-3.0-192.0/18", isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.0.0.0/12", "255.254.0.0", 16, isNoAutoSubnets?"1.0.0.0/16":null, isNoAutoSubnets?"1.0.0.0":null, "1.0.0.0/12");
        this.testSubnet("1.0.0.0/12", "255.243.0.255", 16, isNoAutoSubnets?"1.0.0.0/16":"1.0-3.0.0/16", isNoAutoSubnets?"1.0.0.0":"1.0-3.0.*", "1.0.0.0/12");
        this.testSubnet("1.0.0.0/12", "255.255.0.0", 16, isNoAutoSubnets?"1.0.0.0/16":"1.0-15.0.0/16", isNoAutoSubnets?"1.0.0.0":"1.0-15.0.0", "1.0.0.0/12");
        this.testSubnet("1.0.0.0/12", "255.240.0.0", 16, "1.0.0.0/16", "1.0.0.0", "1.0.0.0/12");
        this.testSubnet("1.0.0.0/12", "255.248.0.0", 13, isNoAutoSubnets?"1.0.0.0/13":"1.0-8.0.0/13", isNoAutoSubnets?"1.0.0.0":null, "1.0.0.0/12");
        this.testSubnet("1.2.0.0/15", "255.254.128.0", 17, isNoAutoSubnets?"1.2.0.0/17":"1.2.0-128.0/17", isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.128.0", 17, isNoAutoSubnets?"1.2.0.0/17":"1.2-3.0-128.0/17", isNoAutoSubnets?"1.2.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.252.128.0", 17, isNoAutoSubnets?"1.0.0.0/17":"1.0.0-128.0/17", isNoAutoSubnets?"1.0.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.252.128.0", 18, isNoAutoSubnets?"1.0.0.0/18":null, isNoAutoSubnets?"1.0.0.0":null, "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.127.0", 15, "1.2.0.0/15", isNoAutoSubnets?"1.2.0.0":"1.2-3.0-127.0", "1.2.0.0/15");
        this.testSubnet("1.2.0.0/15", "255.255.0.255", 15, "1.2.0.0/15", isNoAutoSubnets?"1.2.0.0":"1.2-3.0.*", "1.2.0.0/15");
        if(allPrefixesAreSubnets) {
            this.testSubnet("1.2.128.1/17", "0.0.255.255", 17, "0.0.128.0/17", "0.0.128-255.*", "1.2.128.0/17");
            this.testSubnet("1.2.3.4", "0.0.255.255", 16, "0.0.0.0/16", "0.0.3.4", "1.2.0.0/16");
            this.testSubnet("1.2.3.4", "0.0.255.255", 17, "0.0.0.0/17", "0.0.3.4", "1.2.0.0/17");
            this.testSubnet("1.2.128.4", "0.0.255.255", 17, "0.0.128.0/17", "0.0.128.4", "1.2.128.0/17");
            this.testSubnet("1.2.3.4", "0.0.255.255", 15, "0.0.0.0/15", "0.0.3.4", "1.2.0.0/15");
            this.testSubnet("1.1.3.4", "0.0.255.255", 15, "0.0.0.0/15", "0.0.3.4", "1.0.0.0/15");
            this.testSubnet("1.2.128.4", "0.0.255.255", 15, "0.0.0.0/15", "0.0.128.4", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 16, "0.0.0.0/16", "0.0.*.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 17, "0.0.0-128.0/17", "0.0.*.*", "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "0.0.255.255", 17, "0.0.0-128.0/17", "0.0.*.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 15, "0.0.0.0/15", "0.0.*.*", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/15", "0.0.255.255", 15, "0.0.0.0/15", "0.0.*.*", "1.0.0.0/15");
            this.testSubnet("1.2.128.4/15", "0.0.255.255", 15, "0.0.0.0/15", "0.0.*.*", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/15", "0.1.255.255", 15, "0.0.0.0/15", "0.0-1.*.*", "1.0.0.0/15");
            this.testSubnet("1.0.3.4/15", "0.1.255.255", 15, "0.0.0.0/15", "0.0-1.*.*", "1.0.0.0/15");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 16, "0.0.0.0/16", "0.0.0-127.*", "1.2.0.0/16");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 17, "0.0.0.0/17", "0.0.0-127.*", "1.2.0.0/17");
            this.testSubnet("1.2.128.4/17", "0.0.255.255", 17, "0.0.128.0/17", "0.0.128-255.*", "1.2.128.0/17");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 15, "0.0.0.0/15", "0.0.0-127.*", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/17", "0.0.255.255", 15, "0.0.0.0/15", "0.0.0-127.*", "1.0.0.0/15");
            this.testSubnet("1.2.128.4/17", "0.0.255.255", 15, "0.0.0.0/15", "0.0.128-255.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
            this.testSubnet("1.2.3.4", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/17");
            this.testSubnet("1.2.128.4", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.128.0/17");
            this.testSubnet("1.2.128.4", "255.255.128.0", 17, "1.2.128.0/17", "1.2.128.0", "1.2.128.0/17");
            this.testSubnet("1.2.3.4", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.1.3.4", "255.255.0.0", 15, "1.0.0.0/15", "1.1.0.0", "1.0.0.0/15");
            this.testSubnet("1.2.128.4", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/17");
            this.testSubnet("1.2.128.4/17", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.128.0/17");
            this.testSubnet("1.2.128.4/17", "255.255.128.0", 17, "1.2.128.0/17", "1.2.128.0", "1.2.128.0/17");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/17", "255.255.0.0", 15, "1.0.0.0/15", "1.1.0.0", "1.0.0.0/15");
            this.testSubnet("1.2.128.4/17", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 16, "1.2.0.0/16", "1.2.0.0", "1.2.0.0/16");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/16");
            this.testSubnet("1.2.128.4/16", "255.255.0.0", 17, "1.2.0.0/17", "1.2.0.0", "1.2.0.0/16");
            this.testSubnet("1.2.128.4/16", "255.255.128.0", 17, "1.2.0-128.0/17", null, "1.2.0.0/16");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/16", "255.255.0.0", 15, "1.0.0.0/15", "1.1.0.0", "1.0.0.0/15");
            this.testSubnet("1.2.128.4/16", "255.255.0.0", 15, "1.2.0.0/15", "1.2.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.0.0", 16, "1.2-3.0.0/16", "1.2-3.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.0.0", 17, "1.2-3.0.0/17", "1.2-3.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.0.0", 17, "1.2-3.0.0/17", "1.2-3.0.0", "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 17, "1.2-3.0-128.0/17", null, "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 18, null, null, "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.192.0", 18, "1.2-3.0-192.0/18", null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/12", "255.254.0.0", 16, null, null, "1.0.0.0/12");
            this.testSubnet("1.2.3.4/12", "255.243.0.255", 16, "1.0-3.0.0/16", "1.0-3.0.*", "1.0.0.0/12");
            this.testSubnet("1.2.3.4/12", "255.255.0.0", 16, "1.0-15.0.0/16", "1.0-15.0.0", "1.0.0.0/12");
            this.testSubnet("1.2.3.4/12", "255.240.0.0", 16, "1.0.0.0/16", "1.0.0.0", "1.0.0.0/12");
            this.testSubnet("1.2.3.4/12", "255.248.0.0", 13, "1.0-8.0.0/13", null, "1.0.0.0/12");
            this.testSubnet("1.2.128.4/15", "255.254.128.0", 17, "1.2.0-128.0/17", null, "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 17, "1.2-3.0-128.0/17", null, "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.252.128.0", 17, "1.0.0-128.0/17", null, "1.2.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.252.128.0", 18, null, null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.127.0", 15, "1.2.0.0/15", "1.2-3.0-127.0", "1.2.0.0/15");
            this.testSubnet("1.1.3.4/15", "255.255.0.0", 15, "1.0.0.0/15", "1.0-1.0.0", "1.0.0.0/15");
            this.testSubnet("1.2.128.4/15", "255.255.0.255", 15, "1.2.0.0/15", "1.2-3.0.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4", "255.254.255.255", 15, "1.2.0.0/15", "1.2.3.4", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.254.255.255", 15, "1.2.0.0/15", "1.2.*.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.254.255", 15, "1.2.0.0/15", null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.254.0.255", 15, "1.2.0.0/15", "1.2.0.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.254.255", 16, "1.2-3.0.0/16", null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.254.255", 23, "1.2-3.0-254.0/23", null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/23", "255.255.254.255", 23, "1.2.2.0/23", "1.2.2.*", "1.2.2.0/23");
            this.testSubnet("1.2.3.4/23", "255.255.254.255", 15, "1.2.0.0/15", "1.2.2.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/15", "255.255.254.255", 24, null, null, "1.2.0.0/15");
            this.testSubnet("1.2.3.4/17", "255.255.255.255", 15, "1.2.0.0/15", "1.2.0-127.*", "1.2.0.0/15");
            this.testSubnet("1.2.3.4/17", "255.255.254.255", 24, null, null, "1.2.0.0/17");
            this.testSubnet("1.2.3.4/17", "255.255.254.255", 23, "1.2.0-126.0/23", null, "1.2.0.0/17");
            this.testSubnet("1.2.3.4/17", "255.255.254.255", 22, "1.2.0-124.0/22", null, "1.2.0.0/17");
        } else {
            this.testSubnet("1.2.128.1/17", "0.0.255.255", 17, "0.0.128.1/17", "0.0.128.1", "1.2.128.1/17");
            this.testSubnet("1.2.3.4", "0.0.255.255", 16, "0.0.3.4/16", "0.0.3.4", "1.2.3.4/16");
            this.testSubnet("1.2.3.4", "0.0.255.255", 17, "0.0.3.4/17", "0.0.3.4", "1.2.3.4/17");
            this.testSubnet("1.2.128.4", "0.0.255.255", 17, "0.0.128.4/17", "0.0.128.4", "1.2.128.4/17");
            this.testSubnet("1.2.3.4", "0.0.255.255", 15, "0.0.3.4/15", "0.0.3.4", "1.2.3.4/15");
            this.testSubnet("1.1.3.4", "0.0.255.255", 15, "0.1.3.4/15", "0.0.3.4", "1.1.3.4/15");
            this.testSubnet("1.2.128.4", "0.0.255.255", 15, "0.0.128.4/15", "0.0.128.4", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 16, "0.0.3.4/16", "0.0.3.4", "1.2.3.4/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 17, "0.0.3.4/17", "0.0.3.4", "1.2.3.4/15");
            this.testSubnet("1.2.128.4/15", "0.0.255.255", 17, "0.0.128.4/17", "0.0.128.4", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/15", "0.0.255.255", 15, "0.0.3.4/15", "0.0.3.4", "1.2.3.4/15");
            this.testSubnet("1.1.3.4/15", "0.0.255.255", 15, "0.1.3.4/15", "0.0.3.4", "1.1.3.4/15");
            this.testSubnet("1.2.128.4/15", "0.0.255.255", 15, "0.0.128.4/15", "0.0.128.4", "1.2.128.4/15");
            this.testSubnet("1.1.3.4/15", "0.1.255.255", 15, "0.1.3.4/15", "0.1.3.4", "1.1.3.4/15");
            this.testSubnet("1.0.3.4/15", "0.1.255.255", 15, "0.0.3.4/15", "0.0.3.4", "1.0.3.4/15");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 16, "0.0.3.4/16", "0.0.3.4", "1.2.3.4/16");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 17, "0.0.3.4/17", "0.0.3.4", "1.2.3.4/17");
            this.testSubnet("1.2.128.4/17", "0.0.255.255", 17, "0.0.128.4/17", "0.0.128.4", "1.2.128.4/17");
            this.testSubnet("1.2.3.4/17", "0.0.255.255", 15, "0.0.3.4/15", "0.0.3.4", "1.2.3.4/15");
            this.testSubnet("1.1.3.4/17", "0.0.255.255", 15, "0.1.3.4/15", "0.0.3.4", "1.0.3.4/15");
            this.testSubnet("1.2.128.4/17", "0.0.255.255", 15, "0.0.128.4/15", "0.0.128.4", "1.2.0.4/15");
            this.testSubnet("1.2.3.4", "255.255.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/16");
            this.testSubnet("1.2.3.4", "255.255.0.0", 17, "1.2.3.4/17", "1.2.0.0", "1.2.3.4/17");
            this.testSubnet("1.2.128.4", "255.255.0.0", 17, "1.2.0.4/17", "1.2.0.0", "1.2.128.4/17");
            this.testSubnet("1.2.128.4", "255.255.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/17");
            this.testSubnet("1.2.3.4", "255.255.0.0", 15, "1.2.3.4/15", "1.2.0.0", "1.2.3.4/15");
            this.testSubnet("1.1.3.4", "255.255.0.0", 15, "1.1.3.4/15", "1.1.0.0", "1.1.3.4/15");
            this.testSubnet("1.2.128.4", "255.255.0.0", 15, "1.2.128.4/15", "1.2.0.0", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/16");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 17, "1.2.3.4/17", "1.2.0.0", "1.2.3.4/17");
            this.testSubnet("1.2.128.4/17", "255.255.0.0", 17, "1.2.0.4/17", "1.2.0.0", "1.2.128.4/17");
            this.testSubnet("1.2.128.4/17", "255.255.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/17");
            this.testSubnet("1.2.3.4/17", "255.255.0.0", 15, "1.2.3.4/15", "1.2.0.0", "1.2.3.4/15");
            this.testSubnet("1.1.3.4/17", "255.255.0.0", 15, "1.1.3.4/15", "1.1.0.0", "1.0.3.4/15");
            this.testSubnet("1.2.128.4/17", "255.255.0.0", 15, "1.2.128.4/15", "1.2.0.0", "1.2.0.4/15");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/16");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 17, "1.2.3.4/17", "1.2.0.0", "1.2.3.4/16");
            this.testSubnet("1.2.128.4/16", "255.255.0.0", 17, "1.2.0.4/17", "1.2.0.0", "1.2.128.4/16");
            this.testSubnet("1.2.128.4/16", "255.255.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/16");
            this.testSubnet("1.2.3.4/16", "255.255.0.0", 15, "1.2.3.4/15", "1.2.0.0", "1.2.3.4/15");
            this.testSubnet("1.1.3.4/16", "255.255.0.0", 15, "1.1.3.4/15", "1.1.0.0", "1.0.3.4/15");
            this.testSubnet("1.2.128.4/16", "255.255.0.0", 15, "1.2.128.4/15", "1.2.0.0", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/15", "255.255.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/15");
            this.testSubnet("1.2.3.4/15", "255.255.0.0", 17, "1.2.3.4/17", "1.2.0.0", "1.2.3.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.0.0", 17, "1.2.0.4/17", "1.2.0.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 18, "1.2.128.4/18", "1.2.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.192.0", 18, "1.2.128.4/18", "1.2.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/12", "255.254.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/12");
            this.testSubnet("1.2.3.4/12", "255.243.0.255", 16, "1.2.3.4/16", "1.2.0.4", "1.2.3.4/12");
            this.testSubnet("1.2.3.4/12", "255.255.0.0", 16, "1.2.3.4/16", "1.2.0.0", "1.2.3.4/12");
            this.testSubnet("1.2.3.4/12", "255.240.0.0", 16, "1.0.3.4/16", "1.0.0.0", "1.2.3.4/12");
            this.testSubnet("1.2.3.4/12", "255.248.0.0", 13, "1.2.3.4/13", "1.0.0.0", "1.2.3.4/12");
            this.testSubnet("1.2.128.4/15", "255.254.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.128.0", 17, "1.2.128.4/17", "1.2.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.252.128.0", 17, "1.0.128.4/17", "1.0.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.128.4/15", "255.252.128.0", 18, "1.0.128.4/18", "1.0.128.0", "1.2.128.4/15");
            this.testSubnet("1.2.3.4/15", "255.255.127.0", 15, "1.2.3.4/15", "1.2.3.0", "1.2.3.4/15");
            this.testSubnet("1.1.3.4/15", "255.255.0.0", 15, "1.1.3.4/15", "1.1.0.0", "1.1.3.4/15");
            this.testSubnet("1.2.128.4/15", "255.255.0.255", 15, "1.2.128.4/15", "1.2.0.4", "1.2.128.4/15");
        }
        this.testSubnet("::/8", "ffff::", 128, isNoAutoSubnets?"0:0:0:0:0:0:0:0/128":"0-ff:0:0:0:0:0:0:0/128", isNoAutoSubnets?"0:0:0:0:0:0:0:0":"0-ff:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:0/8");
        this.testSubnet("::/8", "fff0::", 128, isNoAutoSubnets?"0:0:0:0:0:0:0:0/128":null, isNoAutoSubnets?"0:0:0:0:0:0:0:0":null, "0:0:0:0:0:0:0:0/8");
        this.testSubnet("::/8", "fff0::", 12, isNoAutoSubnets?"0:0:0:0:0:0:0:0/12":"0-f0:0:0:0:0:0:0:0/12", isNoAutoSubnets?"0:0:0:0:0:0:0:0":null, "0:0:0:0:0:0:0:0/8");
        this.testSubnet("1.2.0.0/16", "255.255.0.1", 24, "1.2.0.0/24", isNoAutoSubnets?"1.2.0.0":"1.2.0.0-1", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.0.3", 24, "1.2.0.0/24", isNoAutoSubnets?"1.2.0.0":"1.2.0.0-3", "1.2.0.0/16");
        this.testSubnet("1.2.0.0/16", "255.255.3.3", 24, isNoAutoSubnets?"1.2.0.0/24":"1.2.0-3.0/24", isNoAutoSubnets?"1.2.0.0":"1.2.0-3.0-3", "1.2.0.0/16");
        this.testSplit("9.129.237.26", 0, "", "", "", 1, "9.129.237.26", 2);
        this.testSplit("9.129.237.26", 8, "9", "9", "9/8", 2, "129.237.26", 2);
        this.testSplit("9.129.237.26", 16, "9.129", "9.129", "9.129/16", 2, "237.26", 2);
        this.testSplit("9.129.237.26", 31, "9.129.237.26-27", "9.129.237.26", isNoAutoSubnets?"9.129.237.26-27/31":"9.129.237.26/31", 2, "0", 2);
        this.testSplit("9.129.237.26", 32, "9.129.237.26", "9.129.237.26", "9.129.237.26/32", 2, "", 1);
        this.testSplit("1.2.3.4", 4, "0-15", "0", isNoAutoSubnets?"0-15/4":"0/4", 2, "1.2.3.4", 2);
        this.testSplit("255.2.3.4", 4, "240-255", "240", isNoAutoSubnets?"240-255/4":"240/4", 1, "15.2.3.4", 2);
        this.testSplit("9:129::237:26", 0, "", "", "", 1, "9:129:0:0:0:0:237:26", 12);
        this.testSplit("9:129::237:26", 16, "9", "9", "9/16", 2, "129:0:0:0:0:237:26", 12);
        this.testSplit("9:129::237:26", 31, "9:128-129", "9:128", isNoAutoSubnets?"9:128-129/31":"9:128/31", 2, "1:0:0:0:0:237:26", 12);
        this.testSplit("9:129::237:26", 32, "9:129", "9:129", "9:129/32", 2, "0:0:0:0:237:26", 10);
        this.testSplit("9:129::237:26", 33, "9:129:0-7fff", "9:129:0", isNoAutoSubnets?"9:129:0-7fff/33":"9:129:0/33", 2, "0:0:0:0:237:26", 10);
        this.testSplit("9:129::237:26", 63, "9:129:0:0-1", "9:129:0:0", isNoAutoSubnets?"9:129:0:0-1/63":"9:129:0:0/63", 4, "0:0:0:237:26", 10);
        this.testSplit("9:129::237:26", 64, "9:129:0:0", "9:129:0:0", "9:129:0:0/64", 4, "0:0:237:26", 10);
        this.testSplit("9:129::237:26", 96, "9:129:0:0:0:0", "9:129:0:0:0:0", "9:129:0:0:0:0/96", 4, "237:26", 4);
        this.testSplit("9:129::237:26", 111, "9:129:0:0:0:0:236-237", "9:129:0:0:0:0:236", isNoAutoSubnets?"9:129:0:0:0:0:236-237/111":"9:129:0:0:0:0:236/111", 12, "1:26", 4);
        this.testSplit("9:129::237:26", 112, "9:129:0:0:0:0:237", "9:129:0:0:0:0:237", "9:129:0:0:0:0:237/112", 12, "26", 4);
        this.testSplit("9:129::237:26", 113, "9:129:0:0:0:0:237:0-7fff", "9:129:0:0:0:0:237:0", isNoAutoSubnets?"9:129:0:0:0:0:237:0-7fff/113":"9:129:0:0:0:0:237:0/113", 12, "26", 4);
        this.testSplit("9:129::237:ffff", 113, "9:129:0:0:0:0:237:8000-ffff", "9:129:0:0:0:0:237:8000", isNoAutoSubnets?"9:129:0:0:0:0:237:8000-ffff/113":"9:129:0:0:0:0:237:8000/113", 12, "7fff", 3);
        this.testSplit("9:129::237:26", 127, "9:129:0:0:0:0:237:26-27", "9:129:0:0:0:0:237:26", isNoAutoSubnets?"9:129:0:0:0:0:237:26-27/127":"9:129:0:0:0:0:237:26/127", 12, "0", 5);
        this.testSplit("9:129::237:26", 128, "9:129:0:0:0:0:237:26", "9:129:0:0:0:0:237:26", "9:129:0:0:0:0:237:26/128", 12, "", 1);
        let USE_UPPERCASE : number = 2;
        this.testSplit("a:b:c:d:e:f:a:b", 4, "0-fff", "0", isNoAutoSubnets?"0-fff/4":"0/4", 2, "a:b:c:d:e:f:a:b", 6 * USE_UPPERCASE);
        this.testSplit("ffff:b:c:d:e:f:a:b", 4, "f000-ffff", "f000", isNoAutoSubnets?"f000-ffff/4":"f000/4", 1 * USE_UPPERCASE, "fff:b:c:d:e:f:a:b", 6 * USE_UPPERCASE);
        this.testSplit("ffff:b:c:d:e:f:a:b", 2, "c000-ffff", "c000", isNoAutoSubnets?"c000-ffff/2":"c000/2", 1 * USE_UPPERCASE, "3fff:b:c:d:e:f:a:b", 6 * USE_UPPERCASE);
        this.testURL("http://1.2.3.4");
        this.testURL("http://[a:a:a:a:b:b:b:b]");
        this.testURL("http://a:a:a:a:b:b:b:b");
        this.testSections("9.129.237.26", 0, 1);
        this.testSections("9.129.237.26", 8, 1);
        this.testSections("9.129.237.26", 16, 1);
        this.testSections("9.129.237.26", 24, 1);
        this.testSections("9.129.237.26", 32, 1);
        this.testSections("9:129::237:26", 0, 1);
        this.testSections("9:129::237:26", 16, 1);
        this.testSections("9:129::237:26", 64, 2);
        this.testSections("9:129::237:26", 80, 2);
        this.testSections("9:129::237:26", 96, 2);
        this.testSections("9:129::237:26", 112, 2);
        this.testSections("9:129::237:26", 128, 2);
        this.testSections("9.129.237.26", 7, 2);
        this.testSections("9.129.237.26", 9, 128);
        this.testSections("9.129.237.26", 10, 64);
        this.testSections("9.129.237.26", 11, 32);
        this.testSections("9.129.237.26", 12, 16);
        this.testSections("9.129.237.26", 13, 8);
        this.testSections("9.129.237.26", 14, 4);
        this.testSections("9.129.237.26", 15, 2);
        this.testVariantCounts$java_lang_String$int$int$int$int("::", 2, 2, 9, 1297);
        this.testVariantCounts$java_lang_String$int$int$int$int("::1", 2, 2, 10, 1298);
        this.testVariantCounts$java_lang_String$int$int$int$int$int("::ffff:1.2.3.4", 6, 4, 20, 1410, 1320);
        this.testVariantCounts$java_lang_String$int$int$int$int$int("::fffe:1.2.3.4", 2, 4, 20, 1320, 1320);
        this.testVariantCounts$java_lang_String$int$int$int$int$int("::ffff:0:0", 6, 4, 24, 1474, 1384);
        this.testVariantCounts$java_lang_String$int$int$int$int$int("::fffe:0:0", 2, 4, 24, 1384, 1384);
        this.testVariantCounts$java_lang_String$int$int$int$int("2:2:2:2:2:2:2:2", 2, 1, 6, 1280);
        this.testVariantCounts$java_lang_String$int$int$int$int("2:0:0:2:0:2:2:2", 2, 2, 18, 2240);
        this.testVariantCounts$java_lang_String$int$int$int$int("a:b:c:0:d:e:f:1", 2, 4, 12 * USE_UPPERCASE, 1920 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("a:b:c:0:0:d:e:f", 2, 4, 12 * USE_UPPERCASE, 1600 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("a:b:c:d:e:f:0:1", 2, 4, 8 * USE_UPPERCASE, 1408 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("a:b:c:d:e:f:0:0", 2, 4, 8 * USE_UPPERCASE, 1344 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("a:b:c:d:e:f:a:b", 2, 2, 6 * USE_UPPERCASE, 1280 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("aaaa:bbbb:cccc:dddd:eeee:ffff:aaaa:bbbb", 2, 2, 2 * USE_UPPERCASE, 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("a111:1111:1111:1111:1111:1111:9999:9999", 2, 2, 2 * USE_UPPERCASE, 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("1a11:1111:1111:1111:1111:1111:9999:9999", 2, 2, 2 * USE_UPPERCASE, 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("11a1:1111:1111:1111:1111:1111:9999:9999", 2, 2, 2 * USE_UPPERCASE, 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("111a:1111:1111:1111:1111:1111:9999:9999", 2, 2, 2 * USE_UPPERCASE, 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("aaaa:b:cccc:dddd:eeee:ffff:aaaa:bbbb", 2, 2, 4 * USE_UPPERCASE, 4 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("aaaa:b:cc:dddd:eeee:ffff:aaaa:bbbb", 2, 2, 4 * USE_UPPERCASE, 8 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int$int$int("1.2.3.4", 6, 1, 2, 420, 90, 16);
        this.testVariantCounts$java_lang_String$int$int$int$int$int$int("0.0.0.0", 6, 1, 2, 484, 90, 16);
        this.testVariantCounts$java_lang_String$int$int$int$int("1111:2222:aaaa:4444:5555:6666:7070:700a", 2, 1 * USE_UPPERCASE, 1 * USE_UPPERCASE + 2 * USE_UPPERCASE, 1 * USE_UPPERCASE + 2 * USE_UPPERCASE);
        this.testVariantCounts$java_lang_String$int$int$int$int("1111:2222:3333:4444:5555:6666:7070:700a", 2, 2, 1 * USE_UPPERCASE + 2, 1 * USE_UPPERCASE + 2);
        this.testReverseHostAddress("1.2.0.0/20");
        this.testReverseHostAddress("1.2.3.4");
        this.testReverseHostAddress("1:f000::/20");
        this.testFromBytes([-1, -1, -1, -1], "255.255.255.255");
        this.testFromBytes([1, 2, 3, 4], "1.2.3.4");
        this.testFromBytes((s => { let a=[]; while(s-->0) a.push(0); return a; })(16), "::");
        this.testFromBytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], "::1");
        this.testFromBytes([0, 10, 0, 11, 0, 12, 0, 13, 0, 14, 0, 15, 0, 1, 0, 2], "a:b:c:d:e:f:1:2");
        if(this.fullTest && HostTest.runDNS) {
            this.testResolved("espn.com", "199.181.132.250");
            this.testResolved("instapundit.com", "72.32.173.45");
        }
        this.testResolved("9.32.237.26", "9.32.237.26");
        this.testResolved("9.70.146.84", "9.70.146.84");
        this.testNormalized$java_lang_String$java_lang_String("1.2.3.4", "1.2.3.4");
        this.testNormalized$java_lang_String$java_lang_String("1.2.00.4", "1.2.0.4");
        this.testNormalized$java_lang_String$java_lang_String("000.2.00.4", "0.2.0.4");
        this.testNormalized$java_lang_String$java_lang_String("00.2.00.000", "0.2.0.0");
        this.testNormalized$java_lang_String$java_lang_String("000.000.000.000", "0.0.0.0");
        this.testNormalized$java_lang_String$java_lang_String("A:B:C:D:E:F:A:B", "a:b:c:d:e:f:a:b");
        this.testNormalized$java_lang_String$java_lang_String("ABCD:ABCD:CCCC:Dddd:EeEe:fFfF:aAAA:Bbbb", "abcd:abcd:cccc:dddd:eeee:ffff:aaaa:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("AB12:12CD:CCCC:Dddd:EeEe:fFfF:aAAA:Bbbb", "ab12:12cd:cccc:dddd:eeee:ffff:aaaa:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("ABCD::CCCC:Dddd:EeEe:fFfF:aAAA:Bbbb", "abcd::cccc:dddd:eeee:ffff:aaaa:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("::ABCD:CCCC:Dddd:EeEe:fFfF:aAAA:Bbbb", "::abcd:cccc:dddd:eeee:ffff:aaaa:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("ABCD:ABCD:CCCC:Dddd:EeEe:fFfF:aAAA::", "abcd:abcd:cccc:dddd:eeee:ffff:aaaa::");
        this.testNormalized$java_lang_String$java_lang_String("::ABCD:Dddd:EeEe:fFfF:aAAA:Bbbb", "::abcd:dddd:eeee:ffff:aaaa:bbbb");
        this.testNormalized$java_lang_String$java_lang_String("ABCD:ABCD:CCCC:Dddd:fFfF:aAAA::", "abcd:abcd:cccc:dddd:ffff:aaaa::");
        this.testNormalized$java_lang_String$java_lang_String("::ABCD", "::abcd");
        this.testNormalized$java_lang_String$java_lang_String("aAAA::", "aaaa::");
        this.testNormalized$java_lang_String$java_lang_String("0:0:0:0:0:0:0:0", "::");
        this.testNormalized$java_lang_String$java_lang_String("0000:0000:0000:0000:0000:0000:0000:0000", "::");
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("0000:0000:0000:0000:0000:0000:0000:0000", "0:0:0:0:0:0:0:0", true, false);
        this.testNormalized$java_lang_String$java_lang_String("0:0:0:0:0:0:0:1", "::1");
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("0:0:0:0:0:0:0:1", "0:0:0:0:0:0:0:1", true, false);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("0:0:0:0::0:0:1", "0:0:0:0:0:0:0:1", true, false);
        this.testNormalized$java_lang_String$java_lang_String("0000:0000:0000:0000:0000:0000:0000:0001", "::1");
        this.testNormalized$java_lang_String$java_lang_String("1:0:0:0:0:0:0:0", "1::");
        this.testNormalized$java_lang_String$java_lang_String("0001:0000:0000:0000:0000:0000:0000:0000", "1::");
        this.testNormalized$java_lang_String$java_lang_String("1:0:0:0:0:0:0:1", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("0001:0000:0000:0000:0000:0000:0000:0001", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("1:0:0:0::0:0:1", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("0001::0000:0000:0000:0000:0000:0001", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("0001:0000:0000:0000:0000:0000::0001", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("::0000:0000:0000:0000:0000:0001", "::1");
        this.testNormalized$java_lang_String$java_lang_String("0001:0000:0000:0000:0000:0000::", "1::");
        this.testNormalized$java_lang_String$java_lang_String("1:0::1", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("0001:0000::0001", "1::1");
        this.testNormalized$java_lang_String$java_lang_String("0::", "::");
        this.testNormalized$java_lang_String$java_lang_String("0000::", "::");
        this.testNormalized$java_lang_String$java_lang_String("::0", "::");
        this.testNormalized$java_lang_String$java_lang_String("::0000", "::");
        this.testNormalized$java_lang_String$java_lang_String("0:0:0:0:1:0:0:0", "::1:0:0:0");
        this.testNormalized$java_lang_String$java_lang_String("0000:0000:0000:0000:0001:0000:0000:0000", "::1:0:0:0");
        this.testNormalized$java_lang_String$java_lang_String("0:0:0:1:0:0:0:0", "0:0:0:1::");
        this.testNormalized$java_lang_String$java_lang_String("0000:0000:0000:0001:0000:0000:0000:0000", "0:0:0:1::");
        this.testNormalized$java_lang_String$java_lang_String("0:1:0:1:0:1:0:1", "::1:0:1:0:1:0:1");
        this.testNormalized$java_lang_String$java_lang_String("0000:0001:0000:0001:0000:0001:0000:0001", "::1:0:1:0:1:0:1");
        this.testNormalized$java_lang_String$java_lang_String("1:1:0:1:0:1:0:1", "1:1::1:0:1:0:1");
        this.testNormalized$java_lang_String$java_lang_String("0001:0001:0000:0001:0000:0001:0000:0001", "1:1::1:0:1:0:1");
        this.testCanonical("0001:0000:0000:000F:0000:0000:0001:0001", "1::f:0:0:1:1");
        this.testCanonical("0001:0001:0000:000F:0000:0001:0000:0001", "1:1:0:f:0:1:0:1");
        this.testMixed$java_lang_String$java_lang_String("0001:0001:0000:000F:0000:0001:0000:0001", "1:1::f:0:1:0.0.0.1");
        this.testCompressed("a.b.c.d", "a.b.c.d");
        this.testCompressed("1:0:1:1:1:1:1:1", "1::1:1:1:1:1:1");
        this.testCanonical("1:0:1:1:1:1:1:1", "1:0:1:1:1:1:1:1");
        this.testMixed$java_lang_String$java_lang_String("1:0:1:1:1:1:1:1", "1::1:1:1:1:0.1.0.1");
        this.testMixed$java_lang_String$java_lang_String$java_lang_String("::", "::", "::0.0.0.0");
        this.testMixed$java_lang_String$java_lang_String("::1", "::0.0.0.1");
        this.testRadices("255.127.254.2", "11111111.1111111.11111110.10", 2);
        this.testRadices("2.254.127.255", "10.11111110.1111111.11111111", 2);
        this.testRadices("1.12.4.8", "1.1100.100.1000", 2);
        this.testRadices("8.4.12.1", "1000.100.1100.1", 2);
        this.testRadices("10.5.10.5", "1010.101.1010.101", 2);
        this.testRadices("5.10.5.10", "101.1010.101.1010", 2);
        this.testRadices("0.1.0.1", "0.1.0.1", 2);
        this.testRadices("1.0.1.0", "1.0.1.0", 2);
        this.testRadices("255.127.254.2", "513.241.512.2", 7);
        this.testRadices("2.254.127.255", "2.512.241.513", 7);
        this.testRadices("0.1.0.1", "0.1.0.1", 7);
        this.testRadices("1.0.1.0", "1.0.1.0", 7);
        this.testRadices("255.127.254.2", "120.87.11e.2", 15);
        this.testRadices("2.254.127.255", "2.11e.87.120", 15);
        this.testRadices("0.1.0.1", "0.1.0.1", 15);
        this.testRadices("1.0.1.0", "1.0.1.0", 15);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E:F:000.000.000.000", "a:b:c:d:e:f::", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E::000.000.000.000", "a:b:c:d:e::", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::B:C:D:E:F:000.000.000.000", "0:b:c:d:e:f::", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D::000.000.000.000", "a:b:c:d::", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:000.000.000.000", "::c:d:e:f:0.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:000.000.000.000", "0:0:c:d:e:f:0.0.0.0", true, false);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C::E:F:000.000.000.000", "a:b:c:0:e:f::", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B::E:F:000.000.000.000", "a:b::e:f:0.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E:F:000.000.000.001", "a:b:c:d:e:f:0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E::000.000.000.001", "a:b:c:d:e::0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::B:C:D:E:F:000.000.000.001", "::b:c:d:e:f:0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D::000.000.000.001", "a:b:c:d::0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:000.000.000.001", "::c:d:e:f:0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:000.000.000.001", "0:0:c:d:e:f:0.0.0.1", true, false);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C::E:F:000.000.000.001", "a:b:c::e:f:0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B::E:F:000.000.000.001", "a:b::e:f:0.0.0.1", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E:F:001.000.000.000", "a:b:c:d:e:f:1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D:E::001.000.000.000", "a:b:c:d:e::1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::B:C:D:E:F:001.000.000.000", "::b:c:d:e:f:1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C:D::001.000.000.000", "a:b:c:d::1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:001.000.000.000", "::c:d:e:f:1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("::C:D:E:F:001.000.000.000", "0:0:c:d:e:f:1.0.0.0", true, false);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B:C::E:F:001.000.000.000", "a:b:c::e:f:1.0.0.0", true, true);
        this.testNormalized$java_lang_String$java_lang_String$boolean$boolean("A:B::E:F:001.000.000.000", "a:b::e:f:1.0.0.0", true, true);
        this.testMask("1.2.3.4", "0.0.2.0", "0.0.2.0");
        this.testMask("1.2.3.4", "0.0.1.0", "0.0.1.0");
        this.testMask("A:B:C:D:E:F:A:B", "A:0:C:0:E:0:A:0", "A:0:C:0:E:0:A:0");
        this.testMask("A:B:C:D:E:F:A:B", "FFFF:FFFF:FFFF:FFFF::", "A:B:C:D::");
        this.testMask("A:B:C:D:E:F:A:B", "::FFFF:FFFF:FFFF:FFFF", "::E:F:A:B");
        if(this.fullTest) {
            let len : number = 5000;
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            for(let i : number = 0; i < len; i++) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'1'); return sb; })(builder);
            };
            /* append */(sb => { sb.str = sb.str.concat(<any>".2.3.4"); return sb; })(builder);
            this.ipv4test$boolean$java_lang_String(false, /* toString */builder.str);
        }
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "");
        this.ipv4test$boolean$java_lang_String(true, "1.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "[1.2.3.4]");
        this.ipv4test$boolean$java_lang_String(false, "a");
        this.ipv4test$boolean$java_lang_String(this.isLenient(), "1.2.3");
        this.ipv4test$boolean$java_lang_String(false, "a.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.a.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.a.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.a");
        this.ipv4test$boolean$java_lang_String(false, ".2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1..3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2..4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.");
        this.ipv4test$boolean$java_lang_String(false, "256.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.256.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.256.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.256");
        this.ipv4test$boolean$java_lang_String(false, "f.f.f.f");
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "00.0.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.00.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.00.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.0.00", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "000.0.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.000.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.000.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "0.0.0.000", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "000.000.000.000", true);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0000.0.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0000.0.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0.0000.0", true);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0.0.0000", true);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.3.3.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "33.3.3.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.33.3.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.3.33.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.3.3.33", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "233.3.3.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.233.3.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.3.233.3", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "3.3.3.233", false);
        this.ipv4test$boolean$java_lang_String$boolean(true, "200.200.200.200", false);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0333.0.0.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0333.0.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0.0333.0", false);
        this.ipv4test$boolean$java_lang_String$boolean(this.isLenient(), "0.0.0.0333", false);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "00:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:00:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:00:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:00:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:00:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:00:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:00:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0:00", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "000:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:000:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:000:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:000:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:000:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:000:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:000:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0:000", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0000:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0000:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0000:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0000:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0000:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0000:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0000:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(true, "0:0:0:0:0:0:0:0000", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "00000:0:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:00000:0:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:00000:0:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:00000:0:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:00000:0:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:00000:0:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:00000:0", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:0:00000", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "00000:00000:00000:00000:00000:00000:00000:00000", true);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "03333:0:0:0:0:0:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:03333:0:0:0:0:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:03333:0:0:0:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:03333:0:0:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:03333:0:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:03333:0:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:03333:0", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "0:0:0:0:0:0:0:03333", false);
        this.ipv6test$boolean$java_lang_String$boolean(this.isLenient(), "03333:03333:03333:03333:03333:03333:03333:03333", false);
        this.ipv4test$boolean$java_lang_String(false, ".0.0.0");
        this.ipv4test$boolean$java_lang_String(false, "0..0.0");
        this.ipv4test$boolean$java_lang_String(false, "0.0..0");
        this.ipv4test$boolean$java_lang_String(false, "0.0.0.");
        this.ipv4test$boolean$java_lang_String(true, "/0");
        this.ipv4test$boolean$java_lang_String(true, "/1");
        this.ipv4test$boolean$java_lang_String(true, "/31");
        this.ipv4test$boolean$java_lang_String(true, "/32");
        this.ipv4test$boolean$java_lang_String$boolean$boolean(false, "/33", false, true);
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4//16");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4//");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/");
        this.ipv4test$boolean$java_lang_String(false, "/1.2.3.4//16");
        this.ipv4test$boolean$java_lang_String(false, "/1.2.3.4/16");
        this.ipv4test$boolean$java_lang_String(false, "/1.2.3.4");
        this.ipv4test$boolean$java_lang_String(false, "1.2.3.4/y");
        this.ipv4test$boolean$java_lang_String(true, "1.2.3.4/16");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:4//16");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:4//");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:4/");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:4/y");
        this.ipv6test$boolean$java_lang_String(true, "1:2::3:4/16");
        this.ipv6test$boolean$java_lang_String(true, "1:2::3:1.2.3.4/16");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:1.2.3.4//16");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:1.2.3.4//");
        this.ipv6test$boolean$java_lang_String(false, "1:2::3:1.2.3.4/y");
        this.ipv4test$boolean$java_lang_String(false, "127.0.0.1/x");
        this.ipv4test$boolean$java_lang_String(false, "127.0.0.1/127.0.0.1/x");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.255");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.256");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.65535");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.65536");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.16777215");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.16777216");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "4294967295");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "4294967296");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.0xff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.0x100");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0xffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0x10000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0xffffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0x1000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0xffffffff");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0x100000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.0.0377");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0.0400");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.0.017777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0.0200000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "0.077777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "0.0100000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "03777777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(true, "037777777777");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "040000000000");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "1.00x.1.1");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "1.0xx.1.1");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "1.xx.1.1");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "1.0x4x.1.1");
        this.ipv4_inet_aton_test$boolean$java_lang_String(false, "1.x4.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.00x.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.0xx.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.xx.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.0x4x.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.x4.1.1");
        this.ipv4test$boolean$java_lang_String(false, "1.4.1.1%1");
        this.ipv6test$boolean$java_lang_String(false, "1:00x:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:0xx:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:xx:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:0x4x:3:4:5:6:7:8");
        this.ipv6test$boolean$java_lang_String(false, "1:x4:3:4:5:6:7:8");
        this.ipv4testOnly(false, "1:2:3:4:5:6:7:8");
        this.ipv4testOnly(false, "::1");
        this.ipv6test$boolean$java_lang_String$boolean$boolean(false, "", false, this.isLenient());
        this.ipv6test$int$java_lang_String(1, "/0");
        this.ipv6test$int$java_lang_String(1, "/1");
        this.ipv6test$int$java_lang_String(1, "/127");
        this.ipv6test$int$java_lang_String(1, "/128");
        this.ipv6test$int$java_lang_String(0, "/129");
        this.ipv6test$int$java_lang_String$boolean(1, "::/0", isNoAutoSubnets);
        this.ipv6test$int$java_lang_String(0, ":1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "::1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "::1");
        this.ipv6test$int$java_lang_String$boolean(1, "::", true);
        this.ipv6test$int$java_lang_String(1, "0:0:0:0:0:0:0:1");
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0:0:0:0", true);
        this.ipv6test$int$java_lang_String(1, "2001:DB8:0:0:8:800:200C:417A");
        this.ipv6test$int$java_lang_String(1, "FF01:0:0:0:0:0:0:101");
        this.ipv6test$int$java_lang_String(1, "2001:DB8::8:800:200C:417A");
        this.ipv6test$int$java_lang_String(1, "FF01::101");
        this.ipv6test$int$java_lang_String(0, "2001:DB8:0:0:8:800:200C:417A:221");
        this.ipv6test$int$java_lang_String(0, "FF01::101::2");
        this.ipv6test$int$java_lang_String(1, "fe80::217:f2ff:fe07:ed62");
        this.ipv6test$int$java_lang_String(0, "[a::b:c:d:1.2.3.4]");
        this.ipv6testWithZone$int$java_lang_String(0, "[a::b:c:d:1.2.3.4%x]");
        this.ipv6testWithZone$boolean$java_lang_String(true, "a::b:c:d:1.2.3.4%x");
        this.ipv6test$int$java_lang_String(0, "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]");
        this.ipv6testWithZone$boolean$java_lang_String(true, "2001:0000:1234:0000:0000:C1C0:ABCD:0876%x");
        this.ipv6testWithZone$int$java_lang_String(0, "[2001:0000:1234:0000:0000:C1C0:ABCD:0876%x]");
        this.ipv6test$int$java_lang_String(1, "2001:0000:1234:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(1, "3ffe:0b00:0000:0000:0001:0000:0000:000a");
        this.ipv6test$int$java_lang_String(1, "FF02:0000:0000:0000:0000:0000:0000:0001");
        this.ipv6test$int$java_lang_String(1, "0000:0000:0000:0000:0000:0000:0000:0001");
        this.ipv6test$int$java_lang_String$boolean(1, "0000:0000:0000:0000:0000:0000:0000:0000", true);
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "02001:0000:1234:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "2001:0000:1234:0000:00001:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "2001:0000:1234:0000:0000:C1C0:ABCD:0876  0");
        this.ipv6test$int$java_lang_String(0, "0 2001:0000:1234:0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "2001:0000:1234: 0000:0000:C1C0:ABCD:0876");
        this.ipv6test$int$java_lang_String(0, "3ffe:0b00:0000:0001:0000:0000:000a");
        this.ipv6test$int$java_lang_String(0, "FF02:0000:0000:0000:0000:0000:0000:0000:0001");
        this.ipv6test$int$java_lang_String(0, "3ffe:b00::1::a");
        this.ipv6test$int$java_lang_String(0, "::1111:2222:3333:4444:5555:6666::");
        this.ipv6test$int$java_lang_String(1, "2::10");
        this.ipv6test$int$java_lang_String(1, "ff02::1");
        this.ipv6test$int$java_lang_String(1, "fe80::");
        this.ipv6test$int$java_lang_String(1, "2002::");
        this.ipv6test$int$java_lang_String(1, "2001:db8::");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:1234::");
        this.ipv6test$int$java_lang_String(1, "::ffff:0:0");
        this.ipv6test$int$java_lang_String(1, "::1");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3::8");
        this.ipv6test$int$java_lang_String(1, "1:2::8");
        this.ipv6test$int$java_lang_String(1, "1::8");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4:5");
        this.ipv6test$int$java_lang_String(1, "1::2:3:4");
        this.ipv6test$int$java_lang_String(1, "1::2:3");
        this.ipv6test$int$java_lang_String(1, "1::8");
        this.ipv6test$int$java_lang_String(1, "::2:3:4:5:6:7:8");
        this.ipv6test$int$java_lang_String(1, "::2:3:4:5:6:7");
        this.ipv6test$int$java_lang_String(1, "::2:3:4:5:6");
        this.ipv6test$int$java_lang_String(1, "::2:3:4:5");
        this.ipv6test$int$java_lang_String(1, "::2:3:4");
        this.ipv6test$int$java_lang_String(1, "::2:3");
        this.ipv6test$int$java_lang_String(1, "::8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6::");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::");
        this.ipv6test$int$java_lang_String(1, "1:2:3::");
        this.ipv6test$int$java_lang_String(1, "1:2::");
        this.ipv6test$int$java_lang_String(1, "1::");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::7:8");
        this.ipv6test$int$java_lang_String(0, "1:2:3::4:5::7:8");
        this.ipv6test$int$java_lang_String(0, "12345::6:7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:3::7:8");
        this.ipv6test$int$java_lang_String(1, "1:2::7:8");
        this.ipv6test$int$java_lang_String(1, "1::7:8");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:1.2.3.4");
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0:0:0.0.0.0", true);
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5::1.2.3.4");
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0::0.0.0.0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0::0.0.0.0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0.0.0.0", true);
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5:6:.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5:6:1.2.3.");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5:6:1.2..4");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3::1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2::1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1::1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4::5:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2:3::5:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1:2::5:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1::5:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1::5:11.22.33.44");
        this.ipv6test$int$java_lang_String(0, "1::5:400.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:260.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:256.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.256.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.256.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.3.256");
        this.ipv6test$int$java_lang_String(0, "1::5:300.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.300.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.300.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.3.300");
        this.ipv6test$int$java_lang_String(0, "1::5:900.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.900.3.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.900.4");
        this.ipv6test$int$java_lang_String(0, "1::5:1.2.3.900");
        this.ipv6test$int$java_lang_String(0, "1::5:300.300.300.300");
        this.ipv6test$int$java_lang_String(0, "1::5:3000.30.30.30");
        this.ipv6test$int$java_lang_String(0, "1::400.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::260.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::256.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.256.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.256.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.3.256");
        this.ipv6test$int$java_lang_String(0, "1::300.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.300.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.300.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.3.300");
        this.ipv6test$int$java_lang_String(0, "1::900.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.900.3.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.900.4");
        this.ipv6test$int$java_lang_String(0, "1::1.2.3.900");
        this.ipv6test$int$java_lang_String(0, "1::300.300.300.300");
        this.ipv6test$int$java_lang_String(0, "1::3000.30.30.30");
        this.ipv6test$int$java_lang_String(0, "::400.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::260.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::256.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.256.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.256.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.3.256");
        this.ipv6test$int$java_lang_String(0, "::300.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.300.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.300.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.3.300");
        this.ipv6test$int$java_lang_String(0, "::900.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.900.3.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.900.4");
        this.ipv6test$int$java_lang_String(0, "::1.2.3.900");
        this.ipv6test$int$java_lang_String(0, "::300.300.300.300");
        this.ipv6test$int$java_lang_String(0, "::3000.30.30.30");
        this.ipv6test$int$java_lang_String(1, "fe80::217:f2ff:254.7.237.98");
        this.ipv6test$int$java_lang_String(1, "::ffff:192.168.1.26");
        this.ipv6test$int$java_lang_String(0, "2001:1:1:1:1:1:255Z255X255Y255");
        this.ipv6test$int$java_lang_String(0, "::ffff:192x168.1.26");
        this.ipv6test$int$java_lang_String(1, "::ffff:192.168.1.1");
        this.ipv6test$int$java_lang_String(1, "0:0:0:0:0:0:13.1.68.3");
        this.ipv6test$int$java_lang_String(1, "0:0:0:0:0:FFFF:129.144.52.38");
        this.ipv6test$int$java_lang_String(1, "::13.1.68.3");
        this.ipv6test$int$java_lang_String(1, "::FFFF:129.144.52.38");
        this.ipv6test$int$java_lang_String(1, "fe80:0:0:0:204:61ff:254.157.241.86");
        this.ipv6test$int$java_lang_String(1, "fe80::204:61ff:254.157.241.86");
        this.ipv6test$int$java_lang_String(1, "::ffff:12.34.56.78");
        this.ipv6test$boolean$java_lang_String(this.isLenient(), "::ffff:2.3.4");
        this.ipv6test$int$java_lang_String(0, "::ffff:257.1.2.3");
        this.ipv6testOnly(0, "1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "a:b:c:d:e:f:a:b:c:d:e:f:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "a:b:c:d:e:f:a:b:c:d:e:f:a:b.");
        this.ipv6test$int$java_lang_String(0, "a:b:c:d:e:f:1.a:b:c:d:e:f:a");
        this.ipv6test$int$java_lang_String(0, "a:b:c:d:e:f:1.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(0, "a:b:c:d:e:f:.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(0, "::a:b:c:d:e:f:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::a:b:c:d:e:f:a:b.");
        this.ipv6test$int$java_lang_String(0, "::1.a:b:c:d:e:f:a");
        this.ipv6test$int$java_lang_String(0, "::1.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(0, "::.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(0, "1::a:b:c:d:e:f:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1::a:b:c:d:e:f:a:b.");
        this.ipv6test$int$java_lang_String(0, "1::1.a:b:c:d:e:f:a");
        this.ipv6test$int$java_lang_String(0, "1::1.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(0, "1::.a:b:c:d:e:f:a:b");
        this.ipv6test$int$java_lang_String(1, "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:1.2.3.4");
        this.ipv6test$boolean$java_lang_String(!this.isLenient(), "fe80:0000:0000:0000:0204:61ff:254.157.241.086");
        this.ipv6test$int$java_lang_String(1, "::ffff:192.0.2.128");
        this.ipv6test$int$java_lang_String(0, "XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:1.2.3.4");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:00.00.00.00");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:000.000.000.000");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:256.256.256.256");
        this.ipv6test$int$java_lang_String(1, "fe80:0000:0000:0000:0204:61ff:fe9d:f156");
        this.ipv6test$int$java_lang_String(1, "fe80:0:0:0:204:61ff:fe9d:f156");
        this.ipv6test$int$java_lang_String(1, "fe80::204:61ff:fe9d:f156");
        this.ipv6test$int$java_lang_String(1, "::1");
        this.ipv6test$int$java_lang_String(1, "fe80::");
        this.ipv6test$int$java_lang_String(1, "fe80::1");
        this.ipv6test$int$java_lang_String(0, ":");
        this.ipv6test$int$java_lang_String(1, "::ffff:c000:280");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::5555:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::5555:");
        this.ipv6test$int$java_lang_String(0, "1111::5555:");
        this.ipv6test$int$java_lang_String(0, "::5555:");
        this.ipv6test$int$java_lang_String(0, ":::");
        this.ipv6test$int$java_lang_String(0, "1111:");
        this.ipv6test$int$java_lang_String(0, ":");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::5555");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::5555");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::5555");
        this.ipv6test$int$java_lang_String(0, ":1111::5555");
        this.ipv6test$int$java_lang_String(0, ":::5555");
        this.ipv6test$int$java_lang_String(0, ":::");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:85a3:0000:0000:8a2e:0370:7334");
        this.ipv6test$int$java_lang_String(1, "2001:db8:85a3:0:0:8a2e:370:7334");
        this.ipv6test$int$java_lang_String(1, "2001:db8:85a3::8a2e:370:7334");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:0000:0000:0000:0000:1428:57ab");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:0000:0000:0000::1428:57ab");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:0:0:0:0:1428:57ab");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:0:0::1428:57ab");
        this.ipv6test$int$java_lang_String(1, "2001:0db8::1428:57ab");
        this.ipv6test$int$java_lang_String(1, "2001:db8::1428:57ab");
        this.ipv6test$int$java_lang_String(1, "0000:0000:0000:0000:0000:0000:0000:0001");
        this.ipv6test$int$java_lang_String(1, "::1");
        this.ipv6test$int$java_lang_String(1, "::ffff:0c22:384e");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:1234:0000:0000:0000:0000:0000");
        this.ipv6test$int$java_lang_String(1, "2001:0db8:1234:ffff:ffff:ffff:ffff:ffff");
        this.ipv6test$int$java_lang_String(1, "2001:db8:a::123");
        this.ipv6test$int$java_lang_String(1, "fe80::");
        this.ipv6test$boolean$java_lang_String$boolean$boolean(false, "123", false, this.isLenient());
        this.ipv6test$int$java_lang_String(0, "ldkfj");
        this.ipv6test$int$java_lang_String(0, "2001::FFD3::57ab");
        this.ipv6test$int$java_lang_String(0, "2001:db8:85a3::8a2e:37023:7334");
        this.ipv6test$int$java_lang_String(0, "2001:db8:85a3::8a2e:370k:7334");
        this.ipv6test$int$java_lang_String(0, "1:2:3:4:5:6:7:8:9");
        this.ipv6test$int$java_lang_String(0, "1::2::3");
        this.ipv6test$int$java_lang_String(0, "1:::3:4:5");
        this.ipv6test$int$java_lang_String(0, "1:2:3::4:5:6:7:8:9");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:7777::");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666::");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555::");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::");
        this.ipv6test$int$java_lang_String(1, "1111:2222::");
        this.ipv6test$int$java_lang_String(1, "1111::");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666::8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555::8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222::8888");
        this.ipv6test$int$java_lang_String(1, "1111::8888");
        this.ipv6test$int$java_lang_String(1, "::8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555::7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222::7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111::7777:8888");
        this.ipv6test$int$java_lang_String(1, "::7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222::6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111::6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "::6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111::3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "::3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "::2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444:5555::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333:4444::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222:3333::5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111:2222::4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "1111::3333:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(1, "::2222:3333:4444:5555:6666:123.123.123.123");
        this.ipv6test$int$java_lang_String(0, "1::2:3:4:5:6:1.2.3.4");
        this.ipv6test$int$java_lang_String$boolean(1, "::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0:0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0:0:0:0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0:0:0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0:0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0:0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "::0", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0:0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0:0::", true);
        this.ipv6test$int$java_lang_String$boolean(1, "0::", true);
        this.ipv6test$int$java_lang_String(0, "XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:8888:9999");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:8888::");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555:6666:7777:8888:9999");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333");
        this.ipv6test$int$java_lang_String(0, "1111:2222");
        this.ipv6test$boolean$java_lang_String$boolean$boolean(false, "1111", false, this.isLenient());
        this.ipv6test$int$java_lang_String(0, "11112222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:22223333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:33334444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:44445555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:55556666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:66667777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:77778888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:");
        this.ipv6test$int$java_lang_String(0, "1111:");
        this.ipv6test$int$java_lang_String(0, ":");
        this.ipv6test$int$java_lang_String(0, ":8888");
        this.ipv6test$int$java_lang_String(0, ":7777:8888");
        this.ipv6test$int$java_lang_String(0, ":6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:::3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:::7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:::8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:::");
        this.ipv6test$int$java_lang_String(0, "::2222::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "::2222:3333::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555::7777:8888");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555:7777::8888");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555:7777:8888::");
        this.ipv6test$int$java_lang_String(0, "1111::3333::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444:5555::7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444:5555:6666::8888");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444:5555:6666:7777::");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444:5555::7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444:5555:6666::8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444:5555:6666:7777::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555::7777:8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555:6666::8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555:6666:7777::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::6666::8888");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::6666:7777::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555::7777::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:8888:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555:6666:7777:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:1.2.3.4.5");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:1.2.3.4");
        this.ipv6testOnly(0, "1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "11112222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:22223333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:33334444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:44445555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:55556666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:66661.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:255255.255.255");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:255.255255.255");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:255.255.255255");
        this.ipv6test$int$java_lang_String(0, ":1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":2222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::2222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:::3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:::4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::2222::4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::2222:3333::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111::3333::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444:5555::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444:5555::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::.");
        this.ipv6test$int$java_lang_String(0, "::..");
        this.ipv6test$int$java_lang_String(0, "::...");
        this.ipv6test$int$java_lang_String(0, "::1...");
        this.ipv6test$int$java_lang_String(0, "::1.2..");
        this.ipv6test$int$java_lang_String(0, "::1.2.3.");
        this.ipv6test$int$java_lang_String(0, "::.2..");
        this.ipv6test$int$java_lang_String(0, "::.2.3.");
        this.ipv6test$int$java_lang_String(0, "::.2.3.4");
        this.ipv6test$int$java_lang_String(0, "::..3.");
        this.ipv6test$int$java_lang_String(0, "::..3.4");
        this.ipv6test$int$java_lang_String(0, "::...4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666:7777::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::");
        this.ipv6test$int$java_lang_String(0, ":1111::");
        this.ipv6test$int$java_lang_String(0, ":::");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666::8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555::8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::8888");
        this.ipv6test$int$java_lang_String(0, ":1111::8888");
        this.ipv6test$int$java_lang_String(0, ":::8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111::3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":::2222:3333:4444:5555:6666:7777:8888");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444:5555::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333:4444::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222:3333::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111:2222::4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111::4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":1111::3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, ":::2222:3333:4444:5555:6666:1.2.3.4");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:7777:::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666:::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:::");
        this.ipv6test$int$java_lang_String(0, "1111:::");
        this.ipv6test$int$java_lang_String(0, ":::");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555:6666::8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555::8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::8888:");
        this.ipv6test$int$java_lang_String(0, "1111::8888:");
        this.ipv6test$int$java_lang_String(0, "::8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444:5555::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333:4444::6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111::6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222:3333::5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111::5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111:2222::4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111::4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "1111::3333:4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::3333:4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(0, "::2222:3333:4444:5555:6666:7777:8888:");
        this.ipv6test$int$java_lang_String(1, "0:a:b:c:d:e:f::");
        this.ipv6test$int$java_lang_String(1, "::0:a:b:c:d:e:f");
        this.ipv6test$int$java_lang_String(1, "a:b:c:d:e:f:0::");
        this.ipv6test$int$java_lang_String(0, "\':10.0.0.1");
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8", [null, null, null, null, null, null, null, null, null]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("1.2.3.4", "5.6.7.8", [null, null, null, null, null]);
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("1.2.3.4", "5.6.7.8");
        this.testSQLMatching();
        this.testInvalidIpv4Values();
        this.testInvalidIpv6Values();
        this.testIPv4Values([1, 2, 3, 4], "16909060");
        this.testIPv4Values([0, 0, 0, 0], "0");
        this.testIPv4Values([255, 255, 255, 255], /* valueOf */new String(4294967295).toString());
        this.testIPv6Values([1, 2, 3, 4, 5, 6, 7, 8], "5192455318486707404433266433261576");
        this.testIPv6Values([0, 0, 0, 0, 0, 0, 0, 0], "0");
        let thirtyTwo : BigInteger = BigInteger.valueOf(4294967295);
        let one28 : BigInteger = thirtyTwo.shiftLeft(96).or(thirtyTwo.shiftLeft(64).or(thirtyTwo.shiftLeft(32).or(thirtyTwo)));
        this.testIPv6Values([65535, 65535, 65535, 65535, 65535, 65535, 65535, 65535], one28.toString());
        this.testSub("10.0.0.0/22", "10.0.1.0/24", isNoAutoSubnets?["10.0.0.0/22"]:["10.0.0.0/24", "10.0.2.0/23"]);
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1::/32", "1:1:1:1:1:1:1:1", isNoAutoSubnets?null:"1:1:1:1:1:1:1:1");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String$boolean("1:1::/32", "1:1::/16", "1:1::/32", !allPrefixesAreSubnets);
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1::/32", "1:1::/48", "1:1::/48");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1::/32", "1:1::/64", "1:1::/64");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1::/32", "1:1:2:2::/64", isNoAutoSubnets?null:"1:1:2:2::/64");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("1:1::/32", "1:0:2:2::/64", null);
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("10.0.0.0/22", "10.0.0.0/24", "10.0.0.0/24");
        this.testIntersect$java_lang_String$java_lang_String$java_lang_String("10.0.0.0/22", "10.0.1.0/24", isNoAutoSubnets?null:"10.0.1.0/24");
        this.testToPrefixBlock("1:3::3:4", "1:3::3:4");
        this.testToPrefixBlock("1.3.3.4", "1.3.3.4");
        this.testMaxHost("1.2.3.4", allPrefixesAreSubnets?"255.255.255.255":"255.255.255.255/0");
        this.testMaxHost("1.2.255.255/16", allPrefixesAreSubnets?"1.2.255.255":"1.2.255.255/16");
        this.testMaxHost("1:2:3:4:5:6:7:8", allPrefixesAreSubnets?"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff":"ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff/0");
        this.testMaxHost("1:2:ffff:ffff:ffff:ffff:ffff:ffff/64", allPrefixesAreSubnets?"1:2:ffff:ffff:ffff:ffff:ffff:ffff":"1:2:ffff:ffff:ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:2:3:4:5:6:7:8/64", allPrefixesAreSubnets?"1:2:3:4:ffff:ffff:ffff:ffff":"1:2:3:4:ffff:ffff:ffff:ffff/64");
        this.testMaxHost("1:2:3:4:5:6:7:8/128", allPrefixesAreSubnets?"1:2:3:4:5:6:7:8":"1:2:3:4:5:6:7:8/128");
        this.testZeroHost("1.2.3.4", allPrefixesAreSubnets?"0.0.0.0":"0.0.0.0/0");
        this.testZeroHost("1.2.0.0/16", allPrefixesAreSubnets?"1.2.0.0":"1.2.0.0/16");
        this.testZeroHost("1:2:3:4:5:6:7:8", allPrefixesAreSubnets?"::":"::/0");
        this.testZeroHost("1:2::/64", allPrefixesAreSubnets?"1:2::":"1:2::/64");
        this.testZeroHost("1:2:3:4:5:6:7:8/64", allPrefixesAreSubnets?"1:2:3:4::":"1:2:3:4::/64");
        this.testZeroHost("1:2:3:4:5:6:7:8/128", allPrefixesAreSubnets?"1:2:3:4:5:6:7:8":"1:2:3:4:5:6:7:8/128");
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.4", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.4/16", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.0.0/16", isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.4/0", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.3/31", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.4/31", isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("1.2.3.4/32", true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.0.0/16", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/0", 8, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/8", 8, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/31", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/32", 8, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4", 24, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/16", 24, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.0.0/16", 24, isAutoSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/0", 24, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/24", 24, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/31", 24, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("1.2.3.4/32", 24, false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:f:a:b", false, false);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:f:a:b/64", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d::/64", isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e::/64", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c::/64", isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:f:a:b/0", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:f:a:b/127", allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$boolean$boolean("a:b:c:d:e:f:a:b/128", true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d::/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e::/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c::/64", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/0", 0, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/127", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/128", 0, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d::/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e::/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c::/64", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/0", 63, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/127", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/128", 63, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b", 64, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/64", 64, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d::/64", 64, isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e::/64", 64, allPrefixesAreSubnets, allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c::/64", 64, isAutoSubnets, isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/0", 64, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/127", 64, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/128", 64, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b", 65, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/64", 65, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d::/64", 65, isAutoSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e::/64", 65, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c::/64", 65, isAutoSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/0", 65, allPrefixesAreSubnets, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/127", 65, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/128", 65, false, false);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b", 128, true, true);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/64", 128, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d::/64", 128, true, !isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e::/64", 128, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c::/64", 128, true, !isAutoSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/0", 128, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/127", 128, true, !allPrefixesAreSubnets);
        this.testPrefixBlocks$java_lang_String$int$boolean$boolean("a:b:c:d:e:f:a:b/128", 128, true, true);
        this.testSplitBytes$java_lang_String("1.2.3.4");
        this.testSplitBytes$java_lang_String("1.2.3.4/16");
        this.testSplitBytes$java_lang_String("1.2.3.4/0");
        this.testSplitBytes$java_lang_String("1.2.3.4/32");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc:bbbb");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc:bbbb/64");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc:bbbb/0");
        this.testSplitBytes$java_lang_String("ffff:2:3:4:eeee:dddd:cccc:bbbb/128");
        this.testByteExtension("255.255.255.255", [[0, 0, -1, -1, -1, -1], [0, -1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1], [-1]]);
        this.testByteExtension("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", [[0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], [-1, -1, -1], [-1, -1], [-1]]);
        this.testByteExtension("0.0.0.255", [[0, 0, 0, 0, 0, 0, 0, 0, 0, -1], [0, 0, 0, 0, 0, 0, 0, 0, -1], [0, 0, 0, 0, -1], [0, 0, 0, -1], [0, -1]]);
        this.testByteExtension("::ff", [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1], [0, -1]]);
        this.testByteExtension("0.0.0.127", [[0, 0, 0, 0, 0, 127], [0, 0, 0, 0, 127], [0, 0, 0, 127], [0, 127], [127]]);
        this.testByteExtension("::7f", [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127], [0, 0, 127], [0, 127], [127]]);
        this.testByteExtension("255.255.255.128", [[-1, -1, -1, -1, -1, -128], [-1, -1, -1, -1, -128], [0, 0, -1, -1, -1, -128], [0, -1, -1, -1, -128], [-1, -1, -1, -128], [-1, -128], [-128]]);
        this.testByteExtension("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ff80", [[0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128], [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128], [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128], [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128], [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128], [-1, -1, -128], [-1, -128], [-128]]);
        this.testByteExtension("ffff:ffff:ffff:ffff:ffff:ffff:ffff:8000", [[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128, 0], [0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128, 0], [0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128, 0], [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128, 0], [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -128, 0], [-1, -128, 0], [-128, 0]]);
        this.testByteExtension("1.2.3.4", [[1, 2, 3, 4], [0, 1, 2, 3, 4]]);
        this.testByteExtension("102:304:506:708:90a:b0c:d0e:f10", [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]]);
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 0, "1.2.3.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 1, "1.2.3.5");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", -1, "1.2.3.3");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", -4, "1.2.3.0");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", -5, "1.2.2.255");
        this.testIncrement$java_lang_String$long$java_lang_String("0.0.0.4", -5, null);
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 251, "1.2.3.255");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 252, "1.2.4.0");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 256, "1.2.4.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 256, "1.2.4.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 65536, "1.3.3.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 16777216, "2.2.3.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 4261412864, "255.2.3.4");
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 4278190080, null);
        this.testIncrement$java_lang_String$long$java_lang_String("1.2.3.4", 4278058236, null);
        this.testIncrement$java_lang_String$long$java_lang_String("255.0.0.4", -4278190084, "0.0.0.0");
        this.testIncrement$java_lang_String$long$java_lang_String("255.0.0.4", -4278190085, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:f000::0", 1, "ffff:ffff:ffff:ffff:f000::1");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:f000::0", -1, "ffff:ffff:ffff:ffff:efff:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:8000::", Number.MIN_VALUE, "ffff:ffff:ffff:ffff::");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:7fff:ffff:ffff:ffff", Number.MIN_VALUE, "ffff:ffff:ffff:fffe:ffff:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:7fff:ffff:ffff:fffe", Number.MIN_VALUE, "ffff:ffff:ffff:fffe:ffff:ffff:ffff:fffe");
        this.testIncrement$java_lang_String$long$java_lang_String("::8000:0:0:0", Number.MIN_VALUE, "::");
        this.testIncrement$java_lang_String$long$java_lang_String("::7fff:ffff:ffff:ffff", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("::7fff:ffff:ffff:ffff", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("::7fff:ffff:ffff:fffe", Number.MIN_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:8000::0", Number.MAX_VALUE, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("ffff:ffff:ffff:ffff:8000::1", Number.MAX_VALUE, null);
        this.testIncrement$java_lang_String$long$java_lang_String("::1", 1, "::2");
        this.testIncrement$java_lang_String$long$java_lang_String("::1", 0, "::1");
        this.testIncrement$java_lang_String$long$java_lang_String("::1", -1, "::");
        this.testIncrement$java_lang_String$long$java_lang_String("::1", -2, null);
        this.testIncrement$java_lang_String$long$java_lang_String("::2", 1, "::3");
        this.testIncrement$java_lang_String$long$java_lang_String("::2", -1, "::1");
        this.testIncrement$java_lang_String$long$java_lang_String("::2", -2, "::");
        this.testIncrement$java_lang_String$long$java_lang_String("::2", -3, null);
        this.testIncrement$java_lang_String$long$java_lang_String("1::1", 0, "1::1");
        this.testIncrement$java_lang_String$long$java_lang_String("1::1", 1, "1::2");
        this.testIncrement$java_lang_String$long$java_lang_String("1::1", -1, "1::");
        this.testIncrement$java_lang_String$long$java_lang_String("1::1", -2, "::ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("1::2", 1, "1::3");
        this.testIncrement$java_lang_String$long$java_lang_String("1::2", -1, "1::1");
        this.testIncrement$java_lang_String$long$java_lang_String("1::2", -2, "1::");
        this.testIncrement$java_lang_String$long$java_lang_String("1::2", -3, "::ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("::fffe", 2, "::1:0");
        this.testIncrement$java_lang_String$long$java_lang_String("::ffff", 2, "::1:1");
        this.testIncrement$java_lang_String$long$java_lang_String("::1:ffff", 2, "::2:1");
        this.testIncrement$java_lang_String$long$java_lang_String("::1:ffff", -2, "::1:fffd");
        this.testIncrement$java_lang_String$long$java_lang_String("::1:ffff", -65536, "::ffff");
        this.testIncrement$java_lang_String$long$java_lang_String("::1:ffff", -65537, "::fffe");
        this.testSpanAndMerge("1.2.3.0", "1.2.3.1", 1);
        this.testSpanAndMerge("1.2.3.4", "1.2.5.8", 9);
        this.testSpanAndMerge("a:b:c:d:1::", "a:b:c:d:10::", 5);
        this.testSpanAndMerge("a:b:c:d:1::/80", "a:b:c:d:10::", 5);
        this.testSpanAndMerge("a:b:c:d:2::", "a:b:c:d:10::", 4);
        this.testSpanAndMerge("a:b:c:d:2::", "a:b:c:d:10::/76", 4);
        this.testSpanAndMerge("a:b:c:d:2::/79", "a:b:c:d:10::/76", 4);
        this.testCustomNetwork$inet_ipaddr_AddressNetwork_PrefixConfiguration(TestBase.prefixConfiguration);
    }
}
IPAddressTest["__class"] = "inet.ipaddr.test.IPAddressTest";


export namespace IPAddressTest {

    export class TestSQLTranslator extends MySQLTranslator {
        networkStringMap : any = <any>({});

        currentConditions : IPAddressTest.MatchConditions;

        test(expectedConditions : any) : boolean {
            return this.networkStringMap.equals(expectedConditions);
        }

        expected(column : string, expectedConditions : any, isIPv4 : boolean) : string {
            let separator : string = isIPv4?IPv4Address.SEGMENT_SEPARATOR:IPv6Address.SEGMENT_SEPARATOR;
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            if(/* size */Object.keys(expectedConditions).length > 1) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
            }
            let set : Array<Map.Entry<string, IPAddressTest.MatchConditions>> = /* entrySet */(o => { let s = []; for (let e in o) s.push({ k: e, v: o[e], getKey: function() { return this.k }, getValue: function() { return this.v } }); return s; })(expectedConditions);
            let notFirstString : boolean = false;
            for(let index158=0; index158 < set.length; index158++) {
                let entry = set[index158];
                {
                    if(notFirstString) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>" OR "); return sb; })(builder);
                    }
                    notFirstString = true;
                    let notFirstCond : boolean = false;
                    let conds : IPAddressTest.MatchConditions = entry.getValue();
                    if(conds.getCount() > 1) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
                    }
                    for(let index159=0; index159 < conds.matches.length; index159++) {
                        let match = conds.matches[index159];
                        {
                            if(notFirstCond) {
                                /* append */(sb => { sb.str = sb.str.concat(<any>" AND "); return sb; })(builder);
                            }
                            notFirstCond = true;
                            /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(this.matchString(/* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder), column, match));
                        }
                    }
                    for(let index160=0; index160 < conds.subMatches.length; index160++) {
                        let match = conds.subMatches[index160];
                        {
                            if(notFirstCond) {
                                /* append */(sb => { sb.str = sb.str.concat(<any>" AND "); return sb; })(builder);
                            }
                            notFirstCond = true;
                            /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(this.matchSubString(/* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder), column, separator, match.separatorCount, match.match));
                        }
                    }
                    for(let index161=0; index161 < conds.separatorCountMatches.length; index161++) {
                        let match = conds.separatorCountMatches[index161];
                        {
                            if(notFirstCond) {
                                /* append */(sb => { sb.str = sb.str.concat(<any>" AND "); return sb; })(builder);
                            }
                            notFirstCond = true;
                            /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(this.matchSeparatorCount(/* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder), column, separator, match));
                        }
                    }
                    for(let index162=0; index162 < conds.separatorBoundMatches.length; index162++) {
                        let match = conds.separatorBoundMatches[index162];
                        {
                            if(notFirstCond) {
                                /* append */(sb => { sb.str = sb.str.concat(<any>" AND "); return sb; })(builder);
                            }
                            notFirstCond = true;
                            /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(this.boundSeparatorCount(/* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder), column, separator, match));
                        }
                    }
                    if(conds.getCount() > 1) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
                    }
                }
            }
            if(/* size */Object.keys(expectedConditions).length > 1) {
                /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
            }
            return /* toString */builder.str;
        }

        /**
         * 
         * @param {string} networkString
         */
        public setNetwork(networkString : string) {
            this.currentConditions = new IPAddressTest.MatchConditions();
            /* put */(this.networkStringMap[networkString] = this.currentConditions);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {string} expression
         * @param {string} match
         * @return {{ str: string }}
         */
        public matchString(builder : { str: string }, expression : string, match : string) : { str: string } {
            /* add */(this.currentConditions.matches.push(match)>0);
            return super.matchString(builder, expression, match);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {string} expression
         * @param {string} separator
         * @param {number} separatorCount
         * @param {string} match
         * @return {{ str: string }}
         */
        public matchSubString(builder : { str: string }, expression : string, separator : string, separatorCount : number, match : string) : { str: string } {
            /* add */(this.currentConditions.subMatches.push(new IPAddressTest.SubMatch(separatorCount, match))>0);
            return super.matchSubString(builder, expression, separator, separatorCount, match);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {string} expression
         * @param {string} separator
         * @param {number} separatorCount
         * @return {{ str: string }}
         */
        public matchSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string } {
            /* add */(this.currentConditions.separatorCountMatches.push(separatorCount)>0);
            return super.matchSeparatorCount(builder, expression, separator, separatorCount);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {string} expression
         * @param {string} separator
         * @param {number} separatorCount
         * @return {{ str: string }}
         */
        public boundSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string } {
            /* add */(this.currentConditions.separatorBoundMatches.push(separatorCount)>0);
            return super.boundSeparatorCount(builder, expression, separator, separatorCount);
        }

        constructor() {
            super();
            if(this.currentConditions===undefined) this.currentConditions = null;
        }
    }
    TestSQLTranslator["__class"] = "inet.ipaddr.test.IPAddressTest.TestSQLTranslator";
    TestSQLTranslator["__interfaces"] = ["inet.ipaddr.format.util.sql.IPAddressSQLTranslator"];



    export class ExpectedMatch {
        networkString : string;

        conditions : IPAddressTest.MatchConditions;

        constructor(networkString : string, conditions : IPAddressTest.MatchConditions) {
            if(this.networkString===undefined) this.networkString = null;
            if(this.conditions===undefined) this.conditions = null;
            this.networkString = networkString;
            this.conditions = conditions;
        }
    }
    ExpectedMatch["__class"] = "inet.ipaddr.test.IPAddressTest.ExpectedMatch";


    export class SubMatch {
        separatorCount : number;

        match : string;

        constructor(separatorCount : number, match : string) {
            if(this.separatorCount===undefined) this.separatorCount = 0;
            if(this.match===undefined) this.match = null;
            this.separatorCount = separatorCount;
            this.match = match;
        }

        /**
         * 
         * @param {*} other
         * @return {boolean}
         */
        public equals(other : any) : boolean {
            if(other != null && other instanceof <any>IPAddressTest.SubMatch) {
                let otherConds : IPAddressTest.SubMatch = <IPAddressTest.SubMatch>other;
                return Objects.equals(this.match, otherConds.match) && this.separatorCount === otherConds.separatorCount;
            }
            return false;
        }
    }
    SubMatch["__class"] = "inet.ipaddr.test.IPAddressTest.SubMatch";


    export class MatchConditions {
        matches : Array<string> = <any>([]);

        subMatches : Array<IPAddressTest.SubMatch> = <any>([]);

        separatorCountMatches : Array<number> = <any>([]);

        separatorBoundMatches : Array<number> = <any>([]);

        public constructor(match? : any, subMatch? : any, separatorCountMatch? : any, separatorBoundMatch? : any) {
            if(((typeof match === 'string') || match === null) && ((subMatch != null && subMatch instanceof <any>IPAddressTest.SubMatch) || subMatch === null) && ((typeof separatorCountMatch === 'number') || separatorCountMatch === null) && ((typeof separatorBoundMatch === 'number') || separatorBoundMatch === null)) {
                let __args = Array.prototype.slice.call(arguments);
                this.matches = <any>([]);
                this.subMatches = <any>([]);
                this.separatorCountMatches = <any>([]);
                this.separatorBoundMatches = <any>([]);
                (() => {
                    if(match != null) /* add */(this.matches.push(match)>0);
                    if(subMatch != null) /* add */(this.subMatches.push(subMatch)>0);
                    if(separatorCountMatch != null) /* add */(this.separatorCountMatches.push(separatorCountMatch)>0);
                    if(separatorBoundMatch != null) /* add */(this.separatorBoundMatches.push(separatorBoundMatch)>0);
                })();
            } else if(((match != null && match instanceof <any>IPAddressTest.SubMatch) || match === null) && ((typeof subMatch === 'number') || subMatch === null) && ((typeof separatorCountMatch === 'number') || separatorCountMatch === null) && separatorBoundMatch === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let subMatch : any = __args[0];
                let separatorCountMatch : any = __args[1];
                let separatorBoundMatch : any = __args[2];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let match : any = null;
                    this.matches = <any>([]);
                    this.subMatches = <any>([]);
                    this.separatorCountMatches = <any>([]);
                    this.separatorBoundMatches = <any>([]);
                    (() => {
                        if(match != null) /* add */(this.matches.push(match)>0);
                        if(subMatch != null) /* add */(this.subMatches.push(subMatch)>0);
                        if(separatorCountMatch != null) /* add */(this.separatorCountMatches.push(separatorCountMatch)>0);
                        if(separatorBoundMatch != null) /* add */(this.separatorBoundMatches.push(separatorBoundMatch)>0);
                    })();
                }
            } else if(((typeof match === 'string') || match === null) && subMatch === undefined && separatorCountMatch === undefined && separatorBoundMatch === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let subMatch : any = null;
                    let separatorCountMatch : any = null;
                    let separatorBoundMatch : any = null;
                    this.matches = <any>([]);
                    this.subMatches = <any>([]);
                    this.separatorCountMatches = <any>([]);
                    this.separatorBoundMatches = <any>([]);
                    (() => {
                        if(match != null) /* add */(this.matches.push(match)>0);
                        if(subMatch != null) /* add */(this.subMatches.push(subMatch)>0);
                        if(separatorCountMatch != null) /* add */(this.separatorCountMatches.push(separatorCountMatch)>0);
                        if(separatorBoundMatch != null) /* add */(this.separatorBoundMatches.push(separatorBoundMatch)>0);
                    })();
                }
            } else if(((match != null && match instanceof <any>IPAddressTest.SubMatch) || match === null) && subMatch === undefined && separatorCountMatch === undefined && separatorBoundMatch === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let subMatch : any = __args[0];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let match : any = null;
                    let separatorCountMatch : any = null;
                    let separatorBoundMatch : any = null;
                    this.matches = <any>([]);
                    this.subMatches = <any>([]);
                    this.separatorCountMatches = <any>([]);
                    this.separatorBoundMatches = <any>([]);
                    (() => {
                        if(match != null) /* add */(this.matches.push(match)>0);
                        if(subMatch != null) /* add */(this.subMatches.push(subMatch)>0);
                        if(separatorCountMatch != null) /* add */(this.separatorCountMatches.push(separatorCountMatch)>0);
                        if(separatorBoundMatch != null) /* add */(this.separatorBoundMatches.push(separatorBoundMatch)>0);
                    })();
                }
            } else if(match === undefined && subMatch === undefined && separatorCountMatch === undefined && separatorBoundMatch === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                this.matches = <any>([]);
                this.subMatches = <any>([]);
                this.separatorCountMatches = <any>([]);
                this.separatorBoundMatches = <any>([]);
            } else throw new Error('invalid overload');
        }

        getCount() : number {
            return /* size */(<number>this.matches.length) + /* size */(<number>this.subMatches.length) + /* size */(<number>this.separatorCountMatches.length) + /* size */(<number>this.separatorBoundMatches.length);
        }

        /**
         * 
         * @param {*} other
         * @return {boolean}
         */
        public equals(other : any) : boolean {
            if(other != null && other instanceof <any>IPAddressTest.MatchConditions) {
                let otherConds : IPAddressTest.MatchConditions = <IPAddressTest.MatchConditions>other;
                return Objects.equals(this.matches, otherConds.matches) && Objects.equals(this.subMatches, otherConds.subMatches) && Objects.equals(this.separatorCountMatches, otherConds.separatorCountMatches) && Objects.equals(this.separatorBoundMatches, otherConds.separatorBoundMatches);
            }
            return false;
        }
    }
    MatchConditions["__class"] = "inet.ipaddr.test.IPAddressTest.MatchConditions";


    export class MyIPv6Address extends IPv6Address {
        public constructor(bytes? : any, prefixLength? : any) {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(bytes, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>IPAddressTest.MyIPv6AddressSection) || bytes === null) && ((prefixLength != null && (prefixLength["__interfaces"] != null && prefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefixLength.constructor != null && prefixLength.constructor["__interfaces"] != null && prefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefixLength === "string")) || prefixLength === null)) {
                let __args = Array.prototype.slice.call(arguments);
                let section : any = __args[0];
                let zone : any = __args[1];
                super(section, zone);
            } else if(((bytes != null && bytes instanceof <any>IPAddressTest.MyIPv6AddressSection) || bytes === null) && prefixLength === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let section : any = __args[0];
                super(section);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPv6AddressNetwork}
         */
        public getNetwork() : IPv6AddressNetwork {
            return IPAddressTest.myIPv6Network_$LI$();
        }
    }
    MyIPv6Address["__class"] = "inet.ipaddr.test.IPAddressTest.MyIPv6Address";
    MyIPv6Address["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];



    export class MyIPv6AddressSection extends IPv6AddressSection {
        public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, prefixLength? : any) {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(bytes, byteStartIndex, byteEndIndex, segmentCount, prefixLength, true, false);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && prefixLength === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let segments : any = __args[0];
                let startIndex : any = __args[1];
                let cloneSegments : any = __args[2];
                super(segments, startIndex, cloneSegments);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefixLength === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let prefixLength : any = __args[1];
                super(bytes, prefixLength);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefixLength === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let segments : any = __args[0];
                let prefixLength : any = __args[1];
                super(segments, prefixLength);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPv6AddressNetwork}
         */
        public getNetwork() : IPv6AddressNetwork {
            return IPAddressTest.myIPv6Network_$LI$();
        }
    }
    MyIPv6AddressSection["__class"] = "inet.ipaddr.test.IPAddressTest.MyIPv6AddressSection";
    MyIPv6AddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



    export class MyIPv6AddressSegment extends IPv6AddressSegment {
        public constructor(lower? : any, upper? : any, segmentPrefixLength? : any) {
            if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(lower, upper, segmentPrefixLength);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let segmentPrefixLength : any = __args[1];
                super(lower, segmentPrefixLength);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPv6AddressNetwork}
         */
        public getNetwork() : IPv6AddressNetwork {
            return IPAddressTest.myIPv6Network_$LI$();
        }
    }
    MyIPv6AddressSegment["__class"] = "inet.ipaddr.test.IPAddressTest.MyIPv6AddressSegment";
    MyIPv6AddressSegment["__interfaces"] = ["inet.ipaddr.AddressSegment","inet.ipaddr.AddressComponent","inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];



    export class IPAddressTest$0 implements Address.SegmentValueProvider {
        public __parent: any;
        public getValue(segmentIndex : number) : number {
            if(segmentIndex < this.prefSeg) {
                return this.segs[segmentIndex].getLowerSegmentValue();
            } else if(segmentIndex === this.prefSeg) {
                return this.origSeg.getLowerSegmentValue() & this.mask;
            } else {
                return 0;
            }
        }

        constructor(__parent: any, private prefSeg: any, private segs: any, private origSeg: any, private mask: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$0["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$1 implements Address.SegmentValueProvider {
        public __parent: any;
        public getValue(segmentIndex : number) : number {
            if(segmentIndex < this.prefSeg) {
                return this.segs[segmentIndex].getUpperSegmentValue();
            } else if(segmentIndex === this.prefSeg) {
                return this.origSeg.getUpperSegmentValue() & this.mask;
            } else {
                return this.maxValue;
            }
        }

        constructor(__parent: any, private prefSeg: any, private segs: any, private origSeg: any, private mask: any, private maxValue: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$1["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$2 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 256;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$2["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$3 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return -1;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$3["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$4 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 255;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$4["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$5 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 65536;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$5["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$6 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return -1;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$6["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$7 implements Address.SegmentValueProvider {
        public __parent: any;
        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getValue(segmentIndex : number) : number {
            return 65535;
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    IPAddressTest$7["__interfaces"] = ["inet.ipaddr.Address.SegmentValueProvider"];



    export class IPAddressTest$8 extends IPv6AddressNetwork {
        /**
         * 
         * @return {AddressNetwork.PrefixConfiguration}
         */
        public getPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
            return AddressNetwork.PrefixConfiguration.ALL_PREFIXED_ADDRESSES_ARE_SUBNETS;
        }

        /**
         * 
         * @return {IPv6AddressNetwork.IPv6AddressCreator}
         */
        createAddressCreator() : IPv6AddressNetwork.IPv6AddressCreator {
            return new IPAddressTest$8.IPAddressTest$8$0(this, this);
        }

        constructor() {
            super();
        }
    }
    IPAddressTest$8["__interfaces"] = ["java.io.Serializable"];



    export namespace IPAddressTest$8 {

        export class IPAddressTest$8$0 extends IPv6AddressNetwork.IPv6AddressCreator {
            public __parent: any;
            public createSection$byte_A$java_lang_Integer(bytes : number[], prefix : number) : IPv6AddressSection {
                return new IPAddressTest.MyIPv6AddressSection(bytes, prefix);
            }

            public createSection$byte_A$int$int$int$java_lang_Integer(bytes : number[], byteStartIndex : number, byteEndIndex : number, segmentCount : number, prefix : number) : IPv6AddressSection {
                return new IPAddressTest.MyIPv6AddressSection(bytes, byteStartIndex, byteEndIndex, segmentCount, prefix);
            }

            /**
             * 
             * @param {Array} bytes
             * @param {number} byteStartIndex
             * @param {number} byteEndIndex
             * @param {number} segmentCount
             * @param {number} prefix
             * @return {IPv6AddressSection}
             */
            public createSection(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, prefix? : any) : any {
                if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null)) {
                    return <any>this.createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined) {
                    return <any>this.createSection$byte_A$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined) {
                    return <any>this.createSection$byte_A$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$byte_A$java_lang_Integer(bytes, byteStartIndex);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(bytes, byteStartIndex);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$byte_A$java_lang_Integer(bytes, byteStartIndex);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, byteStartIndex);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A(bytes);
                } else if(((bytes != null && bytes instanceof <any>MACAddress) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_mac_MACAddress(bytes);
                } else if(((bytes != null && bytes instanceof <any>MACAddressSection) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_mac_MACAddressSection(bytes);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                    return <any>this.createSection$inet_ipaddr_IPAddressSegment_A(bytes);
                } else throw new Error('invalid overload');
            }

            public createSegment$int$java_lang_Integer(value : number, segmentPrefixLength : number) : IPv6AddressSegment {
                return new IPAddressTest.MyIPv6AddressSegment(value, segmentPrefixLength);
            }

            public createSegment$int$int$java_lang_Integer(lower : number, upper : number, segmentPrefixLength : number) : IPv6AddressSegment {
                return new IPAddressTest.MyIPv6AddressSegment(lower, upper, segmentPrefixLength);
            }

            /**
             * 
             * @param {number} lower
             * @param {number} upper
             * @param {number} segmentPrefixLength
             * @return {IPv6AddressSegment}
             */
            public createSegment(lower? : any, upper? : any, segmentPrefixLength? : any) : any {
                if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                    return <any>this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                    super.createSegment(lower, upper, segmentPrefixLength);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
                    return <any>this.createSegment$int$java_lang_Integer(lower, upper);
                } else if(((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
                    return <any>this.createSegment$int(lower);
                } else throw new Error('invalid overload');
            }

            /**
             * 
             * @param {number} lower
             * @param {number} upper
             * @param {number} segmentPrefixLength
             * @param {*} addressStr
             * @param {number} originalLower
             * @param {number} originalUpper
             * @param {boolean} isStandardString
             * @param {boolean} isStandardRangeString
             * @param {number} lowerStringStartIndex
             * @param {number} lowerStringEndIndex
             * @param {number} upperStringEndIndex
             * @return {IPAddressSegment}
             */
            public createSegmentInternal(lower? : any, upper? : any, segmentPrefixLength? : any, addressStr? : any, originalLower? : any, originalUpper? : any, isStandardString? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, lowerStringEndIndex? : any, upperStringEndIndex? : any) : any {
                if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                    super.createSegmentInternal(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
                    super.createSegmentInternal(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                    return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                    return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
                } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
                    return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
                } else throw new Error('invalid overload');
            }

            createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(value : number, segmentPrefixLength : number, addressStr : any, originalVal : number, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number) : IPv6AddressSegment {
                return new IPAddressTest.MyIPv6AddressSegment(value, segmentPrefixLength);
            }

            /**
             * 
             * @param {Array} segments
             * @param {number} prefix
             * @param {boolean} singleOnly
             * @return {IPv6AddressSection}
             */
            public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
                if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>IPv6AddressSegment))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                    super.createPrefixedSectionInternal(segments, prefix, singleOnly);
                } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                    return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
                } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                    return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
                } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>IPv6AddressSegment))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createPrefixedSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments, prefix);
                } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix);
                } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
                } else throw new Error('invalid overload');
            }

            createPrefixedSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments : IPv6AddressSegment[], prefix : number) : IPv6AddressSection {
                return new IPAddressTest.MyIPv6AddressSection(segments, prefix);
            }

            /**
             * 
             * @param {Array} bytes
             * @param {number} segmentCount
             * @param {number} prefix
             * @param {boolean} singleOnly
             * @return {IPv6AddressSection}
             */
            public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
                if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                    super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                    super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((segmentCount != null && segmentCount instanceof <any>IPv4AddressSection) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$inet_ipaddr_ipv4_IPv4AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createSectionInternal$byte_A$int$java_lang_Integer(bytes, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((segmentCount != null && segmentCount instanceof <any>IPv4AddressSection) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$inet_ipaddr_ipv4_IPv4AddressSection(bytes, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$byte_A$java_lang_Integer(bytes, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$int(bytes, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(bytes);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(bytes);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                    return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
                } else throw new Error('invalid overload');
            }

            createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(segments : IPv6AddressSegment[]) : IPv6AddressSection {
                return new IPAddressTest.MyIPv6AddressSection(segments, 0, false);
            }

            public createAddressInternal(bytes? : any, prefix? : any, zone? : any, fromHost? : any) : any {
                if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((fromHost != null && fromHost instanceof <any>HostName) || fromHost === null)) {
                    super.createAddressInternal(bytes, prefix, zone, fromHost);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof fromHost === 'number') || fromHost === null)) {
                    super.createAddressInternal(bytes, prefix, zone, fromHost);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && zone instanceof <any>HostName) || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefix, zone);
                } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && ((typeof zone === 'number') || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(bytes, prefix, zone);
                } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
                } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$byte_A$java_lang_Integer(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
                } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
                } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(bytes);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A(bytes);
                } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                    return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(bytes);
                } else throw new Error('invalid overload');
            }

            createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_HostIdentifierString(section : IPv6AddressSection, from : HostIdentifierString) : IPv6Address {
                return new IPAddressTest.MyIPv6Address(<IPAddressTest.MyIPv6AddressSection>section);
            }

            createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(section : IPv6AddressSection, zone : any, from : HostIdentifierString) : IPv6Address {
                return new IPAddressTest.MyIPv6Address(<IPAddressTest.MyIPv6AddressSection>section, zone);
            }

            constructor(__parent: any, __arg0: any) {
                super(__arg0);
                this.__parent = __parent;
            }
        }
        IPAddressTest$8$0["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];


    }

}




IPAddressTest.myIPv6Network_$LI$();
