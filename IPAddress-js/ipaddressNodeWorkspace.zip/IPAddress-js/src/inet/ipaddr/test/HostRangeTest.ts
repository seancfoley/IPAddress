/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostName } from '../HostName';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { HostTest } from './HostTest';
import { AddressStringParameters } from '../AddressStringParameters';
import { AddressCreator } from './AddressCreator';
import { TestBase } from './TestBase';
import { AddressNetwork } from '../AddressNetwork';

export class HostRangeTest extends HostTest {
    static HOST_ONLY_OPTIONS : HostNameParameters; public static HOST_ONLY_OPTIONS_$LI$() : HostNameParameters { if(HostRangeTest.HOST_ONLY_OPTIONS == null) HostRangeTest.HOST_ONLY_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toBuilder().allowIPAddress(false).toParams(); return HostRangeTest.HOST_ONLY_OPTIONS; };

    static HOST_WILDCARD_OPTIONS : HostNameParameters; public static HOST_WILDCARD_OPTIONS_$LI$() : HostNameParameters { if(HostRangeTest.HOST_WILDCARD_OPTIONS == null) HostRangeTest.HOST_WILDCARD_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().allowAll(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).getParentBuilder().toParams(); return HostRangeTest.HOST_WILDCARD_OPTIONS; };

    static HOST_WILDCARD_AND_RANGE_OPTIONS : HostNameParameters; public static HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$() : HostNameParameters { if(HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS == null) HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS = HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).getParentBuilder().toParams(); return HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS; };

    static HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS : HostNameParameters; public static HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS_$LI$() : HostNameParameters { if(HostRangeTest.HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS == null) HostRangeTest.HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS = HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).allow_inet_aton(true).getParentBuilder().toParams(); return HostRangeTest.HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS; };

    static ADDRESS_WILDCARD_OPTIONS : IPAddressStringParameters; public static ADDRESS_WILDCARD_OPTIONS_$LI$() : IPAddressStringParameters { if(HostRangeTest.ADDRESS_WILDCARD_OPTIONS == null) HostRangeTest.ADDRESS_WILDCARD_OPTIONS = TestBase.ADDRESS_OPTIONS_$LI$().toBuilder().allowAll(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).toParams(); return HostRangeTest.ADDRESS_WILDCARD_OPTIONS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    /**
     * 
     * @param {string} x
     * @return {HostName}
     */
    createHost_inet_aton(x : string) : HostName {
        let key : TestBase.HostKey = new TestBase.HostKey(x, TestBase.HOST_INET_ATON_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(key);
    }

    public createHost(x? : any, options? : any) : any {
        if(((typeof x === 'string') || x === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            super.createHost(x, options);
        } else if(((typeof x === 'string') || x === null) && options === undefined) {
            return <any>this.createHost$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.HostKey) || x === null) && options === undefined) {
            return <any>this.createHost$inet_ipaddr_test_TestBase_HostKey(x);
        } else throw new Error('invalid overload');
    }

    createHost$java_lang_String(x : string) : HostName {
        let key : TestBase.HostKey = new TestBase.HostKey(x, HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$());
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(key);
    }

    public testMatches(matches? : any, host1? : any, host2? : any, options? : any) : any {
        if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            super.testMatches(matches, host1, host2, options);
        } else if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && options === undefined) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String(matches, host1, host2);
        } else throw new Error('invalid overload');
    }

    testMatches$boolean$java_lang_String$java_lang_String(matches : boolean, host1 : string, host2 : string) {
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(matches, host1, host2, HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$());
    }

    public createAddress(x? : any, opts? : any) : any {
        if(((typeof x === 'string') || x === null) && ((opts != null && opts instanceof <any>IPAddressStringParameters) || opts === null)) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, opts);
        } else if(((typeof x === 'string') || x === null) && opts === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && opts === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && opts === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'number') || x === null) && opts === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        let key : TestBase.IPAddressStringKey = new TestBase.IPAddressStringKey(x, HostRangeTest.ADDRESS_WILDCARD_OPTIONS_$LI$());
        return this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(key);
    }

    /*private*/ testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(h : HostName, hostLabelCount : number, addressLabelCount : number, isValidHost : boolean, isValidAddress : boolean, normalizedHostString : string, normalizedAddressString : string) {
        if(h.isValid() !== isValidHost) {
            this.addFailure(new TestBase.Failure("unexpected invalid host", h));
        } else if(h.getNormalizedLabels().length !== (isValidAddress?addressLabelCount:(isValidHost?hostLabelCount:1))) {
            this.addFailure(new TestBase.Failure("labels length is " + h.getNormalizedLabels().length + " expected " + (isValidAddress?addressLabelCount:(isValidHost?hostLabelCount:1)), h));
        } else {
            let addr : IPAddress = h.asAddress();
            if(isValidAddress !== h.isAddress()) {
                this.addFailure(new TestBase.Failure("not address " + addr, h));
            } else if(isValidAddress !== (addr != null)) {
                this.addFailure(new TestBase.Failure("addr is " + addr, h));
            } else if(isValidAddress && !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(addr.toNormalizedString(),normalizedAddressString))) {
                this.addFailure(new TestBase.Failure("addr string is " + addr.toNormalizedString() + " expected " + normalizedAddressString, h));
            } else {
                let nhString : string = h.toNormalizedString();
                let expected : string;
                if(h.isAddress() && addr.isIPv6()) {
                    expected = isValidHost?normalizedHostString:h.toString();
                } else {
                    expected = isValidAddress?normalizedAddressString:(isValidHost?normalizedHostString:h.toString());
                }
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(nhString,expected))) {
                    this.addFailure(new TestBase.Failure("host string is " + nhString + " expected " + expected, h));
                }
            }
        }
        this.incrementTestCount();
    }

    /*private*/ testHostOrAddress_inet_aton(x : string, hostLabelCount : number, addressLabelCount : number, normalizedHostString : string, normalizedAddressString : string) {
        this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, hostLabelCount, addressLabelCount, true, false, false, true, normalizedHostString, normalizedAddressString);
    }

    /*private*/ testHostOrRangeAddress(x : string, labelCount : number, normalizedHostString : string, normalizedAddressString : string) {
        this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, labelCount, labelCount, true, false, true, true, normalizedHostString, normalizedAddressString);
    }

    /*private*/ testHostOrWildcardAddress(x : string, labelCount : number, normalizedHostString : string, normalizedAddressString : string) {
        this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, labelCount, labelCount, true, true, true, true, normalizedHostString, normalizedAddressString);
    }

    /*private*/ testAddress(x : string, labelCount : number, normalizedHostString : string, normalizedAddressString : string) {
        this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, labelCount, labelCount, false, true, true, true, normalizedHostString, normalizedAddressString);
    }

    /*private*/ testHostOnly(x : string, labelCount : number, normalizedHostString : string, normalizedAddressString : string) {
        this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, labelCount, labelCount, true, false, false, false, normalizedHostString, normalizedAddressString);
    }

    public testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x : string, hostLabelCount : number, addressLabelCount : number, isHostName : boolean, isAddressNotRanged : boolean, isRangeAddress : boolean, is_inet_aton_RangeAddress : boolean, normalizedHostString : string, normalizedAddressString : string) {
        let h : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, HostRangeTest.HOST_ONLY_OPTIONS_$LI$());
        this.testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(h, hostLabelCount, addressLabelCount, isHostName, false, normalizedHostString, normalizedAddressString);
        let isAddress : boolean = isAddressNotRanged;
        h = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$());
        this.testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(h, hostLabelCount, addressLabelCount, isHostName || isAddress, isAddress, normalizedHostString, normalizedAddressString);
        isAddress = isAddressNotRanged || isRangeAddress;
        h = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        this.testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(h, hostLabelCount, addressLabelCount, isHostName || isAddress, isAddress, normalizedHostString, normalizedAddressString);
        isAddress = isAddressNotRanged || isRangeAddress || is_inet_aton_RangeAddress;
        h = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, HostRangeTest.HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS_$LI$());
        this.testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(h, hostLabelCount, addressLabelCount, isHostName || isAddress, isAddress, normalizedHostString, normalizedAddressString);
    }

    public testHostAndAddress(x? : any, hostLabelCount? : any, addressLabelCount? : any, isHostName? : any, isAddressNotRanged? : any, isRangeAddress? : any, is_inet_aton_RangeAddress? : any, normalizedHostString? : any, normalizedAddressString? : any) : any {
        if(((typeof x === 'string') || x === null) && ((typeof hostLabelCount === 'number') || hostLabelCount === null) && ((typeof addressLabelCount === 'number') || addressLabelCount === null) && ((typeof isHostName === 'boolean') || isHostName === null) && ((typeof isAddressNotRanged === 'boolean') || isAddressNotRanged === null) && ((typeof isRangeAddress === 'boolean') || isRangeAddress === null) && ((typeof is_inet_aton_RangeAddress === 'boolean') || is_inet_aton_RangeAddress === null) && ((typeof normalizedHostString === 'string') || normalizedHostString === null) && ((typeof normalizedAddressString === 'string') || normalizedAddressString === null)) {
            return <any>this.testHostAndAddress$java_lang_String$int$int$boolean$boolean$boolean$boolean$java_lang_String$java_lang_String(x, hostLabelCount, addressLabelCount, isHostName, isAddressNotRanged, isRangeAddress, is_inet_aton_RangeAddress, normalizedHostString, normalizedAddressString);
        } else if(((x != null && x instanceof <any>HostName) || x === null) && ((typeof hostLabelCount === 'number') || hostLabelCount === null) && ((typeof addressLabelCount === 'number') || addressLabelCount === null) && ((typeof isHostName === 'boolean') || isHostName === null) && ((typeof isAddressNotRanged === 'boolean') || isAddressNotRanged === null) && ((typeof isRangeAddress === 'string') || isRangeAddress === null) && ((typeof is_inet_aton_RangeAddress === 'string') || is_inet_aton_RangeAddress === null) && normalizedHostString === undefined && normalizedAddressString === undefined) {
            return <any>this.testHostAndAddress$inet_ipaddr_HostName$int$int$boolean$boolean$java_lang_String$java_lang_String(x, hostLabelCount, addressLabelCount, isHostName, isAddressNotRanged, isRangeAddress, is_inet_aton_RangeAddress);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     */
    runTest() {
        this.testResolved$java_lang_String$java_lang_String("a::b:*:d:1.2.*%x", "a::b:*:d:1.2.*%x");
        this.testResolved$java_lang_String$java_lang_String("[a::b:*:d:1.2.*%x]", "a::b:*:d:1.2.*%x");
        this.testResolved$java_lang_String$java_lang_String("[a::*:c:d:1.*.3.4]", "a::*:c:d:1.*.3.4");
        this.testResolved$java_lang_String$java_lang_String("2001:0000:1234:0000:*:C1C0:ABCD:0876%x", "2001:0:1234:0:*:c1c0:abcd:876%x");
        this.testResolved$java_lang_String$java_lang_String("[2001:*:1234:0000:0000:C1C0:ABCD:0876%x]", "2001:*:1234::C1C0:abcd:876%x");
        this.testResolved$java_lang_String$java_lang_String("[2001:0000:*:0000:0000:C1C0:ABCD:0876]", "2001:0:*::C1C0:abcd:876");
        this.testResolved$java_lang_String$java_lang_String("2001:0000:*:0000:0000:C1C0:ABCD:0876", "2001:0:*::C1C0:abcd:876");
        this.testResolved$java_lang_String$java_lang_String("1.2.*.04", "1.2.*.4");
        this.testResolved$java_lang_String$java_lang_String("1.*.0-255.3", "1.*.*.3");
        this.testResolved$java_lang_String$java_lang_String("1.*.3", "1.*.0.3");
        this.testResolved$java_lang_String$java_lang_String("[1.2.*.4]", "1.2.*.4");
        this.testResolved$java_lang_String$java_lang_String("espn.*.com", null);
        this.testResolved$java_lang_String$java_lang_String("*.instapundit.com", null);
        this.testResolved$java_lang_String$java_lang_String("es*n.com", null);
        this.testResolved$java_lang_String$java_lang_String("inst*undit.com", null);
        if(this.fullTest && HostTest.runDNS) {
            this.testResolved$java_lang_String$java_lang_String("espn.com/24", "199.181.132.*");
        }
        this.testResolved$java_lang_String$java_lang_String("3*", null);
        this.testResolved$java_lang_String$java_lang_String("*", "*");
        this.testResolved$java_lang_String$java_lang_String("3.*", "3.*.*.*");
        this.testResolved$java_lang_String$java_lang_String("3:*", "3:*:*:*:*:*:*:*");
        this.testResolved$java_lang_String$java_lang_String("9.*.237.26", "9.*.237.26");
        this.testResolved$java_lang_String$java_lang_String("*.70.146.*", "*.70.146.*");
        this.hostTest$boolean$java_lang_String(true, "1.2.3.4/1.2.3.4");
        this.hostTest$boolean$java_lang_String(false, "1.2.3.4/*");
        this.hostTest$boolean$java_lang_String(false, "1.*.3.4/*");
        this.hostTest$boolean$java_lang_String(true, "1.*.3.4");
        this.hostTest$boolean$java_lang_String(true, "1:*:3:4");
        this.hostLabelsTest$java_lang_String$java_lang_String_A("*", ["*"]);
        this.hostLabelsTest$java_lang_String$java_lang_String_A("**", ["*"]);
        this.testHostOrWildcardAddress("1_.2.3.4", 4, "1_.2.3.4", "10-19.2.3.4");
        this.testHostOrRangeAddress("1-2.2.3.4", 4, "1-2.2.3.4", "1-2.2.3.4");
        this.testHostOrAddress_inet_aton("1-9.1-2", 2, 4, "1-9.1-2", "1-9.0.0.1-2");
        this.testHostOrAddress_inet_aton("1-9.0x1-0x22", 2, 4, "1-9.0x1-0x22", "1-9.0.0.1-34");
        this.testHostOnly("9-1.0x1-0x22", 2, "9-1.0x1-0x22", null);
        this.testHostOrAddress_inet_aton("1-9.0x1-0x22.03.04", 4, 4, "1-9.0x1-0x22.03.04", "1-9.1-34.3.4");
        this.testAddress("1::2", 8, "[1:0:0:0:0:0:0:2]", "1:0:0:0:0:0:0:2");
        this.testAddress("1.2.3.4", 4, "1.2.3.4", "1.2.3.4");
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        this.testMatches$boolean$java_lang_String$java_lang_String(!isNoAutoSubnets, "1.*.*.*/255.0.0.0", "1.0.0.0/255.0.0.0");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.0.0.0/8", "1.0.0.0/255.0.0.0");
        if(allPrefixesAreSubnets) {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/255.0.0.0", "1.*.*.*");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/255.0.0.0", "1.*.___.*");
            this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "1.2.3.4/255.0.0.0", "1.0-255.*.*", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        } else {
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/255.0.0.0", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/255.0.0.0", "1.2.3.4");
            this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.2.3.4/255.0.0.0", "1.2.3.4");
        }
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.0.0.0/255.0.0.0", isNoAutoSubnets?"1.0.0.0":"1.*.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "1.0.0.0/255.0.0.0", isNoAutoSubnets?"1.0.0.0":"1.*.___.*");
        this.testMatches$boolean$java_lang_String$java_lang_String(false, "1.0.0.0/255.0.0.0", "1.0-255.*.*");
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "1.0.0.0/255.0.0.0", isNoAutoSubnets?"1.0.0.0":"1.0-255.*.*", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "1-2.0-0.00-00.00-0", "1-2.0.0.0", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "1-2:0-0:00-00:00-0:0-000:0000-0000:0000-00:0000-0", "1-2:0:0:0:0:0:0:0", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "00-0.0-0.00-00.00-0", "0.0.0.0", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(true, "0-00:0-0:00-00:00-0:0-000:0000-0000:0000-00:0000-0", "::", HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$());
        super.runTest();
    }
}
HostRangeTest["__class"] = "inet.ipaddr.test.HostRangeTest";




HostRangeTest.ADDRESS_WILDCARD_OPTIONS_$LI$();

HostRangeTest.HOST_WILDCARD_AND_RANGE_INET_ATON_OPTIONS_$LI$();

HostRangeTest.HOST_WILDCARD_AND_RANGE_OPTIONS_$LI$();

HostRangeTest.HOST_WILDCARD_OPTIONS_$LI$();

HostRangeTest.HOST_ONLY_OPTIONS_$LI$();
