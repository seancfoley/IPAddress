/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { IPAddress } from '../IPAddress';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IPAddressRangeTest } from './IPAddressRangeTest';
import { AddressCreator } from './AddressCreator';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { HostAllTest } from './HostAllTest';
import { AddressStringParameters } from '../AddressStringParameters';
import { TestBase } from './TestBase';

export class IPAddressAllTest extends IPAddressRangeTest {
    static ADDRESS_SAMPLING : string[]; public static ADDRESS_SAMPLING_$LI$() : string[] { if(IPAddressAllTest.ADDRESS_SAMPLING == null) IPAddressAllTest.ADDRESS_SAMPLING = ["bla", "foo", "", "  ", "     ", "", "1.0.0.0", "1.002.3.4", "1.2.003.4", "1.2.3.4", "000100401404", "0x01020304", "001.002.003.004", "1.002.3.*", "1.002.3.*/31", "1.002.3.*/17", "1.002.3.4/16", "1.002.3.*/16", "001.002.003.004/16", "1.2.003.4/15", "1.2.3.4/15", "255.254.255.254", "255.254.255.255", "*.*.1-3.*", "255.255.255.254", "*.*.*.*", "*.*.%*.*", "255.255.255.255", "1::", "1::2:3:4", "1::2:003:4", "1::2:3:4", "0001:0000::0002:0003:0004", "1::2:3:*/111", "1::2:3:*/127", "1::2:3:*", "1::2:1-3:4:*", "1::2:3:*/31", "1::2:3:*/17", "1::2:003:4/17", "1::2:7:8/17", "1::2:003:4/15", "1::2:3:4/15", "1::2:003:4/16", "1::2:003:*/16", "0001:0000::0002:0003:0004/16", "1:f000::2/17", "a1:f000::2/17", "ffff::fffe:ffff:fffe", "ffff::fffe:ffff:ffff", "ffff::ffff:ffff:fffe", "*::*:*:*", "*::*:%*:*", "ffff::ffff:ffff:ffff", "*:*:a:*:*:*:*:*", "*:*:a:*:*:*:*:*/16", "*:*", "*:*:*:*:*:*:*:*", "/33", "/64", "/128", "/32", "/24", "/0", "*", "**", " *", "%%", "1.2.*.*", "1.2.0.0/16", "000100400000-000100577777", "0x01020000-0x0102ffff", "1.*.*.*", "1.*.0.0/16", "1.*.0.0/12", "000100000000-000177777777", "0x01000000-0x01ffffff", "0.0.0.0", "000000000000", "0x00000000", "9.63.127.254", "001117677776", "0x093f7ffe", "9.63.*.*", "9.63.0.0/16", "001117600000-001117777777", "0x093f0000-0x093fffff", "9.*.*.*", "9.*.0.0/16", "001100000000-001177777777", "0x09000000-0x09ffffff", "000100401772-000100401777", "0x010203fa-0x010203ff", "1.2.3.250-255", "000100401710-000100401777", "0x010203c8-0x010203ff", "1.2.3.200-255", "000100401544-000100401707", "0x01020364-0x010203c7", "1.2.3.100-199", "100-199.2.3.100-199", "100-199.2.3.100-198", "000100401400-000100401543", "0x01020300-0x01020363", "1.2.3.0-99", "000100401544-000100401633", "0x01020364-0x0102039b", "1.2.3.100-155", "1.2.3.100-255", "000100401544-000100401777", "0x01020364-0x010203ff", "1.128-240.0.0/12", "1.128-255.*.*", "000140000000-000177777777", "0x01800000-0x01ffffff", "1.200-252.0.0/14", "1.200-255.*.*", "000162000000-000177777777", "0x01c80000-0x01ffffff", "000a:000b:000c:000d:000e:000f:000a:000b", "00|N0s0$ND2DCD&%D3QB", "0x000a000b000c000d000e000f000a000b", "a:b:c:d:e:f:0.10.0.11", "a:b:c:d:e:f:a:b", "a:b:c:d:*/64", "a:b:c:d:*:*:*:*/64", "000a:000b:000c:000d:0000:0000:0000:0000/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "a:b:c:d:*:*:*:*", "a:b:c:d:0:0:0:0/64", "a:b:c:d::/64", "0000001G~Ie?xF;x&)@P" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "0000001G~JZkWI!qp&GP/64", "0000:0000:000c:000d:0000:0000:0000:0000/64", "0x00000000000c000d0000000000000000-0x00000000000c000dffffffffffffffff", "0:0:c:d:*:*:*:*", "0:0:c:d:0:0:0:0/64", "0:0:c:d::/64", "::c:d:*:*:*:*", "0000001G~Ie^C9jXExx>", "0000:0000:000c:000d:000e:000f:000a:000b", "0:0:c:d:e:f:a:b", "0x00000000000c000d000e000f000a000b", "::c:d:e:f:0.10.0.11", "::c:d:e:f:a:b", "000a:000b:000c:000d:0000:0000:0000:0000", "00|N0s0$ND2BxK96%Chk", "0x000a000b000c000d0000000000000000", "a:b:c:d:0:0:0:0", "a:b:c:d::", "000a:000b:000c:000d:0000:0000:0000:0000/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "a:b:c:d:*:*:*:*", "a:b:c:d:0:0:0:0/64", "a:b:c:d::/64", "000a:0000:0000:000d:0000-8000:0000:0000:0000/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "a:0:0:d:*:*:*:*", "a:0:0:d:*:0:0:0/65", "a:0:0:d:*::/65", "a::d:*:*:*:*", "000a:0000:0000:000d:0000-8000:0000:0000:0000/65", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N/65", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "a:0:0:d:*:*:*:*", "a:0:0:d:*:0:0:0/65", "a:0:0:d:*::/65", "a::d:*:*:*:*", "000a:000b:000c:0000-ffff:0000:0000:0000:0000/64", "00|N0s0$N0-%*(tF5l-X" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0;%a&*sUa#KSGX/64", "0x000a000b000c00000000000000000000-0x000a000b000cffffffffffffffffffff", "a:b:c:*:*:*:*:*", "a:b:c:*:0:0:0:0/64", "a:b:c:*::/64", "000a:000b:000c:000d:0000:0000:0000:0000/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "a:b:c:d:*:*:*:*", "a:b:c:d:0:0:0:0/64", "a:b:c:d::/64", "000a:0000:0000:0000:0000:0000:0000:0000/64", "00|M>t|ttwH6V62lVY`A" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttxBz48@eGWJA/64", "0x000a0000000000000000000000000000-0x000a000000000000ffffffffffffffff", "a:0:0:0:*:*:*:*", "a:0:0:0:0:0:0:0/64", "a::*:*:*:*", "a::/64", "000a:000b:000c:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "00|N0s0$N0-%*(tF5l-X" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0;%a&*sUa#KSGX", "0x000a000b000c00000000000000000000-0x000a000b000cffffffffffffffffffff", "a:b:c:*:*:*:*.*.*.*", "a:b:c:*:*:*:*:*", "000a:0000:0000:000d:000e:000f:0000:0000/112", "00|M>t|tt+WcwbECb*xq/112", "0x000a00000000000d000e000f00000000-0x000a00000000000d000e000f0000ffff", "a:0:0:d:e:f:0:*", "a:0:0:d:e:f:0:0/112", "a:0:0:d:e:f::/112", "a::d:e:f:0:*", "a::d:e:f:0:0/112", "000a:0000:000c:000d:000e:000f:0000:0000/112", "00|M>t};s?v~hFl`j3_$/112", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000f0000ffff", "a:0:c:d:e:f:0:*", "a:0:c:d:e:f:0:0/112", "a:0:c:d:e:f::/112", "a::c:d:e:f:0:*", "000a:0000:000c:000d:000e:000f:0000:0000/97", "00|M>t};s?v~hFl`j3_$/97", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000f7fffffff", "a:0:c:d:e:f:0-7fff:*", "a:0:c:d:e:f:0:0/97", "a:0:c:d:e:f::/97", "a::c:d:e:f:0-7fff:*", "000a:0000:000c:000d:000e:000f:0000:0000/96", "00|M>t};s?v~hFl`j3_$/96", "0x000a0000000c000d000e000f00000000-0x000a0000000c000d000e000fffffffff", "a:0:c:d:e:f:*:*", "a:0:c:d:e:f:0:0/96", "a:0:c:d:e:f::/96", "a::c:d:e:f:*:*", "000a:0000:000c:000d:000e:000f:0001:0000/112", "00|M>t};s?v~hFl`jD0%/112", "0x000a0000000c000d000e000f00010000-0x000a0000000c000d000e000f0001ffff", "a:0:c:d:e:f:1:*", "a:0:c:d:e:f:1:0/112", "a:0:c:d:e:f:1::/112", "a::c:d:e:f:0.1.0.0/112", "a::c:d:e:f:1:*", "a::c:d:e:f:1:0/112", "000a:0000:000c:000d:0000:0000:0001:0000/112", "00|M>t};s?v}5L>MDR^a/112", "0x000a0000000c000d0000000000010000-0x000a0000000c000d000000000001ffff", "a:0:c:d:0:0:1:*", "a:0:c:d:0:0:1:0/112", "a:0:c:d:0:0:1::/112", "a:0:c:d::0.1.0.0/112", "a:0:c:d::1:*", "a:0:c:d::1:0/112", "000a:0000:000c:000d:000e:000f:000a:0000/112", "00|M>t};s?v~hFl`k9s=/112", "0x000a0000000c000d000e000f000a0000-0x000a0000000c000d000e000f000affff", "a:0:c:d:e:f:a:*", "a:0:c:d:e:f:a:0/112", "a:0:c:d:e:f:a::/112", "a::c:d:e:f:0.10.0.0/112", "a::c:d:e:f:a:*", "a::c:d:e:f:a:0/112", "000a:0000:000c:000d:0000:0000:0000:0100/120", "00|M>t};s?v}5L>MDI>a/120", "0x000a0000000c000d0000000000000100-0x000a0000000c000d00000000000001ff", "a:0:c:d:0:0:0:100-1ff", "a:0:c:d:0:0:0:100/120", "a:0:c:d::0.0.1.0/120", "a:0:c:d::100-1ff", "a:0:c:d::100/120", "000a:000b:000c:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "a:b:c:d:*:*:*.*.*.*", "a:b:c:d:*:*:*:*", "000a:000b:000c:000d:0000:0000:0000:0000/64", "00|N0s0$ND2BxK96%Chk" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|N0s0$ND{&WM}~o9(k/64", "0x000a000b000c000d0000000000000000-0x000a000b000c000dffffffffffffffff", "a:b:c:d:*:*:*:*", "a:b:c:d:0:0:0:0/64", "a:b:c:d::/64", "000a:0000:0000:0000:0000:000c:000d:0000-ffff", "00|M>t|ttwH6V6EEzblZ" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttwH6V6EEzkrZ", "0x000a0000000000000000000c000d0000-0x000a0000000000000000000c000dffff", "a:0:0:0:0:c:d:*", "a::c:0.13.*.*", "a::c:d:*", "000a:0000:0000:000d:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "a:0:0:d:*:*:*:*", "a::d:*:*:*.*.*.*", "a::d:*:*:*:*", "000a:0000:0000:0000:0000:0000:0000:0000/64", "00|M>t|ttwH6V62lVY`A" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|ttxBz48@eGWJA/64", "0x000a0000000000000000000000000000-0x000a000000000000ffffffffffffffff", "a:0:0:0:*:*:*:*", "a:0:0:0:0:0:0:0/64", "a::*:*:*:*", "a::/64", "000a:0000:0000:000d:0000:0000:0000:0000/64", "00|M>t|tt+WbKhfd5~qN" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "00|M>t|tt-R6^kVV>{?N/64", "0x000a00000000000d0000000000000000-0x000a00000000000dffffffffffffffff", "a:0:0:d:*:*:*:*", "a:0:0:d:0:0:0:0/64", "a:0:0:d::/64", "a::d:*:*:*:*", "0001:0000:0000:0000:0000:0000:0000:0000/32", "008JOm8Mm5*yBppL!sg1" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "008JPeGE6kXzV|T&xr^1/32", "0x00010000000000000000000000000000-0x00010000ffffffffffffffffffffffff", "1:0:*:*:*:*:*:*", "1:0:0:0:0:0:0:0/32", "1::*:*:*:*:*:*", "1::/32", "0xff000000000000000000000000000000-0xffffffffffffffffffffffffffffffff", "=SN{mv>Qn+T=L9X}Vo30" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "=r54lj&NUUO~Hi%c2ym0/8", "ff00-ffff:*:*:*:*:*:*:*", "ff00:0000:0000:0000:0000:0000:0000:0000/8", "ff00:0:0:0:0:0:0:0/8", "ff00::/8", "0xffff0000000000000000000000000000-0xffff0000000000000000000000ffffff", "=q{+M|w0(OeO5^EGP660/104", "ffff:0000:0000:0000:0000:0000:0000:0000/104", "ffff:0:0:0:0:0:0-ff:*", "ffff:0:0:0:0:0:0:0/104", "ffff::/104", "ffff::0-ff:*", "0xffff0000000000000000000000000000-0xffff00000000000000000000000fffff", "=q{+M|w0(OeO5^EGP660/108", "ffff:0000:0000:0000:0000:0000:0000:0000/108", "ffff:0:0:0:0:0:0-f:*", "ffff:0:0:0:0:0:0:0/108", "ffff::/108", "ffff::0-f:*", "0xffff0000000000000000000010000000-0xffff00000000000000000000100fffff", "=q{+M|w0(OeO5^ELbE%G/108", "ffff:0000:0000:0000:0000:0000:1000:0000/108", "ffff:0:0:0:0:0:1000-100f:*", "ffff:0:0:0:0:0:1000:0/108", "ffff:0:0:0:0:0:1000::/108", "ffff::1000-100f:*", "ffff::1000:0/108", "ffff::16.0.0.0/108", "0xffff00000000000000000000a0000000-0xffff00000000000000000000a00fffff", "=q{+M|w0(OeO5^E(z82>/108", "ffff:0000:0000:0000:0000:0000:a000:0000/108", "ffff:0:0:0:0:0:a000-a00f:*", "ffff:0:0:0:0:0:a000:0/108", "ffff:0:0:0:0:0:a000::/108", "ffff::160.0.0.0/108", "ffff::a000-a00f:*", "ffff::a000:0/108", "0xffff00000000000000000000eee00000-0xffff00000000000000000000eeefffff", "=q{+M|w0(OeO5^F85=Cb/108", "ffff:0000:0000:0000:0000:0000:eee0:0000/108", "ffff:0:0:0:0:0:eee0-eeef:*", "ffff:0:0:0:0:0:eee0:0/108", "ffff:0:0:0:0:0:eee0::/108", "ffff::238.224.0.0/108", "ffff::eee0-eeef:*", "ffff::eee0:0/108", "0xffff0000000000000000000000000000-0xffff00000000000000000000001fffff", "=q{+M|w0(OeO5^EGP660/107", "ffff:0000:0000:0000:0000:0000:0000:0000/107", "ffff:0:0:0:0:0:0-1f:*", "ffff:0:0:0:0:0:0:0/107", "ffff::/107", "ffff::0-1f:*", "0xabcd0000000000000000000000000000-0xabcd00000000000000000000001fffff", "abcd:0000:0000:0000:0000:0000:0000:0000/107", "abcd:0:0:0:0:0:0-1f:*", "abcd:0:0:0:0:0:0:0/107", "abcd::/107", "abcd::0-1f:*", "o6)n`s#^$cP5&p^H}p=a/107", "0001:0002:0003:0004:0000:0000:0000:0000%:%:%", "008JQWOV7Skb)C|ve)jA\u00a7:%:%", "1:2:3:4:0:0:0:0%:%:%", "1:2:3:4::%:%:%", "0x00010002000300040000000000000000%:%:%", "0001:0002:0003:0004:0000:0000-ffff:0000-ffff:0000-ffff", "008JQWOV7Skb)C|ve)jA" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "008JQWOV7Skb?_P3;X#A", "1:2:3:4:0:*:*:*", "1:2:3:4::*:*.*.*.*", "1:2:3:4::*:*:*", "0x00010002000300040000000000000000-0x00010002000300040000ffffffffffff", "0001:0002:0003:0004:0000:0000:0000:0000/80", "008JQWOV7Skb)C|ve)jA/80", "0x00010002000300040000000000000000-0x00010002000300040000ffffffffffff", "1:2:3:4:0:*:*:*", "1:2:3:4:0:0:0:0/80", "1:2:3:4::*:*:*", "1:2:3:4::/80", "0001:0002:0003:0004:0000:0000:0000:0000", "008JQWOV7Skb)C|ve)jA", "0x00010002000300040000000000000000", "1:2:3:4:0:0:0:0", "1:2:3:4::", "0001:0002:0003:0004:0000:0006:0000:0000", "008JQWOV7Skb)D3fCrWG", "0x00010002000300040000000600000000", "1:2:3:4:0:6:0:0", "1:2:3:4:0:6::", "0001:0002:0003:0000:0000:0006:0000:0000", "008JQWOV7O(=61h*;$LC", "0x00010002000300000000000600000000", "1:2:3:0:0:6:0:0", "1:2:3:0:0:6::", "1:2:3::6:0:0", "0x108000000000000000080800200c417a", "1080:0000:0000:0000:0008:0800:200c:417a", "1080:0:0:0:8:800:200c:417a", "1080::8:800:200c:417a", "1080::8:800:32.12.65.122", "4)+k&C#VzJ4br>0wv%Yp", "0000:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "008JOm8Mm5*yBppL!sg0", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0x0000ffffffffffffffffffffffffffff", "::ffff:ffff:ffff:ffff:ffff:255.255.255.255", "::ffff:ffff:ffff:ffff:ffff:ffff:ffff", "=r54lj&NUUO~Hi%c2ym0", "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255", "0xffffffffffffffffffffffffffffffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff"]; return IPAddressAllTest.ADDRESS_SAMPLING; };

    static DEFAULT_OPTIONS : IPAddressStringParameters; public static DEFAULT_OPTIONS_$LI$() : IPAddressStringParameters { if(IPAddressAllTest.DEFAULT_OPTIONS == null) IPAddressAllTest.DEFAULT_OPTIONS = new IPAddressStringParameters.Builder().toParams(); return IPAddressAllTest.DEFAULT_OPTIONS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    /**
     * 
     * @param {string} x
     * @return {IPAddressString}
     */
    createInetAtonAddress(x : string) : IPAddressString {
        return this.createAddress$java_lang_String(x);
    }

    public createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ((ipv6RangeOptions != null && ipv6RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv6RangeOptions === null)) {
            super.createAddress(x, ipv4RangeOptions, ipv6RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>IPAddressStringParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'number') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressAllTest.DEFAULT_OPTIONS_$LI$());
    }

    /**
     * 
     * @return {boolean}
     */
    isLenient() : boolean {
        return true;
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testStrings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && ((typeof normalizedWildcardString === 'boolean') || normalizedWildcardString === null) && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString$boolean(w, ipAddr, normalizedString, normalizedWildcardString);
        } else if(((w != null && w instanceof <any>Array && (w.length==0 || w[0] == null ||(typeof w[0] === 'string'))) || w === null) && ((typeof ipAddr === 'number') || ipAddr === null) && ((normalizedString != null && normalizedString instanceof <any>IPAddressString) || normalizedString === null) && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$java_lang_String_A$int$inet_ipaddr_IPAddressString(w, ipAddr, normalizedString);
        } else if(w === undefined && ipAddr === undefined && normalizedString === undefined && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$();
        } else throw new Error('invalid overload');
    }

    testStrings$() {
        super.testStrings();
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "aaaabbbbccccddddeeeeffffaaaabbbb", "aaaa:bbbb:cccc:dddd:eeee:ffff:aaaa:bbbb");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "4)+k&C#VzJ4br>0wv%Yp", "1080::8:800:200c:417a");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "=r54lj&NUUO~Hi%c2ym0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "aaaabbbbccccdddd0000000000000000-aaaabbbbcccccdddffffffffffffffff", "aaaa:bbbb:cccc:cddd-dddd:*:*:*:*");
        this.testMatches$boolean$java_lang_String$java_lang_String(true, "=r54lj&NUUO~Hi%c2yl0" + IPv6Address.ALTERNATIVE_RANGE_SEPARATOR + "=r54lj&NUUO~Hi%c2ym0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffaa-ffff");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("4)+k&C#VzJ4br>0wv%Yp", "1080:0:0:0:8:800:200c:417a", "1080:0:0:0:8:800:200c:417a", "1080::8:800:200c:417a", "1080:0:0:0:8:800:200c:417a", "1080:0000:0000:0000:0008:0800:200c:417a", "1080::8:800:200c:417a", "1080::8:800:200c:417a", "1080::8:800:200c:417a", "1080::8:800:200c:417a", "1080::8:800:32.12.65.122", "1080::8:800:32.12.65.122", "1080::8:800:32.12.65.122", "1080::8:800:32.12.65.122", "a.7.1.4.c.0.0.2.0.0.8.0.8.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.8.0.1.ip6.arpa", "1080-0-0-0-8-800-200c-417a.ipv6-literal.net", "4)+k&C#VzJ4br>0wv%Yp", "0x108000000000000000080800200c417a", "00204000000000000000000000100200004003040572");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("008JOm8Mm5*yBppL!sg0", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0000:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "::ffff:ffff:ffff:ffff:ffff:ffff:ffff", "0:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "::ffff:ffff:ffff:ffff:ffff:ffff:ffff", "::ffff:ffff:ffff:ffff:ffff:ffff:ffff", "::ffff:ffff:ffff:ffff:ffff:255.255.255.255", "::ffff:ffff:ffff:ffff:ffff:255.255.255.255", "::ffff:ffff:ffff:ffff:ffff:255.255.255.255", "::ffff:ffff:ffff:ffff:ffff:255.255.255.255", "f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.0.0.0.0.ip6.arpa", "0-ffff-ffff-ffff-ffff-ffff-ffff-ffff.ipv6-literal.net", "008JOm8Mm5*yBppL!sg0", "0x0000ffffffffffffffffffffffffffff", "00000017777777777777777777777777777777777777");
        this.testIPv6Strings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("=r54lj&NUUO~Hi%c2ym0", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255", "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255", "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255", "ffff:ffff:ffff:ffff:ffff:ffff:255.255.255.255", "f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.f.ip6.arpa", "ffff-ffff-ffff-ffff-ffff-ffff-ffff-ffff.ipv6-literal.net", "=r54lj&NUUO~Hi%c2ym0", "0xffffffffffffffffffffffffffffffff", "03777777777777777777777777777777777777777777");
    }

    /**
     * 
     * @param {IPAddressString} str
     */
    createList(str : IPAddressString) {
        let ipAddr : IPAddress = str.getAddress();
        let c : string = ipAddr.toCompressedString();
        let canonical : string = ipAddr.toCanonicalString();
        let s : string = ipAddr.toSubnetString();
        let cidr : string = ipAddr.toPrefixLengthString();
        let n : string = ipAddr.toNormalizedString();
        let nw : string = ipAddr.toNormalizedWildcardString();
        let caw : string = ipAddr.toCanonicalWildcardString();
        let cw : string = ipAddr.toCompressedWildcardString();
        let set : Array<string> = <any>([]);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, c);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, canonical);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, s);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, cidr);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, n);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, nw);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, cw);
        /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, caw);
        try {
            let hex : string = ipAddr.toHexString(true);
            /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, hex);
        } catch(e) {
        };
        if(ipAddr.isIPv4()) {
            try {
                let octal : string = ipAddr.toOctalString(true);
                /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, octal);
            } catch(e) {
            };
        }
        if(ipAddr.isIPv6()) {
            let full : string = ipAddr.toFullString();
            let base85 : string = ipAddr.toIPv6().toBase85String();
            let m : string = ipAddr.toIPv6().toMixedString();
            /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, full);
            /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, base85);
            /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, m);
        }
        for(let index141=0; index141 < set.length; index141++) {
            let string = set[index141];
            {
                console.info('\"' + string + "\",");
            }
        }
        console.info();
    }

    testCaches(map : any, testSize : boolean, useBytes : boolean) {
        let cache : IPAddressNetwork.IPAddressStringGenerator = new IPAddressNetwork.IPAddressStringGenerator(map);
        this.testCache(IPAddressAllTest.ADDRESS_SAMPLING_$LI$(), cache, (str) => this.createAddress$java_lang_String(str), testSize, useBytes);
    }

    /**
     * 
     */
    runTest() {
        super.runTest();
        this.testNormalized$java_lang_String$java_lang_String("aaaabbbbcccccddd0000000000000000-aaaabbbbccccddddffffffffffffffff", "aaaa:bbbb:cccc:cddd-dddd:*:*:*:*");
        this.testCanonical("aaaabbbbcccccddd0000000000000000-aaaabbbbccccddddffffffffffffffff", "aaaa:bbbb:cccc:cddd-dddd:*:*:*:*");
        this.testCaches(<any>({}), true, true);
        this.testCaches(<any>({}), true, true);
        this.testCaches(<any>({}), true, false);
        this.testCaches(<any>({}), true, false);
        let map : ConcurrentHashMap<string, IPAddressString> = <any>(new ConcurrentHashMap<string, IPAddressString>());
        HostAllTest.testCachesSync(() => {
            this.testCaches(map, false, false);
        });
    }
}
IPAddressAllTest["__class"] = "inet.ipaddr.test.IPAddressAllTest";




IPAddressAllTest.DEFAULT_OPTIONS_$LI$();

IPAddressAllTest.ADDRESS_SAMPLING_$LI$();
