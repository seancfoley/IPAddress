/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressStringException } from '../AddressStringException';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { MACAddressString } from '../MACAddressString';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressSection } from '../mac/MACAddressSection';
import { MACAddressSegment } from '../mac/MACAddressSegment';
import { MACAddressTest } from './MACAddressTest';
import { AddressStringParameters } from '../AddressStringParameters';
import { AddressCreator } from './AddressCreator';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IPAddressRangeTest } from './IPAddressRangeTest';
import { TestBase } from './TestBase';
import { AddressNetwork } from '../AddressNetwork';
import { MACAddressNetwork } from '../mac/MACAddressNetwork';

export class MACAddressRangeTest extends MACAddressTest {
    static WILDCARD_AND_RANGE_ADDRESS_OPTIONS : MACAddressStringParameters; public static WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$() : MACAddressStringParameters { if(MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS == null) MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS = TestBase.MAC_ADDRESS_OPTIONS_$LI$().toBuilder().allowAll(true).getFormatBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).getParentBuilder().toParams(); return MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS; };

    static WILDCARD_ONLY_ADDRESS_OPTIONS : MACAddressStringParameters; public static WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$() : MACAddressStringParameters { if(MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS == null) MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS = MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getFormatBuilder().setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).getParentBuilder().toParams(); return MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS; };

    static NO_RANGE_ADDRESS_OPTIONS : MACAddressStringParameters; public static NO_RANGE_ADDRESS_OPTIONS_$LI$() : MACAddressStringParameters { if(MACAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS == null) MACAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS = MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getFormatBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$()).getParentBuilder().toParams(); return MACAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    public createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>IPAddressStringParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'number') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        if(x.indexOf(IPAddress.RANGE_SEPARATOR) !== -1) {
            return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$());
        }
        return this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, IPAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$());
    }

    createMACAddress$java_lang_String(x : string) : MACAddressString {
        if(x.indexOf(IPAddress.RANGE_SEPARATOR) !== -1) {
            return this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x, MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$());
        }
        return this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x, MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$());
    }

    public createMACAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x : string, ipv4RangeOptions : AddressStringParameters.RangeParameters) : MACAddressString {
        let validationOptions : MACAddressStringParameters = MACAddressRangeTest.getOpts(ipv4RangeOptions);
        return this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x, validationOptions);
    }

    public createMACAddress(x? : any, ipv4RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>AddressStringParameters.RangeParameters) || ipv4RangeOptions === null)) {
            return <any>this.createMACAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>MACAddressStringParameters) || ipv4RangeOptions === null)) {
            super.createMACAddress(x, ipv4RangeOptions);
        } else if(((typeof x === 'number') || x === null) && ((typeof ipv4RangeOptions === 'boolean') || ipv4RangeOptions === null)) {
            return <any>this.createMACAddress$long$boolean(x, ipv4RangeOptions);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined) {
            return <any>this.createMACAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>MACAddressTest.MACAddressStringKey) || x === null) && ipv4RangeOptions === undefined) {
            return <any>this.createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined) {
            return <any>this.createMACAddress$byte_A(x);
        } else throw new Error('invalid overload');
    }

    /*private*/ static getOpts(options : AddressStringParameters.RangeParameters) : MACAddressStringParameters {
        if(options.equals(AddressStringParameters.RangeParameters.NO_RANGE_$LI$())) {
            return MACAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS_$LI$();
        } else if(options.equals(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$())) {
            return MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$();
        } else if(options.equals(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$())) {
            return MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$();
        }
        return MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getFormatBuilder().setRangeOptions(options).getParentBuilder().toParams();
    }

    createAddress$java_lang_String$inet_ipaddr_AddressStringParameters_RangeParameters(x : string, options : AddressStringParameters.RangeParameters) : MACAddressString {
        return this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(x, MACAddressRangeTest.getOpts(options));
    }

    /**
     * 
     * @param {MACAddress} origAddr
     * @return {boolean}
     */
    testBytes(origAddr : MACAddress) : boolean {
        let failed : boolean = false;
        if(origAddr.isMultiple()) {
            try {
                origAddr.getBytes();
            } catch(e) {
                failed = true;
            };
        } else {
            failed = !super.testBytes(origAddr);
        }
        return !failed;
    }

    public testCount$java_lang_String$int(original : string, number : number) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        this.testCount$inet_ipaddr_MACAddressString$int(w, number);
    }

    public testCount(original? : any, number? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof number === 'number') || number === null)) {
            return <any>this.testCount$java_lang_String$int(original, number);
        } else if(((original != null && original instanceof <any>MACAddressString) || original === null) && ((typeof number === 'number') || number === null)) {
            return <any>this.testCount$inet_ipaddr_MACAddressString$int(original, number);
        } else throw new Error('invalid overload');
    }

    /*private*/ testCount$inet_ipaddr_MACAddressString$int(w : MACAddressString, number : number) {
        IPAddressRangeTest.testCount$inet_ipaddr_test_TestBase$inet_ipaddr_HostIdentifierString$long$long(this, w, number, -1);
    }

    public testPrefixCount$java_lang_String$int(original : string, number : number) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(original);
        this.testPrefixCount$inet_ipaddr_MACAddressString$int(w, number);
    }

    public testPrefixCount(original? : any, number? : any) : any {
        if(((typeof original === 'string') || original === null) && ((typeof number === 'number') || number === null)) {
            return <any>this.testPrefixCount$java_lang_String$int(original, number);
        } else if(((original != null && original instanceof <any>MACAddressString) || original === null) && ((typeof number === 'number') || number === null)) {
            return <any>this.testPrefixCount$inet_ipaddr_MACAddressString$int(original, number);
        } else throw new Error('invalid overload');
    }

    /*private*/ testPrefixCount$inet_ipaddr_MACAddressString$int(w : MACAddressString, number : number) {
        IPAddressRangeTest.testPrefixCount(this, w, number);
    }

    /*private*/ testToOUIPrefixed(addrString : string) {
        let w : MACAddressString = this.createMACAddress$java_lang_String(addrString);
        let v : MACAddress = w.getAddress();
        let suffixSeg : MACAddressSegment = new MACAddressSegment(0, 255);
        let suffixSegs : MACAddressSegment[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(v.getSegmentCount());
        v.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, 3, suffixSegs, 0);
        for(let i : number = 3; i < suffixSegs.length; i++) {
            suffixSegs[i] = suffixSeg;
        };
        let suffix : MACAddressSection = new MACAddressSection(suffixSegs);
        let suffixed : MACAddress = new MACAddress(suffix);
        let prefixed : MACAddress = v.toOUIPrefixBlock();
        if(!prefixed.equals(suffixed)) {
            this.addFailure(new TestBase.Failure("failed oui prefixed " + prefixed + " constructed " + suffixed, w));
        }
        this.incrementTestCount();
    }

    /*private*/ testEquivalentPrefix$java_lang_String$int(host : string, prefix : number) {
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host, prefix, prefix);
    }

    public testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host : string, equivPrefix : number, minPrefix : number) {
        let str : MACAddressString = this.createMACAddress$java_lang_String(host);
        try {
            let h1 : MACAddress = str.toAddress();
            let equiv : number = h1.getPrefixLengthForSingleBlock();
            if(equiv == null?(equivPrefix != null):(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(equivPrefix,equiv)))) {
                this.addFailure(new TestBase.Failure("failed: prefix expected: " + equivPrefix + " prefix got: " + equiv, h1));
            } else {
                let minPref : number = h1.getMinPrefixLengthForBlock();
                if(minPref !== minPrefix) {
                    this.addFailure(new TestBase.Failure("failed: prefix expected: " + minPrefix + " prefix got: " + minPref, h1));
                }
            }
        } catch(__e) {
            if(__e != null && __e instanceof <any>AddressStringException) {
                let e : AddressStringException = <AddressStringException>__e;
                this.addFailure(new TestBase.Failure("failed " + e, str));

            }
            if(__e != null && __e instanceof <any>IncompatibleAddressException) {
                let e : IncompatibleAddressException = <IncompatibleAddressException>__e;
                this.addFailure(new TestBase.Failure("failed " + e, str));

            }
        };
        this.incrementTestCount();
    }

    public testEquivalentPrefix(host? : any, equivPrefix? : any, minPrefix? : any) : any {
        if(((typeof host === 'string') || host === null) && ((typeof equivPrefix === 'number') || equivPrefix === null) && ((typeof minPrefix === 'number') || minPrefix === null)) {
            return <any>this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int(host, equivPrefix, minPrefix);
        } else if(((typeof host === 'string') || host === null) && ((typeof equivPrefix === 'number') || equivPrefix === null) && minPrefix === undefined) {
            return <any>this.testEquivalentPrefix$java_lang_String$int(host, equivPrefix);
        } else throw new Error('invalid overload');
    }

    testPrefixBlock(prefixedAddressStr : string, expectedPref : number) {
        let prefixedAddressString : MACAddressString = this.createMACAddress$java_lang_String(prefixedAddressStr);
        let prefixedAddress : MACAddress = prefixedAddressString.getAddress();
        let prefConf : AddressNetwork.PrefixConfiguration = prefixedAddress.getNetwork().getPrefixConfiguration();
        if(!/* Enum.equals */(<any>(TestBase.prefixConfiguration) === <any>(prefConf))) {
            this.addFailure(new TestBase.Failure("prefix config  " + TestBase.prefixConfiguration + " mismatch with " + prefConf, prefixedAddress));
        }
        let allPrefixesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        let lower : MACAddress = prefixedAddress.getLower();
        let upper : MACAddress = prefixedAddress.getUpper();
        let removedPrefix : MACAddress = prefixedAddress.removePrefixLength();
        let adjustPrefix : MACAddress = prefixedAddress.adjustPrefixLength$int(1);
        let adjustPrefix2 : MACAddress = prefixedAddress.adjustPrefixLength$int(-1);
        let hostSeg : number = ((prefixedAddress.getPrefixLength() + (MACAddress.BITS_PER_SEGMENT - 1)) / MACAddress.BITS_PER_SEGMENT|0);
        let replaced : MACAddress = prefixedAddress;
        let replacement : MACAddress = this.createMACAddress$java_lang_String("1:1:1:1:1:1").getAddress();
        for(let i : number = hostSeg; i < replaced.getSegmentCount(); i++) {
            replaced = replaced.replace(i, i + 1, replacement, i);
        };
        if(lower.equals(upper)) {
            this.addFailure(new TestBase.Failure("lower / upper " + lower + " / " + upper, prefixedAddress));
        }
        if(!prefixedAddress.isPrefixBlock()) {
            this.addFailure(new TestBase.Failure("not prefix block", prefixedAddress));
        }
        if(!adjustPrefix.isPrefixBlock()) {
            this.addFailure(new TestBase.Failure("adjustPrefix is not prefix block: " + adjustPrefix, prefixedAddress));
        }
        if(!adjustPrefix.isPrefixed()) {
            this.addFailure(new TestBase.Failure("adjustPrefix not prefixed: " + adjustPrefix.getPrefixLength(), prefixedAddress));
        }
        if(!adjustPrefix2.isPrefixed()) {
            this.addFailure(new TestBase.Failure("adjustPrefix2 not prefixed: " + adjustPrefix2.getPrefixLength(), prefixedAddress));
        }
        if(removedPrefix.isPrefixed()) {
            this.addFailure(new TestBase.Failure("removedPrefix prefixed: " + removedPrefix.getPrefixLength(), prefixedAddress));
        }
        if(!replaced.isPrefixed()) {
            this.addFailure(new TestBase.Failure("replaced prefixed: " + replaced.getPrefixLength(), prefixedAddress));
        }
        if(allPrefixesAreSubnets) {
            if(!replaced.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("replaced is prefix block: " + replaced, prefixedAddress));
            }
            if(!adjustPrefix2.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("adjustPrefix2 is not prefix block: " + adjustPrefix2, prefixedAddress));
            }
            if(lower.isPrefixed()) {
                this.addFailure(new TestBase.Failure("lower prefixed: " + lower, prefixedAddress));
            }
            if(lower.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("lower is prefix block: " + lower, prefixedAddress));
            }
            if(upper.isPrefixed()) {
                this.addFailure(new TestBase.Failure("upper prefixed: " + upper, prefixedAddress));
            }
            if(upper.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("upper is prefix block: " + upper, prefixedAddress));
            }
            lower = lower.applyPrefixLength(prefixedAddress.getPrefixLength());
            upper = upper.applyPrefixLength(prefixedAddress.getPrefixLength());
        } else {
            if(hostSeg < replaced.getSegmentCount() && replaced.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("replaced is prefix block: " + replaced, prefixedAddress));
            }
            if(adjustPrefix2.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("adjustPrefix2 is not prefix block: " + adjustPrefix2, prefixedAddress));
            }
            if(!lower.isPrefixed()) {
                this.addFailure(new TestBase.Failure("lower not prefixed: " + lower, prefixedAddress));
            }
            if(lower.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("lower is prefix block: " + lower, prefixedAddress));
            }
            if(!upper.isPrefixed()) {
                this.addFailure(new TestBase.Failure("upper not prefixed: " + upper, prefixedAddress));
            }
            if(upper.isPrefixBlock()) {
                this.addFailure(new TestBase.Failure("upper is prefix block: " + upper, prefixedAddress));
            }
        }
        let prefixedBlockAgain : MACAddress = lower.toPrefixBlock();
        if(!prefixedBlockAgain.isPrefixBlock()) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block not a prefix block: " + prefixedBlockAgain, prefixedAddress));
        }
        if(!prefixedBlockAgain.equals(prefixedAddress)) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch: " + prefixedBlockAgain + " original: " + prefixedAddress, prefixedAddress));
        }
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),prefixedAddress.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block prefix mismatch: " + prefixedBlockAgain.getPrefixLength() + " original: " + prefixedAddress.getPrefixLength(), prefixedAddress));
        }
        removedPrefix = removedPrefix.applyPrefixLength(prefixedAddress.getPrefixLength());
        adjustPrefix = adjustPrefix.adjustPrefixLength$int(-1);
        adjustPrefix2 = adjustPrefix2.adjustPrefixLength$int(1);
        if(!prefixedBlockAgain.equals(removedPrefix.toPrefixBlock()) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),removedPrefix.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch with other: " + prefixedBlockAgain + " other: " + removedPrefix, prefixedAddress));
        }
        if(!prefixedBlockAgain.equals(adjustPrefix.toPrefixBlock()) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),adjustPrefix.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch with other: " + prefixedBlockAgain + " other: " + adjustPrefix, prefixedAddress));
        }
        if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),adjustPrefix2.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch with other: " + prefixedBlockAgain + " other: " + adjustPrefix2, prefixedAddress));
        }
        if(!prefixedBlockAgain.equals(replaced.toPrefixBlock()) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),replaced.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch with other: " + prefixedBlockAgain + " other: " + replaced, prefixedAddress));
        }
        if(!prefixedBlockAgain.equals(upper.toPrefixBlock()) || !/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(prefixedBlockAgain.getPrefixLength(),upper.getPrefixLength()))) {
            this.addFailure(new TestBase.Failure("reconstituted prefix block mismatch with other: " + prefixedBlockAgain + " other: " + upper, prefixedAddress));
        }
        this.incrementTestCount();
    }

    /*private*/ testTree(start : string, parents : string[]) {
        try {
            let str : MACAddressString = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(start, MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$());
            let addr : MACAddress = str.getAddress();
            let i : number = 0;
            let j : number = 0;
            let pref : number;
            let brokeEarly : boolean = false;
            do {
                let label : string = MACAddressRangeTest.getLabel(addr.toAddressString());
                let expected : string = parents[i];
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(label,expected))) {
                    this.addFailure(new TestBase.Failure("failed expected: " + expected + " actual: " + label, str));
                    brokeEarly = true;
                    break;
                }
                pref = addr.getPrefixLength();
                addr = addr.adjustPrefixBySegment$boolean$boolean(false, false);
                if(AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets()) {
                    i++;
                }
                j++;
            } while((pref == null || pref !== 0));
            if(!brokeEarly && j !== parents.length) {
                this.addFailure(new TestBase.Failure("failed: invalid label count " + parents.length + " expected " + j));
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("failed: " + e + " " + start));
        };
        this.incrementTestCount();
    }

    /*private*/ static getLabel(addressString : MACAddressString) : string {
        let address : MACAddress = addressString.getAddress();
        if(address == null) {
            return addressString.toString();
        }
        return address.toNormalizedString();
    }

    /*private*/ testTrees() {
        this.testTree("1:2:0-8f:*", ["01:02:00-8f:*:*:*", "01:02:*:*:*:*", "01:*:*:*:*:*", "*:*:*:*:*:*"]);
        this.testTree("a:b:c:d:e:f", ["0a:0b:0c:0d:0e:0f", "0a:0b:0c:0d:0e:*", "0a:0b:0c:0d:*:*", "0a:0b:0c:*:*:*", "0a:0b:*:*:*:*", "0a:*:*:*:*:*", "*:*:*:*:*:*"]);
        this.testTree("a:b:c:d:e:f:a:b", ["0a:0b:0c:0d:0e:0f:0a:0b", "0a:0b:0c:0d:0e:0f:0a:*", "0a:0b:0c:0d:0e:0f:*:*", "0a:0b:0c:0d:0e:*:*:*", "0a:0b:0c:0d:*:*:*:*", "0a:0b:0c:*:*:*:*:*", "0a:0b:*:*:*:*:*:*", "0a:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*"]);
        this.testTree("a:b:c:d:e:f:a0-bf:*", ["0a:0b:0c:0d:0e:0f:a0-bf:*", "0a:0b:0c:0d:0e:0f:*:*", "0a:0b:0c:0d:0e:*:*:*", "0a:0b:0c:0d:*:*:*:*", "0a:0b:0c:*:*:*:*:*", "0a:0b:*:*:*:*:*:*", "0a:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*"]);
        this.testTree("a:b:c:d:e:f:a2-a3:*", ["0a:0b:0c:0d:0e:0f:a2-a3:*", "0a:0b:0c:0d:0e:0f:*:*", "0a:0b:0c:0d:0e:*:*:*", "0a:0b:0c:0d:*:*:*:*", "0a:0b:0c:*:*:*:*:*", "0a:0b:*:*:*:*:*:*", "0a:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*"]);
        this.testTree("a:b:c:d:e:f:1f-80:*", ["0a:0b:0c:0d:0e:0f:1f-80:*", "0a:0b:0c:0d:0e:0f:*:*", "0a:0b:0c:0d:0e:*:*:*", "0a:0b:0c:0d:*:*:*:*", "0a:0b:0c:*:*:*:*:*", "0a:0b:*:*:*:*:*:*", "0a:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*"]);
        this.testTree("a:b:c:11-12:*", ["0a:0b:0c:11-12:*:*", "0a:0b:0c:*:*:*", "0a:0b:*:*:*:*", "0a:*:*:*:*:*", "*:*:*:*:*:*"]);
    }

    public testStrings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, cidrString? : any, compressedWildcardString? : any, reverseDNSString? : any, uncHostString? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof cidrString === 'string') || cidrString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testStrings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, cidrString, compressedWildcardString, reverseDNSString, uncHostString, singleHex, singleOctal);
        } else if(w === undefined && ipAddr === undefined && normalizedString === undefined && normalizedWildcardString === undefined && canonicalWildcardString === undefined && sqlString === undefined && fullString === undefined && compressedString === undefined && canonicalString === undefined && subnetString === undefined && cidrString === undefined && compressedWildcardString === undefined && reverseDNSString === undefined && uncHostString === undefined && singleHex === undefined && singleOctal === undefined) {
            return <any>this.testStrings$();
        } else throw new Error('invalid overload');
    }

    testStrings$() {
        super.testStrings();
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*:*:*", "0a:0b:0c:0d:*:*:*:*", "a:b:c:d:*:*:*:*", "0a-0b-0c-0d-*-*-*-*", "0a0b.0c0d.*.*", "0a 0b 0c 0d * * * *", "0a0b0c0d00000000-0a0b0c0dffffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:*:*:*:*", "0a:0b:0c:*:*:*:*:*", "a:b:c:*:*:*:*:*", "0a-0b-0c-*-*-*-*-*", "0a0b.0c00-0cff.*.*", "0a 0b 0c * * * * *", "0a0b0c0000000000-0a0b0cffffffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:*", "0a:0b:0c:0d:*:*", "a:b:c:d:*:*", "0a-0b-0c-0d-*-*", "0a0b.0c0d.*", "0a 0b 0c 0d * *", "0a0b0c0d0000-0a0b0c0dffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a:b:c:d:1-2:*", "0a:0b:0c:0d:01-02:*", "a:b:c:d:1-2:*", "0a-0b-0c-0d-01|02-*", "0a0b.0c0d.0100-02ff", "0a 0b 0c 0d 01-02 *", "0a0b0c0d0100-0a0b0c0d02ff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0:0:c:d:e:f:10-1f:b", "00:00:0c:0d:0e:0f:10-1f:0b", "0:0:c:d:e:f:10-1f:b", "00-00-0c-0d-0e-0f-10|1f-0b", null, "00 00 0c 0d 0e 0f 10-1f 0b", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0:0:c:d:e:f:10-1f:*", "00:00:0c:0d:0e:0f:10-1f:*", "0:0:c:d:e:f:10-1f:*", "00-00-0c-0d-0e-0f-10|1f-*", "0000.0c0d.0e0f.1000-1fff", "00 00 0c 0d 0e 0f 10-1f *", "00000c0d0e0f1000-00000c0d0e0f1fff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("a-b:b-c:0c-0d:0d-e:e-0f:f-ff:aa-bb:bb-cc", "0a-0b:0b-0c:0c-0d:0d-0e:0e-0f:0f-ff:aa-bb:bb-cc", "a-b:b-c:c-d:d-e:e-f:f-ff:aa-bb:bb-cc", "0a|0b-0b|0c-0c|0d-0d|0e-0e|0f-0f|ff-aa|bb-bb|cc", null, "0a-0b 0b-0c 0c-0d 0d-0e 0e-0f 0f-ff aa-bb bb-cc", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("12-ef:*:cd:d:0:*", "12-ef:*:cd:0d:00:*", "12-ef:*:cd:d:0:*", "12|ef-*-cd-0d-00-*", "1200-efff.cd0d.0000-00ff", "12-ef * cd 0d 00 *", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ff:ff:*:*:aa-ff:0-de", "ff:ff:*:*:aa-ff:00-de", "ff:ff:*:*:aa-ff:0-de", "ff-ff-*-*-aa|ff-00|de", null, "ff ff * * aa-ff 00-de", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ff:ff:aa-ff:*:*:*", "ff:ff:aa-ff:*:*:*", "ff:ff:aa-ff:*:*:*", "ff-ff-aa|ff-*-*-*", "ffff.aa00-ffff.*", "ff ff aa-ff * * *", "ffffaa000000-ffffffffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ff:f:aa-ff:*:*:*", "ff:0f:aa-ff:*:*:*", "ff:f:aa-ff:*:*:*", "ff-0f-aa|ff-*-*-*", "ff0f.aa00-ffff.*", "ff 0f aa-ff * * *", "ff0faa000000-ff0fffffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("ff:ff:ee:aa-ff:*:*", "ff:ff:ee:aa-ff:*:*", "ff:ff:ee:aa-ff:*:*", "ff-ff-ee-aa|ff-*-*", "ffff.eeaa-eeff.*", "ff ff ee aa-ff * *", "ffffeeaa0000-ffffeeffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*", "*:*:*:*:*:*", "*:*:*:*:*:*", "*-*-*-*-*-*", "*.*.*", "* * * * * *", "000000000000-ffffffffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1-3:2:33:4:55-60:6", "01-03:02:33:04:55-60:06", "1-3:2:33:4:55-60:6", "01|03-02-33-04-55|60-06", null, "01-03 02 33 04 55-60 06", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("f3:2:33:4:6:55-60", "f3:02:33:04:06:55-60", "f3:2:33:4:6:55-60", "f3-02-33-04-06-55|60", "f302.3304.0655-0660", "f3 02 33 04 06 55-60", "f30233040655-f30233040660");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*-b00cff", "*:*:*:b0:0c:ff", "*:*:*:b0:c:ff", "*-*-*-b0-0c-ff", null, "* * * b0 0c ff", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0aa0bb-*", "0a:a0:bb:*:*:*", "a:a0:bb:*:*:*", "0a-a0-bb-*-*-*", "0aa0.bb00-bbff.*", "0a a0 bb * * *", "0aa0bb000000-0aa0bbffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0000aa|0000bb-000b00|000cff", "00:00:aa-bb:00:0b-0c:*", "0:0:aa-bb:0:b-c:*", "00-00-aa|bb-00-0b|0c-*", null, "00 00 aa-bb 00 0b-0c *", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("c000aa|c000bb-c00b00|c00cff", "c0:00:aa-bb:c0:0b-0c:*", "c0:0:aa-bb:c0:b-c:*", "c0-00-aa|bb-c0-0b|0c-*", null, "c0 00 aa-bb c0 0b-0c *", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0000aa|0000bb-000b00", "00:00:aa-bb:00:0b:00", "0:0:aa-bb:0:b:0", "00-00-aa|bb-00-0b-00", null, "00 00 aa-bb 00 0b 00", null);
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0000bb-000b00|000cff", "00:00:bb:00:0b-0c:*", "0:0:bb:0:b-c:*", "00-00-bb-00-0b|0c-*", "0000.bb00.0b00-0cff", "00 00 bb 00 0b-0c *", "0000bb000b00-0000bb000cff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("0000aa|0000bb-*", "00:00:aa-bb:*:*:*", "0:0:aa-bb:*:*:*", "00-00-aa|bb-*-*-*", "0000.aa00-bbff.*", "00 00 aa-bb * * *", "0000aa000000-0000bbffffff");
        this.testMACStrings$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*-000b00|000cff", "*:*:*:00:0b-0c:*", "*:*:*:0:b-c:*", "*-*-*-00-0b|0c-*", null, "* * * 00 0b-0c *", null);
    }

    /**
     * 
     * @return {boolean}
     */
    allowsRange() : boolean {
        return true;
    }

    /**
     * 
     */
    runTest() {
        this.testEquivalentPrefix$java_lang_String$int("*:*", 0);
        this.testEquivalentPrefix$java_lang_String$int("*:*:*:*:*:*", 0);
        this.testEquivalentPrefix$java_lang_String$int("*:*:*:*:*:*:*:*", 0);
        this.testEquivalentPrefix$java_lang_String$int("80-ff:*", 1);
        this.testEquivalentPrefix$java_lang_String$int("0-7f:*", 1);
        this.testEquivalentPrefix$java_lang_String$int("1:2:*", 16);
        this.testEquivalentPrefix$java_lang_String$int("1:2:*:*:*:*", 16);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:*:0:*:*", null, 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:*:0:0:0", null, 48);
        this.testEquivalentPrefix$java_lang_String$int("1:2:80-ff:*", 17);
        this.testEquivalentPrefix$java_lang_String$int("1:2:00-7f:*", 17);
        this.testEquivalentPrefix$java_lang_String$int("1:2:c0-ff:*", 18);
        this.testEquivalentPrefix$java_lang_String$int("1:2:00-3f:*", 18);
        this.testEquivalentPrefix$java_lang_String$int("1:2:80-bf:*", 18);
        this.testEquivalentPrefix$java_lang_String$int("1:2:40-7f:*", 18);
        this.testEquivalentPrefix$java_lang_String$int("1:2:fc-ff:*", 22);
        this.testEquivalentPrefix$java_lang_String$int("1:2:fc-ff:0-ff:*", 22);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fd-ff:0-ff:*", null, 24);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fc-ff:0-fe:*", null, 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fb-ff:0-fe:*", null, 32);
        this.testEquivalentPrefix$java_lang_String$java_lang_Integer$int("1:2:fb-ff:0-ff:*", null, 24);
        this.testReverse$java_lang_String$boolean$boolean("1:2:*:4:5:6", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:1-ff:2:3:3", false, false);
        this.testReverse$java_lang_String$boolean$boolean("1:1:0-fe:1-fe:*:1", false, false);
        this.testReverse$java_lang_String$boolean$boolean("ff:80:*:ff:01:ff", false, false);
        this.testReverse$java_lang_String$boolean$boolean("ff:80:fe:7f:01:ff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ff:80:*:*:01:ff", true, false);
        this.testReverse$java_lang_String$boolean$boolean("ff:81:ff:*:1-fe:ff", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:81:c3:42:24:0-fe", false, true);
        this.testReverse$java_lang_String$boolean$boolean("ff:1:ff:ff:*:*", false, false);
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].allPrefixedAddressesAreSubnets();
        if(isAllSubnets) {
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("25:51:27:12:82:55", 16, -5, "25:51:27:12:82:55", "25:51:27:12:82:*", "25:51:27:12:82:40-5f", "25:51:*:*:*:*", "25:51:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("25:51:27:*:*:*", 16, -5, "25:51:27:00:*:*", "25:51:*:*:*:*", "25:51:20-3f:*:*:*", "25:51:*:*:*:*", "25:51:*:*:*:*");
        } else {
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("25:51:27:12:82:55", 16, -5, "25:51:27:12:82:55", "25:51:27:12:82:0", "25:51:27:12:82:40", "25:51:0:0:0:0", "25:51:0:0:0:0");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("25:51:27:*:*:*", 16, -5, "25:51:27:00:*:*", "25:51:0:*:*:*", "25:51:20:*:*:*", "25:51:0:*:*:*", "25:51:0:*:*:*");
        }
        if(isAllSubnets) {
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*:*:*:*:*:0-fe:*", 15, 2, "*:*:*:*:*:*:0-fe:0", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:0-fe:0-3f", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*:*:*:*:*:*:*", 15, 2, "0:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "0-3f:*:*:*:*:*:*:*", "0:0-1:*:*:*:*:*:*", "*:*:*:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:*:*:*:*:*", 15, 2, "1:0:*:*:*:*", "*:*:*:*:*:*", "1:0-3f:*:*:*:*", "1:0-1:*:*:*:*", "1:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("3.8000-ffff.*.*", 15, 2, "3.8000-80ff.*.*", "3.*.*.*", "3.8000-9fff.*.*", "2-3.*.*.*", "2-3.*.*.*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("3.8000-ffff.*.*", 31, 2, "3.8000-80ff.*.*", "3.*.*.*", "3.8000-9fff.*.*", "3.8000-8001.*.*", "3.8000-ffff.*.*");
        } else {
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*:*:*:*:*:0-fe:*", 15, 2, "*:*:*:*:*:*:0-fe:0", "*:*:*:*:*:*:0:*", "*:*:*:*:*:*:0-fe:0-3f", "*:00-fe:00:00:00:00:00:*", "*:00-fe:00:00:00:00:00:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*:*:*:*:*:*:*", 15, 2, "0:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "0-3f:*:*:*:*:*:*:*", "0:0-1:*:*:*:*:*:*", "*:*:*:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("1:*:*:*:*:*", 15, 2, "1:0:*:*:*:*", "0:*:*:*:*:*", "1:0-3f:*:*:*:*", "1:0-1:*:*:*:*", "1:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("3.8000-ffff.*.*", 15, 2, "3.8000-80ff.*.*", "00:03:00-7f:*:*:*:*:*", "3.8000-9fff.*.*", "00:02:00-7f:*:*:*:*:*", "00:02:00-7f:*:*:*:*:*");
            this.testPrefixes$java_lang_String$int$int$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("3.8000-ffff.*.*", 31, 2, "3.8000-80ff.*.*", "00:03:00-7f:*:*:*:*:*", "3.8000-9fff.*.*", "3.8000-8001.*.*", "3.8000-ffff.*.*");
        }
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("25:51:27:*:*:*", 24, 24);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("25:50-51:27:*:*:*", 24, null);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("25:51:27:12:82:55", null, 48);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*", 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*:*:*", 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*:0-fe:*", 56, null);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*:0-ff:*", 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*:0-7f:*", 49, null);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*:*:*:*:*:*:80-ff:*", 49, null);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("*.*.*.*", 0, 0);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("3.*.*.*", 16, 16);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("3.*.*.1-3", null, null);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("3.0-7fff.*.*", 17, 17);
        this.testPrefix$java_lang_String$java_lang_Integer$java_lang_Integer("3.8000-ffff.*.*", 17, 17);
        this.testToOUIPrefixed("25:51:27:*:*:*");
        this.testToOUIPrefixed("*:*:*:*:*:*");
        this.testToOUIPrefixed("*:*:*:25:51:27");
        this.testToOUIPrefixed("ff:ee:25:51:27:*:*:*");
        this.testToOUIPrefixed("*:*:*:*:*:*:*:*");
        this.testToOUIPrefixed("*:*:*:25:51:27:ff:ee");
        this.testToOUIPrefixed("123.456.789.abc");
        this.testToOUIPrefixed("123.456.789.*");
        this.testOUIPrefixed("ff:7f:fe:2:7f:fe", "ff:7f:fe:*", 24);
        this.testOUIPrefixed("ff:7f:fe:2:7f:*", "ff:7f:fe:*", 24);
        this.testOUIPrefixed("ff:7f:fe:*", "ff:7f:fe:*", 24);
        this.testOUIPrefixed("ff:*", "ff:*", 8);
        this.testOUIPrefixed("ff:7f:fe:2:7f:fe:7f:fe", "ff:7f:fe:*:*:*:*:*", 24);
        this.testOUIPrefixed("ff:7f:0-f:*", "ff:7f:0-f:*", 20);
        this.testTrees();
        this.testDelimitedCount("1,2|3,4-3-4,5-6-7-8", 8);
        this.testDelimitedCount("1,2-3,6-7-8-4,5|6-6,8", 16);
        this.testDelimitedCount("1:2:3:*:4:5", 1);
        this.testDelimitedCount("1:2,3,*:3:6:4:5,ff,7,8,99", 15);
        this.testDelimitedCount("1:0,1-2,3,5:3:6:4:5,ff,7,8,99", 30);
        this.testLongShort$java_lang_String$java_lang_String$boolean("ff:ff:ff:ff:ff:*:ff:1-ff", "ff:ff:ff:*:ff:1-ff", true);
        this.testLongShort$java_lang_String$java_lang_String$boolean("12-cd-cc-dd-ee-ff-*", "12-cd-cc-*", true);
        this.testLongShort$java_lang_String$java_lang_String$boolean("12CD.CCdd.*.a", "12CD.*.a", true);
        this.testLongShort$java_lang_String$java_lang_String$boolean("*-0D0E0F0A0B", "0A0B0C-*", true);
        this.testLongShort$java_lang_String$java_lang_String("*-0D0E0F0A0B", "*-0A0B0C");
        this.testLongShort$java_lang_String$java_lang_String$boolean("*-0D0E0F0A0B", "*-*", true);
        this.testLongShort$java_lang_String$java_lang_String("ee:ff:aa:*:dd:ee:ff", "ee:ff:a-b:bb:cc:dd");
        this.testLongShort$java_lang_String$java_lang_String$boolean("ee:ff:aa:*:dd:ee:ff", "ee:ff:a-b:*:dd", true);
        this.testLongShort$java_lang_String$java_lang_String$boolean("e:f:a:b:c:d:e:e-f", "e:*", true);
        this.testMatches(true, "aa:-1:cc:d:ee:f", "aa:0-1:cc:d:ee:f");
        this.testMatches(true, "aa:-:cc:d:ee:f", "aa:*:cc:d:ee:f");
        this.testMatches(true, "-:-:cc:d:ee:f", "*:cc:d:ee:f");
        this.testMatches(true, "aa:-dd:cc:d:ee:f", "aa:0-dd:cc:d:ee:f");
        this.testMatches(true, "aa:1-:cc:d:ee:f", "aa:1-ff:cc:d:ee:f");
        this.testMatches(true, "-1:aa:cc:d:ee:f", "0-1:aa:cc:d:ee:f");
        this.testMatches(true, "1-:aa:cc:d:ee:f", "1-ff:aa:cc:d:ee:f");
        this.testMatches(true, "aa:cc:d:ee:f:1-", "aa:cc:d:ee:f:1-ff");
        this.testMatches(true, "aa-|1-cc-d-ee-f", "aa-0|1-cc-d-ee-f");
        this.testMatches(true, "|1-aa-cc-d-ee-f", "0|1-aa-cc-d-ee-f");
        this.testMatches(true, "aa-1|-cc-d-ee-f", "aa-1|ff-cc-d-ee-f");
        this.testMatches(true, "1|-aa-cc-d-ee-f", "1|ff-aa-cc-d-ee-f");
        this.testMatches(true, "|-aa-cc-d-ee-f", "*-aa-cc-d-ee-f");
        this.testMatches(true, "|-|-cc-d-ee-f", "*-cc-d-ee-f");
        this.testMatches(true, "|-|-cc-d-ee-|", "*-*-cc-d-ee-*");
        this.testMatches(true, "|-|-cc-d-ee-2|", "*-*-cc-d-ee-2|ff");
        this.testMatches(true, "|-|-cc-d-ee-|2", "*-*-cc-d-ee-0|2");
        this.testMatches(true, "*-|-*", "*-*");
        this.testMatches(true, "*-|-|", "*-*");
        this.testMatches(true, "|-|-*", "*:*");
        this.testMatches(true, "*:*:*:*:*:*", "*:*");
        this.testMatches(true, "1:*:*:*:*:*", "1:*");
        this.testMatches(true, "*:*:*:*:*:1", "*:1");
        this.testMatches(true, "*:*:*:12:34:56", "*-123456");
        this.testMatches(true, "12:34:56:*:*:*", "123456-*");
        this.testMatches(true, "1:*:*:*:*:*", "1-*");
        this.testMatches(true, "*:*:*:*:*:1", "*-1");
        this.testMatches(true, "*-*-*", "*:*:*");
        this.testMatches(true, "*-*", "*:*:*");
        this.testMatches(true, "bbaacc0dee0f", "bb:aa:cc:d:ee:f");
        this.testMatches(true, "bbaacc0dee0faab0", "bb:aa:cc:d:ee:f:aa:b0");
        this.mactest$boolean$java_lang_String(false, "*|1");
        this.mactest$boolean$java_lang_String(false, "1|*");
        this.mactest$boolean$java_lang_String(true, "*-1");
        this.mactest$boolean$java_lang_String(true, "1-*");
        this.mactest$boolean$java_lang_String(true, "*-*");
        this.mactest$boolean$java_lang_String(true, "*:1");
        this.mactest$boolean$java_lang_String(true, "1:*");
        this.mactest$boolean$java_lang_String(true, "*:*");
        this.mactest$boolean$java_lang_String(false, "1:1");
        this.mactest$boolean$java_lang_String(false, "1-1");
        this.mactest$boolean$java_lang_String(true, "0xaabbccddeeee-0xaabbccddeeff");
        this.mactest$boolean$java_lang_String(true, "0xaabbccddeeee-aabbccddeeff");
        this.mactest$boolean$java_lang_String(true, "aabbccddeeee-0xaabbccddeeff");
        this.mactest$boolean$java_lang_String(true, "aabbccddeeee-aabbccddeeff");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-|1-*-d-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "|1-aa-cc-*-ee-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-1|-cc-d-*-f");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "1|-aa-cc-d-*");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-0|1-cc-*");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "aa-1|ff-*");
        this.mactest$boolean$java_lang_String(this.allowsRange(), "*-1|ff-*");
        this.mactest$boolean$java_lang_String(true, "aa0000|abffff-ddeeff");
        this.mactest$boolean$java_lang_String(true, "aa0000|abffff-*");
        this.mactest$boolean$java_lang_String(false, "aabbcc|ddeeff-ddeefff");
        this.mactest$boolean$java_lang_String(false, "aabbcc|aabbcd-ddeefffff");
        this.mactest$boolean$java_lang_String(true, "aabbcc|aabbcd-ddeeffffff");
        this.mactest$boolean$java_lang_String(false, "aabbcc|aabbcd-ddeefffffff");
        this.mactest$boolean$java_lang_String(true, "aabbcc|aabbcd-*");
        this.mactest$boolean$java_lang_String(false, "aabbcc|aabbcd-ddeefffffff");
        this.mactest$boolean$java_lang_String(true, "ddeeff-aa0000|afffff");
        this.mactest$boolean$java_lang_String(true, "*-aa0000|afffff");
        this.mactest$boolean$java_lang_String(false, "ddeefff-aabbcc|ddeeff");
        this.mactest$boolean$java_lang_String(true, "ddeeff-aabbffffcc|aabbffffdd");
        this.mactest$boolean$java_lang_String(false, "ddeeff-aabbffffccc|aabbffffddd");
        this.mactest$boolean$java_lang_String(false, "ddeeff-aabbffffc|aabbffffd");
        this.mactest$boolean$java_lang_String(false, "ddeefffffff-aabbcc|aabbcd");
        this.testMACIPv6("aaaa:bbbb:cccc:dddd:0221:2fff:fe00-feff:6e10", "00:21:2f:*:6e:10");
        this.testMACIPv6("*:*:*:*:200-2ff:FF:FE00-FEFF:*", "0:*:0:*:*:*");
        this.testMACIPv6("*:*:*:*:200-3ff:abFF:FE01-FE03:*", "0-1:*:ab:1-3:*:*");
        this.testMACIPv6("*:*:*:*:a200-a3ff:abFF:FE01-FE03:*", "a0-a1:*:ab:1-3:*:*");
        this.testMACIPv6("*:2:*:*:a388-a399:abFF:FE01-FE03:*", "a1:88-99:ab:1-3:*:*");
        this.testMACIPv6("*:2:*:*:a388-a399:abFF:FE01-FE03:*", "a1:88-99:ab:1-3:*:*");
        this.testMACIPv6("1:0:0:0:8a0:bbff:fe00-feff:*", "0a:a0:bb:*:*:*");
        this.testMACIPv6("1:0:0:0:200:bbff:fe00:b00-cff", "00:00:bb:00:0b-0c:*");
        this.testMACIPv6("1:0:0:0:200:bbff:fe00:b00-cff", "00:00:bb:00:0b-0c:*");
        this.testMACIPv6("1:0:0:0:c200:aaff:fec0:b00-cff", "c0:00:aa:c0:0b-0c:*");
        this.testMACIPv6("1:0:0:0:200:aaff:fe00:b00", "00:00:aa:00:0b:00");
        this.testMACIPv6("1:0:0:0:200:bbff:fe00:b00-cff", "00:00:bb:00:0b-0c:*");
        this.testMACIPv6("1:0:0:0:200:bbff:fe00-feff:*", "00:00:bb:*:*:*");
        this.testNotContains("*.*", "1.2.3.4");
        this.testContains("*.*.*.*", "1.2.3.4", false);
        this.testContains("*.*.*", "1.2.3", false);
        this.testContains("*.*.1.aa00-ffff", "1.2.1.bbbb", false);
        this.testContains("*.*.1.aa00-ffff", "0-ffff.*.1.aa00-ffff", true);
        this.testContains("0-1ff.*.*.*", "127.2.3.4", false);
        this.testContains("0-1ff.*.*.*", "128.2.3.4", false);
        this.testNotContains("0-1ff.*", "200.2.3.4");
        this.testNotContains("0-1ff.*", "128.2.3.4");
        this.testContains("0-1ff.*", "128.2.3", false);
        this.testContains("0-ff.*.*.*", "15.2.3.4", false);
        this.testContains("0-ff.*", "15.2.3", false);
        this.testContains("9.129.*.*", "9.129.237.26", false);
        this.testContains("9.129.*", "9.129.237", false);
        this.testNotContains("9.129.*.25", "9.129.237.26");
        this.testContains("9.129.*.26", "9.129.237.26", false);
        this.testContains("9.129.*.26", "9.129.*.26", true);
        this.testContains("9.a0-ae.1.226-254", "9.ad.1.227", false);
        this.testNotContains("9.a0-ac.1.226-254", "9.ad.1.227");
        this.testNotContains("9.a0-ae.2.226-254", "9.ad.1.227");
        this.testContains("9.a0-ae.1.226-254", "9.a0-ae.1.226-254", true);
        this.testContains("8-9:a0-ae:1-3:20-26:0:1", "9:ad:1:20:0:1", false);
        this.testContains("8-9:a0-ae:1-3:20-26:0:1", "9:ad:1:23-25:0:1", false);
        this.testNotContains("8-9:a0-ae:1-3:20-26:0:1", "9:ad:1:23-27:0:1");
        this.testNotContains("8-9:a0-ae:1-3:20-26:0:1", "9:ad:1:18-25:0:1");
        this.testContains("*:*:*:*:ab:*:*:*", "*:*:*:*:ab:*:*:*", true);
        this.testContains("*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", true);
        this.testContains("*:*:*:*:*:*:*:*", "a:b:c:d:e:f:a:b", false);
        this.testContains("*:*:*:*:*:*", "a:b:c:d:a:b", false);
        this.testContains("80-8f:*:*:*:*:*", "8a:d:e:f:a:b", false);
        this.testContains("*:*:*:*:*:80-8f", "d:e:f:a:b:8a", false);
        this.testContains("*:*:*:*:*:*:*:*", "a:*:c:d:e:1-ff:a:b", false);
        this.testContains("8a-8d:*:*:*:*:*:*:*", "8c:b:c:d:e:f:*:b", false);
        this.testNotContains("80:0:0:0:0:0:0:0-1", "7f-8f:b:c:d:e:f:*:b");
        this.testContains("ff:0-3:*:*:*:*:*:*", "ff:0-3:c:d:e:f:a:b", false);
        this.testNotContains("ff:0-3:*:*:*:*:*:*", "ff:0-4:c:d:e:f:a:b");
        this.testContains("ff:0:*:*:*:*:*:*", "ff:0:ff:1-d:e:f:*:b", false);
        this.testContains("*:*:ff:0:*:*:*:*", "*:b:ff:0:ff:1-d:e:f", false);
        this.testNotContains("ff:0:*:*:*:*:*:*", "ff:0-1:ff:d:e:f:a:b");
        this.testContains("ff:0:0:0:0:4-ff:0:fc-ff", "ff:0:0:0:0:4-ff:0:fd-ff", false);
        this.testContains("ff:0:0:0:0:4-ff:0:fc-ff", "ff:0:0:0:0:4-ff:0:fc-ff", true);
        this.testContains("ff:0:*:0:0:4-ff:0:ff", "ff:0:*:0:0:4-ff:0:ff", true);
        this.testContains("*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", true);
        this.testContains("80-8f:*:*:*:*:80-8f", "83-8e:*:*:*:a-b:80-8f", false);
        this.testContains("80-8f:*:*:*:*:80-8f", "83-8e:*:*:*:a-b:80-8f", false);
        this.testNotContains("80-8f:*:*:*:*:80-8f", "7f-8e:*:*:*:a-b:80-8f");
        this.testSections("00-1:21-ff:*:10");
        this.testSections("00-1:21-ff:2f:*:10");
        this.testSections("*-A7-94-07-CB-*");
        this.testSections("aa-*");
        this.testSections("aa-bb-*");
        this.testSections("aa-bb-cc-*");
        this.testSections("8-9:a0-ae:1-3:20-26:0:1");
        this.testSections("fe-ef-39-*-94-07-b|C-D0");
        this.testSections("5634-5678.*.7feb.6b40");
        this.testSections("ff:0:1:*");
        this.testSections("ff:0:1:*:*:*:*:*");
        this.testRadices("11:10:*:1-7f:f3:2", "10001:10000:*:1-1111111:11110011:10", 2);
        this.testRadices("0:1:0:1:0-1:1:0:1", "0:1:0:1:0-1:1:0:1", 2);
        this.testRadices("f3-ff:7f:fe:*:7_:fe", "f3-ff:7f:fe:*:70-7f:fe", 16);
        this.testRadices("*:1:0:1:0-1:1:0:1", "*:1:0:1:0-1:1:0:1", 16);
        this.testRadices("ff:7f:*:2:7_:fe", "255:127:*:2:112-127:254", 10);
        this.testRadices("*:1:0:1:0-1:1:0:1", "*:1:0:1:0-1:1:0:1", 10);
        this.testRadices("ff:*:fe:2:7d-7f:fe", "513:*:512:2:236-241:512", 7);
        this.testRadices("1:0:0-1:0:1:*", "1:0:0-1:0:1:*", 7);
        this.testRadices("ff:70-7f:fe:2:*:fe", "377:160-177:376:2:*:376", 8);
        this.testRadices("1:0:0-1:0:1:*", "1:0:0-1:0:1:*", 8);
        this.testRadices("ff:7f:fa-fe:2:7f:*", "120:87:11a-11e:2:87:*", 15);
        this.testRadices("1:0:0-1:0:1:*", "1:0:0-1:0:1:*", 15);
        this.testCount$java_lang_String$int("11:22:33:44:55:ff", 1);
        this.testCount$java_lang_String$int("11:22:*:0-2:55:ff", 3 * 256);
        this.testCount$java_lang_String$int("11:22:2:0-2:55:*", 3 * 256);
        this.testCount$java_lang_String$int("11:2-4:1:0-2:55:ff", 9);
        this.testCount$java_lang_String$int("112-114.1.0-2.55ff", 9);
        this.testCount$java_lang_String$int("*.1.0-2.55ff", 3 * 65536);
        this.testCount$java_lang_String$int("1-2.1-2.1-2.2-3", 16);
        this.testCount$java_lang_String$int("1-2.1.*.2-3", 4 * 65536);
        this.testCount$java_lang_String$int("11:*:*:0-2:55:ff", 3 * 256 * 256);
        this.testPrefixCount$java_lang_String$int("11:22:*:0-2:55:ff", 3 * 256);
        this.testPrefixCount$java_lang_String$int("11:22:*:0-2:55:*", 3 * 256);
        this.testPrefixCount$java_lang_String$int("11:22:1:2:55:*", 1);
        this.testMatches(true, "1-02.03-4.05-06.07", "1-2.3-4.5-6.7");
        this.testMatches(true, "1-002.003-4.005-006.007", "1-2.3-4.5-6.7");
        this.testMatches(true, "1-002.003-4.0005-006.0007", "1-2.3-4.5-6.7");
        this.testMatches(true, "1100-22ff.003-4.0005-006.0007", "1100-22ff.3-4.5-6.7");
        this.testMatches(true, "1-2.0-0.00-00.00-0", "1-2.0.0.0");
        this.testMatches(true, "00-0.0-0.00-00.00-0", "0.0.0.0");
        this.testMatches(true, "0-00:0-0:00-00:00-0:0-00:00-00:00-00:00-0", "0:0:0:0:0:0:0:0");
        this.testMatches(true, "1-2:0-0:00-00:00-0:0-00:00-00:00-00:00-0", "1-2:0:0:0:0:0:0:0");
        this.mactest$int$java_lang_String(1, "11:11:11:ff:_:0");
        this.mactest$int$java_lang_String(1, "_:11:11:11:1:1");
        this.mactest$int$java_lang_String(1, "1:2:3:4:_:6:7:8");
        this.mactest$int$java_lang_String(1, "1:2:_:4:5:6:8:7");
        this.mactest$int$java_lang_String(1, "1:3:4:5:6:_");
        this.mactest$int$java_lang_String(1, "1:2:3:_:5:6:8:7");
        this.mactest$int$java_lang_String(1, "_:2:3:5:ff:8");
        this.mactest$int$java_lang_String(1, "1:11:11:11:1:_");
        this.mactest$int$java_lang_String(1, "_:2:3:4:5:6:7:7");
        this.mactest$int$java_lang_String(1, "_:2:3:4:5:6");
        this.mactest$int$java_lang_String(1, "1:5:2:3:4:_");
        this.mactest$int$java_lang_String(1, "11:11:11:ff:__:0");
        this.mactest$int$java_lang_String(1, "__:11:11:11:1:1");
        this.mactest$int$java_lang_String(1, "1:2:3:4:__:6:7:8");
        this.mactest$int$java_lang_String(1, "1:2:__:4:5:6:7:8");
        this.mactest$int$java_lang_String(1, "1:2:3:4:5:__");
        this.mactest$int$java_lang_String(1, "1:2:3:__:5:8");
        this.mactest$int$java_lang_String(1, "__:2:3:4:5:8");
        this.mactest$int$java_lang_String(1, "1:2:3:4:5:__");
        this.mactest$int$java_lang_String(1, "__:2:3:4:5:6:7:8");
        this.mactest$int$java_lang_String(1, "__:2:3:4:5:6");
        this.mactest$int$java_lang_String(1, "1:2:3:3:4:__");
        this.mactest$int$java_lang_String(0, "11:11:11:ff:___:0");
        this.mactest$int$java_lang_String(0, "___:11:11:11:1:1");
        this.mactest$int$java_lang_String(0, "1:2:3:4:___:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:___:4:5:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:___");
        this.mactest$int$java_lang_String(0, "1:2:3:___:5:8");
        this.mactest$int$java_lang_String(0, "___:2:3:4:5:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:___");
        this.mactest$int$java_lang_String(0, "___:2:3:4:5:6:7:8");
        this.mactest$int$java_lang_String(0, "___:2:3:4:5:6");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:___");
        this.mactest$int$java_lang_String(0, "11:11:11:ff:_2_:0");
        this.mactest$int$java_lang_String(0, "_2_:11:11:11:1:1");
        this.mactest$int$java_lang_String(0, "1:2:3:4:_2_:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:_2_:4:5:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:_2_");
        this.mactest$int$java_lang_String(0, "1:2:3:_2_:5:8");
        this.mactest$int$java_lang_String(0, "_2_:2:3:4:5:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:_2_");
        this.mactest$int$java_lang_String(0, "_2_:2:3:4:5:6:7");
        this.mactest$int$java_lang_String(0, "_2_:2:3:4:5:6");
        this.mactest$int$java_lang_String(0, "11:11:11:ff:_2:0");
        this.mactest$int$java_lang_String(0, "_2:11:11:11:1:1");
        this.mactest$int$java_lang_String(0, "1:2:3:4:_2:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:_2:4:5:6:7:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:_2");
        this.mactest$int$java_lang_String(0, "1:2:3:_2:5:8");
        this.mactest$int$java_lang_String(0, "_2:2:3:4:5:8");
        this.mactest$int$java_lang_String(0, "1:2:3:4:5:_2");
        this.mactest$int$java_lang_String(0, "_2:2:3:4:5:6:7:8");
        this.mactest$int$java_lang_String(0, "_2:2:3:4:5:6");
        this.mactest$int$java_lang_String(1, "11:11:11:ff:2_:0");
        this.mactest$int$java_lang_String(1, "2_:11:11:11:1:1");
        this.mactest$int$java_lang_String(1, "1:2:3:4:2_:6:7:8");
        this.mactest$int$java_lang_String(1, "1:2:2_:4:5:6:7:8");
        this.mactest$int$java_lang_String(1, "1:2:3:4:5:2_");
        this.mactest$int$java_lang_String(1, "1:2:3:2_:5:8");
        this.mactest$int$java_lang_String(1, "2_:2:3:4:5:8");
        this.mactest$int$java_lang_String(1, "1:2:3:4:5:2_");
        this.mactest$int$java_lang_String(1, "2_:2:3:4:5:6:7:8");
        this.mactest$int$java_lang_String(1, "2_:2:3:4:5:6");
        this.testMatches(true, "11:11:11:ff:20-2f:0", "11:11:11:ff:2_:0");
        this.testMatches(true, "20-2f:11:11:11:1:1", "2_:11:11:11:1:1");
        this.testMatches(true, "1:2:3:4:20-2f:6:7:8", "1:2:3:4:2_:6:7:8");
        this.testMatches(true, "1:2:20-2f:4:5:6:7:8", "1:2:2_:4:5:6:7:8");
        this.testMatches(true, "1:2:3:4:5:20-2f", "1:2:3:4:5:2_");
        this.testMatches(true, "1:2:3:20-2f:5:8", "1:2:3:2_:5:8");
        this.testMatches(true, "20-2f:2:3:4:5:8", "2_:2:3:4:5:8");
        this.testMatches(true, "1:2:3:4:5:20-2f", "1:2:3:4:5:2_");
        this.testMatches(true, "20-2f:2:3:4:5:6:7:8", "2_:2:3:4:5:6:7:8");
        this.testMatches(true, "20-2f:2:3:4:5:6", "2_:2:3:4:5:6");
        this.testMatches(true, "11:11:11:ff:0-f:0", "11:11:11:ff:_:0");
        this.testMatches(true, "0-f:11:11:11:1:1", "_:11:11:11:1:1");
        this.testMatches(true, "1:2:3:4:0-f:6:7:8", "1:2:3:4:_:6:7:8");
        this.testMatches(true, "1:2:0-f:4:5:6:7:8", "1:2:_:4:5:6:7:8");
        this.testMatches(true, "1:2:3:4:6:0-f", "1:2:3:4:6:_");
        this.testMatches(true, "1:2:3:0-f:5:6:8:8", "1:2:3:_:5:6:8:8");
        this.testMatches(true, "0-f:2:3:5:ff:8", "_:2:3:5:ff:8");
        this.testMatches(true, "1:11:11:11:1:0-f", "1:11:11:11:1:_");
        this.testMatches(true, "0-f:2:3:4:5:6:7:8", "_:2:3:4:5:6:7:8");
        this.testMatches(true, "0-f:2:3:4:5:6", "_:2:3:4:5:6");
        this.testMatches(true, "1:5:2:3:4:0-f", "1:5:2:3:4:_");
        this.testMatches(true, "11:11:11:ff:*:0", "11:11:11:ff:__:0");
        this.testMatches(true, "*:11:11:11:1:1", "__:11:11:11:1:1");
        this.testMatches(true, "1:2:3:4:*:6:7:8", "1:2:3:4:__:6:7:8");
        this.testMatches(true, "1:2:*:4:5:6:7:8", "1:2:__:4:5:6:7:8");
        this.testMatches(true, "1:2:3:4:5:*", "1:2:3:4:5:__");
        this.testMatches(true, "1:2:3:*:5:8", "1:2:3:__:5:8");
        this.testMatches(true, "*:2:3:4:5:8", "__:2:3:4:5:8");
        this.testMatches(true, "1:2:3:4:5:*", "1:2:3:4:5:__");
        this.testMatches(true, "*:2:3:4:5:6:7:8", "__:2:3:4:5:6:7:8");
        this.testMatches(true, "*:2:3:4:5:6", "__:2:3:4:5:6");
        this.testMatches(true, "1:2:3:4:4:*", "1:2:3:4:4:__");
        this.testMatches(true, "0-ff.2.3.4", "__.2.3.4");
        this.testMatches(true, "1.2.3.0-ff", "1.2.3.__");
        this.testMatches(true, "0-f.2.3.4", "_.2.3.4");
        this.testMatches(true, "1.2.3.0-f", "1.2.3._");
        this.testMatches(true, "1.0-fff.3.4", "1.___.3.4");
        this.testMatches(true, "1.2.0-fff.0-f", "1.2.___._");
        this.testMatches(true, "1.*.3.4", "1.____.3.4");
        this.testMatches(true, "1.2.*.0-f", "1.2.____._");
        this.testMatches(true, "*.2.3.4", "____.2.3.4");
        this.testMatches(true, "1.2.3.*", "1.2.3.____");
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", [0, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb", "*:*:*:*:*:*:*:*", [0, 8, 16, 24, 32, 40, 48, 56, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("*:*:*:*:*:*:*:*", "1:2:3:4:5:6:7:8", [0, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:*:*:*:*", "1:2:3:4:*:*:*:*", [32, 32, 32, 32, 32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:*:*:*:*", [32, 32, 32, 32, 32, 40, 48, 56, 64]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:0-1:*:*:*:*", "1:2:3:4:5:6:7:8", [null, null, null, null, 31, 31, 31, 31, 31]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:*:*:*:*", "1:2:3:4:5:6:7:8", [null, null, null, null, 32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:0-7f:*:*:*", "1:2:3:4:5:6:7:8", [null, null, null, null, null, 33, 33, 33, 33]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:*:*:*:*:*:*", "1:2:3:4:*:*:*:*", [32, 32, 16, 16, 16, 16, 16, 16, 16]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("a:b:c:d:*:*:*:*", "1:2:*:*:*:*:*:*", [16, 16, 16, 24, 32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$int_A("*:*:*:*:*:*:*:*", "1:2:3:4:*:*:*:*", [0, 0, 0, 0, 0, 0, 0, 0, 0]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:*:*:*:*", "1:2:3:4:5:6:7:8", [null, null, null, null, 32, 32, 32, 32, 32]);
        this.testInsertAndAppend$java_lang_String$java_lang_String$java_lang_Integer_A("a:b:c:d:e:f:aa:bb", "1:2:3:4:*:*:*:*", [32, 32, 32, 32, 32, 40, 48, 56, null]);
        this.testReplace$java_lang_String$java_lang_String("*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "*:*:*:*:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("*:*:*:*:*:*:*:*", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*", "1:2:3:4:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:0-1:*:*:*:*", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:0-7f:*:*:*", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:*:*:*:*:*:*", "1:2:3:4:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*", "1:2:*:*:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("*:*:*:*:*:*:*:*", "1:2:3:4:*:*:*:*");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:*:*:*:*", "1:2:3:4:5:6:7:8");
        this.testReplace$java_lang_String$java_lang_String("a:b:c:d:e:f:aa:bb", "1:2:3:4:*:*:*:*");
        this.testPrefixBlock("ff:*:*:*:*:*", 8);
        this.testPrefixBlock("ff:ff:*:*:*:*", 16);
        this.testPrefixBlock("ff:fe-ff:*:*:*:*", 15);
        this.testPrefixBlock("ff:fc-ff:*:*:*:*", 14);
        this.testPrefixBlock("ff:ff:80-ff:*:*:*", 17);
        this.testPrefixBlock("ff:ff:0-7f:*:*:*", 17);
        this.testPrefixBlock("ff:ff:0-3f:*:*:*", 18);
        this.testPrefixBlock("ff:0:0:ff:0:*", 40);
        this.testPrefixBlock("ff:0:0:ff:0:fe-ff", 47);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", 0, "ff:ff:ff:ff:ff:1:2:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", 2, "ff:ff:ff:ff:ff:2:2:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", 3, "ff:ff:ff:ff:ff:2:3:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", 4, "ff:ff:ff:ff:ff:2:4:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:fe-ff:fe-ff:ff", 4, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", 0, "ff:ff:ff:1:2:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", 2, "ff:ff:ff:2:2:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", 3, "ff:ff:ff:2:3:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", 4, "ff:ff:ff:2:4:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:fe-ff:fe-ff:ff", 4, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", -66299, "ff:ff:ff:ff:ff:0:0:4");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", -66300, "ff:ff:ff:ff:ff:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", -66303, "ff:ff:ff:ff:ff:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:ff:ff:1-2:2-3:ff", -66304, "ff:ff:ff:ff:fe:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:0:0:1-2:2-3:ff", -66304, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", -66299, "ff:ff:ff:0:0:4");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", -66300, "ff:ff:ff:0:0:3");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", -66303, "ff:ff:ff:0:0:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:ff:ff:1-2:2-3:ff", -66304, "ff:ff:fe:ff:ff:ff");
        this.testIncrement$java_lang_String$long$java_lang_String("0:0:0:1-2:2-3:ff", -66304, null);
        this.testIncrement$java_lang_String$long$java_lang_String("ff:3-4:ff:ff:ff:1-2:2-3:0", 6, "ff:4:ff:ff:ff:2:2:0");
        this.testIncrement$java_lang_String$long$java_lang_String("ff:3-4:ff:ff:ff:1-2:2-3:0", 8, "ff:4:ff:ff:ff:2:3:1");
        this.testIncrement$java_lang_String$long$java_lang_String("3-4:ff:ff:1-2:2-3:0", 6, "4:ff:ff:2:2:0");
        this.testIncrement$java_lang_String$long$java_lang_String("3-4:ff:ff:1-2:2-3:0", 8, "4:ff:ff:2:3:1");
        super.runTest();
    }
}
MACAddressRangeTest["__class"] = "inet.ipaddr.test.MACAddressRangeTest";




MACAddressRangeTest.NO_RANGE_ADDRESS_OPTIONS_$LI$();

MACAddressRangeTest.WILDCARD_ONLY_ADDRESS_OPTIONS_$LI$();

MACAddressRangeTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$();
