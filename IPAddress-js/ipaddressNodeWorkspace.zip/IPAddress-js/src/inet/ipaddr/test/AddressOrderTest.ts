/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressComparator } from '../AddressComparator';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { MACAddressString } from '../MACAddressString';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { MACAddress } from '../mac/MACAddress';
import { TestBase } from './TestBase';
import { AddressStringParameters } from '../AddressStringParameters';
import { AddressCreator } from './AddressCreator';
import { AddressNetwork } from '../AddressNetwork';

export class AddressOrderTest extends TestBase {
    static WILDCARD_AND_RANGE_ADDRESS_OPTIONS : IPAddressStringParameters; public static WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(AddressOrderTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS == null) AddressOrderTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS = TestBase.ADDRESS_OPTIONS_$LI$().toBuilder().allowAll(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).toParams(); return AddressOrderTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS; };

    static WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS : IPAddressStringParameters; public static WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(AddressOrderTest.WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS == null) AddressOrderTest.WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS = AddressOrderTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$().toBuilder().getIPv6AddressParametersBuilder().allowZone(false).getParentBuilder().toParams(); return AddressOrderTest.WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS; };

    static ORDERING_OPTS : IPAddressStringParameters; public static ORDERING_OPTS_$LI$() : IPAddressStringParameters { if(AddressOrderTest.ORDERING_OPTS == null) AddressOrderTest.ORDERING_OPTS = AddressOrderTest.WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS_$LI$().toBuilder().allowEmpty(true).setEmptyAsLoopback(false).toParams(); return AddressOrderTest.ORDERING_OPTS; };

    static MAC_ORDERING_OPTS : MACAddressStringParameters; public static MAC_ORDERING_OPTS_$LI$() : MACAddressStringParameters { if(AddressOrderTest.MAC_ORDERING_OPTS == null) AddressOrderTest.MAC_ORDERING_OPTS = TestBase.MAC_ADDRESS_OPTIONS_$LI$().toBuilder().allowAll(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$()).allowEmpty(true).toParams(); return AddressOrderTest.MAC_ORDERING_OPTS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    testOrder() {
        let ipAddressSupplier : AddressOrderTest.OrderingSupplier<AddressOrderTest.AddressOrdering> = { supply : (s, i) => {
            let addr : IPAddress = this.createAddress$java_lang_String(s).getAddress();
            return addr == null?null:new AddressOrderTest.AddressOrdering(this, addr, i);
        } };
        let macAddressSupplier : AddressOrderTest.OrderingSupplier<AddressOrderTest.AddressOrdering> = { supply : (s, i) => {
            let addr : MACAddress = this.createMACAddress$java_lang_String(s).getAddress();
            return addr == null?null:new AddressOrderTest.AddressOrdering(this, addr, i);
        } };
        let nullIPAddressSupplier : AddressOrderTest.OrderingSupplier<AddressOrderTest.IPAddressStringOrdering> = { supply : (s, i) => null };
        let nullMACAddressSupplier : AddressOrderTest.OrderingSupplier<AddressOrderTest.MACAddressStringOrdering> = { supply : (s, i) => null };
        this.testDefaultOrder<any>(<any>([]), (address,order) => { return new AddressOrderTest.IPAddressStringOrdering(address,order) }, nullIPAddressSupplier);
        let lowValComparator : AddressComparator.ValueComparator = new AddressComparator.ValueComparator(false);
        this.testLowValueOrder<any>(<any>([]), (arg0, arg1) => { return new IPAddressOrderingComparator(lowValComparator).compare(arg0, arg1); }, (address,order) => { return new AddressOrderTest.IPAddressStringOrdering(address,order) }, nullIPAddressSupplier);
        this.testLowValueOrder<any>(<any>([]), (arg0, arg1) => { return new MACOrderingComparator(lowValComparator).compare(arg0, arg1); }, nullMACAddressSupplier, (address,order) => { return new AddressOrderTest.MACAddressStringOrdering(address,order) });
        this.testLowValueOrder<any>(<any>([]), (arg0, arg1) => { return new AddressOrderingComparator(lowValComparator).compare(arg0, arg1); }, ipAddressSupplier, macAddressSupplier);
        let highValComparator : AddressComparator.ValueComparator = new AddressComparator.ValueComparator(true);
        this.testHighValueOrder<any>(<any>([]), (arg0, arg1) => { return new IPAddressOrderingComparator(highValComparator).compare(arg0, arg1); }, (address,order) => { return new AddressOrderTest.IPAddressStringOrdering(address,order) }, nullIPAddressSupplier);
        this.testHighValueOrder<any>(<any>([]), (arg0, arg1) => { return new MACOrderingComparator(highValComparator).compare(arg0, arg1); }, nullMACAddressSupplier, (address,order) => { return new AddressOrderTest.MACAddressStringOrdering(address,order) });
        this.testHighValueOrder<any>(<any>([]), (arg0, arg1) => { return new AddressOrderingComparator(highValComparator).compare(arg0, arg1); }, ipAddressSupplier, macAddressSupplier);
        this.testDefaultOrder<any>(<any>([]), (address,order) => { return new AddressOrderTest.IPAddressStringOrdering(address,order) }, nullIPAddressSupplier);
        this.testDefaultOrder<any>(<any>([]), nullMACAddressSupplier, (address,order) => { return new AddressOrderTest.MACAddressStringOrdering(address,order) });
        this.testDefaultOrder<any>(<any>([]), ipAddressSupplier, macAddressSupplier);
    }

    testHighValueOrder<T extends AddressOrderTest.Ordering<T, any>>(ordering : Array<T>, comparator : any, ipAddressSupplier : AddressOrderTest.OrderingSupplier<T>, macAddressSupplier : AddressOrderTest.OrderingSupplier<T>) {
        let orderNumber : number = 0;
        let strs : string[] = ["/129", "bla", "fo", "foo", "four", "xxx"];
        for(let index134=0; index134 < strs.length; index134++) {
            let s = strs[index134];
            {
                /* add */(ordering.push(ipAddressSupplier.supply(s, orderNumber))>0);
                /* add */(ordering.push(macAddressSupplier.supply(s, orderNumber))>0);
                orderNumber++;
            }
        }
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:00:00:2:03:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:00:00:02:03:04", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3-4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-7f:2:3:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:*:2:03:4:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:*:02:03:04:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:f0-ff:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-ff:*:*:*:8", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0-1:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("a1:f0:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:%*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:a:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0:0:0:0:0:0:0:1", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        /* add */(ordering.push(ipAddressSupplier.supply("1.0.0.0", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.0/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("001.002.000.000/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.000.0/15", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.*/17", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.003.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("001.002.003.004", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*/31", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.*/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.0/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("001.002.000.000/16", orderNumber))>0);
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.*.*/16", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.000.0/15", orderNumber))>0);
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.2-3.*.*/15", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.1-3.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.*.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.%*.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::", orderNumber))>0);
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::/17", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1::/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0000:0000:0000/16", orderNumber))>0);
        }
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::*/31", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1::*/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1::2:2:*/111", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:003:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0002:0003:0004", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::2:2:*/111", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*/127", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::*/31", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1::/17", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1::*/17", orderNumber))>0);
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:0:*/17", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1:8000::/17", orderNumber))>0);
            orderNumber++;
        } else {
            /* add */(ordering.push(ipAddressSupplier.supply("1::/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0000:0000:0000/16", orderNumber))>0);
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:*/17", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1:*/16", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1:8000::/17", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("2::/15", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("2:*/15", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("a1:8000::/17", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:ffff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:%*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:ffff", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*:*:*/16", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:a:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*:*:*/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("*:*", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("/33", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/64", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("*:*", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("/128", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/32", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/24", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("**", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply(" *", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("%%", orderNumber))>0);
        orderNumber++;
        this.checkOrdering<any>(ordering, orderNumber, <any>(comparator));
    }

    testLowValueOrder<T extends AddressOrderTest.Ordering<T, any>>(ordering : Array<T>, comparator : any, ipAddressSupplier : AddressOrderTest.OrderingSupplier<T>, macAddressSupplier : AddressOrderTest.OrderingSupplier<T>) {
        let orderNumber : number = 0;
        let strs : string[] = ["/129", "bla", "fo", "foo", "four", "xxx"];
        for(let index135=0; index135 < strs.length; index135++) {
            let s = strs[index135];
            {
                /* add */(ordering.push(ipAddressSupplier.supply(s, orderNumber++))>0);
                /* add */(ordering.push(macAddressSupplier.supply(s, orderNumber++))>0);
            }
        }
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0-1:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:%*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:a:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-ff:*:*:*:8", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3-4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:00:00:2:03:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:00:00:02:03:04", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-7f:2:3:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:*:2:03:4:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:*:02:03:04:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:f0-ff:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("a1:f0:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0:0:0:0:0:0:0:1", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.*.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.%*.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.1-3.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.0.0.0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.000.0.*/17", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.0/16", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("001.002.000.000/16", orderNumber))>0);
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.*.*/16", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.000.0/15", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.*.*/16", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.2-3.*.*/15", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*/31", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.003.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("001.002.003.004", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:%*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*:*:*/16", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("*:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:a:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::", orderNumber))>0);
        if(!isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1::/31", orderNumber))>0);
        if(!isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1::/17", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1:0::/17", orderNumber))>0);
        if(!isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1::/16", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0000:0000:0000/16", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:0::*/16", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:0:*/16", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:*/17", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1:*/16", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:2:*/111", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*/127", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:003:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0002:0003:0004", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1:8000::/17", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("2::/15", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("2::0:*/15", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("2:0:*/15", orderNumber))>0);
        if(isNoAutoSubnets) {
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("2:*/15", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("a1:8000::/17", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:ffff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:ffff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/33", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff:ffff:ffff::", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/64", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff:ffff:ffff:ffff::1", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/128", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/32", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/24", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("**", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply(" *", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("%%", orderNumber))>0);
        orderNumber++;
        this.checkOrdering<any>(ordering, orderNumber, <any>(comparator));
    }

    checkOrdering<T extends AddressOrderTest.Ordering<T, any>>(ordering : Array<T>, orderCount : number, comparator : any) {
        let set : Array<Wrapper> = <any>([]);
        for(let index136=0; index136 < ordering.length; index136++) {
            let o = ordering[index136];
            {
                if(o != null) {
                    /* add */((s, e) => { if(s.indexOf(e)==-1) { s.push(e); return true; } else { return false; } })(set, new AddressOrderTest.Wrapper(this, o));
                }
            }
        }
        /* clear */(ordering.length = 0);
        for(let index137=0; index137 < set.length; index137++) {
            let w = set[index137];
            {
                /* add */(ordering.push(w.o)>0);
            }
        }
        if(comparator != null) {
            /* sort */((l,c) => { if((<any>c).compare) l.sort((e1,e2)=>(<any>c).compare(e1,e2)); else l.sort(<any>c); })(ordering,comparator);
        } else {
            /* sort */ordering.sort();
        }
        let sorted : Array<string> = <any>([]);
        let previousOrder : number = -1;
        let lastIndex : number = -1;
        for(let i : number = 0; i < /* size */(<number>ordering.length); i++) {
            let o : AddressOrderTest.Ordering<any, any> = /* get */ordering[i];
            let currentOrder : number = o.order;
            let index : number;
            if(currentOrder === previousOrder) {
                index = lastIndex;
            } else {
                index = i + 1;
            }
            /* add */(sorted.push("\n(" + index + ") " + o.nestedType + ' ' + o.getDescription())>0);
            previousOrder = currentOrder;
            lastIndex = index;
        };
        let failedOrdering : boolean = false;
        let lastOrder : number = -1;
        for(let i : number = 0; i < /* size */(<number>ordering.length); i++) {
            let orderingItem : AddressOrderTest.Ordering<any, any> = /* get */ordering[i];
            let order : number = orderingItem.order;
            if(order < lastOrder) {
                failedOrdering = true;
                this.addFailure(new TestBase.Failure("item " + (i + 1) + ": " + orderingItem.nestedType + " is in wrong place in ordering ( order number: " + order + ", previous order number: " + lastOrder + ")"));
            }
            lastOrder = order;
        };
        if(failedOrdering) {
            this.addFailure(new TestBase.Failure("ordering failed: " + /* implicit toString */ (a => a?'['+a.join(', ')+']':'null')(sorted)));
        }
        this.incrementTestCount();
    }

    /**
     * The default order goes by count first, and then the count of the more significant segment followed the lower value magnitude in the same segment.
     * @param {AddressOrderTest.Ordering[]} ordering
     * @param {*} ipAddressSupplier
     * @param {*} macAddressSupplier
     */
    testDefaultOrder<T extends AddressOrderTest.Ordering<T, any>>(ordering : Array<T>, ipAddressSupplier : AddressOrderTest.OrderingSupplier<T>, macAddressSupplier : AddressOrderTest.OrderingSupplier<T>) {
        let strs : string[] = ["/129", "bla", "fo", "foo", "four", "xxx"];
        let orderNumber : number = 0;
        for(let index138=0; index138 < strs.length; index138++) {
            let s = strs[index138];
            {
                /* add */(ordering.push(ipAddressSupplier.supply(s, orderNumber))>0);
                /* add */(ordering.push(macAddressSupplier.supply(s, orderNumber))>0);
                orderNumber++;
            }
        }
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:00:00:2:03:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:4", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:00:00:02:03:04", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:fe:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:fe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:0:0:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("a1:f0:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:2:3-4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:f0-ff:2:3:4:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:*:2:03:4:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("01:*:02:03:04:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-7f:2:3:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0-ff:*:*:*:8", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:0:0:*:%*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:a:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0-1:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*", orderNumber))>0);
        /* add */(ordering.push(macAddressSupplier.supply("*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("0:0:0:0:0:0:0:1", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("1:0:0:0:0:0:0:0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("ff:ff:ff:ff:ff:ff:ff:ff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(macAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("  ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("     ", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.0.0.0", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.0/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("001.002.000.000/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.000.0/15", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.0.0/15", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.003.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.2.3.4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("001.002.003.004", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.254.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.254", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("255.255.255.255", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.3.*/31", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.*.*/17", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1.002.*.*/16", orderNumber))>0);
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1.002.0.0/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("001.002.000.000/16", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.000.0/15", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1.2.0.0/15", orderNumber))>0);
        }
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.1-3.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.*.*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*.*.%*.*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::", orderNumber))>0);
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::/17", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1::/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("0001::/16", orderNumber))>0);
        }
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:003:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:4", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("0001:0000::0002:0003:0004", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1:8000::/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("2::/15", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("a1:8000::/17", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::fffe:ffff:ffff", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:fffe", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("ffff::ffff:ffff:ffff", orderNumber))>0);
        orderNumber++;
        if(isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("/33", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("/64", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("/128", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*/127", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:3:*/111", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("1::2:1-3:4:*", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("/64", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*::*:%*:*", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("/33", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("1:0:*/31", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("1::/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1:8000::/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("a1:8000::/17", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1::/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("0001::/16", orderNumber))>0);
            /* add */(ordering.push(ipAddressSupplier.supply("1:*/16", orderNumber))>0);
            orderNumber++;
        } else {
            /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*:*:*/16", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("1:*/16", orderNumber))>0);
            orderNumber++;
        }
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:a:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        if(!isNoAutoSubnets) {
            /* add */(ordering.push(ipAddressSupplier.supply("2::/15", orderNumber))>0);
            orderNumber++;
            /* add */(ordering.push(ipAddressSupplier.supply("*::*:*:*:*:*/16", orderNumber))>0);
        }
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:*:*:*:*:*:*/16", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*:*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("*:*:*:*:*:*:*:*", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/32", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/24", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("/0", orderNumber))>0);
        orderNumber++;
        /* add */(ordering.push(ipAddressSupplier.supply("*", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("**", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply(" *", orderNumber))>0);
        /* add */(ordering.push(ipAddressSupplier.supply("%%", orderNumber))>0);
        orderNumber++;
        this.checkOrdering<any>(ordering, orderNumber, <any>(null));
    }

    /**
     * 
     */
    runTest() {
        this.testOrder();
    }
}
AddressOrderTest["__class"] = "inet.ipaddr.test.AddressOrderTest";


export namespace AddressOrderTest {

    export abstract class Ordering<T extends AddressOrderTest.Ordering<T, NestedType>, NestedType extends java.lang.Comparable<NestedType>> {
        nestedType : NestedType;

        order : number;

        constructor(nestedType : NestedType, order : number) {
            if(this.nestedType===undefined) this.nestedType = null;
            if(this.order===undefined) this.order = 0;
            this.nestedType = nestedType;
            this.order = order;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.nestedType));
        }

        /**
         * 
         * @param {AddressOrderTest.Ordering} o
         * @return {number}
         */
        public compareTo(o : T) : number {
            return this.nestedType.compareTo(o.nestedType);
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>AddressOrderTest.Ordering) {
                let other : AddressOrderTest.Ordering<any, any> = <AddressOrderTest.Ordering<any, any>>o;
                return this.nestedType.equals(other.nestedType);
            }
            return false;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            return "(" + this.order + ") " + this.nestedType;
        }

        public getDescription() : string {
            return this.toString();
        }
    }
    Ordering["__class"] = "inet.ipaddr.test.AddressOrderTest.Ordering";
    Ordering["__interfaces"] = ["java.lang.Comparable"];



    export interface OrderingSupplier<T extends AddressOrderTest.Ordering<T, any>> {
        supply(string : string, order : number) : T;
    }

    export class IPAddressStringOrdering extends AddressOrderTest.Ordering<AddressOrderTest.IPAddressStringOrdering, IPAddressString> {
        public __parent: any;
        constructor(__parent: any, address : string, order : number) {
            super(__parent.createAddress(address, AddressOrderTest.ORDERING_OPTS_$LI$()), order);
            this.__parent = __parent;
        }

        /**
         * 
         * @return {string}
         */
        public getDescription() : string {
            return this.nestedType.getAddress() == null?"":"\t\t\t (" + this.nestedType.getAddress().toNormalizedWildcardString() + ")";
        }
    }
    IPAddressStringOrdering["__class"] = "inet.ipaddr.test.AddressOrderTest.IPAddressStringOrdering";
    IPAddressStringOrdering["__interfaces"] = ["java.lang.Comparable"];



    export class MACAddressStringOrdering extends AddressOrderTest.Ordering<AddressOrderTest.MACAddressStringOrdering, MACAddressString> {
        public __parent: any;
        constructor(__parent: any, address : string, order : number) {
            super(__parent.createMACAddress(address, AddressOrderTest.MAC_ORDERING_OPTS_$LI$()), order);
            this.__parent = __parent;
        }

        /**
         * 
         * @return {string}
         */
        public getDescription() : string {
            return this.nestedType.getAddress() == null?"":"\t\t\t (" + this.nestedType.getAddress().toNormalizedString() + ")";
        }
    }
    MACAddressStringOrdering["__class"] = "inet.ipaddr.test.AddressOrderTest.MACAddressStringOrdering";
    MACAddressStringOrdering["__interfaces"] = ["java.lang.Comparable"];



    export class AddressOrdering extends AddressOrderTest.Ordering<AddressOrderTest.AddressOrdering, Address> {
        public __parent: any;
        constructor(__parent: any, address : Address, order : number) {
            super(address, order);
            this.__parent = __parent;
        }

        /**
         * 
         * @return {string}
         */
        public getDescription() : string {
            return "\t\t\t (" + this.nestedType.toNormalizedString() + ")";
        }
    }
    AddressOrdering["__class"] = "inet.ipaddr.test.AddressOrderTest.AddressOrdering";
    AddressOrdering["__interfaces"] = ["java.lang.Comparable"];



    export class AddressOrderingComparator {
        public __parent: any;
        comp : AddressComparator;

        constructor(__parent: any, comp : AddressComparator) {
            this.__parent = __parent;
            if(this.comp===undefined) this.comp = null;
            this.comp = comp;
        }

        /**
         * 
         * @param {AddressOrderTest.AddressOrdering} o1
         * @param {AddressOrderTest.AddressOrdering} o2
         * @return {number}
         */
        public compare(o1 : AddressOrderTest.AddressOrdering, o2 : AddressOrderTest.AddressOrdering) : number {
            let one : Address = o1.nestedType;
            let two : Address = o2.nestedType;
            return this.comp['compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries'](one, two);
        }
    }
    AddressOrderingComparator["__class"] = "AddressOrderingComparator";
    AddressOrderingComparator["__interfaces"] = ["java.util.Comparator"];



    export class IPAddressOrderingComparator {
        public __parent: any;
        comp : AddressComparator;

        constructor(__parent: any, comp : AddressComparator) {
            this.__parent = __parent;
            if(this.comp===undefined) this.comp = null;
            this.comp = comp;
        }

        /**
         * 
         * @param {AddressOrderTest.IPAddressStringOrdering} o1
         * @param {AddressOrderTest.IPAddressStringOrdering} o2
         * @return {number}
         */
        public compare(o1 : AddressOrderTest.IPAddressStringOrdering, o2 : AddressOrderTest.IPAddressStringOrdering) : number {
            let one : IPAddress = o1.nestedType.getAddress();
            let two : IPAddress = o2.nestedType.getAddress();
            if(one != null && two != null) {
                return this.comp['compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries'](one, two);
            }
            return o1.nestedType.compareTo(o2.nestedType);
        }
    }
    IPAddressOrderingComparator["__class"] = "IPAddressOrderingComparator";
    IPAddressOrderingComparator["__interfaces"] = ["java.util.Comparator"];



    export class MACOrderingComparator {
        public __parent: any;
        comp : AddressComparator;

        constructor(__parent: any, comp : AddressComparator) {
            this.__parent = __parent;
            if(this.comp===undefined) this.comp = null;
            this.comp = comp;
        }

        /**
         * 
         * @param {AddressOrderTest.MACAddressStringOrdering} o1
         * @param {AddressOrderTest.MACAddressStringOrdering} o2
         * @return {number}
         */
        public compare(o1 : AddressOrderTest.MACAddressStringOrdering, o2 : AddressOrderTest.MACAddressStringOrdering) : number {
            let one : MACAddress = o1.nestedType.getAddress();
            let two : MACAddress = o2.nestedType.getAddress();
            if(one != null && two != null) {
                return this.comp['compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries'](one, two);
            }
            return o1.nestedType.compareTo(o2.nestedType);
        }
    }
    MACOrderingComparator["__class"] = "MACOrderingComparator";
    MACOrderingComparator["__interfaces"] = ["java.util.Comparator"];



    export class Wrapper {
        public __parent: any;
        o : T;

        constructor(__parent: any, o : T) {
            this.__parent = __parent;
            if(this.o===undefined) this.o = null;
            this.o = o;
        }
    }
    Wrapper["__class"] = "Wrapper";

}




AddressOrderTest.MAC_ORDERING_OPTS_$LI$();

AddressOrderTest.ORDERING_OPTS_$LI$();

AddressOrderTest.WILDCARD_AND_RANGE_NO_ZONE_ADDRESS_OPTIONS_$LI$();

AddressOrderTest.WILDCARD_AND_RANGE_ADDRESS_OPTIONS_$LI$();
