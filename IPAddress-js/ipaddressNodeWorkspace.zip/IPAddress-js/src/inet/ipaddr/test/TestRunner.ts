/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { HostName } from '../HostName';
import { IPAddress } from '../IPAddress';
import { IPAddressString } from '../IPAddressString';
import { MACAddressString } from '../MACAddressString';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressNetwork } from '../ipv4/IPv4AddressNetwork';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressNetwork } from '../mac/MACAddressNetwork';
import { TestBase } from './TestBase';
import { AddressCreator } from './AddressCreator';
import { HostTest } from './HostTest';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { MACAddressTest } from './MACAddressTest';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { AddressNetwork } from '../AddressNetwork';
import { SpecialTypesTest } from './SpecialTypesTest';
import { IPAddressTest } from './IPAddressTest';
import { IPAddressRangeTest } from './IPAddressRangeTest';
import { IPAddressAllTest } from './IPAddressAllTest';
import { HostRangeTest } from './HostRangeTest';
import { HostAllTest } from './HostAllTest';
import { MACAddressRangeTest } from './MACAddressRangeTest';
import { AddressOrderTest } from './AddressOrderTest';

export class TestRunner extends TestBase implements AddressCreator {
    public static main(args : string[]) {
        let testRunner : TestRunner = new TestRunner();
        for(let i : number = 0; i < args.length; i++) {
            let arg : string = args[i];
            if(/* equalsIgnoreCase */((o1, o2) => o1.toUpperCase() === (o2===null?o2:o2.toUpperCase()))(arg, "fast")) {
                HostTest.runDNS = false;
                testRunner.fullTest = false;
            } else if(/* equalsIgnoreCase */((o1, o2) => o1.toUpperCase() === (o2===null?o2:o2.toUpperCase()))(arg, "limited")) {
                HostTest.runDNS = false;
                testRunner.limited = true;
            } else if(/* equalsIgnoreCase */((o1, o2) => o1.toUpperCase() === (o2===null?o2:o2.toUpperCase()))(arg, "performance")) {
                HostTest.runDNS = false;
                testRunner.performance = true;
            }
        };
        testRunner.runTest();
    }

    /*private*/ hostCreator : TestRunner.Creator<TestBase.HostKey, HostName> = new TestRunner.TestRunner$0(this);

    /*private*/ ipAddressStringCreator : TestRunner.Creator<TestBase.IPAddressStringKey, IPAddressString> = new TestRunner.TestRunner$1(this);

    /*private*/ ipAddressCreator : TestRunner.Creator<TestBase.IPAddressKey, IPAddress> = new TestRunner.TestRunner$2(this);

    /*private*/ ipIntAddressCreator : TestRunner.Creator<number, IPv4Address> = new TestRunner.TestRunner$3(this);

    /*private*/ macAddressStringCreator : TestRunner.Creator<MACAddressTest.MACAddressStringKey, MACAddressString> = new TestRunner.TestRunner$4(this);

    /*private*/ macAddressCreator : TestRunner.Creator<MACAddressTest.MACAddressKey, MACAddress> = new TestRunner.TestRunner$5(this);

    /*private*/ macAddressFromLongCreator : TestRunner.Creator<MACAddressTest.MACAddressLongKey, MACAddress> = new TestRunner.TestRunner$6(this);

    hostNameCache : IPAddressNetwork.HostNameGenerator = new IPAddressNetwork.HostNameGenerator(<any>(new ConcurrentHashMap<string, HostName>()), TestBase.HOST_OPTIONS_$LI$(), false);

    ipAddressStringCache : IPAddressNetwork.IPAddressStringGenerator = new IPAddressNetwork.IPAddressStringGenerator(<any>(new ConcurrentHashMap<string, IPAddressString>()), TestBase.ADDRESS_OPTIONS_$LI$());

    public createHost(x? : any, options? : any) : any {
        if(((typeof x === 'string') || x === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            super.createHost(x, options);
        } else if(((x != null && x instanceof <any>TestBase.HostKey) || x === null) && options === undefined) {
            return <any>this.createHost$inet_ipaddr_test_TestBase_HostKey(x);
        } else if(((typeof x === 'string') || x === null) && options === undefined) {
            return <any>this.createHost$java_lang_String(x);
        } else throw new Error('invalid overload');
    }

    public createHost$inet_ipaddr_test_TestBase_HostKey(key : TestBase.HostKey) : HostName {
        if(this.CACHING) {
            return this.cache.getFromHostMap(key, this.hostCreator);
        }
        return this.hostCreator.create(key);
    }

    public createAddress(x? : any, ipv4RangeOptions? : any, ipv6RangeOptions? : any) : any {
        if(((typeof x === 'string') || x === null) && ((ipv4RangeOptions != null && ipv4RangeOptions instanceof <any>IPAddressStringParameters) || ipv4RangeOptions === null) && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, ipv4RangeOptions);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'string') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((typeof x === 'number') || x === null) && ipv4RangeOptions === undefined && ipv6RangeOptions === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    public createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(key : TestBase.IPAddressStringKey) : IPAddressString {
        if(this.CACHING) {
            return this.cache.getFromAddressStringMap$inet_ipaddr_test_TestBase_IPAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key, this.ipAddressStringCreator);
        }
        return this.ipAddressStringCreator.create(key);
    }

    public createMACAddress(x? : any, opts? : any) : any {
        if(((typeof x === 'string') || x === null) && ((opts != null && opts instanceof <any>MACAddressStringParameters) || opts === null)) {
            super.createMACAddress(x, opts);
        } else if(((typeof x === 'number') || x === null) && ((typeof opts === 'boolean') || opts === null)) {
            return <any>this.createMACAddress$long$boolean(x, opts);
        } else if(((x != null && x instanceof <any>MACAddressTest.MACAddressStringKey) || x === null) && opts === undefined) {
            return <any>this.createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && opts === undefined) {
            return <any>this.createMACAddress$byte_A(x);
        } else if(((typeof x === 'string') || x === null) && opts === undefined) {
            return <any>this.createMACAddress$java_lang_String(x);
        } else throw new Error('invalid overload');
    }

    public createMACAddress$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(key : MACAddressTest.MACAddressStringKey) : MACAddressString {
        if(this.CACHING) {
            return this.cache.getFromAddressStringMap$inet_ipaddr_test_MACAddressTest_MACAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key, this.macAddressStringCreator);
        }
        return this.macAddressStringCreator.create(key);
    }

    public createAddress$byte_A(bytes : number[]) : IPAddress {
        let key : TestBase.IPAddressKey = new TestBase.IPAddressKey(bytes);
        if(this.CACHING) {
            return this.cache.getFromAddressMap$inet_ipaddr_test_TestBase_IPAddressKey$inet_ipaddr_test_TestRunner_Creator(key, this.ipAddressCreator);
        }
        return this.ipAddressCreator.create(key);
    }

    public createAddress$int(val : number) : IPv4Address {
        let key : number = val;
        if(this.CACHING) {
            return this.cache.getFromAddressMap$java_lang_Integer$inet_ipaddr_test_TestRunner_Creator(key, this.ipIntAddressCreator);
        }
        return this.ipIntAddressCreator.create(key);
    }

    public createMACAddress$byte_A(bytes : number[]) : MACAddress {
        let key : MACAddressTest.MACAddressKey = new MACAddressTest.MACAddressKey(bytes);
        if(this.CACHING) {
            return this.cache.getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressKey$inet_ipaddr_test_TestRunner_Creator(key, this.macAddressCreator);
        }
        return this.macAddressCreator.create(key);
    }

    public createMACAddress$long$boolean(val : number, extended : boolean) : MACAddress {
        let key : MACAddressTest.MACAddressLongKey = new MACAddressTest.MACAddressLongKey(val, extended);
        if(this.CACHING) {
            return this.cache.getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressLongKey$inet_ipaddr_test_TestRunner_Creator(key, this.macAddressFromLongCreator);
        }
        return this.macAddressFromLongCreator.create(key);
    }

    static DEBUG_CACHE : boolean = false;

    public serialize(input : TestRunner.Cache) : TestRunner.Cache {
        let outmine : TestRunner.EfficientByteArrayOuputStream = (() => { let __o : any = new TestRunner.EfficientByteArrayOuputStream(); __o.__delegate = new TestRunner.EfficientByteArrayOuputStream(); return __o; })();
        let outputmine : ObjectOutput = new ObjectOutputStream(outmine);
        outputmine.writeObject(input);
        outputmine.close();
        let bytesmine : Array<any> = outmine.getBytes();
        let inmine : TestRunner.EfficientByteArrayInputStream = (() => { let __o : any = new TestRunner.EfficientByteArrayInputStream(bytesmine); __o.__delegate = new TestRunner.EfficientByteArrayInputStream(bytesmine); return __o; })();
        let inputmine : ObjectInput = null;
        let result : TestRunner.Cache = null;
        try {
            inputmine = new ObjectInputStream(inmine);
            result = <TestRunner.Cache>inputmine.readObject();
            return result;
        } finally {
            if(inputmine != null) {
                try {
                    inputmine.close();
                } catch(e) {
                    if(result != null) {
                        throw e;
                    }
                };
            }
        };
    }

    /*private*/ cache : TestRunner.Cache = new TestRunner.Cache();

    /*private*/ CACHING : boolean;

    fullTest : boolean = true;

    limited : boolean = false;

    performance : boolean = false;

    constructor() {
        super(null);
        if(this.CACHING===undefined) this.CACHING = false;
    }

    /**
     * 
     */
    runTest() {
        let ordering : AddressNetwork.PrefixConfiguration[] = [AddressNetwork.PrefixConfiguration.ALL_PREFIXED_ADDRESSES_ARE_SUBNETS, AddressNetwork.PrefixConfiguration.PREFIXED_ZERO_HOSTS_ARE_SUBNETS, AddressNetwork.PrefixConfiguration.EXPLICIT_SUBNETS];
        let count : number = 0;
        while((count < ordering.length)) {
            TestBase.showMessage("");
            let prefConf : AddressNetwork.PrefixConfiguration = ordering[count++];
            TestBase.prefixConfiguration = prefConf;
            IPv4AddressNetwork.setDefaultPrefixConfiguration(prefConf);
            IPv6AddressNetwork.setDefaultPrefixConfiguration(prefConf);
            MACAddressNetwork.setDefaultPrefixConfiguration(prefConf);
            TestBase.showMessage("testing with " + prefConf);
            TestBase.showMessage("count of 1.2.0.0/16 is " + new IPAddressString("1.2.0.0/16").getAddress().getCount());
            TestBase.showMessage("count of 1.2.3.4/16 is " + new IPAddressString("1.2.3.4/16").getAddress().getCount());
            this.runBattery();
            Address.defaultIpv4Network().clearCaches();
            Address.defaultIpv6Network().clearCaches();
            Address.defaultMACNetwork().clearCaches();
        };
    }

    runBattery() {
        this.CACHING = false;
        this.failures = new TestBase.Failures();
        this.perf = new TestBase.Perf();
        TestBase.showMessage("Starting " + /* getSimpleName */(c => c["__class"]?c["__class"].substring(c["__class"].lastIndexOf('.')+1):c["name"].substring(c["name"].lastIndexOf('.')+1))((<any>this.constructor)));
        let startTime : number = java.lang.System.nanoTime();
        this.runPerf(startTime);
        this.failures.add(this.testAll());
        if(!this.limited) {
            this.CACHING = true;
            this.failures.add(this.testAll());
            this.failures.add(this.testAll());
            let threads : java.lang.Thread[] = this.runInThreads(10, () => {
                this.failures.add(this.testAll());
            });
            try {
                for(let index175=0; index175 < threads.length; index175++) {
                    let thread = threads[index175];
                    {
                        thread.join();
                    }
                }
                this.cache.clear();
                threads = this.runInThreads(10, () => {
                    this.failures.add(this.testAll());
                });
                let threads2 : java.lang.Thread[] = this.runInThreads(5, () => {
                    this.failures.add(this.testAll());
                });
                for(let index176=0; index176 < threads.length; index176++) {
                    let thread = threads[index176];
                    {
                        thread.join();
                    }
                }
                for(let index177=0; index177 < threads2.length; index177++) {
                    let thread = threads2[index177];
                    {
                        thread.join();
                    }
                }
            } catch(e) {
                console.error(e.message, e);
            };
            try {
                let oldCache : TestRunner.Cache = this.cache;
                this.cache = this.serialize(oldCache);
                if(!oldCache.equals(this.cache)) {
                    this.failures.numTested++;
                    /* add */(this.failures.failures.push(new TestBase.Failure("serialized cache mismatch"))>0);
                    console.info("cache is same: " + oldCache.equals(this.cache));
                }
                this.failures.add(this.testAll());
            } catch(e) {
                this.failures.numTested++;
                /* add */(this.failures.failures.push(new TestBase.Failure(e.toString()))>0);
            };
            this.runPerf(java.lang.System.nanoTime());
        }
        this.report();
        TestBase.showMessage("Done in " + (n => n<0?Math.ceil(n):Math.floor(n))((java.lang.System.nanoTime() - startTime) / 1000000) + " milliseconds");
        this.cache.clear();
    }

    runPerf(startTime : number) {
        if(this.performance) {
            let perfStartTime : number = startTime;
            for(let i : number = 0; i < 10; i++) {
                this.failures.add(this.testAll());
                let endTime : number = java.lang.System.nanoTime();
                let totalTime : number = endTime - perfStartTime;
                this.perf.addTime(totalTime);
                perfStartTime = endTime;
            };
        }
    }

    runInThreads(numThreads : number, runnable : () => void) : java.lang.Thread[] {
        let threads : java.lang.Thread[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(numThreads);
        let barrier : CyclicBarrier = new CyclicBarrier(numThreads);
        for(let i : number = 0; i < numThreads; i++) {
            let thread : java.lang.Thread = new TestRunner.TestRunner$7(this, barrier, runnable);
            threads[i] = thread;
            thread.start();
        };
        return threads;
    }

    public testAll() : TestBase.Failures {
        let failures : TestBase.Failures = new TestBase.Failures();
        let tests : TestBase[] = [new SpecialTypesTest(this), new IPAddressTest(this), new HostTest(this), new IPAddressRangeTest(this), new IPAddressAllTest(this), new HostRangeTest(this), new HostAllTest(this), new MACAddressTest(this), new MACAddressRangeTest(this), new AddressOrderTest(this)];
        for(let index178=0; index178 < tests.length; index178++) {
            let test = tests[index178];
            {
                test.fullTest = this.fullTest;
                test.runTest();
                failures.add(test.failures);
            }
        }
        return failures;
    }
}
TestRunner["__class"] = "inet.ipaddr.test.TestRunner";
TestRunner["__interfaces"] = ["inet.ipaddr.test.AddressCreator"];



export namespace TestRunner {

    export interface Creator<K, V> {
        /**
         * 
         * @param {TestBase.HostKey} hostKey
         * @return {HostName}
         */
        create(hostKey? : any) : any;
    }

    export class Cache {
        static serialVersionUID : number = 4;

        cachingIPStringMap : ConcurrentHashMap<TestBase.IPAddressStringKey, IPAddressString> = <any>(new ConcurrentHashMap<TestBase.IPAddressStringKey, IPAddressString>());

        cachingIPMap : ConcurrentHashMap<TestBase.IPAddressKey, IPAddress> = <any>(new ConcurrentHashMap<TestBase.IPAddressKey, IPAddress>());

        cachingIPIntMap : ConcurrentHashMap<number, IPv4Address> = <any>(new ConcurrentHashMap<number, IPv4Address>());

        cachingMACStringMap : ConcurrentHashMap<MACAddressTest.MACAddressStringKey, MACAddressString> = <any>(new ConcurrentHashMap<MACAddressTest.MACAddressStringKey, MACAddressString>());

        cachingMACMap : ConcurrentHashMap<MACAddressTest.MACAddressKey, MACAddress> = <any>(new ConcurrentHashMap<MACAddressTest.MACAddressKey, MACAddress>());

        cachingMACLongMap : ConcurrentHashMap<MACAddressTest.MACAddressLongKey, MACAddress> = <any>(new ConcurrentHashMap<MACAddressTest.MACAddressLongKey, MACAddress>());

        cachingHostMap : ConcurrentHashMap<TestBase.HostKey, HostName> = <any>(new ConcurrentHashMap<TestBase.HostKey, HostName>());

        static getFromMap<K, V>(map : any, key : K, creator : TestRunner.Creator<K, V>) : V {
            let result : V = /* get */((m,k) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { return m.entries[i].value; } return null; })(<any>map, key);
            if(result == null) {
                {
                    result = /* get */((m,k) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { return m.entries[i].value; } return null; })(<any>map, key);
                    if(result == null) {
                        result = creator.create(key);
                        /* put */((m,k,v) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { m.entries[i].value=v; return; } m.entries.push({key:k,value:v,getKey: function() { return this.key }, getValue: function() { return this.value }}); })(<any>map, key, result);
                    } else {
                        if(TestRunner.DEBUG_CACHE) {
                            console.info("reusing " + result);
                        }
                    }
                };
            } else {
                if(TestRunner.DEBUG_CACHE) {
                    console.info("reusing " + result);
                }
            }
            return result;
        }

        public getFromAddressMap$java_lang_Integer$inet_ipaddr_test_TestRunner_Creator(key : number, addressCreator : TestRunner.Creator<number, IPv4Address>) : IPv4Address {
            return <any>(Cache.getFromMap<any, any>(this.cachingIPIntMap, key, addressCreator));
        }

        public getFromAddressMap(key? : any, addressCreator? : any) : any {
            if(((typeof key === 'number') || key === null) && ((addressCreator != null && (addressCreator["__interfaces"] != null && addressCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressCreator.constructor != null && addressCreator.constructor["__interfaces"] != null && addressCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressCreator === null)) {
                return <any>this.getFromAddressMap$java_lang_Integer$inet_ipaddr_test_TestRunner_Creator(key, addressCreator);
            } else if(((key != null && key instanceof <any>TestBase.IPAddressKey) || key === null) && ((addressCreator != null && (addressCreator["__interfaces"] != null && addressCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressCreator.constructor != null && addressCreator.constructor["__interfaces"] != null && addressCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressCreator === null)) {
                return <any>this.getFromAddressMap$inet_ipaddr_test_TestBase_IPAddressKey$inet_ipaddr_test_TestRunner_Creator(key, addressCreator);
            } else if(((key != null && key instanceof <any>MACAddressTest.MACAddressKey) || key === null) && ((addressCreator != null && (addressCreator["__interfaces"] != null && addressCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressCreator.constructor != null && addressCreator.constructor["__interfaces"] != null && addressCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressCreator === null)) {
                return <any>this.getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressKey$inet_ipaddr_test_TestRunner_Creator(key, addressCreator);
            } else if(((key != null && key instanceof <any>MACAddressTest.MACAddressLongKey) || key === null) && ((addressCreator != null && (addressCreator["__interfaces"] != null && addressCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressCreator.constructor != null && addressCreator.constructor["__interfaces"] != null && addressCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressCreator === null)) {
                return <any>this.getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressLongKey$inet_ipaddr_test_TestRunner_Creator(key, addressCreator);
            } else throw new Error('invalid overload');
        }

        getFromAddressMap$inet_ipaddr_test_TestBase_IPAddressKey$inet_ipaddr_test_TestRunner_Creator(key : TestBase.IPAddressKey, addressCreator : TestRunner.Creator<TestBase.IPAddressKey, IPAddress>) : IPAddress {
            return <any>(Cache.getFromMap<any, any>(this.cachingIPMap, key, addressCreator));
        }

        public getFromAddressStringMap$inet_ipaddr_test_TestBase_IPAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key : TestBase.IPAddressStringKey, addressStringCreator : TestRunner.Creator<TestBase.IPAddressStringKey, IPAddressString>) : IPAddressString {
            return <any>(Cache.getFromMap<any, any>(this.cachingIPStringMap, key, addressStringCreator));
        }

        public getFromAddressStringMap(key? : any, addressStringCreator? : any) : any {
            if(((key != null && key instanceof <any>TestBase.IPAddressStringKey) || key === null) && ((addressStringCreator != null && (addressStringCreator["__interfaces"] != null && addressStringCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressStringCreator.constructor != null && addressStringCreator.constructor["__interfaces"] != null && addressStringCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressStringCreator === null)) {
                return <any>this.getFromAddressStringMap$inet_ipaddr_test_TestBase_IPAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key, addressStringCreator);
            } else if(((key != null && key instanceof <any>MACAddressTest.MACAddressStringKey) || key === null) && ((addressStringCreator != null && (addressStringCreator["__interfaces"] != null && addressStringCreator["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0 || addressStringCreator.constructor != null && addressStringCreator.constructor["__interfaces"] != null && addressStringCreator.constructor["__interfaces"].indexOf("inet.ipaddr.test.TestRunner.Creator") >= 0)) || addressStringCreator === null)) {
                return <any>this.getFromAddressStringMap$inet_ipaddr_test_MACAddressTest_MACAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key, addressStringCreator);
            } else throw new Error('invalid overload');
        }

        getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressKey$inet_ipaddr_test_TestRunner_Creator(key : MACAddressTest.MACAddressKey, addressCreator : TestRunner.Creator<MACAddressTest.MACAddressKey, MACAddress>) : MACAddress {
            return <any>(Cache.getFromMap<any, any>(this.cachingMACMap, key, addressCreator));
        }

        getFromAddressMap$inet_ipaddr_test_MACAddressTest_MACAddressLongKey$inet_ipaddr_test_TestRunner_Creator(key : MACAddressTest.MACAddressLongKey, addressCreator : TestRunner.Creator<MACAddressTest.MACAddressLongKey, MACAddress>) : MACAddress {
            return <any>(Cache.getFromMap<any, any>(this.cachingMACLongMap, key, addressCreator));
        }

        getFromAddressStringMap$inet_ipaddr_test_MACAddressTest_MACAddressStringKey$inet_ipaddr_test_TestRunner_Creator(key : MACAddressTest.MACAddressStringKey, addressStringCreator : TestRunner.Creator<MACAddressTest.MACAddressStringKey, MACAddressString>) : MACAddressString {
            return <any>(Cache.getFromMap<any, any>(this.cachingMACStringMap, key, addressStringCreator));
        }

        getFromHostMap(key : TestBase.HostKey, hostCreator : TestRunner.Creator<TestBase.HostKey, HostName>) : HostName {
            return <any>(Cache.getFromMap<any, any>(this.cachingHostMap, key, hostCreator));
        }

        clear() {
            this.cachingIPStringMap.clear();
            this.cachingIPMap.clear();
            this.cachingHostMap.clear();
            this.cachingMACMap.clear();
            this.cachingMACStringMap.clear();
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>TestRunner.Cache) {
                let other : TestRunner.Cache = <TestRunner.Cache>o;
                return this.cachingIPStringMap.equals(other.cachingIPStringMap) && this.cachingIPMap.equals(other.cachingIPMap) && this.cachingHostMap.equals(other.cachingHostMap);
            }
            return false;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            return "IPAddressString count: " + this.cachingIPStringMap.size() + "; IPAddress count: " + this.cachingIPMap.size() + "; Host count: " + this.cachingHostMap.size() + "; " + "; MACAddressString count: " + this.cachingMACStringMap.size() + "; MACAddress count: " + this.cachingMACMap.size();
        }

        constructor() {
        }
    }
    Cache["__class"] = "inet.ipaddr.test.TestRunner.Cache";
    Cache["__interfaces"] = ["java.io.Serializable"];



    export class EfficientByteArrayOuputStream {
        public static BOUNDARY_SIZE : number = 1024;

        streamList : Array<number[]> = <any>([]);

        currentCount : number;

        public constructor() {
            if(this.currentCount===undefined) this.currentCount = 0;
            this.add();
        }

        getBytes() : Array<any> {
            let result : Array<number[]> = <any>(this.streamList.slice(0));
            let lastIndex : number = /* size */(<number>result.length) - 1;
            if(this.currentCount < EfficientByteArrayOuputStream.BOUNDARY_SIZE) {
                let last : number[] = this.streamList.getLast();
                last = /* copyOf */last.slice(0,this.currentCount);
                /* add */result.splice(lastIndex, 0, last);
            }
            return result;
        }

        toByteArray() : number[] {
            let result : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(this.getCount());
            let current : number = 0;
            for(let i : number = 0; i < /* size */(<number>this.streamList.length) - 1; i++, current += EfficientByteArrayOuputStream.BOUNDARY_SIZE) {
                let bytes : number[] = /* get */this.streamList[i];
                /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(bytes, 0, result, current, EfficientByteArrayOuputStream.BOUNDARY_SIZE);
            };
            let last : number[] = this.streamList.getLast();
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(last, 0, result, current, this.currentCount);
            return result;
        }

        getCount() : number {
            let total : number = 0;
            for(let index179=0; index179 < this.streamList.length; index179++) {
                let bytes = this.streamList[index179];
                {
                    total += bytes.length;
                }
            }
            total -= (EfficientByteArrayOuputStream.BOUNDARY_SIZE - this.currentCount);
            return total;
        }

        add() : number[] {
            let toAdd : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(EfficientByteArrayOuputStream.BOUNDARY_SIZE);
            /* add */(this.streamList.push(toAdd)>0);
            this.currentCount = 0;
            return toAdd;
        }

        public write$int(b : number) {
            let current : number[];
            if(this.currentCount === EfficientByteArrayOuputStream.BOUNDARY_SIZE) {
                current = this.add();
            } else {
                current = this.streamList.getLast();
            }
            current[this.currentCount++] = (<number>b|0);
        }

        public write$byte_A$int$int(b : number[], off : number, len : number) {
            let current : number[] = this.streamList.getLast();
            while((this.currentCount + len > EfficientByteArrayOuputStream.BOUNDARY_SIZE)) {
                let toWrite : number = EfficientByteArrayOuputStream.BOUNDARY_SIZE - this.currentCount;
                /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(b, off, current, this.currentCount, toWrite);
                len -= toWrite;
                off += toWrite;
                current = this.add();
            };
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(b, off, current, this.currentCount, len);
            this.currentCount += len;
        }

        /**
         * 
         * @param {Array} b
         * @param {number} off
         * @param {number} len
         */
        public write(b? : any, off? : any, len? : any) : any {
            if(((b != null && b instanceof <any>Array && (b.length==0 || b[0] == null ||(typeof b[0] === 'number'))) || b === null) && ((typeof off === 'number') || off === null) && ((typeof len === 'number') || len === null)) {
                return <any>this.write$byte_A$int$int(b, off, len);
            } else if(((typeof b === 'number') || b === null) && off === undefined && len === undefined) {
                return <any>this.write$int(b);
            } else throw new Error('invalid overload');
        }
    }
    EfficientByteArrayOuputStream["__class"] = "inet.ipaddr.test.TestRunner.EfficientByteArrayOuputStream";
    EfficientByteArrayOuputStream["__interfaces"] = ["java.io.Closeable","java.lang.AutoCloseable","java.io.Flushable"];



    export class EfficientByteArrayInputStream {
        streamList : Array<number[]>;

        currentCount : number;

        totalRead : number;

        constructor(initial : Array<any>) {
            if(this.streamList===undefined) this.streamList = null;
            if(this.currentCount===undefined) this.currentCount = 0;
            if(this.totalRead===undefined) this.totalRead = 0;
            this.streamList = <any>(initial.slice(0));
        }

        public read$() : number {
            if(/* isEmpty */(this.streamList.length == 0)) {
                return -1;
            }
            let current : number[] = this.streamList.getFirst();
            let result : number = current[this.currentCount++];
            if(this.currentCount === current.length) {
                this.remove();
            }
            this.totalRead++;
            return result;
        }

        remove() {
            this.currentCount = 0;
            this.streamList.removeFirst();
        }

        public read$byte_A$int$int(b : number[], off : number, len : number) : number {
            let originalLen : number = len;
            if(/* isEmpty */(this.streamList.length == 0)) {
                return -1;
            }
            let current : number[] = this.streamList.getFirst();
            while((this.currentCount + len >= current.length)) {
                let bytes : number = current.length - this.currentCount;
                /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(current, this.currentCount, b, off, bytes);
                len -= bytes;
                off += bytes;
                this.remove();
                if(/* isEmpty */(this.streamList.length == 0)) {
                    return originalLen - len;
                }
                current = this.streamList.getFirst();
            };
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(current, this.currentCount, b, off, len);
            this.currentCount += len;
            this.totalRead += len;
            return originalLen;
        }

        /**
         * 
         * @param {Array} b
         * @param {number} off
         * @param {number} len
         * @return {number}
         */
        public read(b? : any, off? : any, len? : any) : any {
            if(((b != null && b instanceof <any>Array && (b.length==0 || b[0] == null ||(typeof b[0] === 'number'))) || b === null) && ((typeof off === 'number') || off === null) && ((typeof len === 'number') || len === null)) {
                return <any>this.read$byte_A$int$int(b, off, len);
            } else if(b === undefined && off === undefined && len === undefined) {
                return <any>this.read$();
            } else throw new Error('invalid overload');
        }

        getBytesRead() : number {
            return this.totalRead;
        }
    }
    EfficientByteArrayInputStream["__class"] = "inet.ipaddr.test.TestRunner.EfficientByteArrayInputStream";
    EfficientByteArrayInputStream["__interfaces"] = ["java.io.Closeable","java.lang.AutoCloseable"];



    export class TestRunner$0 implements TestRunner.Creator<TestBase.HostKey, HostName> {
        public __parent: any;
        public create$inet_ipaddr_test_TestBase_HostKey(hostKey : TestBase.HostKey) : HostName {
            if(hostKey.options == null) {
                return new HostName(hostKey.keyString, TestBase.HOST_OPTIONS_$LI$());
            }
            return new HostName(hostKey.keyString, hostKey.options);
        }

        /**
         * 
         * @param {TestBase.HostKey} hostKey
         * @return {HostName}
         */
        public create(hostKey? : any) : any {
            if(((hostKey != null && hostKey instanceof <any>TestBase.HostKey) || hostKey === null)) {
                return <any>this.create$inet_ipaddr_test_TestBase_HostKey(hostKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$0["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$1 implements TestRunner.Creator<TestBase.IPAddressStringKey, IPAddressString> {
        public __parent: any;
        public create$inet_ipaddr_test_TestBase_IPAddressStringKey(addressStringKey : TestBase.IPAddressStringKey) : IPAddressString {
            if(addressStringKey.options == null) {
                return new IPAddressString(addressStringKey.keyString, TestBase.ADDRESS_OPTIONS_$LI$());
            }
            return new IPAddressString(addressStringKey.keyString, addressStringKey.options);
        }

        /**
         * 
         * @param {TestBase.IPAddressStringKey} addressStringKey
         * @return {IPAddressString}
         */
        public create(addressStringKey? : any) : any {
            if(((addressStringKey != null && addressStringKey instanceof <any>TestBase.IPAddressStringKey) || addressStringKey === null)) {
                return <any>this.create$inet_ipaddr_test_TestBase_IPAddressStringKey(addressStringKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$1["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$2 implements TestRunner.Creator<TestBase.IPAddressKey, IPAddress> {
        public __parent: any;
        public create$inet_ipaddr_test_TestBase_IPAddressKey(addressKey : TestBase.IPAddressKey) : IPAddress {
            if(addressKey.bytes.length === 4) {
                return new IPv4Address(addressKey.bytes);
            }
            return new IPv6Address(addressKey.bytes);
        }

        /**
         * 
         * @param {TestBase.IPAddressKey} addressKey
         * @return {IPAddress}
         */
        public create(addressKey? : any) : any {
            if(((addressKey != null && addressKey instanceof <any>TestBase.IPAddressKey) || addressKey === null)) {
                return <any>this.create$inet_ipaddr_test_TestBase_IPAddressKey(addressKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$2["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$3 implements TestRunner.Creator<number, IPv4Address> {
        public __parent: any;
        public create$java_lang_Integer(addressKey : number) : IPv4Address {
            return new IPv4Address(addressKey);
        }

        /**
         * 
         * @param {number} addressKey
         * @return {IPv4Address}
         */
        public create(addressKey? : any) : any {
            if(((typeof addressKey === 'number') || addressKey === null)) {
                return <any>this.create$java_lang_Integer(addressKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$3["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$4 implements TestRunner.Creator<MACAddressTest.MACAddressStringKey, MACAddressString> {
        public __parent: any;
        public create$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(addressStringKey : MACAddressTest.MACAddressStringKey) : MACAddressString {
            if(addressStringKey.options == null) {
                return new MACAddressString(addressStringKey.keyString, TestBase.MAC_ADDRESS_OPTIONS_$LI$());
            }
            return new MACAddressString(addressStringKey.keyString, addressStringKey.options);
        }

        /**
         * 
         * @param {MACAddressTest.MACAddressStringKey} addressStringKey
         * @return {MACAddressString}
         */
        public create(addressStringKey? : any) : any {
            if(((addressStringKey != null && addressStringKey instanceof <any>MACAddressTest.MACAddressStringKey) || addressStringKey === null)) {
                return <any>this.create$inet_ipaddr_test_MACAddressTest_MACAddressStringKey(addressStringKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$4["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$5 implements TestRunner.Creator<MACAddressTest.MACAddressKey, MACAddress> {
        public __parent: any;
        public create$inet_ipaddr_test_MACAddressTest_MACAddressKey(addressKey : MACAddressTest.MACAddressKey) : MACAddress {
            return new MACAddress(addressKey.bytes);
        }

        /**
         * 
         * @param {MACAddressTest.MACAddressKey} addressKey
         * @return {MACAddress}
         */
        public create(addressKey? : any) : any {
            if(((addressKey != null && addressKey instanceof <any>MACAddressTest.MACAddressKey) || addressKey === null)) {
                return <any>this.create$inet_ipaddr_test_MACAddressTest_MACAddressKey(addressKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$5["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$6 implements TestRunner.Creator<MACAddressTest.MACAddressLongKey, MACAddress> {
        public __parent: any;
        public create$inet_ipaddr_test_MACAddressTest_MACAddressLongKey(addressKey : MACAddressTest.MACAddressLongKey) : MACAddress {
            return new MACAddress(addressKey.val, addressKey.extended);
        }

        /**
         * 
         * @param {MACAddressTest.MACAddressLongKey} addressKey
         * @return {MACAddress}
         */
        public create(addressKey? : any) : any {
            if(((addressKey != null && addressKey instanceof <any>MACAddressTest.MACAddressLongKey) || addressKey === null)) {
                return <any>this.create$inet_ipaddr_test_MACAddressTest_MACAddressLongKey(addressKey);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$6["__interfaces"] = ["inet.ipaddr.test.TestRunner.Creator"];



    export class TestRunner$7 {
        public __parent: any;
        /**
         * 
         */
        public run() {
            try {
                this.barrier.await();
                (target => (typeof target === 'function')?target():(<any>target).run())(this.runnable);
            } catch(e) {
                console.error(e.message, e);
            };
        }

        constructor(__parent: any, private barrier: any, private runnable: any) {
            this.__parent = __parent;
        }
    }
    TestRunner$7["__interfaces"] = ["java.lang.Runnable"];


}




TestRunner.main(null);
