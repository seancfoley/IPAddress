/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { HostName } from '../HostName';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddress } from '../IPAddress';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { MACAddressString } from '../MACAddressString';
import { MACAddressStringParameters } from '../MACAddressStringParameters';
import { IPAddressLargeDivision } from '../format/IPAddressLargeDivision';
import { MACAddress } from '../mac/MACAddress';
import { TestBase } from './TestBase';
import { AddressStringParameters } from '../AddressStringParameters';
import { AddressCreator } from './AddressCreator';
import { IPv6AddressStringParameters } from '../ipv6/IPv6AddressStringParameters';
import { IPv4AddressStringParameters } from '../ipv4/IPv4AddressStringParameters';
import { AddressNetwork } from '../AddressNetwork';

export class SpecialTypesTest extends TestBase {
    static HOST_OPTIONS : HostNameParameters; public static HOST_OPTIONS_$LI$() : HostNameParameters { if(SpecialTypesTest.HOST_OPTIONS == null) SpecialTypesTest.HOST_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toBuilder().allowEmpty(true).setEmptyAsLoopback(true).getAddressOptionsBuilder().allowEmpty(false).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).allowAll(true).getParentBuilder().toParams(); return SpecialTypesTest.HOST_OPTIONS; };

    static ADDRESS_OPTIONS : IPAddressStringParameters; public static ADDRESS_OPTIONS_$LI$() : IPAddressStringParameters { if(SpecialTypesTest.ADDRESS_OPTIONS == null) SpecialTypesTest.ADDRESS_OPTIONS = SpecialTypesTest.HOST_OPTIONS_$LI$().toAddressOptionsBuilder().allowEmpty(true).setEmptyAsLoopback(true).toParams(); return SpecialTypesTest.ADDRESS_OPTIONS; };

    static MAC_OPTIONS : MACAddressStringParameters; public static MAC_OPTIONS_$LI$() : MACAddressStringParameters { if(SpecialTypesTest.MAC_OPTIONS == null) SpecialTypesTest.MAC_OPTIONS = TestBase.MAC_ADDRESS_OPTIONS_$LI$().toBuilder().allowEmpty(true).setRangeOptions(AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$()).allowAll(true).toParams(); return SpecialTypesTest.MAC_OPTIONS; };

    static EMPTY_ADDRESS_OPTIONS : HostNameParameters; public static EMPTY_ADDRESS_OPTIONS_$LI$() : HostNameParameters { if(SpecialTypesTest.EMPTY_ADDRESS_OPTIONS == null) SpecialTypesTest.EMPTY_ADDRESS_OPTIONS = TestBase.HOST_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().allowEmpty(true).setEmptyAsLoopback(true).getParentBuilder().toParams(); return SpecialTypesTest.EMPTY_ADDRESS_OPTIONS; };

    static EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS : HostNameParameters; public static EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS_$LI$() : HostNameParameters { if(SpecialTypesTest.EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS == null) SpecialTypesTest.EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS = SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$().toBuilder().getAddressOptionsBuilder().setEmptyAsLoopback(false).getParentBuilder().toParams(); return SpecialTypesTest.EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    public createHost$java_lang_String$inet_ipaddr_HostNameParameters(x : string, options : HostNameParameters) : HostName {
        let key : TestBase.HostKey = new TestBase.HostKey(x, options);
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(key);
    }

    /**
     * 
     * @param {string} x
     * @param {HostNameParameters} options
     * @return {HostName}
     */
    public createHost(x? : any, options? : any) : any {
        if(((typeof x === 'string') || x === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            return <any>this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(x, options);
        } else if(((x != null && x instanceof <any>TestBase.HostKey) || x === null) && options === undefined) {
            return <any>this.createHost$inet_ipaddr_test_TestBase_HostKey(x);
        } else if(((typeof x === 'string') || x === null) && options === undefined) {
            return <any>this.createHost$java_lang_String(x);
        } else throw new Error('invalid overload');
    }

    testIPv4Strings(addr : string, explicit : boolean, normalizedString : string, normalizedWildcardString : string, sqlString : string, fullString : string, reverseDNSString : string, singleHex : string, singleOctal : string) {
        let w : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(addr, SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        let ipAddr : IPAddress;
        if(explicit) {
            ipAddr = w.getAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV4);
        } else {
            ipAddr = w.getAddress();
        }
        this.testStrings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, normalizedWildcardString, sqlString, fullString, normalizedString, normalizedString, normalizedWildcardString, normalizedString, normalizedWildcardString, reverseDNSString, normalizedString, singleHex, singleOctal);
    }

    public testIPv6Strings(w? : any, ipAddr? : any, normalizedString? : any, normalizedWildcardString? : any, canonicalWildcardString? : any, sqlString? : any, fullString? : any, compressedString? : any, canonicalString? : any, subnetString? : any, compressedWildcardString? : any, mixedStringNoCompressMixed? : any, mixedStringNoCompressHost? : any, mixedStringCompressCoveredHost? : any, mixedString? : any, reverseDNSString? : any, uncHostString? : any, base85String? : any, singleHex? : any, singleOctal? : any) : any {
        if(((w != null && w instanceof <any>IPAddressString) || w === null) && ((ipAddr != null && ipAddr instanceof <any>IPAddress) || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof mixedStringNoCompressMixed === 'string') || mixedStringNoCompressMixed === null) && ((typeof mixedStringNoCompressHost === 'string') || mixedStringNoCompressHost === null) && ((typeof mixedStringCompressCoveredHost === 'string') || mixedStringCompressCoveredHost === null) && ((typeof mixedString === 'string') || mixedString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof base85String === 'string') || base85String === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            super.testIPv6Strings(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
        } else if(((typeof w === 'string') || w === null) && ((typeof ipAddr === 'boolean') || ipAddr === null) && ((typeof normalizedString === 'string') || normalizedString === null) && ((typeof normalizedWildcardString === 'string') || normalizedWildcardString === null) && ((typeof canonicalWildcardString === 'string') || canonicalWildcardString === null) && ((typeof sqlString === 'string') || sqlString === null) && ((typeof fullString === 'string') || fullString === null) && ((typeof compressedString === 'string') || compressedString === null) && ((typeof canonicalString === 'string') || canonicalString === null) && ((typeof subnetString === 'string') || subnetString === null) && ((typeof compressedWildcardString === 'string') || compressedWildcardString === null) && ((typeof mixedStringNoCompressMixed === 'string') || mixedStringNoCompressMixed === null) && ((typeof mixedStringNoCompressHost === 'string') || mixedStringNoCompressHost === null) && ((typeof mixedStringCompressCoveredHost === 'string') || mixedStringCompressCoveredHost === null) && ((typeof mixedString === 'string') || mixedString === null) && ((typeof reverseDNSString === 'string') || reverseDNSString === null) && ((typeof uncHostString === 'string') || uncHostString === null) && ((typeof base85String === 'string') || base85String === null) && ((typeof singleHex === 'string') || singleHex === null) && ((typeof singleOctal === 'string') || singleOctal === null)) {
            return <any>this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
        } else throw new Error('invalid overload');
    }

    testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(addr : string, explicit : boolean, normalizedString : string, normalizedWildcardString : string, canonicalWildcardString : string, sqlString : string, fullString : string, compressedString : string, canonicalString : string, subnetString : string, compressedWildcardString : string, mixedStringNoCompressMixed : string, mixedStringNoCompressHost : string, mixedStringCompressCoveredHost : string, mixedString : string, reverseDNSString : string, uncHostString : string, base85String : string, singleHex : string, singleOctal : string) {
        let w : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(addr, SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        let ipAddr : IPAddress;
        if(explicit) {
            ipAddr = w.getAddress$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV6);
        } else {
            ipAddr = w.getAddress();
        }
        this.testIPv6Strings$inet_ipaddr_IPAddressString$inet_ipaddr_IPAddress$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String(w, ipAddr, normalizedString, normalizedWildcardString, canonicalWildcardString, sqlString, fullString, compressedString, canonicalString, subnetString, compressedWildcardString, mixedStringNoCompressMixed, mixedStringNoCompressHost, mixedStringCompressCoveredHost, mixedString, reverseDNSString, uncHostString, base85String, singleHex, singleOctal);
    }

    testAllMACValues(count1 : BigInteger, count2 : BigInteger) {
        let macAll : MACAddress = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters("*", SpecialTypesTest.MAC_OPTIONS_$LI$()).getAddress();
        let macAll2 : MACAddress = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters("*:*:*:*:*:*:*", SpecialTypesTest.MAC_OPTIONS_$LI$()).getAddress();
        let address1Str : string = "*:*:*:*:*:*";
        let address2Str : string = "*:*:*:*:*:*:*:*";
        let mac1 : MACAddress = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(address1Str, SpecialTypesTest.MAC_OPTIONS_$LI$()).getAddress();
        let mac2 : MACAddress = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters(address2Str, SpecialTypesTest.MAC_OPTIONS_$LI$()).getAddress();
        if(!macAll.equals(mac1)) {
            this.addFailure(new TestBase.Failure("no match " + macAll, mac1));
        } else if(!macAll2.equals(mac2)) {
            this.addFailure(new TestBase.Failure("no match " + macAll2, mac2));
        } else if(macAll.compareTo(mac1) !== 0) {
            this.addFailure(new TestBase.Failure("no match " + macAll, mac1));
        } else if(macAll2.compareTo(mac2) !== 0) {
            this.addFailure(new TestBase.Failure("no match " + macAll2, mac2));
        } else if(!macAll.getCount().equals(count1)) {
            this.addFailure(new TestBase.Failure("no count match ", macAll));
        } else if(!macAll2.getCount().equals(count2)) {
            this.addFailure(new TestBase.Failure("no count match ", macAll2));
        }
        this.incrementTestCount();
    }

    public testAllValues$inet_ipaddr_IPAddress_IPVersion$java_math_BigInteger(version : IPAddress.IPVersion, count : BigInteger) {
        let hostAll : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("*", SpecialTypesTest.HOST_OPTIONS_$LI$());
        let addressAllStr : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        let addressAll : IPAddress = addressAllStr.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
        let address2Str : string = IPAddress.IPVersion["_$wrappers"][version].isIPv4()?"*.*.*.*":"*:*:*:*:*:*:*:*";
        let address : IPAddress = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(address2Str, SpecialTypesTest.ADDRESS_OPTIONS_$LI$()).getAddress();
        if(!addressAll.equals(address)) {
            this.addFailure(new TestBase.Failure("no match " + address, addressAll));
        } else if(addressAll.compareTo(address) !== 0) {
            this.addFailure(new TestBase.Failure("no match " + address, addressAll));
        } else if(!addressAll.getCount().equals(count)) {
            this.addFailure(new TestBase.Failure("no count match ", addressAll));
        } else {
            addressAll = hostAll.asAddress$inet_ipaddr_IPAddress_IPVersion(version);
            if(!addressAll.equals(address)) {
                this.addFailure(new TestBase.Failure("no match " + address, addressAll));
            } else if(addressAll.compareTo(address) !== 0) {
                this.addFailure(new TestBase.Failure("no match " + address, addressAll));
            } else if(!addressAll.getCount().equals(count)) {
                this.addFailure(new TestBase.Failure("no count match ", addressAll));
            }
        }
        this.incrementTestCount();
    }

    public testAllValues(version? : any, count? : any) : any {
        if(((typeof version === 'number') || version === null) && ((count != null && count instanceof <any>BigInteger) || count === null)) {
            return <any>this.testAllValues$inet_ipaddr_IPAddress_IPVersion$java_math_BigInteger(version, count);
        } else if(version === undefined && count === undefined) {
            return <any>this.testAllValues$();
        } else throw new Error('invalid overload');
    }

    testAllValues$() {
        let hostAll : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("*", SpecialTypesTest.HOST_OPTIONS_$LI$());
        let addressAll : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        let macAll : MACAddressString = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters("*", SpecialTypesTest.MAC_OPTIONS_$LI$());
        if(addressAll.getAddress() != null) {
            this.addFailure(new TestBase.Failure("non null", addressAll));
        } else if(hostAll.asAddress() != null) {
            this.addFailure(new TestBase.Failure("non null", hostAll));
        } else if(hostAll.getAddress() != null) {
            this.addFailure(new TestBase.Failure("non null", hostAll));
        } else if(macAll.getAddress() == null) {
            this.addFailure(new TestBase.Failure("null", macAll));
        }
        this.incrementTestCount();
    }

    testEmptyValues() {
        let hostEmpty : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.HOST_OPTIONS_$LI$());
        let addressEmpty : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        try {
            let addr : InetAddress = InetAddress.getByName("");
            let addr2 : InetAddress = InetAddress.getByName(null);
            let params : IPAddressStringParameters.IPAddressStringFormatParameters = (addr != null && addr instanceof <any>Inet6Address)?SpecialTypesTest.ADDRESS_OPTIONS_$LI$().getIPv6Parameters():SpecialTypesTest.ADDRESS_OPTIONS_$LI$().getIPv4Parameters();
            let network : IPAddressNetwork<any, any, any, any, any> = params.getNetwork();
            let address : IPAddress = network.getAddressCreator().createAddress$byte_A(addr.getAddress());
            let params2 : IPAddressStringParameters.IPAddressStringFormatParameters = (addr2 != null && addr2 instanceof <any>Inet6Address)?SpecialTypesTest.ADDRESS_OPTIONS_$LI$().getIPv6Parameters():SpecialTypesTest.ADDRESS_OPTIONS_$LI$().getIPv4Parameters();
            let network2 : IPAddressNetwork<any, any, any, any, any> = params2.getNetwork();
            let address2 : IPAddress = network2.getAddressCreator().createAddress$byte_A(addr2.getAddress());
            if(!addressEmpty.getAddress().equals(address)) {
                this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
            } else if(!addressEmpty.getAddress().equals(address2)) {
                this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
            } else if(addressEmpty.getAddress().compareTo(address) !== 0) {
                this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
            } else if(addressEmpty.getAddress().compareTo(address2) !== 0) {
                this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
            } else if(!addressEmpty.getAddress().getCount().equals(BigInteger.ONE)) {
                this.addFailure(new TestBase.Failure("no count match " + addr2, addressEmpty));
            } else {
                addressEmpty = hostEmpty.asAddressString();
                if(addressEmpty != null) {
                    this.addFailure(new TestBase.Failure("host treated as address " + addr, addressEmpty));
                } else {
                    addressEmpty = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$()).asAddressString();
                    if(addressEmpty == null || !addressEmpty.getAddress().equals(address)) {
                        this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
                    } else if(!addressEmpty.getAddress().equals(address2)) {
                        this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
                    } else if(addressEmpty.getAddress().compareTo(address) !== 0) {
                        this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
                    } else if(addressEmpty.getAddress().compareTo(address2) !== 0) {
                        this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
                    } else if(!addressEmpty.getAddress().getCount().equals(BigInteger.ONE)) {
                        this.addFailure(new TestBase.Failure("no count match " + addr2, addressEmpty));
                    } else {
                        let addressEmptyValue : IPAddress = hostEmpty.getAddress();
                        if(!addressEmptyValue.equals(address)) {
                            this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
                        } else if(!addressEmptyValue.equals(address2)) {
                            this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
                        } else if(addressEmptyValue.compareTo(address) !== 0) {
                            this.addFailure(new TestBase.Failure("no match " + addr, addressEmpty));
                        } else if(addressEmptyValue.compareTo(address2) !== 0) {
                            this.addFailure(new TestBase.Failure("no match " + addr2, addressEmpty));
                        } else if(!addressEmptyValue.getCount().equals(BigInteger.ONE)) {
                            this.addFailure(new TestBase.Failure("no count match " + addr2, addressEmpty));
                        }
                    }
                }
            }
        } catch(e) {
            this.addFailure(new TestBase.Failure("unexpected unknown host", addressEmpty));
        };
        this.incrementTestCount();
    }

    testInvalidValues() {
        let addressAll : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*/f0ff::", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        try {
            addressAll.getAddress();
            this.addFailure(new TestBase.Failure("unexpectedly valid", addressAll));
        } catch(e) {
            addressAll = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*/fff0::", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
            try {
                if(addressAll.getAddress() == null) {
                    this.addFailure(new TestBase.Failure("unexpectedly invalid", addressAll));
                } else {
                    addressAll = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
                    if(addressAll.getAddress() != null) {
                        this.addFailure(new TestBase.Failure("unexpectedly invalid", addressAll));
                    } else {
                        addressAll = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*/16", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
                        if(addressAll.getAddress() != null) {
                            this.addFailure(new TestBase.Failure("unexpectedly invalid", addressAll));
                        }
                    }
                }
            } catch(e2) {
                this.addFailure(new TestBase.Failure("unexpectedly valid", addressAll));
            };
        };
    }

    testValidity() {
        let hostEmpty : HostName = this.createHost$java_lang_String("");
        let hostAll : HostName = this.createHost$java_lang_String("*");
        let hostAllIPv4 : HostName = this.createHost$java_lang_String("*.*.*.*");
        let hostAllIPv6 : HostName = this.createHost$java_lang_String("*:*:*:*:*:*:*:*");
        let addressEmpty : IPAddressString = this.createAddress$java_lang_String("");
        let addressAll : IPAddressString = this.createAddress$java_lang_String("*");
        let macEmpty : MACAddressString = this.createMACAddress$java_lang_String("");
        let macAll : MACAddressString = this.createMACAddress$java_lang_String("*");
        if(hostEmpty.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostEmpty));
        } else if(hostAll.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostAll));
        } else if(hostAllIPv4.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostAllIPv4));
        } else if(hostAllIPv6.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostAllIPv6));
        } else if(addressEmpty.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", addressEmpty));
        } else if(addressAll.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", addressAll));
        } else if(macEmpty.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", macEmpty));
        } else if(macAll.isValid()) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", macAll));
        } else if(hostAll.getAddress() != null) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostAll));
        } else if(hostEmpty.getAddress() != null) {
            this.addFailure(new TestBase.Failure("unexpectedly valid", hostEmpty));
        } else {
            hostEmpty = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.HOST_OPTIONS_$LI$());
            hostAll = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("*", SpecialTypesTest.HOST_OPTIONS_$LI$());
            hostAllIPv4 = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("*.*.*.*", SpecialTypesTest.HOST_OPTIONS_$LI$());
            hostAllIPv6 = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("*:*:*:*:*:*:*:*", SpecialTypesTest.HOST_OPTIONS_$LI$());
            addressEmpty = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
            addressAll = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
            macEmpty = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters("", SpecialTypesTest.MAC_OPTIONS_$LI$());
            macAll = this.createMACAddress$java_lang_String$inet_ipaddr_MACAddressStringParameters("*", SpecialTypesTest.MAC_OPTIONS_$LI$());
            if(!hostEmpty.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostEmpty));
            } else if(!hostAll.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostAll));
            } else if(!hostAllIPv4.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostAllIPv4));
            } else if(!hostAllIPv6.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostAllIPv6));
            } else if(!addressEmpty.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", addressEmpty));
            } else if(!addressAll.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", addressAll));
            } else if(!macEmpty.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", macEmpty));
            } else if(!macAll.isValid()) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", macAll));
            } else if(hostEmpty.getAddress() == null) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostEmpty));
            } else if(hostAll.getAddress() != null) {
                this.addFailure(new TestBase.Failure("unexpectedly invalid", hostAll));
            } else {
                hostEmpty = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$());
                if(!hostEmpty.isValid()) {
                    this.addFailure(new TestBase.Failure("unexpectedly invalid", hostEmpty));
                } else if(hostEmpty.getAddress() == null) {
                    this.addFailure(new TestBase.Failure("unexpectedly invalid", hostEmpty));
                } else {
                    addressAll = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters("*.*/64", SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
                    if(addressAll.isValid()) {
                        this.addFailure(new TestBase.Failure("unexpectedly valid", addressAll));
                    }
                }
            }
        }
        this.incrementTestCount();
    }

    testEmptyIsSelf() {
        let w : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.HOST_OPTIONS_$LI$());
        if(w.isSelf()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + w.isSelf(), w));
        }
        let w2 : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$());
        if(!w2.isSelf()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + w2.isSelf(), w2));
        }
        this.incrementTestCount();
    }

    testSelf(host : string, isSelf : boolean) {
        let w : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(host, SpecialTypesTest.HOST_OPTIONS_$LI$());
        if(isSelf !== w.isSelf()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + isSelf, w));
        }
        this.incrementTestCount();
    }

    testEmptyLoopback() {
        let w : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.HOST_OPTIONS_$LI$());
        if(w.isLoopback()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + w.isSelf(), w));
        }
        let addressEmptyValue : IPAddress = w.getAddress();
        if(!addressEmptyValue.isLoopback()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + addressEmptyValue.isLoopback(), w));
        }
        let w2 : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$());
        if(!w2.isLoopback()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + w2.isSelf(), w2));
        }
        this.incrementTestCount();
    }

    testLoopback(host : string, isSelf : boolean) {
        let w : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters(host, SpecialTypesTest.HOST_OPTIONS_$LI$());
        if(isSelf !== w.isLoopback()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + isSelf, w));
        }
        let w2 : IPAddressString = this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(host, SpecialTypesTest.ADDRESS_OPTIONS_$LI$());
        if(isSelf !== w2.isLoopback()) {
            this.addFailure(new TestBase.Failure("failed: isSelf is " + isSelf, w));
        }
        this.incrementTestCount();
    }

    getCount(segmentMax : number, segmentCount : number) : BigInteger {
        let segCount : BigInteger = BigInteger.valueOf(segmentMax + 1);
        return segCount.pow(segmentCount);
    }

    /**
     * 
     */
    runTest() {
        let allSingleHex : string = "0x00000000-0xffffffff";
        let allSingleOctal : string = "000000000000-037777777777";
        let isNoAutoSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][TestBase.prefixConfiguration].prefixedSubnetsAreExplicit();
        this.testIPv4Strings("*", true, "*.*.*.*", "*.*.*.*", "%.%.%.%", "000-255.000-255.000-255.000-255", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("***.***.***.***", true, "*.*.*.*", "*.*.*.*", "%.%.%.%", "000-255.000-255.000-255.000-255", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*.*", false, "*.*.*.*", "*.*.*.*", "%.%.%.%", "000-255.000-255.000-255.000-255", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*/16", true, isNoAutoSubnets?"*.*.*.*/16":"*.*.0.0/16", "*.*.*.*", "%.%.%.%", isNoAutoSubnets?"000-255.000-255.000-255.000-255/16":"000-255.000-255.000.000/16", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*/255.255.0.0", false, isNoAutoSubnets?"*.*.*.*/16":"*.*.0.0/16", "*.*.*.*", "%.%.%.%", isNoAutoSubnets?"000-255.000-255.000-255.000-255/16":"000-255.000-255.000.000/16", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*/255.255.0.0", true, isNoAutoSubnets?"*.*.*.*/16":"*.*.0.0/16", "*.*.*.*", "%.%.%.%", isNoAutoSubnets?"000-255.000-255.000-255.000-255/16":"000-255.000-255.000.000/16", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*.*/16", false, isNoAutoSubnets?"*.*.*.*/16":"*.*.0.0/16", "*.*.*.*", "%.%.%.%", isNoAutoSubnets?"000-255.000-255.000-255.000-255/16":"000-255.000-255.000.000/16", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("*.*/16", true, isNoAutoSubnets?"*.*.*.*/16":"*.*.0.0/16", "*.*.*.*", "%.%.%.%", isNoAutoSubnets?"000-255.000-255.000-255.000-255/16":"000-255.000-255.000.000/16", "*.*.*.*.in-addr.arpa", allSingleHex, allSingleOctal);
        this.testIPv4Strings("", false, "127.0.0.1", "127.0.0.1", "127.0.0.1", "127.000.000.001", "1.0.0.127.in-addr.arpa", "0x7f000001", "017700000001");
        this.testIPv4Strings("", true, "127.0.0.1", "127.0.0.1", "127.0.0.1", "127.000.000.001", "1.0.0.127.in-addr.arpa", "0x7f000001", "017700000001");
        let base85All : string = "00000000000000000000" + IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$() + "=r54lj&NUUO~Hi%c2ym0";
        let base85AllPrefixed : string = base85All + "/16";
        let base85AllPrefixed64 : string = base85All + "/64";
        let base8516 : string = "00000000000000000000" + IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$() + "=q{+M|w0(OeO5^EGP660" + "/16";
        let base8564 : string = "00000000000000000000" + IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$() + "=r54lj&NUTUTif>jH#O0" + "/64";
        let allSingleHexIPv6 : string = "0x00000000000000000000000000000000-0xffffffffffffffffffffffffffffffff";
        let allSingleOctalIPv6 : string = "00000000000000000000000000000000000000000000-03777777777777777777777777777777777777777777";
        this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*", true, "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net", base85All, allSingleHexIPv6, allSingleOctalIPv6);
        this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*", false, "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net", base85All, allSingleHexIPv6, allSingleOctalIPv6);
        this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*", true, "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*:*:*:*:*:*:*.*.*.*", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net", base85All, allSingleHexIPv6, allSingleOctalIPv6);
        if(isNoAutoSubnets) {
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/16", true, "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/16", base85AllPrefixed, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/16", false, "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/16", base85AllPrefixed, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/16", true, "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/16", base85AllPrefixed, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/64", false, "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/64", base85AllPrefixed64, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/64", true, "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/64", base85AllPrefixed64, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/64", false, "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/64", base85AllPrefixed64, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/64", true, "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*:*:*:*:*:*:*.*.*.*/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/64", base85AllPrefixed64, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/ffff::", false, "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/16", base85AllPrefixed, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/ffff::", true, "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000-ffff/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*:*:*:*:*:*:*.*.*.*/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-*-*-*-*.ipv6-literal.net/16", base85AllPrefixed, allSingleHexIPv6, allSingleOctalIPv6);
        } else {
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/16", true, "*:0:0:0:0:0:0:0/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000:0000:0000:0000:0000:0000:0000/16", "*::/16", "*::/16", "*::/16", "*:*:*:*:*:*:*:*", "*::0.0.0.0/16", "*::0.0.0.0/16", "*::/16", "*::/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-0-0-0-0-0-0-0.ipv6-literal.net/16", base8516, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/16", false, "*:0:0:0:0:0:0:0/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000:0000:0000:0000:0000:0000:0000/16", "*::/16", "*::/16", "*::/16", "*:*:*:*:*:*:*:*", "*::0.0.0.0/16", "*::0.0.0.0/16", "*::/16", "*::/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-0-0-0-0-0-0-0.ipv6-literal.net/16", base8516, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/16", true, "*:0:0:0:0:0:0:0/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000:0000:0000:0000:0000:0000:0000/16", "*::/16", "*::/16", "*::/16", "*:*:*:*:*:*:*:*", "*::0.0.0.0/16", "*::0.0.0.0/16", "*::/16", "*::/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-0-0-0-0-0-0-0.ipv6-literal.net/16", base8516, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/64", false, "*:*:*:*:0:0:0:0/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000:0000:0000:0000/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*:*:*:*:*", "*:*:*:*::0.0.0.0/64", "*:*:*:*::0.0.0.0/64", "*:*:*:*::/64", "*:*:*:*::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-0-0-0-0.ipv6-literal.net/64", base8564, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/64", true, "*:*:*:*:0:0:0:0/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000:0000:0000:0000/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*:*:*:*:*", "*:*:*:*::0.0.0.0/64", "*:*:*:*::0.0.0.0/64", "*:*:*:*::/64", "*:*:*:*::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-0-0-0-0.ipv6-literal.net/64", base8564, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/64", false, "*:*:*:*:0:0:0:0/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000:0000:0000:0000/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*:*:*:*:*", "*:*:*:*::0.0.0.0/64", "*:*:*:*::0.0.0.0/64", "*:*:*:*::/64", "*:*:*:*::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-0-0-0-0.ipv6-literal.net/64", base8564, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*:*/64", true, "*:*:*:*:0:0:0:0/64", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000-ffff:0000-ffff:0000-ffff:0000:0000:0000:0000/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*::/64", "*:*:*:*:*:*:*:*", "*:*:*:*::0.0.0.0/64", "*:*:*:*::0.0.0.0/64", "*:*:*:*::/64", "*:*:*:*::/64", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-*-*-*-0-0-0-0.ipv6-literal.net/64", base8564, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/ffff::", false, "*:0:0:0:0:0:0:0/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000:0000:0000:0000:0000:0000:0000/16", "*::/16", "*::/16", "*::/16", "*:*:*:*:*:*:*:*", "*::0.0.0.0/16", "*::0.0.0.0/16", "*::/16", "*::/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-0-0-0-0-0-0-0.ipv6-literal.net/16", base8516, allSingleHexIPv6, allSingleOctalIPv6);
            this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("*/ffff::", true, "*:0:0:0:0:0:0:0/16", "*:*:*:*:*:*:*:*", "*:*:*:*:*:*:*:*", "%:%:%:%:%:%:%:%", "0000-ffff:0000:0000:0000:0000:0000:0000:0000/16", "*::/16", "*::/16", "*::/16", "*:*:*:*:*:*:*:*", "*::0.0.0.0/16", "*::0.0.0.0/16", "*::/16", "*::/16", "*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.*.ip6.arpa", "*-0-0-0-0-0-0-0.ipv6-literal.net/16", base8516, allSingleHexIPv6, allSingleOctalIPv6);
        }
        this.testIPv6Strings$java_lang_String$boolean$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String$java_lang_String("", true, "0:0:0:0:0:0:0:1", "0:0:0:0:0:0:0:1", "::1", "0:0:0:0:0:0:0:1", "0000:0000:0000:0000:0000:0000:0000:0001", "::1", "::1", "::1", "::1", "::0.0.0.1", "::0.0.0.1", "::0.0.0.1", "::0.0.0.1", "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa", "0-0-0-0-0-0-0-1.ipv6-literal.net", "00000000000000000001", "0x00000000000000000000000000000001", "00000000000000000000000000000000000000000001");
        this.testInvalidValues();
        this.testValidity();
        this.testEmptyValues();
        this.testAllValues();
        this.testAllValues$inet_ipaddr_IPAddress_IPVersion$java_math_BigInteger(IPAddress.IPVersion.IPV4, this.getCount(255, 4));
        this.testAllValues$inet_ipaddr_IPAddress_IPVersion$java_math_BigInteger(IPAddress.IPVersion.IPV6, this.getCount(65535, 8));
        this.testAllMACValues(this.getCount(255, 6), this.getCount(255, 8));
        let addressEmpty : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$());
        this.hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(addressEmpty, ["127", "0", "0", "1"]);
        let addressEmpty2 : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS_$LI$());
        this.hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(addressEmpty2, []);
        let hostEmpty : HostName = this.createHost$java_lang_String$inet_ipaddr_HostNameParameters("", SpecialTypesTest.HOST_OPTIONS_$LI$());
        this.hostLabelsTest$inet_ipaddr_HostName$java_lang_String_A(hostEmpty, []);
        this.testEmptyIsSelf();
        this.testSelf("localhost", true);
        this.testSelf("127.0.0.1", true);
        this.testSelf("::1", true);
        this.testSelf("[::1]", true);
        this.testSelf("*", false);
        this.testSelf("sean.com", false);
        this.testSelf("1.2.3.4", false);
        this.testSelf("::", false);
        this.testSelf("[::]", false);
        this.testSelf("[1:2:3:4:1:2:3:4]", false);
        this.testSelf("1:2:3:4:1:2:3:4", false);
        this.testEmptyLoopback();
        this.testLoopback("127.0.0.1", true);
        this.testLoopback("::1", true);
        this.testLoopback("*", false);
        this.testLoopback("1.2.3.4", false);
        this.testLoopback("::", false);
        this.testLoopback("1:2:3:4:1:2:3:4", false);
    }
}
SpecialTypesTest["__class"] = "inet.ipaddr.test.SpecialTypesTest";




SpecialTypesTest.EMPTY_ADDRESS_NO_LOOPBACK_OPTIONS_$LI$();

SpecialTypesTest.EMPTY_ADDRESS_OPTIONS_$LI$();

SpecialTypesTest.MAC_OPTIONS_$LI$();

SpecialTypesTest.ADDRESS_OPTIONS_$LI$();

SpecialTypesTest.HOST_OPTIONS_$LI$();
