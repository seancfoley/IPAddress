/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostName } from '../HostName';
import { HostNameParameters } from '../HostNameParameters';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { HostRangeTest } from './HostRangeTest';
import { AddressCreator } from './AddressCreator';
import { TestBase } from './TestBase';
import { IPAddressNetwork } from '../IPAddressNetwork';

export class HostAllTest extends HostRangeTest {
    static HOST_SAMPLING : string[]; public static HOST_SAMPLING_$LI$() : string[] { if(HostAllTest.HOST_SAMPLING == null) HostAllTest.HOST_SAMPLING = ["1.2.3.4", "1::", "[1::]", "bla.com", "::1", "[::1]", "localhost", "127.0.0.1", "[127.0.0.1]", "[localhost]", "-ab-.com", "A.cOm", "a.comx", "a.com", "2::", "1:0::", "f::", "F:0::", "[1:0::]", "1:0:1::", "001.2.3.04", "::ffff:1.2.3.4", "1:2:3:4:5:6:1.2.3.4%a", "1:2:3:4:5:6:102:304%a", "1:2:3:4:5:6:1.2.3.4%", "1:2:3:4:5:6:102:304%", "1:2:3:4:5:6:1.2.3.4%%", "1:2:3:4:5:6:102:304%%", "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:1.2.3.4", "1:2:3:4:5:6:1.2.3.4", "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:6:0.0.0.0", "1:2:3:4:5:6::", "1:2:3:4:5:6:1.2.3.4/1:2:3:4:5:0:0.0.0.0", "1:2:3:4:5::", "[1:2:3:4:5:6::%y]", "1:2:3:4:5:6::%y", "[1:2:3:4:5:6::%25y]", "1:2:3:4:5:6::%y", "[1:2:3:4:5:6::]/32", "1:2:3:4:5:6::/32", "1.2.3.4/255.0.0.0", "1.0.0.0/255.0.0.0", "[IPv6:1:2:3:4:5:6:7:8%y]", "1:2:3:4:5:6:7:8%y", "[IPv6:1:2:3:4:5:6:7:8]", "1:2:3:4:5:6:7:8", "[IPv6:1:2:3:4:5:6::]/32", "1:2:3:4:5:6::/32", "[IPv6:::1]", "[IPv6:1::]", "a::b:c:d:1.2.3.4%x", "a::b:c:d:1.2.3.4%x", "[a::b:c:d:1.2.3.4%x]", "a::b:c:d:1.2.3.4%x", "[a::b:c:d:1.2.3.4]", "a::b:c:d:1.2.3.4", "2001:0000:1234:0000:0000:C1C0:ABCD:0876%x", "2001:0:1234::c1c0:abcd:876%x", "[2001:0000:1234:0000:0000:C1C0:ABCD:0876%x]", "2001:0:1234::c1c0:abcd:876%x", "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "2001:0:1234::C1C0:abcd:876", "2001:0000:1234:0000:0000:C1C0:ABCD:0876", "2001:0:1234::C1C0:abcd:876", "1.2.3.04", "1.2.3", "[1.2.3.4]", "espn.com", "espn.com/24", "instapundit.com", "[A::b:c:d:1.2.03.4]", "[a:0:0:b:c:d:102:304]", "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "[2001:0:1234:0:0:c1c0:abcd:876]", "[A:0::c:d:1.2.03.4]", "a::c:d:102:304", "[2001:0000:1234:0000:0000:C1C0:ABCD:0876]", "2001:0:1234::c1c0:abcd:876", "WWW.ABC.COM", "www.abc.com", "WWW.AB-C.COM", "www.ab-c.com", "one.two.three.four.five.six.seven.EIGHT", "one.two.three.four.fIVE.sIX.seven", "one.two.THREE.four.five.six", "one.two.three.four.five", "one.two.three.four", "one.Two.three", "onE.two", "one", "", " ", "1:2:3:4:5:6:7:8", "[::]", "::", "aa-bb-cc-dd-ee-ff-aaaa-bbbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbbb", "aa-bb-cc-dd-ee-ff-aaaa-bbbbseth0.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbbb", "aa-bb-cc-dd-ee-ff.ipv6-literal.net", "aa-Bb-cc-dd-ee-FF.ipv6-literal.net", "aa-bb-cc-dd-ee-ff.ipv6-literal.net", "aa-bb-cc-dd-ee-ff-aaaa-bbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbb", "aa-Bb-cc-dd-ee-FF-aaaa-bbb.ipv6-literal.net", "aa:bb:cc:dd:ee:ff:aaaa:bbb", "f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.arpa", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", "f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", "f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int:45", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", "F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int:45", "cccc:bbbb:aaaa:bbbb:cccc:dddd:ee:ffff", "f.F.f.f.F.e.e.0.0.d.D.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.C.ip6.int:45", "f.f.f.f.f.e.e.0.0.d.d.d.d.c.c.c.c.b.b.b.b.a.a.a.a.b.b.b.b.c.c.c.c.ip6.int", "255.22.2.111.in-addr.arpa", "111.2.22.255", "255.22.2.111.in-addr.arpa:35", "111.2.22.255", "255.22.2.111.3.in-addr.arpa:35", "255.22.2.111.3.in-addr.arpa", "1.2.2.1:33", "1.2.2.1", "[::1]:33", "0:0:0:0:0:0:0:1", "::1:33", "0:0:0:0:0:0:1:33", "::1%eth0", "0:0:0:0:0:0:0:1", "[::1%eth0]:33", "0:0:0:0:0:0:0:1", "bla.bla:33", "bla.bla", "blA:33", "bla", "f:33", "f", "f::33", "f:0:0:0:0:0:0:33", "::1", "0:0:0:0:0:0:0:1", "[::1]", "0:0:0:0:0:0:0:1", "/16", "/32", "/64", "ffff:ffff:ffff:ffff:*:*:*:*", "ffff:ffff:ffff:ffff:0:0:0:0/64", "123-123456789-123456789-123456789-123456789-123456789-123456789.com", "aaa.123456789.123456789.123456789.123456789.123456789.123456789.123", "1234-123456789-123456789-123456789-123456789-123456789-123456789.com", "123.123456789.123456789.123456789.123456789.123456789.123456789.123", "-ab-.com", "ab-.com", "-ab.com", "ab.-com", "ab.com-"]; return HostAllTest.HOST_SAMPLING; };

    static HOST_ALL_OPTIONS : HostNameParameters; public static HOST_ALL_OPTIONS_$LI$() : HostNameParameters { if(HostAllTest.HOST_ALL_OPTIONS == null) HostAllTest.HOST_ALL_OPTIONS = new HostNameParameters.Builder().toParams(); return HostAllTest.HOST_ALL_OPTIONS; };

    static DEFAULT_OPTIONS : IPAddressStringParameters; public static DEFAULT_OPTIONS_$LI$() : IPAddressStringParameters { if(HostAllTest.DEFAULT_OPTIONS == null) HostAllTest.DEFAULT_OPTIONS = new IPAddressStringParameters.Builder().toParams(); return HostAllTest.DEFAULT_OPTIONS; };

    constructor(creator : AddressCreator) {
        super(creator);
    }

    /**
     * 
     * @return {boolean}
     */
    isLenient() : boolean {
        return true;
    }

    /**
     * 
     * @param {string} x
     * @return {HostName}
     */
    createHost_inet_aton(x : string) : HostName {
        let key : TestBase.HostKey = new TestBase.HostKey(x, HostAllTest.HOST_ALL_OPTIONS_$LI$());
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(key);
    }

    public createHost(x? : any, options? : any) : any {
        if(((typeof x === 'string') || x === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            super.createHost(x, options);
        } else if(((typeof x === 'string') || x === null) && options === undefined) {
            return <any>this.createHost$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.HostKey) || x === null) && options === undefined) {
            return <any>this.createHost$inet_ipaddr_test_TestBase_HostKey(x);
        } else throw new Error('invalid overload');
    }

    createHost$java_lang_String(x : string) : HostName {
        let key : TestBase.HostKey = new TestBase.HostKey(x, HostAllTest.HOST_ALL_OPTIONS_$LI$());
        return this.createHost$inet_ipaddr_test_TestBase_HostKey(key);
    }

    public testMatches(matches? : any, host1? : any, host2? : any, options? : any) : any {
        if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && ((options != null && options instanceof <any>HostNameParameters) || options === null)) {
            super.testMatches(matches, host1, host2, options);
        } else if(((typeof matches === 'boolean') || matches === null) && ((typeof host1 === 'string') || host1 === null) && ((typeof host2 === 'string') || host2 === null) && options === undefined) {
            return <any>this.testMatches$boolean$java_lang_String$java_lang_String(matches, host1, host2);
        } else throw new Error('invalid overload');
    }

    testMatches$boolean$java_lang_String$java_lang_String(matches : boolean, host1 : string, host2 : string) {
        this.testMatches$boolean$java_lang_String$java_lang_String$inet_ipaddr_HostNameParameters(matches, host1, host2, HostAllTest.HOST_ALL_OPTIONS_$LI$());
    }

    public createAddress(x? : any, opts? : any) : any {
        if(((typeof x === 'string') || x === null) && ((opts != null && opts instanceof <any>IPAddressStringParameters) || opts === null)) {
            return <any>this.createAddress$java_lang_String$inet_ipaddr_IPAddressStringParameters(x, opts);
        } else if(((typeof x === 'string') || x === null) && opts === undefined) {
            return <any>this.createAddress$java_lang_String(x);
        } else if(((x != null && x instanceof <any>TestBase.IPAddressStringKey) || x === null) && opts === undefined) {
            return <any>this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(x);
        } else if(((x != null && x instanceof <any>Array && (x.length==0 || x[0] == null ||(typeof x[0] === 'number'))) || x === null) && opts === undefined) {
            return <any>this.createAddress$byte_A(x);
        } else if(((typeof x === 'number') || x === null) && opts === undefined) {
            return <any>this.createAddress$int(x);
        } else throw new Error('invalid overload');
    }

    createAddress$java_lang_String(x : string) : IPAddressString {
        let key : TestBase.IPAddressStringKey = new TestBase.IPAddressStringKey(x, HostAllTest.DEFAULT_OPTIONS_$LI$());
        return this.createAddress$inet_ipaddr_test_TestBase_IPAddressStringKey(key);
    }

    /**
     * 
     * @param {string} x
     * @return {IPAddressString}
     */
    createInetAtonAddress(x : string) : IPAddressString {
        return this.createAddress$java_lang_String(x);
    }

    testCaches(map : any, testSize : boolean, useBytes : boolean) {
        let cache2 : IPAddressNetwork.HostNameGenerator = new IPAddressNetwork.HostNameGenerator(map);
        this.testCache(HostAllTest.HOST_SAMPLING_$LI$(), cache2, (str) => this.createHost$java_lang_String(str), testSize, useBytes);
    }

    static testCachesSync(runnable : () => void) {
        let threads : java.lang.Thread[] = [null, null, null, null, null, null, null, null, null, null];
        for(let i : number = 0; i < threads.length; i++) {
            threads[i] = new java.lang.Thread(<any>(runnable));
        };
        for(let index139=0; index139 < threads.length; index139++) {
            let thread = threads[index139];
            {
                thread.start();
            }
        }
        for(let index140=0; index140 < threads.length; index140++) {
            let thread = threads[index140];
            {
                try {
                    thread.join();
                } catch(e) {
                    console.error(e.message, e);
                };
            }
        }
    }

    /**
     * 
     */
    runTest() {
        super.runTest();
        this.testCaches(<any>({}), true, false);
        this.testCaches(<any>({}), true, false);
        let map : ConcurrentHashMap<string, HostName> = <any>(new ConcurrentHashMap<string, HostName>());
        HostAllTest.testCachesSync(() => {
            this.testCaches(map, false, false);
        });
    }
}
HostAllTest["__class"] = "inet.ipaddr.test.HostAllTest";




HostAllTest.DEFAULT_OPTIONS_$LI$();

HostAllTest.HOST_ALL_OPTIONS_$LI$();

HostAllTest.HOST_SAMPLING_$LI$();
