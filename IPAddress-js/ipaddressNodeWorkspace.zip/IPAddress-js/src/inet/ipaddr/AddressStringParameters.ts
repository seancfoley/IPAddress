/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
 * This class allows you to control the validation performed by the class {@link IPAddressString} or {@link MACAddressString}.
 * <p>
 * Those classes use a default permissive instance when you do not specify one.
 * <p>
 * All instances are immutable and must be constructed with the nested Builder class.
 * 
 * @author sfoley
 * @param {boolean} allowEmpty
 * @param {boolean} allowAll
 * @param {boolean} allowSingleSegment
 * @class
 */
export class AddressStringParameters {
    static serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_EMPTY : boolean = true;

    public static DEFAULT_ALLOW_ALL : boolean = true;

    public static DEFAULT_ALLOW_SINGLE_SEGMENT : boolean = true;

    /**
     * Allows zero-length IPAddressStrings like ""
     * @see #DEFAULT_ALLOW_EMPTY
     */
    public allowEmpty : boolean;

    /**
     * Allows the all-encompassing address *, which represents the network of all IPv4 and IPv6 addresses
     * @see #DEFAULT_ALLOW_ALL
     */
    public allowAll : boolean;

    /**
     * Allows an address to be specified as a single value, eg ffffffff, without the standard use of segments like 1.2.3.4 or 1:2:4:3:5:6:7:8
     * 
     * @see #DEFAULT_ALLOW_SINGLE_SEGMENT
     */
    public allowSingleSegment : boolean;

    public toBuilder$inet_ipaddr_AddressStringParameters_BuilderBase(builder : AddressStringParameters.BuilderBase) : AddressStringParameters.BuilderBase {
        builder.__allowAll = this.allowAll;
        builder.__allowEmpty = this.allowEmpty;
        builder.__allowSingleSegment = this.allowSingleSegment;
        return builder;
    }

    public toBuilder(builder? : any) : any {
        if(((builder != null && builder instanceof <any>AddressStringParameters.BuilderBase) || builder === null)) {
            return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_BuilderBase(builder);
        } else throw new Error('invalid overload');
    }

    public constructor(allowEmpty : boolean, allowAll : boolean, allowSingleSegment : boolean) {
        if(this.allowEmpty===undefined) this.allowEmpty = false;
        if(this.allowAll===undefined) this.allowAll = false;
        if(this.allowSingleSegment===undefined) this.allowSingleSegment = false;
        this.allowEmpty = allowEmpty;
        this.allowAll = allowAll;
        this.allowSingleSegment = allowSingleSegment;
    }

    /**
     * 
     * @return {AddressStringParameters}
     */
    public clone() : AddressStringParameters {
        try {
            let result : AddressStringParameters = <AddressStringParameters>/* clone *//* clone */((o:any) => { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; })(this);
            return result;
        } catch(e) {
        };
        return null;
    }

    /**
     * 
     * @param {IPAddressStringParameters} o
     * @return {number}
     */
    public compareTo(o? : any) : any {
        if(((o != null && o instanceof <any>AddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_AddressStringParameters(o);
        } else throw new Error('invalid overload');
    }

    public compareTo$inet_ipaddr_AddressStringParameters(o : AddressStringParameters) : number {
        let result : number = javaemul.internal.BooleanHelper.compare(this.allowAll, o.allowAll);
        if(result === 0) {
            result = javaemul.internal.BooleanHelper.compare(this.allowEmpty, o.allowEmpty);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowSingleSegment, o.allowSingleSegment);
            }
        }
        return result;
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>AddressStringParameters) {
            let other : AddressStringParameters = <AddressStringParameters>o;
            return this.allowEmpty === other.allowEmpty && this.allowAll === other.allowAll && this.allowSingleSegment === other.allowSingleSegment;
        }
        return false;
    }
}
AddressStringParameters["__class"] = "inet.ipaddr.AddressStringParameters";
AddressStringParameters["__interfaces"] = ["java.lang.Cloneable","java.io.Serializable"];



export namespace AddressStringParameters {

    /**
     * Controls special characters in addresses like '*', '-', '_'
     * @see AddressStringFormatParameters#DEFAULT_RANGE_OPTIONS
     * @author sfoley
     * @param {boolean} wildcard
     * @param {boolean} range
     * @param {boolean} singleWildcard
     * @class
     */
    export class RangeParameters {
        static serialVersionUID : number = 4;

        wildcard : boolean;

        range : boolean;

        singleWildcard : boolean;

        public static NO_RANGE : AddressStringParameters.RangeParameters; public static NO_RANGE_$LI$() : AddressStringParameters.RangeParameters { if(RangeParameters.NO_RANGE == null) RangeParameters.NO_RANGE = new AddressStringParameters.RangeParameters(false, false, false); return RangeParameters.NO_RANGE; };

        public static WILDCARD_ONLY : AddressStringParameters.RangeParameters; public static WILDCARD_ONLY_$LI$() : AddressStringParameters.RangeParameters { if(RangeParameters.WILDCARD_ONLY == null) RangeParameters.WILDCARD_ONLY = new AddressStringParameters.RangeParameters(true, false, true); return RangeParameters.WILDCARD_ONLY; };

        public static WILDCARD_AND_RANGE : AddressStringParameters.RangeParameters; public static WILDCARD_AND_RANGE_$LI$() : AddressStringParameters.RangeParameters { if(RangeParameters.WILDCARD_AND_RANGE == null) RangeParameters.WILDCARD_AND_RANGE = new AddressStringParameters.RangeParameters(true, true, true); return RangeParameters.WILDCARD_AND_RANGE; };

        public constructor(wildcard : boolean, range : boolean, singleWildcard : boolean) {
            if(this.wildcard===undefined) this.wildcard = false;
            if(this.range===undefined) this.range = false;
            if(this.singleWildcard===undefined) this.singleWildcard = false;
            this.wildcard = wildcard;
            this.range = range;
            this.singleWildcard = singleWildcard;
        }

        /**
         * 
         * @return {boolean} whether no wildcards or range characters allowed
         */
        public isNoRange() : boolean {
            return !(this.wildcard || this.range || this.singleWildcard);
        }

        /**
         * 
         * @return {boolean} whether '*' is allowed to denote segments covering all possible segment values
         */
        public allowsWildcard() : boolean {
            return this.wildcard;
        }

        /**
         * 
         * @return {boolean} whether '-' (or the expected range separator for the address) is allowed to denote a range from lower to higher, like 1-10
         */
        public allowsRangeSeparator() : boolean {
            return this.range;
        }

        /**
         * 
         * @return {boolean} whether to allow a segment terminating with '_' characters, which represent any digit
         */
        public allowsSingleWildcard() : boolean {
            return this.singleWildcard;
        }

        /**
         * 
         * @return {AddressStringParameters.RangeParameters}
         */
        public clone() : AddressStringParameters.RangeParameters {
            try {
                return <AddressStringParameters.RangeParameters>/* clone *//* clone */((o:any) => { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; })(this);
            } catch(e) {
            };
            return null;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            let result : number = 0;
            if(this.wildcard) {
                result = 1;
            }
            if(this.range) {
                result |= 2;
            }
            if(this.singleWildcard) {
                result |= 4;
            }
            return result;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(this === o) {
                return true;
            }
            if(o != null && o instanceof <any>AddressStringParameters.RangeParameters) {
                let other : AddressStringParameters.RangeParameters = <AddressStringParameters.RangeParameters>o;
                return this.wildcard === other.wildcard && this.range === other.range && this.singleWildcard === other.singleWildcard;
            }
            return false;
        }

        /**
         * 
         * @param {AddressStringParameters.RangeParameters} o
         * @return {number}
         */
        public compareTo(o : AddressStringParameters.RangeParameters) : number {
            let val : number = javaemul.internal.BooleanHelper.compare(this.wildcard, o.wildcard);
            if(val === 0) {
                val = javaemul.internal.BooleanHelper.compare(this.range, o.range);
                if(val === 0) {
                    val = javaemul.internal.BooleanHelper.compare(this.singleWildcard, o.singleWildcard);
                }
            }
            return val;
        }
    }
    RangeParameters["__class"] = "inet.ipaddr.AddressStringParameters.RangeParameters";
    RangeParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



    export class BuilderBase {
        __allowEmpty : boolean = AddressStringParameters.DEFAULT_ALLOW_EMPTY;

        __allowAll : boolean = AddressStringParameters.DEFAULT_ALLOW_ALL;

        __allowSingleSegment : boolean = AddressStringParameters.DEFAULT_ALLOW_SINGLE_SEGMENT;

        public constructor() {
        }

        /**
         * @see AddressStringParameters#allowEmpty
         * @param {boolean} allow
         * @return {AddressStringParameters.BuilderBase} the builder
         */
        public allowEmpty(allow : boolean) : AddressStringParameters.BuilderBase {
            this.__allowEmpty = allow;
            return this;
        }

        /**
         * @see AddressStringParameters#allowEmpty
         * @param {boolean} allow
         * @return {AddressStringParameters.BuilderBase} the builder
         */
        public allowSingleSegment(allow : boolean) : AddressStringParameters.BuilderBase {
            this.__allowSingleSegment = allow;
            return this;
        }

        public allowAll(allow : boolean) : AddressStringParameters.BuilderBase {
            this.__allowAll = allow;
            return this;
        }
    }
    BuilderBase["__class"] = "inet.ipaddr.AddressStringParameters.BuilderBase";


    export class AddressStringFormatParameters {
        static serialVersionUID : number = 4;

        public static DEFAULT_ALLOW_LEADING_ZEROS : boolean = true;

        public static DEFAULT_ALLOW_UNLIMITED_LEADING_ZEROS : boolean = true;

        public static DEFAULT_ALLOW_WILDCARDED_SEPARATOR : boolean = true;

        public static DEFAULT_RANGE_OPTIONS : AddressStringParameters.RangeParameters; public static DEFAULT_RANGE_OPTIONS_$LI$() : AddressStringParameters.RangeParameters { if(AddressStringFormatParameters.DEFAULT_RANGE_OPTIONS == null) AddressStringFormatParameters.DEFAULT_RANGE_OPTIONS = AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$(); return AddressStringFormatParameters.DEFAULT_RANGE_OPTIONS; };

        /**
         * controls whether wildcards like '*', '_' or ranges with '-' are allowed
         */
        public rangeOptions : AddressStringParameters.RangeParameters;

        /**
         * controls whether the wildcard '*' or '%' can replace the segment separators '.' and ':'.
         * If so, then you can write addresses like *.* or *:*
         * @see AddressStringFormatParameters#DEFAULT_ALLOW_WILDCARDED_SEPARATOR
         */
        public allowWildcardedSeparator : boolean;

        /**
         * whether you allow addresses with segments that have leasing zeros like 001.2.3.004 or 1:000a::
         * For IPV4, this option overrides inet_aton octal.
         * 
         * In other words, if this field is true, and if there are leading zeros then they are interpreted as decimal regardless of {@link inet.ipaddr.ipv4.IPv4AddressStringParameters#inet_aton_octal}.
         * 
         * Otherwise, validation defers to {@link inet.ipaddr.ipv4.IPv4AddressStringParameters#inet_aton_octal}
         * 
         * @see AddressStringFormatParameters#DEFAULT_ALLOW_LEADING_ZEROS
         */
        public allowLeadingZeros : boolean;

        /**
         * if {@link #allowLeadingZeros} or the address is IPv4 and {@link inet.ipaddr.ipv4.IPv4AddressStringParameters#inet_aton_octal} is true,
         * this determines if you allow leading zeros that extend segments
         * beyond the usual segment length, which is 3 for IPv4 dotted-decimal and 4 for IPv6.
         * For example, this determines whether you allow 0001.0002.0003.0004
         * 
         * @see AddressStringFormatParameters#DEFAULT_ALLOW_UNLIMITED_LEADING_ZEROS
         */
        public allowUnlimitedLeadingZeros : boolean;

        public constructor(allowLeadingZeros : boolean, allowUnlimitedLeadingZeros : boolean, rangeOptions : AddressStringParameters.RangeParameters, allowWildcardedSeparator : boolean) {
            if(this.rangeOptions===undefined) this.rangeOptions = null;
            if(this.allowWildcardedSeparator===undefined) this.allowWildcardedSeparator = false;
            if(this.allowLeadingZeros===undefined) this.allowLeadingZeros = false;
            if(this.allowUnlimitedLeadingZeros===undefined) this.allowUnlimitedLeadingZeros = false;
            this.rangeOptions = rangeOptions;
            if(rangeOptions == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
            }
            this.allowWildcardedSeparator = allowWildcardedSeparator;
            this.allowLeadingZeros = allowLeadingZeros;
            this.allowUnlimitedLeadingZeros = allowUnlimitedLeadingZeros;
        }

        public toBuilder(builder? : any) : any {
            if(((builder != null && builder instanceof <any>AddressStringParameters.AddressStringFormatParameters.BuilderBase) || builder === null)) {
                return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
            } else throw new Error('invalid overload');
        }

        toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder : AddressStringFormatParameters.BuilderBase) : AddressStringFormatParameters.BuilderBase {
            builder.__allowUnlimitedLeadingZeros = this.allowUnlimitedLeadingZeros;
            builder.rangeOptions = this.rangeOptions;
            builder.__allowWildcardedSeparator = this.allowWildcardedSeparator;
            builder.__allowLeadingZeros = this.allowLeadingZeros;
            return builder;
        }

        /**
         * 
         * @param {IPv4AddressStringParameters} o
         * @return {number}
         */
        public compareTo(o? : any) : any {
            if(((o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) || o === null)) {
                return <any>this.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
            } else throw new Error('invalid overload');
        }

        compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o : AddressStringParameters.AddressStringFormatParameters) : number {
            let result : number = this.rangeOptions.compareTo(o.rangeOptions);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowWildcardedSeparator, o.allowWildcardedSeparator);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.allowLeadingZeros, o.allowLeadingZeros);
                }
            }
            return result;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) {
                let other : AddressStringParameters.AddressStringFormatParameters = <AddressStringParameters.AddressStringFormatParameters>o;
                return this.rangeOptions.equals(other.rangeOptions) && this.allowUnlimitedLeadingZeros === other.allowUnlimitedLeadingZeros && this.allowWildcardedSeparator === other.allowWildcardedSeparator && this.allowLeadingZeros === other.allowLeadingZeros;
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.rangeOptions));
            if(this.allowUnlimitedLeadingZeros) {
                hash |= 8;
            }
            if(this.allowWildcardedSeparator) {
                hash |= 16;
            }
            if(this.allowLeadingZeros) {
                hash |= 32;
            }
            return hash;
        }
    }
    AddressStringFormatParameters["__class"] = "inet.ipaddr.AddressStringParameters.AddressStringFormatParameters";
    AddressStringFormatParameters["__interfaces"] = ["java.lang.Cloneable","java.io.Serializable"];



    export namespace AddressStringFormatParameters {

        export class BuilderBase {
            rangeOptions : AddressStringParameters.RangeParameters = AddressStringFormatParameters.DEFAULT_RANGE_OPTIONS_$LI$();

            __allowWildcardedSeparator : boolean = AddressStringFormatParameters.DEFAULT_ALLOW_WILDCARDED_SEPARATOR;

            __allowLeadingZeros : boolean = AddressStringFormatParameters.DEFAULT_ALLOW_LEADING_ZEROS;

            __allowUnlimitedLeadingZeros : boolean = AddressStringFormatParameters.DEFAULT_ALLOW_UNLIMITED_LEADING_ZEROS;

            public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : AddressStringFormatParameters.BuilderBase {
                this.rangeOptions = rangeOptions;
                return this;
            }

            public allowWildcardedSeparator(allow : boolean) : AddressStringFormatParameters.BuilderBase {
                this.__allowWildcardedSeparator = allow;
                return this;
            }

            public allowLeadingZeros(allow : boolean) : AddressStringFormatParameters.BuilderBase {
                this.__allowLeadingZeros = allow;
                if(!allow) {
                    this.__allowUnlimitedLeadingZeros = allow;
                }
                return this;
            }

            public allowUnlimitedLeadingZeros(allow : boolean) : AddressStringFormatParameters.BuilderBase {
                this.__allowUnlimitedLeadingZeros = allow;
                if(allow) {
                    this.__allowLeadingZeros = allow;
                }
                return this;
            }

            constructor() {
            }
        }
        BuilderBase["__class"] = "inet.ipaddr.AddressStringParameters.AddressStringFormatParameters.BuilderBase";

    }

}




AddressStringParameters.AddressStringFormatParameters.DEFAULT_RANGE_OPTIONS_$LI$();

AddressStringParameters.RangeParameters.WILDCARD_AND_RANGE_$LI$();

AddressStringParameters.RangeParameters.WILDCARD_ONLY_$LI$();

AddressStringParameters.RangeParameters.NO_RANGE_$LI$();
