/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierStringValidator } from './format/validate/HostIdentifierStringValidator';
import { IPAddressProvider } from './format/validate/IPAddressProvider';
import { Validator } from './format/validate/Validator';
import { IPv4Address } from './ipv4/IPv4Address';
import { IPv6Address } from './ipv6/IPv6Address';
import { MACAddress } from './mac/MACAddress';
import { HostIdentifierString } from './HostIdentifierString';
import { IPAddressStringParameters } from './IPAddressStringParameters';
import { AddressStringException } from './AddressStringException';
import { IPAddress } from './IPAddress';
import { PrefixLenException } from './PrefixLenException';
import { IncompatibleAddressException } from './IncompatibleAddressException';
import { IPAddressNetwork } from './IPAddressNetwork';
import { Address } from './Address';
import { IPAddressSegment } from './IPAddressSegment';

/**
 * @param {string} addr the address in string format
 * 
 * This constructor allows you to alter the default validation options.
 * @param {IPAddressStringParameters} valOptions
 * @class
 * @author sfoley
 */
export class IPAddressString implements HostIdentifierString {
    static serialVersionUID : number = 4;

    static DEFAULT_VALIDATION_OPTIONS : IPAddressStringParameters; public static DEFAULT_VALIDATION_OPTIONS_$LI$() : IPAddressStringParameters { if(IPAddressString.DEFAULT_VALIDATION_OPTIONS == null) IPAddressString.DEFAULT_VALIDATION_OPTIONS = new IPAddressStringParameters.Builder().toParams(); return IPAddressString.DEFAULT_VALIDATION_OPTIONS; };

    static IS_IPV6_EXCEPTION : AddressStringException; public static IS_IPV6_EXCEPTION_$LI$() : AddressStringException { if(IPAddressString.IS_IPV6_EXCEPTION == null) IPAddressString.IS_IPV6_EXCEPTION = new AddressStringException("ipaddress.error.address.is.ipv6"); return IPAddressString.IS_IPV6_EXCEPTION; };

    static IS_IPV4_EXCEPTION : AddressStringException; public static IS_IPV4_EXCEPTION_$LI$() : AddressStringException { if(IPAddressString.IS_IPV4_EXCEPTION == null) IPAddressString.IS_IPV4_EXCEPTION = new AddressStringException("ipaddress.error.address.is.ipv4"); return IPAddressString.IS_IPV4_EXCEPTION; };

    validationOptions : IPAddressStringParameters;

    fullAddr : string;

    /*private*/ ipv6Exception : AddressStringException;

    /*private*/ ipv4Exception : AddressStringException;

    /*private*/ addressProvider : IPAddressProvider = IPAddressProvider.NO_TYPE_PROVIDER_$LI$();

    public constructor(addr? : any, valOptions? : any) {
        if(((typeof addr === 'string') || addr === null) && ((valOptions != null && valOptions instanceof <any>IPAddressStringParameters) || valOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.ipv6Exception===undefined) this.ipv6Exception = null;
            if(this.ipv4Exception===undefined) this.ipv4Exception = null;
            this.addressProvider = IPAddressProvider.NO_TYPE_PROVIDER_$LI$();
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.ipv6Exception===undefined) this.ipv6Exception = null;
            if(this.ipv4Exception===undefined) this.ipv4Exception = null;
            (() => {
                if(addr == null) {
                    this.fullAddr = addr = "";
                } else {
                    addr = addr.trim();
                    this.fullAddr = addr;
                }
                this.validationOptions = valOptions;
            })();
        } else if(((addr != null && addr instanceof <any>IPAddress) || addr === null) && ((valOptions != null && valOptions instanceof <any>IPAddressStringParameters) || valOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.ipv6Exception===undefined) this.ipv6Exception = null;
            if(this.ipv4Exception===undefined) this.ipv4Exception = null;
            this.addressProvider = IPAddressProvider.NO_TYPE_PROVIDER_$LI$();
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.fullAddr===undefined) this.fullAddr = null;
            if(this.ipv6Exception===undefined) this.ipv6Exception = null;
            if(this.ipv4Exception===undefined) this.ipv4Exception = null;
            (() => {
                this.validationOptions = valOptions;
                this.fullAddr = address.toCanonicalString();
                this.initByAddress(address);
            })();
        } else if(((typeof addr === 'string') || addr === null) && valOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let valOptions : any = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.fullAddr===undefined) this.fullAddr = null;
                if(this.ipv6Exception===undefined) this.ipv6Exception = null;
                if(this.ipv4Exception===undefined) this.ipv4Exception = null;
                this.addressProvider = IPAddressProvider.NO_TYPE_PROVIDER_$LI$();
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.fullAddr===undefined) this.fullAddr = null;
                if(this.ipv6Exception===undefined) this.ipv6Exception = null;
                if(this.ipv4Exception===undefined) this.ipv4Exception = null;
                (() => {
                    if(addr == null) {
                        this.fullAddr = addr = "";
                    } else {
                        addr = addr.trim();
                        this.fullAddr = addr;
                    }
                    this.validationOptions = valOptions;
                })();
            }
        } else throw new Error('invalid overload');
    }

    cacheAddress(address : IPAddress) {
        if(this.addressProvider === IPAddressProvider.NO_TYPE_PROVIDER_$LI$()) {
            this.initByAddress(address);
        }
    }

    initByAddress(address : IPAddress) {
        let provider : IPAddressProvider = address.getProvider();
        if(provider.isIPv4()) {
            this.ipv6Exception = IPAddressString.IS_IPV4_EXCEPTION_$LI$();
        } else if(provider.isIPv6()) {
            this.ipv4Exception = IPAddressString.IS_IPV6_EXCEPTION_$LI$();
        }
        this.addressProvider = provider;
    }

    public getValidationOptions() : IPAddressStringParameters {
        return this.validationOptions;
    }

    /**
     * @return {boolean} whether this address has an associated prefix length
     */
    public isPrefixed() : boolean {
        return this.isValid() && this.addressProvider.isPrefixed();
    }

    /**
     * @return {number} if this address is a valid address with a network prefix then this returns that prefix, otherwise returns null
     */
    public getNetworkPrefixLength() : number {
        if(this.isValid()) {
            return this.addressProvider.getNetworkPrefixLength();
        }
        return null;
    }

    /**
     * @return {boolean} whether the address represents one of the accepted IP address types, which are:
     * an IPv4 address, an IPv6 address, a network prefix, the address representing all addresses of all types, or an empty string.
     * If it does not, and you want more details, call validate() and examine the thrown exception.
     */
    public isValid() : boolean {
        if(this.addressProvider.isUninitialized()) {
            try {
                this.validate();
                return true;
            } catch(e) {
                return false;
            };
        }
        return !this.addressProvider.isInvalid();
    }

    /**
     * @return {boolean} whether the address represents a valid specific IP address,
     * as opposed to an empty string, the address representing all addresses of all types, a prefix length, or an invalid format.
     */
    public isIPAddress() : boolean {
        return this.isValid() && this.addressProvider.isIPAddress();
    }

    /**
     * @return {boolean} whether the address represents the set all all valid IP addresses (as opposed to an empty string, a specific address, a prefix length, or an invalid format).
     */
    public isAllAddresses() : boolean {
        return this.isValid() && this.addressProvider.isAllAddresses();
    }

    /**
     * @return {boolean} whether the address represents a valid IP address network prefix (as opposed to an empty string, an address with or without a prefix, or an invalid format).
     */
    public isPrefixOnly() : boolean {
        return this.isValid() && this.addressProvider.isPrefixOnly();
    }

    /**
     * Returns true if the address is empty (zero-length).
     * @return
     * @return {boolean}
     */
    public isEmpty() : boolean {
        return this.isValid() && this.addressProvider.isEmpty();
    }

    /**
     * Returns true if the address is IPv4 (with or without a network prefix, with or without wildcard segments).
     * @return
     * @return {boolean}
     */
    public isIPv4() : boolean {
        return this.isValid() && this.addressProvider.isIPv4();
    }

    /**
     * Returns true if the address is IPv6 (with or without a network prefix, with or without wildcard segments).
     * @return
     * @return {boolean}
     */
    public isIPv6() : boolean {
        return this.isValid() && this.addressProvider.isIPv6();
    }

    /**
     * If this address string represents an IPv6 address, returns whether the lower 4 bytes were represented as IPv4
     * @return
     * @return {boolean}
     */
    public isMixedIPv6() : boolean {
        return this.isIPv6() && this.addressProvider.isMixedIPv6();
    }

    /**
     * If this address string represents an IPv6 address, returns whether the string was base 85
     * @return
     * @return {boolean}
     */
    public isBase85IPv6() : boolean {
        return this.isIPv6() && this.addressProvider.isBase85IPv6();
    }

    public getIPVersion() : IPAddress.IPVersion {
        if(this.isValid()) {
            return this.addressProvider.getIPVersion();
        }
        return null;
    }

    /**
     * @see java.net.InetAddress#isLoopbackAddress()
     * @return {boolean}
     */
    public isLoopback() : boolean {
        let val : IPAddress = this.getAddress();
        return val != null && val.isLoopback();
    }

    public isZero() : boolean {
        let value : IPAddress = this.getAddress();
        return value != null && value.isZero();
    }

    /**
     * Validates that this string is a valid IPv4 address, and if not, throws an exception with a descriptive message indicating why it is not.
     * @throws AddressStringException
     */
    public validateIPv4() {
        this.validate$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV4);
        this.checkIPv4Exception();
    }

    /**
     * Validates that this string is a valid IPv6 address, and if not, throws an exception with a descriptive message indicating why it is not.
     * @throws AddressStringException
     */
    public validateIPv6() {
        this.validate$inet_ipaddr_IPAddress_IPVersion(IPAddress.IPVersion.IPV6);
        this.checkIPv6Exception();
    }

    public validate$() {
        this.validate$inet_ipaddr_IPAddress_IPVersion(null);
    }

    /*private*/ checkIPv4Exception() {
        if(this.ipv4Exception != null) {
            if(this.ipv4Exception === IPAddressString.IS_IPV6_EXCEPTION_$LI$()) {
                this.ipv4Exception = new AddressStringException("ipaddress.error.address.is.ipv6");
            }
            throw this.ipv4Exception;
        }
    }

    /*private*/ checkIPv6Exception() {
        if(this.ipv6Exception != null) {
            if(this.ipv6Exception === IPAddressString.IS_IPV4_EXCEPTION_$LI$()) {
                this.ipv6Exception = new AddressStringException("ipaddress.error.address.is.ipv4");
            }
            throw this.ipv6Exception;
        }
    }

    /*private*/ isValidated(version : IPAddress.IPVersion) : boolean {
        if(this.addressProvider !== IPAddressProvider.NO_TYPE_PROVIDER_$LI$()) {
            if(version == null) {
                if(this.ipv6Exception != null && this.ipv4Exception != null) {
                    throw this.ipv4Exception;
                }
            } else if(IPAddress.IPVersion["_$wrappers"][version].isIPv4()) {
                this.checkIPv4Exception();
            } else if(IPAddress.IPVersion["_$wrappers"][version].isIPv6()) {
                this.checkIPv6Exception();
            }
            return true;
        }
        return false;
    }

    getValidator() : HostIdentifierStringValidator {
        return Validator.VALIDATOR_$LI$();
    }

    public validate$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) {
        if(this.isValidated(version)) {
            return;
        }
        {
            if(this.isValidated(version)) {
                return;
            }
            try {
                let valueCreator : IPAddressProvider = this.getValidator()['validateAddress$inet_ipaddr_IPAddressString'](this);
                let createdVersion : IPAddress.IPVersion = valueCreator.getIPVersion();
                if(createdVersion != null) {
                    if(IPAddress.IPVersion["_$wrappers"][createdVersion].isIPv4()) {
                        this.ipv6Exception = IPAddressString.IS_IPV4_EXCEPTION_$LI$();
                    } else if(IPAddress.IPVersion["_$wrappers"][createdVersion].isIPv6()) {
                        this.ipv4Exception = IPAddressString.IS_IPV6_EXCEPTION_$LI$();
                    }
                }
                this.addressProvider = valueCreator;
            } catch(e) {
                this.ipv6Exception = this.ipv4Exception = e;
                this.addressProvider = IPAddressProvider.INVALID_PROVIDER_$LI$();
                throw e;
            };
        };
    }

    public validate(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.validate$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.validate$();
        } else throw new Error('invalid overload');
    }

    /**
     * Validates that the string has the format "/x" for a valid prefix length x.
     * @param {IPAddress.IPVersion} ipVersion IPv4, IPv6, or null if you do not know in which case it will be assumed that it can be either
     * @param {*} networkPrefixLength the network prefix length integer as a string, eg "24"
     * @return {number} the network prefix length
     * @throws IncompatibleAddressException if invalid with an appropriate message
     */
    public static validateNetworkPrefixLength(ipVersion : IPAddress.IPVersion, networkPrefixLength : any) : number {
        try {
            return Validator.VALIDATOR_$LI$().validatePrefix(networkPrefixLength, ipVersion);
        } catch(e) {
            throw new PrefixLenException(networkPrefixLength, ipVersion, e);
        };
    }

    public static validateNetworkPrefix(ipVersion : IPAddress.IPVersion, networkPrefixLength : number, allowPrefixesBeyondAddressSize : boolean) {
        let asIPv4 : boolean = (ipVersion != null && IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv4());
        if(networkPrefixLength > (asIPv4?IPv4Address.BIT_COUNT:IPv6Address.BIT_COUNT)) {
            throw new PrefixLenException(networkPrefixLength, ipVersion);
        }
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        if(this.isValid()) {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.addressProvider));
        }
        return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.toString()));
    }

    /**
     * 
     * @param {IPAddressString} other
     * @return {number}
     */
    public compareTo(other : IPAddressString) : number {
        if(this === other) {
            return 0;
        }
        let isValid : boolean = this.isValid();
        let otherIsValid : boolean = other.isValid();
        if(!isValid && !otherIsValid) {
            return /* compareTo */this.toString().localeCompare(other.toString());
        }
        return this.addressProvider.compareTo(other.addressProvider);
    }

    /**
     * Two IPAddressString objects are equal if they represent the same set of addresses.
     * Whether one or the other has an associated network prefix length is not considered.
     * 
     * If an IPAddressString is invalid, it is equal to another address only if the other address was constructed from the same string.
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>IPAddressString) {
            let other : IPAddressString = <IPAddressString>o;
            if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.toString(),other.toString()))) {
                return true;
            }
            if(this.isValid() && other.isValid()) {
                return this.addressProvider.equals(other.addressProvider);
            }
        }
        return false;
    }

    /**
     * If this address string was constructed from a host address with prefix length,
     * then this provides just the host address, rather than the address
     * provided by {@link #getAddress()} that incorporates the prefix.
     * <p>
     * Otherwise this returns the same object as {@link #getAddress()}.
     * <p>
     * This method returns null for invalid formats, the equivalent method {@link #toHostAddress()} throws exceptions for invalid formats.
     * 
     * @see AddressNetwork#getPrefixConfiguration()
     * @return
     * @return {IPAddress}
     */
    public getHostAddress() : IPAddress {
        if(!this.addressProvider.isInvalid()) {
            try {
                return this.toHostAddress();
            } catch(e) {
            };
        }
        return null;
    }

    public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
        if(!this.addressProvider.isInvalid()) {
            try {
                return this.toAddress$inet_ipaddr_IPAddress_IPVersion(version);
            } catch(e) {
            };
        }
        return null;
    }

    /**
     * Similar to {@link #toAddress(IPVersion)}, but returns null rather than throwing an exception with the address is invalid or does not match the supplied version.
     * 
     * @param {IPAddress.IPVersion} version
     * @return {IPAddress}
     */
    public getAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.getAddress$();
        } else throw new Error('invalid overload');
    }

    public getAddress$() : IPAddress {
        if(!this.addressProvider.isInvalid()) {
            try {
                return this.toAddress();
            } catch(e) {
            };
        }
        return null;
    }

    /**
     * If this address string was constructed from a host address with prefix,
     * then this provides just the host address, rather than the address with the prefix
     * provided by {@link #toAddress()} that incorporates the prefix.
     * 
     * Otherwise this returns the same object as {@link #toAddress()}
     * 
     * This method throws exceptions for invalid formats, the equivalent method {@link #getHostAddress()} will simply return null in such cases.
     * 
     * @return
     * @return {IPAddress}
     */
    public toHostAddress() : IPAddress {
        this.validate();
        return this.addressProvider.getHostAddress();
    }

    public toAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
        this.validate();
        return this.addressProvider.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
    }

    /**
     * Produces the {@link IPAddress} of the specified address version corresponding to this IPAddressString.
     * <p>
     * In most cases the string indicates the address version and calling {@link #toAddress()} is sufficient, with a few exceptions.
     * <p>
     * When this object represents only a network prefix length,
     * specifying the address version allows the conversion to take place to the associated mask for that prefix length.
     * <p>
     * When this object represents all addresses, specifying the address version allows the conversion to take place
     * to the associated representation of all IPv4 or all IPv6 addresses.
     * <p>
     * When this object represents the empty string and that string is interpreted as a loopback, then it returns
     * the corresponding loopback address.  If empty strings are not interpreted as loopback, null is returned.
     * <p>
     * When this object represents an ipv4 or ipv6 address, it returns that address if and only if that address matches the provided version.
     * <p>
     * If the string used to construct this object is an invalid format,
     * or a format that does not match the provided version, then this method throws {@link AddressStringException}.
     * <p>
     * @param {IPAddress.IPVersion} version the address version that this address should represent.
     * @return
     * @throws AddressStringException
     * @throws IncompatibleAddressException address in proper format cannot be converted to an address: for masks inconsistent with associated address range, or ipv4 mixed segments that cannot be joined into ipv6 segments
     * @return {IPAddress}
     */
    public toAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.toAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.toAddress$();
        } else throw new Error('invalid overload');
    }

    public toAddress$() : IPAddress {
        this.validate();
        return this.addressProvider.getAddress();
    }

    public adjustPrefixBySegment(nextSegment : boolean) : IPAddressString {
        if(this.isPrefixOnly()) {
            let bitsPerSegment : number = IPv4Address.BITS_PER_SEGMENT;
            let existingPrefixLength : number = this.getNetworkPrefixLength();
            let newBits : number;
            if(nextSegment) {
                let adjustment : number = existingPrefixLength % bitsPerSegment;
                newBits = Math.min(IPv6Address.BIT_COUNT, existingPrefixLength + bitsPerSegment - adjustment);
            } else {
                let adjustment : number = ((existingPrefixLength - 1) % bitsPerSegment) + 1;
                newBits = Math.max(0, existingPrefixLength - adjustment);
            }
            return new IPAddressString(IPAddressNetwork.getPrefixString(newBits), this.validationOptions);
        }
        let address : IPAddress = this.getAddress();
        if(address == null) {
            return null;
        }
        let prefix : number = address.getNetworkPrefixLength();
        if(!nextSegment && prefix != null && prefix === 0 && address.isMultiple() && address.isPrefixBlock()) {
            return new IPAddressString(IPAddress.SEGMENT_WILDCARD_STR_$LI$(), this.validationOptions);
        }
        return address.adjustPrefixBySegment$boolean(nextSegment).toAddressString();
    }

    public adjustPrefixLength(adjustment : number) : IPAddressString {
        if(this.isPrefixOnly()) {
            let newBits : number = adjustment > 0?Math.min(IPv6Address.BIT_COUNT, this.getNetworkPrefixLength() + adjustment):Math.max(0, this.getNetworkPrefixLength() + adjustment);
            return new IPAddressString(IPAddressNetwork.getPrefixString(newBits), this.validationOptions);
        }
        let address : IPAddress = this.getAddress();
        if(address == null) {
            return null;
        }
        if(adjustment === 0) {
            return this;
        }
        let prefix : number = address.getNetworkPrefixLength();
        if(prefix != null && prefix + adjustment < 0 && address.isPrefixBlock()) {
            return new IPAddressString(IPAddress.SEGMENT_WILDCARD_STR_$LI$(), this.validationOptions);
        }
        return address.adjustPrefixLength$int(adjustment).toAddressString();
    }

    /**
     * Given a string with comma delimiters to denote segment elements, this method will count the possible combinations.
     * <p>
     * For example, given "1,2.3.4,5.6" this method will return 4 for the possible combinations: "1.3.4.6", "1.3.5.6", "2.3.4.6" and "2.3.5.6"
     * <p>
     * @param {string} str
     * @return
     * @return {number}
     */
    public static countDelimitedAddresses(str : string) : number {
        let segDelimitedCount : number = 0;
        let result : number = 1;
        for(let i : number = 0; i < str.length; i++) {
            let c : string = str.charAt(i);
            if(IPAddressString.isDelimitedBoundary(c)) {
                if(segDelimitedCount > 0) {
                    result *= segDelimitedCount + 1;
                    segDelimitedCount = 0;
                }
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostIdentifierString.SEGMENT_VALUE_DELIMITER)) {
                segDelimitedCount++;
            }
        };
        if(segDelimitedCount > 0) {
            result *= segDelimitedCount + 1;
        }
        return result;
    }

    /*private*/ static isDelimitedBoundary(c : string) : boolean {
        return (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv4Address.SEGMENT_SEPARATOR) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.RANGE_SEPARATOR) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR);
    }

    /**
     * Given a string with comma delimiters to denote segment elements, this method will provide an iterator to iterate through the possible combinations.
     * <p>
     * For example, given "1,2.3.4,5.6" this will iterate through "1.3.4.6", "1.3.5.6", "2.3.4.6" and "2.3.5.6"
     * <p>
     * Another example: "1-2,3.4.5.6" will iterate through "1-2.4.5.6" and "1-3.4.5.6".
     * <p>
     * This method will not validate strings.  Each string produced can be validated using an instance of IPAddressString.
     * 
     * @param {string} str
     * @return
     * @return {*}
     */
    public static parseDelimitedSegments(str : string) : any {
        let parts : Array<Array<string>> = null;
        let lastSegmentStartIndex : number = 0;
        let lastPartIndex : number = 0;
        let lastDelimiterIndex : number = 0;
        let anyDelimited : boolean = false;
        let delimitedList : Array<string> = null;
        for(let i : number = 0; i < str.length; i++) {
            let c : string = str.charAt(i);
            if(IPAddressString.isDelimitedBoundary(c)) {
                if(delimitedList != null) {
                    if(parts == null) {
                        parts = <any>([]);
                    }
                    IPAddressString.addParts(str, parts, lastSegmentStartIndex, lastPartIndex, lastDelimiterIndex, delimitedList, i);
                    lastPartIndex = i;
                    delimitedList = null;
                }
                lastSegmentStartIndex = lastDelimiterIndex = i + 1;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostIdentifierString.SEGMENT_VALUE_DELIMITER)) {
                anyDelimited = true;
                if(delimitedList == null) {
                    delimitedList = <any>([]);
                }
                let sub : string = str.substring(lastDelimiterIndex, i);
                /* add */(delimitedList.push(sub)>0);
                lastDelimiterIndex = i + 1;
            }
        };
        if(anyDelimited) {
            if(delimitedList != null) {
                if(parts == null) {
                    parts = <any>([]);
                }
                IPAddressString.addParts(str, parts, lastSegmentStartIndex, lastPartIndex, lastDelimiterIndex, delimitedList, str.length);
            } else {
                /* add */(parts.push(/* asList */[str.substring(lastPartIndex, str.length)].slice(0))>0);
            }
            return IPAddressString.iterator(parts);
        }
        return new IPAddressString.IPAddressString$0(str);
    }

    /*private*/ static iterator(parts : Array<Array<string>>) : any {
        return new IPAddressString.IPAddressString$1(parts);
    }

    /*private*/ static addParts(str : string, parts : Array<Array<string>>, lastSegmentStartIndex : number, lastPartIndex : number, lastDelimiterIndex : number, delimitedList : Array<string>, i : number) {
        let sub : string = str.substring(lastDelimiterIndex, i);
        /* add */(delimitedList.push(sub)>0);
        if(lastPartIndex !== lastSegmentStartIndex) {
            /* add */(parts.push(/* asList */[str.substring(lastPartIndex, lastSegmentStartIndex)].slice(0))>0);
        }
        /* add */(parts.push(delimitedList)>0);
    }

    /**
     * Converts this address to a prefix length
     * 
     * @return {string} the prefix of the indicated IP type represented by this address or null if this address is valid but cannot be represented by a network prefix length
     * @throws AddressStringException if the address is invalid
     */
    public convertToPrefixLength() : string {
        let address : IPAddress = this.toAddress();
        let prefix : number;
        if(address == null) {
            if(this.isPrefixOnly()) {
                prefix = this.getNetworkPrefixLength();
            } else {
                return null;
            }
        } else {
            prefix = address.getBlockMaskPrefixLength(true);
            if(prefix == null) {
                return null;
            }
        }
        return /* toString */IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder(prefix, 10, /* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })({ str: "", toString: function() { return this.str; } })).str;
    }

    /*private*/ static toNormalizedString(addressProvider : IPAddressProvider) : string {
        let result : string;
        if(addressProvider.isAllAddresses()) {
            result = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
        } else if(addressProvider.isEmpty()) {
            result = "";
        } else if(addressProvider.isPrefixOnly()) {
            result = IPAddressNetwork.getPrefixString(addressProvider.getNetworkPrefixLength());
        } else if(addressProvider.isIPAddress()) {
            result = addressProvider.getAddress().toNormalizedString();
        } else {
            result = null;
        }
        return result;
    }

    public toNormalizedString(wildcard? : any) : any {
        if(wildcard === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        let result : string;
        if(this.isValid()) {
            result = IPAddressString.toNormalizedString(this.addressProvider);
        } else {
            result = this.toString();
        }
        return result;
    }

    /**
     * Gives us the original string provided to the constructor.  For variations, call {@link #getAddress()}/{@link #toAddress()} and then use string methods on the address object.
     * @return {string}
     */
    public toString() : string {
        return this.fullAddr;
    }
}
IPAddressString["__class"] = "inet.ipaddr.IPAddressString";
IPAddressString["__interfaces"] = ["java.lang.Comparable","inet.ipaddr.HostIdentifierString","java.io.Serializable"];



export namespace IPAddressString {

    export class IPAddressString$0 {
        done : boolean;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return !this.done;
        }

        /**
         * 
         * @return {string}
         */
        public next() : string {
            if(this.done) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            this.done = true;
            return this.str;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private str: any) {
            if(this.done===undefined) this.done = false;
        }
    }
    IPAddressString$0["__interfaces"] = ["java.util.Iterator"];



    export class IPAddressString$1 {
        done : boolean;

        partCount : number = /* size */(<number>this.parts.length);

        variations : any[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.partCount);

        nextSet : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.partCount);

        updateVariations(start : number) {
            for(let i : number = start; i < this.partCount; i++) {
                this.variations[i] = /* iterator */((a) => { var i = 0; return { next: function() { return i<a.length?a[i++]:null; }, hasNext: function() { return i<a.length; }}})(/* get */this.parts[i]);
                this.nextSet[i] = this.variations[i].next();
            };
        }

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return !this.done;
        }

        /**
         * 
         * @return {string}
         */
        public next() : string {
            if(this.done) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let result : { str: string } = { str: "", toString: function() { return this.str; } };
            for(let i : number = 0; i < this.partCount; i++) {
                /* append */(sb => { sb.str = sb.str.concat(<any>this.nextSet[i]); return sb; })(result);
            };
            this.increment();
            return /* toString */result.str;
        }

        increment() {
            for(let j : number = this.partCount - 1; j >= 0; j--) {
                if(this.variations[j].hasNext()) {
                    this.nextSet[j] = this.variations[j].next();
                    this.updateVariations(j + 1);
                    return;
                }
            };
            this.done = true;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private parts: any) {
            if(this.done===undefined) this.done = false;
            (() => {
                this.updateVariations(0);
            })();
        }
    }
    IPAddressString$1["__interfaces"] = ["java.util.Iterator"];


}




IPAddressString.IS_IPV4_EXCEPTION_$LI$();

IPAddressString.IS_IPV6_EXCEPTION_$LI$();

IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
