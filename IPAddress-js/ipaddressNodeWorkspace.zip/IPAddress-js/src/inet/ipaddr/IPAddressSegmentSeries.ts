/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressPartStringCollection } from './format/util/IPAddressPartStringCollection';
import { AddressSegmentSeries } from './AddressSegmentSeries';
import { IPAddress } from './IPAddress';
import { PrefixLenException } from './PrefixLenException';
import { IPAddressSection } from './IPAddressSection';
import { IPAddressNetwork } from './IPAddressNetwork';
import { IPAddressSegment } from './IPAddressSegment';

/**
 * Represents a series of IP address segments.
 * <p>
 * Provides methods relevant to IP addresses and IP address sections in addition to the more general methods pertaining to address and address sections in AddressSegmentSeries.
 * 
 * 
 * @author sfoley
 * @class
 */
export interface IPAddressSegmentSeries extends AddressSegmentSeries {
    /**
     * Returns the version of this segment series
     * 
     * @return
     * @return {IPAddress.IPVersion}
     */
    getIPVersion() : IPAddress.IPVersion;

    getNetworkPrefixLength(segmentIndex? : any, segmentPrefix? : any) : any;

    /**
     * Returns the equivalent address series with the smallest CIDR prefix possible (largest network),
     * such that the range of values of this address includes the subnet block for that prefix.
     * 
     * @see #toPrefixBlock()
     * @see #assignPrefixForSingleBlock()
     * @return
     * @return {*}
     */
    assignMinPrefixForBlock() : IPAddressSegmentSeries;

    /**
     * Returns the equivalent CIDR address series with a prefix length for which the subnet block for that prefix matches the range of values in this series.
     * In short, the returned series is a single block of address segment series.
     * Another way of looking at it: if the range matches the range associated with some prefix length, then it returns the address series with that prefix length.
     * <p>
     * If no such prefix length exists, returns null.
     * <p>
     * If this address represents just a single address, "this" is returned.
     * <p>
     * The methods {@link #assignMinPrefixForBlock}, {@link #assignPrefixForSingleBlock} can be compared as follows.<p>
     * {@link #assignMinPrefixForBlock} finds the smallest prefix length possible for this subnet and returns that subnet.<br>
     * {@link #assignPrefixForSingleBlock} finds the smallest prefix length possible for this subnet that results in just a single prefix and returns that subnet.<br>
     * <p>
     * For example, given the address 1-2.2.3.* /16<br>
     * {@link #assignMinPrefixForBlock} returns 1-2.2.3.* /24 if the prefix configuration is not ALL_PREFIXES_ARE_SUBNETS, otherwise 1-2.2.*.* /16, in order to return the subnet with the smallest prefix length <br>
     * {@link #assignPrefixForSingleBlock} returns null because any prefix length will end up with at least two prefixes due to the first segment spanning two values: 1-2.
     * <p>
     * For another example, for the address 1.2.*.* /16 or the address 1.2.*.* both methods return 1.2.*.* /16.
     * 
     * @see #toPrefixBlock()
     * @see #assignMinPrefixForBlock()
     * @return
     * @return {*}
     */
    assignPrefixForSingleBlock() : IPAddressSegmentSeries;

    /**
     * 
     * Returns the segment series of the same length that spans all hosts.
     * The network prefix length will be the one provided, and the network values will match the same of this series.
     * 
     * @param {number} networkPrefixLength
     * @return
     * @return {*}
     */
    toPrefixBlock(networkPrefixLength? : any) : any;

    /**
     * Returns the host section of the address as indicated by the network prefix length provided.  The returned section will have only as many segments as needed
     * to hold the host as indicated by the provided network prefix length.
     * 
     * @param {number} networkPrefixLength
     * @return
     * @return {IPAddressSection}
     */
    getHostSection(networkPrefixLength? : any) : any;

    /**
     * Returns the network section of the series.  The returned section will have only as many segments as needed as indicated by networkPrefixLength.
     * If withPrefixLength is true, it will have networkPrefixLength as its associated prefix length,
     * unless this series already has a smaller prefix length, in which case the existing prefix length is retained.
     * 
     * @param {number} networkPrefixLength
     * @param {boolean} withPrefixLength whether the resulting section will have networkPrefixLength as the associated prefix length or not
     * @return
     * @return {IPAddressSection}
     */
    getNetworkSection(networkPrefixLength? : any, withPrefixLength? : any) : any;

    /**
     * This produces a string with no compressed segments and all segments of full length,
     * which is 4 characters for IPv6 segments and 3 characters for IPv4 segments.
     * @return {string}
     */
    toFullString() : string;

    /**
     * Returns a string with a CIDR prefix length if this section has a network prefix length.
     * For IPv6, the host section will be compressed with ::, for IPv4 the host section will be zeros.
     * @return
     * @return {string}
     */
    toPrefixLengthString() : string;

    /**
     * Produces a consistent subnet string.
     * 
     * In the case of IPv4, this means that wildcards are used instead of a network prefix.
     * In the case of IPv6, a prefix will be used and the host section will be compressed with ::.
     * @return {string}
     */
    toSubnetString() : string;

    /**
     * This produces a string similar to the normalized string and avoids the CIDR prefix.
     * CIDR addresses will be shown with wildcards and ranges instead of using the CIDR prefix notation.
     * @return {string}
     */
    toNormalizedWildcardString() : string;

    /**
     * This produces a string similar to the canonical string and avoids the CIDR prefix.
     * Addresses with a network prefix length will be shown with wildcards and ranges instead of using the CIDR prefix length notation.
     * IPv6 addresses will be compressed according to the canonical representation.
     * @return {string}
     */
    toCanonicalWildcardString() : string;

    /**
     * This is similar to toNormalizedWildcardString, avoiding the CIDR prefix, but with compression as well.
     * @return {string}
     */
    toCompressedWildcardString() : string;

    /**
     * This is the same as the string from toNormalizedWildcardString except that
     * it uses {@link IPAddress#SEGMENT_SQL_WILDCARD} instead of {@link IPAddress#SEGMENT_WILDCARD} and also uses {@link IPAddress#SEGMENT_SQL_SINGLE_WILDCARD}
     * @return {string}
     */
    toSQLWildcardString() : string;

    /**
     * Generates the reverse DNS lookup string
     * For 8.255.4.4 it is 4.4.255.8.in-addr.arpa
     * For 2001:db8::567:89ab it is b.a.9.8.7.6.5.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.8.b.d.0.1.0.0.2.ip6.arpa
     * 
     * 
     * @throws IncompatibleAddressException if this address is a subnet
     * @return
     * @return {string}
     */
    toReverseDNSLookupString() : string;

    toBinaryString(zone? : any) : any;

    toOctalString(with0Prefix? : any, zone? : any) : any;

    toStringCollection(opts? : any, zone? : any) : any;

    toNormalizedString(options? : any, zone? : any) : any;

    /**
     * 
     * @return {IPAddressNetwork}
     */
    getNetwork() : IPAddressNetwork<any, any, any, any, any>;

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPAddressSection}
     */
    getSection(index? : any, endIndex? : any) : any;

    /**
     * 
     * @param {number} index
     * @return {IPAddressSegment}
     */
    getSegment(index : number) : IPAddressSegment;

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} destIndex
     */
    getSegments(start? : any, end? : any, segs? : any, destIndex? : any) : any;

    /**
     * Gets the count of single value series that this series may represent.  If excludeZeroHosts is true, the count excludes series whose host is zero.
     * 
     * If this address series has no range of values, then there is only one such address.
     * 
     * If this has no CIDR network prefix length, then it is equivalent to {@link #getCount()}.
     * 
     * @return
     * @return {BigInteger}
     */
    getNonZeroHostCount() : BigInteger;

    /**
     * Similar to {@link #getLower()}, but will not return a series that has a prefix length and whose host value is zero.
     * If this series has no prefix length, returns the same series as {@link #getLower()}.
     * 
     * @return {*} the lowest IP address series whose host is non-zero, or null if no such address section exists.
     */
    getLowerNonZeroHost() : IPAddressSegmentSeries;

    /**
     * 
     * @return {*}
     */
    getLower() : IPAddressSegmentSeries;

    /**
     * 
     * @return {*}
     */
    getUpper() : IPAddressSegmentSeries;

    /**
     * 
     * @return {*}
     */
    getIterable() : java.lang.Iterable<any>;

    iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any;

    prefixBlockIterator(original? : any, creator? : any) : any;

    nonZeroHostIterator() : any;

    segmentsIterator(excludeZeroHosts? : any) : any;

    segmentsNonZeroHostIterator() : any;

    /**
     * 
     * @param {number} increment
     * @return {*}
     */
    increment(increment : number) : IPAddressSegmentSeries;

    /**
     * 
     * @param {number} increment
     * @return {*}
     */
    incrementBoundary(increment : number) : IPAddressSegmentSeries;

    /**
     * Produces the series with host values of 0 for the given prefix length.
     * <p>
     * If this series has the same prefix length, then the resulting series will too, otherwise the resulting series will have no prefix length.
     * <p>
     * This is nearly equivalent to doing the mask (bitwise conjunction) of this address series with the network mask for the given prefix length,
     * but without the possibility of IncompatibleAddressException that can occur when applying a mask to a range of values.
     * Instead, in this case, if the resulting series has a range of values, then the resulting series range boundaries will have host values of 0, but not necessarily  the intervening values.
     * <p>
     * For instance, you can get the network address for a subnet of prefix length 16 as follows:
     * <code>
     * String addrStr = "1.2.3.4";
     * IPAddress address = new IPAddressString(addrStr).getAddress();
     * IPAddress networkAddress = address.toZeroHost(16); //1.2.0.0
     * </code>
     * 
     * @param {number} prefixLength
     * @return
     * @return {*}
     */
    toZeroHost(prefixLength? : any) : any;

    /**
     * Returns whether all bits past the given prefix length are zero.
     * 
     * @return
     * @param {number} prefixLength
     * @return {boolean}
     */
    includesZeroHost(prefixLength? : any) : any;

    /**
     * Produces the series with host values of all one bits for the given prefix length.
     * <p>
     * If this series has the same prefix length, then the resulting series will too, otherwise the resulting series will have no prefix length.
     * <p>
     * This is nearly equivalent to doing the bitwise or (bitwise disjunction) of this address series with the network mask for the given prefix length,
     * but without the possibility of IncompatibleAddressException that can occur when applying a mask to a range of values.
     * Instead, in this case, if the resulting series has a range of values, then the resulting series range boundaries will have host values of all ones, but not necessarily  the intervening values.
     * <p>
     * For instance, you can get the broadcast address for a subnet of prefix length 16 as follows:
     * <code>
     * String addrStr = "1.2.3.4";
     * IPAddress address = new IPAddressString(addrStr).getAddress();
     * IPAddress broadcastAddress = address.toMaxHost(16); //1.2.255.255
     * </code>
     * 
     * @param {number} prefixLength
     * @return
     * @return {*}
     */
    toMaxHost(prefixLength? : any) : any;

    /**
     * Returns whether all bits past the given prefix length are all ones.
     * 
     * @return
     * @param {number} prefixLength
     * @return {boolean}
     */
    includesMaxHost(prefixLength? : any) : any;

    /**
     * 
     * @return {*}
     */
    reverseSegments() : IPAddressSegmentSeries;

    /**
     * Returns a new series which has the bits reversed.
     * <p>
     * If this has an associated prefix length, then the prefix length is dropped in the reversed series.
     * <p>
     * If this represents a range of values that cannot be reversed,
     * because reversing the range results in a set of addresses that cannot be described by a range, then this throws {@link IncompatibleAddressException}.
     * In such cases you can call {@link #iterator()}, {@link #getLower()}, {@link #getUpper()} or some other method to transform the address
     * into an address representing a single value before reversing.
     * <p>
     * @param {boolean} perByte if true, only the bits in each byte are reversed, if false, then all bits in the address are reversed
     * @throws IncompatibleAddressException if this is a subnet that cannot be reversed
     * @return
     * @return {*}
     */
    reverseBits(perByte? : any) : any;

    reverseBytes(perSegment? : any) : any;

    /**
     * 
     * @return {*}
     */
    reverseBytesPerSegment() : IPAddressSegmentSeries;

    /**
     * Removes the prefix length.  If zeroed is false, the bits that were host bits do not become zero, unlike {@link #removePrefixLength()}
     * 
     * @param {boolean} zeroed whether the host bits become zero.
     * @return
     * @return {*}
     */
    removePrefixLength(zeroed? : any) : any;

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {*}
     */
    adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any;

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {*}
     */
    adjustPrefixLength(adjustment? : any, zeroed? : any) : any;

    setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any;

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {*}
     */
    applyPrefixLength(networkPrefixLength : number) : IPAddressSegmentSeries;
}


