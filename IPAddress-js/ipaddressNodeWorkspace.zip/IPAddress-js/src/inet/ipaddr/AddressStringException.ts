/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierException } from './HostIdentifierException';

/**
 * 
 * @author sfoley
 * @param {*} str
 * @param {string} key
 * @param {Error} cause
 * @class
 * @extends HostIdentifierException
 */
export class AddressStringException extends HostIdentifierException {
    static __inet_ipaddr_AddressStringException_serialVersionUID : number = 4;

    static errorMessage : string; public static errorMessage_$LI$() : string { if(AddressStringException.errorMessage == null) AddressStringException.errorMessage = this.message; return AddressStringException.errorMessage; };

    public constructor(str? : any, key? : any, cause? : any) {
        if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof key === 'string') || key === null) && ((cause != null && (cause["__classes"] && cause["__classes"].indexOf("java.lang.Throwable") >= 0) || cause != null && cause instanceof <any>Error) || cause === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(str, AddressStringException.errorMessage_$LI$(), key, cause);
            (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof key === 'string') || key === null) && ((typeof cause === 'number') || cause === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let characterIndex : any = __args[2];
            super(str.toString() + ' ' + AddressStringException.errorMessage_$LI$() + ' ' + this.message + ' ' + characterIndex);
            (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof key === 'number') || key === null) && ((typeof cause === 'boolean') || cause === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let characterIndex : any = __args[1];
            let combo : any = __args[2];
            super(str.toString() + ' ' + AddressStringException.errorMessage_$LI$() + ' ' + this.message + ' ' + characterIndex);
            (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof key === 'string') || key === null) && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            super(str, AddressStringException.errorMessage_$LI$(), key);
            (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
        } else if(((str != null && (str["__interfaces"] != null && str["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || str.constructor != null && str.constructor["__interfaces"] != null && str.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof str === "string")) || str === null) && ((typeof key === 'number') || key === null) && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let characterIndex : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let combo : any = false;
                super(str.toString() + ' ' + AddressStringException.errorMessage_$LI$() + ' ' + this.message + ' ' + characterIndex);
                (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
            }
        } else if(((typeof str === 'string') || str === null) && key === undefined && cause === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let key : any = __args[0];
            super(AddressStringException.errorMessage_$LI$(), key);
            (<any>Object).setPrototypeOf(this, AddressStringException.prototype);
        } else throw new Error('invalid overload');
    }
}
AddressStringException["__class"] = "inet.ipaddr.AddressStringException";
AddressStringException["__interfaces"] = ["java.io.Serializable"];





AddressStringException.errorMessage_$LI$();
