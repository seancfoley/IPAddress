/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringParameters } from './IPAddressStringParameters';
import { IPAddressString } from './IPAddressString';

/**
 * This class allows you to control the validation performed by the class {@link HostName}.
 * 
 * The {@link HostName} class uses a default permissive HostNameParameters object when you do not specify one.
 * 
 * If you wish to use parameters different from the default, then use this class.  All instances are immutable and must be constructed with the nested Builder class.
 * 
 * @author sfoley
 * @param {IPAddressStringParameters} addressOptions
 * @param {boolean} allowEmpty
 * @param {boolean} emptyIsLoopback
 * @param {boolean} allowBracketedIPv6
 * @param {boolean} allowBracketedIPv4
 * @param {boolean} normalizeToLowercase
 * @param {boolean} allowIPAddress
 * @param {boolean} allowPort
 * @param {boolean} expectPort
 * @param {boolean} allowService
 * @class
 */
export class HostNameParameters {
    static serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_EMPTY : boolean = true;

    public static DEFAULT_EMPTY_IS_LOOPBACK : boolean = true;

    public static DEFAULT_ACCEPT_BRACKETED_IPV6 : boolean = true;

    public static DEFAULT_ACCEPT_BRACKETED_IPV4 : boolean = true;

    public static DEFAULT_NORMALIZE_TO_LOWER_CASE : boolean = true;

    public static DEFAULT_ALLOW_IP_ADDRESS : boolean = true;

    public static DEFAULT_ALLOW_PORT : boolean = true;

    public static DEFAULT_EXPECT_PORT : boolean = false;

    public static DEFAULT_ALLOW_SERVICE : boolean = true;

    public allowEmpty : boolean;

    public emptyIsLoopback : boolean;

    public allowBracketedIPv4 : boolean;

    public allowBracketedIPv6 : boolean;

    public normalizeToLowercase : boolean;

    public allowIPAddress : boolean;

    public allowPort : boolean;

    public allowService : boolean;

    public expectPort : boolean;

    public addressOptions : IPAddressStringParameters;

    public constructor(addressOptions : IPAddressStringParameters, allowEmpty : boolean, emptyIsLoopback : boolean, allowBracketedIPv6 : boolean, allowBracketedIPv4 : boolean, normalizeToLowercase : boolean, allowIPAddress : boolean, allowPort : boolean, expectPort : boolean, allowService : boolean) {
        if(this.allowEmpty===undefined) this.allowEmpty = false;
        if(this.emptyIsLoopback===undefined) this.emptyIsLoopback = false;
        if(this.allowBracketedIPv4===undefined) this.allowBracketedIPv4 = false;
        if(this.allowBracketedIPv6===undefined) this.allowBracketedIPv6 = false;
        if(this.normalizeToLowercase===undefined) this.normalizeToLowercase = false;
        if(this.allowIPAddress===undefined) this.allowIPAddress = false;
        if(this.allowPort===undefined) this.allowPort = false;
        if(this.allowService===undefined) this.allowService = false;
        if(this.expectPort===undefined) this.expectPort = false;
        if(this.addressOptions===undefined) this.addressOptions = null;
        this.allowEmpty = allowEmpty;
        this.emptyIsLoopback = emptyIsLoopback;
        this.allowBracketedIPv6 = allowBracketedIPv6;
        this.allowBracketedIPv4 = allowBracketedIPv4;
        this.normalizeToLowercase = normalizeToLowercase;
        this.allowIPAddress = allowIPAddress;
        this.allowPort = allowPort;
        this.expectPort = expectPort;
        this.allowService = allowService;
        this.addressOptions = addressOptions;
    }

    public toBuilder() : HostNameParameters.Builder {
        let builder : HostNameParameters.Builder = new HostNameParameters.Builder();
        builder.__allowEmpty = this.allowEmpty;
        builder.emptyIsLoopback = this.emptyIsLoopback;
        builder.__allowBracketedIPv4 = this.allowBracketedIPv4;
        builder.__allowBracketedIPv6 = this.allowBracketedIPv6;
        builder.normalizeToLowercase = this.normalizeToLowercase;
        builder.__allowIPAddress = this.allowIPAddress;
        builder.__allowPort = this.allowPort;
        builder.__allowService = this.allowService;
        builder.addressOptionsBuilder = this.toAddressOptionsBuilder();
        return builder;
    }

    public toAddressOptionsBuilder() : IPAddressStringParameters.Builder {
        return this.addressOptions.toBuilder();
    }

    /**
     * 
     * @return {HostNameParameters}
     */
    public clone() : HostNameParameters {
        try {
            return <HostNameParameters>/* clone *//* clone */((o:any) => { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; })(this);
        } catch(e) {
        };
        return null;
    }

    /**
     * 
     * @param {HostNameParameters} o
     * @return {number}
     */
    public compareTo(o : HostNameParameters) : number {
        let result : number = javaemul.internal.BooleanHelper.compare(this.allowEmpty, o.allowEmpty);
        if(result === 0) {
            result = javaemul.internal.BooleanHelper.compare(this.allowBracketedIPv6, o.allowBracketedIPv6);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowBracketedIPv4, o.allowBracketedIPv4);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.normalizeToLowercase, o.normalizeToLowercase);
                    if(result === 0) {
                        result = javaemul.internal.BooleanHelper.compare(this.allowIPAddress, o.allowIPAddress);
                        if(result === 0) {
                            result = javaemul.internal.BooleanHelper.compare(this.allowPort, o.allowPort);
                            if(result === 0) {
                                result = javaemul.internal.BooleanHelper.compare(this.expectPort, o.expectPort);
                                if(result === 0) {
                                    result = javaemul.internal.BooleanHelper.compare(this.allowService, o.allowService);
                                    if(result === 0) {
                                        result = this.addressOptions.compareTo$inet_ipaddr_IPAddressStringParameters(o.addressOptions);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>HostNameParameters) {
            let other : HostNameParameters = <HostNameParameters>o;
            return this.allowEmpty === other.allowEmpty && this.allowBracketedIPv6 === other.allowBracketedIPv6 && this.allowBracketedIPv4 === other.allowBracketedIPv4 && this.normalizeToLowercase === other.normalizeToLowercase && this.allowIPAddress === other.allowIPAddress && this.allowPort === other.allowPort && this.expectPort === other.expectPort && this.allowService === other.allowService && this.addressOptions.equals(other.addressOptions);
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let hash : number = this.allowIPAddress?/* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.addressOptions)):0;
        if(this.allowEmpty) {
            hash |= 536870912;
        }
        if(this.allowIPAddress) {
            if(this.allowBracketedIPv6 || this.allowBracketedIPv4) {
                hash |= -2147483648;
            }
        }
        if(this.allowPort || this.allowService || this.expectPort) {
            hash |= 1073741824;
        }
        return hash;
    }
}
HostNameParameters["__class"] = "inet.ipaddr.HostNameParameters";
HostNameParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



export namespace HostNameParameters {

    export class Builder {
        __allowEmpty : boolean = HostNameParameters.DEFAULT_ALLOW_EMPTY;

        emptyIsLoopback : boolean = HostNameParameters.DEFAULT_EMPTY_IS_LOOPBACK;

        __allowBracketedIPv6 : boolean = HostNameParameters.DEFAULT_ACCEPT_BRACKETED_IPV6;

        __allowBracketedIPv4 : boolean = HostNameParameters.DEFAULT_ACCEPT_BRACKETED_IPV4;

        normalizeToLowercase : boolean = HostNameParameters.DEFAULT_NORMALIZE_TO_LOWER_CASE;

        __allowIPAddress : boolean = HostNameParameters.DEFAULT_ALLOW_IP_ADDRESS;

        __allowPort : boolean = HostNameParameters.DEFAULT_ALLOW_PORT;

        __expectPort : boolean = HostNameParameters.DEFAULT_EXPECT_PORT;

        __allowService : boolean = HostNameParameters.DEFAULT_ALLOW_SERVICE;

        addressOptionsBuilder : IPAddressStringParameters.Builder;

        public constructor() {
            if(this.addressOptionsBuilder===undefined) this.addressOptionsBuilder = null;
        }

        public allowPort(allow : boolean) : HostNameParameters.Builder {
            this.__allowPort = allow;
            return this;
        }

        public expectPort(expect : boolean) : HostNameParameters.Builder {
            this.__expectPort = expect;
            return this;
        }

        public allowService(allow : boolean) : HostNameParameters.Builder {
            this.__allowService = allow;
            return this;
        }

        public allowIPAddress(allow : boolean) : HostNameParameters.Builder {
            this.__allowIPAddress = allow;
            return this;
        }

        public allowEmpty(allow : boolean) : HostNameParameters.Builder {
            this.__allowEmpty = allow;
            return this;
        }

        public setEmptyAsLoopback(bool : boolean) : HostNameParameters.Builder {
            this.emptyIsLoopback = bool;
            return this;
        }

        public allowBracketedIPv6(allow : boolean) : HostNameParameters.Builder {
            this.__allowBracketedIPv6 = allow;
            return this;
        }

        public allowBracketedIPv4(allow : boolean) : HostNameParameters.Builder {
            this.__allowBracketedIPv4 = allow;
            return this;
        }

        public setNormalizeToLowercase(bool : boolean) : HostNameParameters.Builder {
            this.normalizeToLowercase = bool;
            return this;
        }

        public getAddressOptionsBuilder() : IPAddressStringParameters.Builder {
            if(this.addressOptionsBuilder == null) {
                this.addressOptionsBuilder = new IPAddressStringParameters.Builder();
            }
            this.addressOptionsBuilder.parent = this;
            return this.addressOptionsBuilder;
        }

        public toParams() : HostNameParameters {
            let addressOpts : IPAddressStringParameters;
            if(this.addressOptionsBuilder == null) {
                addressOpts = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
            } else {
                addressOpts = this.addressOptionsBuilder.toParams();
            }
            return new HostNameParameters(addressOpts, this.__allowEmpty, this.emptyIsLoopback, this.__allowIPAddress && this.__allowBracketedIPv6, this.__allowIPAddress && this.__allowBracketedIPv4, this.normalizeToLowercase, this.__allowIPAddress, this.__allowPort, this.__expectPort, this.__allowService);
        }
    }
    Builder["__class"] = "inet.ipaddr.HostNameParameters.Builder";

}



