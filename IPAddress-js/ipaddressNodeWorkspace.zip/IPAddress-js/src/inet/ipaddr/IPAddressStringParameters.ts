/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPv4AddressStringParameters } from './ipv4/IPv4AddressStringParameters';
import { IPv6AddressStringParameters } from './ipv6/IPv6AddressStringParameters';
import { AddressStringParameters } from './AddressStringParameters';
import { IPAddress } from './IPAddress';
import { HostNameParameters } from './HostNameParameters';
import { IPAddressNetwork } from './IPAddressNetwork';

/**
 * This class allows you to control the validation performed by the class {@link IPAddressString}.
 * 
 * The {@link IPAddressString} class uses a default permissive IPAddressStringParameters instance when you do not specify one.
 * 
 * If you wish to use parameters different from the default, then use this class.  All instances are immutable and must be constructed with the nested Builder class.
 * 
 * @author sfoley
 * @param {boolean} allowEmpty
 * @param {boolean} allowAll
 * @param {boolean} allowSingleSegment
 * @param {boolean} emptyIsLoopback
 * @param {boolean} allowPrefix
 * @param {boolean} allowMask
 * @param {boolean} allowPrefixOnly
 * @param {boolean} allowIPv4
 * @param {boolean} allowIPv6
 * @param {IPv4AddressStringParameters} ipv4Options
 * @param {IPv6AddressStringParameters} ipv6Options
 * @class
 * @extends AddressStringParameters
 */
export class IPAddressStringParameters extends AddressStringParameters {
    static __inet_ipaddr_IPAddressStringParameters_serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_PREFIX_ONLY : boolean = true;

    public static DEFAULT_EMPTY_IS_LOOPBACK : boolean = true;

    public static DEFAULT_ALLOW_PREFIX : boolean = true;

    public static DEFAULT_ALLOW_MASK : boolean = true;

    public static DEFAULT_ALLOW_IPV4 : boolean = true;

    public static DEFAULT_ALLOW_IPV6 : boolean = true;

    /**
     * Allows addresses like /64 which are only prefix lenths.
     * Such addresses are interpreted as the network mask for the given prefix length.
     * @see #DEFAULT_ALLOW_PREFIX_ONLY
     */
    public allowPrefixOnly : boolean;

    /**
     * Whether the zero-length address is interpreted as the loopback.
     * @see #allowEmpty
     * @see #DEFAULT_EMPTY_IS_LOOPBACK
     */
    public emptyIsLoopback : boolean;

    /**
     * Allows addresses with prefix length like 1.2.0.0/16
     * Such as an address is interpreted as a subnet.
     * 1.2.0.0/16 is the subnet of addresses with network prefix 1.2
     * 
     * @see #DEFAULT_ALLOW_PREFIX
     */
    public allowPrefix : boolean;

    /**
     * Allows masks to follow valid addresses, such as 1.2.3.4/255.255.0.0 which has the mask 255.255.0.0<p>
     * If the mask is the mask for a network prefix length, this is interpreted as the subnet for that network prefix length.
     * Otherwise the address is simply masked by the mask.
     * For instance, 1.2.3.4/255.0.255.0 is 1.0.3.0, while 1.2.3.4/255.255.0.0 is 1.2.0.0/16.
     * 
     * @see #allowPrefix
     * @see #DEFAULT_ALLOW_MASK
     * 
     */
    public allowMask : boolean;

    public allowIPv6 : boolean;

    public allowIPv4 : boolean;

    /*private*/ ipv6Options : IPv6AddressStringParameters;

    /*private*/ ipv4Options : IPv4AddressStringParameters;

    public inferVersion() : IPAddress.IPVersion {
        if(this.allowIPv6) {
            if(!this.allowIPv4) {
                return IPAddress.IPVersion.IPV6;
            }
        } else {
            if(this.allowIPv4) {
                return IPAddress.IPVersion.IPV4;
            }
        }
        return null;
    }

    public toBuilder(builder? : any) : any {
        if(((builder != null && builder instanceof <any>AddressStringParameters.BuilderBase) || builder === null)) {
            super.toBuilder(builder);
        } else if(((typeof builder === 'boolean') || builder === null)) {
            return <any>this.toBuilder$boolean(builder);
        } else if(builder === undefined) {
            return <any>this.toBuilder$();
        } else throw new Error('invalid overload');
    }

    public toBuilder$() : IPAddressStringParameters.Builder {
        return this.toBuilder$boolean(false);
    }

    public toBuilder$boolean(isMixed : boolean) : IPAddressStringParameters.Builder {
        let builder : IPAddressStringParameters.Builder = new IPAddressStringParameters.Builder();
        super.toBuilder$inet_ipaddr_AddressStringParameters_BuilderBase(builder);
        builder.__allowPrefixOnly = this.allowPrefixOnly;
        builder.emptyIsLoopback = this.emptyIsLoopback;
        builder.__allowPrefix = this.allowPrefix;
        builder.__allowMask = this.allowMask;
        builder.__allowIPv6 = this.allowIPv6;
        builder.__allowIPv4 = this.allowIPv4;
        builder.ipv4Builder = this.ipv4Options.toBuilder();
        builder.ipv6Builder = this.ipv6Options.toBuilder$boolean(isMixed);
        builder.__allowSingleSegment = this.allowSingleSegment;
        builder.__allowEmpty = this.allowEmpty;
        builder.__allowAll = this.allowAll;
        return builder;
    }

    public constructor(allowEmpty : boolean, allowAll : boolean, allowSingleSegment : boolean, emptyIsLoopback : boolean, allowPrefix : boolean, allowMask : boolean, allowPrefixOnly : boolean, allowIPv4 : boolean, allowIPv6 : boolean, ipv4Options : IPv4AddressStringParameters, ipv6Options : IPv6AddressStringParameters) {
        super(allowEmpty, allowAll, allowSingleSegment);
        if(this.allowPrefixOnly===undefined) this.allowPrefixOnly = false;
        if(this.emptyIsLoopback===undefined) this.emptyIsLoopback = false;
        if(this.allowPrefix===undefined) this.allowPrefix = false;
        if(this.allowMask===undefined) this.allowMask = false;
        if(this.allowIPv6===undefined) this.allowIPv6 = false;
        if(this.allowIPv4===undefined) this.allowIPv4 = false;
        if(this.ipv6Options===undefined) this.ipv6Options = null;
        if(this.ipv4Options===undefined) this.ipv4Options = null;
        this.allowPrefixOnly = allowPrefixOnly;
        this.emptyIsLoopback = emptyIsLoopback;
        this.allowPrefix = allowPrefix;
        this.allowMask = allowMask;
        this.allowIPv4 = allowIPv4;
        this.allowIPv6 = allowIPv6;
        this.ipv6Options = ipv6Options;
        this.ipv4Options = ipv4Options;
    }

    public getIPv6Parameters() : IPv6AddressStringParameters {
        return this.ipv6Options;
    }

    public getIPv4Parameters() : IPv4AddressStringParameters {
        return this.ipv4Options;
    }

    /**
     * 
     * @return {IPAddressStringParameters}
     */
    public clone() : IPAddressStringParameters {
        let result : IPAddressStringParameters = <IPAddressStringParameters>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
        result.ipv4Options = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.ipv4Options);
        result.ipv6Options = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.ipv6Options);
        return result;
    }

    public compareTo$inet_ipaddr_IPAddressStringParameters(o : IPAddressStringParameters) : number {
        let result : number = super.compareTo$inet_ipaddr_AddressStringParameters(o);
        if(result === 0) {
            result = this.ipv4Options.compareTo$inet_ipaddr_ipv4_IPv4AddressStringParameters(o.ipv4Options);
            if(result === 0) {
                result = this.ipv6Options.compareTo$inet_ipaddr_ipv6_IPv6AddressStringParameters(o.ipv6Options);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.emptyIsLoopback, o.emptyIsLoopback);
                    if(result === 0) {
                        result = javaemul.internal.BooleanHelper.compare(this.allowPrefix, o.allowPrefix);
                        if(result === 0) {
                            result = javaemul.internal.BooleanHelper.compare(this.allowMask, o.allowMask);
                            if(result === 0) {
                                result = javaemul.internal.BooleanHelper.compare(this.allowIPv6, o.allowIPv6);
                                if(result === 0) {
                                    result = javaemul.internal.BooleanHelper.compare(this.allowIPv4, o.allowIPv4);
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * 
     * @param {IPAddressStringParameters} o
     * @return {number}
     */
    public compareTo(o? : any) : any {
        if(((o != null && o instanceof <any>IPAddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_IPAddressStringParameters(o);
        } else if(((o != null && o instanceof <any>AddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_AddressStringParameters(o);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>IPAddressStringParameters) {
            let other : IPAddressStringParameters = <IPAddressStringParameters>o;
            return super.equals(o) && this.ipv4Options.equals(other.ipv4Options) && this.ipv6Options.equals(other.ipv6Options) && this.emptyIsLoopback === other.emptyIsLoopback && this.allowPrefix === other.allowPrefix && this.allowMask === other.allowMask && this.allowIPv6 === other.allowIPv6 && this.allowIPv4 === other.allowIPv4;
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.ipv4Options));
        hash |= /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.ipv6Options)) << 9;
        if(this.emptyIsLoopback) {
            hash |= 134217728;
        }
        if(this.allowPrefix) {
            hash |= 268435456;
        }
        if(this.allowMask) {
            hash |= 536870912;
        }
        if(this.allowEmpty) {
            hash |= 1073741824;
        }
        if(this.allowSingleSegment) {
            hash |= -2147483648;
        }
        return hash;
    }
}
IPAddressStringParameters["__class"] = "inet.ipaddr.IPAddressStringParameters";
IPAddressStringParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



export namespace IPAddressStringParameters {

    export class Builder extends AddressStringParameters.BuilderBase {
        emptyIsLoopback : boolean = IPAddressStringParameters.DEFAULT_EMPTY_IS_LOOPBACK;

        __allowPrefix : boolean = IPAddressStringParameters.DEFAULT_ALLOW_PREFIX;

        __allowMask : boolean = IPAddressStringParameters.DEFAULT_ALLOW_MASK;

        __allowPrefixOnly : boolean = IPAddressStringParameters.DEFAULT_ALLOW_PREFIX_ONLY;

        __allowIPv4 : boolean = IPAddressStringParameters.DEFAULT_ALLOW_IPV4;

        __allowIPv6 : boolean = IPAddressStringParameters.DEFAULT_ALLOW_IPV6;

        ipv4Builder : IPv4AddressStringParameters.Builder;

        static DEFAULT_IPV4_OPTS : IPv4AddressStringParameters; public static DEFAULT_IPV4_OPTS_$LI$() : IPv4AddressStringParameters { if(Builder.DEFAULT_IPV4_OPTS == null) Builder.DEFAULT_IPV4_OPTS = new IPv4AddressStringParameters.Builder().toParams(); return Builder.DEFAULT_IPV4_OPTS; };

        ipv6Builder : IPv6AddressStringParameters.Builder;

        static DEFAULT_IPV6_OPTS : IPv6AddressStringParameters; public static DEFAULT_IPV6_OPTS_$LI$() : IPv6AddressStringParameters { if(Builder.DEFAULT_IPV6_OPTS == null) Builder.DEFAULT_IPV6_OPTS = new IPv6AddressStringParameters.Builder().toParams(); return Builder.DEFAULT_IPV6_OPTS; };

        parent : HostNameParameters.Builder;

        public constructor() {
            super();
            if(this.ipv4Builder===undefined) this.ipv4Builder = null;
            if(this.ipv6Builder===undefined) this.ipv6Builder = null;
            if(this.parent===undefined) this.parent = null;
        }

        public getParentBuilder() : HostNameParameters.Builder {
            return this.parent;
        }

        /**
         * @see IPAddressStringParameters#allowEmpty
         * @param {boolean} allow
         * @return {IPAddressStringParameters.Builder} the builder
         */
        public allowEmpty(allow : boolean) : IPAddressStringParameters.Builder {
            return <IPAddressStringParameters.Builder>super.allowEmpty(allow);
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPAddressStringParameters.Builder}
         */
        public allowSingleSegment(allow : boolean) : IPAddressStringParameters.Builder {
            return <IPAddressStringParameters.Builder>super.allowSingleSegment(allow);
        }

        public setEmptyAsLoopback(bool : boolean) : IPAddressStringParameters.Builder {
            this.emptyIsLoopback = bool;
            return this;
        }

        public allowPrefix(allow : boolean) : IPAddressStringParameters.Builder {
            this.__allowPrefix = allow;
            return this;
        }

        public allowMask(allow : boolean) : IPAddressStringParameters.Builder {
            this.__allowMask = allow;
            return this;
        }

        public allowPrefixOnly(allow : boolean) : IPAddressStringParameters.Builder {
            this.__allowPrefixOnly = allow;
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPAddressStringParameters.Builder}
         */
        public allowAll(allow : boolean) : IPAddressStringParameters.Builder {
            return <IPAddressStringParameters.Builder>super.allowAll(allow);
        }

        public allowIPv4(allow : boolean) : IPAddressStringParameters.Builder {
            this.__allowIPv4 = allow;
            return this;
        }

        public allowIPv6(allow : boolean) : IPAddressStringParameters.Builder {
            this.__allowIPv6 = allow;
            return this;
        }

        public allowWildcardedSeparator(allow : boolean) : IPAddressStringParameters.Builder {
            this.getIPv4AddressParametersBuilder().allowWildcardedSeparator(allow);
            this.getIPv6AddressParametersBuilder().allowWildcardedSeparator(allow);
            return this;
        }

        public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : IPAddressStringParameters.Builder {
            this.getIPv4AddressParametersBuilder().setRangeOptions(rangeOptions);
            this.getIPv6AddressParametersBuilder().setRangeOptions(rangeOptions);
            return this;
        }

        public allow_inet_aton(allow : boolean) : IPAddressStringParameters.Builder {
            this.getIPv4AddressParametersBuilder().allow_inet_aton(allow);
            this.getIPv6AddressParametersBuilder().allow_mixed_inet_aton(allow);
            return this;
        }

        /**
         * Replaces all existing IPv6 parameters with the ones in the supplied parameters instance.
         * @param {IPv6AddressStringParameters} params
         */
        public setIPv6AddressParameters(params : IPv6AddressStringParameters) {
            this.ipv6Builder = params.toBuilder();
        }

        /**
         * Get the sub-builder for setting IPv6 parameters.
         * @return {IPv6AddressStringParameters.Builder} the IPv6 builder
         */
        public getIPv6AddressParametersBuilder() : IPv6AddressStringParameters.Builder {
            if(this.ipv6Builder == null) {
                this.ipv6Builder = new IPv6AddressStringParameters.Builder();
            }
            (<IPAddressStringParameters.IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>this.ipv6Builder).parent = this;
            return this.ipv6Builder;
        }

        /**
         * Replaces all existing IPv4 parameters with the ones in the supplied parameters instance.
         * @param {IPv4AddressStringParameters} params
         */
        public setIPv4AddressParameters(params : IPv4AddressStringParameters) {
            this.ipv4Builder = params.toBuilder();
        }

        /**
         * Get the sub-builder for setting IPv4 parameters.
         * @return {IPv4AddressStringParameters.Builder} the IPv4 builder
         */
        public getIPv4AddressParametersBuilder() : IPv4AddressStringParameters.Builder {
            if(this.ipv4Builder == null) {
                this.ipv4Builder = new IPv4AddressStringParameters.Builder();
            }
            (<IPAddressStringParameters.IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>this.ipv4Builder).parent = this;
            return this.ipv4Builder;
        }

        public toParams() : IPAddressStringParameters {
            let ipv4Opts : IPv4AddressStringParameters;
            if(this.ipv4Builder == null) {
                ipv4Opts = Builder.DEFAULT_IPV4_OPTS_$LI$();
            } else {
                ipv4Opts = this.ipv4Builder.toParams();
            }
            let ipv6Opts : IPv6AddressStringParameters;
            if(this.ipv6Builder == null) {
                ipv6Opts = Builder.DEFAULT_IPV6_OPTS_$LI$();
            } else {
                ipv6Opts = this.ipv6Builder.toParams();
            }
            return new IPAddressStringParameters(this.__allowEmpty, this.__allowAll, this.__allowSingleSegment, this.emptyIsLoopback, this.__allowPrefix, this.__allowMask, this.__allowPrefixOnly, this.__allowIPv4, this.__allowIPv6, ipv4Opts, ipv6Opts);
        }
    }
    Builder["__class"] = "inet.ipaddr.IPAddressStringParameters.Builder";


    export abstract class IPAddressStringFormatParameters extends AddressStringParameters.AddressStringFormatParameters {
        static __inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_serialVersionUID : number = 4;

        public static DEFAULT_ALLOW_PREFIX_LENGTH_LEADING_ZEROS : boolean = true;

        public static DEFAULT_ALLOW_PREFIX_BEYOND_ADDRESS_SIZE : boolean = false;

        /**
         * controls whether ipv4 can have prefix length bigger than 32 and whether ipv6 can have prefix length bigger than 128
         * @see #DEFAULT_ALLOW_PREFIX_BEYOND_ADDRESS_SIZE
         */
        public allowPrefixesBeyondAddressSize : boolean;

        /**
         * controls whether you allow addresses with prefixes that have leasing zeros like 1.0.0.0/08 or 1::/064
         * 
         * @see #DEFAULT_ALLOW_PREFIX_LENGTH_LEADING_ZEROS
         */
        public allowPrefixLengthLeadingZeros : boolean;

        public constructor(allowLeadingZeros : boolean, allowPrefixLengthLeadingZeros : boolean, allowUnlimitedLeadingZeros : boolean, rangeOptions : AddressStringParameters.RangeParameters, allowWildcardedSeparator : boolean, allowPrefixesBeyondAddressSize : boolean) {
            super(allowLeadingZeros, allowUnlimitedLeadingZeros, rangeOptions, allowWildcardedSeparator);
            if(this.allowPrefixesBeyondAddressSize===undefined) this.allowPrefixesBeyondAddressSize = false;
            if(this.allowPrefixLengthLeadingZeros===undefined) this.allowPrefixLengthLeadingZeros = false;
            this.allowPrefixLengthLeadingZeros = allowPrefixLengthLeadingZeros;
            this.allowPrefixesBeyondAddressSize = allowPrefixesBeyondAddressSize;
        }

        public toBuilder$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase(builder : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
            super.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
            builder.__allowPrefixLengthLeadingZeros = this.allowPrefixLengthLeadingZeros;
            builder.__allowPrefixesBeyondAddressSize = this.allowPrefixesBeyondAddressSize;
            return builder;
        }

        public toBuilder(builder? : any) : any {
            if(((builder != null && builder instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase) || builder === null)) {
                return <any>this.toBuilder$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase(builder);
            } else if(((builder != null && builder instanceof <any>AddressStringParameters.AddressStringFormatParameters.BuilderBase) || builder === null)) {
                return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
            } else throw new Error('invalid overload');
        }

        public abstract getNetwork() : IPAddressNetwork<any, any, any, any, any>;

        /**
         * 
         * @param {IPv4AddressStringParameters} o
         * @return {number}
         */
        public compareTo(o? : any) : any {
            if(((o != null && o instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters) || o === null)) {
                return <any>this.compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o);
            } else if(((o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) || o === null)) {
                return <any>this.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
            } else throw new Error('invalid overload');
        }

        compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o : IPAddressStringParameters.IPAddressStringFormatParameters) : number {
            let result : number = super.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowPrefixesBeyondAddressSize, o.allowPrefixesBeyondAddressSize);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.allowPrefixLengthLeadingZeros, o.allowPrefixLengthLeadingZeros);
                }
            }
            return result;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o != null && o instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters) {
                let other : IPAddressStringParameters.IPAddressStringFormatParameters = <IPAddressStringParameters.IPAddressStringFormatParameters>o;
                return super.equals(o) && this.allowPrefixesBeyondAddressSize === other.allowPrefixesBeyondAddressSize && this.allowPrefixLengthLeadingZeros === other.allowPrefixLengthLeadingZeros;
            }
            return false;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
            if(this.allowPrefixesBeyondAddressSize) {
                hash |= 8;
            }
            return hash;
        }
    }
    IPAddressStringFormatParameters["__class"] = "inet.ipaddr.IPAddressStringParameters.IPAddressStringFormatParameters";
    IPAddressStringFormatParameters["__interfaces"] = ["java.lang.Cloneable","java.io.Serializable"];



    export namespace IPAddressStringFormatParameters {

        export class __inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase extends AddressStringParameters.AddressStringFormatParameters.BuilderBase {
            __allowPrefixesBeyondAddressSize : boolean = IPAddressStringFormatParameters.DEFAULT_ALLOW_PREFIX_BEYOND_ADDRESS_SIZE;

            __allowPrefixLengthLeadingZeros : boolean = IPAddressStringFormatParameters.DEFAULT_ALLOW_PREFIX_LENGTH_LEADING_ZEROS;

            parent : IPAddressStringParameters.Builder;

            public getParentBuilder() : IPAddressStringParameters.Builder {
                return this.parent;
            }

            /**
             * 
             * @param {AddressStringParameters.RangeParameters} rangeOptions
             * @return {IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase}
             */
            public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                return <IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>super.setRangeOptions(rangeOptions);
            }

            public allowPrefixesBeyondAddressSize(allow : boolean) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                this.__allowPrefixesBeyondAddressSize = allow;
                return this;
            }

            /**
             * 
             * @param {boolean} allow
             * @return {IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase}
             */
            public allowWildcardedSeparator(allow : boolean) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                return <IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>super.allowWildcardedSeparator(allow);
            }

            /**
             * 
             * @param {boolean} allow
             * @return {IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase}
             */
            public allowLeadingZeros(allow : boolean) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                return <IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>super.allowLeadingZeros(allow);
            }

            public allowPrefixLengthLeadingZeros(allow : boolean) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                this.__allowPrefixLengthLeadingZeros = allow;
                return this;
            }

            /**
             * 
             * @param {boolean} allow
             * @return {IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase}
             */
            public allowUnlimitedLeadingZeros(allow : boolean) : IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
                return <IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase>super.allowUnlimitedLeadingZeros(allow);
            }

            constructor() {
                super();
                if(this.parent===undefined) this.parent = null;
            }
        }
        __inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase["__class"] = "inet.ipaddr.IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase";

    }

}




IPAddressStringParameters.Builder.DEFAULT_IPV6_OPTS_$LI$();

IPAddressStringParameters.Builder.DEFAULT_IPV4_OPTS_$LI$();
