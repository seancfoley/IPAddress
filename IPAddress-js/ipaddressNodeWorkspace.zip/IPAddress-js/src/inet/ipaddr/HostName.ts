/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierStringValidator } from './format/validate/HostIdentifierStringValidator';
import { ParsedHost } from './format/validate/ParsedHost';
import { Validator } from './format/validate/Validator';
import { IPv6Address } from './ipv6/IPv6Address';
import { HostIdentifierString } from './HostIdentifierString';
import { HostNameParameters } from './HostNameParameters';
import { HostNameException } from './HostNameException';
import { IPAddress } from './IPAddress';
import { IPAddressProvider } from './format/validate/IPAddressProvider';
import { IPAddressStringParameters } from './IPAddressStringParameters';
import { IPAddressString } from './IPAddressString';
import { IPv4Address } from './ipv4/IPv4Address';
import { IPv4AddressNetwork } from './ipv4/IPv4AddressNetwork';
import { IPv4AddressStringParameters } from './ipv4/IPv4AddressStringParameters';
import { IPv6AddressNetwork } from './ipv6/IPv6AddressNetwork';
import { IPv6AddressStringParameters } from './ipv6/IPv6AddressStringParameters';
import { IPAddressSegment } from './IPAddressSegment';
import { AddressStringException } from './AddressStringException';

/**
 * An internet host name.  Can be a fully qualified domain name, a simple host name, or an ip address string.
 * <p>
 * <h2>Supported formats</h2>
 * You can use all host or address formats supported by nmap and all address formats supported by {@link IPAddressString}.
 * All manners of domain names are supported. You can add a prefix length to denote the subnet of the resolved address.
 * <p>
 * Validation is done separately from DNS resolution to avoid unnecessary lookups.
 * <p>
 * See rfc 3513, 2181, 952, 1035, 1034, 1123, 5890 or the list of rfcs for IPAddress.  For IPv6 addresses in host, see rfc 2732 specifying [] notation
 * and 3986 and 4038 (combining IPv6 [] with prefix or zone) and SMTP rfc 2821 for alternative uses of [] for both IPv4 and IPv6
 * <p>
 * 
 * @custom.core
 * @author sfoley
 * @param {InetAddress} inetAddr
 * @param {IPAddressStringParameters} addressOptions
 * @class
 */
export class HostName implements HostIdentifierString {
    static serialVersionUID : number = 4;

    public static LABEL_SEPARATOR : string = '.';

    public static IPV6_START_BRACKET : string = '[';

    public static IPV6_END_BRACKET : string = ']';

    public static PORT_SEPARATOR : string = ':';

    public static DEFAULT_VALIDATION_OPTIONS : HostNameParameters; public static DEFAULT_VALIDATION_OPTIONS_$LI$() : HostNameParameters { if(HostName.DEFAULT_VALIDATION_OPTIONS == null) HostName.DEFAULT_VALIDATION_OPTIONS = new HostNameParameters.Builder().toParams(); return HostName.DEFAULT_VALIDATION_OPTIONS; };

    /*private*/ host : string;

    /*private*/ normalizedString : string;

    /*private*/ normalizedWildcardString : string;

    /*private*/ parsedHost : ParsedHost;

    /*private*/ validationException : HostNameException;

    resolvedAddress : IPAddress;

    /*private*/ resolvedIsNull : boolean;

    /*private*/ validationOptions : HostNameParameters;

    public constructor(inetAddr? : any, addressOptions? : any) {
        if(((inetAddr != null && inetAddr instanceof <any>InetAddress) || inetAddr === null) && ((addressOptions != null && addressOptions instanceof <any>IPAddressStringParameters) || addressOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let addr : any = (inetAddr != null && inetAddr instanceof <any>Inet4Address)?addressOptions.getIPv4Parameters().getNetwork().getAddressCreator().createAddress$java_net_Inet4Address(<Inet4Address>inetAddr):addressOptions.getIPv6Parameters().getNetwork().getAddressCreator().createAddress$java_net_Inet6Address(<Inet6Address>inetAddr);
                if(this.host===undefined) this.host = null;
                if(this.normalizedString===undefined) this.normalizedString = null;
                if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                if(this.parsedHost===undefined) this.parsedHost = null;
                if(this.validationException===undefined) this.validationException = null;
                if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.host===undefined) this.host = null;
                if(this.normalizedString===undefined) this.normalizedString = null;
                if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                if(this.parsedHost===undefined) this.parsedHost = null;
                if(this.validationException===undefined) this.validationException = null;
                if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                if(this.validationOptions===undefined) this.validationOptions = null;
                (() => {
                    this.normalizedString = this.host = addr.toNormalizedString();
                    this.parsedHost = new ParsedHost(this.host, addr.getProvider());
                    this.validationOptions = null;
                })();
            }
        } else if(((typeof inetAddr === 'string') || inetAddr === null) && ((addressOptions != null && addressOptions instanceof <any>ParsedHost) || addressOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let hostStr : any = __args[0];
            let parsed : any = __args[1];
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            (() => {
                this.host = hostStr;
                this.parsedHost = parsed;
                this.validationOptions = null;
            })();
        } else if(((typeof inetAddr === 'string') || inetAddr === null) && ((addressOptions != null && addressOptions instanceof <any>HostNameParameters) || addressOptions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let host : any = __args[0];
            let options : any = __args[1];
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            (() => {
                if(options == null) {
                    throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                }
                this.validationOptions = options;
                this.host = (host == null)?"":host.trim();
            })();
        } else if(((inetAddr != null && inetAddr instanceof <any>IPAddress) || inetAddr === null) && addressOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let addr : any = __args[0];
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            if(this.host===undefined) this.host = null;
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
            if(this.parsedHost===undefined) this.parsedHost = null;
            if(this.validationException===undefined) this.validationException = null;
            if(this.resolvedAddress===undefined) this.resolvedAddress = null;
            if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
            if(this.validationOptions===undefined) this.validationOptions = null;
            (() => {
                this.normalizedString = this.host = addr.toNormalizedString();
                this.parsedHost = new ParsedHost(this.host, addr.getProvider());
                this.validationOptions = null;
            })();
        } else if(((inetAddr != null && inetAddr instanceof <any>InetAddress) || inetAddr === null) && addressOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let addressOptions : any = IPAddressString.DEFAULT_VALIDATION_OPTIONS_$LI$();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let addr : any = (inetAddr != null && inetAddr instanceof <any>Inet4Address)?addressOptions.getIPv4Parameters().getNetwork().getAddressCreator().createAddress$java_net_Inet4Address(<Inet4Address>inetAddr):addressOptions.getIPv6Parameters().getNetwork().getAddressCreator().createAddress$java_net_Inet6Address(<Inet6Address>inetAddr);
                    if(this.host===undefined) this.host = null;
                    if(this.normalizedString===undefined) this.normalizedString = null;
                    if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                    if(this.parsedHost===undefined) this.parsedHost = null;
                    if(this.validationException===undefined) this.validationException = null;
                    if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                    if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                    if(this.validationOptions===undefined) this.validationOptions = null;
                    if(this.host===undefined) this.host = null;
                    if(this.normalizedString===undefined) this.normalizedString = null;
                    if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                    if(this.parsedHost===undefined) this.parsedHost = null;
                    if(this.validationException===undefined) this.validationException = null;
                    if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                    if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                    if(this.validationOptions===undefined) this.validationOptions = null;
                    (() => {
                        this.normalizedString = this.host = addr.toNormalizedString();
                        this.parsedHost = new ParsedHost(this.host, addr.getProvider());
                        this.validationOptions = null;
                    })();
                }
            }
        } else if(((typeof inetAddr === 'string') || inetAddr === null) && addressOptions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let host : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = HostName.DEFAULT_VALIDATION_OPTIONS_$LI$();
                if(this.host===undefined) this.host = null;
                if(this.normalizedString===undefined) this.normalizedString = null;
                if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                if(this.parsedHost===undefined) this.parsedHost = null;
                if(this.validationException===undefined) this.validationException = null;
                if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                if(this.validationOptions===undefined) this.validationOptions = null;
                if(this.host===undefined) this.host = null;
                if(this.normalizedString===undefined) this.normalizedString = null;
                if(this.normalizedWildcardString===undefined) this.normalizedWildcardString = null;
                if(this.parsedHost===undefined) this.parsedHost = null;
                if(this.validationException===undefined) this.validationException = null;
                if(this.resolvedAddress===undefined) this.resolvedAddress = null;
                if(this.resolvedIsNull===undefined) this.resolvedIsNull = false;
                if(this.validationOptions===undefined) this.validationOptions = null;
                (() => {
                    if(options == null) {
                        throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                    }
                    this.validationOptions = options;
                    this.host = (host == null)?"":host.trim();
                })();
            }
        } else throw new Error('invalid overload');
    }

    cacheAddress(addr : IPAddress) {
        if(this.parsedHost == null) {
            this.parsedHost = new ParsedHost(this.host, addr.getProvider());
            this.normalizedString = addr.toNormalizedString();
        } else if(this.normalizedString == null) {
            this.normalizedString = addr.toNormalizedString();
        }
    }

    public getValidationOptions() : HostNameParameters {
        return this.validationOptions;
    }

    /**
     * 
     */
    public validate() {
        if(this.parsedHost != null) {
            return;
        }
        if(this.validationException != null) {
            throw this.validationException;
        }
        {
            if(this.parsedHost != null) {
                return;
            }
            if(this.validationException != null) {
                throw this.validationException;
            }
            try {
                this.parsedHost = this.getValidator().validateHost(this);
            } catch(e) {
                this.validationException = e;
                throw e;
            };
        };
    }

    getValidator() : HostIdentifierStringValidator {
        return Validator.VALIDATOR_$LI$();
    }

    public isValid() : boolean {
        if(this.parsedHost != null) {
            return true;
        }
        if(this.validationException != null) {
            return false;
        }
        try {
            this.validate();
            return true;
        } catch(e) {
            return false;
        };
    }

    public resolvesToSelf() : boolean {
        return this.isSelf() || (this.getAddress() != null && this.resolvedAddress.isLoopback());
    }

    public isSelf() : boolean {
        return this.isLocalHost() || this.isLoopback();
    }

    public isLocalHost() : boolean {
        return this.isValid() && /* equalsIgnoreCase */((o1, o2) => o1.toUpperCase() === (o2===null?o2:o2.toUpperCase()))(this.host, "localhost");
    }

    public isLoopback() : boolean {
        return this.isAddress() && this.asAddress().isLoopback();
    }

    public toInetAddress() : InetAddress {
        this.validate();
        return this.toAddress().toInetAddress();
    }

    public toNormalizedString$() : string {
        let result : string = this.normalizedString;
        if(result == null) {
            this.normalizedString = result = this.toNormalizedString$boolean(false);
        }
        return result;
    }

    /*private*/ toNormalizedWildcardString() : string {
        let result : string = this.normalizedWildcardString;
        if(result == null) {
            this.normalizedWildcardString = result = this.toNormalizedString$boolean(true);
        }
        return result;
    }

    /*private*/ static translateReserved(addr : IPv6Address, str : string) : any {
        if(!addr.hasZone()) {
            return str;
        }
        let index : number = str.indexOf(IPv6Address.ZONE_SEPARATOR);
        let translated : { str: string } = { str: "", toString: function() { return this.str; } };
        /* append */(sb => { sb.str = sb.str.concat((<any>str).substr(0, index)); return sb; })(translated);
        /* append */(sb => { sb.str = sb.str.concat(<any>"%25"); return sb; })(translated);
        for(let i : number = index + 1; i < str.length; i++) {
            let c : string = str.charAt(i);
            if(Validator.isReserved(c)) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'%'); return sb; })(translated);
                IPAddressSegment.toUnsignedString$int$int$java_lang_StringBuilder((c).charCodeAt(0), 16, translated);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(translated);
            }
        };
        return translated;
    }

    public toNormalizedString$boolean(wildcard : boolean) : string {
        if(this.isValid()) {
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            if(this.isAddress()) {
                let addr : IPAddress = this.asAddress();
                if(addr.isIPv6()) {
                    if(!wildcard && addr.isPrefixed()) {
                        let normalized : string = addr.toNormalizedString();
                        let index : number = normalized.indexOf(IPAddress.PREFIX_LEN_SEPARATOR);
                        let translated : any = HostName.translateReserved(addr.toIPv6(), normalized.substring(0, index));
                        /* append */(sb => { sb.str = sb.str.concat(<any>normalized.substring(index)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.IPV6_END_BRACKET); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>translated); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.IPV6_START_BRACKET); return sb; })(builder))));
                    } else {
                        let normalized : string = addr.toNormalizedWildcardString();
                        let translated : any = HostName.translateReserved(addr.toIPv6(), normalized);
                        /* append */(sb => { sb.str = sb.str.concat(<any>HostName.IPV6_END_BRACKET); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>translated); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.IPV6_START_BRACKET); return sb; })(builder)));
                    }
                } else {
                    /* append */(sb => { sb.str = sb.str.concat(<any>wildcard?addr.toNormalizedWildcardString():addr.toNormalizedString()); return sb; })(builder);
                }
            } else if(this.isAddressString()) {
                /* append */(sb => { sb.str = sb.str.concat(<any>this.asAddressString().toNormalizedString()); return sb; })(builder);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>this.parsedHost.getHost()); return sb; })(builder);
                let networkPrefixLength : number = this.parsedHost.getEquivalentPrefixLength();
                if(networkPrefixLength != null) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>networkPrefixLength); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })(builder));
                } else {
                    let mask : IPAddress = this.parsedHost.getMask();
                    if(mask != null) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>mask.toNormalizedString()); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })(builder));
                    }
                }
            }
            let port : number = this.parsedHost.getPort();
            if(port != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>port); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.PORT_SEPARATOR); return sb; })(builder));
            } else {
                let service : string = this.parsedHost.getService();
                if(service != null) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>service); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.PORT_SEPARATOR); return sb; })(builder));
                }
            }
            return /* toString */builder.str;
        }
        return this.host;
    }

    public toNormalizedString(wildcard? : any) : any {
        if(((typeof wildcard === 'boolean') || wildcard === null)) {
            return <any>this.toNormalizedString$boolean(wildcard);
        } else if(wildcard === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        return (o != null && o instanceof <any>HostName) && this.matches(<HostName>o);
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.toNormalizedWildcardString()));
    }

    public getNormalizedLabels() : string[] {
        if(this.isValid()) {
            return this.parsedHost.getNormalizedLabels();
        }
        if(this.host.length === 0) {
            return [];
        }
        return [this.host];
    }

    /**
     * Returns the host string normalized but without port, service, prefix or mask.
     * 
     * If an address, returns the address string normalized, but without port, service, prefix, mask, or brackets for IPv6.
     * 
     * To get a normalized string encompassing all details, use toNormalizedString()
     * 
     * If not a valid host, returns null
     * 
     * @return
     * @return {string}
     */
    public getHost() : string {
        if(this.isValid()) {
            return this.parsedHost.getHost();
        }
        return null;
    }

    public matches(host : HostName) : boolean {
        if(this === host) {
            return true;
        }
        if(this.isValid()) {
            if(host.isValid()) {
                if(this.isAddressString()) {
                    return host.isAddressString() && this.asAddressString().equals(host.asAddressString()) && Objects.equals(this.getPort(), host.getPort()) && Objects.equals(this.getService(), host.getService());
                }
                if(host.isAddressString()) {
                    return false;
                }
                let thisHost : string = this.parsedHost.getHost();
                let otherHost : string = host.parsedHost.getHost();
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(thisHost,otherHost))) {
                    return false;
                }
                return Objects.equals(this.parsedHost.getEquivalentPrefixLength(), host.parsedHost.getEquivalentPrefixLength()) && Objects.equals(this.parsedHost.getMask(), host.parsedHost.getMask()) && Objects.equals(this.parsedHost.getPort(), host.parsedHost.getPort()) && Objects.equals(this.parsedHost.getService(), host.parsedHost.getService());
            }
            return false;
        }
        return !host.isValid() && /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(this.toString(),host.toString()));
    }

    /**
     * 
     * @param {HostName} other
     * @return {number}
     */
    public compareTo(other : HostName) : number {
        if(this.isValid()) {
            if(other.isValid()) {
                if(this.isAddressString()) {
                    if(other.isAddressString()) {
                        let result : number = this.asAddressString().compareTo(other.asAddressString());
                        if(result !== 0) {
                            return result;
                        }
                    } else {
                        return -1;
                    }
                } else if(other.isAddressString()) {
                    return 1;
                } else {
                    let normalizedLabels : string[] = this.parsedHost.getNormalizedLabels();
                    let otherNormalizedLabels : string[] = other.parsedHost.getNormalizedLabels();
                    let oneLen : number = normalizedLabels.length;
                    let twoLen : number = otherNormalizedLabels.length;
                    for(let i : number = 1, minLen : number = Math.min(oneLen, twoLen); i <= minLen; i++) {
                        let one : string = normalizedLabels[oneLen - i];
                        let two : string = otherNormalizedLabels[twoLen - i];
                        let result : number = /* compareTo */one.localeCompare(two);
                        if(result !== 0) {
                            return result;
                        }
                    };
                    if(oneLen !== twoLen) {
                        return oneLen - twoLen;
                    }
                    let networkPrefixLength : number = this.parsedHost.getEquivalentPrefixLength();
                    let otherPrefixLength : number = other.parsedHost.getEquivalentPrefixLength();
                    if(networkPrefixLength != null) {
                        if(otherPrefixLength != null) {
                            if(/* intValue */(networkPrefixLength|0) !== /* intValue */(otherPrefixLength|0)) {
                                return otherPrefixLength - networkPrefixLength;
                            }
                        } else {
                            return 1;
                        }
                    } else {
                        if(otherPrefixLength != null) {
                            return -1;
                        }
                        let mask : IPAddress = this.parsedHost.getMask();
                        let otherMask : IPAddress = other.parsedHost.getMask();
                        if(mask != null) {
                            if(otherMask != null) {
                                let ret : number = mask.compareTo(otherMask);
                                if(ret !== 0) {
                                    return ret;
                                }
                            } else {
                                return 1;
                            }
                        } else {
                            if(otherMask != null) {
                                return -1;
                            }
                        }
                    }
                }
                let portOne : number = this.parsedHost.getPort();
                let portTwo : number = other.parsedHost.getPort();
                if(portOne != null) {
                    if(portTwo != null) {
                        let ret : number = portOne - portTwo;
                        if(ret !== 0) {
                            return ret;
                        }
                    } else {
                        return 1;
                    }
                } else if(portTwo != null) {
                    return -1;
                }
                let serviceOne : string = this.parsedHost.getService();
                let serviceTwo : string = other.parsedHost.getService();
                if(serviceOne != null) {
                    if(serviceTwo != null) {
                        let ret : number = /* compareTo */serviceOne.localeCompare(serviceTwo);
                        if(ret !== 0) {
                            return ret;
                        }
                    } else {
                        return 1;
                    }
                } else if(serviceTwo != null) {
                    return -1;
                }
                return 0;
            } else {
                return 1;
            }
        } else if(other.isValid()) {
            return -1;
        }
        return /* compareTo */this.toString().localeCompare(other.toString());
    }

    public isAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : boolean {
        return this.isValid() && this.parsedHost.isAddressString() && this.parsedHost.asAddress$inet_ipaddr_IPAddress_IPVersion(version) != null;
    }

    public isAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.isAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.isAddress$();
        } else throw new Error('invalid overload');
    }

    public isAddress$() : boolean {
        return this.isAddressString() && this.parsedHost.asAddress() != null;
    }

    public isAddressString() : boolean {
        return this.isValid() && this.parsedHost.isAddressString();
    }

    /**
     * @return {boolean} whether the address represents the set all all valid IP addresses (as opposed to an empty string, a specific address, a prefix length, or an invalid format).
     */
    public isAllAddresses() : boolean {
        return this.isAddressString() && this.parsedHost.getAddressProvider().isAllAddresses();
    }

    /**
     * @return {boolean} whether the address represents a valid IP address network prefix (as opposed to an empty string, an address with or without a prefix, or an invalid format).
     */
    public isPrefixOnly() : boolean {
        return this.isAddressString() && this.parsedHost.getAddressProvider().isPrefixOnly();
    }

    /**
     * Returns true if the address is empty (zero-length).
     * @return
     * @return {boolean}
     */
    public isEmpty() : boolean {
        return this.isAddressString() && this.parsedHost.getAddressProvider().isEmpty();
    }

    /**
     * If a port was supplied, returns the port, otherwise returns null
     * 
     * @return
     * @return {number}
     */
    public getPort() : number {
        return this.isValid()?this.parsedHost.getPort():null;
    }

    /**
     * If a service name was supplied, returns the service name, otherwise returns null
     * 
     * @return
     * @return {string}
     */
    public getService() : string {
        return this.isValid()?this.parsedHost.getService():null;
    }

    /**
     * Returns the exception thrown for invalid ipv6 literal or invalid reverse DNS hosts.
     * 
     * This method will return non-null when this host is valid, so no HostException is thrown,
     * but a secondary address within the host is not valid.
     * 
     * @return
     * @return {AddressStringException}
     */
    public getAddressStringException() : AddressStringException {
        if(this.isValid()) {
            return this.parsedHost.getAddressStringException();
        }
        return null;
    }

    public isUNCIPv6Literal() : boolean {
        return this.isValid() && this.parsedHost.isUNCIPv6Literal();
    }

    public isReverseDNS() : boolean {
        return this.isValid() && this.parsedHost.isReverseDNS();
    }

    /**
     * If this represents an ip address or represents a valid IPAddressString, returns the corresponding address string.
     * Otherwise, returns null.  Call toResolvedAddress or resolve to get the resolved address.
     * @return
     * @return {IPAddressString}
     */
    public asAddressString() : IPAddressString {
        if(this.isAddressString()) {
            return this.parsedHost.asGenericAddressString();
        }
        return null;
    }

    public asAddress$() : IPAddress {
        if(this.isAddress()) {
            return this.parsedHost.asAddress();
        }
        return null;
    }

    public asAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
        if(this.isAddress$inet_ipaddr_IPAddress_IPVersion(version)) {
            return this.parsedHost.asAddress$inet_ipaddr_IPAddress_IPVersion(version);
        }
        return null;
    }

    /**
     * If this represents an ip address, returns that address.
     * Otherwise, returns null.  Call {@link #toAddress()} or {@link #getAddress()} to get the resolved address.
     * 
     * @return
     * @param {IPAddress.IPVersion} version
     * @return {IPAddress}
     */
    public asAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.asAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.asAddress$();
        } else throw new Error('invalid overload');
    }

    /**
     * If a prefix was supplied, either as part of an address or as part of a domain (in which case the prefix applies to any resolved address),
     * then returns that prefix length.  Otherwise, returns null.
     * @return {number}
     */
    public getNetworkPrefixLength() : number {
        if(this.isAddress()) {
            return this.parsedHost.asAddress().getNetworkPrefixLength();
        } else if(this.isAddressString()) {
            return this.parsedHost.asGenericAddressString().getNetworkPrefixLength();
        }
        return this.isValid()?this.parsedHost.getNetworkPrefixLength():null;
    }

    /**
     * If this represents an ip address, returns that address.
     * If this represents a host, returns the resolved ip address of that host.
     * Otherwise, returns null, but only for strings that are considered valid address strings but cannot be converted to address objects.
     * 
     * This method will throw exceptions for invalid formats and failures to resolve the address.  The equivalent method {@link #getAddress()} will simply return null rather than throw those exceptions.
     * 
     * If you wish to get the represented address and avoid DNS resolution, use {@link #asAddress()} or {@link #asAddressString()}
     * 
     * @return
     * @return {IPAddress}
     */
    public toAddress() : IPAddress {
        let addr : IPAddress = this.resolvedAddress;
        if(addr == null && !this.resolvedIsNull) {
            this.validate();
            {
                addr = this.resolvedAddress;
                if(addr == null && !this.resolvedIsNull) {
                    if(this.parsedHost.isAddressString()) {
                        addr = this.parsedHost.asAddress();
                        this.resolvedIsNull = (addr == null);
                    } else {
                        let strHost : string = this.parsedHost.getHost();
                        if(strHost.length === 0 && !this.validationOptions.emptyIsLoopback) {
                            addr = null;
                            this.resolvedIsNull = true;
                        } else {
                            let inetAddress : InetAddress = InetAddress.getByName(strHost);
                            let bytes : number[] = inetAddress.getAddress();
                            let networkPrefixLength : number = this.parsedHost.getNetworkPrefixLength();
                            if(networkPrefixLength == null) {
                                let mask : IPAddress = this.parsedHost.getMask();
                                if(mask != null) {
                                    let maskBytes : number[] = mask.getBytes();
                                    if(maskBytes.length !== bytes.length) {
                                        throw new HostNameException(this.host, "ipaddress.error.ipMismatch");
                                    }
                                    for(let i : number = 0; i < bytes.length; i++) {
                                        bytes[i] &= maskBytes[i];
                                    };
                                    networkPrefixLength = mask.getBlockMaskPrefixLength(true);
                                }
                            }
                            let addressParams : IPAddressStringParameters = this.validationOptions.addressOptions;
                            if(bytes.length === IPv6Address.BYTE_COUNT) {
                                let creator : IPv6AddressNetwork.IPv6AddressCreator = addressParams.getIPv6Parameters().getNetwork().getAddressCreator();
                                addr = creator.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence$inet_ipaddr_HostName(bytes, networkPrefixLength, null, this);
                            } else {
                                let creator : IPv4AddressNetwork.IPv4AddressCreator = addressParams.getIPv4Parameters().getNetwork().getAddressCreator();
                                addr = creator.createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes, networkPrefixLength, this);
                            }
                        }
                    }
                    this.resolvedAddress = addr;
                }
            };
        }
        return addr;
    }

    /**
     * If this represents an ip address, returns that address.
     * If this represents a host, returns the resolved ip address of that host.
     * Otherwise, returns null.
     * 
     * If you wish to get the represented address and avoid DNS resolution, use {@link #asAddress()} or {@link #asAddressString()}
     * 
     * @return
     * @return {IPAddress}
     */
    public getAddress() : IPAddress {
        try {
            return this.toAddress();
        } catch(e) {
        };
        return null;
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.host;
    }
}
HostName["__class"] = "inet.ipaddr.HostName";
HostName["__interfaces"] = ["java.lang.Comparable","inet.ipaddr.HostIdentifierString","java.io.Serializable"];





HostName.DEFAULT_VALIDATION_OPTIONS_$LI$();
