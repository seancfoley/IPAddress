/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressNetwork } from '../AddressNetwork';
import { AddressSection } from '../AddressSection';
import { AddressSegment } from '../AddressSegment';
import { ParsedAddressCreator } from './validate/ParsedAddressCreator';
import { HostIdentifierString } from '../HostIdentifierString';

/**
 * Has methods for creating addresses, segments and sections that are available to the parser.
 * 
 * @author sfoley
 * 
 * @param <T> the address type
 * @param <R> the section type
 * @param <E> the embedded section type (ie IPv4 in a mixed IPv6/IPv4)
 * @param <S> the segment type
 * @class
 * @extends ParsedAddressCreator
 */
export abstract class AddressCreator<T extends Address, R extends AddressSection, E extends AddressSection, S extends AddressSegment> extends ParsedAddressCreator<T, R, E, S> implements AddressNetwork.AddressSegmentCreator<S> {
    static __inet_ipaddr_format_AddressCreator_serialVersionUID : number = 4;

    public abstract clearCaches();

    public abstract getNetwork() : AddressNetwork<S>;

    public createAddressInternal(segments? : any, zone? : any, from? : any, prefix? : any) : any {
        if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && ((typeof prefix === 'number') || prefix === null)) {
            super.createAddressInternal(segments, zone, from, prefix);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof from === 'number') || from === null) && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, zone, from);
        } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(segments, zone, from);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof zone === 'number') || zone === null) && ((typeof from === 'boolean') || from === null) && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, zone, from);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof zone === 'number') || zone === null) && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, zone);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(typeof segments[0] === 'number'))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(segments, zone);
        } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(segments, zone);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && zone === undefined && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(segments);
        } else throw new Error('invalid overload');
    }

    createAddressInternal$inet_ipaddr_AddressSegment_A(segments : S[]) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments : S[], prefix : number) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments : S[], prefix : number, singleOnly : boolean) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes : number[], segmentCount : number, prefix : number, singleOnly : boolean) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
            return <any>this.createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes, segmentCount, prefix, singleOnly);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
        } else throw new Error('invalid overload');
    }

    createSectionInternal$inet_ipaddr_AddressSegment_A(segments : S[]) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {Array} segments
     * @param {number} prefix
     * @param {boolean} singleOnly
     * @return {IPv4AddressSection}
     */
    public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
        if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
            return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
            return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
        } else throw new Error('invalid overload');
    }

    createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments : S[], prefix : number, singleOnly : boolean) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(segments : S[], startIndex : number, extended : boolean) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createAddress(lowerValueProvider? : any, upperValueProvider? : any, prefix? : any, zone? : any) : any {
        if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
            return <any>this.createAddress$inet_ipaddr_AddressSection(lowerValueProvider);
        } else throw new Error('invalid overload');
    }

    public createAddress$inet_ipaddr_AddressSection(section : R) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public abstract createSegment(value?: any): any;
    public abstract createSegment(value?: any, segmentPrefixLength?: any): any;
    public abstract createSegment(lower?: any, upper?: any, segmentPrefixLength?: any): any;
    public abstract createSegmentArray(length?: any): any;
    constructor() {
        super();
    }
}
AddressCreator["__class"] = "inet.ipaddr.format.AddressCreator";
AddressCreator["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];




