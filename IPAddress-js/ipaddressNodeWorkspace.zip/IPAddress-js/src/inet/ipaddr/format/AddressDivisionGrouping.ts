/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressNetwork } from '../AddressNetwork';
import { AddressSection } from '../AddressSection';
import { AddressSegment } from '../AddressSegment';
import { AddressSegmentSeries } from '../AddressSegmentSeries';
import { AddressValueException } from '../AddressValueException';
import { HostIdentifierException } from '../HostIdentifierException';
import { IPAddress } from '../IPAddress';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressSection } from '../IPAddressSection';
import { IPAddressSegment } from '../IPAddressSegment';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { NetworkMismatchException } from '../NetworkMismatchException';
import { PrefixLenException } from '../PrefixLenException';
import { AddressDivisionWriter } from './util/AddressDivisionWriter';
import { AddressSegmentParams } from './util/AddressSegmentParams';
import { AddressDivisionSeries } from './AddressDivisionSeries';
import { AddressDivision } from './AddressDivision';
import { AddressComparator } from '../AddressComparator';
import { AddressCreator } from './AddressCreator';
import { AddressDivisionBase } from './AddressDivisionBase';
import { AddressStringDivisionSeries } from './AddressStringDivisionSeries';
import { AddressStringDivision } from './AddressStringDivision';

/**
 * AddressDivisionGrouping objects consist of a series of AddressDivision objects, each division containing one or more segments.
 * <p>
 * AddressDivisionGrouping objects are immutable.  This also makes them thread-safe.
 * 
 * @author sfoley
 * @param {Array} divisions
 * @param {boolean} checkDivisions
 * @class
 */
export class AddressDivisionGrouping implements AddressDivisionSeries {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!AddressDivisionGrouping.__static_initialized) { AddressDivisionGrouping.__static_initialized = true; AddressDivisionGrouping.__static_initializer_0(); } }

    static serialVersionUID : number = 4;

    static LONG_MAX : BigInteger; public static LONG_MAX_$LI$() : BigInteger { AddressDivisionGrouping.__static_initialize(); if(AddressDivisionGrouping.LONG_MAX == null) AddressDivisionGrouping.LONG_MAX = BigInteger.valueOf(Number.MAX_VALUE); return AddressDivisionGrouping.LONG_MAX; };

    static NO_PREFIX_LENGTH : number = -1;

    static bundle : ResourceBundle; public static bundle_$LI$() : ResourceBundle { AddressDivisionGrouping.__static_initialize(); return AddressDivisionGrouping.bundle; };

    static __static_initializer_0() {
        let propertyFileName : string = "IPAddressResources";
        let name : string = HostIdentifierException.getPackage().getName() + '.' + propertyFileName;
        try {
            AddressDivisionGrouping.bundle = ResourceBundle.getBundle(name);
        } catch(e) {
            console.error("bundle " + name + " is missing");
        };
    }

    valueCache : AddressDivisionGrouping.ValueCache;

    /*private*/ divisions : AddressDivision[];

    cachedPrefixLength : number;

    /*private*/ __isMultiple : boolean;

    /*private*/ cachedCount : BigInteger;

    __hashCode : number;

    static getMessage(key : string) : string {
        if(AddressDivisionGrouping.bundle_$LI$() != null) {
            try {
                return AddressDivisionGrouping.bundle_$LI$().getString(key);
            } catch(e1) {
            };
        }
        return key;
    }

    public constructor(divisions? : any, checkDivisions? : any) {
        if(((divisions != null && divisions instanceof <any>Array && (divisions.length==0 || divisions[0] == null ||(divisions[0] != null && divisions[0] instanceof <any>AddressDivision))) || divisions === null) && ((typeof checkDivisions === 'boolean') || checkDivisions === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.divisions===undefined) this.divisions = null;
            if(this.cachedPrefixLength===undefined) this.cachedPrefixLength = null;
            if(this.__isMultiple===undefined) this.__isMultiple = null;
            if(this.cachedCount===undefined) this.cachedCount = null;
            if(this.__hashCode===undefined) this.__hashCode = 0;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.divisions===undefined) this.divisions = null;
            if(this.cachedPrefixLength===undefined) this.cachedPrefixLength = null;
            if(this.__isMultiple===undefined) this.__isMultiple = null;
            if(this.cachedCount===undefined) this.cachedCount = null;
            if(this.__hashCode===undefined) this.__hashCode = 0;
            (() => {
                this.divisions = divisions;
                if(checkDivisions) {
                    for(let i : number = 0; i < divisions.length; i++) {
                        if(divisions[i] == null) {
                            throw Object.defineProperty(new Error(AddressDivisionGrouping.getMessage("ipaddress.error.null.segment")), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                        }
                    };
                }
            })();
        } else if(((divisions != null && divisions instanceof <any>Array && (divisions.length==0 || divisions[0] == null ||(divisions[0] != null && divisions[0] instanceof <any>AddressDivision))) || divisions === null) && checkDivisions === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let checkDivisions : any = true;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.divisions===undefined) this.divisions = null;
                if(this.cachedPrefixLength===undefined) this.cachedPrefixLength = null;
                if(this.__isMultiple===undefined) this.__isMultiple = null;
                if(this.cachedCount===undefined) this.cachedCount = null;
                if(this.__hashCode===undefined) this.__hashCode = 0;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.divisions===undefined) this.divisions = null;
                if(this.cachedPrefixLength===undefined) this.cachedPrefixLength = null;
                if(this.__isMultiple===undefined) this.__isMultiple = null;
                if(this.cachedCount===undefined) this.cachedCount = null;
                if(this.__hashCode===undefined) this.__hashCode = 0;
                (() => {
                    this.divisions = divisions;
                    if(checkDivisions) {
                        for(let i : number = 0; i < divisions.length; i++) {
                            if(divisions[i] == null) {
                                throw Object.defineProperty(new Error(AddressDivisionGrouping.getMessage("ipaddress.error.null.segment")), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                            }
                        };
                    }
                })();
            }
        } else throw new Error('invalid overload');
    }

    public initCachedValues(prefixLen? : any, network? : any, cachedNetworkPrefix? : any, cachedMinPrefix? : any, cachedEquivalentPrefix? : any, cachedCount? : any, zeroSegments? : any, zeroRanges? : any) : any {
        if(((typeof prefixLen === 'number') || prefixLen === null) && ((network != null && network instanceof <any>BigInteger) || network === null) && cachedNetworkPrefix === undefined && cachedMinPrefix === undefined && cachedEquivalentPrefix === undefined && cachedCount === undefined && zeroSegments === undefined && zeroRanges === undefined) {
            return <any>this.initCachedValues$java_lang_Integer$java_math_BigInteger(prefixLen, network);
        } else throw new Error('invalid overload');
    }

    initCachedValues$java_lang_Integer$java_math_BigInteger(cachedNetworkPrefixLength : number, cachedCount : BigInteger) {
        this.cachedPrefixLength = cachedNetworkPrefixLength == null?AddressDivisionGrouping.NO_PREFIX_LENGTH:cachedNetworkPrefixLength;
        this.cachedCount = cachedCount;
    }

    /**
     * 
     * @param {number} index
     * @return {AddressDivision}
     */
    public getDivision(index : number) : AddressDivision {
        return this.getDivisionsInternal()[index];
    }

    /**
     * 
     * @return {number}
     */
    public getDivisionCount() : number {
        return this.getDivisionsInternal().length;
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        let count : number = this.getDivisionCount();
        let bitCount : number = 0;
        for(let i : number = 0; i < count; i++) {
            bitCount += this.getDivision(i).getBitCount();
        };
        return bitCount;
    }

    public getBytes(provided? : any, startIndex? : any, cached? : any) : any {
        if(((provided != null && provided instanceof <any>Array && (provided.length==0 || provided[0] == null ||(typeof provided[0] === 'number'))) || provided === null) && ((typeof startIndex === 'number') || startIndex === null) && cached === undefined) {
            return <any>this.getBytes$byte_A$int(provided, startIndex);
        } else if(((provided != null && provided instanceof <any>Array && (provided.length==0 || provided[0] == null ||(typeof provided[0] === 'number'))) || provided === null) && startIndex === undefined && cached === undefined) {
            return <any>this.getBytes$byte_A(provided);
        } else if(provided === undefined && startIndex === undefined && cached === undefined) {
            return <any>this.getBytes$();
        } else throw new Error('invalid overload');
    }

    public getBytes$() : number[] {
        return /* clone */this.getBytesInternal().slice(0);
    }

    getBytesInternal() : number[] {
        let cached : number[];
        if(this.hasNoValueCache() || (cached = this.valueCache.lowerBytes) == null) {
            this.valueCache.lowerBytes = cached = this.getBytesImpl(true);
        }
        return cached;
    }

    public getBytes$byte_A$int(bytes : number[], index : number) : number[] {
        return AddressDivisionGrouping.getBytesCopy(bytes, index, this.getBytesInternal(), this.getBitCount());
    }

    public getBytes$byte_A(bytes : number[]) : number[] {
        return this.getBytes$byte_A$int(bytes, 0);
    }

    static getBytesCopy(bytes : number[], startIndex : number, cached : number[], bitCount : number) : number[] {
        let byteCount : number = (bitCount + 7) >> 3;
        if(bytes == null || bytes.length < byteCount + startIndex) {
            if(startIndex > 0) {
                let bytes2 : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(byteCount + startIndex);
                if(bytes != null) {
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(bytes, 0, bytes2, 0, Math.min(startIndex, bytes.length));
                }
                /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(cached, 0, bytes2, startIndex, cached.length);
                return bytes2;
            }
            return /* clone */cached.slice(0);
        }
        /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(cached, 0, bytes, startIndex, byteCount);
        return bytes;
    }

    public getUpperBytes$() : number[] {
        return /* clone */this.getUpperBytesInternal().slice(0);
    }

    /**
     * Gets the bytes for the highest address in the range represented by this address.
     * 
     * @return
     * @return {Array}
     */
    getUpperBytesInternal() : number[] {
        let cached : number[];
        if(this.hasNoValueCache()) {
            let cache : AddressDivisionGrouping.ValueCache = this.valueCache;
            cache.upperBytes = cached = this.getBytesImpl(false);
            if(!this.isMultiple()) {
                cache.lowerBytes = cached;
            }
        } else {
            let cache : AddressDivisionGrouping.ValueCache = this.valueCache;
            if((cached = cache.upperBytes) == null) {
                if(!this.isMultiple()) {
                    if((cached = cache.lowerBytes) != null) {
                        cache.upperBytes = cached;
                    } else {
                        cache.lowerBytes = cache.upperBytes = cached = this.getBytesImpl(false);
                    }
                } else {
                    cache.upperBytes = cached = this.getBytesImpl(false);
                }
            }
        }
        return cached;
    }

    public getUpperBytes$byte_A$int(bytes : number[], index : number) : number[] {
        return AddressDivisionGrouping.getBytesCopy(bytes, index, this.getUpperBytesInternal(), this.getBitCount());
    }

    /**
     * Similar to {@link #getBytes(byte[], int)}, but for obtaining the upper value of the range.
     * If this division represents a single value, equivalent to {@link #getBytes(byte[], int)}
     * @param {Array} bytes
     * @param {number} index
     * @return {Array}
     */
    public getUpperBytes(bytes? : any, index? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof index === 'number') || index === null)) {
            return <any>this.getUpperBytes$byte_A$int(bytes, index);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && index === undefined) {
            return <any>this.getUpperBytes$byte_A(bytes);
        } else if(bytes === undefined && index === undefined) {
            return <any>this.getUpperBytes$();
        } else throw new Error('invalid overload');
    }

    public getUpperBytes$byte_A(bytes : number[]) : number[] {
        return this.getBytes$byte_A$int(bytes, 0);
    }

    getBytesImpl(low : boolean) : number[] {
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })((this.getBitCount() + 7) >> 3);
        let byteCount : number = bytes.length;
        let divCount : number = this.getDivisionCount();
        for(let k : number = divCount - 1, byteIndex : number = byteCount - 1, bitIndex : number = 8; k >= 0; k--) {
            let div : AddressDivision = this.getDivision(k);
            let segmentValue : number = low?div.getLowerValue():div.getUpperValue();
            let divBits : number = div.getBitCount();
            while((divBits > 0)) {
                bytes[byteIndex] |= segmentValue << (8 - bitIndex);
                segmentValue >>= bitIndex;
                if(divBits < bitIndex) {
                    bitIndex -= divBits;
                    break;
                } else {
                    divBits -= bitIndex;
                    bitIndex = 8;
                    byteIndex--;
                }
            };
        };
        return bytes;
    }

    setBytes(bytes : number[]) {
        if(this.valueCache == null) {
            this.valueCache = new AddressDivisionGrouping.ValueCache();
        }
        this.valueCache.lowerBytes = bytes;
    }

    setUpperBytes(bytes : number[]) {
        if(this.valueCache == null) {
            this.valueCache = new AddressDivisionGrouping.ValueCache();
        }
        this.valueCache.upperBytes = bytes;
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getValue() : BigInteger {
        let cached : BigInteger;
        if(this.hasNoValueCache() || (cached = this.valueCache.value) == null) {
            this.valueCache.value = cached = new BigInteger(1, this.getBytesInternal());
        }
        return cached;
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getUpperValue() : BigInteger {
        let cached : BigInteger;
        if(this.hasNoValueCache()) {
            let cache : AddressDivisionGrouping.ValueCache = this.valueCache;
            cache.upperValue = cached = new BigInteger(1, this.getUpperBytesInternal());
            if(!this.isMultiple()) {
                cache.value = cached;
            }
        } else {
            let cache : AddressDivisionGrouping.ValueCache = this.valueCache;
            if((cached = cache.upperValue) == null) {
                if(!this.isMultiple()) {
                    if((cached = cache.value) != null) {
                        cache.upperValue = cached;
                    } else {
                        cache.value = cache.upperValue = cached = new BigInteger(1, this.getUpperBytesInternal());
                    }
                } else {
                    cache.upperValue = cached = new BigInteger(1, this.getUpperBytesInternal());
                }
            }
        }
        return cached;
    }

    hasNoValueCache() : boolean {
        if(this.valueCache == null) {
            {
                if(this.valueCache == null) {
                    this.valueCache = new AddressDivisionGrouping.ValueCache();
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 
     * @return {boolean}
     */
    public isPrefixed() : boolean {
        return this.getPrefixLength() != null;
    }

    /**
     * 
     * @return {number}
     */
    public getPrefixLength() : number {
        return this.cachedPrefixLength;
    }

    /**
     * Returns the smallest prefix length possible such that this address division grouping includes the block of addresses for that prefix.
     * 
     * @return {number} the prefix length
     */
    public getMinPrefixLengthForBlock() : number {
        let count : number = this.getDivisionCount();
        let totalPrefix : number = this.getBitCount();
        for(let i : number = count - 1; i >= 0; i--) {
            let div : AddressDivision = this.getDivision(i);
            let segBitCount : number = div.getBitCount();
            let segPrefix : number = div.getMinPrefixLengthForBlock();
            if(segPrefix === segBitCount) {
                break;
            } else {
                totalPrefix -= segBitCount;
                if(segPrefix !== 0) {
                    totalPrefix += segPrefix;
                    break;
                }
            }
        };
        return totalPrefix;
    }

    /**
     * Returns a prefix length for which the range of this segment grouping matches the the block of addresses for that prefix.
     * 
     * If no such prefix exists, returns null
     * 
     * If this segment grouping represents a single value, returns the bit length
     * 
     * @return {number} the prefix length or null
     */
    public getPrefixLengthForSingleBlock() : number {
        let count : number = this.getDivisionCount();
        let totalPrefix : number = 0;
        for(let i : number = 0; i < count; i++) {
            let div : AddressDivision = this.getDivision(i);
            let divPrefix : number = div.getMinPrefixLengthForBlock();
            if(!div.matchesWithMask$long$long(div.getLowerValue(), ~0 << (div.getBitCount() - divPrefix))) {
                return null;
            }
            if(divPrefix < div.getBitCount()) {
                for(i++; i < count; i++) {
                    let laterDiv : AddressDivision = this.getDivision(i);
                    if(!laterDiv.isFullRange()) {
                        return null;
                    }
                };
                return totalPrefix + divPrefix;
            }
            totalPrefix += divPrefix;
        };
        return totalPrefix;
    }

    /**
     * gets the count of addresses that this address may represent
     * 
     * If this address division grouping is not a subnet block of multiple addresses or has no range of values, then there is only one such address.
     * 
     * @return
     * @return {BigInteger}
     */
    public getCount() : BigInteger {
        let cached : BigInteger = this.cachedCount;
        if(cached == null) {
            this.cachedCount = cached = this.getCountImpl();
        }
        return cached;
    }

    public getCountImpl(excludeZeroHosts? : any) : any {
        if(excludeZeroHosts === undefined) {
            return <any>this.getCountImpl$();
        } else throw new Error('invalid overload');
    }

    getCountImpl$() : BigInteger {
        let result : BigInteger = BigInteger.ONE;
        let count : number = this.getDivisionCount();
        if(count > 0) {
            if(this.isMultiple()) {
                for(let i : number = 0; i < count; i++) {
                    let segCount : number = this.getDivision(i).getDivisionValueCount();
                    result = result.multiply(BigInteger.valueOf(segCount));
                };
            }
        }
        return result;
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getPrefixCount() : BigInteger {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength == null || prefixLength >= this.getBitCount() || !this.isMultiple()) {
            return this.getCount();
        }
        let result : BigInteger = BigInteger.ONE;
        let divisionCount : number = this.getDivisionCount();
        let divPrefixLength : number = prefixLength;
        for(let i : number = 0; i < divisionCount; i++) {
            let division : AddressDivision = this.getDivision(i);
            let divBitCount : number = division.getBitCount();
            let segCount : number = (divPrefixLength < divBitCount)?division.getDivisionPrefixCount(divPrefixLength):division.getDivisionValueCount();
            result = result.multiply(BigInteger.valueOf(segCount));
            if(divPrefixLength <= divBitCount) {
                break;
            }
            divPrefixLength -= divBitCount;
        };
        return result;
    }

    /**
     * 
     * @param {*} other
     * @return {number}
     */
    public isMore(other : AddressDivisionSeries) : number {
        if(!this.isMultiple()) {
            return other.isMultiple()?-1:0;
        }
        if(!other.isMultiple()) {
            return 1;
        }
        return this.getCount().compareTo(other.getCount());
    }

    /**
     * @return {boolean} whether this address represents more than one address.
     * Such addresses include CIDR/IP addresses (eg 1.2.3.4/11) or wildcard addresses (eg 1.2.*.4) or range addresses (eg 1.2.3-4.5)
     */
    public isMultiple() : boolean {
        let result : boolean = this.__isMultiple;
        if(result == null) {
            for(let i : number = this.getDivisionCount() - 1; i >= 0; i--) {
                let seg : AddressDivision = this.getDivision(i);
                if(seg.isMultiple()) {
                    return this.__isMultiple = true;
                }
            };
            return this.__isMultiple = false;
        }
        return result;
    }

    /**
     * 
     * @return {boolean}
     */
    public isSinglePrefixBlock() : boolean {
        return this.isPrefixed() && this.containsSinglePrefixBlock(this.getPrefixLength());
    }

    /**
     * 
     * @return {boolean}
     */
    public isPrefixBlock() : boolean {
        return this.isPrefixed() && this.containsPrefixBlock(this.getPrefixLength());
    }

    checkSubnet(prefixLength : number) {
        if(prefixLength < 0 || prefixLength > this.getBitCount()) {
            throw new PrefixLenException(this, prefixLength);
        }
    }

    /**
     * Returns whether the values of this division grouping contain the prefix block for the given prefix length
     * 
     * @param {number} prefixLength
     * @return
     * @return {boolean}
     */
    public containsPrefixBlock(prefixLength : number) : boolean {
        this.checkSubnet(prefixLength);
        let divisionCount : number = this.getDivisionCount();
        let prevBitCount : number = 0;
        for(let i : number = 0; i < divisionCount; i++) {
            let division : AddressDivision = this.getDivision(i);
            let bitCount : number = division.getBitCount();
            let totalBitCount : number = bitCount + prevBitCount;
            if(prefixLength < totalBitCount) {
                let divPrefixLen : number = Math.max(0, prefixLength - prevBitCount);
                if(!division.isPrefixBlock$long$long$int(division.getLowerValue(), division.getUpperValue(), divPrefixLen)) {
                    return false;
                }
                for(++i; i < divisionCount; i++) {
                    division = this.getDivision(i);
                    if(!division.isFullRange()) {
                        return false;
                    }
                };
                return true;
            }
            prevBitCount = totalBitCount;
        };
        return true;
    }

    /**
     * Returns whether the values of this division grouping match the prefix block for the given prefix length
     * @param {number} prefixLength
     * @return
     * @return {boolean}
     */
    public containsSinglePrefixBlock(prefixLength : number) : boolean {
        this.checkSubnet(prefixLength);
        let divisionCount : number = this.getDivisionCount();
        let prevBitCount : number = 0;
        for(let i : number = 0; i < divisionCount; i++) {
            let division : AddressDivision = this.getDivision(i);
            let bitCount : number = division.getBitCount();
            let totalBitCount : number = bitCount + prevBitCount;
            if(prefixLength >= totalBitCount) {
                if(division.isMultiple()) {
                    return false;
                }
            } else {
                let divPrefixLen : number = Math.max(0, prefixLength - prevBitCount);
                if(!division.isSinglePrefixBlock$long$long$int(division.getLowerValue(), division.getUpperValue(), divPrefixLen)) {
                    return false;
                }
                for(++i; i < divisionCount; i++) {
                    division = this.getDivision(i);
                    if(!division.isFullRange()) {
                        return false;
                    }
                };
                return true;
            }
            prevBitCount = totalBitCount;
        };
        return true;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let res : number = this.__hashCode;
        if(res === 0) {
            let fullResult : number = 1;
            let count : number = this.getDivisionCount();
            for(let i : number = 0; i < count; i++) {
                let combo : AddressDivision = this.getDivision(i);
                let value : number = combo.getLowerValue();
                let shifted : number = value >>> 32;
                let adjusted : number = (<number>((shifted === 0)?value:(value ^ shifted))|0);
                fullResult = 31 * fullResult + adjusted;
                let upperValue : number = combo.getUpperValue();
                if(upperValue !== value) {
                    shifted = upperValue >>> 32;
                    adjusted = (<number>((shifted === 0)?upperValue:(upperValue ^ shifted))|0);
                    fullResult = 31 * fullResult + adjusted;
                }
            };
            this.__hashCode = res = fullResult;
        }
        return res;
    }

    isSameGrouping(other : AddressDivisionGrouping) : boolean {
        if(this.getDivisionCount() !== other.getDivisionCount()) {
            return false;
        }
        for(let i : number = 0; i < this.getDivisionCount(); i++) {
            let one : AddressDivision = this.getDivision(i);
            let two : AddressDivision = other.getDivision(i);
            if(!one.isSameValues$inet_ipaddr_format_AddressDivision(two)) {
                return false;
            }
        };
        return true;
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>AddressDivisionGrouping) {
            let other : AddressDivisionGrouping = <AddressDivisionGrouping>o;
            return other.isSameGrouping(this);
        }
        return false;
    }

    /**
     * 
     * @param {AddressDivisionGrouping} other
     * @return {number}
     */
    public compareTo(other : AddressDivisionGrouping) : number {
        return IPAddress.DEFAULT_ADDRESS_COMPARATOR_$LI$()['compare$inet_ipaddr_format_AddressDivisionSeries$inet_ipaddr_format_AddressDivisionSeries'](this, other);
    }

    getDivisionsInternal() : AddressDivision[] {
        return this.divisions;
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return /* toString */('['+/* asList */this.getDivisionsInternal().slice(0).join(', ')+']');
    }

    /**
     * 
     * @return {Array}
     */
    public getDivisionStrings() : string[] {
        let result : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.getDivisionCount());
        Arrays.setAll<any>(result, (i) => this.getDivision(i).getWildcardString());
        return result;
    }

    /**
     * 
     * @return {boolean}
     */
    public isZero() : boolean {
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            if(!this.getDivision(i).isZero()) {
                return false;
            }
        };
        return true;
    }

    /**
     * 
     * @return {boolean}
     */
    public includesZero() : boolean {
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            if(!this.getDivision(i).includesZero()) {
                return false;
            }
        };
        return true;
    }

    /**
     * 
     * @return {boolean}
     */
    public isMax() : boolean {
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            if(!this.getDivision(i).isMax()) {
                return false;
            }
        };
        return true;
    }

    /**
     * 
     * @return {boolean}
     */
    public includesMax() : boolean {
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            if(!this.getDivision(i).includesMax()) {
                return false;
            }
        };
        return true;
    }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : AddressDivision = this.getDivision(i);
            if(!div.isFullRange()) {
                return false;
            }
        };
        return true;
    }

    public static getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment : number, prefixLength : number, segmentIndex : number) : number {
        if(prefixLength != null) {
            return AddressDivisionGrouping.getPrefixedSegmentPrefixLength(bitsPerSegment, prefixLength, segmentIndex);
        }
        return null;
    }

    /**
     * Across the address prefixes are:
     * IPv6: (null):...:(null):(1 to 16):(0):...:(0)
     * or IPv4: ...(null).(1 to 8).(0)...
     * @param {number} bitsPerSegment
     * @param {number} prefixLength
     * @param {number} segmentIndex
     * @return {number}
     */
    public static getSegmentPrefixLength(bitsPerSegment? : any, prefixLength? : any, segmentIndex? : any) : any {
        if(((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentIndex === 'number') || segmentIndex === null)) {
            return <any>AddressDivisionGrouping.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
        } else if(((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof prefixLength === 'number') || prefixLength === null) && segmentIndex === undefined) {
            return <any>AddressDivisionGrouping.getSegmentPrefixLength$int$int(bitsPerSegment, prefixLength);
        } else throw new Error('invalid overload');
    }

    static getPrefixedSegmentPrefixLength(bitsPerSegment : number, prefixLength : number, segmentIndex : number) : number {
        let decrement : number = (bitsPerSegment === 8)?segmentIndex << 3:((bitsPerSegment === 16)?segmentIndex << 4:segmentIndex * bitsPerSegment);
        return AddressDivisionGrouping.getSegmentPrefixLength$int$int(bitsPerSegment, prefixLength - decrement);
    }

    static getSegmentPrefixLength$int$int(segmentBits : number, segmentPrefixedBits : number) : number {
        if(segmentPrefixedBits <= 0) {
            return 0;
        } else if(segmentPrefixedBits <= segmentBits) {
            return segmentPrefixedBits;
        }
        return null;
    }

    public getAdjustedPrefix$boolean$int$boolean(nextSegment : boolean, bitsPerSegment : number, skipBitCountPrefix : boolean) : number {
        let prefix : number = this.getPrefixLength();
        let bitCount : number = this.getBitCount();
        if(nextSegment) {
            if(prefix == null) {
                if(this.getMinPrefixLengthForBlock() === 0) {
                    return 0;
                }
                return bitCount;
            }
            if(prefix === bitCount) {
                return bitCount;
            }
            let existingPrefixLength : number = /* intValue */(prefix|0);
            let adjustment : number = existingPrefixLength % bitsPerSegment;
            return existingPrefixLength + bitsPerSegment - adjustment;
        } else {
            if(prefix == null) {
                if(this.getMinPrefixLengthForBlock() === 0) {
                    return 0;
                }
                if(skipBitCountPrefix) {
                    prefix = bitCount;
                } else {
                    return bitCount;
                }
            } else if(prefix === 0) {
                return 0;
            }
            let existingPrefixLength : number = /* intValue */(prefix|0);
            let adjustment : number = ((existingPrefixLength - 1) % bitsPerSegment) + 1;
            return existingPrefixLength - adjustment;
        }
    }

    public getAdjustedPrefix(nextSegment? : any, bitsPerSegment? : any, skipBitCountPrefix? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof skipBitCountPrefix === 'boolean') || skipBitCountPrefix === null)) {
            return <any>this.getAdjustedPrefix$boolean$int$boolean(nextSegment, bitsPerSegment, skipBitCountPrefix);
        } else if(((typeof nextSegment === 'number') || nextSegment === null) && ((typeof bitsPerSegment === 'boolean') || bitsPerSegment === null) && ((typeof skipBitCountPrefix === 'boolean') || skipBitCountPrefix === null)) {
            return <any>this.getAdjustedPrefix$int$boolean$boolean(nextSegment, bitsPerSegment, skipBitCountPrefix);
        } else throw new Error('invalid overload');
    }

    getAdjustedPrefix$int$boolean$boolean(adjustment : number, floor : boolean, ceiling : boolean) : number {
        let prefix : number = this.getPrefixLength();
        if(prefix == null) {
            if(this.getMinPrefixLengthForBlock() === 0) {
                prefix = 0;
            } else {
                prefix = this.getBitCount();
            }
        }
        let result : number = prefix + adjustment;
        if(ceiling) {
            result = Math.min(this.getBitCount(), result);
        }
        if(floor) {
            result = Math.max(0, result);
        }
        return result;
    }

    /**
     * In the case where the prefix sits at a segment boundary, and the prefix sequence is null - null - 0, this changes to prefix sequence of null - x - 0, where x is segment bit length.
     * 
     * Note: We allow both [null, null, 0] and [null, x, 0] where x is segment length.  However, to avoid inconsistencies when doing segment replacements,
     * and when getting subsections, in the calling constructor we normalize [null, null, 0] to become [null, x, 0].
     * We need to support [null, x, 0] so that we can create subsections and full addresses ending with [null, x] where x is bit length.
     * So we defer to that when constructing addresses and sections.
     * Also note that in our append/appendNetowrk/insert/replace we have special handling for cases like inserting [null] into [null, 8, 0] at index 2.
     * The straight replace would give [null, 8, null, 0] which is wrong.
     * In that code we end up with [null, null, 8, 0] by doing a special trick:
     * We remove the end of [null, 8, 0] and do an append [null, 0] and we'd remove prefix from [null, 8] to get [null, null] and then we'd do another append to get [null, null, null, 0]
     * The final step is this normalization here that gives [null, null, 8, 0]
     * 
     * However, when users construct AddressDivisionGrouping or IPAddressDivisionGrouping, either one is allowed: [null, null, 0] and [null, x, 0].
     * Since those objects cannot be further subdivided with getSection/getNetworkSection/getHostSection or grown with appended/inserted/replaced,
     * there are no inconsistencies introduced, we are simply more user-friendly.
     * Also note that normalization of AddressDivisionGrouping or IPAddressDivisionGrouping is really not possible without the address creator objects we use for addresses and sections,
     * that allow us to recreate new segments of the correct type.
     * 
     * @param {number} sectionPrefixBits
     * @param {Array} segments
     * @param {number} segmentBitCount
     * @param {number} segmentByteCount
     * @param {*} segProducer
     */
    static normalizePrefixBoundary<S extends IPAddressSegment>(sectionPrefixBits : number, segments : S[], segmentBitCount : number, segmentByteCount : number, segProducer : (p1: S, p2: number) => S) {
        let networkSegmentIndex : number = AddressDivisionGrouping.getNetworkSegmentIndex(sectionPrefixBits, segmentByteCount, segmentBitCount);
        if(networkSegmentIndex >= 0) {
            let segment : S = segments[networkSegmentIndex];
            if(!segment.isPrefixed()) {
                segments[networkSegmentIndex] = (target => (typeof target === 'function')?target(segment, segmentBitCount):(<any>target).apply(segment, segmentBitCount))(segProducer);
            }
        }
    }

    static setPrefixedSegments<S extends AddressSegment>(network : AddressNetwork<any>, sectionPrefixBits : number, segments : S[], segmentBitCount : number, segmentByteCount : number, segmentCreator : AddressNetwork.AddressSegmentCreator<S>, segProducer : (p1: S, p2: number) => S) : S[] {
        let allPrefsSubnet : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        for(let i : number = (sectionPrefixBits === 0)?0:AddressDivisionGrouping.getNetworkSegmentIndex(sectionPrefixBits, segmentByteCount, segmentBitCount); i < segments.length; i++) {
            let pref : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(segmentBitCount, sectionPrefixBits, i);
            if(pref != null) {
                segments[i] = (target => (typeof target === 'function')?target(segments[i], pref):(<any>target).apply(segments[i], pref))(segProducer);
                if(allPrefsSubnet) {
                    if(++i < segments.length) {
                        let allSeg : S = segmentCreator['createSegment$int$java_lang_Integer'](0, 0);
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segments, i, segments.length, allSeg);
                    }
                }
            }
        };
        return segments;
    }

    /**
     * Returns the index of the segment containing the last byte within the network prefix
     * When networkPrefixLength is zero (so there are no segments containing bytes within the network prefix), returns -1
     * 
     * @param {number} networkPrefixLength
     * @param byteLength
     * @return
     * @param {number} bytesPerSegment
     * @param {number} bitsPerSegment
     * @return {number}
     */
    static getNetworkSegmentIndex(networkPrefixLength : number, bytesPerSegment : number, bitsPerSegment : number) : number {
        if(bytesPerSegment > 1) {
            if(bytesPerSegment === 2) {
                return (networkPrefixLength - 1) >> 4;
            }
            return ((networkPrefixLength - 1) / bitsPerSegment|0);
        }
        return (networkPrefixLength - 1) >> 3;
    }

    /**
     * Returns the index of the segment containing the first byte outside the network prefix.
     * When networkPrefixLength is null, or it matches or exceeds the bit length, returns the segment count.
     * 
     * @param {number} networkPrefixLength
     * @param byteLength
     * @return
     * @param {number} bytesPerSegment
     * @param {number} bitsPerSegment
     * @return {number}
     */
    static getHostSegmentIndex(networkPrefixLength : number, bytesPerSegment : number, bitsPerSegment : number) : number {
        if(bytesPerSegment > 1) {
            if(bytesPerSegment === 2) {
                return networkPrefixLength >> 4;
            }
            return (networkPrefixLength / bitsPerSegment|0);
        }
        return networkPrefixLength >> 3;
    }

    static removePrefix<R extends AddressSection, S extends AddressSegment>(original : R, segments : S[], segmentBitCount : number, prefixSetter : AddressDivisionGrouping.SegFunction<S, number, number, S>) : S[] {
        let oldPrefix : number = original.getPrefixLength();
        if(oldPrefix != null) {
            segments = /* clone */segments.slice(0);
            for(let i : number = 0; i < segments.length; i++) {
                let oldPref : number = AddressDivisionGrouping.getPrefixedSegmentPrefixLength(segmentBitCount, oldPrefix, i);
                segments[i] = prefixSetter.apply(segments[i], oldPref, null);
            };
        }
        return segments;
    }

    static createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer<S extends AddressSegment>(segments : S[], highBytes : number, lowBytes : number, bitsPerSegment : number, network : AddressNetwork<S>, prefixLength : number) : S[] {
        let creator : AddressNetwork.AddressSegmentCreator<S> = network.getAddressCreator();
        let segmentMask : number = ~(~0 << bitsPerSegment);
        let lowIndex : number = Math.max(0, segments.length - ((javaemul.internal.LongHelper.SIZE / bitsPerSegment|0)));
        let segmentIndex : number = segments.length - 1;
        let bytes : number = lowBytes;
        while((true)) {
            while((true)) {
                let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
                let value : number = segmentMask & (<number>bytes|0);
                let seg : S = creator['createSegment$int$java_lang_Integer'](value, segmentPrefixLength);
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,seg.getNetwork()))) {
                    throw new NetworkMismatchException(seg);
                }
                segments[segmentIndex] = seg;
                if(--segmentIndex < lowIndex) {
                    break;
                }
                bytes >>>= bitsPerSegment;
            };
            if(lowIndex === 0) {
                break;
            }
            lowIndex = 0;
            bytes = highBytes;
        };
        return segments;
    }

    public static createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer<S extends AddressSegment>(segments : S[], lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, bytesPerSegment : number, bitsPerSegment : number, network : AddressNetwork<S>, prefixLength : number) : S[] {
        let creator : AddressNetwork.AddressSegmentCreator<S> = network.getAddressCreator();
        let segmentCount : number = segments.length;
        for(let segmentIndex : number = 0; segmentIndex < segmentCount; segmentIndex++) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
            if(segmentPrefixLength != null && segmentPrefixLength === 0 && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                let allSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,allSeg.getNetwork()))) {
                    throw new NetworkMismatchException(allSeg);
                }
                /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segments, segmentIndex, segmentCount, allSeg);
                break;
            }
            let value : number = 0;
            let value2 : number = 0;
            if(lowerValueProvider == null) {
                value = upperValueProvider.getValue(segmentIndex);
            } else {
                value = lowerValueProvider.getValue(segmentIndex);
                if(upperValueProvider != null) {
                    value2 = upperValueProvider.getValue(segmentIndex);
                }
            }
            let seg : S = (lowerValueProvider != null && upperValueProvider != null)?creator['createSegment$int$int$java_lang_Integer'](value, value2, segmentPrefixLength):creator['createSegment$int$java_lang_Integer'](value, segmentPrefixLength);
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,seg.getNetwork()))) {
                throw new NetworkMismatchException(seg);
            }
            segments[segmentIndex] = seg;
        };
        return segments;
    }

    public static createSegments<S extends AddressSegment>(segments? : any, lowerValueProvider? : any, upperValueProvider? : any, bytesPerSegment? : any, bitsPerSegment? : any, network? : any, prefixLength? : any) : any {
        if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((network != null && network instanceof <any>AddressNetwork) || network === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segments, lowerValueProvider, upperValueProvider, bytesPerSegment, bitsPerSegment, network, prefixLength);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((bitsPerSegment != null && bitsPerSegment instanceof <any>AddressNetwork) || bitsPerSegment === null) && ((typeof network === 'number') || network === null) && prefixLength === undefined) {
            return <any>AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segments, lowerValueProvider, upperValueProvider, bytesPerSegment, bitsPerSegment, network);
        } else throw new Error('invalid overload');
    }

    static toSegments<S extends AddressSegment>(segments : S[], bytes : number[], startIndex : number, endIndex : number, bytesPerSegment : number, bitsPerSegment : number, network : AddressNetwork<S>, prefixLength : number) : S[] {
        if(endIndex < 0 || endIndex > bytes.length) {
            throw new AddressValueException(endIndex);
        }
        if(startIndex < 0 || startIndex > endIndex) {
            throw new AddressValueException(startIndex);
        }
        let creator : AddressNetwork.AddressSegmentCreator<S> = network.getAddressCreator();
        let segmentCount : number = segments.length;
        let expectedByteCount : number = segmentCount * bytesPerSegment;
        let missingBytes : number = expectedByteCount + startIndex - endIndex;
        if(missingBytes < 0) {
            let expectedStartIndex : number = endIndex - expectedByteCount;
            let higherStartIndex : number = expectedStartIndex - 1;
            let expectedExtendedValue : number = bytes[higherStartIndex];
            if(expectedExtendedValue !== 0) {
                let mostSignificantBit : number = bytes[expectedStartIndex] >>> 7;
                if(mostSignificantBit !== 0) {
                    if(expectedExtendedValue !== -1) {
                        throw new AddressValueException(expectedExtendedValue);
                    }
                } else {
                    throw new AddressValueException(expectedExtendedValue);
                }
            }
            while((startIndex < higherStartIndex)) {
                if(bytes[--higherStartIndex] !== expectedExtendedValue) {
                    throw new AddressValueException(expectedExtendedValue);
                }
            };
            startIndex = expectedStartIndex;
            missingBytes = 0;
        }
        let allPrefixedAddressesAreSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        for(let i : number = 0, segmentIndex : number = 0; i < expectedByteCount; segmentIndex++) {
            let segmentPrefixLength : number = IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, prefixLength, segmentIndex);
            if(allPrefixedAddressesAreSubnets && segmentPrefixLength != null && segmentPrefixLength === 0) {
                let allSeg : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,allSeg.getNetwork()))) {
                    throw new NetworkMismatchException(allSeg);
                }
                /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segments, segmentIndex, segmentCount, allSeg);
                break;
            }
            let value : number = 0;
            let k : number = bytesPerSegment + i;
            let j : number = i;
            if(j < missingBytes) {
                let mostSignificantBit : number = bytes[startIndex] >>> 7;
                if(mostSignificantBit === 0) {
                    j = missingBytes;
                } else {
                    let upper : number = Math.min(missingBytes, k);
                    for(; j < upper; j++) {
                        value <<= 8;
                        value |= 255;
                    };
                }
            }
            for(; j < k; j++) {
                let byteValue : number = 255 & bytes[startIndex + j - missingBytes];
                value <<= 8;
                value |= byteValue;
            };
            i = k;
            let seg : S = creator['createSegment$int$java_lang_Integer'](value, segmentPrefixLength);
            if(!/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(network,seg.getNetwork()))) {
                throw new NetworkMismatchException(seg);
            }
            segments[segmentIndex] = seg;
        };
        return segments;
    }

    static createSingle<R extends AddressSection, S extends AddressSegment>(original : R, segmentCreator : AddressNetwork.AddressSegmentCreator<S>, segProducer : (p0 : number) => S) : S[] {
        let segmentCount : number = original.getSegmentCount();
        let segs : S[] = segmentCreator.createSegmentArray(segmentCount);
        for(let i : number = 0; i < segmentCount; i++) {
            segs[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
        };
        return segs;
    }

    static getSectionCache<R extends AddressSegmentSeries>(section : R, sectionCacheGetter : () => AddressDivisionGrouping.SectionCache<R>, sectionCacheCreator : () => AddressDivisionGrouping.SectionCache<R>) : AddressDivisionGrouping.SectionCache<R> {
        let result : AddressDivisionGrouping.SectionCache<R> = (target => (typeof target === 'function')?target():(<any>target).get())(sectionCacheGetter);
        if(result == null) {
            {
                result = (target => (typeof target === 'function')?target():(<any>target).get())(sectionCacheGetter);
                if(result == null) {
                    result = (target => (typeof target === 'function')?target():(<any>target).get())(sectionCacheCreator);
                }
            };
        }
        return result;
    }

    static getSingleLowestOrHighestSection<R extends AddressSegmentSeries>(section : R) : R {
        if(!section.isMultiple() && !(section.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][section.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets())) {
            return section;
        }
        return null;
    }

    static reverseSegments<R extends AddressSection, S extends AddressSegment>(section : R, creator : AddressCreator<any, R, any, S>, segProducer : (p0 : number) => S, removePrefix : boolean) : R {
        let count : number = section.getSegmentCount();
        let newSegs : S[] = creator.createSegmentArray(count);
        let halfCount : number = count >>> 1;
        let i : number = 0;
        let isSame : boolean = !removePrefix || !section.isPrefixed();
        for(let j : number = count - 1; i < halfCount; i++, j--) {
            newSegs[j] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            newSegs[i] = (target => (typeof target === 'function')?target(j):(<any>target).apply(j))(segProducer);
            if(isSame && !(newSegs[i].equals(section.getSegment(i)) && newSegs[j].equals(section.getSegment(j)))) {
                isSame = false;
            }
        };
        if((count & 1) === 1) {
            newSegs[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segProducer);
            if(isSame && !newSegs[i].equals(section.getSegment(i))) {
                isSame = false;
            }
        }
        if(isSame) {
            return section;
        }
        return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(newSegs);
    }

    static reverseBits<R extends AddressSection, S extends AddressSegment>(perByte : boolean, section : R, creator : AddressCreator<any, R, any, S>, segBitReverser : (p0 : number) => S, removePrefix : boolean) : R {
        if(perByte) {
            let isSame : boolean = !removePrefix || !section.isPrefixed();
            let count : number = section.getSegmentCount();
            let newSegs : S[] = creator.createSegmentArray(count);
            for(let i : number = 0; i < count; i++) {
                newSegs[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segBitReverser);
                if(isSame && !newSegs[i].equals(section.getSegment(i))) {
                    isSame = false;
                }
            };
            if(isSame) {
                return section;
            }
            return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(newSegs);
        }
        return <any>(AddressDivisionGrouping.reverseSegments<any, any>(section, creator, <any>(segBitReverser), removePrefix));
    }

    static reverseBytes<R extends AddressSection, S extends AddressSegment>(perSegment : boolean, section : R, creator : AddressCreator<any, R, any, S>, segByteReverser : (p0 : number) => S, removePrefix : boolean) : R {
        if(perSegment) {
            let isSame : boolean = !removePrefix || !section.isPrefixed();
            let count : number = section.getSegmentCount();
            let newSegs : S[] = creator.createSegmentArray(count);
            for(let i : number = 0; i < count; i++) {
                newSegs[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(segByteReverser);
                if(isSame && !newSegs[i].equals(section.getSegment(i))) {
                    isSame = false;
                }
            };
            if(isSame) {
                return section;
            }
            return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(newSegs);
        }
        return <any>(AddressDivisionGrouping.reverseSegments<any, any>(section, creator, <any>(segByteReverser), removePrefix));
    }

    createNewDivisions<S extends AddressDivisionBase>(bitsPerDigit : number, groupingCreator : AddressDivisionGrouping.GroupingCreator<S>, groupingArrayCreator : (p0 : number) => S[]) : S[] {
        return this.createNewPrefixedDivisions<any>(bitsPerDigit, null, null, { createDivision : (value, upperValue, bitCount, radix, network, prefixLength) => groupingCreator.createDivision(value, upperValue, bitCount, radix) }, <any>(groupingArrayCreator));
    }

    static getRadixPower(radix : BigInteger, power : number) : BigInteger {
        return AddressDivisionBase.getRadixPower(radix, power);
    }

    /**
     * 
     * @param {number} bitsPerDigit
     * @param {IPAddressNetwork} network can be null if networkPrefixLength is null
     * @param {number} networkPrefixLength
     * @param {*} groupingCreator
     * @param {*} groupingArrayCreator
     * @throws AddressValueException if bitsPerDigit is larger than 32
     * @return
     * @return {Array}
     */
    createNewPrefixedDivisions<S extends AddressDivisionBase>(bitsPerDigit : number, network : IPAddressNetwork<any, any, any, any, any>, networkPrefixLength : number, groupingCreator : AddressDivisionGrouping.PrefixedGroupingCreator<S>, groupingArrayCreator : (p0 : number) => S[]) : S[] {
        if(bitsPerDigit >= javaemul.internal.IntegerHelper.SIZE) {
            throw new AddressValueException(bitsPerDigit);
        }
        let bitCount : number = this.getBitCount();
        let bitDivs : Array<number> = <any>([]);
        let largestBitCount : number = javaemul.internal.LongHelper.SIZE - 1;
        largestBitCount -= largestBitCount % bitsPerDigit;
        do {
            if(bitCount <= largestBitCount) {
                let mod : number = bitCount % bitsPerDigit;
                let secondLast : number = bitCount - mod;
                if(secondLast > 0) {
                    /* add */(bitDivs.push(secondLast)>0);
                }
                if(mod > 0) {
                    /* add */(bitDivs.push(mod)>0);
                }
                break;
            } else {
                bitCount -= largestBitCount;
                /* add */(bitDivs.push(largestBitCount)>0);
            }
        } while((true));
        let bitDivSize : number = /* size */(<number>bitDivs.length);
        let divs : S[] = (target => (typeof target === 'function')?target(bitDivSize):(<any>target).apply(bitDivSize))(groupingArrayCreator);
        let currentSegmentIndex : number = 0;
        let seg : AddressDivision = this.getDivision(currentSegmentIndex);
        let segLowerVal : number = seg.getLowerValue();
        let segUpperVal : number = seg.getUpperValue();
        let segBits : number = seg.getBitCount();
        let bitsSoFar : number = 0;
        let radix : number = AddressDivisionGrouping.getRadixPower(BigInteger.valueOf(2), bitsPerDigit).intValue();
        for(let i : number = bitDivSize - 1; i >= 0; i--) {
            let originalDivBitSize : number;
            let divBitSize : number;
            originalDivBitSize = divBitSize = /* get */bitDivs[i];
            let divLowerValue : number;
            let divUpperValue : number;
            divLowerValue = divUpperValue = 0;
            while((true)) {
                if(segBits >= divBitSize) {
                    let diff : number = segBits - divBitSize;
                    divLowerValue |= segLowerVal >>> diff;
                    let shift : number = ~(~0 << diff);
                    segLowerVal &= shift;
                    divUpperValue |= segUpperVal >>> diff;
                    segUpperVal &= shift;
                    segBits = diff;
                    let segPrefixBits : number = networkPrefixLength == null?null:AddressDivisionGrouping.getSegmentPrefixLength$int$int(originalDivBitSize, networkPrefixLength - bitsSoFar);
                    let div : S = groupingCreator.createDivision(divLowerValue, divUpperValue, originalDivBitSize, radix, network, segPrefixBits);
                    divs[bitDivSize - i - 1] = div;
                    if(segBits === 0 && i > 0) {
                        seg = this.getDivision(++currentSegmentIndex);
                        segLowerVal = seg.getLowerValue();
                        segUpperVal = seg.getUpperValue();
                        segBits = seg.getBitCount();
                    }
                    break;
                } else {
                    let diff : number = divBitSize - segBits;
                    divLowerValue |= segLowerVal << diff;
                    divUpperValue |= segUpperVal << diff;
                    divBitSize = diff;
                    seg = this.getDivision(++currentSegmentIndex);
                    segLowerVal = seg.getLowerValue();
                    segUpperVal = seg.getUpperValue();
                    segBits = seg.getBitCount();
                }
            };
            bitsSoFar += originalDivBitSize;
        };
        return divs;
    }

    static iterator$boolean$inet_ipaddr_AddressSection$inet_ipaddr_format_AddressCreator$java_util_Iterator$java_lang_Integer<R extends AddressSection, S extends AddressSegment>(useOriginal : boolean, original : R, creator : AddressCreator<any, R, any, S>, iterator : any, prefixLength : number) : any {
        if(useOriginal) {
            return new AddressDivisionGrouping.AddressDivisionGrouping$0<R>(original);
        }
        return new AddressDivisionGrouping.AddressDivisionGrouping$1<R>(iterator, creator, prefixLength);
    }

    static createIteratedSection<R extends AddressSection, S extends AddressSegment>(next : S[], creator : AddressCreator<any, R, any, S>, prefixLength : number) : R {
        return creator.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(next, prefixLength, true);
    }

    iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate<S extends AddressSegment>(segmentCreator : AddressNetwork.AddressSegmentCreator<S>, segSupplier : () => S[], segIteratorProducer : (p0 : number) => any, excludeFunc : (p1: S[]) => boolean) : any {
        return this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(segmentCreator, <any>(segSupplier), <any>(segIteratorProducer), <any>(excludeFunc), this.getDivisionCount() - 1, this.getDivisionCount(), <any>(null));
    }

    public iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction<S extends AddressSegment>(segmentCreator : AddressNetwork.AddressSegmentCreator<S>, segSupplier : () => S[], segIteratorProducer : (p0 : number) => any, excludeFunc : (p1: S[]) => boolean, networkSegmentIndex : number, hostSegmentIndex : number, prefixedSegIteratorProducer : (p0 : number) => any) : any {
        let segmentCount : number = this.getDivisionCount();
        if(!this.isMultiple() && (prefixedSegIteratorProducer == null || hostSegmentIndex >= segmentCount)) {
            return new AddressDivisionGrouping.AddressDivisionGrouping$2(this, segSupplier, excludeFunc);
        }
        return new AddressDivisionGrouping.AddressDivisionGrouping$3(this, segmentCount, segmentCreator, networkSegmentIndex, prefixedSegIteratorProducer, excludeFunc, hostSegmentIndex, segIteratorProducer);
    }

    /**
     * Used to produce regular iterators with or without zero-host values, and prefix block iterators
     * @param {*} segmentCreator
     * @param {*} segSupplier
     * @param {*} segIteratorProducer
     * @param {*} excludeFunc
     * @param {number} networkSegmentIndex
     * @param {number} hostSegmentIndex
     * @param {*} prefixedSegIteratorProducer
     * @return
     * @return {*}
     */
    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && ((typeof networkSegmentIndex === 'number') || networkSegmentIndex === null) && ((typeof hostSegmentIndex === 'number') || hostSegmentIndex === null) && ((typeof prefixedSegIteratorProducer === 'function' && (<any>prefixedSegIteratorProducer).length == 1) || prefixedSegIteratorProducer === null)) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(segmentCreator, segSupplier, segIteratorProducer, excludeFunc, networkSegmentIndex, hostSegmentIndex, prefixedSegIteratorProducer);
        } else if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(segmentCreator, segSupplier, segIteratorProducer, excludeFunc);
        } else throw new Error('invalid overload');
    }

    public static iterator$inet_ipaddr_Address$inet_ipaddr_format_AddressCreator$boolean$java_util_Iterator$java_lang_Integer<T extends Address, S extends AddressSegment>(original : T, creator : AddressCreator<T, any, any, S>, useOriginal : boolean, iterator : any, prefixLength : number) : any {
        if(useOriginal) {
            return new AddressDivisionGrouping.AddressDivisionGrouping$4<T>(original);
        }
        return new AddressDivisionGrouping.AddressDivisionGrouping$5<T>(iterator, prefixLength, creator);
    }

    public static iterator<T extends Address, S extends AddressSegment>(original? : any, creator? : any, useOriginal? : any, iterator? : any, prefixLength? : any) : any {
        if(((original != null) || original === null) && ((creator != null && creator instanceof <any>AddressCreator) || creator === null) && ((typeof useOriginal === 'boolean') || useOriginal === null) && ((iterator != null && (iterator instanceof Object)) || iterator === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>AddressDivisionGrouping.iterator$inet_ipaddr_Address$inet_ipaddr_format_AddressCreator$boolean$java_util_Iterator$java_lang_Integer(original, creator, useOriginal, iterator, prefixLength);
        } else if(((typeof original === 'boolean') || original === null) && ((creator != null) || creator === null) && ((useOriginal != null && useOriginal instanceof <any>AddressCreator) || useOriginal === null) && ((iterator != null && (iterator instanceof Object)) || iterator === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>AddressDivisionGrouping.iterator$boolean$inet_ipaddr_AddressSection$inet_ipaddr_format_AddressCreator$java_util_Iterator$java_lang_Integer(original, creator, useOriginal, iterator, prefixLength);
        } else throw new Error('invalid overload');
    }

    static checkOverflow$long$long$long$long$java_util_function_LongSupplier(increment : number, lowerValue : number, upperValue : number, count : number, maxValue : any) {
        if(increment < 0) {
            if(lowerValue < -increment) {
                throw new AddressValueException(increment);
            }
        } else {
            if(count > 1) {
                increment -= count - 1;
            }
            if(increment > (target => (typeof target === 'function')?target():(<any>target).getAsLong())(maxValue) - upperValue) {
                throw new AddressValueException(increment);
            }
        }
    }

    public static checkOverflow$long$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_util_function_Supplier(increment : number, bigIncrement : BigInteger, lowerValue : BigInteger, upperValue : BigInteger, count : BigInteger, maxValue : () => BigInteger) {
        let isMultiple : boolean = count.compareTo(BigInteger.ONE) > 0;
        if(increment < 0) {
            if(lowerValue.compareTo(bigIncrement.negate()) < 0) {
                throw new AddressValueException(increment);
            }
        } else {
            if(isMultiple) {
                bigIncrement = bigIncrement.subtract(count.subtract(BigInteger.ONE));
            }
            if(bigIncrement.compareTo((target => (typeof target === 'function')?target():(<any>target).get())(maxValue).subtract(upperValue)) > 0) {
                throw new AddressValueException(increment);
            }
        }
    }

    public static checkOverflow(increment? : any, bigIncrement? : any, lowerValue? : any, upperValue? : any, count? : any, maxValue? : any) : any {
        if(((typeof increment === 'number') || increment === null) && ((bigIncrement != null && bigIncrement instanceof <any>BigInteger) || bigIncrement === null) && ((lowerValue != null && lowerValue instanceof <any>BigInteger) || lowerValue === null) && ((upperValue != null && upperValue instanceof <any>BigInteger) || upperValue === null) && ((count != null && count instanceof <any>BigInteger) || count === null) && ((typeof maxValue === 'function' && (<any>maxValue).length == 0) || maxValue === null)) {
            return <any>AddressDivisionGrouping.checkOverflow$long$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_util_function_Supplier(increment, bigIncrement, lowerValue, upperValue, count, maxValue);
        } else if(((typeof increment === 'number') || increment === null) && ((typeof bigIncrement === 'number') || bigIncrement === null) && ((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof count === 'function' && (<any>count).length == 0) || count === null) && maxValue === undefined) {
            return <any>AddressDivisionGrouping.checkOverflow$long$long$long$long$java_util_function_LongSupplier(increment, bigIncrement, lowerValue, upperValue, count);
        } else throw new Error('invalid overload');
    }

    /**
     * Handles the cases in which we can use longs rather than BigInteger
     * 
     * @param {*} section
     * @param {number} increment
     * @param {AddressCreator} addrCreator
     * @param {*} lowerProducer
     * @param {*} upperProducer
     * @param {number} prefixLength
     * @return
     * @return {*}
     */
    static fastIncrement<R extends AddressSection, S extends AddressSegment>(section : R, increment : number, addrCreator : AddressCreator<any, R, any, S>, lowerProducer : () => R, upperProducer : () => R, prefixLength : number) : R {
        if(increment >= 0) {
            let count : BigInteger = section.getCount();
            if(count.compareTo(AddressDivisionGrouping.LONG_MAX_$LI$()) <= 0) {
                let longCount : number = count.longValue();
                if(longCount > increment) {
                    if(longCount === increment + 1) {
                        return (target => (typeof target === 'function')?target():(<any>target).get())(upperProducer);
                    }
                    return <any>(AddressDivisionGrouping.incrementRange<any, any>(section, increment, addrCreator, <any>(lowerProducer), prefixLength));
                }
                let value : BigInteger = section.getValue();
                let upperValue : BigInteger;
                if(value.compareTo(AddressDivisionGrouping.LONG_MAX_$LI$()) <= 0 && (upperValue = section.getUpperValue()).compareTo(AddressDivisionGrouping.LONG_MAX_$LI$()) <= 0) {
                    return <any>(AddressDivisionGrouping.increment(section, increment, addrCreator, count.longValue(), value.longValue(), upperValue.longValue(), <any>(lowerProducer), <any>(upperProducer), prefixLength));
                }
            }
        } else {
            let value : BigInteger = section.getValue();
            if(value.compareTo(AddressDivisionGrouping.LONG_MAX_$LI$()) <= 0) {
                return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(lowerProducer), value.longValue(), increment, addrCreator, prefixLength));
            }
        }
        return null;
    }

    public static increment$inet_ipaddr_AddressSection$long$inet_ipaddr_format_AddressCreator$long$long$long$java_util_function_Supplier$java_util_function_Supplier$java_lang_Integer<R extends AddressSection, S extends AddressSegment>(section : R, increment : number, addrCreator : AddressCreator<any, R, any, S>, count : number, lowerValue : number, upperValue : number, lowerProducer : () => R, upperProducer : () => R, prefixLength : number) : R {
        if(!section.isMultiple()) {
            return <any>(AddressDivisionGrouping.add(section, lowerValue, increment, addrCreator, prefixLength));
        }
        let isDecrement : boolean = increment <= 0;
        if(isDecrement) {
            return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(lowerProducer), lowerValue, increment, addrCreator, prefixLength));
        }
        if(count > increment) {
            if(count === increment + 1) {
                return (target => (typeof target === 'function')?target():(<any>target).get())(upperProducer);
            }
            return <any>(AddressDivisionGrouping.incrementRange<any, any>(section, increment, addrCreator, <any>(lowerProducer), prefixLength));
        }
        if(increment <= Number.MAX_VALUE - upperValue) {
            return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(upperProducer), upperValue, increment - (count - 1), addrCreator, prefixLength));
        }
        return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(upperProducer), BigInteger.valueOf(increment - (count - 1)), addrCreator, prefixLength));
    }

    public static increment<R extends AddressSection, S extends AddressSegment>(section? : any, increment? : any, addrCreator? : any, count? : any, lowerValue? : any, upperValue? : any, lowerProducer? : any, upperProducer? : any, prefixLength? : any) : any {
        if(((section != null) || section === null) && ((typeof increment === 'number') || increment === null) && ((addrCreator != null && addrCreator instanceof <any>AddressCreator) || addrCreator === null) && ((typeof count === 'number') || count === null) && ((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof lowerProducer === 'function' && (<any>lowerProducer).length == 0) || lowerProducer === null) && ((typeof upperProducer === 'function' && (<any>upperProducer).length == 0) || upperProducer === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>AddressDivisionGrouping.increment$inet_ipaddr_AddressSection$long$inet_ipaddr_format_AddressCreator$long$long$long$java_util_function_Supplier$java_util_function_Supplier$java_lang_Integer(section, increment, addrCreator, count, lowerValue, upperValue, lowerProducer, upperProducer, prefixLength);
        } else if(((section != null) || section === null) && ((typeof increment === 'number') || increment === null) && ((addrCreator != null && addrCreator instanceof <any>BigInteger) || addrCreator === null) && ((count != null && count instanceof <any>AddressCreator) || count === null) && ((typeof lowerValue === 'function' && (<any>lowerValue).length == 0) || lowerValue === null) && ((typeof upperValue === 'function' && (<any>upperValue).length == 0) || upperValue === null) && ((typeof lowerProducer === 'number') || lowerProducer === null) && upperProducer === undefined && prefixLength === undefined) {
            return <any>AddressDivisionGrouping.increment$inet_ipaddr_AddressSection$long$java_math_BigInteger$inet_ipaddr_format_AddressCreator$java_util_function_Supplier$java_util_function_Supplier$java_lang_Integer(section, increment, addrCreator, count, lowerValue, upperValue, lowerProducer);
        } else throw new Error('invalid overload');
    }

    static increment$inet_ipaddr_AddressSection$long$java_math_BigInteger$inet_ipaddr_format_AddressCreator$java_util_function_Supplier$java_util_function_Supplier$java_lang_Integer<R extends AddressSection, S extends AddressSegment>(section : R, increment : number, bigIncrement : BigInteger, addrCreator : AddressCreator<any, R, any, S>, lowerProducer : () => R, upperProducer : () => R, prefixLength : number) : R {
        if(!section.isMultiple()) {
            return <any>(AddressDivisionGrouping.add(section, bigIncrement, addrCreator, prefixLength));
        }
        let isDecrement : boolean = increment <= 0;
        if(isDecrement) {
            return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(lowerProducer), bigIncrement, addrCreator, prefixLength));
        }
        let count : BigInteger = section.getCount();
        let incrementPlus1 : BigInteger = bigIncrement.add(BigInteger.ONE);
        let countCompare : number = count.compareTo(incrementPlus1);
        if(countCompare <= 0) {
            if(countCompare === 0) {
                return (target => (typeof target === 'function')?target():(<any>target).get())(upperProducer);
            }
            return <any>(AddressDivisionGrouping.add((target => (typeof target === 'function')?target():(<any>target).get())(upperProducer), incrementPlus1.subtract(count), addrCreator, prefixLength));
        }
        return <any>(AddressDivisionGrouping.incrementRange<any, any>(section, increment, addrCreator, <any>(lowerProducer), prefixLength));
    }

    /**
     * 
     * @param {*} section
     * @param {number} increment
     * @param {AddressCreator} addrCreator
     * @param rangeIncrement the positive value of the number of increments through the range (0 means take lower or upper value in range)
     * @param isDecrement
     * @param {*} lowerProducer
     * @param upperProducer
     * @param {number} prefixLength
     * @return
     * @return {*}
     */
    static incrementRange<R extends AddressSection, S extends AddressSegment>(section : R, increment : number, addrCreator : AddressCreator<any, R, any, S>, lowerProducer : () => R, prefixLength : number) : R {
        if(increment === 0) {
            return (target => (typeof target === 'function')?target():(<any>target).get())(lowerProducer);
        }
        let segCount : number = section.getSegmentCount();
        let newSegments : S[] = addrCreator.createSegmentArray(segCount);
        for(let i : number = segCount - 1; i >= 0; i--) {
            let seg : AddressSegment = section.getSegment(i);
            let segRange : number = seg.getValueCount();
            let revolutions : number = (n => n<0?Math.ceil(n):Math.floor(n))(increment / segRange);
            let remainder : number = (<number>(increment % segRange)|0);
            let newSegment : S = addrCreator['createSegment$int'](seg.getLowerSegmentValue() + remainder);
            newSegments[i] = newSegment;
            if(revolutions === 0) {
                for(i--; i >= 0; i--) {
                    let original : AddressSegment = section.getSegment(i);
                    newSegments[i] = addrCreator['createSegment$int'](original.getLowerSegmentValue());
                };
                break;
            } else {
                increment = revolutions;
            }
        };
        return <any>(AddressDivisionGrouping.createIteratedSection<any, any>(newSegments, addrCreator, prefixLength));
    }

    static add$inet_ipaddr_AddressSection$java_math_BigInteger$inet_ipaddr_format_AddressCreator$java_lang_Integer<R extends AddressSection, S extends AddressSegment>(section : R, increment : BigInteger, addrCreator : AddressCreator<any, R, any, S>, prefixLength : number) : R {
        if(section.isMultiple()) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }
        let segCount : number = section.getSegmentCount();
        let fullValue : BigInteger = section.getValue();
        fullValue = fullValue.add(increment);
        let bytes : number[] = fullValue.toByteArray();
        return addrCreator.createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes, segCount, prefixLength, true);
    }

    public static add$inet_ipaddr_AddressSection$long$long$inet_ipaddr_format_AddressCreator$java_lang_Integer<R extends AddressSection, S extends AddressSegment>(section : R, fullValue : number, increment : number, addrCreator : AddressCreator<any, R, any, S>, prefixLength : number) : R {
        if(section.isMultiple()) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }
        let segCount : number = section.getSegmentCount();
        let newSegs : S[] = addrCreator.createSegmentArray(segCount);
        AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(newSegs, 0, fullValue + increment, section.getBitsPerSegment(), addrCreator.getNetwork(), prefixLength);
        return <any>(AddressDivisionGrouping.createIteratedSection<any, any>(newSegs, addrCreator, prefixLength));
    }

    public static add<R extends AddressSection, S extends AddressSegment>(section? : any, fullValue? : any, increment? : any, addrCreator? : any, prefixLength? : any) : any {
        if(((section != null) || section === null) && ((typeof fullValue === 'number') || fullValue === null) && ((typeof increment === 'number') || increment === null) && ((addrCreator != null && addrCreator instanceof <any>AddressCreator) || addrCreator === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>AddressDivisionGrouping.add$inet_ipaddr_AddressSection$long$long$inet_ipaddr_format_AddressCreator$java_lang_Integer(section, fullValue, increment, addrCreator, prefixLength);
        } else if(((section != null) || section === null) && ((fullValue != null && fullValue instanceof <any>BigInteger) || fullValue === null) && ((increment != null && increment instanceof <any>AddressCreator) || increment === null) && ((typeof addrCreator === 'number') || addrCreator === null) && prefixLength === undefined) {
            return <any>AddressDivisionGrouping.add$inet_ipaddr_AddressSection$java_math_BigInteger$inet_ipaddr_format_AddressCreator$java_lang_Integer(section, fullValue, increment, addrCreator);
        } else throw new Error('invalid overload');
    }

    static getSection<R extends AddressSection, S extends AddressSegment>(index : number, endIndex : number, section : R, creator : AddressCreator<any, R, any, S>) : R {
        if(index === 0 && endIndex === section.getSegmentCount()) {
            return section;
        }
        let segmentCount : number = endIndex - index;
        if(segmentCount < 0) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.IndexOutOfBoundsException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }
        let segs : S[] = creator.createSegmentArray(segmentCount);
        section['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](index, endIndex, segs, 0);
        return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(segs);
    }

    static append<R extends AddressSection, S extends AddressSegment>(section : R, other : R, creator : AddressCreator<any, R, any, S>) : R {
        let otherSegmentCount : number = other.getSegmentCount();
        let segmentCount : number = section.getSegmentCount();
        let totalSegmentCount : number = segmentCount + otherSegmentCount;
        let segs : S[] = creator.createSegmentArray(totalSegmentCount);
        section['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](0, segmentCount, segs, 0);
        if(section.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][section.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            let allSegment : S = creator['createSegment$int$java_lang_Integer'](0, 0);
            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segs, segmentCount, totalSegmentCount, allSegment);
        } else {
            other['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](0, otherSegmentCount, segs, segmentCount);
        }
        return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(segs);
    }

    static replace<R extends AddressSection, S extends AddressSegment>(section : R, index : number, endIndex : number, replacement : R, replacementStartIndex : number, replacementEndIndex : number, creator : AddressCreator<any, R, any, S>, appendNetwork : boolean, isMac : boolean) : R {
        let otherSegmentCount : number = replacementEndIndex - replacementStartIndex;
        let segmentCount : number = section.getSegmentCount();
        let totalSegmentCount : number = segmentCount + otherSegmentCount - (endIndex - index);
        let segs : S[] = creator.createSegmentArray(totalSegmentCount);
        section['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](0, index, segs, 0);
        if(index < totalSegmentCount) {
            if(section.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][section.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && (appendNetwork?(AddressDivisionGrouping.getHostSegmentIndex(section.getPrefixLength(), section.getBytesPerSegment(), section.getBitsPerSegment()) < index):(AddressDivisionGrouping.getNetworkSegmentIndex(section.getPrefixLength(), section.getBytesPerSegment(), section.getBitsPerSegment()) < index)) && (isMac || index > 0)) {
                let allSegment : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segs, index, totalSegmentCount, allSegment);
                return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(segs);
            }
            replacement['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](replacementStartIndex, replacementEndIndex, segs, index);
            if(index + otherSegmentCount < totalSegmentCount) {
                if(replacement.isPrefixed() && AddressNetwork.PrefixConfiguration["_$wrappers"][section.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() && AddressDivisionGrouping.getNetworkSegmentIndex(replacement.getPrefixLength(), replacement.getBytesPerSegment(), replacement.getBitsPerSegment()) < replacementEndIndex && (isMac || otherSegmentCount > 0)) {
                    let allSegment : S = creator['createSegment$int$java_lang_Integer'](0, 0);
                    /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segs, index + otherSegmentCount, totalSegmentCount, allSegment);
                } else {
                    section['getSegments$int$int$inet_ipaddr_AddressSegment_A$int'](endIndex, segmentCount, segs, index + otherSegmentCount);
                }
            }
        }
        return creator.createSectionInternal$inet_ipaddr_AddressSegment_A(segs);
    }

    public static createSectionInternal(creator? : any, segments? : any, startIndex? : any, extended? : any) : any {
        if(((creator != null && creator instanceof <any>AddressCreator) || creator === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null)) {
            return <any>AddressDivisionGrouping.createSectionInternal$inet_ipaddr_format_AddressCreator$inet_ipaddr_AddressSegment_A$int$boolean(creator, segments, startIndex, extended);
        } else throw new Error('invalid overload');
    }

    static createSectionInternal$inet_ipaddr_format_AddressCreator$inet_ipaddr_AddressSegment_A$int$boolean<R extends AddressSection, S extends AddressSegment>(creator : AddressCreator<any, R, any, S>, segments : S[], startIndex : number, extended : boolean) : R {
        return creator.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(segments, startIndex, extended);
    }

    static getCachedParams(opts : AddressDivisionGrouping.StringOptions) : AddressDivisionWriter {
        return opts.cachedParams;
    }

    static setCachedParams(opts : AddressDivisionGrouping.StringOptions, cachedParams : AddressDivisionWriter) {
        opts.cachedParams = cachedParams;
    }

    isDualString() : boolean {
        let count : number = this.getDivisionCount();
        for(let i : number = 0; i < count; i++) {
            let division : AddressDivision = this.getDivision(i);
            if(division.isMultiple()) {
                let isLastFull : boolean = true;
                let lastDivision : AddressDivision = null;
                for(let j : number = count - 1; j >= 0; j--) {
                    division = this.getDivision(j);
                    if(division.isMultiple()) {
                        if(!isLastFull) {
                            throw new IncompatibleAddressException(division, i, lastDivision, i + 1, "ipaddress.error.segmentMismatch");
                        }
                        isLastFull = division.isFullRange();
                    } else {
                        isLastFull = false;
                    }
                    lastDivision = division;
                };
                return true;
            }
        };
        return false;
    }

    static toNormalizedStringRange<T extends AddressStringDivisionSeries, E extends AddressStringDivisionSeries>(params : AddressDivisionGrouping.AddressStringParams<T>, lower : T, upper : T, zone : any) : string {
        let length : number = params.getStringLength(lower, zone) + params.getStringLength(upper, zone);
        let builder : { str: string };
        let separator : string = params.getWildcards().rangeSeparator;
        if(separator != null) {
            length += separator.length;
            builder = { str: "", toString: function() { return this.str; } };
            params.append(/* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(params.append(builder, lower, null)), upper, zone);
        } else {
            builder = { str: "", toString: function() { return this.str; } };
            params.append(params.append(builder, lower, null), upper, zone);
        }
        AddressDivisionGrouping.AddressStringParams.checkLengths(length, builder);
        return /* toString */builder.str;
    }
}
AddressDivisionGrouping["__class"] = "inet.ipaddr.format.AddressDivisionGrouping";
AddressDivisionGrouping["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



export namespace AddressDivisionGrouping {

    export class SectionCache<R extends AddressSegmentSeries> {
        public lower : R;

        public lowerNonZeroHost : R;

        public upper : R;

        public lowerNonZeroHostIsNull : boolean;

        public constructor() {
            if(this.lower===undefined) this.lower = null;
            if(this.lowerNonZeroHost===undefined) this.lowerNonZeroHost = null;
            if(this.upper===undefined) this.upper = null;
            if(this.lowerNonZeroHostIsNull===undefined) this.lowerNonZeroHostIsNull = false;
        }
    }
    SectionCache["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.SectionCache";


    export class StringCache {
        public canonicalString : string;

        public hexString : string;

        public hexStringPrefixed : string;

        constructor() {
            if(this.canonicalString===undefined) this.canonicalString = null;
            if(this.hexString===undefined) this.hexString = null;
            if(this.hexStringPrefixed===undefined) this.hexStringPrefixed = null;
        }
    }
    StringCache["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.StringCache";


    export class ValueCache {
        public lowerBytes : number[];

        public upperBytes : number[];

        public value : BigInteger;

        public upperValue : BigInteger;

        public inetAddress : InetAddress;

        public upperInetAddress : InetAddress;

        constructor() {
            if(this.lowerBytes===undefined) this.lowerBytes = null;
            if(this.upperBytes===undefined) this.upperBytes = null;
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.inetAddress===undefined) this.inetAddress = null;
            if(this.upperInetAddress===undefined) this.upperInetAddress = null;
        }
    }
    ValueCache["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.ValueCache";


    export interface SegFunction<T, U, V, R> {
        apply(t : T, u : U, v : V) : R;
    }

    export interface GroupingCreator<S extends AddressDivisionBase> {
        createDivision(value : number, upperValue : number, bitCount : number, radix : number) : S;
    }

    export interface PrefixedGroupingCreator<S extends AddressDivisionBase> {
        createDivision(value : number, upperValue : number, bitCount : number, radix : number, network : IPAddressNetwork<any, any, any, any, any>, prefixLength : number) : S;
    }

    export class AddressStringParams<T extends AddressStringDivisionSeries> implements AddressDivisionWriter, AddressSegmentParams {
        public static DEFAULT_WILDCARDS : StringOptions.Wildcards; public static DEFAULT_WILDCARDS_$LI$() : StringOptions.Wildcards { if(AddressStringParams.DEFAULT_WILDCARDS == null) AddressStringParams.DEFAULT_WILDCARDS = new StringOptions.Wildcards(); return AddressStringParams.DEFAULT_WILDCARDS; };

        wildcards : StringOptions.Wildcards = AddressStringParams.DEFAULT_WILDCARDS_$LI$();

        __expandSegments : boolean;

        segmentStrPrefix : string = "";

        radix : number;

        separator : string;

        uppercase : boolean;

        reverse : boolean;

        splitDigits : boolean;

        addressLabel : string = "";

        zoneSeparator : string;

        public constructor(radix? : any, separator? : any, uppercase? : any, zoneSeparator? : any) {
            if(((typeof radix === 'number') || radix === null) && ((typeof separator === 'string') || separator === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof zoneSeparator === 'string') || zoneSeparator === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.__expandSegments===undefined) this.__expandSegments = false;
                if(this.radix===undefined) this.radix = 0;
                if(this.separator===undefined) this.separator = null;
                if(this.uppercase===undefined) this.uppercase = false;
                if(this.reverse===undefined) this.reverse = false;
                if(this.splitDigits===undefined) this.splitDigits = false;
                if(this.zoneSeparator===undefined) this.zoneSeparator = null;
                this.wildcards = AddressStringParams.DEFAULT_WILDCARDS_$LI$();
                this.segmentStrPrefix = "";
                this.addressLabel = "";
                if(this.__expandSegments===undefined) this.__expandSegments = false;
                if(this.radix===undefined) this.radix = 0;
                if(this.separator===undefined) this.separator = null;
                if(this.uppercase===undefined) this.uppercase = false;
                if(this.reverse===undefined) this.reverse = false;
                if(this.splitDigits===undefined) this.splitDigits = false;
                if(this.zoneSeparator===undefined) this.zoneSeparator = null;
                (() => {
                    this.radix = radix;
                    this.separator = separator;
                    this.uppercase = uppercase;
                    this.zoneSeparator = zoneSeparator;
                })();
            } else if(((typeof radix === 'number') || radix === null) && ((typeof separator === 'string') || separator === null) && ((typeof uppercase === 'boolean') || uppercase === null) && zoneSeparator === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zoneSeparator : any = String.fromCharCode(0);
                    if(this.__expandSegments===undefined) this.__expandSegments = false;
                    if(this.radix===undefined) this.radix = 0;
                    if(this.separator===undefined) this.separator = null;
                    if(this.uppercase===undefined) this.uppercase = false;
                    if(this.reverse===undefined) this.reverse = false;
                    if(this.splitDigits===undefined) this.splitDigits = false;
                    if(this.zoneSeparator===undefined) this.zoneSeparator = null;
                    this.wildcards = AddressStringParams.DEFAULT_WILDCARDS_$LI$();
                    this.segmentStrPrefix = "";
                    this.addressLabel = "";
                    if(this.__expandSegments===undefined) this.__expandSegments = false;
                    if(this.radix===undefined) this.radix = 0;
                    if(this.separator===undefined) this.separator = null;
                    if(this.uppercase===undefined) this.uppercase = false;
                    if(this.reverse===undefined) this.reverse = false;
                    if(this.splitDigits===undefined) this.splitDigits = false;
                    if(this.zoneSeparator===undefined) this.zoneSeparator = null;
                    (() => {
                        this.radix = radix;
                        this.separator = separator;
                        this.uppercase = uppercase;
                        this.zoneSeparator = zoneSeparator;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        public setZoneSeparator(zoneSeparator : string) {
            this.zoneSeparator = zoneSeparator;
        }

        public getAddressLabel() : string {
            return this.addressLabel;
        }

        public setAddressLabel(str : string) {
            this.addressLabel = str;
        }

        public getSeparator() : string {
            return this.separator;
        }

        public setSeparator(separator : string) {
            this.separator = separator;
        }

        /**
         * 
         * @return {AddressDivisionGrouping.StringOptions.Wildcards}
         */
        public getWildcards() : StringOptions.Wildcards {
            return this.wildcards;
        }

        public setWildcards(wc : StringOptions.Wildcards) {
            this.wildcards = wc;
        }

        /**
         * 
         * @return {boolean}
         */
        public preferWildcards() : boolean {
            return true;
        }

        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getLeadingZeros(segmentIndex : number) : number {
            if(this.__expandSegments) {
                return -1;
            }
            return 0;
        }

        /**
         * 
         * @return {string}
         */
        public getSegmentStrPrefix() : string {
            return this.segmentStrPrefix;
        }

        public setSegmentStrPrefix(segmentStrPrefix : string) {
            if(segmentStrPrefix == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
            }
            this.segmentStrPrefix = segmentStrPrefix;
        }

        /**
         * 
         * @return {number}
         */
        public getRadix() : number {
            return this.radix;
        }

        public setRadix(radix : number) {
            this.radix = radix;
        }

        public setUppercase(uppercase : boolean) {
            this.uppercase = uppercase;
        }

        /**
         * 
         * @return {boolean}
         */
        public isUppercase() : boolean {
            return this.uppercase;
        }

        public setSplitDigits(split : boolean) {
            this.splitDigits = split;
        }

        /**
         * 
         * @return {boolean}
         */
        public isSplitDigits() : boolean {
            return this.splitDigits;
        }

        /**
         * 
         * @return {string}
         */
        public getSplitDigitSeparator() : string {
            return this.separator;
        }

        /**
         * 
         * @return {boolean}
         */
        public isReverseSplitDigits() : boolean {
            return this.reverse;
        }

        public setReverse(rev : boolean) {
            this.reverse = rev;
        }

        public isReverse() : boolean {
            return this.reverse;
        }

        public expandSegments(expand : boolean) {
            this.__expandSegments = expand;
        }

        public appendLabel(builder : { str: string }) : { str: string } {
            let str : string = this.getAddressLabel();
            if(str != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(builder);
            }
            return builder;
        }

        public getAddressLabelLength() : number {
            let str : string = this.getAddressLabel();
            if(str != null) {
                return str.length;
            }
            return 0;
        }

        /**
         * 
         * @param {IPv6AddressSection} part
         * @return {number}
         */
        public getSegmentsStringLength(part? : any) : any {
            if(((part != null) || part === null)) {
                return <any>this.getSegmentsStringLength$inet_ipaddr_format_AddressStringDivisionSeries(part);
            } else throw new Error('invalid overload');
        }

        public getSegmentsStringLength$inet_ipaddr_format_AddressStringDivisionSeries(part : T) : number {
            let count : number = 0;
            if(part.getDivisionCount() !== 0) {
                let divCount : number = part.getDivisionCount();
                for(let i : number = 0; i < divCount; i++) {
                    count += this.appendSegment(i, null, part);
                };
                let separator : string = this.getSeparator();
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                    count += divCount - 1;
                }
            }
            return count;
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {IPv6AddressSection} addr
         * @return {{ str: string }}
         */
        public appendSegments(builder? : any, addr? : any) : any {
            if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null)) {
                return <any>this.appendSegments$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder, addr);
            } else throw new Error('invalid overload');
        }

        public appendSegments$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder : { str: string }, part : T) : { str: string } {
            let count : number = part.getDivisionCount();
            if(count !== 0) {
                let reverse : boolean = this.isReverse();
                let i : number = 0;
                let separator : string = this.getSeparator();
                while((true)) {
                    let segIndex : number = reverse?(count - i - 1):i;
                    this.appendSegment(segIndex, builder, part);
                    if(++i === count) {
                        break;
                    }
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(builder);
                    }
                };
            }
            return builder;
        }

        public appendSingleDivision(seg : AddressStringDivision, builder : { str: string }) : number {
            if(builder == null) {
                return this.getAddressLabelLength() + seg.getStandardString(0, this, null);
            }
            this.appendLabel(builder);
            seg.getStandardString(0, this, builder);
            return 0;
        }

        /**
         * 
         * @param {number} segmentIndex
         * @param {{ str: string }} builder
         * @param {*} part
         * @return {number}
         */
        public appendSegment(segmentIndex? : any, builder? : any, part? : any) : any {
            if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((builder != null && (builder instanceof Object)) || builder === null) && ((part != null) || part === null)) {
                return <any>this.appendSegment$int$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(segmentIndex, builder, part);
            } else throw new Error('invalid overload');
        }

        appendSegment$int$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(segmentIndex : number, builder : { str: string }, part : T) : number {
            let seg : AddressStringDivision = part.getDivision(segmentIndex);
            return seg.getStandardString(segmentIndex, this, builder);
        }

        public getZoneLength(zone : any) : number {
            if(zone != null && zone.length > 0) {
                return zone.length + 1;
            }
            return 0;
        }

        public getStringLength$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(addr : T, zone : any) : number {
            let result : number = this.getStringLength(addr);
            if(zone != null) {
                result += this.getZoneLength(zone);
            }
            return result;
        }

        public getStringLength(addr? : any, zone? : any) : any {
            if(((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.getStringLength$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(addr, zone);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_format_AddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public getStringLength$inet_ipaddr_format_AddressStringDivisionSeries(addr : T) : number {
            return this.getAddressLabelLength() + this.getSegmentsStringLength(addr);
        }

        public appendZone(builder : { str: string }, zone : any) : { str: string } {
            if(zone != null && zone.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>zone); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.zoneSeparator); return sb; })(builder));
            }
            return builder;
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {IPv6AddressSection} addr
         * @param {*} zone
         * @return {{ str: string }}
         */
        public append(builder? : any, addr? : any, zone? : any) : any {
            if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && zone === undefined) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder, addr);
            } else throw new Error('invalid overload');
        }

        public append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(builder : { str: string }, addr : T, zone : any) : { str: string } {
            return this.appendZone(this.appendSegments(this.appendLabel(builder), addr), zone);
        }

        public append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder : { str: string }, addr : T) : { str: string } {
            return this.append(builder, addr, null);
        }

        /**
         * 
         * @param {*} seg
         * @return {number}
         */
        public getDivisionStringLength(seg : AddressStringDivision) : number {
            return this.appendSingleDivision(seg, null);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {*} seg
         * @return {{ str: string }}
         */
        public appendDivision(builder : { str: string }, seg : AddressStringDivision) : { str: string } {
            this.appendSingleDivision(seg, builder);
            return builder;
        }

        public toString$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(addr : T, zone : any) : string {
            let length : number = this.getStringLength(addr, zone);
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            this.append(builder, addr, zone);
            AddressStringParams.checkLengths(length, builder);
            return /* toString */builder.str;
        }

        public toString(addr? : any, zone? : any) : any {
            if(((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.toString$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(addr, zone);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.toString$inet_ipaddr_format_AddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public toString$inet_ipaddr_format_AddressStringDivisionSeries(addr : T) : string {
            return this.toString(addr, null);
        }

        public static checkLengths(length : number, builder : { str: string }) {
        }

        public static toParams(opts : AddressDivisionGrouping.StringOptions) : AddressDivisionGrouping.AddressStringParams<AddressStringDivisionSeries> {
            let result : AddressDivisionGrouping.AddressStringParams<AddressStringDivisionSeries> = <AddressDivisionGrouping.AddressStringParams<AddressStringDivisionSeries>><any>AddressDivisionGrouping.getCachedParams(opts);
            if(result == null) {
                result = <any>(new AddressDivisionGrouping.AddressStringParams<AddressStringDivisionSeries>(opts.base, opts.separator, opts.uppercase));
                result.expandSegments(opts.expandSegments);
                result.setWildcards(opts.wildcards);
                result.setSegmentStrPrefix(opts.segmentStrPrefix);
                result.setAddressLabel(opts.addrLabel);
                result.setReverse(opts.reverse);
                result.setSplitDigits(opts.splitDigits);
                AddressDivisionGrouping.setCachedParams(opts, result);
            }
            return result;
        }

        /**
         * 
         * @return {AddressDivisionGrouping.AddressStringParams}
         */
        public clone() : AddressDivisionGrouping.AddressStringParams<T> {
            try {
                let parms : AddressDivisionGrouping.AddressStringParams<T> = <AddressDivisionGrouping.AddressStringParams<T>>/* clone *//* clone */((o:any) => { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; })(this);
                return parms;
            } catch(e) {
                return null;
            };
        }
    }
    AddressStringParams["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.AddressStringParams";
    AddressStringParams["__interfaces"] = ["inet.ipaddr.format.util.AddressDivisionWriter","inet.ipaddr.format.util.AddressSegmentParams","java.lang.Cloneable"];



    /**
     * Represents a clear way to create a specific type of string.
     * 
     * @author sfoley
     * @class
     */
    export class StringOptions {
        public wildcards : StringOptions.Wildcards;

        public expandSegments : boolean;

        public base : number;

        public segmentStrPrefix : string;

        public separator : string;

        public addrLabel : string;

        public reverse : boolean;

        public splitDigits : boolean;

        public uppercase : boolean;

        cachedParams : AddressDivisionWriter;

        constructor(base : number, expandSegments : boolean, wildcards : StringOptions.Wildcards, segmentStrPrefix : string, separator : string, label : string, reverse : boolean, splitDigits : boolean, uppercase : boolean) {
            if(this.wildcards===undefined) this.wildcards = null;
            if(this.expandSegments===undefined) this.expandSegments = false;
            if(this.base===undefined) this.base = 0;
            if(this.segmentStrPrefix===undefined) this.segmentStrPrefix = null;
            if(this.separator===undefined) this.separator = null;
            if(this.addrLabel===undefined) this.addrLabel = null;
            if(this.reverse===undefined) this.reverse = false;
            if(this.splitDigits===undefined) this.splitDigits = false;
            if(this.uppercase===undefined) this.uppercase = false;
            if(this.cachedParams===undefined) this.cachedParams = null;
            this.expandSegments = expandSegments;
            this.wildcards = wildcards;
            this.base = base;
            if(segmentStrPrefix == null) {
                throw Object.defineProperty(new Error("segment str"), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
            }
            this.segmentStrPrefix = segmentStrPrefix;
            this.separator = separator;
            if(label == null) {
                throw Object.defineProperty(new Error("label"), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
            }
            this.addrLabel = label;
            this.reverse = reverse;
            this.splitDigits = splitDigits;
            this.uppercase = uppercase;
        }
    }
    StringOptions["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.StringOptions";


    export namespace StringOptions {

        export class Wildcards {
            public rangeSeparator : string;

            public wildcard : string;

            public singleWildcard : string;

            public constructor(rangeSeparator? : any, wildcard? : any, singleWildcard? : any) {
                if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && ((typeof singleWildcard === 'string') || singleWildcard === null)) {
                    let __args = Array.prototype.slice.call(arguments);
                    if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                    if(this.wildcard===undefined) this.wildcard = null;
                    if(this.singleWildcard===undefined) this.singleWildcard = null;
                    if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                    if(this.wildcard===undefined) this.wildcard = null;
                    if(this.singleWildcard===undefined) this.singleWildcard = null;
                    (() => {
                        if(rangeSeparator == null) {
                            rangeSeparator = Address.RANGE_SEPARATOR_STR_$LI$();
                        }
                        this.rangeSeparator = rangeSeparator;
                        this.wildcard = wildcard;
                        this.singleWildcard = singleWildcard;
                    })();
                } else if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && singleWildcard === undefined) {
                    let __args = Array.prototype.slice.call(arguments);
                    let wildcard : any = __args[0];
                    let singleWildcard : any = __args[1];
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let rangeSeparator : any = Address.RANGE_SEPARATOR_STR_$LI$();
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        (() => {
                            if(rangeSeparator == null) {
                                rangeSeparator = Address.RANGE_SEPARATOR_STR_$LI$();
                            }
                            this.rangeSeparator = rangeSeparator;
                            this.wildcard = wildcard;
                            this.singleWildcard = singleWildcard;
                        })();
                    }
                } else if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && wildcard === undefined && singleWildcard === undefined) {
                    let __args = Array.prototype.slice.call(arguments);
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let wildcard : any = null;
                        let singleWildcard : any = null;
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        (() => {
                            if(rangeSeparator == null) {
                                rangeSeparator = Address.RANGE_SEPARATOR_STR_$LI$();
                            }
                            this.rangeSeparator = rangeSeparator;
                            this.wildcard = wildcard;
                            this.singleWildcard = singleWildcard;
                        })();
                    }
                } else if(rangeSeparator === undefined && wildcard === undefined && singleWildcard === undefined) {
                    let __args = Array.prototype.slice.call(arguments);
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let rangeSeparator : any = Address.RANGE_SEPARATOR_STR_$LI$();
                        let wildcard : any = Address.SEGMENT_WILDCARD_STR_$LI$();
                        let singleWildcard : any = null;
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        if(this.rangeSeparator===undefined) this.rangeSeparator = null;
                        if(this.wildcard===undefined) this.wildcard = null;
                        if(this.singleWildcard===undefined) this.singleWildcard = null;
                        (() => {
                            if(rangeSeparator == null) {
                                rangeSeparator = Address.RANGE_SEPARATOR_STR_$LI$();
                            }
                            this.rangeSeparator = rangeSeparator;
                            this.wildcard = wildcard;
                            this.singleWildcard = singleWildcard;
                        })();
                    }
                } else throw new Error('invalid overload');
            }

            /**
             * 
             * @return {string}
             */
            public toString() : string {
                return "range separator: " + this.rangeSeparator + "\nwildcard: " + this.wildcard + "\nsingle wildcard: " + this.singleWildcard;
            }
        }
        Wildcards["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.StringOptions.Wildcards";


        export class Builder {
            public static DEFAULT_WILDCARDS : StringOptions.Wildcards; public static DEFAULT_WILDCARDS_$LI$() : StringOptions.Wildcards { if(Builder.DEFAULT_WILDCARDS == null) Builder.DEFAULT_WILDCARDS = new StringOptions.Wildcards(); return Builder.DEFAULT_WILDCARDS; };

            wildcards : StringOptions.Wildcards = Builder.DEFAULT_WILDCARDS_$LI$();

            expandSegments : boolean;

            base : number;

            segmentStrPrefix : string = "";

            separator : string;

            addrLabel : string = "";

            reverse : boolean;

            splitDigits : boolean;

            uppercase : boolean;

            constructor(base : number, separator : string) {
                if(this.expandSegments===undefined) this.expandSegments = false;
                if(this.base===undefined) this.base = 0;
                if(this.separator===undefined) this.separator = null;
                if(this.reverse===undefined) this.reverse = false;
                if(this.splitDigits===undefined) this.splitDigits = false;
                if(this.uppercase===undefined) this.uppercase = false;
                this.base = base;
                this.separator = separator;
            }

            public setWildcards(wildcards : StringOptions.Wildcards) : StringOptions.Builder {
                this.wildcards = wildcards;
                return this;
            }

            public setReverse(reverse : boolean) : StringOptions.Builder {
                this.reverse = reverse;
                return this;
            }

            public setUppercase(uppercase : boolean) : StringOptions.Builder {
                this.uppercase = uppercase;
                return this;
            }

            public setSplitDigits(splitDigits : boolean) : StringOptions.Builder {
                this.splitDigits = splitDigits;
                return this;
            }

            public setExpandedSegments(expandSegments : boolean) : StringOptions.Builder {
                this.expandSegments = expandSegments;
                return this;
            }

            public setRadix(base : number) : StringOptions.Builder {
                this.base = base;
                return this;
            }

            public setSeparator(separator : string) : StringOptions.Builder {
                this.separator = separator;
                return this;
            }

            public setAddressLabel(label : string) : StringOptions.Builder {
                this.addrLabel = label;
                return this;
            }

            public setSegmentStrPrefix(prefix : string) : StringOptions.Builder {
                this.segmentStrPrefix = prefix;
                return this;
            }

            public toOptions() : AddressDivisionGrouping.StringOptions {
                return new AddressDivisionGrouping.StringOptions(this.base, this.expandSegments, this.wildcards, this.segmentStrPrefix, this.separator, this.addrLabel, this.reverse, this.splitDigits, this.uppercase);
            }
        }
        Builder["__class"] = "inet.ipaddr.format.AddressDivisionGrouping.StringOptions.Builder";

    }


    export class AddressDivisionGrouping$0<R> {
        orig : R = this.original;

        /**
         * 
         * @return {*}
         */
        public next() : R {
            if(this.orig == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let result : R = this.orig;
            this.orig = null;
            return result;
        }

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.orig != null;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private original: any) {
        }
    }
    AddressDivisionGrouping$0["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivisionGrouping$1<R> {
        /**
         * 
         * @return {*}
         */
        public next() : R {
            if(!this.iterator.hasNext()) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let next : S[] = this.iterator.next();
            return <any>(AddressDivisionGrouping.createIteratedSection(next, this.creator, this.prefixLength));
        }

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.iterator.hasNext();
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private iterator: any, private creator: any, private prefixLength: any) {
        }
    }
    AddressDivisionGrouping$1["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivisionGrouping$2 {
        public __parent: any;
        result : S[];

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.result != null;
        }

        /**
         * 
         * @return {Array}
         */
        public next() : S[] {
            if(this.result == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let res : S[] = this.result;
            this.result = null;
            return res;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(__parent: any, private segSupplier: any, private excludeFunc: any) {
            this.__parent = __parent;
            this.result = (target => (typeof target === 'function')?target():(<any>target).get())(this.segSupplier);
            (() => {
                if(this.excludeFunc != null && (target => (typeof target === 'function')?target(this.result):(<any>target).test(this.result))(this.excludeFunc)) {
                    this.result = null;
                }
            })();
        }
    }
    AddressDivisionGrouping$2["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivisionGrouping$3 {
        public __parent: any;
        done : boolean;

        variations : any[];

        nextSet : S[];

        updateVariations(start : number) {
            let i : number = start;
            for(; i < this.hostSegmentIndex; i++) {
                this.variations[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(this.segIteratorProducer);
                this.nextSet[i] = this.variations[i].next();
            };
            if(i === this.networkSegmentIndex) {
                this.variations[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(this.prefixedSegIteratorProducer);
                this.nextSet[i] = this.variations[i].next();
            }
        }

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return !this.done;
        }

        /**
         * 
         * @return {Array}
         */
        public next() : S[] {
            if(this.done) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            return this.increment();
        }

        increment() : S[] {
            let previousSegs : S[] = null;
            for(let j : number = this.networkSegmentIndex; j >= 0; j--) {
                while((this.variations[j].hasNext())) {
                    if(previousSegs == null) {
                        previousSegs = /* clone */this.nextSet.slice(0);
                    }
                    this.nextSet[j] = this.variations[j].next();
                    this.updateVariations(j + 1);
                    if(this.excludeFunc != null && (target => (typeof target === 'function')?target(this.nextSet):(<any>target).test(this.nextSet))(this.excludeFunc)) {
                        j = this.networkSegmentIndex;
                    } else {
                        return previousSegs;
                    }
                };
            };
            this.done = true;
            return previousSegs == null?this.nextSet:previousSegs;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(__parent: any, private segmentCount: any, private segmentCreator: any, private networkSegmentIndex: any, private prefixedSegIteratorProducer: any, private excludeFunc: any, private hostSegmentIndex: any, private segIteratorProducer: any) {
            this.__parent = __parent;
            if(this.done===undefined) this.done = false;
            this.variations = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.segmentCount);
            this.nextSet = this.segmentCreator.createSegmentArray(this.segmentCount);
            (() => {
                this.updateVariations(0);
                for(let i : number = this.networkSegmentIndex + 1; i < this.segmentCount; i++) {
                    this.variations[i] = (target => (typeof target === 'function')?target(i):(<any>target).apply(i))(this.prefixedSegIteratorProducer);
                    this.nextSet[i] = this.variations[i].next();
                };
                if(this.excludeFunc != null && (target => (typeof target === 'function')?target(this.nextSet):(<any>target).test(this.nextSet))(this.excludeFunc)) {
                    this.increment();
                }
            })();
        }
    }
    AddressDivisionGrouping$3["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivisionGrouping$4<T> {
        orig : T = this.original;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.orig != null;
        }

        /**
         * 
         * @return {Address}
         */
        public next() : T {
            if(this.orig == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let result : T = this.orig;
            this.orig = null;
            return result;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private original: any) {
        }
    }
    AddressDivisionGrouping$4["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivisionGrouping$5<T> {
        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.iterator.hasNext();
        }

        /**
         * 
         * @return {Address}
         */
        public next() : T {
            if(!this.hasNext()) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let next : S[] = this.iterator.next();
            return this.prefixLength != null?this.creator.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(next, this.prefixLength, true):this.creator.createAddressInternal$inet_ipaddr_AddressSegment_A(next);
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private iterator: any, private prefixLength: any, private creator: any) {
        }
    }
    AddressDivisionGrouping$5["__interfaces"] = ["java.util.Iterator"];


}




AddressDivisionGrouping.StringOptions.Builder.DEFAULT_WILDCARDS_$LI$();

AddressDivisionGrouping.AddressStringParams.DEFAULT_WILDCARDS_$LI$();

AddressDivisionGrouping.bundle_$LI$();

AddressDivisionGrouping.LONG_MAX_$LI$();

AddressDivisionGrouping.__static_initialize();
