/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressSegment } from '../AddressSegment';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { IPAddress } from '../IPAddress';
import { AddressDivisionBase } from './AddressDivisionBase';
import { AddressComparator } from '../AddressComparator';
import { AddressNetwork } from '../AddressNetwork';
import { AddressSegmentParams } from './util/AddressSegmentParams';

/**
 * A division of an address.
 * 
 * @author sfoley
 * @extends AddressDivisionBase
 * @class
 */
export abstract class AddressDivision extends AddressDivisionBase {
    static __inet_ipaddr_format_AddressDivision_serialVersionUID : number = 4;

    constructor() {
        super();
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        let bitCount : number = this.getBitCount();
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })((bitCount + 7) >> 3);
        let byteIndex : number = bytes.length - 1;
        let bitIndex : number = 8;
        let segmentValue : number = low?this.getLowerValue():this.getUpperValue();
        while((true)) {
            bytes[byteIndex] |= segmentValue << (8 - bitIndex);
            segmentValue >>= bitIndex;
            if(bitCount <= bitIndex) {
                return bytes;
            }
            bitCount -= bitIndex;
            bitIndex = 8;
            byteIndex--;
        };
    }

    /**
     * @return {boolean} whether this segment represents multiple values
     */
    public isMultiple() : boolean {
        return this.getLowerValue() !== this.getUpperValue();
    }

    getMinPrefixLengthForBlock() : number {
        let result : number = this.getBitCount();
        let lowerZeros : number = javaemul.internal.LongHelper.numberOfTrailingZeros(this.getLowerValue());
        if(lowerZeros !== 0) {
            let upperOnes : number = javaemul.internal.LongHelper.numberOfTrailingZeros(~this.getUpperValue());
            if(upperOnes !== 0) {
                let prefixedBitCount : number = Math.min(lowerZeros, upperOnes);
                result -= prefixedBitCount;
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    getDefaultSegmentWildcardString() : string {
        return Address.SEGMENT_WILDCARD_STR_$LI$();
    }

    /**
     * 
     * @return {string}
     */
    getDefaultRangeSeparatorString() : string {
        return Address.RANGE_SEPARATOR_STR_$LI$();
    }

    public getMaxValue() : number {
        return ~(~0 << this.getBitCount());
    }

    /**
     * 
     * @return {boolean}
     */
    public isZero() : boolean {
        return !this.isMultiple() && this.includesZero();
    }

    /**
     * 
     * @return {boolean}
     */
    public includesZero() : boolean {
        return this.getLowerValue() === 0;
    }

    /**
     * 
     * @return {boolean}
     */
    public isMax() : boolean {
        return !this.isMultiple() && this.includesMax();
    }

    /**
     * 
     * @return {boolean}
     */
    public includesMax() : boolean {
        return this.getUpperValue() === this.getMaxValue();
    }

    public abstract getLowerValue() : number;

    public abstract getUpperValue() : number;

    public getDivisionValueCount() : number {
        return this.getUpperValue() - this.getLowerValue() + 1;
    }

    public getDivisionPrefixCount(divisionPrefixLength : number) : number {
        let shiftAdjustment : number = this.getBitCount() - divisionPrefixLength;
        return (this.getUpperValue() >>> shiftAdjustment) - (this.getLowerValue() >>> shiftAdjustment) + 1;
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getCount() : BigInteger {
        return BigInteger.valueOf(this.getDivisionValueCount());
    }

    static testRange(lowerValue : number, upperValue : number, finalUpperValue : number, networkMask : number, hostMask : number) : boolean {
        return lowerValue === (lowerValue & networkMask) && finalUpperValue === (upperValue | hostMask);
    }

    public isPrefixBlock$long$long$int(divisionValue : number, upperValue : number, divisionPrefixLen : number) : boolean {
        if(divisionPrefixLen === 0) {
            return this.isFullRange();
        }
        let ones : number = ~0;
        let divisionBitMask : number = ~(ones << this.getBitCount());
        let divisionPrefixMask : number = ones << (this.getBitCount() - divisionPrefixLen);
        let divisionNonPrefixMask : number = ~divisionPrefixMask;
        return AddressDivision.testRange(divisionValue, upperValue, upperValue, divisionPrefixMask & divisionBitMask, divisionNonPrefixMask);
    }

    /**
     * Returns whether the division range includes the block of values for its prefix length
     * @param {number} divisionValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isPrefixBlock(divisionValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof divisionValue === 'number') || divisionValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            return <any>this.isPrefixBlock$long$long$int(divisionValue, upperValue, divisionPrefixLen);
        } else throw new Error('invalid overload');
    }

    public isSinglePrefixBlock$long$long$int(divisionValue : number, upperValue : number, divisionPrefixLen : number) : boolean {
        let ones : number = ~0;
        let divisionBitMask : number = ~(ones << this.getBitCount());
        let divisionPrefixMask : number = ones << (this.getBitCount() - divisionPrefixLen);
        let divisionNonPrefixMask : number = ~divisionPrefixMask;
        return AddressDivision.testRange(divisionValue, divisionValue, upperValue, divisionPrefixMask & divisionBitMask, divisionNonPrefixMask);
    }

    /**
     * 
     * @param {number} divisionValue
     * @param {number} divisionPrefixLen
     * @return {boolean} whether the given range of segmentValue to upperValue is equivalent to the range of segmentValue with the prefix of divisionPrefixLen
     * @param {number} upperValue
     */
    public isSinglePrefixBlock(divisionValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof divisionValue === 'number') || divisionValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            return <any>this.isSinglePrefixBlock$long$long$int(divisionValue, upperValue, divisionPrefixLen);
        } else throw new Error('invalid overload');
    }

    /**
     * Returns true if the possible values of this division fall below the given value.
     * @param {number} value
     * @return {boolean}
     */
    public isBoundedBy(value : number) : boolean {
        return this.getUpperValue() < value;
    }

    /**
     * 
     * @param {number} value
     * @return {boolean}
     */
    public matches(value? : any) : any {
        if(((typeof value === 'number') || value === null)) {
            return <any>this.matches$long(value);
        } else throw new Error('invalid overload');
    }

    public matches$long(value : number) : boolean {
        return !this.isMultiple() && value === this.getLowerValue();
    }

    /**
     * 
     * @param {number} lowerValue
     * @param {number} upperValue
     * @param {number} mask
     * @return {boolean}
     */
    public matchesWithMask(lowerValue? : any, upperValue? : any, mask? : any) : any {
        if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof mask === 'number') || mask === null)) {
            return <any>this.matchesWithMask$long$long$long(lowerValue, upperValue, mask);
        } else if(((typeof lowerValue === 'number') || lowerValue === null) && ((typeof upperValue === 'number') || upperValue === null) && mask === undefined) {
            return <any>this.matchesWithMask$long$long(lowerValue, upperValue);
        } else throw new Error('invalid overload');
    }

    public matchesWithMask$long$long(value : number, mask : number) : boolean {
        if(this.isMultiple()) {
            let diffBits : number = this.getLowerValue() ^ this.getUpperValue();
            let leadingZeros : number = javaemul.internal.LongHelper.numberOfLeadingZeros(diffBits);
            let fullMask : number = ~0 >>> leadingZeros;
            if((fullMask & mask) !== 0) {
                return false;
            }
        }
        return value === (this.getLowerValue() & mask);
    }

    public matchesWithMask$long$long$long(lowerValue : number, upperValue : number, mask : number) : boolean {
        if(lowerValue === upperValue) {
            return this.matchesWithMask$long$long(lowerValue, mask);
        }
        if(!this.isMultiple()) {
            return false;
        }
        let thisValue : number = this.getLowerValue();
        let thisUpperValue : number = this.getUpperValue();
        if(!AddressDivision.isMaskCompatibleWithRange(thisValue, thisUpperValue, mask, this.getMaxValue())) {
            return false;
        }
        return lowerValue === (thisValue & mask) && upperValue === (thisUpperValue & mask);
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        return this.includesZero() && this.includesMax();
    }

    /**
     * 
     * @param {AddressDivision} other
     * @return {number}
     */
    public compareTo(other : AddressDivision) : number {
        return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$()['compare$inet_ipaddr_format_AddressDivision$inet_ipaddr_format_AddressDivision'](this, other);
    }

    static isMaskCompatibleWithRange(value : number, upperValue : number, maskValue : number, maxValue : number) : boolean {
        if(value === upperValue || maskValue === maxValue || maskValue === 0) {
            return true;
        }
        let differing : number = value ^ upperValue;
        let foundDiffering : boolean = (differing !== 0);
        let differingIsLowestBit : boolean = (differing === 1);
        if(foundDiffering && !differingIsLowestBit) {
            let highestDifferingBitInRange : number = javaemul.internal.LongHelper.numberOfLeadingZeros(differing);
            let maskMask : number = ~0 >>> highestDifferingBitInRange;
            let differingMasked : number = maskValue & maskMask;
            foundDiffering = (differingMasked !== 0);
            differingIsLowestBit = (differingMasked === 1);
            if(foundDiffering && !differingIsLowestBit) {
                let highestDifferingBitMasked : number = javaemul.internal.LongHelper.numberOfLeadingZeros(differingMasked);
                let hostMask : number = ~0 >>> (highestDifferingBitMasked + 1);
                if((maskValue & hostMask) !== hostMask) {
                    return false;
                }
                if(highestDifferingBitMasked > highestDifferingBitInRange) {
                    let hostMaskUpper : number = ~0 >>> highestDifferingBitMasked;
                    if((upperValue & hostMaskUpper) !== hostMaskUpper) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    static isBitwiseOrCompatibleWithRange(value : number, upperValue : number, maskValue : number, maxValue : number) : boolean {
        if(value === upperValue || maskValue === maxValue || maskValue === 0) {
            return true;
        }
        let differing : number = value ^ upperValue;
        let foundDiffering : boolean = (differing !== 0);
        let differingIsLowestBit : boolean = (differing === 1);
        if(foundDiffering && !differingIsLowestBit) {
            let highestDifferingBitInRange : number = javaemul.internal.LongHelper.numberOfLeadingZeros(differing);
            let maskMask : number = ~0 >>> highestDifferingBitInRange;
            let differingMasked : number = maskValue & maskMask;
            foundDiffering = (differingMasked !== maskMask);
            differingIsLowestBit = ((differingMasked | 1) === maskMask);
            if(foundDiffering && !differingIsLowestBit) {
                let highestDifferingBitMasked : number = javaemul.internal.LongHelper.numberOfLeadingZeros(~differingMasked & maskMask);
                let hostMask : number = ~0 >>> (highestDifferingBitMasked + 1);
                if((maskValue & hostMask) !== 0) {
                    return false;
                }
                if(highestDifferingBitMasked > highestDifferingBitInRange) {
                    let hostMaskLower : number = ~0 >>> highestDifferingBitMasked;
                    if((value & hostMaskLower) !== 0) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public hasUppercaseVariations(radix : number, lowerOnly : boolean) : boolean {
        if(radix <= 1) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }
        if(radix <= 10) {
            return false;
        }
        let isPowerOfTwo : boolean;
        let shift : number = 0;
        let mask : number = 0;
        switch((radix)) {
        case 16:
            isPowerOfTwo = true;
            shift = 4;
            mask = 15;
            break;
        default:
            isPowerOfTwo = (radix & (radix - 1)) === 0;
            if(isPowerOfTwo) {
                shift = javaemul.internal.IntegerHelper.numberOfTrailingZeros(radix);
                mask = ~(~0 << shift);
            }
        }
        let handledUpper : boolean = false;
        let value : number = this.getLowerValue();
        do {
            while((value > 0)) {
                let checkVal : number = isPowerOfTwo?(mask & value):(value % radix);
                if(checkVal >= 10) {
                    return true;
                }
                if(isPowerOfTwo) {
                    value >>>= shift;
                } else {
                    value /= radix;
                }
            };
            if(handledUpper || lowerOnly) {
                break;
            }
            value = this.getUpperValue();
            handledUpper = true;
        } while((true));
        return false;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getDigitCount(radix : number) : number {
        if(!this.isMultiple() && radix === this.getDefaultTextualRadix()) {
            return this.getWildcardString().length;
        }
        return AddressDivisionBase.getDigitCount$long$int(this.getUpperValue(), radix);
    }

    public getMaxDigitCount$int(radix : number) : number {
        let defaultRadix : number = this.getDefaultTextualRadix();
        if(radix === defaultRadix) {
            return this.getMaxDigitCount();
        }
        return AddressDivisionBase.getMaxDigitCount$int$int$long(radix, this.getBitCount(), this.getMaxValue());
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            return <any>this.getMaxDigitCount$int(radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @return {number}
     */
    adjustLowerLeadingZeroCount(leadingZeroCount : number, radix : number) : number {
        return this.adjustLeadingZeroCount(leadingZeroCount, this.getLowerValue(), radix);
    }

    /**
     * 
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @return {number}
     */
    adjustUpperLeadingZeroCount(leadingZeroCount : number, radix : number) : number {
        return this.adjustLeadingZeroCount(leadingZeroCount, this.getUpperValue(), radix);
    }

    /*private*/ adjustLeadingZeroCount(leadingZeroCount : number, value : number, radix : number) : number {
        if(leadingZeroCount < 0) {
            let width : number = AddressDivisionBase.getDigitCount$long$int(value, radix);
            return Math.max(0, this.getMaxDigitCount$int(radix) - width);
        }
        return leadingZeroCount;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getLowerStringLength(radix : number) : number {
        return AddressDivision.toUnsignedStringLength$long$int(this.getLowerValue(), radix);
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getUpperStringLength(radix : number) : number {
        return AddressDivision.toUnsignedStringLength$long$int(this.getUpperValue(), radix);
    }

    getLowerString$int$boolean$java_lang_StringBuilder(radix : number, uppercase : boolean, appendable : { str: string }) {
        AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(this.getLowerValue(), radix, 0, uppercase, uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$(), appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    getUpperString(radix : number, uppercase : boolean, appendable : { str: string }) {
        AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(this.getUpperValue(), radix, 0, uppercase, uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$(), appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    getUpperStringMasked(radix : number, uppercase : boolean, appendable : { str: string }) {
        this.getUpperString(radix, uppercase, appendable);
    }

    public getLowerString$int$int$boolean$java_lang_StringBuilder(radix : number, rangeDigits : number, uppercase : boolean, appendable : { str: string }) {
        AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(this.getLowerValue(), radix, rangeDigits, uppercase, uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$(), appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {number} rangeDigits
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    public getLowerString(radix? : any, rangeDigits? : any, uppercase? : any, appendable? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof rangeDigits === 'number') || rangeDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getLowerString$int$int$boolean$java_lang_StringBuilder(radix, rangeDigits, uppercase, appendable);
        } else if(((typeof radix === 'number') || radix === null) && ((typeof rangeDigits === 'boolean') || rangeDigits === null) && ((uppercase != null && (uppercase instanceof Object)) || uppercase === null) && appendable === undefined) {
            return <any>this.getLowerString$int$boolean$java_lang_StringBuilder(radix, rangeDigits, uppercase);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} radix
     * @param {number} choppedDigits
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @param {{ str: string }} appendable
     */
    getSplitLowerString(radix : number, choppedDigits : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        AddressDivision.toSplitUnsignedString(this.getLowerValue(), radix, choppedDigits, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
    }

    public getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator : string, wildcard : string, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        AddressDivision.toUnsignedSplitRangeString(this.getLowerValue(), this.getUpperValue(), rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
    }

    /**
     * 
     * @param {string} rangeSeparator
     * @param {string} wildcard
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @param {{ str: string }} appendable
     */
    public getSplitRangeString(rangeSeparator? : any, wildcard? : any, radix? : any, uppercase? : any, splitDigitSeparator? : any, reverseSplitDigits? : any, stringPrefix? : any, appendable? : any) : any {
        if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && ((typeof radix === 'number') || radix === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof reverseSplitDigits === 'boolean') || reverseSplitDigits === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
        } else if(((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((wildcard != null && (wildcard["__interfaces"] != null && wildcard["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0 || wildcard.constructor != null && wildcard.constructor["__interfaces"] != null && wildcard.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0)) || wildcard === null) && ((radix != null && (radix instanceof Object)) || radix === null) && uppercase === undefined && splitDigitSeparator === undefined && reverseSplitDigits === undefined && stringPrefix === undefined && appendable === undefined) {
            return <any>this.getSplitRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(rangeSeparator, wildcard, radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {string} rangeSeparator
     * @param {string} wildcard
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @return {number}
     */
    getSplitRangeStringLength(rangeSeparator : string, wildcard : string, leadingZeroCount : number, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string) : number {
        return AddressDivision.toUnsignedSplitRangeStringLength(this.getLowerValue(), this.getUpperValue(), rangeSeparator, wildcard, leadingZeroCount, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix);
    }

    /**
     * 
     * @return {string}
     */
    getDefaultString() : string {
        return AddressDivision.toDefaultString(this.getLowerValue(), this.getDefaultTextualRadix());
    }

    getDefaultRangeString$() : string {
        return this.getDefaultRangeString$long$long$int(this.getLowerValue(), this.getUpperValue(), this.getDefaultTextualRadix());
    }

    public getDefaultRangeString$long$long$int(val1 : number, val2 : number, radix : number) : string {
        let len1 : number;
        let len2 : number;
        let value1 : number;
        let value2 : number;
        let quotient : number;
        let remainder : number;
        if(radix === 10) {
            if(val2 < 10) {
                len2 = 1;
            } else if(val2 < 100) {
                len2 = 2;
            } else if(val2 < 1000) {
                len2 = 3;
            } else {
                return this.buildDefaultRangeString(radix);
            }
            value2 = (<number>val2|0);
            if(val1 < 10) {
                len1 = 1;
            } else if(val1 < 100) {
                len1 = 2;
            } else if(val1 < 1000) {
                len1 = 3;
            } else {
                return this.buildDefaultRangeString(radix);
            }
            value1 = (<number>val1|0);
            len2 += len1 + 1;
            let chars : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(len2);
            chars[len1] = IPAddress.RANGE_SEPARATOR;
            let dig : string[] = AddressDivisionBase.DIGITS_$LI$();
            do {
                quotient = (value1 * 52429) >>> 19;
                remainder = value1 - ((quotient << 3) + (quotient << 1));
                chars[--len1] = dig[remainder];
                value1 = quotient;
            } while((value1 !== 0));
            do {
                quotient = (value2 * 52429) >>> 19;
                remainder = value2 - ((quotient << 3) + (quotient << 1));
                chars[--len2] = dig[remainder];
                value2 = quotient;
            } while((value2 !== 0));
            return chars.join('');
        }
        if(radix === 16) {
            if(val2 < 16) {
                len2 = 1;
            } else if(val2 < 256) {
                len2 = 2;
            } else if(val2 < 4096) {
                len2 = 3;
            } else if(val2 < 65536) {
                len2 = 4;
            } else {
                return this.buildDefaultRangeString(radix);
            }
            value2 = (<number>val2|0);
            if(val1 < 16) {
                len1 = 1;
            } else if(val1 < 256) {
                len1 = 2;
            } else if(val1 < 4096) {
                len1 = 3;
            } else if(val1 < 65536) {
                len1 = 4;
            } else {
                return this.buildDefaultRangeString(radix);
            }
            value1 = (<number>val1|0);
            len2 += len1 + 1;
            let chars : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(len2);
            chars[len1] = IPAddress.RANGE_SEPARATOR;
            let dig : string[] = AddressDivisionBase.DIGITS_$LI$();
            do {
                quotient = value1 >>> 4;
                remainder = value1 - (quotient << 4);
                chars[--len1] = dig[remainder];
                value1 = quotient;
            } while((value1 !== 0));
            do {
                quotient = value2 >>> 4;
                remainder = value2 - (quotient << 4);
                chars[--len2] = dig[remainder];
                value2 = quotient;
            } while((value2 !== 0));
            return chars.join('');
        }
        return this.buildDefaultRangeString(radix);
    }

    public getDefaultRangeString(val1? : any, val2? : any, radix? : any) : any {
        if(((typeof val1 === 'number') || val1 === null) && ((typeof val2 === 'number') || val2 === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>this.getDefaultRangeString$long$long$int(val1, val2, radix);
        } else if(val1 === undefined && val2 === undefined && radix === undefined) {
            return <any>this.getDefaultRangeString$();
        } else throw new Error('invalid overload');
    }

    /*private*/ buildDefaultRangeString(radix : number) : string {
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        this.getRangeString$java_lang_String$int$int$java_lang_String$int$boolean$boolean$java_lang_StringBuilder(IPAddress.RANGE_SEPARATOR_STR_$LI$(), 0, 0, "", radix, false, false, builder);
        return /* toString */builder.str;
    }

    static toDefaultString(val : number, radix : number) : string {
        if(val === 0) {
            return "0";
        }
        if(val === 1) {
            return "1";
        }
        let len : number;
        let quotient : number;
        let remainder : number;
        let value : number;
        if(radix === 10) {
            if(val < 10) {
                return /* valueOf */((str, index, len) => str.join('').substring(index, index + len))(AddressDivisionBase.DIGITS_$LI$(), (<number>val|0), 1);
            } else if(val < 100) {
                len = 2;
                value = (<number>val|0);
            } else if(val < 1000) {
                len = 3;
                value = (<number>val|0);
            } else {
                return /* toString */(''+(val));
            }
            let chars : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(len);
            let dig : string[] = AddressDivisionBase.DIGITS_$LI$();
            do {
                quotient = (value * 52429) >>> 19;
                remainder = value - ((quotient << 3) + (quotient << 1));
                chars[--len] = dig[remainder];
                value = quotient;
            } while((value !== 0));
            return chars.join('');
        }
        if(radix === 16) {
            if(val < 16) {
                return /* valueOf */((str, index, len) => str.join('').substring(index, index + len))(AddressDivisionBase.DIGITS_$LI$(), (<number>val|0), 1);
            } else if(val < 256) {
                len = 2;
                value = (<number>val|0);
            } else if(val < 4096) {
                len = 3;
                value = (<number>val|0);
            } else if(val < 65536) {
                if(val === 65535) {
                    return "ffff";
                }
                value = (<number>val|0);
                len = 4;
            } else {
                return /* toString */(''+(val));
            }
            let chars : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(len);
            let dig : string[] = AddressDivisionBase.DIGITS_$LI$();
            do {
                quotient = value >>> 4;
                remainder = value - (quotient << 4);
                chars[--len] = dig[remainder];
                value = quotient;
            } while((value !== 0));
            return chars.join('');
        }
        return /* toString */(''+(val));
    }

    public static toUnsignedStringFast$int$int$int$boolean$char_A$java_lang_StringBuilder(value : number, radix : number, choppedDigits : number, uppercase : boolean, dig : string[], appendable : { str: string }) : boolean {
        if(AddressDivision.toUnsignedStringFast$int$int$boolean$char_A$java_lang_StringBuilder(value, radix, uppercase, dig, appendable)) {
            if(choppedDigits > 0) {
                /* setLength */((sb, length) => sb.str = sb.str.substring(0, length))(appendable, /* length */appendable.str.length - choppedDigits);
            }
            return true;
        }
        return false;
    }

    public static toUnsignedStringFast(value? : any, radix? : any, choppedDigits? : any, uppercase? : any, dig? : any, appendable? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((dig != null && dig instanceof <any>Array && (dig.length==0 || dig[0] == null ||(typeof dig[0] === 'string'))) || dig === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>AddressDivision.toUnsignedStringFast$int$int$int$boolean$char_A$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, dig, appendable);
        } else if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'boolean') || choppedDigits === null) && ((uppercase != null && uppercase instanceof <any>Array && (uppercase.length==0 || uppercase[0] == null ||(typeof uppercase[0] === 'string'))) || uppercase === null) && ((dig != null && (dig instanceof Object)) || dig === null) && appendable === undefined) {
            return <any>AddressDivision.toUnsignedStringFast$int$int$boolean$char_A$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, dig);
        } else throw new Error('invalid overload');
    }

    /*private*/ static toUnsignedStringFast$int$int$boolean$char_A$java_lang_StringBuilder(value : number, radix : number, uppercase : boolean, dig : string[], appendable : { str: string }) : boolean {
        if(value <= 1) {
            if(value === 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'0'); return sb; })(appendable);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>'1'); return sb; })(appendable);
            }
            return true;
        }
        let quotient : number;
        let remainder : number;
        if(radix === 10) {
            if(value < 10) {
                /* append */(sb => { sb.str = sb.str.concat(<any>dig[value]); return sb; })(appendable);
                return true;
            } else if(value < 100) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"  "); return sb; })(appendable);
            } else if(value < 1000) {
                if(value === 127) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>"127"); return sb; })(appendable);
                    return true;
                }
                if(value === 255) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>"255"); return sb; })(appendable);
                    return true;
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>"   "); return sb; })(appendable);
            } else if(value < 10000) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"    "); return sb; })(appendable);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>"     "); return sb; })(appendable);
            }
            let index : number = /* length */appendable.str.length;
            do {
                quotient = (value * 52429) >>> 19;
                remainder = value - ((quotient << 3) + (quotient << 1));
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, --index, dig[remainder]);
                value = quotient;
            } while((value !== 0));
            return true;
        }
        if(radix === 16) {
            if(value < 10) {
                /* append */(sb => { sb.str = sb.str.concat(<any>dig[value]); return sb; })(appendable);
                return true;
            } else if(value < 16) {
                /* append */(sb => { sb.str = sb.str.concat(<any>dig[value]); return sb; })(appendable);
                return true;
            } else if(value < 256) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"  "); return sb; })(appendable);
            } else if(value < 4096) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"   "); return sb; })(appendable);
            } else {
                if(value === 65535) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>uppercase?"FFFF":"ffff"); return sb; })(appendable);
                    return true;
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>"    "); return sb; })(appendable);
            }
            let index : number = /* length */appendable.str.length;
            do {
                quotient = value >>> 4;
                remainder = value - (quotient << 4);
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, --index, dig[remainder]);
                value = quotient;
            } while((value !== 0));
            return true;
        }
        if(radix === 8) {
            if(value < 8) {
                /* append */(sb => { sb.str = sb.str.concat(<any>dig[value]); return sb; })(appendable);
                return true;
            } else if(value < 64) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"  "); return sb; })(appendable);
            } else if(value < 512) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"   "); return sb; })(appendable);
            } else if(value < 4096) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"    "); return sb; })(appendable);
            } else if(value < 32768) {
                /* append */(sb => { sb.str = sb.str.concat(<any>"     "); return sb; })(appendable);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>"      "); return sb; })(appendable);
            }
            let index : number = /* length */appendable.str.length;
            do {
                quotient = value >>> 3;
                remainder = value - (quotient << 3);
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, --index, dig[remainder]);
                value = quotient;
            } while((value !== 0));
            return true;
        }
        if(radix === 2) {
            let digitCount : number = 15;
            let val : number = value;
            if(val >>> 8 === 0) {
                digitCount -= 8;
            } else {
                val >>>= 8;
            }
            if(val >>> 4 === 0) {
                digitCount -= 4;
            } else {
                val >>>= 4;
            }
            if(val >>> 2 === 0) {
                digitCount -= 2;
            } else {
                val >>>= 2;
            }
            if((val & 2) === 0) {
                --digitCount;
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>'1'); return sb; })(appendable);
            while((digitCount > 0)) {
                let c : string = dig[(value >>> --digitCount) & 1];
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(appendable);
            };
            return true;
        }
        return false;
    }

    public static toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(value : number, radix : number, choppedDigits : number, uppercase : boolean, dig : string[], appendable : { str: string }) : { str: string } {
        if(value > 65535 || !AddressDivision.toUnsignedStringFast$int$int$int$boolean$char_A$java_lang_StringBuilder((<number>value|0), radix, choppedDigits, uppercase, dig, appendable)) {
            AddressDivision.toUnsignedString$long$int$int$char_A$java_lang_StringBuilder(value, radix, choppedDigits, dig, appendable);
        }
        return appendable;
    }

    public static toUnsignedString(value? : any, radix? : any, choppedDigits? : any, uppercase? : any, dig? : any, appendable? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((dig != null && dig instanceof <any>Array && (dig.length==0 || dig[0] == null ||(typeof dig[0] === 'string'))) || dig === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, dig, appendable);
        } else if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((uppercase != null && uppercase instanceof <any>Array && (uppercase.length==0 || uppercase[0] == null ||(typeof uppercase[0] === 'string'))) || uppercase === null) && ((dig != null && (dig instanceof Object)) || dig === null) && appendable === undefined) {
            return <any>AddressDivision.toUnsignedString$long$int$int$char_A$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, dig);
        } else throw new Error('invalid overload');
    }

    /*private*/ static toUnsignedSplitRangeStringLength(lower : number, upper : number, rangeSeparator : string, wildcard : string, leadingZerosCount : number, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string) : number {
        let digitsLength : number = -1;
        let stringPrefixLength : number = stringPrefix.length;
        do {
            let upperDigit : number = (<number>(upper % radix)|0);
            let lowerDigit : number = (<number>(lower % radix)|0);
            let isFull : boolean = (lowerDigit === 0) && (upperDigit === radix - 1);
            if(isFull) {
                digitsLength += wildcard.length + 1;
            } else {
                digitsLength += (stringPrefixLength << 1) + 4;
            }
            upper /= radix;
            lower /= radix;
        } while((upper !== lower));
        let remaining : number = (upper === 0)?0:AddressDivision.toUnsignedStringLength$long$int(upper, radix);
        remaining += leadingZerosCount;
        if(remaining > 0) {
            digitsLength += remaining * (stringPrefixLength + 2);
        }
        return digitsLength;
    }

    public static toUnsignedStringLength(value? : any, radix? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>AddressDivision.toUnsignedStringLength$long$int(value, radix);
        } else throw new Error('invalid overload');
    }

    static toUnsignedStringLength$long$int(value : number, radix : number) : number {
        let result : number;
        if(value > 65535 || (result = AddressDivision.toUnsignedStringLengthFast((<number>value|0), radix)) < 0) {
            result = AddressDivision.toUnsignedStringLengthSlow(value, radix);
        }
        return result;
    }

    /*private*/ static toUnsignedStringLengthSlow(value : number, radix : number) : number {
        let count : number = 1;
        let useInts : boolean = value <= Number.MAX_VALUE;
        let value2 : number = useInts?(<number>value|0):radix;
        while((value2 >= radix)) {
            if(useInts) {
                value2 /= radix;
            } else {
                value /= radix;
                if(value <= Number.MAX_VALUE) {
                    useInts = true;
                    value2 = (<number>value|0);
                }
            }
            ++count;
        };
        return count;
    }

    static toUnsignedStringLengthFast(value : number, radix : number) : number {
        if(value <= 1) {
            return 1;
        }
        if(radix === 10) {
            if(value < 10) {
                return 1;
            } else if(value < 100) {
                return 2;
            } else if(value < 1000) {
                return 3;
            } else if(value < 10000) {
                return 4;
            }
            return 5;
        }
        if(radix === 16) {
            if(value < 16) {
                return 1;
            } else if(value < 256) {
                return 2;
            } else if(value < 4096) {
                return 3;
            }
            return 4;
        }
        if(radix === 8) {
            if(value < 8) {
                return 1;
            } else if(value < 64) {
                return 2;
            } else if(value < 512) {
                return 3;
            } else if(value < 4096) {
                return 4;
            } else if(value < 32768) {
                return 5;
            }
            return 6;
        }
        if(radix === 2) {
            let digitCount : number = 15;
            let val : number = value;
            if(val >>> 8 === 0) {
                digitCount -= 8;
            } else {
                val >>>= 8;
            }
            if(val >>> 4 === 0) {
                digitCount -= 4;
            } else {
                val >>>= 4;
            }
            if(val >>> 2 === 0) {
                digitCount -= 2;
            } else {
                val >>>= 2;
            }
            if((val & 2) !== 0) {
                ++digitCount;
            }
            return digitCount;
        }
        return -1;
    }

    /*private*/ static toUnsignedString$long$int$int$char_A$java_lang_StringBuilder(value : number, radix : number, choppedDigits : number, dig : string[], appendable : { str: string }) {
        let front : number = /* length */appendable.str.length;
        AddressDivision.appendDigits$long$int$int$char_A$java_lang_StringBuilder(value, radix, choppedDigits, dig, appendable);
        let back : number = /* length */appendable.str.length - 1;
        while((front < back)) {
            let frontChar : string = /* charAt */appendable.str.charAt(front);
            /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, front++, /* charAt */appendable.str.charAt(back));
            /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, back--, frontChar);
        };
    }

    /*private*/ static toSplitUnsignedString(value : number, radix : number, choppedDigits : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        let front : number = /* length */appendable.str.length;
        AddressDivision.appendDigits$long$int$int$boolean$char$java_lang_String$java_lang_StringBuilder(value, radix, choppedDigits, uppercase, splitDigitSeparator, stringPrefix, appendable);
        if(!reverseSplitDigits) {
            let back : number = /* length */appendable.str.length - 1;
            let stringPrefixLen : number = stringPrefix.length;
            front += stringPrefixLen;
            while((front < back)) {
                let frontChar : string = /* charAt */appendable.str.charAt(front);
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, front, /* charAt */appendable.str.charAt(back));
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, back, frontChar);
                front += 2;
                back -= 2;
                front += stringPrefixLen;
                back -= stringPrefixLen;
            };
        }
    }

    /*private*/ static toUnsignedSplitRangeString(lower : number, upper : number, rangeSeparator : string, wildcard : string, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        let front : number = /* length */appendable.str.length;
        AddressDivision.appendDigits$long$long$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(lower, upper, rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
        if(!reverseSplitDigits) {
            let back : number = /* length */appendable.str.length - 1;
            while((front < back)) {
                let frontChar : string = /* charAt */appendable.str.charAt(front);
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, front++, /* charAt */appendable.str.charAt(back));
                /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(appendable, back--, frontChar);
            };
        }
    }

    /*private*/ static appendDigits$long$int$int$char_A$java_lang_StringBuilder(value : number, radix : number, choppedDigits : number, dig : string[], appendable : { str: string }) {
        let useInts : boolean = value <= Number.MAX_VALUE;
        let value2 : number = useInts?(<number>value|0):radix;
        let index : number;
        while((value2 >= radix)) {
            if(useInts) {
                let val2 : number = value2;
                value2 /= radix;
                if(choppedDigits > 0) {
                    choppedDigits--;
                    continue;
                }
                index = val2 % radix;
            } else {
                let val : number = value;
                value /= radix;
                if(value <= Number.MAX_VALUE) {
                    useInts = true;
                    value2 = (<number>value|0);
                }
                if(choppedDigits > 0) {
                    choppedDigits--;
                    continue;
                }
                index = (<number>(val % radix)|0);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>dig[index]); return sb; })(appendable);
        };
        if(choppedDigits === 0) {
            /* append */(sb => { sb.str = sb.str.concat(<any>dig[value2]); return sb; })(appendable);
        }
    }

    /*private*/ static appendDigits$long$int$int$boolean$char$java_lang_String$java_lang_StringBuilder(value : number, radix : number, choppedDigits : number, uppercase : boolean, splitDigitSeparator : string, stringPrefix : string, appendable : { str: string }) {
        let useInts : boolean = value <= Number.MAX_VALUE;
        let value2 : number = useInts?(<number>value|0):radix;
        let dig : string[] = uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$();
        let index : number;
        let prefLen : number = stringPrefix.length;
        while((value2 >= radix)) {
            if(useInts) {
                let val : number = value2;
                value2 /= radix;
                if(choppedDigits > 0) {
                    choppedDigits--;
                    continue;
                }
                index = val % radix;
            } else {
                let val : number = value;
                value /= radix;
                if(value <= Number.MAX_VALUE) {
                    useInts = true;
                    value2 = (<number>value|0);
                }
                if(choppedDigits > 0) {
                    choppedDigits--;
                    continue;
                }
                index = (<number>(val % radix)|0);
            }
            if(prefLen > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>dig[index]); return sb; })(appendable);
            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
        };
        if(choppedDigits === 0) {
            if(prefLen > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>dig[value2]); return sb; })(appendable);
        }
    }

    public static appendDigits$long$long$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(lower : number, upper : number, rangeSeparator : string, wildcard : string, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        let dig : string[] = uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$();
        let previousWasFullRange : boolean = true;
        let useInts : boolean = upper <= Number.MAX_VALUE;
        let upperInt : number;
        let lowerInt : number;
        if(useInts) {
            upperInt = (<number>upper|0);
            lowerInt = (<number>lower|0);
        } else {
            upperInt = lowerInt = radix;
        }
        let prefLen : number = stringPrefix.length;
        while((true)) {
            let upperDigit : number;
            let lowerDigit : number;
            if(useInts) {
                let ud : number = upperInt;
                upperDigit = upperInt % radix;
                upperInt /= radix;
                if(ud === lowerInt) {
                    lowerInt = upperInt;
                    lowerDigit = upperDigit;
                } else {
                    lowerDigit = lowerInt % radix;
                    lowerInt /= radix;
                }
            } else {
                let ud : number = upper;
                upperDigit = (<number>(upper % radix)|0);
                upper /= radix;
                if(ud === lower) {
                    lower = upper;
                    lowerDigit = upperDigit;
                } else {
                    lowerDigit = (<number>(lower % radix)|0);
                    lower /= radix;
                }
                if(upper <= Number.MAX_VALUE) {
                    useInts = true;
                    upperInt = (<number>upper|0);
                    lowerInt = (<number>lower|0);
                }
            }
            if(lowerDigit === upperDigit) {
                previousWasFullRange = false;
                if(reverseSplitDigits) {
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>dig[lowerDigit]); return sb; })(appendable);
                } else {
                    /* append */(sb => { sb.str = sb.str.concat(<any>dig[lowerDigit]); return sb; })(appendable);
                    for(let k : number = prefLen - 1; k >= 0; k--) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix.charAt(k)); return sb; })(appendable);
                    };
                }
            } else {
                if(!previousWasFullRange) {
                    throw new IncompatibleAddressException(lower, upper, "ipaddress.error.splitMismatch");
                }
                previousWasFullRange = (lowerDigit === 0) && (upperDigit === radix - 1);
                if(previousWasFullRange && wildcard != null) {
                    if(reverseSplitDigits) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>wildcard); return sb; })(appendable);
                    } else {
                        for(let k : number = wildcard.length - 1; k >= 0; k--) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>wildcard.charAt(k)); return sb; })(appendable);
                        };
                    }
                } else {
                    if(reverseSplitDigits) {
                        if(prefLen > 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                        }
                        /* append */(sb => { sb.str = sb.str.concat(<any>dig[lowerDigit]); return sb; })(appendable);
                        /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
                        /* append */(sb => { sb.str = sb.str.concat(<any>dig[upperDigit]); return sb; })(appendable);
                    } else {
                        /* append */(sb => { sb.str = sb.str.concat(<any>dig[upperDigit]); return sb; })(appendable);
                        /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
                        /* append */(sb => { sb.str = sb.str.concat(<any>dig[lowerDigit]); return sb; })(appendable);
                        for(let k : number = prefLen - 1; k >= 0; k--) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix.charAt(k)); return sb; })(appendable);
                        };
                    }
                }
            }
            if(upperInt === 0) {
                break;
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
        };
    }

    public static appendDigits(lower? : any, upper? : any, rangeSeparator? : any, wildcard? : any, radix? : any, uppercase? : any, splitDigitSeparator? : any, reverseSplitDigits? : any, stringPrefix? : any, appendable? : any) : any {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && ((typeof radix === 'number') || radix === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof reverseSplitDigits === 'boolean') || reverseSplitDigits === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>AddressDivision.appendDigits$long$long$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(lower, upper, rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((typeof wildcard === 'boolean') || wildcard === null) && ((typeof radix === 'string') || radix === null) && ((typeof uppercase === 'string') || uppercase === null) && ((splitDigitSeparator != null && (splitDigitSeparator instanceof Object)) || splitDigitSeparator === null) && reverseSplitDigits === undefined && stringPrefix === undefined && appendable === undefined) {
            return <any>AddressDivision.appendDigits$long$int$int$boolean$char$java_lang_String$java_lang_StringBuilder(lower, upper, rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator);
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((wildcard != null && wildcard instanceof <any>Array && (wildcard.length==0 || wildcard[0] == null ||(typeof wildcard[0] === 'string'))) || wildcard === null) && ((radix != null && (radix instanceof Object)) || radix === null) && uppercase === undefined && splitDigitSeparator === undefined && reverseSplitDigits === undefined && stringPrefix === undefined && appendable === undefined) {
            return <any>AddressDivision.appendDigits$long$int$int$char_A$java_lang_StringBuilder(lower, upper, rangeSeparator, wildcard, radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getRangeDigitCount(radix : number) : number {
        if(!this.isMultiple()) {
            return 0;
        }
        if(radix === this.getDefaultTextualRadix()) {
            return this.getRangeDigitCountImpl();
        }
        return AddressDivision.calculateRangeDigitCount(radix, this.getLowerValue(), this.getUpperValue(), this.getMaxValue());
    }

    getRangeDigitCountImpl() : number {
        return AddressDivision.calculateRangeDigitCount(this.getDefaultTextualRadix(), this.getLowerValue(), this.getUpperValue(), this.getMaxValue());
    }

    /*private*/ static calculateRangeDigitCount(radix : number, value : number, upperValue : number, maxValue : number) : number {
        let factor : number = radix;
        let numDigits : number = 1;
        while((true)) {
            let lowerRemainder : number = value % factor;
            if(lowerRemainder === 0) {
                let max : number = ((n => n<0?Math.ceil(n):Math.floor(n))(maxValue / factor) === (n => n<0?Math.ceil(n):Math.floor(n))(upperValue / factor))?maxValue % factor:factor - 1;
                let upperRemainder : number = upperValue % factor;
                if(upperRemainder === max) {
                    if(upperValue - upperRemainder === value) {
                        return numDigits;
                    } else {
                        numDigits++;
                        factor *= radix;
                        continue;
                    }
                }
            }
            return 0;
        };
    }

    public static reverseBits$byte(b : number) : number {
        let x : number = b;
        x = ((x & 170) >>> 1) | ((x & 85) << 1);
        x = ((x & 204) >>> 2) | ((x & 51) << 2);
        x = (255 & ((x >>> 4) | (x << 4)));
        return x;
    }

    public static reverseBits(b? : any) : any {
        if(((typeof b === 'number') || b === null)) {
            return <any>AddressDivision.reverseBits$byte(b);
        } else if(((typeof b === 'number') || b === null)) {
            return <any>AddressDivision.reverseBits$short(b);
        } else if(((typeof b === 'number') || b === null)) {
            return <any>AddressDivision.reverseBits$int(b);
        } else throw new Error('invalid overload');
    }

    static reverseBits$short(b : number) : number {
        let x : number = b;
        x = ((x & 43690) >>> 1) | ((x & 21845) << 1);
        x = ((x & 52428) >>> 2) | ((x & 13107) << 2);
        x = ((x & 61680) >>> 4) | ((x & 3855) << 4);
        return 65535 & ((x >>> 8) | (x << 8));
    }

    static reverseBits$int(i : number) : number {
        let x : number = i;
        x = ((x & -1431655766) >>> 1) | ((x & 1431655765) << 1);
        x = ((x & -858993460) >>> 2) | ((x & 858993459) << 2);
        x = ((x & -252645136) >>> 4) | ((x & 252645135) << 4);
        x = ((x & -16711936) >>> 8) | ((x & 16711935) << 8);
        return (x >>> 16) | (x << 16);
    }

    static iterator<S extends AddressSegment>(original : S, creator : AddressNetwork.AddressSegmentCreator<S>, returnThisSegment : boolean, networkIteratorSegmentPrefixLength : number) : any {
        let useShiftAdjustment : boolean = networkIteratorSegmentPrefixLength != null;
        let shiftAdjustment : number;
        let shiftMask : number;
        let upperShiftMask : number;
        let lower : number = original.getLowerSegmentValue();
        let upper : number = original.getUpperSegmentValue();
        if(useShiftAdjustment) {
            shiftAdjustment = original.getBitCount() - networkIteratorSegmentPrefixLength;
            shiftMask = ~0 << shiftAdjustment;
            upperShiftMask = ~shiftMask;
            if(returnThisSegment) {
                let newLow : number = shiftMask & lower;
                let newUp : number = upper | upperShiftMask;
                if(lower !== newLow || upper !== newUp) {
                    returnThisSegment = false;
                    lower = newLow;
                    upper = newUp;
                }
            }
        } else {
            shiftAdjustment = shiftMask = upperShiftMask = 0;
        }
        let returnThis : boolean = returnThisSegment;
        let lowerValue : number = lower;
        let upperValue : number = upper;
        if(!original.isMultiple()) {
            return new AddressDivision.AddressDivision$0<S>(returnThis, creator, lowerValue, upperValue, networkIteratorSegmentPrefixLength, original);
        }
        return new AddressDivision.AddressDivision$1<S>(lowerValue, upperValue, useShiftAdjustment, shiftAdjustment, creator, upperShiftMask, networkIteratorSegmentPrefixLength);
    }

    static setPrefixedSegment<S extends AddressSegment>(original : S, oldSegmentPrefixLength : number, newSegmentPrefixLength : number, zeroed : boolean, creator : AddressNetwork.AddressSegmentCreator<S>) : S {
        if(Objects.equals(oldSegmentPrefixLength, newSegmentPrefixLength)) {
            return original;
        }
        let newLower : number;
        let newUpper : number;
        if(zeroed) {
            let prefixMask : number;
            let bitCount : number = original.getBitCount();
            let allOnes : number = ~0;
            if(oldSegmentPrefixLength != null) {
                if(newSegmentPrefixLength == null) {
                    prefixMask = allOnes << (bitCount - oldSegmentPrefixLength);
                } else if(oldSegmentPrefixLength > newSegmentPrefixLength) {
                    prefixMask = allOnes << (bitCount - newSegmentPrefixLength);
                    prefixMask |= ~(allOnes << (bitCount - oldSegmentPrefixLength));
                } else {
                    prefixMask = allOnes << (bitCount - oldSegmentPrefixLength);
                    prefixMask |= ~(allOnes << (bitCount - newSegmentPrefixLength));
                }
            } else {
                prefixMask = allOnes << (bitCount - newSegmentPrefixLength);
            }
            newLower = original.getLowerSegmentValue() & prefixMask;
            newUpper = original.getUpperSegmentValue() & prefixMask;
        } else {
            newLower = original.getLowerSegmentValue();
            newUpper = original.getUpperSegmentValue();
        }
        return creator['createSegment$int$int$java_lang_Integer'](newLower, newUpper, newSegmentPrefixLength);
    }

    static isReversibleRange<S extends AddressSegment>(segment : S) : boolean {
        return segment.getLowerSegmentValue() <= 1 && segment.getUpperSegmentValue() >= segment.getMaxSegmentValue() - 1;
    }
}
AddressDivision["__class"] = "inet.ipaddr.format.AddressDivision";
AddressDivision["__interfaces"] = ["inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



export namespace AddressDivision {

    export class AddressDivision$0<S> {
        done : boolean;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return !this.done;
        }

        /**
         * 
         * @return {*}
         */
        public next() : S {
            if(!this.hasNext()) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            this.done = true;
            if(!this.returnThis) {
                let result : S = this.creator['createSegment$int$int$java_lang_Integer'](this.lowerValue, this.upperValue, this.networkIteratorSegmentPrefixLength);
                return result;
            }
            return this.original;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private returnThis: any, private creator: any, private lowerValue: any, private upperValue: any, private networkIteratorSegmentPrefixLength: any, private original: any) {
            if(this.done===undefined) this.done = false;
        }
    }
    AddressDivision$0["__interfaces"] = ["java.util.Iterator"];



    export class AddressDivision$1<S> {
        done : boolean;

        current : number = this.lowerValue;

        last : number = this.upperValue;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return !this.done;
        }

        /**
         * 
         * @return {*}
         */
        public next() : S {
            if(this.done) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
            }
            let result : S;
            if(this.useShiftAdjustment) {
                let low : number = this.current << this.shiftAdjustment;
                result = this.creator['createSegment$int$int$java_lang_Integer'](low, low | this.upperShiftMask, this.networkIteratorSegmentPrefixLength);
            } else {
                result = this.creator['createSegment$int'](this.current);
            }
            this.done = ++this.current > this.last;
            return result;
        }

        /**
         * 
         */
        public remove() {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.UnsupportedOperationException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }

        constructor(private lowerValue: any, private upperValue: any, private useShiftAdjustment: any, private shiftAdjustment: any, private creator: any, private upperShiftMask: any, private networkIteratorSegmentPrefixLength: any) {
            if(this.done===undefined) this.done = false;
            (() => {
                if(this.useShiftAdjustment) {
                    this.current >>>= this.shiftAdjustment;
                    this.last >>>= this.shiftAdjustment;
                }
            })();
        }
    }
    AddressDivision$1["__interfaces"] = ["java.util.Iterator"];


}



