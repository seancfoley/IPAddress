/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressSegmentParams } from './util/AddressSegmentParams';
import { AddressItem } from './AddressItem';
import { AddressStringDivision } from './AddressStringDivision';
import { AddressDivisionGrouping } from './AddressDivisionGrouping';

/**
 * Base class for address divisions.
 * 
 * @author sfoley
 * @class
 */
export abstract class AddressDivisionBase implements AddressItem, AddressStringDivision {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!AddressDivisionBase.__static_initialized) { AddressDivisionBase.__static_initialized = true; AddressDivisionBase.__static_initializer_0(); } }

    static serialVersionUID : number = 4;

    static zeros : string[]; public static zeros_$LI$() : string[] { AddressDivisionBase.__static_initialize(); return AddressDivisionBase.zeros; };

    static __static_initializer_0() {
        let zerosLength : number = 20;
        AddressDivisionBase.zeros = (s => { let a=[]; while(s-->0) a.push(null); return a; })(zerosLength);
        AddressDivisionBase.zeros_$LI$()[0] = "";
        for(let i : number = 1; i < zerosLength; i++) {
            AddressDivisionBase.zeros_$LI$()[i] = AddressDivisionBase.zeros_$LI$()[i - 1] + '0';
        };
    }

    static DIGITS : string[]; public static DIGITS_$LI$() : string[] { AddressDivisionBase.__static_initialize(); if(AddressDivisionBase.DIGITS == null) AddressDivisionBase.DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']; return AddressDivisionBase.DIGITS; };

    static UPPERCASE_DIGITS : string[]; public static UPPERCASE_DIGITS_$LI$() : string[] { AddressDivisionBase.__static_initialize(); if(AddressDivisionBase.UPPERCASE_DIGITS == null) AddressDivisionBase.UPPERCASE_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']; return AddressDivisionBase.UPPERCASE_DIGITS; };

    static maxDigitMap : any; public static maxDigitMap_$LI$() : any { AddressDivisionBase.__static_initialize(); if(AddressDivisionBase.maxDigitMap == null) AddressDivisionBase.maxDigitMap = <any>({}); return AddressDivisionBase.maxDigitMap; };

    static radixPowerMap : any; public static radixPowerMap_$LI$() : any { AddressDivisionBase.__static_initialize(); if(AddressDivisionBase.radixPowerMap == null) AddressDivisionBase.radixPowerMap = <any>({}); return AddressDivisionBase.radixPowerMap; };

    cachedString : string;

    /*private*/ lowerBytes : number[];

    /*private*/ upperBytes : number[];

    constructor() {
        if(this.cachedString===undefined) this.cachedString = null;
        if(this.lowerBytes===undefined) this.lowerBytes = null;
        if(this.upperBytes===undefined) this.upperBytes = null;
    }

    public getBytes$() : number[] {
        let cached : number[] = this.lowerBytes;
        if(cached == null) {
            this.lowerBytes = cached = this.getBytesImpl(true);
        }
        return /* clone */cached.slice(0);
    }

    public getBytes$byte_A$int(bytes : number[], index : number) : number[] {
        let cached : number[] = this.lowerBytes;
        if(cached == null) {
            this.lowerBytes = cached = this.getBytesImpl(true);
        }
        return this.getBytes$byte_A$int$byte_A(bytes, index, cached);
    }

    public getBytes$byte_A(bytes : number[]) : number[] {
        return this.getBytes$byte_A$int(bytes, 0);
    }

    public getBytes$byte_A$int$byte_A(provided : number[], startIndex : number, cached : number[]) : number[] {
        let byteCount : number = (this.getBitCount() + 7) >> 3;
        if(provided == null || provided.length < byteCount + startIndex) {
            if(startIndex > 0) {
                let bytes2 : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(byteCount + startIndex);
                if(provided != null) {
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(provided, 0, bytes2, 0, Math.min(startIndex, provided.length));
                }
                /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(cached, 0, bytes2, startIndex, cached.length);
                return bytes2;
            }
            return /* clone */cached.slice(0);
        }
        /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(cached, 0, provided, startIndex, byteCount);
        return provided;
    }

    public getBytes(provided? : any, startIndex? : any, cached? : any) : any {
        if(((provided != null && provided instanceof <any>Array && (provided.length==0 || provided[0] == null ||(typeof provided[0] === 'number'))) || provided === null) && ((typeof startIndex === 'number') || startIndex === null) && ((cached != null && cached instanceof <any>Array && (cached.length==0 || cached[0] == null ||(typeof cached[0] === 'number'))) || cached === null)) {
            return <any>this.getBytes$byte_A$int$byte_A(provided, startIndex, cached);
        } else if(((provided != null && provided instanceof <any>Array && (provided.length==0 || provided[0] == null ||(typeof provided[0] === 'number'))) || provided === null) && ((typeof startIndex === 'number') || startIndex === null) && cached === undefined) {
            return <any>this.getBytes$byte_A$int(provided, startIndex);
        } else if(((provided != null && provided instanceof <any>Array && (provided.length==0 || provided[0] == null ||(typeof provided[0] === 'number'))) || provided === null) && startIndex === undefined && cached === undefined) {
            return <any>this.getBytes$byte_A(provided);
        } else if(provided === undefined && startIndex === undefined && cached === undefined) {
            return <any>this.getBytes$();
        } else throw new Error('invalid overload');
    }

    public getUpperBytes$() : number[] {
        if(!this.isMultiple()) {
            return this.getBytes();
        }
        let cached : number[] = this.upperBytes;
        if(cached == null) {
            this.upperBytes = cached = this.getBytesImpl(false);
        }
        return /* clone */cached.slice(0);
    }

    public getUpperBytes$byte_A$int(bytes : number[], index : number) : number[] {
        if(!this.isMultiple()) {
            return this.getBytes$byte_A$int(bytes, index);
        }
        let cached : number[] = this.upperBytes;
        if(cached == null) {
            this.upperBytes = cached = this.getBytesImpl(false);
        }
        return this.getBytes$byte_A$int$byte_A(bytes, index, cached);
    }

    /**
     * 
     * @param {Array} bytes
     * @param {number} index
     * @return {Array}
     */
    public getUpperBytes(bytes? : any, index? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof index === 'number') || index === null)) {
            return <any>this.getUpperBytes$byte_A$int(bytes, index);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && index === undefined) {
            return <any>this.getUpperBytes$byte_A(bytes);
        } else if(bytes === undefined && index === undefined) {
            return <any>this.getUpperBytes$();
        } else throw new Error('invalid overload');
    }

    public getUpperBytes$byte_A(bytes : number[]) : number[] {
        return this.getUpperBytes$byte_A$int(bytes, 0);
    }

    abstract getBytesImpl(low : boolean) : number[];

    /**
     * @return {number} the default radix for textual representations of addresses (10 for IPv4, 16 for IPv6)
     */
    public abstract getDefaultTextualRadix() : number;

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public static getMaxDigitCount$int$int$java_math_BigInteger(radix : number, bitCount : number, maxValue : BigInteger) : number {
        let key : number = (((n => n<0?Math.ceil(n):Math.floor(n))(<number>radix)) << 32) | bitCount;
        let digs : number = /* get */((m,k) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { return m.entries[i].value; } return null; })(<any>AddressDivisionBase.maxDigitMap_$LI$(), key);
        if(digs == null) {
            if(maxValue == null) {
                maxValue = AddressDivisionBase.getMaxValue(bitCount);
            }
            digs = AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(maxValue, BigInteger.valueOf(radix));
            /* put */((m,k,v) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { m.entries[i].value=v; return; } m.entries.push({key:k,value:v,getKey: function() { return this.key }, getValue: function() { return this.value }}); })(<any>AddressDivisionBase.maxDigitMap_$LI$(), key, digs);
        }
        return digs;
    }

    public static getMaxDigitCount(radix? : any, bitCount? : any, maxValue? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof bitCount === 'number') || bitCount === null) && ((maxValue != null && maxValue instanceof <any>BigInteger) || maxValue === null)) {
            return <any>AddressDivisionBase.getMaxDigitCount$int$int$java_math_BigInteger(radix, bitCount, maxValue);
        } else if(((typeof radix === 'number') || radix === null) && ((typeof bitCount === 'number') || bitCount === null) && ((typeof maxValue === 'number') || maxValue === null)) {
            return <any>AddressDivisionBase.getMaxDigitCount$int$int$long(radix, bitCount, maxValue);
        } else throw new Error('invalid overload');
    }

    static getMaxValue(bitCount : number) : BigInteger {
        let maxBytes : number = ((bitCount + 7) / 8|0);
        let topBits : number = bitCount % 8;
        if(topBits === 0) {
            topBits = 8;
        }
        let max : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(maxBytes);
        max[0] = (<number>~(~0 << topBits)|0);
        for(let i : number = 1; i < max.length; i++) {
            max[i] = ~0;
        };
        return new BigInteger(1, max);
    }

    public static getDigitCount$java_math_BigInteger$java_math_BigInteger(val : BigInteger, radix : BigInteger) : number {
        if(val.equals(BigInteger.ZERO) || val.equals(BigInteger.ONE)) {
            return 1;
        }
        let result : number = 1;
        while((true)) {
            val = val.divide(radix);
            if(val.equals(BigInteger.ZERO)) {
                break;
            }
            result++;
        };
        return result;
    }

    public static getDigitCount(val? : any, radix? : any) : any {
        if(((val != null && val instanceof <any>BigInteger) || val === null) && ((radix != null && radix instanceof <any>BigInteger) || radix === null)) {
            return <any>AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(val, radix);
        } else if(((typeof val === 'number') || val === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>AddressDivisionBase.getDigitCount$long$int(val, radix);
        } else throw new Error('invalid overload');
    }

    static getMaxDigitCount$int$int$long(radix : number, bitCount : number, maxValue : number) : number {
        let key : number = (((n => n<0?Math.ceil(n):Math.floor(n))(<number>radix)) << 32) | bitCount;
        let digs : number = /* get */((m,k) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { return m.entries[i].value; } return null; })(<any>AddressDivisionBase.maxDigitMap_$LI$(), key);
        if(digs == null) {
            digs = AddressDivisionBase.getDigitCount$long$int(maxValue, radix);
            /* put */((m,k,v) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { m.entries[i].value=v; return; } m.entries.push({key:k,value:v,getKey: function() { return this.key }, getValue: function() { return this.value }}); })(<any>AddressDivisionBase.maxDigitMap_$LI$(), key, digs);
        }
        return digs;
    }

    public static getDigitCount$long$int(value : number, radix : number) : number {
        let result : number = 1;
        if(radix === 16) {
            while((true)) {
                value >>>= 4;
                if(value === 0) {
                    break;
                }
                result++;
            };
        } else {
            if(radix === 10) {
                if(value < 10) {
                    return 1;
                } else if(value < 100) {
                    return 2;
                } else if(value < 1000) {
                    return 3;
                }
                value /= 1000;
                result = 3;
            } else if(radix === 8) {
                while((true)) {
                    value >>>= 3;
                    if(value === 0) {
                        break;
                    }
                    result++;
                };
                return result;
            }
            while((true)) {
                value /= radix;
                if(value === 0) {
                    break;
                }
                result++;
            };
        }
        return result;
    }

    /**
     * Caches the results of radix to the given power.
     * 
     * @param {BigInteger} radix
     * @param {number} power
     * @return
     * @return {BigInteger}
     */
    static getRadixPower(radix : BigInteger, power : number) : BigInteger {
        let key : number = (((n => n<0?Math.ceil(n):Math.floor(n))(<number>radix.intValue())) << 32) | power;
        let result : BigInteger = /* get */((m,k) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { return m.entries[i].value; } return null; })(<any>AddressDivisionBase.radixPowerMap_$LI$(), key);
        if(result == null) {
            if(power === 1) {
                result = radix;
            } else if((power & 1) === 0) {
                let halfPower : BigInteger = AddressDivisionBase.getRadixPower(radix, power >> 1);
                result = halfPower.multiply(halfPower);
            } else {
                let halfPower : BigInteger = AddressDivisionBase.getRadixPower(radix, (power - 1) >> 1);
                result = halfPower.multiply(halfPower).multiply(radix);
            }
            /* put */((m,k,v) => { if(m.entries==null) m.entries=[]; for(let i=0;i<m.entries.length;i++) if(m.entries[i].key.equals!=null && m.entries[i].key.equals(k) || m.entries[i].key===k) { m.entries[i].value=v; return; } m.entries.push({key:k,value:v,getKey: function() { return this.key }, getValue: function() { return this.value }}); })(<any>AddressDivisionBase.radixPowerMap_$LI$(), key, result);
        }
        return result;
    }

    abstract adjustLowerLeadingZeroCount(leadingZeroCount : number, radix : number) : number;

    abstract adjustUpperLeadingZeroCount(leadingZeroCount : number, radix : number) : number;

    public static getSplitChar$int$char$java_lang_String$java_lang_String$java_lang_StringBuilder(count : number, splitDigitSeparator : string, characters : string, stringPrefix : string, builder : { str: string }) {
        while((count-- > 0)) {
            if(stringPrefix.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(builder);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>characters); return sb; })(builder);
            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(builder);
        };
        /* setLength */((sb, length) => sb.str = sb.str.substring(0, length))(builder, /* length */builder.str.length - 1);
    }

    public static getSplitChar(count? : any, splitDigitSeparator? : any, characters? : any, stringPrefix? : any, builder? : any) : any {
        if(((typeof count === 'number') || count === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof characters === 'string') || characters === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((builder != null && (builder instanceof Object)) || builder === null)) {
            return <any>AddressDivisionBase.getSplitChar$int$char$java_lang_String$java_lang_String$java_lang_StringBuilder(count, splitDigitSeparator, characters, stringPrefix, builder);
        } else if(((typeof count === 'number') || count === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof characters === 'string') || characters === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((builder != null && (builder instanceof Object)) || builder === null)) {
            return <any>AddressDivisionBase.getSplitChar$int$char$char$java_lang_String$java_lang_StringBuilder(count, splitDigitSeparator, characters, stringPrefix, builder);
        } else throw new Error('invalid overload');
    }

    /*private*/ static getSplitChar$int$char$char$java_lang_String$java_lang_StringBuilder(count : number, splitDigitSeparator : string, character : string, stringPrefix : string, builder : { str: string }) {
        let prefLen : number = stringPrefix.length;
        while((count-- > 0)) {
            if(prefLen > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(builder);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>character); return sb; })(builder);
            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(builder);
        };
        /* setLength */((sb, length) => sb.str = sb.str.substring(0, length))(builder, /* length */builder.str.length - 1);
    }

    /*private*/ static getSplitLeadingZeros(leadingZeroCount : number, splitDigitSeparator : string, stringPrefix : string, builder : { str: string }) {
        AddressDivisionBase.getSplitChar$int$char$char$java_lang_String$java_lang_StringBuilder(leadingZeroCount, splitDigitSeparator, '0', stringPrefix, builder);
    }

    static getLeadingZeros(leadingZeroCount : number, builder : { str: string }) {
        if(leadingZeroCount > 0) {
            let stringArray : string[] = AddressDivisionBase.zeros_$LI$();
            if(leadingZeroCount >= stringArray.length) {
                let increment : number = stringArray.length - 1;
                let incrementStr : string = stringArray[increment];
                while((leadingZeroCount >= increment)) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>incrementStr); return sb; })(builder);
                    leadingZeroCount -= increment;
                };
                /* append */(sb => { sb.str = sb.str.concat(<any>stringArray[leadingZeroCount]); return sb; })(builder);
                return;
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>stringArray[leadingZeroCount]); return sb; })(builder);
        }
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.getString();
    }

    /**
     * A simple string using just the lower value and the default radix.
     * 
     * @return
     * @return {string}
     */
    abstract getDefaultString() : string;

    public getDefaultRangeString(val1? : any, val2? : any, radix? : any) : any {
        if(val1 === undefined && val2 === undefined && radix === undefined) {
            return <any>this.getDefaultRangeString$();
        } else throw new Error('invalid overload');
    }

    getDefaultRangeString$() : string { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * This is the wildcard string to be used when producing the default strings with getString() or getWildcardString()
     * 
     * Since no parameters for the string are provided, default settings are used, but they must be consistent with the address.
     * 
     * For instance, generally the '*' is used as a wildcard to denote all possible values for a given segment,
     * but in some cases that character is used for a segment separator.
     * 
     * Note that this only applies to "default" settings, there are additional string methods that allow you to specify these separator characters.
     * Those methods must be aware of the defaults as well, to know when they can defer to the defaults and when they cannot.
     * 
     * @return
     * @return {string}
     */
    abstract getDefaultSegmentWildcardString() : string;

    /**
     * This is the wildcard string to be used when producing the default strings with getString() or getWildcardString()
     * 
     * Since no parameters for the string are provided, default settings are used, but they must be consistent with the address.
     * 
     * For instance, generally the '-' is used as a range separator, but in some cases that character is used for a segment separator.
     * 
     * Note that this only applies to "default" settings, there are additional string methods that allow you to specify these separator characters.
     * Those methods must be aware of the defaults as well, to know when they can defer to the defaults and when they cannot.
     * 
     * @return
     * @return {string}
     */
    abstract getDefaultRangeSeparatorString() : string;

    /**
     * Produces a normalized string to represent the segment.
     * If the segment CIDR prefix length covers the range, then it is assumed to be a CIDR, and the string has only the lower value of the CIDR range.
     * Otherwise, the explicit range will be printed.
     * @return
     * @return {string}
     */
    public getString() : string {
        let result : string = this.cachedString;
        if(result == null) {
            {
                result = this.cachedString;
                if(result == null) {
                    if(!this.isMultiple()) {
                        result = this.getDefaultString();
                    } else if(!this.isFullRange() || (result = this.getDefaultSegmentWildcardString()) == null) {
                        result = this.getDefaultRangeString();
                    }
                    this.cachedString = result;
                }
            };
        }
        return result;
    }

    getWildcardString() : string {
        return this.getString();
    }

    /*private*/ getCachedString() : string {
        let result : string = this.cachedString;
        if(result == null) {
            {
                result = this.cachedString;
                if(result == null) {
                    this.cachedString = result = this.getDefaultString();
                }
            };
        }
        return result;
    }

    setDefaultAsFullRangeString() {
        if(this.cachedString == null) {
            let result : string = this.getDefaultSegmentWildcardString();
            if(result != null) {
                {
                    this.cachedString = result;
                };
            }
        }
    }

    setDefaultAsFullRangeWildcardString() {
        this.setDefaultAsFullRangeString();
    }

    abstract getLowerStringLength(radix : number) : number;

    abstract getUpperStringLength(radix : number) : number;

    getLowerString$int$boolean$java_lang_StringBuilder(radix : number, uppercase : boolean, appendable : { str: string }) { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getLowerString$int$int$boolean$java_lang_StringBuilder(radix : number, choppedDigits : number, uppercase : boolean, appendable : { str: string }) { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getLowerString(radix? : any, choppedDigits? : any, uppercase? : any, appendable? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getLowerString$int$int$boolean$java_lang_StringBuilder(radix, choppedDigits, uppercase, appendable);
        } else if(((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'boolean') || choppedDigits === null) && ((uppercase != null && (uppercase instanceof Object)) || uppercase === null) && appendable === undefined) {
            return <any>this.getLowerString$int$boolean$java_lang_StringBuilder(radix, choppedDigits, uppercase);
        } else throw new Error('invalid overload');
    }

    abstract getUpperString(radix : number, uppercase : boolean, appendable : { str: string });

    abstract getUpperStringMasked(radix : number, uppercase : boolean, appendable : { str: string });

    abstract getSplitLowerString(radix : number, choppedDigits : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string });

    public getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator : string, wildcard : string, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getSplitRangeString(rangeSeparator? : any, wildcard? : any, radix? : any, uppercase? : any, splitDigitSeparator? : any, reverseSplitDigits? : any, stringPrefix? : any, appendable? : any) : any {
        if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && ((typeof radix === 'number') || radix === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof reverseSplitDigits === 'boolean') || reverseSplitDigits === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
        } else if(((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((wildcard != null && (wildcard["__interfaces"] != null && wildcard["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0 || wildcard.constructor != null && wildcard.constructor["__interfaces"] != null && wildcard.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0)) || wildcard === null) && ((radix != null && (radix instanceof Object)) || radix === null) && uppercase === undefined && splitDigitSeparator === undefined && reverseSplitDigits === undefined && stringPrefix === undefined && appendable === undefined) {
            return <any>this.getSplitRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(rangeSeparator, wildcard, radix);
        } else throw new Error('invalid overload');
    }

    abstract getSplitRangeStringLength(rangeSeparator : string, wildcard : string, leadingZeroCount : number, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string) : number;

    abstract getRangeDigitCount(radix : number) : number;

    appendUppercase(str : any, radix : number, appendable : { str: string }) {
        if(radix > 10) {
            for(let i : number = 0; i < str.length; i++) {
                let c : string = str.charAt(i);
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'z'.charCodeAt(0)) {
                    c = String.fromCharCode((c).charCodeAt(0) + 'A'.charCodeAt(0) - 'a'.charCodeAt(0));
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(appendable);
            };
        } else {
            /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(appendable);
        }
    }

    /*private*/ static getFullRangeString(wildcard : string, appendable : { str: string }) : number {
        if(appendable == null) {
            return wildcard.length;
        }
        /* append */(sb => { sb.str = sb.str.concat(<any>wildcard); return sb; })(appendable);
        return 0;
    }

    getPrefixAdjustedRangeString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let leadingZeroCount : number = params.getLeadingZeros(segmentIndex);
        let radix : number = params.getRadix();
        let lowerLeadingZeroCount : number = this.adjustLowerLeadingZeroCount(leadingZeroCount, radix);
        let upperLeadingZeroCount : number = this.adjustUpperLeadingZeroCount(leadingZeroCount, radix);
        let wildcards : StringOptions.Wildcards = params.getWildcards();
        let rangeSeparator : string = wildcards.rangeSeparator;
        let rangeDigitCount : number = wildcards.singleWildcard == null?0:this.getRangeDigitCount(radix);
        if(rangeDigitCount === 0 && radix === this.getDefaultTextualRadix() && !this.isFullRange()) {
            let str : string = this.getString();
            let rangeSep : string = this.getDefaultRangeSeparatorString();
            let stringPrefix : string = params.getSegmentStrPrefix();
            let prefLen : number = stringPrefix.length;
            if(lowerLeadingZeroCount === 0 && upperLeadingZeroCount === 0 && /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(rangeSep,rangeSeparator)) && prefLen === 0) {
                if(appendable == null) {
                    return str.length;
                } else {
                    if(params.isUppercase()) {
                        this.appendUppercase(str, radix, appendable);
                    } else {
                        /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(appendable);
                    }
                    return 0;
                }
            } else {
                if(appendable == null) {
                    let count : number = str.length + (rangeSeparator.length - rangeSep.length) + lowerLeadingZeroCount + upperLeadingZeroCount;
                    if(prefLen > 0) {
                        count += prefLen << 1;
                    }
                    return count;
                } else {
                    let firstEnd : number = str.indexOf(rangeSep);
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    if(lowerLeadingZeroCount > 0) {
                        AddressDivisionBase.getLeadingZeros(lowerLeadingZeroCount, appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>str.substring(0, firstEnd)); return sb; })(appendable);
                    /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    if(upperLeadingZeroCount > 0) {
                        AddressDivisionBase.getLeadingZeros(upperLeadingZeroCount, appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>str.substring(firstEnd + rangeSep.length)); return sb; })(appendable);
                    return 0;
                }
            }
        }
        rangeDigitCount = this.adjustRangeDigits(rangeDigitCount);
        if(leadingZeroCount < 0 && appendable == null) {
            let charLength : number = this['getMaxDigitCount$int'](radix);
            let stringPrefix : string = params.getSegmentStrPrefix();
            let prefLen : number = stringPrefix.length;
            if(rangeDigitCount !== 0) {
                let count : number = charLength;
                if(prefLen > 0) {
                    count += prefLen;
                }
                return count;
            }
            let count : number = charLength << 1;
            if(prefLen > 0) {
                count += prefLen << 1;
            }
            count += rangeSeparator.length;
            return count;
        }
        if(rangeDigitCount !== 0) {
            return this.getRangeDigitString(segmentIndex, params, appendable);
        }
        return this.getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$int$int$boolean$java_lang_StringBuilder(segmentIndex, params, lowerLeadingZeroCount, upperLeadingZeroCount, true, appendable);
    }

    /**
     * 
     * @param {number} segmentIndex
     * @param {*} params
     * @param {{ str: string }} appendable
     * @return {number}
     */
    public getLowerStandardString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let count : number = 0;
        let stringPrefix : string = params.getSegmentStrPrefix();
        let prefLen : number = stringPrefix.length;
        if(prefLen > 0) {
            if(appendable == null) {
                count += prefLen;
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
        }
        let radix : number = params.getRadix();
        let leadingZeroCount : number = params.getLeadingZeros(segmentIndex);
        leadingZeroCount = this.adjustLowerLeadingZeroCount(leadingZeroCount, radix);
        if(leadingZeroCount !== 0) {
            if(appendable == null) {
                if(leadingZeroCount < 0) {
                    return count + this['getMaxDigitCount$int'](radix);
                } else {
                    count += leadingZeroCount;
                }
            } else {
                leadingZeroCount = this.adjustLowerLeadingZeroCount(leadingZeroCount, radix);
                AddressDivisionBase.getLeadingZeros(leadingZeroCount, appendable);
            }
        }
        let uppercase : boolean = params.isUppercase();
        if(radix === this.getDefaultTextualRadix()) {
            let str : string = this.getCachedString();
            if(appendable == null) {
                return count + str.length;
            } else if(uppercase) {
                this.appendUppercase(str, radix, appendable);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(appendable);
            }
        } else {
            if(appendable == null) {
                return count + this.getLowerStringLength(radix);
            } else {
                this.getLowerString$int$boolean$java_lang_StringBuilder(radix, uppercase, appendable);
            }
        }
        return 0;
    }

    /**
     * Produces a string to represent the segment, using wildcards and range characters.
     * Use this instead of getWildcardString() if you have a customized wildcard or range separator or you have a non-zero leadingZeroCount,
     * or you have a non-standard radix (for IPv4 standard radix is 10, for IPv6 it is 16)
     * 
     * @param {number} segmentIndex
     * @param {*} params
     * @param {{ str: string }} appendable
     * @return {number}
     */
    public getStandardString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        if(!this.isMultiple()) {
            let splitDigits : boolean = params.isSplitDigits();
            if(splitDigits) {
                let radix : number = params.getRadix();
                let leadingZeroCount : number = params.getLeadingZeros(segmentIndex);
                leadingZeroCount = this.adjustLowerLeadingZeroCount(leadingZeroCount, radix);
                let stringPrefix : string = params.getSegmentStrPrefix();
                let prefLen : number = stringPrefix.length;
                if(appendable == null) {
                    let len : number;
                    if(leadingZeroCount !== 0) {
                        if(leadingZeroCount < 0) {
                            len = this['getMaxDigitCount$int'](radix);
                        } else {
                            len = this.getLowerStringLength(radix) + leadingZeroCount;
                        }
                    } else {
                        len = this.getLowerStringLength(radix);
                    }
                    let count : number = (len << 1) - 1;
                    if(prefLen > 0) {
                        count += len * prefLen;
                    }
                    return count;
                } else {
                    let splitDigitSeparator : string = (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(params.getSplitDigitSeparator()) == null?String.fromCharCode(0):String.fromCharCode(params.getSplitDigitSeparator());
                    let reverseSplitDigits : boolean = params.isReverseSplitDigits();
                    let uppercase : boolean = params.isUppercase();
                    if(reverseSplitDigits) {
                        this.getSplitLowerString(radix, 0, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
                        if(leadingZeroCount !== 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                            AddressDivisionBase.getSplitLeadingZeros(leadingZeroCount, splitDigitSeparator, stringPrefix, appendable);
                        }
                    } else {
                        if(leadingZeroCount !== 0) {
                            AddressDivisionBase.getSplitLeadingZeros(leadingZeroCount, splitDigitSeparator, stringPrefix, appendable);
                            /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                        }
                        this.getSplitLowerString(radix, 0, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
                    }
                    return 0;
                }
            }
            return this.getLowerStandardString(segmentIndex, params, appendable);
        }
        if(this.isFullRange()) {
            let wildcard : string = params.getWildcards().wildcard;
            if(wildcard != null) {
                if(/* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(wildcard,this.getDefaultSegmentWildcardString()))) {
                    this.setDefaultAsFullRangeWildcardString();
                }
                let splitDigits : boolean = params.isSplitDigits();
                if(splitDigits) {
                    let radix : number = params.getRadix();
                    if(appendable == null) {
                        let len : number = this['getMaxDigitCount$int'](radix);
                        let count : number = len * (wildcard.length + 1) - 1;
                        return count;
                    }
                    let splitDigitSeparator : string = (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(params.getSplitDigitSeparator()) == null?String.fromCharCode(0):String.fromCharCode(params.getSplitDigitSeparator());
                    AddressDivisionBase.getSplitChar$int$char$java_lang_String$java_lang_String$java_lang_StringBuilder(this['getMaxDigitCount$int'](radix), splitDigitSeparator, wildcard, "", appendable);
                    return 0;
                }
                return AddressDivisionBase.getFullRangeString(wildcard, appendable);
            }
        }
        return this.getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(segmentIndex, params, appendable);
    }

    getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let splitDigits : boolean = params.isSplitDigits();
        let radix : number = params.getRadix();
        let leadingZeroCount : number = params.getLeadingZeros(segmentIndex);
        let wildcards : StringOptions.Wildcards = params.getWildcards();
        let rangeSeparator : string = wildcards.rangeSeparator;
        let rangeDigitCount : number = wildcards.singleWildcard == null?0:this.getRangeDigitCount(radix);
        let lowerLeadingZeroCount : number = this.adjustLowerLeadingZeroCount(leadingZeroCount, radix);
        let upperLeadingZeroCount : number = this.adjustUpperLeadingZeroCount(leadingZeroCount, radix);
        if(rangeDigitCount === 0 && radix === this.getDefaultTextualRadix() && !splitDigits && !this.isFullRange()) {
            let str : string = this.getWildcardString();
            let rangeSep : string = this.getDefaultRangeSeparatorString();
            let stringPrefix : string = params.getSegmentStrPrefix();
            let prefLen : number = stringPrefix.length;
            if(lowerLeadingZeroCount === 0 && upperLeadingZeroCount === 0 && prefLen === 0 && /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(rangeSeparator,rangeSep))) {
                if(appendable == null) {
                    return str.length;
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(appendable);
                return 0;
            } else {
                if(appendable == null) {
                    let count : number = str.length + (rangeSeparator.length - rangeSep.length) + lowerLeadingZeroCount + upperLeadingZeroCount;
                    if(prefLen > 0) {
                        count += prefLen << 1;
                    }
                    return count;
                } else {
                    let firstEnd : number = str.indexOf(rangeSep);
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    if(lowerLeadingZeroCount > 0) {
                        AddressDivisionBase.getLeadingZeros(lowerLeadingZeroCount, appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>str.substring(0, firstEnd)); return sb; })(appendable);
                    /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    if(upperLeadingZeroCount > 0) {
                        AddressDivisionBase.getLeadingZeros(upperLeadingZeroCount, appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>str.substring(firstEnd + rangeSep.length)); return sb; })(appendable);
                    return 0;
                }
            }
        }
        if(!splitDigits && leadingZeroCount < 0 && appendable == null) {
            let stringPrefix : string = params.getSegmentStrPrefix();
            let prefLen : number = stringPrefix.length;
            let charLength : number = this['getMaxDigitCount$int'](radix);
            if(rangeDigitCount !== 0) {
                let count : number = charLength;
                if(prefLen > 0) {
                    count += prefLen;
                }
                return count;
            }
            let count : number = charLength << 1;
            if(prefLen > 0) {
                count += prefLen << 1;
            }
            count += rangeSeparator.length;
            return count;
        }
        rangeDigitCount = this.adjustRangeDigits(rangeDigitCount);
        if(rangeDigitCount !== 0) {
            if(splitDigits) {
                return this.getSplitRangeDigitString(segmentIndex, params, appendable);
            } else {
                return this.getRangeDigitString(segmentIndex, params, appendable);
            }
        }
        if(splitDigits) {
            return this.getSplitRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(segmentIndex, params, appendable);
        }
        return this.getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$int$int$boolean$java_lang_StringBuilder(segmentIndex, params, lowerLeadingZeroCount, upperLeadingZeroCount, false, appendable);
    }

    getSplitRangeDigitString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let radix : number = params.getRadix();
        let leadingZerosCount : number = params.getLeadingZeros(segmentIndex);
        leadingZerosCount = this.adjustLowerLeadingZeroCount(leadingZerosCount, radix);
        let stringPrefix : string = params.getSegmentStrPrefix();
        if(appendable == null) {
            let len : number = this.getLowerStringLength(radix) + leadingZerosCount;
            let count : number = (len << 1) - 1;
            let prefLen : number = stringPrefix.length;
            if(prefLen > 0) {
                count += len * prefLen;
            }
            return count;
        } else {
            let wildcards : StringOptions.Wildcards = params.getWildcards();
            let rangeDigits : number = this.adjustRangeDigits(this.getRangeDigitCount(radix));
            let splitDigitSeparator : string = (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(params.getSplitDigitSeparator()) == null?String.fromCharCode(0):String.fromCharCode(params.getSplitDigitSeparator());
            let reverseSplitDigits : boolean = params.isReverseSplitDigits();
            let uppercase : boolean = params.isUppercase();
            if(reverseSplitDigits) {
                AddressDivisionBase.getSplitChar$int$char$java_lang_String$java_lang_String$java_lang_StringBuilder(rangeDigits, splitDigitSeparator, wildcards.singleWildcard, stringPrefix, appendable);
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                this.getSplitLowerString(radix, rangeDigits, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
                if(leadingZerosCount > 0) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                    AddressDivisionBase.getSplitLeadingZeros(leadingZerosCount, splitDigitSeparator, stringPrefix, appendable);
                }
            } else {
                if(leadingZerosCount !== 0) {
                    AddressDivisionBase.getSplitLeadingZeros(leadingZerosCount, splitDigitSeparator, stringPrefix, appendable);
                    /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                }
                this.getSplitLowerString(radix, rangeDigits, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                AddressDivisionBase.getSplitChar$int$char$java_lang_String$java_lang_String$java_lang_StringBuilder(rangeDigits, splitDigitSeparator, wildcards.singleWildcard, stringPrefix, appendable);
            }
        }
        return 0;
    }

    getRangeDigitString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let radix : number = params.getRadix();
        let leadingZerosCount : number = params.getLeadingZeros(segmentIndex);
        leadingZerosCount = this.adjustLowerLeadingZeroCount(leadingZerosCount, radix);
        let stringPrefix : string = params.getSegmentStrPrefix();
        let prefLen : number = stringPrefix.length;
        let wildcards : StringOptions.Wildcards = params.getWildcards();
        let rangeDigits : number = this.adjustRangeDigits(this.getRangeDigitCount(radix));
        if(appendable == null) {
            return this.getLowerStringLength(radix) + leadingZerosCount + prefLen;
        } else {
            if(prefLen > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            if(leadingZerosCount > 0) {
                AddressDivisionBase.getLeadingZeros(leadingZerosCount, appendable);
            }
            let uppercase : boolean = params.isUppercase();
            this.getLowerString$int$int$boolean$java_lang_StringBuilder(radix, rangeDigits, uppercase, appendable);
            for(let i : number = 0; i < rangeDigits; i++) {
                /* append */(sb => { sb.str = sb.str.concat(<any>wildcards.singleWildcard); return sb; })(appendable);
            };
        }
        return 0;
    }

    adjustRangeDigits(rangeDigits : number) : number {
        if(rangeDigits !== 0) {
            if(!this.includesZero() || rangeDigits === 1) {
                return rangeDigits;
            }
        }
        return 0;
    }

    getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$int$int$boolean$java_lang_StringBuilder(segmentIndex : number, params : AddressSegmentParams, lowerLeadingZerosCount : number, upperLeadingZerosCount : number, maskUpper : boolean, appendable : { str: string }) : number {
        let stringPrefix : string = params.getSegmentStrPrefix();
        let radix : number = params.getRadix();
        let rangeSeparator : string = params.getWildcards().rangeSeparator;
        let uppercase : boolean = params.isUppercase();
        return this.getRangeString$java_lang_String$int$int$java_lang_String$int$boolean$boolean$java_lang_StringBuilder(rangeSeparator, lowerLeadingZerosCount, upperLeadingZerosCount, stringPrefix, radix, uppercase, maskUpper, appendable);
    }

    public getRangeString$java_lang_String$int$int$java_lang_String$int$boolean$boolean$java_lang_StringBuilder(rangeSeparator : string, lowerLeadingZerosCount : number, upperLeadingZerosCount : number, stringPrefix : string, radix : number, uppercase : boolean, maskUpper : boolean, appendable : { str: string }) : number {
        let prefLen : number = stringPrefix.length;
        let hasStringPrefix : boolean = prefLen > 0;
        if(appendable == null) {
            let count : number = lowerLeadingZerosCount + upperLeadingZerosCount + this.getLowerStringLength(radix) + this.getUpperStringLength(radix) + rangeSeparator.length;
            if(hasStringPrefix) {
                count += prefLen << 1;
            }
            return count;
        } else {
            if(hasStringPrefix) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            if(lowerLeadingZerosCount > 0) {
                AddressDivisionBase.getLeadingZeros(lowerLeadingZerosCount, appendable);
            }
            this.getLowerString$int$boolean$java_lang_StringBuilder(radix, uppercase, appendable);
            /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
            if(hasStringPrefix) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            if(upperLeadingZerosCount > 0) {
                AddressDivisionBase.getLeadingZeros(upperLeadingZerosCount, appendable);
            }
            if(maskUpper) {
                this.getUpperStringMasked(radix, uppercase, appendable);
            } else {
                this.getUpperString(radix, uppercase, appendable);
            }
        }
        return 0;
    }

    public getRangeString(rangeSeparator? : any, lowerLeadingZerosCount? : any, upperLeadingZerosCount? : any, stringPrefix? : any, radix? : any, uppercase? : any, maskUpper? : any, appendable? : any) : any {
        if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof lowerLeadingZerosCount === 'number') || lowerLeadingZerosCount === null) && ((typeof upperLeadingZerosCount === 'number') || upperLeadingZerosCount === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((typeof radix === 'number') || radix === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof maskUpper === 'boolean') || maskUpper === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getRangeString$java_lang_String$int$int$java_lang_String$int$boolean$boolean$java_lang_StringBuilder(rangeSeparator, lowerLeadingZerosCount, upperLeadingZerosCount, stringPrefix, radix, uppercase, maskUpper, appendable);
        } else if(((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((lowerLeadingZerosCount != null && (lowerLeadingZerosCount["__interfaces"] != null && lowerLeadingZerosCount["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0 || lowerLeadingZerosCount.constructor != null && lowerLeadingZerosCount.constructor["__interfaces"] != null && lowerLeadingZerosCount.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0)) || lowerLeadingZerosCount === null) && ((typeof upperLeadingZerosCount === 'number') || upperLeadingZerosCount === null) && ((typeof stringPrefix === 'number') || stringPrefix === null) && ((typeof radix === 'boolean') || radix === null) && ((uppercase != null && (uppercase instanceof Object)) || uppercase === null) && maskUpper === undefined && appendable === undefined) {
            return <any>this.getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$int$int$boolean$java_lang_StringBuilder(rangeSeparator, lowerLeadingZerosCount, upperLeadingZerosCount, stringPrefix, radix, uppercase);
        } else if(((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((lowerLeadingZerosCount != null && (lowerLeadingZerosCount["__interfaces"] != null && lowerLeadingZerosCount["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0 || lowerLeadingZerosCount.constructor != null && lowerLeadingZerosCount.constructor["__interfaces"] != null && lowerLeadingZerosCount.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0)) || lowerLeadingZerosCount === null) && ((upperLeadingZerosCount != null && (upperLeadingZerosCount instanceof Object)) || upperLeadingZerosCount === null) && stringPrefix === undefined && radix === undefined && uppercase === undefined && maskUpper === undefined && appendable === undefined) {
            return <any>this.getRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(rangeSeparator, lowerLeadingZerosCount, upperLeadingZerosCount);
        } else throw new Error('invalid overload');
    }

    getSplitRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        let stringPrefix : string = params.getSegmentStrPrefix();
        let radix : number = params.getRadix();
        let leadingZeroCount : number = params.getLeadingZeros(segmentIndex);
        leadingZeroCount = this.adjustUpperLeadingZeroCount(leadingZeroCount, radix);
        let wildcards : StringOptions.Wildcards = params.getWildcards();
        let uppercase : boolean = params.isUppercase();
        let splitDigitSeparator : string = (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(params.getSplitDigitSeparator()) == null?String.fromCharCode(0):String.fromCharCode(params.getSplitDigitSeparator());
        let reverseSplitDigits : boolean = params.isReverseSplitDigits();
        let rangeSeparator : string = wildcards.rangeSeparator;
        if(appendable == null) {
            return this.getSplitRangeStringLength(rangeSeparator, wildcards.wildcard, leadingZeroCount, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix);
        } else {
            let hasLeadingZeros : boolean = leadingZeroCount !== 0;
            if(hasLeadingZeros && !reverseSplitDigits) {
                AddressDivisionBase.getSplitLeadingZeros(leadingZeroCount, splitDigitSeparator, stringPrefix, appendable);
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                hasLeadingZeros = false;
            }
            this.getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator, wildcards.wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
            if(hasLeadingZeros) {
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
                AddressDivisionBase.getSplitLeadingZeros(leadingZeroCount, splitDigitSeparator, stringPrefix, appendable);
            }
        }
        return 0;
    }

    public abstract isBoundedBy(value?: any): any;
    public abstract isFullRange(): any;
    public abstract includesMax(): any;
    public abstract isMax(): any;
    public abstract includesZero(): any;
    public abstract isZero(): any;
    public abstract getCount(): any;
    public abstract isMultiple(): any;
    public abstract getBitCount(): any;}
AddressDivisionBase["__class"] = "inet.ipaddr.format.AddressDivisionBase";
AddressDivisionBase["__interfaces"] = ["inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.io.Serializable"];





AddressDivisionBase.radixPowerMap_$LI$();

AddressDivisionBase.maxDigitMap_$LI$();

AddressDivisionBase.UPPERCASE_DIGITS_$LI$();

AddressDivisionBase.DIGITS_$LI$();

AddressDivisionBase.zeros_$LI$();

AddressDivisionBase.__static_initialize();
