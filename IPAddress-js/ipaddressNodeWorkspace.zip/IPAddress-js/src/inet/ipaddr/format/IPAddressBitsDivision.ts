/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressValueException } from '../AddressValueException';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressDivision } from './IPAddressDivision';
import { AddressNetwork } from '../AddressNetwork';
import { AddressDivision } from './AddressDivision';

export class IPAddressBitsDivision extends IPAddressDivision {
    static __inet_ipaddr_format_IPAddressBitsDivision_serialVersionUID : number = 4;

    /*private*/ bitCount : number;

    /*private*/ defaultRadix : number;

    /*private*/ maxDigitCount : number;

    /*private*/ value : number;

    /*private*/ upperValue : number;

    /*private*/ bitsMask : number;

    public constructor(value? : any, upperValue? : any, bitCount? : any, defaultRadix? : any, network? : any, networkPrefixLength? : any) {
        if(((typeof value === 'number') || value === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof bitCount === 'number') || bitCount === null) && ((typeof defaultRadix === 'number') || defaultRadix === null) && ((network != null && network instanceof <any>IPAddressNetwork) || network === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(networkPrefixLength == null?null:Math.min(bitCount, networkPrefixLength));
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            if(this.maxDigitCount===undefined) this.maxDigitCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitsMask===undefined) this.bitsMask = 0;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            if(this.maxDigitCount===undefined) this.maxDigitCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitsMask===undefined) this.bitsMask = 0;
            (() => {
                this.bitCount = bitCount;
                if(value < 0 || upperValue < 0) {
                    throw new AddressValueException(value < 0?value:upperValue);
                }
                if(value > upperValue) {
                    let tmp : number = value;
                    value = upperValue;
                    upperValue = tmp;
                }
                let fullMask : number = ~0 << bitCount;
                let max : number = ~fullMask;
                if(upperValue > max) {
                    throw new AddressValueException(upperValue);
                }
                networkPrefixLength = this.getDivisionPrefixLength();
                if(networkPrefixLength != null && networkPrefixLength < bitCount && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                    let mask : number = ~0 << (bitCount - networkPrefixLength);
                    this.value = value & mask;
                    this.upperValue = upperValue | ~mask;
                } else {
                    this.value = value;
                    this.upperValue = upperValue;
                }
                this.defaultRadix = defaultRadix;
                this.bitsMask = max;
                this.maxDigitCount = AddressDivisionBase.getMaxDigitCount$int$int$long(defaultRadix, bitCount, max);
            })();
        } else if(((typeof value === 'number') || value === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof bitCount === 'number') || bitCount === null) && ((typeof defaultRadix === 'number') || defaultRadix === null) && network === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let network : any = null;
                let networkPrefixLength : any = null;
                super(networkPrefixLength == null?null:Math.min(bitCount, networkPrefixLength));
                if(this.bitCount===undefined) this.bitCount = 0;
                if(this.defaultRadix===undefined) this.defaultRadix = 0;
                if(this.maxDigitCount===undefined) this.maxDigitCount = 0;
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                if(this.bitsMask===undefined) this.bitsMask = 0;
                if(this.bitCount===undefined) this.bitCount = 0;
                if(this.defaultRadix===undefined) this.defaultRadix = 0;
                if(this.maxDigitCount===undefined) this.maxDigitCount = 0;
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                if(this.bitsMask===undefined) this.bitsMask = 0;
                (() => {
                    this.bitCount = bitCount;
                    if(value < 0 || upperValue < 0) {
                        throw new AddressValueException(value < 0?value:upperValue);
                    }
                    if(value > upperValue) {
                        let tmp : number = value;
                        value = upperValue;
                        upperValue = tmp;
                    }
                    let fullMask : number = ~0 << bitCount;
                    let max : number = ~fullMask;
                    if(upperValue > max) {
                        throw new AddressValueException(upperValue);
                    }
                    networkPrefixLength = this.getDivisionPrefixLength();
                    if(networkPrefixLength != null && networkPrefixLength < bitCount && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        let mask : number = ~0 << (bitCount - networkPrefixLength);
                        this.value = value & mask;
                        this.upperValue = upperValue | ~mask;
                    } else {
                        this.value = value;
                        this.upperValue = upperValue;
                    }
                    this.defaultRadix = defaultRadix;
                    this.bitsMask = max;
                    this.maxDigitCount = AddressDivisionBase.getMaxDigitCount$int$int$long(defaultRadix, bitCount, max);
                })();
            }
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.bitCount;
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionNetworkMask(bits : number) : number {
        let bitShift : number = this.bitCount - bits;
        return this.bitsMask & (~0 << bitShift);
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionHostMask(bits : number) : number {
        let bitShift : number = this.bitCount - bits;
        return ~(~0 << bitShift);
    }

    /**
     * 
     * @return {number}
     */
    public getLowerValue() : number {
        return this.value;
    }

    /**
     * 
     * @return {number}
     */
    public getUpperValue() : number {
        return this.upperValue;
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean {
        if(other != null && other instanceof <any>IPAddressBitsDivision) {
            return this.isSameValues$inet_ipaddr_format_AddressDivision(<IPAddressBitsDivision>other);
        }
        return false;
    }

    public isSameValues$inet_ipaddr_format_IPAddressBitsDivision(otherSegment : IPAddressBitsDivision) : boolean {
        return this.value === otherSegment.value && this.upperValue === otherSegment.upperValue && this.bitCount === otherSegment.bitCount;
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>IPAddressBitsDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_IPAddressBitsDivision(otherSegment);
        } else if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return this.defaultRadix;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        return this.maxDigitCount;
    }
}
IPAddressBitsDivision["__class"] = "inet.ipaddr.format.IPAddressBitsDivision";
IPAddressBitsDivision["__interfaces"] = ["inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];




