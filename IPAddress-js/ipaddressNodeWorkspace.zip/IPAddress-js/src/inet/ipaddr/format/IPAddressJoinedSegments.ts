/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressValueException } from '../AddressValueException';
import { IPAddressDivision } from './IPAddressDivision';
import { AddressDivision } from './AddressDivision';

/**
 * A combination of two or more IP address segments.
 * 
 * @author sfoley
 * @param {number} joinedCount
 * @param {number} lower
 * @param {number} upper
 * @param {number} segmentPrefixLength
 * @class
 * @extends IPAddressDivision
 */
export abstract class IPAddressJoinedSegments extends IPAddressDivision {
    static __inet_ipaddr_format_IPAddressJoinedSegments_serialVersionUID : number = 4;

    joinedCount : number;

    value : number;

    upperValue : number;

    public constructor(joinedCount? : any, lower? : any, upper? : any, segmentPrefixLength? : any) {
        if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(segmentPrefixLength);
            if(this.joinedCount===undefined) this.joinedCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.joinedCount===undefined) this.joinedCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(lower < 0 || upper < 0) {
                    throw new AddressValueException(lower < 0?lower:upper);
                } else if(joinedCount <= 0) {
                    throw new AddressValueException(joinedCount);
                }
                if(lower > upper) {
                    let tmp : number = lower;
                    lower = upper;
                    upper = tmp;
                }
                this.value = lower;
                this.upperValue = upper;
                this.joinedCount = joinedCount;
            })();
        } else if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[1];
            let segmentPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lower : any = value;
                let upper : any = value;
                super(segmentPrefixLength);
                if(this.joinedCount===undefined) this.joinedCount = 0;
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                if(this.joinedCount===undefined) this.joinedCount = 0;
                if(this.value===undefined) this.value = 0;
                if(this.upperValue===undefined) this.upperValue = 0;
                (() => {
                    if(lower < 0 || upper < 0) {
                        throw new AddressValueException(lower < 0?lower:upper);
                    } else if(joinedCount <= 0) {
                        throw new AddressValueException(joinedCount);
                    }
                    if(lower > upper) {
                        let tmp : number = lower;
                        lower = upper;
                        upper = tmp;
                    }
                    this.value = lower;
                    this.upperValue = upper;
                    this.joinedCount = joinedCount;
                })();
            }
        } else if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[1];
            super();
            if(this.joinedCount===undefined) this.joinedCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.joinedCount===undefined) this.joinedCount = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            (() => {
                if(value < 0) {
                    throw new AddressValueException(value);
                } else if(joinedCount <= 0) {
                    throw new AddressValueException(joinedCount);
                }
                this.value = this.upperValue = value;
                this.joinedCount = joinedCount;
            })();
        } else throw new Error('invalid overload');
    }

    public getJoinedCount() : number {
        return this.joinedCount;
    }

    /**
     * 
     * @return {number}
     */
    public getLowerValue() : number {
        return this.value;
    }

    /**
     * 
     * @return {number}
     */
    public getUpperValue() : number {
        return this.upperValue;
    }

    abstract getBitsPerSegment() : number;

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return (this.joinedCount + 1) * this.getBitsPerSegment();
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        return AddressDivisionBase.getDigitCount$long$int(this.getMaxValue(), this.getDefaultTextualRadix());
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean {
        return (other != null && other instanceof <any>IPAddressJoinedSegments) && this.isSameValues$inet_ipaddr_format_AddressDivision(<IPAddressJoinedSegments>other);
    }

    public isSameValues$inet_ipaddr_format_IPAddressJoinedSegments(otherSegment : IPAddressJoinedSegments) : boolean {
        return otherSegment.joinedCount === this.joinedCount && this.value === otherSegment.value && this.upperValue === otherSegment.upperValue;
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>IPAddressJoinedSegments) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_IPAddressJoinedSegments(otherSegment);
        } else if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public equals(other : any) : boolean {
        return other === this || ((other != null && other instanceof <any>IPAddressJoinedSegments) && this.isSameValues$inet_ipaddr_format_AddressDivision(<IPAddressJoinedSegments>other));
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return (<number>(this.value | (this.upperValue << this.getBitCount()))|0);
    }
}
IPAddressJoinedSegments["__class"] = "inet.ipaddr.format.IPAddressJoinedSegments";
IPAddressJoinedSegments["__interfaces"] = ["inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];




