/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressValueException } from '../AddressValueException';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { AddressSegmentParams } from './util/AddressSegmentParams';
import { AddressDivisionBase } from './AddressDivisionBase';
import { IPAddressStringDivision } from './IPAddressStringDivision';
import { AddressNetwork } from '../AddressNetwork';
import { AddressDivisionGrouping } from './AddressDivisionGrouping';
import { AddressDivision } from './AddressDivision';

/**
 * This class supports a segment of an arbitrary number of bits.
 * 
 * For a bit count less than or equal to 63 bits, AddressDivision is a more efficient choice.
 * 
 * @author sfoley
 * @param {Array} bytes
 * @param {Array} upperBytes
 * @param {number} bitCount
 * @param {number} defaultRadix
 * @param {IPAddressNetwork} network
 * @param {number} prefixLength
 * @class
 * @extends AddressDivisionBase
 */
export class IPAddressLargeDivision extends AddressDivisionBase implements IPAddressStringDivision {
    public static EXTENDED_DIGITS_RANGE_SEPARATOR : string; public static EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$() : string { if(IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR == null) IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR = Address.ALTERNATIVE_RANGE_SEPARATOR; return IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR; };

    public static EXTENDED_DIGITS_RANGE_SEPARATOR_STR : string; public static EXTENDED_DIGITS_RANGE_SEPARATOR_STR_$LI$() : string { if(IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_STR == null) IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_STR = /* valueOf */new String(IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$()).toString(); return IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_STR; };

    public static EXTENDED_DIGITS : string[]; public static EXTENDED_DIGITS_$LI$() : string[] { if(IPAddressLargeDivision.EXTENDED_DIGITS == null) IPAddressLargeDivision.EXTENDED_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '!', '#', '$', '%', '&', '(', ')', '*', '+', '-', ';', '<', '=', '>', '?', '@', '^', '_', '`', '{', '|', '}', '~']; return IPAddressLargeDivision.EXTENDED_DIGITS; };

    static __inet_ipaddr_format_IPAddressLargeDivision_serialVersionUID : number = 4;

    /*private*/ value : BigInteger;

    /*private*/ upperValue : BigInteger;

    /*private*/ maxValue : BigInteger;

    /*private*/ upperValueMasked : BigInteger;

    /*private*/ defaultRadix : BigInteger;

    /*private*/ bitCount : number;

    /*private*/ networkPrefixLength : number;

    /*private*/ __isSinglePrefixBlock : boolean;

    /*private*/ __isPrefixBlock : boolean;

    cachedWildcardString : string;

    public constructor(bytes? : any, upperBytes? : any, bitCount? : any, defaultRadix? : any, network? : any, prefixLength? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((upperBytes != null && upperBytes instanceof <any>Array && (upperBytes.length==0 || upperBytes[0] == null ||(typeof upperBytes[0] === 'number'))) || upperBytes === null) && ((typeof bitCount === 'number') || bitCount === null) && ((typeof defaultRadix === 'number') || defaultRadix === null) && ((network != null && network instanceof <any>IPAddressNetwork) || network === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super();
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            (() => {
                if(prefixLength != null && prefixLength < 0) {
                    throw new PrefixLenException(prefixLength);
                }
                bytes = IPAddressLargeDivision.extend(bytes, bitCount);
                upperBytes = IPAddressLargeDivision.extend(upperBytes, bitCount);
                this.maxValue = AddressDivisionBase.getMaxValue(bitCount);
                this.bitCount = bitCount;
                this.defaultRadix = BigInteger.valueOf(defaultRadix);
                if(prefixLength == null || prefixLength >= bitCount) {
                    if(prefixLength != null && prefixLength > bitCount) {
                        prefixLength = bitCount;
                    }
                    let low : BigInteger;
                    let high : BigInteger;
                    if(/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(bytes, upperBytes)) {
                        low = high = new BigInteger(1, bytes);
                        this.__isSinglePrefixBlock = prefixLength != null;
                    } else {
                        low = new BigInteger(1, bytes);
                        high = new BigInteger(1, upperBytes);
                        if(low.compareTo(high) > 0) {
                            let tmp : BigInteger = high;
                            high = low;
                            low = tmp;
                        }
                        this.__isSinglePrefixBlock = false;
                    }
                    this.__isPrefixBlock = prefixLength != null;
                    this.value = low;
                    this.upperValueMasked = this.upperValue = high;
                } else {
                    let shift : number = bitCount - prefixLength;
                    let byteShift : number = ((shift + 7) / 8|0);
                    let byteIndex : number = bytes.length - byteShift;
                    let mask : number = 255 & (~0 << (((shift - 1) % 8) + 1));
                    let upperByteIndex : number = upperBytes.length - byteShift;
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        let low : BigInteger;
                        let high : BigInteger;
                        let highMasked : BigInteger;
                        while((true)) {
                            bytes[byteIndex] &= mask;
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(bytes, byteIndex + 1, bytes.length, (<number>0|0));
                            low = new BigInteger(1, bytes);
                            upperBytes[upperByteIndex] |= ~mask;
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(upperBytes, upperByteIndex + 1, upperBytes.length, (<number>255|0));
                            high = new BigInteger(1, upperBytes);
                            let maskedUpperBytes : number[] = /* clone */upperBytes.slice(0);
                            maskedUpperBytes[upperByteIndex] &= mask;
                            /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(maskedUpperBytes, upperByteIndex + 1, upperBytes.length, (<number>0|0));
                            highMasked = new BigInteger(1, maskedUpperBytes);
                            if(low.compareTo(high) > 0) {
                                let tmp : number[] = upperBytes;
                                upperBytes = bytes;
                                bytes = tmp;
                                continue;
                            }
                            break;
                        };
                        this.value = low;
                        this.upperValue = high;
                        this.upperValueMasked = highMasked;
                        this.__isPrefixBlock = true;
                        this.__isSinglePrefixBlock = IPAddressLargeDivision.isPrefixSubnetBlock(bytes, upperBytes, bitCount, prefixLength, true, false);
                    } else {
                        let low : BigInteger;
                        let high : BigInteger;
                        if(/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(bytes, upperBytes)) {
                            low = high = new BigInteger(1, bytes);
                            this.__isPrefixBlock = this.__isSinglePrefixBlock = false;
                        } else {
                            low = new BigInteger(1, bytes);
                            high = new BigInteger(1, upperBytes);
                            let backIsPrefixed : boolean = IPAddressLargeDivision.isPrefixSubnetBlock(bytes, upperBytes, bitCount, prefixLength, false, true);
                            if(backIsPrefixed) {
                                this.__isPrefixBlock = true;
                                this.__isSinglePrefixBlock = IPAddressLargeDivision.isPrefixSubnetBlock(bytes, upperBytes, bitCount, prefixLength, true, false);
                            } else {
                                this.__isPrefixBlock = this.__isSinglePrefixBlock = false;
                            }
                            if(low.compareTo(high) > 0) {
                                let tmp : BigInteger = high;
                                high = low;
                                low = tmp;
                            }
                        }
                        this.value = low;
                        this.upperValue = high;
                        let maskedUpperBytes : number[] = /* clone */upperBytes.slice(0);
                        maskedUpperBytes[byteIndex] &= mask;
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(maskedUpperBytes, byteIndex + 1, bytes.length, (<number>0|0));
                        this.upperValueMasked = new BigInteger(1, maskedUpperBytes);
                    }
                }
                if(this.upperValue.compareTo(this.maxValue) > 0) {
                    throw new AddressValueException(this.upperValue);
                }
                this.networkPrefixLength = prefixLength;
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof upperBytes === 'number') || upperBytes === null) && ((typeof bitCount === 'number') || bitCount === null) && ((defaultRadix != null && defaultRadix instanceof <any>IPAddressNetwork) || defaultRadix === null) && ((typeof network === 'number') || network === null) && prefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let bitCount : any = __args[1];
            let defaultRadix : any = __args[2];
            let network : any = __args[3];
            let prefixLength : any = __args[4];
            super();
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            (() => {
                if(prefixLength != null && prefixLength < 0) {
                    throw new PrefixLenException(prefixLength);
                }
                this.maxValue = AddressDivisionBase.getMaxValue(bitCount);
                this.bitCount = bitCount;
                this.defaultRadix = BigInteger.valueOf(defaultRadix);
                if(prefixLength == null || prefixLength >= bitCount) {
                    if(prefixLength != null && prefixLength > bitCount) {
                        prefixLength = bitCount;
                    }
                    this.__isPrefixBlock = this.__isSinglePrefixBlock = prefixLength != null;
                    this.upperValueMasked = this.upperValue = this.value = new BigInteger(1, bytes);
                } else {
                    bytes = IPAddressLargeDivision.extend(bytes, bitCount);
                    let upperBytes : number[] = /* clone */bytes.slice(0);
                    let shift : number = bitCount - prefixLength;
                    let byteShift : number = ((shift + 7) / 8|0);
                    let byteIndex : number = bytes.length - byteShift;
                    let mask : number = 255 & (~0 << (((shift - 1) % 8) + 1));
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        bytes[byteIndex] &= mask;
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(bytes, byteIndex + 1, bytes.length, (<number>0|0));
                        this.upperValueMasked = this.value = new BigInteger(1, bytes);
                        upperBytes[byteIndex] |= ~mask;
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(upperBytes, byteIndex + 1, bytes.length, (<number>255|0));
                        this.upperValue = new BigInteger(1, upperBytes);
                        this.__isPrefixBlock = this.__isSinglePrefixBlock = true;
                    } else {
                        let maskedUpperBytes : number[] = /* clone */upperBytes.slice(0);
                        maskedUpperBytes[byteIndex] &= mask;
                        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(maskedUpperBytes, byteIndex + 1, bytes.length, (<number>0|0));
                        this.upperValueMasked = new BigInteger(1, maskedUpperBytes);
                        this.upperValue = this.value = new BigInteger(1, bytes);
                        this.__isPrefixBlock = this.__isSinglePrefixBlock = false;
                    }
                }
                if(this.upperValue.compareTo(this.maxValue) > 0) {
                    throw new AddressValueException(this.upperValue);
                }
                this.networkPrefixLength = prefixLength;
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof upperBytes === 'number') || upperBytes === null) && ((typeof bitCount === 'number') || bitCount === null) && defaultRadix === undefined && network === undefined && prefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let bitCount : any = __args[1];
            let defaultRadix : any = __args[2];
            super();
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            if(this.value===undefined) this.value = null;
            if(this.upperValue===undefined) this.upperValue = null;
            if(this.maxValue===undefined) this.maxValue = null;
            if(this.upperValueMasked===undefined) this.upperValueMasked = null;
            if(this.defaultRadix===undefined) this.defaultRadix = null;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = false;
            if(this.__isPrefixBlock===undefined) this.__isPrefixBlock = false;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            (() => {
                this.maxValue = AddressDivisionBase.getMaxValue(bitCount);
                this.bitCount = bitCount;
                this.defaultRadix = BigInteger.valueOf(defaultRadix);
                this.__isPrefixBlock = this.__isSinglePrefixBlock = false;
                this.upperValueMasked = this.upperValue = this.value = new BigInteger(1, bytes);
                this.networkPrefixLength = null;
                if(this.upperValue.compareTo(this.maxValue) > 0) {
                    throw new AddressValueException(this.upperValue);
                }
            })();
        } else throw new Error('invalid overload');
    }

    /*private*/ static isPrefixSubnetBlock(bytes : number[], upperBytes : number[], bitCount : number, prefix : number, front : boolean, back : boolean) : boolean {
        if(prefix == null) {
            return false;
        }
        let shift : number = bitCount - prefix;
        let byteShift : number = ((shift + 7) / 8|0);
        let byteIndex : number = bytes.length - byteShift;
        let mask : number = 255 & (~0 << (((shift - 1) % 8) + 1));
        let lowerByte : number = bytes[byteIndex];
        let upperByte : number = upperBytes[byteIndex];
        if(front) {
            let lower : number = lowerByte & mask;
            let upper : number = upperByte & mask;
            if(lower !== upper) {
                return false;
            }
            for(let i : number = byteIndex - 1; i >= 0; i--) {
                if(bytes[i] !== upperBytes[i]) {
                    return false;
                }
            };
        }
        if(back) {
            let hostMask : number = 255 & ~mask;
            let lower : number = lowerByte & hostMask;
            let upper : number = upperByte & hostMask;
            if(lower !== 0 || upper !== hostMask) {
                return false;
            }
            for(let i : number = byteIndex + 1; i < bytes.length; i++) {
                if(bytes[i] !== 0 || upperBytes[i] !== (<number>255|0)) {
                    return false;
                }
            };
        }
        return true;
    }

    /*private*/ static extend(bytes : number[], bitCount : number) : number[] {
        return IPAddressLargeDivision.convert(bytes, ((bitCount + 7) / 8|0), "");
    }

    /*private*/ static convert(bytes : number[], requiredByteCount : number, key : string) : number[] {
        let len : number = bytes.length;
        if(len < requiredByteCount) {
            let oldBytes : number[] = bytes;
            bytes = (s => { let a=[]; while(s-->0) a.push(0); return a; })(requiredByteCount);
            let diff : number = bytes.length - oldBytes.length;
            let mostSignificantBit : number = 128 & oldBytes[0];
            if(mostSignificantBit !== 0) {
                /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(bytes, 0, diff, (<number>255|0));
            }
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(oldBytes, 0, bytes, diff, oldBytes.length);
        } else {
            if(len > requiredByteCount) {
                let i : number = 0;
                do {
                    if(bytes[i++] !== 0) {
                        throw new AddressValueException(key, len);
                    }
                } while((--len > requiredByteCount));
                bytes = Arrays.copyOfRange(bytes, i, bytes.length);
            }
        }
        return bytes;
    }

    /**
     * 
     * @param {number} val
     * @return {boolean}
     */
    public isBoundedBy(val : number) : boolean {
        let bigVal : BigInteger = BigInteger.valueOf(val);
        return this.upperValue.compareTo(bigVal) < 0;
    }

    public getDigitCount$int(radix : number) : number {
        if(!this.isMultiple() && radix === this.getDefaultTextualRadix()) {
            return this.getString().length;
        }
        return IPAddressLargeDivision.getDigitCountStatic(this.upperValue, radix);
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getCount() : BigInteger {
        return this.upperValue.subtract(this.value).add(BigInteger.ONE);
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.bitCount;
    }

    /**
     * 
     * @return {boolean}
     */
    public isMultiple() : boolean {
        return !this.value.equals(this.upperValue);
    }

    /**
     * 
     * @return {boolean}
     */
    public includesZero() : boolean {
        return this.value.equals(BigInteger.ZERO);
    }

    /**
     * 
     * @return {boolean}
     */
    public includesMax() : boolean {
        return this.upperValue.equals(this.maxValue);
    }

    /**
     * 
     * @return {boolean}
     */
    public isMax() : boolean {
        return this.includesMax() && !this.isMultiple();
    }

    /**
     * 
     * @return {boolean}
     */
    public isZero() : boolean {
        return this.includesZero() && !this.isMultiple();
    }

    /**
     * 
     * @return {boolean}
     */
    public isFullRange() : boolean {
        return this.includesZero() && this.includesMax();
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        return IPAddressLargeDivision.convert(low?this.value.toByteArray():this.upperValue.toByteArray(), ((this.bitCount + 7) / 8|0), "");
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return this.defaultRadix.intValue();
    }

    public getMaxDigitCount$() : number {
        return AddressDivisionBase.getMaxDigitCount$int$int$java_math_BigInteger(this.defaultRadix.intValue(), this.bitCount, this.maxValue);
    }

    public getMaxDigitCount$int(radix : number) : number {
        return AddressDivisionBase.getMaxDigitCount$int$int$java_math_BigInteger(radix, this.bitCount, this.maxValue);
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            return <any>this.getMaxDigitCount$int(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @return {number}
     */
    adjustLowerLeadingZeroCount(leadingZeroCount : number, radix : number) : number {
        return this.adjustLeadingZeroCount(leadingZeroCount, this.value, radix);
    }

    /**
     * 
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @return {number}
     */
    adjustUpperLeadingZeroCount(leadingZeroCount : number, radix : number) : number {
        return this.adjustLeadingZeroCount(leadingZeroCount, this.upperValue, radix);
    }

    /*private*/ adjustLeadingZeroCount(leadingZeroCount : number, value : BigInteger, radix : number) : number {
        if(leadingZeroCount < 0) {
            let width : number = this.getDigitCount$java_math_BigInteger$int(value, radix);
            return Math.max(0, this.getMaxDigitCount$int(radix) - width);
        }
        return leadingZeroCount;
    }

    public getDigitCount$java_math_BigInteger$int(val : BigInteger, radix : number) : number {
        let bigRadix : BigInteger = this.defaultRadix.intValue() === radix?this.defaultRadix:BigInteger.valueOf(radix);
        return AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(val, bigRadix);
    }

    public getDigitCount(val? : any, radix? : any) : any {
        if(((val != null && val instanceof <any>BigInteger) || val === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>this.getDigitCount$java_math_BigInteger$int(val, radix);
        } else if(((typeof val === 'number') || val === null) && radix === undefined) {
            return <any>this.getDigitCount$int(val);
        } else throw new Error('invalid overload');
    }

    /*private*/ static getDigitCountStatic(val : BigInteger, radix : number) : number {
        return AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(val, BigInteger.valueOf(radix));
    }

    /*private*/ toDefaultString(val : BigInteger, radix : number, uppercase : boolean, choppedDigits : number) : string {
        let bigRadix : BigInteger = this.defaultRadix.intValue() === radix?this.defaultRadix:BigInteger.valueOf(radix);
        return IPAddressLargeDivision.toDefaultString(val, bigRadix, uppercase, choppedDigits, AddressDivisionBase.getMaxDigitCount$int$int$java_math_BigInteger(radix, this.bitCount, null));
    }

    /*private*/ static toDefaultStringRecursive(val : BigInteger, radix : BigInteger, uppercase : boolean, choppedDigits : number, digitCount : number, dig : string[], highest : boolean, builder : { str: string }) {
        if(val.compareTo(AddressDivisionGrouping.LONG_MAX_$LI$()) <= 0) {
            let longVal : number = val.longValue();
            let intRadix : number = radix.intValue();
            if(!highest) {
                AddressDivisionBase.getLeadingZeros(digitCount - AddressDivision.toUnsignedStringLength$long$int(longVal, intRadix), builder);
            }
            AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(longVal, intRadix, choppedDigits, uppercase, dig, builder);
        } else {
            let halfCount : number = digitCount >>> 1;
            if(halfCount > choppedDigits) {
                let radixPower : BigInteger = AddressDivisionBase.getRadixPower(radix, halfCount);
                let highLow : BigInteger[] = val.divideAndRemainder(radixPower);
                let high : BigInteger = highLow[0];
                let low : BigInteger = highLow[1];
                if(highest && high.equals(BigInteger.ZERO)) {
                    IPAddressLargeDivision.toDefaultStringRecursive(low, radix, uppercase, choppedDigits, halfCount, dig, true, builder);
                } else {
                    if(digitCount > choppedDigits) {
                        IPAddressLargeDivision.toDefaultStringRecursive(high, radix, uppercase, Math.max(0, choppedDigits - halfCount), digitCount - halfCount, dig, highest, builder);
                    }
                    IPAddressLargeDivision.toDefaultStringRecursive(low, radix, uppercase, choppedDigits, halfCount, dig, false, builder);
                }
            }
        }
    }

    /*private*/ isExtendedDigits() : boolean {
        return IPAddressLargeDivision.isExtendedDigits(this.defaultRadix.intValue());
    }

    /*private*/ static isExtendedDigits(radix : number) : boolean {
        return radix > 36;
    }

    /*private*/ static getDigits(radix : number, uppercase : boolean) : string[] {
        if(IPAddressLargeDivision.isExtendedDigits(radix)) {
            return IPAddressLargeDivision.EXTENDED_DIGITS_$LI$();
        }
        return uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$();
    }

    /**
     * 
     * @param {*} str
     * @param {number} radix
     * @param {{ str: string }} appendable
     */
    appendUppercase(str : any, radix : number, appendable : { str: string }) {
        if(radix > 10 && !this.isExtendedDigits()) {
            for(let i : number = 0; i < str.length; i++) {
                let c : string = str.charAt(i);
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'z'.charCodeAt(0)) {
                    c = String.fromCharCode((c).charCodeAt(0) + 'A'.charCodeAt(0) - 'a'.charCodeAt(0));
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(appendable);
            };
        } else {
            /* append */(sb => { sb.str = sb.str.concat(<any>str); return sb; })(appendable);
        }
    }

    /*private*/ static toDefaultString(val : BigInteger, radix : BigInteger, uppercase : boolean, choppedDigits : number, maxDigits : number) : string {
        if(val.equals(BigInteger.ZERO)) {
            return "0";
        }
        if(val.equals(BigInteger.ONE)) {
            return "1";
        }
        let dig : string[] = IPAddressLargeDivision.getDigits(radix.intValue(), uppercase);
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        if(maxDigits > 0) {
            if(maxDigits > choppedDigits) {
                IPAddressLargeDivision.toDefaultStringRecursive(val, radix, uppercase, choppedDigits, maxDigits, dig, true, builder);
            }
        } else {
            do {
                let divisorRemainder : BigInteger[] = val.divideAndRemainder(radix);
                let quotient : BigInteger = divisorRemainder[0];
                let remainder : BigInteger = divisorRemainder[1];
                if(choppedDigits > 0) {
                    --choppedDigits;
                    continue;
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>dig[remainder.intValue()]); return sb; })(builder);
                val = quotient;
            } while((!val.equals(BigInteger.ZERO)));
            builder.reverse();
        }
        return /* toString */builder.str;
    }

    /**
     * Produces a normalized string to represent the segment.
     * If the segment CIDR prefix length covers the range, then it is assumed to be a CIDR, and the string has only the lower value of the CIDR range.
     * Otherwise, the explicit range will be printed.
     * @return
     * @return {string}
     */
    public getString() : string {
        let result : string = this.cachedString;
        if(result == null) {
            {
                result = this.cachedString;
                if(result == null) {
                    if(this.isSinglePrefixBlock() || !this.isMultiple()) {
                        result = this.getDefaultString();
                    } else if(!this.isFullRange() || (result = this.getDefaultSegmentWildcardString()) == null) {
                        if(this.isPrefixed() && this.isPrefixBlock$int(this.getDivisionPrefixLength())) {
                            result = this.getDefaultMaskedRangeString();
                        } else {
                            result = this.getDefaultRangeString();
                        }
                    }
                    this.cachedString = result;
                }
            };
        }
        return result;
    }

    /**
     * Produces a string to represent the segment, favouring wildcards and range characters over the network prefix to represent subnets.
     * If it exists, the segment CIDR prefix is ignored and the explicit range is printed.
     * @return
     * @return {string}
     */
    public getWildcardString() : string {
        let result : string = this.cachedWildcardString;
        if(result == null) {
            {
                result = this.cachedWildcardString;
                if(result == null) {
                    if(!this.isPrefixed() || !this.isMultiple()) {
                        result = this.getString();
                    } else if(!this.isFullRange() || (result = this.getDefaultSegmentWildcardString()) == null) {
                        result = this.getDefaultRangeString();
                    }
                    this.cachedWildcardString = result;
                }
            };
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    getDefaultString() : string {
        return IPAddressLargeDivision.toDefaultString(this.value, this.defaultRadix, false, 0, this.getMaxDigitCount());
    }

    public getDefaultRangeString(val1? : any, val2? : any, radix? : any) : any {
        if(val1 === undefined && val2 === undefined && radix === undefined) {
            return <any>this.getDefaultRangeString$();
        } else throw new Error('invalid overload');
    }

    getDefaultRangeString$() : string {
        let maxDigitCount : number = this.getMaxDigitCount();
        return IPAddressLargeDivision.toDefaultString(this.value, this.defaultRadix, false, 0, maxDigitCount) + this.getDefaultRangeSeparatorString() + IPAddressLargeDivision.toDefaultString(this.upperValue, this.defaultRadix, false, 0, maxDigitCount);
    }

    getDefaultMaskedRangeString() : string {
        let maxDigitCount : number = this.getMaxDigitCount();
        return IPAddressLargeDivision.toDefaultString(this.value, this.defaultRadix, false, 0, maxDigitCount) + this.getDefaultRangeSeparatorString() + IPAddressLargeDivision.toDefaultString(this.upperValueMasked, this.defaultRadix, false, 0, maxDigitCount);
    }

    /**
     * 
     * @return {string}
     */
    getDefaultSegmentWildcardString() : string {
        return this.isExtendedDigits()?null:Address.SEGMENT_WILDCARD_STR_$LI$();
    }

    /**
     * 
     * @return {string}
     */
    getDefaultRangeSeparatorString() : string {
        return this.isExtendedDigits()?IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_STR_$LI$():Address.RANGE_SEPARATOR_STR_$LI$();
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getLowerStringLength(radix : number) : number {
        return AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(this.value, this.defaultRadix);
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getUpperStringLength(radix : number) : number {
        return AddressDivisionBase.getDigitCount$java_math_BigInteger$java_math_BigInteger(this.upperValue, this.defaultRadix);
    }

    getLowerString$int$boolean$java_lang_StringBuilder(radix : number, uppercase : boolean, appendable : { str: string }) {
        /* append */(sb => { sb.str = sb.str.concat(<any>this.toDefaultString(this.value, radix, uppercase, 0)); return sb; })(appendable);
    }

    public getLowerString$int$int$boolean$java_lang_StringBuilder(radix : number, choppedDigits : number, uppercase : boolean, appendable : { str: string }) {
        /* append */(sb => { sb.str = sb.str.concat(<any>this.toDefaultString(this.value, radix, uppercase, choppedDigits)); return sb; })(appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {number} choppedDigits
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    public getLowerString(radix? : any, choppedDigits? : any, uppercase? : any, appendable? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'number') || choppedDigits === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getLowerString$int$int$boolean$java_lang_StringBuilder(radix, choppedDigits, uppercase, appendable);
        } else if(((typeof radix === 'number') || radix === null) && ((typeof choppedDigits === 'boolean') || choppedDigits === null) && ((uppercase != null && (uppercase instanceof Object)) || uppercase === null) && appendable === undefined) {
            return <any>this.getLowerString$int$boolean$java_lang_StringBuilder(radix, choppedDigits, uppercase);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    getUpperString(radix : number, uppercase : boolean, appendable : { str: string }) {
        /* append */(sb => { sb.str = sb.str.concat(<any>this.toDefaultString(this.upperValue, radix, uppercase, 0)); return sb; })(appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    getUpperStringMasked(radix : number, uppercase : boolean, appendable : { str: string }) {
        /* append */(sb => { sb.str = sb.str.concat(<any>this.toDefaultString(this.upperValueMasked, radix, uppercase, 0)); return sb; })(appendable);
    }

    /**
     * 
     * @param {number} radix
     * @param {number} choppedDigits
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @param {{ str: string }} appendable
     */
    getSplitLowerString(radix : number, choppedDigits : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        this.getLowerString$int$int$boolean$java_lang_StringBuilder(radix, choppedDigits, uppercase, builder);
        let prefLen : number = stringPrefix.length;
        for(let i : number = 0; i < /* length */builder.str.length; i++) {
            if(i > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
            }
            if(prefLen > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>/* charAt */builder.str.charAt(reverseSplitDigits?(/* length */builder.str.length - i - 1):i)); return sb; })(appendable);
        };
    }

    public getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator : string, wildcard : string, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string, appendable : { str: string }) {
        let lowerBuilder : { str: string } = { str: "", toString: function() { return this.str; } };
        let upperBuilder : { str: string } = { str: "", toString: function() { return this.str; } };
        this.getLowerString$int$boolean$java_lang_StringBuilder(radix, uppercase, lowerBuilder);
        this.getUpperString(radix, uppercase, upperBuilder);
        let diff : number = /* length */upperBuilder.str.length - /* length */lowerBuilder.str.length;
        if(diff > 0) {
            let newLowerBuilder : { str: string } = { str: "", toString: function() { return this.str; } };
            while((diff-- > 0)) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'0'); return sb; })(newLowerBuilder);
            };
            /* append */(sb => { sb.str = sb.str.concat(<any>lowerBuilder); return sb; })(newLowerBuilder);
            lowerBuilder = newLowerBuilder;
        }
        let previousWasFull : boolean = true;
        let nextMustBeFull : boolean = false;
        let dig : string[] = IPAddressLargeDivision.getDigits(radix, uppercase);
        let zeroDigit : string = dig[0];
        let highestDigit : string = dig[radix - 1];
        let len : number = /* length */lowerBuilder.str.length;
        let prefLen : number = stringPrefix.length;
        for(let i : number = 0; i < len; i++) {
            let index : number = reverseSplitDigits?(len - i - 1):i;
            let lower : string = /* charAt */lowerBuilder.str.charAt(index);
            let upper : string = /* charAt */upperBuilder.str.charAt(index);
            if(i > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>splitDigitSeparator); return sb; })(appendable);
            }
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(lower) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(upper)) {
                if(nextMustBeFull) {
                    throw new IncompatibleAddressException((lower).charCodeAt(0), (upper).charCodeAt(0), "ipaddress.error.splitMismatch");
                }
                if(prefLen > 0) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>lower); return sb; })(appendable);
            } else {
                let isFullRange : boolean = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(lower) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(zeroDigit)) && ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(upper) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(highestDigit));
                if(isFullRange) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>wildcard); return sb; })(appendable);
                } else {
                    if(nextMustBeFull) {
                        throw new IncompatibleAddressException((lower).charCodeAt(0), (upper).charCodeAt(0), "ipaddress.error.splitMismatch");
                    }
                    if(prefLen > 0) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>stringPrefix); return sb; })(appendable);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>lower); return sb; })(appendable);
                    /* append */(sb => { sb.str = sb.str.concat(<any>rangeSeparator); return sb; })(appendable);
                    /* append */(sb => { sb.str = sb.str.concat(<any>upper); return sb; })(appendable);
                }
                if(reverseSplitDigits) {
                    if(!previousWasFull) {
                        throw new IncompatibleAddressException((lower).charCodeAt(0), (upper).charCodeAt(0), "ipaddress.error.splitMismatch");
                    }
                    previousWasFull = isFullRange;
                } else {
                    nextMustBeFull = true;
                }
            }
        };
    }

    /**
     * 
     * @param {string} rangeSeparator
     * @param {string} wildcard
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @param {{ str: string }} appendable
     */
    public getSplitRangeString(rangeSeparator? : any, wildcard? : any, radix? : any, uppercase? : any, splitDigitSeparator? : any, reverseSplitDigits? : any, stringPrefix? : any, appendable? : any) : any {
        if(((typeof rangeSeparator === 'string') || rangeSeparator === null) && ((typeof wildcard === 'string') || wildcard === null) && ((typeof radix === 'number') || radix === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof splitDigitSeparator === 'string') || splitDigitSeparator === null) && ((typeof reverseSplitDigits === 'boolean') || reverseSplitDigits === null) && ((typeof stringPrefix === 'string') || stringPrefix === null) && ((appendable != null && (appendable instanceof Object)) || appendable === null)) {
            return <any>this.getSplitRangeString$java_lang_String$java_lang_String$int$boolean$char$boolean$java_lang_String$java_lang_StringBuilder(rangeSeparator, wildcard, radix, uppercase, splitDigitSeparator, reverseSplitDigits, stringPrefix, appendable);
        } else if(((typeof rangeSeparator === 'number') || rangeSeparator === null) && ((wildcard != null && (wildcard["__interfaces"] != null && wildcard["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0 || wildcard.constructor != null && wildcard.constructor["__interfaces"] != null && wildcard.constructor["__interfaces"].indexOf("inet.ipaddr.format.util.AddressSegmentParams") >= 0)) || wildcard === null) && ((radix != null && (radix instanceof Object)) || radix === null) && uppercase === undefined && splitDigitSeparator === undefined && reverseSplitDigits === undefined && stringPrefix === undefined && appendable === undefined) {
            return <any>this.getSplitRangeString$int$inet_ipaddr_format_util_AddressSegmentParams$java_lang_StringBuilder(rangeSeparator, wildcard, radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {string} rangeSeparator
     * @param {string} wildcard
     * @param {number} leadingZeroCount
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {string} splitDigitSeparator
     * @param {boolean} reverseSplitDigits
     * @param {string} stringPrefix
     * @return {number}
     */
    getSplitRangeStringLength(rangeSeparator : string, wildcard : string, leadingZeroCount : number, radix : number, uppercase : boolean, splitDigitSeparator : string, reverseSplitDigits : boolean, stringPrefix : string) : number {
        let digitsLength : number = -1;
        let stringPrefixLength : number = stringPrefix.length;
        let lowerBuilder : { str: string } = { str: "", toString: function() { return this.str; } };
        let upperBuilder : { str: string } = { str: "", toString: function() { return this.str; } };
        this.getLowerString$int$boolean$java_lang_StringBuilder(radix, uppercase, lowerBuilder);
        this.getUpperString(radix, uppercase, upperBuilder);
        let dig : string[] = IPAddressLargeDivision.getDigits(radix, uppercase);
        let zeroDigit : string = dig[0];
        let highestDigit : string = dig[radix - 1];
        let remainingAfterLoop : number = leadingZeroCount;
        for(let i : number = 1; i <= /* length */upperBuilder.str.length; i++) {
            let lower : string = (i <= /* length */lowerBuilder.str.length)?/* charAt */lowerBuilder.str.charAt(/* length */lowerBuilder.str.length - i):String.fromCharCode(0);
            let upperIndex : number = /* length */upperBuilder.str.length - i;
            let upper : string = /* charAt */upperBuilder.str.charAt(upperIndex);
            let isFullRange : boolean = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(lower) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(zeroDigit)) && ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(upper) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(highestDigit));
            if(isFullRange) {
                digitsLength += wildcard.length + 1;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(lower) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(upper)) {
                digitsLength += (stringPrefixLength << 1) + 4;
            } else {
                remainingAfterLoop += upperIndex + 1;
                break;
            }
        };
        if(remainingAfterLoop > 0) {
            digitsLength += remainingAfterLoop * (stringPrefixLength + 2);
        }
        return digitsLength;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    getRangeDigitCount(radix : number) : number {
        if(!this.isMultiple()) {
            return 0;
        }
        let val : BigInteger = this.value;
        let upperVal : BigInteger = this.upperValue;
        let count : number = 1;
        let bigRadix : BigInteger = BigInteger.valueOf(radix);
        let bigUpper : BigInteger = BigInteger.valueOf(radix - 1);
        while((true)) {
            let highLow : BigInteger[] = val.divideAndRemainder(bigRadix);
            let quotient : BigInteger = highLow[0];
            let remainder : BigInteger = highLow[1];
            if(remainder.equals(BigInteger.ZERO)) {
                highLow = upperVal.divideAndRemainder(bigRadix);
                let upperQuotient : BigInteger = highLow[0];
                remainder = highLow[1];
                if(remainder.equals(bigUpper)) {
                    val = quotient;
                    upperVal = upperQuotient;
                    if(val.equals(upperVal)) {
                        return count;
                    } else {
                        count++;
                        continue;
                    }
                }
            }
            return 0;
        };
    }

    /**
     * 
     * @param {number} segmentIndex
     * @param {*} params
     * @param {{ str: string }} appendable
     * @return {number}
     */
    public getPrefixAdjustedRangeString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        return super.getPrefixAdjustedRangeString(segmentIndex, params, appendable);
    }

    /**
     * 
     * @param {number} segmentValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isPrefixBlock(segmentValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof segmentValue === 'number') || segmentValue === null) && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$int(segmentValue);
        } else if(segmentValue === undefined && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public isPrefixBlock$() : boolean {
        return this.__isPrefixBlock;
    }

    /**
     * 
     * @param {number} segmentValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isSinglePrefixBlock(segmentValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(segmentValue === undefined && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isSinglePrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public isSinglePrefixBlock$() : boolean {
        return this.__isSinglePrefixBlock;
    }

    /**
     * 
     * @return {number}
     */
    public getDivisionPrefixLength() : number {
        return this.networkPrefixLength;
    }

    public isPrefixed() : boolean {
        return this.networkPrefixLength != null;
    }

    public isPrefixBlock$int(divisionPrefixLen : number) : boolean {
        if(divisionPrefixLen === 0) {
            return this.isFullRange();
        }
        let prefixLen : number = divisionPrefixLen;
        let lower : BigInteger = this.value;
        let upper : BigInteger = this.upperValue;
        let hostBits : number = this.bitCount - prefixLen;
        let fullMask : number = ~0;
        do {
            let low : number = lower.longValue();
            let up : number = upper.longValue();
            if(hostBits <= 64) {
                let networkMask : number;
                let hostMask : number;
                if(hostBits === 64) {
                    networkMask = 0;
                    hostMask = fullMask;
                } else {
                    networkMask = fullMask << hostBits;
                    hostMask = ~networkMask;
                }
                let maskedLow : number = low & networkMask;
                let maskedUp : number = up | hostMask;
                return low === maskedLow && up === maskedUp;
            } else {
                if(low !== 0 || up !== fullMask) {
                    return false;
                }
            }
            lower = lower.shiftRight(64);
            upper = upper.shiftRight(64);
            hostBits -= 64;
        } while((!upper.equals(BigInteger.ZERO)));
        return false;
    }
}
IPAddressLargeDivision["__class"] = "inet.ipaddr.format.IPAddressLargeDivision";
IPAddressLargeDivision["__interfaces"] = ["inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.io.Serializable"];





IPAddressLargeDivision.EXTENDED_DIGITS_$LI$();

IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_STR_$LI$();

IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$();
