/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressValueException } from '../AddressValueException';
import { AddressDivision } from './AddressDivision';

/**
 * An address division for mac
 * 
 * @author sfoley
 * @param {number} lower
 * @param {number} upper
 * @param {number} bitCount
 * @param {number} defaultRadix
 * @class
 * @extends AddressDivision
 */
export class AddressBitsDivision extends AddressDivision {
    static __inet_ipaddr_format_AddressBitsDivision_serialVersionUID : number = 4;

    value : number;

    upperValue : number;

    /*private*/ bitCount : number;

    /*private*/ defaultRadix : number;

    public constructor(lower? : any, upper? : any, bitCount? : any, defaultRadix? : any) {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof bitCount === 'number') || bitCount === null) && ((typeof defaultRadix === 'number') || defaultRadix === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super();
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            (() => {
                if(lower < 0 || upper < 0) {
                    throw new AddressValueException(lower < 0?lower:upper);
                }
                if(lower > upper) {
                    let tmp : number = lower;
                    lower = upper;
                    upper = tmp;
                }
                this.value = lower;
                this.upperValue = upper;
                this.bitCount = bitCount;
                this.defaultRadix = defaultRadix;
            })();
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof bitCount === 'number') || bitCount === null) && defaultRadix === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            let bitCount : any = __args[1];
            let defaultRadix : any = __args[2];
            super();
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            if(this.value===undefined) this.value = 0;
            if(this.upperValue===undefined) this.upperValue = 0;
            if(this.bitCount===undefined) this.bitCount = 0;
            if(this.defaultRadix===undefined) this.defaultRadix = 0;
            (() => {
                if(value < 0) {
                    throw new AddressValueException(value);
                }
                this.value = this.upperValue = value;
                this.bitCount = bitCount;
                this.defaultRadix = defaultRadix;
            })();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getLowerValue() : number {
        return this.value;
    }

    /**
     * 
     * @return {number}
     */
    public getUpperValue() : number {
        return this.upperValue;
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        return low?[(<number>(this.value >> 8)|0), (<number>(255 & this.value)|0)]:[(<number>(this.upperValue >> 8)|0), (<number>(255 & this.upperValue)|0)];
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.bitCount;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        return (this.getBitCount() + 3) >> 2;
    }

    isSameValues$inet_ipaddr_format_AddressDivision(other : AddressDivision) : boolean {
        if(other != null && other instanceof <any>AddressBitsDivision) {
            return this.isSameValues$inet_ipaddr_format_AddressDivision(<AddressBitsDivision>other);
        }
        return false;
    }

    public isSameValues$inet_ipaddr_format_AddressBitsDivision(otherSegment : AddressBitsDivision) : boolean {
        return this.value === otherSegment.value && this.upperValue === otherSegment.upperValue;
    }

    public isSameValues(otherSegment? : any) : any {
        if(((otherSegment != null && otherSegment instanceof <any>AddressBitsDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressBitsDivision(otherSegment);
        } else if(((otherSegment != null && otherSegment instanceof <any>AddressDivision) || otherSegment === null)) {
            return <any>this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public equals(other : any) : boolean {
        if(other === this) {
            return true;
        }
        if(other != null && other instanceof <any>AddressBitsDivision) {
            let otherSegments : AddressBitsDivision = <AddressBitsDivision>other;
            return this.isSameValues$inet_ipaddr_format_AddressDivision(otherSegments);
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        return (<number>(this.value | (this.upperValue << this.getBitCount()))|0);
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return this.defaultRadix;
    }
}
AddressBitsDivision["__class"] = "inet.ipaddr.format.AddressBitsDivision";
AddressBitsDivision["__interfaces"] = ["inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];




