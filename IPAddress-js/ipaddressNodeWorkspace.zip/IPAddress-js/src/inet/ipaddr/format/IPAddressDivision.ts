/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddress } from '../IPAddress';
import { IPAddressSection } from '../IPAddressSection';
import { PrefixLenException } from '../PrefixLenException';
import { AddressSegmentParams } from './util/AddressSegmentParams';
import { AddressDivision } from './AddressDivision';
import { IPAddressStringDivision } from './IPAddressStringDivision';

/**
 * A division of an IP address.
 * 
 * May be associated with a prefix length, in which case that number of bits in the upper-most
 * portion of the object represent a prefix, while the remaining bits can assume all possible values.
 * 
 * @author sfoley
 * @extends AddressDivision
 * @class
 */
export abstract class IPAddressDivision extends AddressDivision implements IPAddressStringDivision {
    static serialVersionUID : number = 4;

    /*private*/ divisionNetworkPrefix : number;

    cachedWildcardString : string;

    /*private*/ __isSinglePrefixBlock : boolean;

    public constructor(networkPrefixLength? : any) {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super();
            if(this.divisionNetworkPrefix===undefined) this.divisionNetworkPrefix = null;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = null;
            if(this.divisionNetworkPrefix===undefined) this.divisionNetworkPrefix = null;
            if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
            if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = null;
            (() => {
                if(networkPrefixLength != null && networkPrefixLength < 0) {
                    throw new PrefixLenException(networkPrefixLength);
                }
                this.divisionNetworkPrefix = networkPrefixLength;
            })();
        } else if(networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super();
                if(this.divisionNetworkPrefix===undefined) this.divisionNetworkPrefix = null;
                if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
                if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = null;
                if(this.divisionNetworkPrefix===undefined) this.divisionNetworkPrefix = null;
                if(this.cachedWildcardString===undefined) this.cachedWildcardString = null;
                if(this.__isSinglePrefixBlock===undefined) this.__isSinglePrefixBlock = null;
                (() => {
                    if(networkPrefixLength != null && networkPrefixLength < 0) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    this.divisionNetworkPrefix = networkPrefixLength;
                })();
            }
        } else throw new Error('invalid overload');
    }

    public isPrefixed() : boolean {
        return this.divisionNetworkPrefix != null;
    }

    /**
     * Returns the network prefix for the division.
     * 
     * The network prefix is 16 for an address like 1.2.0.0/16.
     * 
     * When it comes to each address division or segment, the prefix for the division is the
     * prefix obtained when applying the address or section prefix.
     * 
     * For instance, with the address 1.2.0.0/20,
     * segment 1 has no prefix because the address prefix 20 extends beyond the 8 bits in the first segment, it does not even apply to the segment,
     * segment 2 has no prefix because the address prefix extends beyond bits 9 to 16 which lie in the second segment, it does not apply to that segment either,
     * segment 3 has the prefix 4 because the address prefix 20 corresponds to the first 4 bits in the 3rd segment,
     * which means that the first 4 bits are part of the network section of the address or segment,
     * and segment 4 has the prefix 0 because not a single bit is in the network section of the address or segment
     * 
     * The prefix applied across the address is null ... null ... (1 to segment bit length) ... 0 ... 0
     * 
     * If the segment has no prefix then null is returned.
     * 
     * @return
     * @return {number}
     */
    public getDivisionPrefixLength() : number {
        return this.divisionNetworkPrefix;
    }

    public matchesWithPrefixMask(value? : any, segmentPrefixLength? : any) : any {
        if(((typeof value === 'number') || value === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            return <any>this.matchesWithPrefixMask$long$java_lang_Integer(value, segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    public matchesWithPrefixMask$long$java_lang_Integer(value : number, divisionPrefixLen : number) : boolean {
        if(divisionPrefixLen == null) {
            return this.matches$long(value);
        }
        let mask : number = this.getDivisionNetworkMask(divisionPrefixLen);
        let matchingValue : number = value & mask;
        return matchingValue === (this.getLowerValue() & mask) && matchingValue === (this.getUpperValue() & mask);
    }

    abstract getDivisionNetworkMask(bits : number) : number;

    abstract getDivisionHostMask(bits : number) : number;

    /**
     * If this is equivalent to the mask for a CIDR prefix length block or subnet class, it returns the prefix length.
     * Otherwise, it returns null.
     * A CIDR network mask is an address with all 1s in the network section (the upper bits) and then all 0s in the host section.
     * A CIDR host mask is an address with all 0s in the network section (the lower bits) and then all 1s in the host section.
     * The prefix length is the length of the network section.
     * 
     * Also, keep in mind that the prefix length returned by this method is not equivalent to the prefix length used to construct this object.
     * The prefix length used to construct indicates the network and host portion of this address.
     * The prefix length returned here indicates the whether the value of this address can be used as a mask for the network and host of an address with that prefix length.
     * Therefore the two values can be different values, or one can be null while the other is not.
     * 
     * This method applies only to the lower value of the range if this segment represents multiple values.
     * 
     * @see IPAddressSection#getPrefixLengthForSingleBlock()
     * 
     * @param {boolean} network whether to check for a network mask or a host mask
     * @return {number} the prefix length corresponding to this mask, or null if there is no such prefix length
     */
    public getBlockMaskPrefixLength(network : boolean) : number {
        let val : number;
        let invertedVal : number;
        if(network) {
            val = this.getLowerValue();
            invertedVal = ~val & this.getMaxValue();
        } else {
            invertedVal = this.getLowerValue();
            val = ~invertedVal & this.getMaxValue();
        }
        let bitCount : number = this.getBitCount();
        let hostLength : number = Math.min(javaemul.internal.LongHelper.numberOfTrailingZeros(val), bitCount);
        let shifted : number = invertedVal >>> hostLength;
        return shifted === 0?bitCount - hostLength:null;
    }

    public isPrefixBlock$long$long$int(segmentValue : number, upperValue : number, divisionPrefixLen : number) : boolean {
        if(divisionPrefixLen === 0) {
            return this.isFullRange();
        }
        return AddressDivision.testRange(segmentValue, upperValue, upperValue, this.getDivisionNetworkMask(divisionPrefixLen), this.getDivisionHostMask(divisionPrefixLen));
    }

    /**
     * 
     * @param {number} segmentValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isPrefixBlock(segmentValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof segmentValue === 'number') || segmentValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            return <any>this.isPrefixBlock$long$long$int(segmentValue, upperValue, divisionPrefixLen);
        } else if(((typeof segmentValue === 'number') || segmentValue === null) && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$int(segmentValue);
        } else if(segmentValue === undefined && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    public isSinglePrefixBlock$long$long$int(segmentValue : number, upperValue : number, divisionPrefixLen : number) : boolean {
        return AddressDivision.testRange(segmentValue, segmentValue, upperValue, this.getDivisionNetworkMask(divisionPrefixLen), this.getDivisionHostMask(divisionPrefixLen));
    }

    /**
     * 
     * @param {number} segmentValue
     * @param {number} upperValue
     * @param {number} divisionPrefixLen
     * @return {boolean}
     */
    public isSinglePrefixBlock(segmentValue? : any, upperValue? : any, divisionPrefixLen? : any) : any {
        if(((typeof segmentValue === 'number') || segmentValue === null) && ((typeof upperValue === 'number') || upperValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null)) {
            return <any>this.isSinglePrefixBlock$long$long$int(segmentValue, upperValue, divisionPrefixLen);
        } else if(((typeof segmentValue === 'number') || segmentValue === null) && ((typeof upperValue === 'number') || upperValue === null) && divisionPrefixLen === undefined) {
            return <any>this.isSinglePrefixBlock$long$int(segmentValue, upperValue);
        } else if(((typeof segmentValue === 'number') || segmentValue === null) && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isSinglePrefixBlock$int(segmentValue);
        } else if(segmentValue === undefined && upperValue === undefined && divisionPrefixLen === undefined) {
            return <any>this.isSinglePrefixBlock$();
        } else throw new Error('invalid overload');
    }

    isSinglePrefixBlock$long$int(segmentValue : number, divisionPrefixLen : number) : boolean {
        return this.isSinglePrefixBlock$long$long$int(segmentValue, this.getUpperValue(), divisionPrefixLen);
    }

    public isPrefixBlock$int(divisionPrefixLen : number) : boolean {
        return this.isPrefixBlock$long$long$int(this.getLowerValue(), this.getUpperValue(), divisionPrefixLen);
    }

    public isPrefixBlock$() : boolean {
        return this.isPrefixed() && this.isPrefixBlock$int(this.getDivisionPrefixLength());
    }

    public isSinglePrefixBlock$int(divisionPrefixLen : number) : boolean {
        return this.isSinglePrefixBlock$long$long$int(this.getLowerValue(), this.getUpperValue(), divisionPrefixLen);
    }

    public isSinglePrefixBlock$() : boolean {
        if(this.__isSinglePrefixBlock == null) {
            this.__isSinglePrefixBlock = this.isPrefixed() && this.isSinglePrefixBlock$int(this.getDivisionPrefixLength());
        }
        return this.__isSinglePrefixBlock;
    }

    public isBitwiseOrCompatibleWithRange$long$java_lang_Integer$boolean(maskValue : number, divisionPrefixLen : number, isAutoSubnets : boolean) : boolean {
        let value : number = this.getLowerValue();
        let upperValue : number = this.getUpperValue();
        let maxValue : number = this.getMaxValue();
        if(divisionPrefixLen != null) {
            let divPrefLen : number = divisionPrefixLen;
            let bitCount : number = this.getBitCount();
            if(divPrefLen < 0 || divPrefLen > bitCount) {
                throw new PrefixLenException(this, divisionPrefixLen);
            }
            if(isAutoSubnets) {
                let shift : number = bitCount - divPrefLen;
                maskValue >>>= shift;
                value >>>= shift;
                upperValue >>>= shift;
                maxValue >>>= shift;
            }
        }
        return AddressDivision.isBitwiseOrCompatibleWithRange(value, upperValue, maskValue, maxValue);
    }

    public isBitwiseOrCompatibleWithRange(maskValue? : any, divisionPrefixLen? : any, isAutoSubnets? : any) : any {
        if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && ((typeof isAutoSubnets === 'boolean') || isAutoSubnets === null)) {
            return <any>this.isBitwiseOrCompatibleWithRange$long$java_lang_Integer$boolean(maskValue, divisionPrefixLen, isAutoSubnets);
        } else throw new Error('invalid overload');
    }

    public isMaskCompatibleWithRange$long$java_lang_Integer$boolean(maskValue : number, divisionPrefixLen : number, isAutoSubnets : boolean) : boolean {
        let value : number = this.getLowerValue();
        let upperValue : number = this.getUpperValue();
        let maxValue : number = this.getMaxValue();
        if(divisionPrefixLen != null) {
            let divPrefLen : number = divisionPrefixLen;
            let bitCount : number = this.getBitCount();
            if(divPrefLen < 0 || divPrefLen > bitCount) {
                throw new PrefixLenException(this, divisionPrefixLen);
            }
            if(isAutoSubnets) {
                let shift : number = bitCount - divPrefLen;
                maskValue >>>= shift;
                value >>>= shift;
                upperValue >>>= shift;
                maxValue >>>= shift;
            }
        }
        return AddressDivision.isMaskCompatibleWithRange(value, upperValue, maskValue, maxValue);
    }

    public isMaskCompatibleWithRange(maskValue? : any, divisionPrefixLen? : any, isAutoSubnets? : any) : any {
        if(((typeof maskValue === 'number') || maskValue === null) && ((typeof divisionPrefixLen === 'number') || divisionPrefixLen === null) && ((typeof isAutoSubnets === 'boolean') || isAutoSubnets === null)) {
            return <any>this.isMaskCompatibleWithRange$long$java_lang_Integer$boolean(maskValue, divisionPrefixLen, isAutoSubnets);
        } else throw new Error('invalid overload');
    }

    /**
     * Produces a normalized string to represent the segment.
     * If the segment CIDR prefix length covers the range, then it is assumed to be a CIDR, and the string has only the lower value of the CIDR range.
     * Otherwise, the explicit range will be printed.
     * @return
     * @return {string}
     */
    public getString() : string {
        let result : string = this.cachedString;
        if(result == null) {
            {
                result = this.cachedString;
                if(result == null) {
                    if(this.isSinglePrefixBlock() || !this.isMultiple()) {
                        result = this.getDefaultString();
                    } else if(this.isFullRange()) {
                        result = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
                    } else {
                        let upperValue : number = this.getUpperValue();
                        if(this.isPrefixBlock()) {
                            upperValue &= this.getDivisionNetworkMask(this.getDivisionPrefixLength());
                        }
                        result = this.getDefaultRangeString$long$long$int(this.getLowerValue(), upperValue, this.getDefaultTextualRadix());
                    }
                    this.cachedString = result;
                }
            };
        }
        return result;
    }

    /**
     * Produces a string to represent the segment, favouring wildcards and range characters over the network prefix to represent subnets.
     * If it exists, the segment CIDR prefix is ignored and the explicit range is printed.
     * @return
     * @return {string}
     */
    public getWildcardString() : string {
        let result : string = this.cachedWildcardString;
        if(result == null) {
            {
                result = this.cachedWildcardString;
                if(result == null) {
                    if(!this.isPrefixed() || !this.isMultiple()) {
                        result = this.getString();
                    } else if(this.isFullRange()) {
                        result = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
                    } else {
                        result = this.getDefaultRangeString();
                    }
                    this.cachedWildcardString = result;
                }
            };
        }
        return result;
    }

    /**
     * 
     */
    setDefaultAsFullRangeWildcardString() {
        if(this.cachedWildcardString == null) {
            {
                this.cachedWildcardString = IPAddress.SEGMENT_WILDCARD_STR_$LI$();
            };
        }
    }

    /**
     * 
     * @param {number} radix
     * @param {boolean} uppercase
     * @param {{ str: string }} appendable
     */
    getUpperStringMasked(radix : number, uppercase : boolean, appendable : { str: string }) {
        let upperValue : number = this.getUpperValue();
        let mask : number = this.getDivisionNetworkMask(this.getDivisionPrefixLength());
        upperValue &= mask;
        AddressDivision.toUnsignedString$long$int$int$boolean$char_A$java_lang_StringBuilder(upperValue, radix, 0, uppercase, uppercase?AddressDivisionBase.UPPERCASE_DIGITS_$LI$():AddressDivisionBase.DIGITS_$LI$(), appendable);
    }

    /**
     * 
     * @param {number} segmentIndex
     * @param {*} params
     * @param {{ str: string }} appendable
     * @return {number}
     */
    public getPrefixAdjustedRangeString(segmentIndex : number, params : AddressSegmentParams, appendable : { str: string }) : number {
        return super.getPrefixAdjustedRangeString(segmentIndex, params, appendable);
    }

    public abstract getBitCount(): any;}
IPAddressDivision["__class"] = "inet.ipaddr.format.IPAddressDivision";
IPAddressDivision["__interfaces"] = ["inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];




