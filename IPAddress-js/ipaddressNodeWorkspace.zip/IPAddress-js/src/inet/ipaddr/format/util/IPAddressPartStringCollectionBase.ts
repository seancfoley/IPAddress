/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringDivisionSeries } from '../IPAddressStringDivisionSeries';
import { IPAddressStringWriter } from './IPAddressStringWriter';
import { IPAddressPartConfiguredString } from './IPAddressPartConfiguredString';

/**
 * 
 * @author sfoley
 * 
 * @param <T> the type of the address part from which this collection was derived
 * @param <P> the type of the params used to generate each string
 * @param <S> the type of the configurable strings, each of which pairs an IPAddressPart and a {@link IPAddressStringWriter} to produce a string.
 * @class
 */
export abstract class IPAddressPartStringCollectionBase<T extends IPAddressStringDivisionSeries, P extends IPAddressStringWriter<any>, S extends IPAddressPartConfiguredString<any, any>> {
    abstract size() : number;

    public toStrings() : string[] {
        let strings : string[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.size());
        let i : number = 0;
        for(let index124=this.iterator();index124.hasNext();) {
            let createdString = index124.next();
            {
                strings[i++] = createdString.getString();
            }
        }
        return strings;
    }

    constructor() {
    }
}
IPAddressPartStringCollectionBase["__class"] = "inet.ipaddr.format.util.IPAddressPartStringCollectionBase";
IPAddressPartStringCollectionBase["__interfaces"] = ["java.lang.Iterable"];




