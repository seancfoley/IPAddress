/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressStringDivision } from '../AddressStringDivision';
import { IPAddressStringDivisionSeries } from '../IPAddressStringDivisionSeries';
import { IPAddressPartStringCollectionBase } from './IPAddressPartStringCollectionBase';
import { IPAddressStringWriter } from './IPAddressStringWriter';
import { IPAddressPartConfiguredString } from './IPAddressPartConfiguredString';
import { IPAddressPartStringSubCollection } from './IPAddressPartStringSubCollection';
import { IPAddressSection } from '../../IPAddressSection';
import { IPAddressStringDivision } from '../IPAddressStringDivision';

/**
 * 
 * @author sfoley
 * @extends IPAddressPartStringCollectionBase
 * @class
 */
export class IPAddressPartStringCollection extends IPAddressPartStringCollectionBase<IPAddressStringDivisionSeries, IPAddressStringWriter<any>, IPAddressPartConfiguredString<any, any>> {
    /*private*/ collections : Array<IPAddressPartStringSubCollection<any, any, any>> = <any>([]);

    constructor() {
        super();
    }

    add(collection : IPAddressPartStringSubCollection<any, any, any>) {
        /* add */(this.collections.push(collection)>0);
    }

    addAll(collections : IPAddressPartStringCollection) {
        /* addAll */((l1, l2) => l1.push.apply(l1, l2))(this.collections, collections.collections);
    }

    public getPartCount() : number {
        return /* size */(<number>this.collections.length);
    }

    public getPart(index : number) : IPAddressStringDivisionSeries {
        return this.getSubCollection$int(index).part;
    }

    public getParts(array : IPAddressStringDivisionSeries[]) : IPAddressStringDivisionSeries[] {
        let size : number = this.getPartCount();
        let result : IPAddressStringDivisionSeries[];
        if(array.length < size) {
            result = <IPAddressStringDivisionSeries[]>/* newInstance */new Array<any>(size);
        } else {
            result = array;
        }
        let i : number = 0;
        for(let index121=0; index121 < this.collections.length; index121++) {
            let coll = this.collections[index121];
            {
                result[i++] = coll.part;
            }
        }
        return result;
    }

    public getSubCollection$inet_ipaddr_format_IPAddressStringDivisionSeries(part : IPAddressStringDivisionSeries) : IPAddressPartStringSubCollection<any, any, any> {
        for(let index122=0; index122 < this.collections.length; index122++) {
            let sub = this.collections[index122];
            {
                if(/* equals */((a1, a2) => { if(a1==null && a2==null) return true; if(a1==null || a2==null) return false; if(a1.length != a2.length) return false; for(let i = 0; i < a1.length; i++) { if(<any>a1[i] != <any>a2[i]) return false; } return true; })(sub.params, part)) {
                    return sub;
                }
            }
        }
        return null;
    }

    public getSubCollection(part? : any) : any {
        if(((part != null && (part["__interfaces"] != null && part["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0 || part.constructor != null && part.constructor["__interfaces"] != null && part.constructor["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0)) || part === null)) {
            return <any>this.getSubCollection$inet_ipaddr_format_IPAddressStringDivisionSeries(part);
        } else if(((typeof part === 'number') || part === null)) {
            return <any>this.getSubCollection$int(part);
        } else throw new Error('invalid overload');
    }

    public getSubCollection$int(index : number) : IPAddressPartStringSubCollection<any, any, any> {
        return /* get */this.collections[index];
    }

    /**
     * 
     * @return {number}
     */
    public size() : number {
        let size : number = 0;
        for(let index123=0; index123 < this.collections.length; index123++) {
            let collection = this.collections[index123];
            {
                size += collection.size();
            }
        }
        return size;
    }

    /**
     * 
     * @return {*}
     */
    public iterator() : any {
        return new IPAddressPartStringCollection.IPAddressPartStringCollection$0(this);
    }
}
IPAddressPartStringCollection["__class"] = "inet.ipaddr.format.util.IPAddressPartStringCollection";
IPAddressPartStringCollection["__interfaces"] = ["java.lang.Iterable"];



export namespace IPAddressPartStringCollection {

    /**
     * 
     * @author sfoley
     * 
     * @param <T> the type of the address part from which this builder was derived
     * @param <P> the type of the params used to generate each string
     * @param <S> the type of the configurable strings, each of which pairs an IPAddressPart and a IPAddressPartStringParams to produce a string.
     * @param <C> the type of the collection produced by this builder
     * @param <O> the type of the options used by this builder to control which strings are produced
     * @class
     */
    export abstract class AddressPartStringBuilder<T extends IPAddressStringDivisionSeries, P extends IPAddressStringWriter<T>, S extends IPAddressPartConfiguredString<T, P>, C extends IPAddressPartStringSubCollection<T, P, S>, O extends IPAddressSection.IPStringBuilderOptions> {
        static MAX_BASE : number = 16;

        leadingZeros : number[][];

        addressSection : T;

        options : O;

        collection : C;

        done : boolean;

        constructor(addressSection : T, options : O, collection : C) {
            if(this.leadingZeros===undefined) this.leadingZeros = null;
            if(this.addressSection===undefined) this.addressSection = null;
            if(this.options===undefined) this.options = null;
            if(this.collection===undefined) this.collection = null;
            if(this.done===undefined) this.done = false;
            this.addressSection = addressSection;
            this.options = options;
            this.collection = collection;
        }

        public getVariations() : C {
            if(!this.done) {
                {
                    if(!this.done) {
                        this.done = true;
                        this.addAllVariations();
                    }
                };
            }
            return this.collection;
        }

        abstract addAllVariations();

        /**
         * 
         * @param {IPv4AddressSection.IPv4StringParams} stringParams
         */
        public addStringParam(stringParams? : any) : any {
            if(((stringParams != null) || stringParams === null)) {
                return <any>this.addStringParam$inet_ipaddr_format_util_IPAddressStringWriter(stringParams);
            } else throw new Error('invalid overload');
        }

        addStringParam$inet_ipaddr_format_util_IPAddressStringWriter(stringParams : P) {
            this.collection.add(stringParams);
        }

        isExpandable(radix : number) : boolean {
            return AddressPartStringBuilder.isExpandable(radix, this.addressSection);
        }

        isExpandableOutsideRange(radix : number, segmentIndex : number, count : number) : boolean {
            return AddressPartStringBuilder.isExpandableOutsideRange(radix, this.addressSection, segmentIndex, count);
        }

        static isExpandable(radix : number, part : IPAddressStringDivisionSeries) : boolean {
            return AddressPartStringBuilder.isExpandableOutsideRange(radix, part, -1, 0);
        }

        static isExpandableOutsideRange(radix : number, part : IPAddressStringDivisionSeries, segmentIndex : number, count : number) : boolean {
            let nextSegmentIndex : number = segmentIndex + count;
            for(let i : number = 0; i < part.getDivisionCount(); i++) {
                if(i >= segmentIndex && i < nextSegmentIndex) {
                    continue;
                }
                let div : AddressStringDivision = part.getDivision(i);
                let digitCount : number = div['getDigitCount$int'](radix);
                let maxDigitCount : number = div['getMaxDigitCount$int'](radix);
                if(digitCount < maxDigitCount) {
                    return true;
                }
            };
            return false;
        }

        getExpandableSegments(radix : number) : number[] {
            let result : number[];
            if(this.leadingZeros == null) {
                this.leadingZeros = (s => { let a=[]; while(s-->0) a.push(null); return a; })(AddressPartStringBuilder.MAX_BASE + 1);
                this.leadingZeros[radix] = result = AddressPartStringBuilder.getExpandableSegments(radix, this.addressSection);
            } else {
                if((result = this.leadingZeros[radix]) == null) {
                    this.leadingZeros[radix] = result = AddressPartStringBuilder.getExpandableSegments(radix, this.addressSection);
                }
            }
            return result;
        }

        static getExpandableSegments(radix : number, part : IPAddressStringDivisionSeries) : number[] {
            let count : number = part.getDivisionCount();
            let expandables : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(count);
            for(let i : number = 0; i < count; i++) {
                let div : AddressStringDivision = part.getDivision(i);
                let digitCount : number = div['getDigitCount$int'](radix);
                let maxDigitCount : number = div['getMaxDigitCount$int'](radix);
                if(digitCount < maxDigitCount) {
                    expandables[i] = maxDigitCount - digitCount;
                } else {
                    expandables[i] = 0;
                }
            };
            return expandables;
        }
    }
    AddressPartStringBuilder["__class"] = "inet.ipaddr.format.util.IPAddressPartStringCollection.AddressPartStringBuilder";


    export class IPAddressPartStringCollection$0 {
        public __parent: any;
        i : number;

        currentIterator : any;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            while((true)) {
                if(this.currentIterator == null) {
                    if(this.i < /* size */(<number>this.__parent.collections.length)) {
                        this.currentIterator = /* get */this.__parent.collections[this.i++].iterator();
                    } else {
                        return false;
                    }
                }
                if(this.currentIterator.hasNext()) {
                    return true;
                }
                this.currentIterator = null;
            };
        }

        /**
         * 
         * @return {IPAddressPartConfiguredString}
         */
        public next() : IPAddressPartConfiguredString<any, any> {
            if(this.hasNext()) {
                return this.currentIterator.next();
            }
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.util.NoSuchElementException','java.lang.Exception'] });
        }

        /**
         * 
         */
        public remove() {
            if(this.currentIterator == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.IllegalStateException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
            }
            this.currentIterator.remove();
        }

        constructor(__parent: any) {
            this.__parent = __parent;
            if(this.i===undefined) this.i = 0;
            if(this.currentIterator===undefined) this.currentIterator = null;
        }
    }
    IPAddressPartStringCollection$0["__interfaces"] = ["java.util.Iterator"];


}



