/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
 * Used to produce SQL for matching ip address section strings in databases.
 * 
 * Provides SQL conditions using SQL targeting a given database type.
 * 
 * @author sfoley
 * @class
 */
export interface IPAddressSQLTranslator {
    /**
     * Called with the network section, taken from an IP address or IP address section, that is being matched, for logging or debugging purposes.
     * 
     * @param {string} networkString
     */
    setNetwork(networkString : string);

    /**
     * Produces an SQL condition that evaluates to true when the given expression matches the given String,
     * appending the condition to the given string builder.
     * 
     * @param {{ str: string }} builder
     * @param {string} expression the expression
     * @param {string} match the String to match with the expression
     * @return {{ str: string }} builder with the condition appended
     */
    matchString(builder : { str: string }, expression : string, match : string) : { str: string };

    /**
     * Produces an SQL condition that evaluates to true when the given expression matches a substring obtained from the given expression,
     * appending the condition to the given string builder.
     * 
     * @param {{ str: string }} builder
     * @param {string} expression the expression
     * @param {string} match the String to match with a substring of the expression,
     * the substring being the substring taken from "expression" prior to the separatorCount appearance of the given separator char.
     * If there are not that many appearances of the separator char, then the substring is all of the String expression.
     * @return {{ str: string }} builder with the condition appended
     * @param {string} separator
     * @param {number} separatorCount
     */
    matchSubString(builder : { str: string }, expression : string, separator : string, separatorCount : number, match : string) : { str: string };

    /**
     * Produces an SQL condition that evaluates to true when "expression" has exactly a certain number of a given char within,
     * appending the condition to the given string builder.
     * 
     * @param {{ str: string }} builder
     * @param {string} expression the expression which must contain the indicated count of the indicated separator char
     * @param {string} separator the separator char
     * @param {number} separatorCount the count to  match
     * @return {{ str: string }} builder with the condition appended
     */
    matchSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string };

    /**
     * Produces an SQL condition that evaluates to true when "expression" has at most a certain number of a given char within,
     * appending the condition to the given string builder.
     * 
     * @param {{ str: string }} builder
     * @param {string} expression the expression which must contain at most the indicated count of the indicated separator char
     * @param {string} separator the separator char
     * @param {number} separatorCount the count to  match
     * @return {{ str: string }} builder with the condition appended
     */
    boundSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string };
}


