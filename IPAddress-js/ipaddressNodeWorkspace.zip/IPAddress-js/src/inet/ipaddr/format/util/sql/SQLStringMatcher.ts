/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringDivisionSeries } from '../../IPAddressStringDivisionSeries';
import { IPAddressPartConfiguredString } from '../IPAddressPartConfiguredString';
import { IPAddressStringWriter } from '../IPAddressStringWriter';
import { IPAddressSQLTranslator } from './IPAddressSQLTranslator';

/**
 * This class is intended to match part of an address when it is written with a given string.
 * 
 * Note that a given address part can be written many ways.
 * Also note that some of these representations can represent more than one address section.
 * 
 * @author sfoley
 * @param {IPAddressPartConfiguredString} networkString
 * @param {boolean} isEntireAddress
 * @param {*} translator
 * @class
 */
export class SQLStringMatcher<T extends IPAddressStringDivisionSeries, P extends IPAddressStringWriter<T>, S extends IPAddressPartConfiguredString<T, P>> {
    networkString : S;

    /*private*/ isEntireAddress : boolean;

    /*private*/ translator : IPAddressSQLTranslator;

    public constructor(networkString : S, isEntireAddress : boolean, translator : IPAddressSQLTranslator) {
        if(this.networkString===undefined) this.networkString = null;
        if(this.isEntireAddress===undefined) this.isEntireAddress = false;
        if(this.translator===undefined) this.translator = null;
        this.networkString = networkString;
        this.translator = translator;
        this.isEntireAddress = isEntireAddress;
        translator.setNetwork(networkString.getString());
    }

    /**
     * Get an SQL condition to match this address section representation
     * 
     * @param {{ str: string }} builder
     * @param {string} columnName
     * @return {{ str: string }} the condition
     */
    public getSQLCondition(builder : { str: string }, columnName : string) : { str: string } {
        let string : string = this.networkString.getString();
        if(this.isEntireAddress) {
            this.matchString(builder, columnName, string);
        } else {
            this.matchSubString(builder, columnName, this.networkString.getTrailingSegmentSeparator(), this.networkString.getTrailingSeparatorCount() + 1, string);
        }
        return builder;
    }

    matchString(builder : { str: string }, expression : string, match : string) {
        this.translator.matchString(builder, expression, match);
    }

    matchSubString(builder : { str: string }, expression : string, separator : string, separatorCount : number, match : string) {
        this.translator.matchSubString(builder, expression, separator, separatorCount, match);
    }

    matchSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) {
        this.translator.matchSeparatorCount(builder, expression, separator, separatorCount);
    }

    boundSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) {
        this.translator.boundSeparatorCount(builder, expression, separator, separatorCount);
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return /* toString */this.getSQLCondition({ str: "", toString: function() { return this.str; } }, "COLUMN").str;
    }
}
SQLStringMatcher["__class"] = "inet.ipaddr.format.util.sql.SQLStringMatcher";



