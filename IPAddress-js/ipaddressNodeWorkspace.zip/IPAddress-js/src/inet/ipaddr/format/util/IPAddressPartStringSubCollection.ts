/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringDivisionSeries } from '../IPAddressStringDivisionSeries';
import { IPAddressStringWriter } from './IPAddressStringWriter';
import { IPAddressPartConfiguredString } from './IPAddressPartConfiguredString';
import { IPAddressPartStringCollectionBase } from './IPAddressPartStringCollectionBase';

export abstract class IPAddressPartStringSubCollection<T extends IPAddressStringDivisionSeries, P extends IPAddressStringWriter<T>, S extends IPAddressPartConfiguredString<T, P>> extends IPAddressPartStringCollectionBase<T, P, S> {
    public part : T;

    params : Array<P> = <any>([]);

    constructor(part : T) {
        super();
        if(this.part===undefined) this.part = null;
        this.part = part;
    }

    add(stringParams : P) {
        /* add */(this.params.push(stringParams)>0);
    }

    public getParams(array : P[]) : P[] {
        return /* toArray */((a1, a2) => { if(a1.length >= a2.length) { a1.length=0; a1.push.apply(a1, a2); return a1; } else { return a2.slice(0); } })(array, this.params);
    }

    public getParamCount() : number {
        return /* size */(<number>this.params.length);
    }

    /**
     * 
     * @return {number}
     */
    public size() : number {
        return /* size */(<number>this.params.length);
    }
}
IPAddressPartStringSubCollection["__class"] = "inet.ipaddr.format.util.IPAddressPartStringSubCollection";
IPAddressPartStringSubCollection["__interfaces"] = ["java.lang.Iterable"];



export namespace IPAddressPartStringSubCollection {

    export abstract class IPAddressConfigurableStringIterator {
        public __parent: any;
        iterator : any;

        /**
         * 
         * @return {boolean}
         */
        public hasNext() : boolean {
            return this.iterator.hasNext();
        }

        /**
         * 
         */
        public remove() {
            this.iterator.remove();
        }

        constructor(__parent: any) {
            this.__parent = __parent;
            this.iterator = /* iterator */((a) => { var i = 0; return { next: function() { return i<a.length?a[i++]:null; }, hasNext: function() { return i<a.length; }}})(this.__parent.params);
        }
    }
    IPAddressConfigurableStringIterator["__class"] = "inet.ipaddr.format.util.IPAddressPartStringSubCollection.IPAddressConfigurableStringIterator";
    IPAddressConfigurableStringIterator["__interfaces"] = ["java.util.Iterator"];


}



