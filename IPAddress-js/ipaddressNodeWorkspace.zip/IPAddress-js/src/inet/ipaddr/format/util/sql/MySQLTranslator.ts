/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressSQLTranslator } from './IPAddressSQLTranslator';

/**
 * 
 * @author sfoley
 * @class
 */
export class MySQLTranslator implements IPAddressSQLTranslator {
    /**
     * 
     * @param {string} networkString
     */
    public setNetwork(networkString : string) {
    }

    /**
     * 
     * @param {{ str: string }} builder
     * @param {string} expression
     * @param {string} match
     * @return {{ str: string }}
     */
    public matchString(builder : { str: string }, expression : string, match : string) : { str: string } {
        return /* append */(sb => { sb.str = sb.str.concat(<any>"\'"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>match); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>" = \'"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>expression); return sb; })(builder))));
    }

    /**
     * 
     * @param {{ str: string }} builder
     * @param {string} expression
     * @param {string} separator
     * @param {number} separatorCount
     * @param {string} match
     * @return {{ str: string }}
     */
    public matchSubString(builder : { str: string }, expression : string, separator : string, separatorCount : number, match : string) : { str: string } {
        return /* append */(sb => { sb.str = sb.str.concat(<any>'\''); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>match); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'\''); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>") = "); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>separatorCount); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\',"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>",\'"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>expression); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"substring_index("); return sb; })(builder))))))))));
    }

    /**
     * 
     * @param {{ str: string }} builder
     * @param {string} expression
     * @param {string} separator
     * @param {number} separatorCount
     * @return {{ str: string }}
     */
    public matchSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string } {
        return this.compareSeparatorCount(builder, expression, separator, "=", separatorCount);
    }

    /**
     * 
     * @param {{ str: string }} builder
     * @param {string} expression
     * @param {string} separator
     * @param {number} separatorCount
     * @return {{ str: string }}
     */
    public boundSeparatorCount(builder : { str: string }, expression : string, separator : string, separatorCount : number) : { str: string } {
        return this.compareSeparatorCount(builder, expression, separator, "<=", separatorCount);
    }

    /*private*/ compareSeparatorCount(builder : { str: string }, expression : string, separator : string, operator : string, separatorCount : number) : { str: string } {
        return /* append */(sb => { sb.str = sb.str.concat(<any>separatorCount); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>" "); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>operator); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\', \'\')) "); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>", \'"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>expression); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>") - LENGTH(REPLACE("); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>expression); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"LENGTH ("); return sb; })(builder))))))))));
    }

    constructor() {
    }
}
MySQLTranslator["__class"] = "inet.ipaddr.format.util.sql.MySQLTranslator";
MySQLTranslator["__interfaces"] = ["inet.ipaddr.format.util.sql.IPAddressSQLTranslator"];




