/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressDivisionGrouping } from '../AddressDivisionGrouping';

/**
 * Each segment params has settings to write exactly one type of IP address part string segment.
 * @class
 */
export interface AddressSegmentParams {
    getWildcards() : StringOptions.Wildcards;

    preferWildcards() : boolean;

    /**
     * returns -1 for as many leading zeros as needed to write the max number of characters per segment,
     * or 0, 1, 2, 3 to indicate the number of leading zeros
     * @param {number} segmentIndex
     * @return {number}
     */
    getLeadingZeros(segmentIndex : number) : number;

    getSegmentStrPrefix() : string;

    getRadix() : number;

    isUppercase() : boolean;

    isSplitDigits() : boolean;

    getSplitDigitSeparator() : string;

    isReverseSplitDigits() : boolean;
}


