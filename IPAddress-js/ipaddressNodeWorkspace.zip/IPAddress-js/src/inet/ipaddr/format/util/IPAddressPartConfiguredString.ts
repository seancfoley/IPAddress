/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressStringDivisionSeries } from '../IPAddressStringDivisionSeries';
import { IPAddressSQLTranslator } from './sql/IPAddressSQLTranslator';
import { SQLStringMatcher } from './sql/SQLStringMatcher';
import { IPAddressStringWriter } from './IPAddressStringWriter';

/**
 * Pairs a part of an IP address along with an instance of a parameter class to define a specific string.
 * 
 * @author sfoley
 * 
 * @param <T> the type of the address part from which this configurable string was derived
 * @param <P> the type of the params used to generate the string
 * @param {*} addr
 * @param {*} stringParams
 * @class
 */
export class IPAddressPartConfiguredString<T extends IPAddressStringDivisionSeries, P extends IPAddressStringWriter<T>> {
    public addr : T;

    public stringParams : P;

    string : string;

    public constructor(addr : T, stringParams : P) {
        if(this.addr===undefined) this.addr = null;
        if(this.stringParams===undefined) this.stringParams = null;
        if(this.string===undefined) this.string = null;
        this.stringParams = stringParams;
        this.addr = addr;
    }

    public getTrailingSeparatorCount() : number {
        return this.stringParams.getTrailingSeparatorCount(this.addr);
    }

    public getTrailingSegmentSeparator() : string {
        return this.stringParams.getTrailingSegmentSeparator();
    }

    /**
     * Provides an object that can build SQL clauses to match this string representation.
     * 
     * This method can be overridden for other IP address types to match in their own ways.
     * 
     * @param {boolean} isEntireAddress
     * @param {*} translator
     * @return
     * @return {SQLStringMatcher}
     */
    public getNetworkStringMatcher<S extends IPAddressPartConfiguredString<T, P>>(isEntireAddress : boolean, translator : IPAddressSQLTranslator) : SQLStringMatcher<T, P, S> {
        return <any>(new SQLStringMatcher<T, P, S>(<S><any>this, isEntireAddress, translator));
    }

    public getString() : string {
        if(this.string == null) {
            this.string = this.stringParams.toString(this.addr);
        }
        return this.string;
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.getString();
    }
}
IPAddressPartConfiguredString["__class"] = "inet.ipaddr.format.util.IPAddressPartConfiguredString";



