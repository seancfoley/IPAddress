/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressStringException } from '../../AddressStringException';
import { HostName } from '../../HostName';
import { IPAddress } from '../../IPAddress';
import { IPAddressNetwork } from '../../IPAddressNetwork';
import { IPAddressSection } from '../../IPAddressSection';
import { IPAddressString } from '../../IPAddressString';
import { ParsedHostIdentifierStringQualifier } from './ParsedHostIdentifierStringQualifier';
import { IPAddressProvider } from './IPAddressProvider';
import { IPAddressStringParameters } from '../../IPAddressStringParameters';

/**
 * The result of parsing a valid host name.
 * 
 * @author sfoley
 * @param {string} originalStr
 * @param {IPAddressProvider} valueProvider
 * @param {ParsedHostIdentifierStringQualifier} portQualifier
 * @class
 */
export class ParsedHost {
    static serialVersionUID : number = 4;

    static NO_EMBEDDED_ADDRESS : ParsedHost.EmbeddedAddress; public static NO_EMBEDDED_ADDRESS_$LI$() : ParsedHost.EmbeddedAddress { if(ParsedHost.NO_EMBEDDED_ADDRESS == null) ParsedHost.NO_EMBEDDED_ADDRESS = new ParsedHost.EmbeddedAddress(); return ParsedHost.NO_EMBEDDED_ADDRESS; };

    static NO_QUALIFIER : ParsedHostIdentifierStringQualifier; public static NO_QUALIFIER_$LI$() : ParsedHostIdentifierStringQualifier { if(ParsedHost.NO_QUALIFIER == null) ParsedHost.NO_QUALIFIER = new ParsedHostIdentifierStringQualifier(); return ParsedHost.NO_QUALIFIER; };

    /*private*/ normalizedLabels : string[];

    /*private*/ separatorIndices : number[];

    /*private*/ normalizedFlags : boolean[];

    /*private*/ labelsQualifier : ParsedHostIdentifierStringQualifier;

    /*private*/ service : string;

    /*private*/ embeddedAddress : ParsedHost.EmbeddedAddress;

    host : string;

    /*private*/ originalStr : string;

    public constructor(originalStr? : any, separatorIndices? : any, normalizedFlags? : any, labelsQualifier? : any, embeddedAddress? : any) {
        if(((typeof originalStr === 'string') || originalStr === null) && ((separatorIndices != null && separatorIndices instanceof <any>Array && (separatorIndices.length==0 || separatorIndices[0] == null ||(typeof separatorIndices[0] === 'number'))) || separatorIndices === null) && ((normalizedFlags != null && normalizedFlags instanceof <any>Array && (normalizedFlags.length==0 || normalizedFlags[0] == null ||(typeof normalizedFlags[0] === 'boolean'))) || normalizedFlags === null) && ((labelsQualifier != null && labelsQualifier instanceof <any>ParsedHostIdentifierStringQualifier) || labelsQualifier === null) && ((embeddedAddress != null && embeddedAddress instanceof <any>ParsedHost.EmbeddedAddress) || embeddedAddress === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.normalizedLabels===undefined) this.normalizedLabels = null;
            if(this.separatorIndices===undefined) this.separatorIndices = null;
            if(this.normalizedFlags===undefined) this.normalizedFlags = null;
            if(this.labelsQualifier===undefined) this.labelsQualifier = null;
            if(this.service===undefined) this.service = null;
            if(this.embeddedAddress===undefined) this.embeddedAddress = null;
            if(this.host===undefined) this.host = null;
            if(this.originalStr===undefined) this.originalStr = null;
            if(this.normalizedLabels===undefined) this.normalizedLabels = null;
            if(this.separatorIndices===undefined) this.separatorIndices = null;
            if(this.normalizedFlags===undefined) this.normalizedFlags = null;
            if(this.labelsQualifier===undefined) this.labelsQualifier = null;
            if(this.service===undefined) this.service = null;
            if(this.embeddedAddress===undefined) this.embeddedAddress = null;
            if(this.host===undefined) this.host = null;
            if(this.originalStr===undefined) this.originalStr = null;
            (() => {
                this.labelsQualifier = labelsQualifier;
                this.normalizedFlags = normalizedFlags;
                this.separatorIndices = separatorIndices;
                this.originalStr = originalStr;
                this.embeddedAddress = embeddedAddress == null?ParsedHost.NO_EMBEDDED_ADDRESS_$LI$():embeddedAddress;
            })();
        } else if(((typeof originalStr === 'string') || originalStr === null) && ((separatorIndices != null && separatorIndices instanceof <any>Array && (separatorIndices.length==0 || separatorIndices[0] == null ||(typeof separatorIndices[0] === 'number'))) || separatorIndices === null) && ((normalizedFlags != null && normalizedFlags instanceof <any>Array && (normalizedFlags.length==0 || normalizedFlags[0] == null ||(typeof normalizedFlags[0] === 'boolean'))) || normalizedFlags === null) && ((labelsQualifier != null && labelsQualifier instanceof <any>ParsedHostIdentifierStringQualifier) || labelsQualifier === null) && embeddedAddress === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let embeddedAddress : any = null;
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                (() => {
                    this.labelsQualifier = labelsQualifier;
                    this.normalizedFlags = normalizedFlags;
                    this.separatorIndices = separatorIndices;
                    this.originalStr = originalStr;
                    this.embeddedAddress = embeddedAddress == null?ParsedHost.NO_EMBEDDED_ADDRESS_$LI$():embeddedAddress;
                })();
            }
        } else if(((typeof originalStr === 'string') || originalStr === null) && ((separatorIndices != null && separatorIndices instanceof <any>IPAddressProvider) || separatorIndices === null) && ((normalizedFlags != null && normalizedFlags instanceof <any>ParsedHostIdentifierStringQualifier) || normalizedFlags === null) && labelsQualifier === undefined && embeddedAddress === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[1];
            let portQualifier : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let separatorIndices : any = null;
                let normalizedFlags : any = null;
                let labelsQualifier : any = portQualifier;
                let embeddedAddress : any = new ParsedHost.EmbeddedAddress();
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                (() => {
                    this.labelsQualifier = labelsQualifier;
                    this.normalizedFlags = normalizedFlags;
                    this.separatorIndices = separatorIndices;
                    this.originalStr = originalStr;
                    this.embeddedAddress = embeddedAddress == null?ParsedHost.NO_EMBEDDED_ADDRESS_$LI$():embeddedAddress;
                })();
            }
            (() => {
                this.embeddedAddress.addressProvider = valueProvider;
            })();
        } else if(((typeof originalStr === 'string') || originalStr === null) && ((separatorIndices != null && separatorIndices instanceof <any>IPAddressProvider) || separatorIndices === null) && normalizedFlags === undefined && labelsQualifier === undefined && embeddedAddress === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let separatorIndices : any = null;
                let normalizedFlags : any = null;
                let labelsQualifier : any = ParsedHost.NO_QUALIFIER_$LI$();
                let embeddedAddress : any = new ParsedHost.EmbeddedAddress();
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                if(this.normalizedLabels===undefined) this.normalizedLabels = null;
                if(this.separatorIndices===undefined) this.separatorIndices = null;
                if(this.normalizedFlags===undefined) this.normalizedFlags = null;
                if(this.labelsQualifier===undefined) this.labelsQualifier = null;
                if(this.service===undefined) this.service = null;
                if(this.embeddedAddress===undefined) this.embeddedAddress = null;
                if(this.host===undefined) this.host = null;
                if(this.originalStr===undefined) this.originalStr = null;
                (() => {
                    this.labelsQualifier = labelsQualifier;
                    this.normalizedFlags = normalizedFlags;
                    this.separatorIndices = separatorIndices;
                    this.originalStr = originalStr;
                    this.embeddedAddress = embeddedAddress == null?ParsedHost.NO_EMBEDDED_ADDRESS_$LI$():embeddedAddress;
                })();
            }
            (() => {
                this.embeddedAddress.addressProvider = valueProvider;
            })();
        } else throw new Error('invalid overload');
    }

    public isIPv6Address() : boolean {
        return this.hasEmbeddedAddress() && this.getAddressProvider().isIPv6();
    }

    public getPort() : number {
        return this.labelsQualifier.getPort();
    }

    public getService() : string {
        let serv : string = this.service;
        if(serv == null) {
            let sv : any = this.labelsQualifier.getService();
            if(sv != null) {
                this.service = serv = sv.toString();
            }
        }
        return serv;
    }

    public getNetworkPrefixLength() : number {
        return this.labelsQualifier.getNetworkPrefixLength();
    }

    public getEquivalentPrefixLength() : number {
        return this.labelsQualifier.getEquivalentPrefixLength();
    }

    public getMask() : IPAddress {
        return this.labelsQualifier.getMask();
    }

    public getAddressProvider() : IPAddressProvider {
        return this.embeddedAddress.addressProvider;
    }

    hasEmbeddedAddress() : boolean {
        return this.embeddedAddress.addressProvider != null;
    }

    public isAddressString() : boolean {
        return this.getAddressProvider() != null;
    }

    public asAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
        if(this.hasEmbeddedAddress()) {
            return this.getAddressProvider().getAddress$inet_ipaddr_IPAddress_IPVersion(version);
        }
        return null;
    }

    public asAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.asAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.asAddress$();
        } else throw new Error('invalid overload');
    }

    public asAddress$() : IPAddress {
        if(this.hasEmbeddedAddress()) {
            return this.getAddressProvider().getAddress();
        }
        return null;
    }

    public asGenericAddressString() : IPAddressString {
        if(this.hasEmbeddedAddress()) {
            let addressProvider : IPAddressProvider = this.getAddressProvider();
            if(addressProvider.isAllAddresses()) {
                return new IPAddressString(IPAddress.SEGMENT_WILDCARD_STR_$LI$(), addressProvider.getParameters());
            } else if(addressProvider.isPrefixOnly()) {
                return new IPAddressString(IPAddressNetwork.getPrefixString(addressProvider.getNetworkPrefixLength()), addressProvider.getParameters());
            } else if(addressProvider.isEmpty()) {
                return new IPAddressString("", addressProvider.getParameters());
            } else {
                let addr : IPAddress = addressProvider.getAddress();
                return addr.toAddressString();
            }
        }
        return null;
    }

    public getNormalizedLabels() : string[] {
        let labels : string[] = this.normalizedLabels;
        if(labels == null) {
            {
                labels = this.normalizedLabels;
                if(labels == null) {
                    if(this.hasEmbeddedAddress()) {
                        let addressProvider : IPAddressProvider = this.getAddressProvider();
                        let addr : IPAddress = addressProvider.getAddress();
                        if(addr == null) {
                            if(addressProvider.isEmpty()) {
                                return [];
                            }
                            return [this.asGenericAddressString().toString()];
                        }
                        let section : IPAddressSection = addr.getSection();
                        labels = section.getSegmentStrings();
                    } else {
                        labels = (s => { let a=[]; while(s-->0) a.push(null); return a; })(this.separatorIndices.length);
                        for(let i : number = 0, lastSep : number = -1; i < labels.length; i++) {
                            let index : number = this.separatorIndices[i];
                            if(this.normalizedFlags != null && !this.normalizedFlags[i]) {
                                let second : { str: string } = { str: "", toString: function() { return this.str; } };
                                for(let j : number = lastSep + 1; j < index; j++) {
                                    let c : string = this.originalStr.charAt(j);
                                    /* append */(sb => { sb.str = sb.str.concat(<any>((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'Z'.charCodeAt(0))?String.fromCharCode(((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) + ('a'.charCodeAt(0) - 'A'.charCodeAt(0)))):c); return sb; })(second);
                                };
                                labels[i] = /* toString */second.str;
                            } else {
                                labels[i] = this.originalStr.substring(lastSep + 1, index);
                            }
                            lastSep = index;
                        };
                        this.separatorIndices = null;
                        this.normalizedFlags = null;
                    }
                    this.normalizedLabels = labels;
                }
            };
        }
        return labels;
    }

    public getHost() : string {
        let str : string = this.host;
        if(str == null) {
            if(this.originalStr.length > 0) {
                {
                    str = this.host;
                    if(str == null) {
                        if(this.hasEmbeddedAddress()) {
                            let addressProvider : IPAddressProvider = this.getAddressProvider();
                            let addr : IPAddress = addressProvider.getAddress();
                            if(addr == null) {
                                return this.asGenericAddressString().toString();
                            }
                            return addr.getSection().toCanonicalWildcardString();
                        } else {
                            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
                            let labels : string[] = this.getNormalizedLabels();
                            /* append */(sb => { sb.str = sb.str.concat(<any>labels[0]); return sb; })(builder);
                            for(let i : number = 1; i < labels.length; i++) {
                                /* append */(sb => { sb.str = sb.str.concat(<any>labels[i]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>HostName.LABEL_SEPARATOR); return sb; })(builder));
                            };
                            str = /* toString */builder.str;
                        }
                    }
                };
            } else {
                str = this.originalStr;
            }
            this.host = str;
        }
        return str;
    }

    public getAddressStringException() : AddressStringException {
        return this.embeddedAddress.addressStringException;
    }

    public isUNCIPv6Literal() : boolean {
        return this.embeddedAddress.isUNCIPv6Literal;
    }

    public isReverseDNS() : boolean {
        return this.embeddedAddress.isReverseDNS;
    }
}
ParsedHost["__class"] = "inet.ipaddr.format.validate.ParsedHost";
ParsedHost["__interfaces"] = ["java.io.Serializable"];



export namespace ParsedHost {

    export class EmbeddedAddress {
        static serialVersionUID : number = 4;

        isUNCIPv6Literal : boolean;

        isReverseDNS : boolean;

        addressStringException : AddressStringException;

        addressProvider : IPAddressProvider;

        constructor() {
            if(this.isUNCIPv6Literal===undefined) this.isUNCIPv6Literal = false;
            if(this.isReverseDNS===undefined) this.isReverseDNS = false;
            if(this.addressStringException===undefined) this.addressStringException = null;
            if(this.addressProvider===undefined) this.addressProvider = null;
        }
    }
    EmbeddedAddress["__class"] = "inet.ipaddr.format.validate.ParsedHost.EmbeddedAddress";
    EmbeddedAddress["__interfaces"] = ["java.io.Serializable"];


}




ParsedHost.NO_QUALIFIER_$LI$();

ParsedHost.NO_EMBEDDED_ADDRESS_$LI$();
