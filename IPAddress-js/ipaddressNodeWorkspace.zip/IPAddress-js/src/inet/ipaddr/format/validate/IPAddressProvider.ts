/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { HostIdentifierString } from '../../HostIdentifierString';
import { IPAddress } from '../../IPAddress';
import { IPAddressNetwork } from '../../IPAddressNetwork';
import { IPAddressStringParameters } from '../../IPAddressStringParameters';
import { ParsedIPAddress } from './ParsedIPAddress';
import { ParsedHostIdentifierStringQualifier } from './ParsedHostIdentifierStringQualifier';
import { IPv4AddressNetwork } from '../../ipv4/IPv4AddressNetwork';
import { IPv4AddressStringParameters } from '../../ipv4/IPv4AddressStringParameters';
import { IPv6AddressNetwork } from '../../ipv6/IPv6AddressNetwork';
import { IPv6AddressStringParameters } from '../../ipv6/IPv6AddressStringParameters';
import { ParsedAddressCreator } from './ParsedAddressCreator';
import { IPv6Address } from '../../ipv6/IPv6Address';
import { IPv4Address } from '../../ipv4/IPv4Address';

/**
 * Provides an address corresponding to a parsed string.
 * 
 * @author sfoley
 * @class
 */
export abstract class IPAddressProvider {
    static serialVersionUID : number = 4;

    public static INVALID_PROVIDER : IPAddressProvider.NullProvider; public static INVALID_PROVIDER_$LI$() : IPAddressProvider.NullProvider { if(IPAddressProvider.INVALID_PROVIDER == null) IPAddressProvider.INVALID_PROVIDER = new IPAddressProvider.IPAddressProvider$0(IPAddressProvider.IPType.INVALID); return IPAddressProvider.INVALID_PROVIDER; };

    public static NO_TYPE_PROVIDER : IPAddressProvider.NullProvider; public static NO_TYPE_PROVIDER_$LI$() : IPAddressProvider.NullProvider { if(IPAddressProvider.NO_TYPE_PROVIDER == null) IPAddressProvider.NO_TYPE_PROVIDER = new IPAddressProvider.IPAddressProvider$1(null); return IPAddressProvider.NO_TYPE_PROVIDER; };

    static EMPTY_PROVIDER : IPAddressProvider.NullProvider; public static EMPTY_PROVIDER_$LI$() : IPAddressProvider.NullProvider { if(IPAddressProvider.EMPTY_PROVIDER == null) IPAddressProvider.EMPTY_PROVIDER = new IPAddressProvider.IPAddressProvider$2(IPAddressProvider.IPType.EMPTY); return IPAddressProvider.EMPTY_PROVIDER; };

    constructor() {
    }

    public abstract getType() : IPAddressProvider.IPType;

    public abstract getHostAddress() : IPAddress;

    public getAddress$() : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public getAddress(version? : any) : any {
        if(((typeof version === 'number') || version === null)) {
            return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
        } else if(version === undefined) {
            return <any>this.getAddress$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let value : IPAddress = this.getAddress();
        if(value != null) {
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(value));
        }
        return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(Objects));
    }

    /**
     * 
     * @param {IPAddressProvider} other
     * @return {number}
     */
    public compareTo(other : IPAddressProvider) : number {
        if(this === other) {
            return 0;
        }
        let value : IPAddress = this.getAddress();
        if(value != null) {
            let otherValue : IPAddress = other.getAddress();
            if(otherValue != null) {
                return value.compareTo(otherValue);
            }
        }
        let thisType : IPAddressProvider.IPType = this.getType();
        let otherType : IPAddressProvider.IPType = other.getType();
        if(thisType == null) {
            return otherType == null?0:-1;
        } else if(otherType == null) {
            return 1;
        }
        return /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[thisType]] - /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[otherType]];
    }

    /**
     * When a value provider produces no value, equality and comparison are based on the enum IPType,
     * which can by null.
     * @param {*} o
     * @return
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(this === o) {
            return true;
        }
        if(o != null && o instanceof <any>IPAddressProvider) {
            let other : IPAddressProvider = <IPAddressProvider>o;
            let value : IPAddress = this.getAddress();
            if(value != null) {
                let otherValue : IPAddress = other.getAddress();
                if(otherValue != null) {
                    return value.equals(otherValue);
                }
            }
            return this.getType() === other.getType();
        }
        return false;
    }

    public getIPVersion() : IPAddress.IPVersion {
        return null;
    }

    public isIPAddress() : boolean {
        return false;
    }

    public isIPv4() : boolean {
        return false;
    }

    public isIPv6() : boolean {
        return false;
    }

    public isPrefixOnly() : boolean {
        return false;
    }

    public isAllAddresses() : boolean {
        return false;
    }

    public isEmpty() : boolean {
        return false;
    }

    public isInvalid() : boolean {
        return false;
    }

    public isUninitialized() : boolean {
        return false;
    }

    public isMixedIPv6() : boolean {
        return false;
    }

    public isBase85IPv6() : boolean {
        return false;
    }

    public getNetworkPrefixLength() : number {
        return null;
    }

    public isPrefixed() : boolean {
        return this.getNetworkPrefixLength() != null;
    }

    /**
     * If the address was created by parsing, this provides the parameters used when creating the address.
     * 
     * @return {IPAddressStringParameters} the parameters used to create the address, or null if no such parameters were used.
     */
    public getParameters() : IPAddressStringParameters {
        return null;
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return /* valueOf */new String(this.getAddress()).toString();
    }

    /**
     * Wraps an IPAddress for IPAddressString in the cases where no parsing is provided, the address exists already
     * @param value
     * @return
     * @param {IPAddress} address
     * @param {IPAddress} hostAddress
     * @return {IPAddressProvider}
     */
    public static getProviderFor(address : IPAddress, hostAddress : IPAddress) : IPAddressProvider {
        return new IPAddressProvider.CachedAddressProvider(address, hostAddress);
    }
}
IPAddressProvider["__class"] = "inet.ipaddr.format.validate.IPAddressProvider";
IPAddressProvider["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



export namespace IPAddressProvider {

    export enum IPType {
        INVALID, EMPTY, IPV4, IPV6, PREFIX_ONLY, ALL
    }

    /** @ignore */
    export class IPType_$WRAPPER {
        constructor(protected _$ordinal : number, protected _$name : string) {
        }

        static from(version) : IPAddressProvider.IPType {
            switch((version)) {
            case IPAddress.IPVersion.IPV4:
                return IPType.IPV4;
            case IPAddress.IPVersion.IPV6:
                return IPType.IPV6;
            default:
                return null;
            }
        }
        public name() : string { return this._$name; }
        public ordinal() : number { return this._$ordinal; }
    }
    IPType["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.IPType";
    IPType["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

    IPType["_$wrappers"] = [new IPType_$WRAPPER(0, "INVALID"), new IPType_$WRAPPER(1, "EMPTY"), new IPType_$WRAPPER(2, "IPV4"), new IPType_$WRAPPER(3, "IPV6"), new IPType_$WRAPPER(4, "PREFIX_ONLY"), new IPType_$WRAPPER(5, "ALL")];


    export abstract class NullProvider extends IPAddressProvider {
        static __inet_ipaddr_format_validate_IPAddressProvider_NullProvider_serialVersionUID : number = 4;

        type : IPAddressProvider.IPType;

        public constructor(type : IPAddressProvider.IPType) {
            super();
            if(this.type===undefined) this.type = null;
            this.type = type;
        }

        /**
         * 
         * @return {IPAddressProvider.IPType}
         */
        public getType() : IPAddressProvider.IPType {
            return this.type;
        }

        /**
         * 
         * @return {IPAddress}
         */
        public getHostAddress() : IPAddress {
            return null;
        }

        public getAddress$() : IPAddress {
            return null;
        }

        public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
            return null;
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        public getAddress(version? : any) : any {
            if(((typeof version === 'number') || version === null)) {
                return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
            } else if(version === undefined) {
                return <any>this.getAddress$();
            } else throw new Error('invalid overload');
        }
    }
    NullProvider["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.NullProvider";
    NullProvider["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class CachedAddressProvider extends IPAddressProvider {
        static __inet_ipaddr_format_validate_IPAddressProvider_CachedAddressProvider_serialVersionUID : number = 4;

        values : ParsedIPAddress.CachedIPAddresses<any>;

        public constructor(address? : any, hostAddress? : any) {
            if(((address != null && address instanceof <any>IPAddress) || address === null) && ((hostAddress != null && hostAddress instanceof <any>IPAddress) || hostAddress === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super();
                if(this.values===undefined) this.values = null;
                if(this.values===undefined) this.values = null;
                (() => {
                    this.values = <any>(new ParsedIPAddress.CachedIPAddresses<IPAddress>(address, hostAddress));
                })();
            } else if(address === undefined && hostAddress === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                super();
                if(this.values===undefined) this.values = null;
                if(this.values===undefined) this.values = null;
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPAddress.IPVersion}
         */
        public getIPVersion() : IPAddress.IPVersion {
            return this.getAddress().getIPVersion();
        }

        /**
         * 
         * @return {IPAddressProvider.IPType}
         */
        public getType() : IPAddressProvider.IPType {
            return IPAddressProvider.IPType_$WRAPPER.from(this.getIPVersion());
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPAddress() : boolean {
            return true;
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv4() : boolean {
            return this.getAddress().isIPv4();
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv6() : boolean {
            return this.getAddress().isIPv6();
        }

        /**
         * 
         * @return {IPAddress}
         */
        public getHostAddress() : IPAddress {
            return this.values.getHostAddress();
        }

        public getAddress$() : IPAddress {
            return this.values.getAddress();
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            return this.getAddress().getNetworkPrefixLength();
        }

        public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
            let thisVersion : IPAddress.IPVersion = this.getIPVersion();
            if(!/* Enum.equals */(<any>(version) === <any>(thisVersion))) {
                return null;
            }
            return this.getAddress();
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        public getAddress(version? : any) : any {
            if(((typeof version === 'number') || version === null)) {
                return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
            } else if(version === undefined) {
                return <any>this.getAddress$();
            } else throw new Error('invalid overload');
        }
    }
    CachedAddressProvider["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.CachedAddressProvider";
    CachedAddressProvider["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export abstract class CachedAddressCreator extends IPAddressProvider.CachedAddressProvider {
        static serialVersionUID : number = 4;

        public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
            this.getAddress();
            return super.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        public getAddress(version? : any) : any {
            if(((typeof version === 'number') || version === null)) {
                return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
            } else if(version === undefined) {
                return <any>this.getAddress$();
            } else throw new Error('invalid overload');
        }

        getCachedAddresses() : ParsedIPAddress.CachedIPAddresses<any> {
            let val : ParsedIPAddress.CachedIPAddresses<any> = this.values;
            if(val == null) {
                {
                    val = this.values;
                    if(val == null) {
                        this.values = val = this.createAddresses();
                    }
                };
            }
            return val;
        }

        /**
         * 
         * @return {IPAddress}
         */
        public getHostAddress() : IPAddress {
            return this.getCachedAddresses().getHostAddress();
        }

        public getAddress$() : IPAddress {
            return this.getCachedAddresses().getAddress();
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            this.getAddress();
            return super.getNetworkPrefixLength();
        }

        abstract createAddresses() : ParsedIPAddress.CachedIPAddresses<any>;

        constructor() {
            super();
        }
    }
    CachedAddressCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.CachedAddressCreator";
    CachedAddressCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class ParsedAddressProvider extends IPAddressProvider.CachedAddressCreator {
        static __inet_ipaddr_format_validate_IPAddressProvider_ParsedAddressProvider_serialVersionUID : number = 4;

        parseResult : ParsedIPAddress;

        version : IPAddress.IPVersion;

        __isMixedIPv6 : boolean;

        __isBase85IPv6 : boolean;

        constructor(parseResult : ParsedIPAddress) {
            super();
            if(this.parseResult===undefined) this.parseResult = null;
            if(this.version===undefined) this.version = null;
            if(this.__isMixedIPv6===undefined) this.__isMixedIPv6 = false;
            if(this.__isBase85IPv6===undefined) this.__isBase85IPv6 = false;
            this.parseResult = parseResult;
            this.version = parseResult.getIPVersion();
            this.__isMixedIPv6 = parseResult.isMixedIPv6();
            this.__isBase85IPv6 = parseResult.isBase85IPv6();
        }

        /**
         * 
         * @return {boolean}
         */
        public isMixedIPv6() : boolean {
            return this.__isMixedIPv6;
        }

        /**
         * 
         * @return {boolean}
         */
        public isBase85IPv6() : boolean {
            return this.__isBase85IPv6;
        }

        /**
         * 
         * @return {IPAddress.IPVersion}
         */
        public getIPVersion() : IPAddress.IPVersion {
            return this.version;
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv4() : boolean {
            return IPAddress.IPVersion["_$wrappers"][this.getIPVersion()].isIPv4();
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv6() : boolean {
            return IPAddress.IPVersion["_$wrappers"][this.getIPVersion()].isIPv6();
        }

        /**
         * 
         * @return {ParsedIPAddress.IPAddresses}
         */
        createAddresses() : ParsedIPAddress.IPAddresses<any, any> {
            let result : ParsedIPAddress.IPAddresses<any, any> = this.parseResult.createAddresses();
            this.parseResult = null;
            return result;
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            let parsedAddress : ParsedIPAddress = this.parseResult;
            if(parsedAddress != null) {
                return parsedAddress.getNetworkPrefixLength();
            }
            return super.getNetworkPrefixLength();
        }

        /**
         * 
         * @return {boolean}
         */
        public isPrefixed() : boolean {
            let parsedAddress : ParsedIPAddress = this.parseResult;
            if(parsedAddress != null) {
                return parsedAddress.isPrefixed();
            }
            return super.isPrefixed();
        }

        /**
         * 
         * @return {IPAddressStringParameters}
         */
        public getParameters() : IPAddressStringParameters {
            return this.parseResult.options;
        }
    }
    ParsedAddressProvider["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.ParsedAddressProvider";
    ParsedAddressProvider["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export abstract class VersionedAddressCreator extends IPAddressProvider.CachedAddressCreator {
        static __inet_ipaddr_format_validate_IPAddressProvider_VersionedAddressCreator_serialVersionUID : number = 4;

        versionedValues : IPAddress[];

        options : IPAddressStringParameters;

        constructor(options : IPAddressStringParameters) {
            super();
            if(this.versionedValues===undefined) this.versionedValues = null;
            if(this.options===undefined) this.options = null;
            this.options = options;
        }

        /**
         * 
         * @return {IPAddressStringParameters}
         */
        public getParameters() : IPAddressStringParameters {
            return this.options;
        }

        checkResult(version : IPAddress.IPVersion, index : number) : IPAddress {
            let result : IPAddress = this.versionedValues[index];
            if(result == null) {
                this.versionedValues[index] = result = this.createVersionedAddress(version);
            }
            return result;
        }

        public getAddress$inet_ipaddr_IPAddress_IPVersion(version : IPAddress.IPVersion) : IPAddress {
            let index : number = /* Enum.ordinal */IPAddress.IPVersion[IPAddress.IPVersion[version]];
            let result : IPAddress;
            if(this.versionedValues == null) {
                {
                    if(this.versionedValues == null) {
                        this.versionedValues = (s => { let a=[]; while(s-->0) a.push(null); return a; })(/* Enum.values */function() { let result: number[] = []; for(let val in IPAddress.IPVersion) { if(!isNaN(<any>val)) { result.push(parseInt(val,10)); } } return result; }().length);
                        this.versionedValues[index] = result = this.createVersionedAddress(version);
                    } else {
                        result = this.checkResult(version, index);
                    }
                };
            } else {
                result = this.versionedValues[index];
                if(result == null) {
                    {
                        result = this.checkResult(version, index);
                    };
                }
            }
            return result;
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        public getAddress(version? : any) : any {
            if(((typeof version === 'number') || version === null)) {
                return <any>this.getAddress$inet_ipaddr_IPAddress_IPVersion(version);
            } else if(version === undefined) {
                return <any>this.getAddress$();
            } else throw new Error('invalid overload');
        }

        abstract createVersionedAddress(version : IPAddress.IPVersion) : IPAddress;
    }
    VersionedAddressCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.VersionedAddressCreator";
    VersionedAddressCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export abstract class AdjustedAddressCreator extends IPAddressProvider.VersionedAddressCreator {
        static serialVersionUID : number = 4;

        adjustedVersion : IPAddress.IPVersion;

        qualifier : ParsedHostIdentifierStringQualifier;

        public constructor(qualifier? : any, adjustedVersion? : any, options? : any) {
            if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((typeof adjustedVersion === 'number') || adjustedVersion === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(options);
                if(this.adjustedVersion===undefined) this.adjustedVersion = null;
                if(this.qualifier===undefined) this.qualifier = null;
                if(this.adjustedVersion===undefined) this.adjustedVersion = null;
                if(this.qualifier===undefined) this.qualifier = null;
                (() => {
                    this.qualifier = qualifier;
                    this.adjustedVersion = adjustedVersion;
                })();
            } else if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((adjustedVersion != null && adjustedVersion instanceof <any>IPAddressStringParameters) || adjustedVersion === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[1];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let adjustedVersion : any = null;
                    super(options);
                    if(this.adjustedVersion===undefined) this.adjustedVersion = null;
                    if(this.qualifier===undefined) this.qualifier = null;
                    if(this.adjustedVersion===undefined) this.adjustedVersion = null;
                    if(this.qualifier===undefined) this.qualifier = null;
                    (() => {
                        this.qualifier = qualifier;
                        this.adjustedVersion = adjustedVersion;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPAddress() : boolean {
            return this.adjustedVersion != null;
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv4() : boolean {
            return this.isIPAddress() && IPAddress.IPVersion["_$wrappers"][this.adjustedVersion].isIPv4();
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv6() : boolean {
            return this.isIPAddress() && IPAddress.IPVersion["_$wrappers"][this.adjustedVersion].isIPv6();
        }

        /**
         * 
         * @return {IPAddress.IPVersion}
         */
        public getIPVersion() : IPAddress.IPVersion {
            return this.adjustedVersion;
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            if(this.qualifier == null) {
                return null;
            }
            return this.qualifier.getNetworkPrefixLength();
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        public getAddress(version? : any) : any {
            if(((typeof version === 'number') || version === null)) {
                super.getAddress(version);
            } else if(version === undefined) {
                return <any>this.getAddress$();
            } else throw new Error('invalid overload');
        }

        public getAddress$() : IPAddress {
            if(this.adjustedVersion == null) {
                return null;
            }
            return super.getAddress();
        }

        /**
         * 
         * @return {IPAddress}
         */
        public getHostAddress() : IPAddress {
            if(this.adjustedVersion == null) {
                return null;
            }
            return super.getHostAddress();
        }
    }
    AdjustedAddressCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.AdjustedAddressCreator";
    AdjustedAddressCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class LoopbackCreator extends IPAddressProvider.VersionedAddressCreator {
        static serialVersionUID : number = 4;

        zone : any;

        public constructor(zone? : any, options? : any) {
            if(((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(options);
                if(this.zone===undefined) this.zone = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.zone = zone;
                })();
            } else if(((zone != null && zone instanceof <any>IPAddressStringParameters) || zone === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[0];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zone : any = null;
                    super(options);
                    if(this.zone===undefined) this.zone = null;
                    if(this.zone===undefined) this.zone = null;
                    (() => {
                        this.zone = zone;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPAddressProvider.IPType}
         */
        public getType() : IPAddressProvider.IPType {
            return IPAddressProvider.IPType_$WRAPPER.from(this.getIPVersion());
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPAddress() : boolean {
            return true;
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv4() : boolean {
            return this.getAddress().isIPv4();
        }

        /**
         * 
         * @return {boolean}
         */
        public isIPv6() : boolean {
            return this.getAddress().isIPv6();
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        createVersionedAddress(version : IPAddress.IPVersion) : IPAddress {
            if(this.values != null && /* Enum.equals */(<any>(version) === <any>(this.values.getAddress().getIPVersion()))) {
                return this.values.getAddress();
            }
            let network : IPAddressNetwork<any, any, any, any, any> = IPAddress.IPVersion["_$wrappers"][version].isIPv4()?this.options.getIPv4Parameters().getNetwork():this.options.getIPv6Parameters().getNetwork();
            let address : IPAddress = network.getLoopback();
            if(this.zone != null && this.zone.length > 0 && IPAddress.IPVersion["_$wrappers"][version].isIPv6()) {
                let addressCreator : ParsedAddressCreator<any, any, any, any> = network.getAddressCreator();
                return addressCreator.createAddressInternal$byte_A$java_lang_CharSequence(address.getBytes(), this.zone);
            }
            return address;
        }

        /**
         * 
         * @return {ParsedIPAddress.CachedIPAddresses}
         */
        createAddresses() : ParsedIPAddress.CachedIPAddresses<IPAddress> {
            let loopback : InetAddress = InetAddress.getLoopbackAddress();
            let isIPv6 : boolean = (loopback != null && loopback instanceof <any>Inet6Address);
            let result : IPAddress;
            if(this.zone != null && this.zone.length > 0 && isIPv6) {
                let addressCreator : ParsedAddressCreator<any, any, any, any> = this.options.getIPv6Parameters().getNetwork().getAddressCreator();
                result = addressCreator.createAddressInternal$byte_A$java_lang_CharSequence(loopback.getAddress(), this.zone);
            } else if(isIPv6) {
                result = this.options.getIPv6Parameters().getNetwork().getLoopback();
            } else {
                result = this.options.getIPv4Parameters().getNetwork().getLoopback();
            }
            return <any>(new ParsedIPAddress.CachedIPAddresses<IPAddress>(result));
        }

        /**
         * 
         * @return {IPAddress.IPVersion}
         */
        public getIPVersion() : IPAddress.IPVersion {
            return this.getAddress().getIPVersion();
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            return null;
        }
    }
    LoopbackCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.LoopbackCreator";
    LoopbackCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class MaskCreator extends IPAddressProvider.AdjustedAddressCreator {
        static __inet_ipaddr_format_validate_IPAddressProvider_MaskCreator_serialVersionUID : number = 4;

        public constructor(qualifier? : any, adjustedVersion? : any, options? : any) {
            if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((typeof adjustedVersion === 'number') || adjustedVersion === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(qualifier, adjustedVersion, options);
            } else if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((adjustedVersion != null && adjustedVersion instanceof <any>IPAddressStringParameters) || adjustedVersion === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let options : any = __args[1];
                super(qualifier, options);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            if(this.adjustedVersion == null) {
                return this.getNetworkPrefixLength();
            }
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.getAddress()));
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o === this) {
                return true;
            }
            if(o != null && o instanceof <any>IPAddressProvider) {
                let valueProvider : IPAddressProvider = <IPAddressProvider>o;
                if(this.adjustedVersion == null) {
                    if(valueProvider.getType() === IPAddressProvider.IPType.PREFIX_ONLY) {
                        return valueProvider.getNetworkPrefixLength() === this.getNetworkPrefixLength();
                    }
                    return false;
                }
                return super.equals(valueProvider);
            }
            return false;
        }

        /**
         * 
         * @param {IPAddressProvider} other
         * @return {number}
         */
        public compareTo(other : IPAddressProvider) : number {
            if(this === other) {
                return 0;
            }
            if(this.adjustedVersion == null) {
                if(other.getType() === IPAddressProvider.IPType.PREFIX_ONLY) {
                    return other.getNetworkPrefixLength() - this.getNetworkPrefixLength();
                }
                return /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[IPAddressProvider.IPType.PREFIX_ONLY]] - /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[other.getType()]];
            }
            let otherValue : IPAddress = other.getAddress();
            if(otherValue != null) {
                return this.getAddress().compareTo(otherValue);
            }
            return /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[IPAddressProvider.IPType_$WRAPPER.from(this.adjustedVersion)]] - /* Enum.ordinal */IPAddressProvider.IPType[IPAddressProvider.IPType[other.getType()]];
        }

        createVersionedMask(version : IPAddress.IPVersion, bits : number, withPrefixLength : boolean) : IPAddress {
            let network : IPAddressNetwork<any, any, any, any, any> = IPAddress.IPVersion["_$wrappers"][version].isIPv4()?this.options.getIPv4Parameters().getNetwork():this.options.getIPv6Parameters().getNetwork();
            return network.getNetworkMask(bits, withPrefixLength);
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        createVersionedAddress(version : IPAddress.IPVersion) : IPAddress {
            return this.createVersionedMask(version, this.getNetworkPrefixLength(), true);
        }

        /**
         * 
         * @return {number}
         */
        public getNetworkPrefixLength() : number {
            return this.qualifier.getNetworkPrefixLength();
        }

        /**
         * 
         * @return {IPAddressProvider.IPType}
         */
        public getType() : IPAddressProvider.IPType {
            if(this.adjustedVersion != null) {
                return IPAddressProvider.IPType_$WRAPPER.from(this.adjustedVersion);
            }
            return IPAddressProvider.IPType.PREFIX_ONLY;
        }

        /**
         * 
         * @return {boolean}
         */
        public isPrefixOnly() : boolean {
            return this.adjustedVersion == null;
        }

        /**
         * 
         * @return {ParsedIPAddress.CachedIPAddresses}
         */
        createAddresses() : ParsedIPAddress.CachedIPAddresses<any> {
            return <any>(new ParsedIPAddress.CachedIPAddresses<IPAddress>(this.createVersionedMask(this.adjustedVersion, this.getNetworkPrefixLength(), true), this.createVersionedMask(this.adjustedVersion, this.getNetworkPrefixLength(), false)));
        }
    }
    MaskCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.MaskCreator";
    MaskCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class AllCreator extends IPAddressProvider.AdjustedAddressCreator {
        static __inet_ipaddr_format_validate_IPAddressProvider_AllCreator_serialVersionUID : number = 4;

        originator : HostIdentifierString;

        public constructor(qualifier? : any, adjustedVersion? : any, originator? : any, options? : any) {
            if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((typeof adjustedVersion === 'number') || adjustedVersion === null) && ((originator != null && (originator["__interfaces"] != null && originator["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || originator.constructor != null && originator.constructor["__interfaces"] != null && originator.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || originator === null) && ((options != null && options instanceof <any>IPAddressStringParameters) || options === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(qualifier, adjustedVersion, options);
                if(this.originator===undefined) this.originator = null;
                if(this.originator===undefined) this.originator = null;
                (() => {
                    this.originator = originator;
                })();
            } else if(((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null) && ((adjustedVersion != null && (adjustedVersion["__interfaces"] != null && adjustedVersion["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || adjustedVersion.constructor != null && adjustedVersion.constructor["__interfaces"] != null && adjustedVersion.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || adjustedVersion === null) && ((originator != null && originator instanceof <any>IPAddressStringParameters) || originator === null) && options === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let originator : any = __args[1];
                let options : any = __args[2];
                super(qualifier, options);
                if(this.originator===undefined) this.originator = null;
                if(this.originator===undefined) this.originator = null;
                (() => {
                    this.originator = originator;
                })();
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {IPAddress.IPVersion} version
         * @return {IPAddress}
         */
        createVersionedAddress(version : IPAddress.IPVersion) : IPAddress {
            return ParsedIPAddress.createAllAddress(version, this.qualifier, this.originator, this.options);
        }

        /**
         * 
         * @return {IPAddressProvider.IPType}
         */
        public getType() : IPAddressProvider.IPType {
            if(this.adjustedVersion != null) {
                return IPAddressProvider.IPType_$WRAPPER.from(this.adjustedVersion);
            }
            return IPAddressProvider.IPType.ALL;
        }

        /**
         * 
         * @return {boolean}
         */
        public isAllAddresses() : boolean {
            return this.adjustedVersion == null;
        }

        /**
         * 
         * @return {number}
         */
        public hashCode() : number {
            if(this.adjustedVersion == null) {
                return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(IPAddress.SEGMENT_WILDCARD_STR_$LI$()));
            }
            return /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
        }

        /**
         * 
         * @return {ParsedIPAddress.CachedIPAddresses}
         */
        createAddresses() : ParsedIPAddress.CachedIPAddresses<any> {
            return <any>(new ParsedIPAddress.CachedIPAddresses<IPAddress>(ParsedIPAddress.createAllAddress(this.adjustedVersion, this.qualifier, this.originator, this.options)));
        }
    }
    AllCreator["__class"] = "inet.ipaddr.format.validate.IPAddressProvider.AllCreator";
    AllCreator["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class IPAddressProvider$0 extends IPAddressProvider.NullProvider {
        /**
         * 
         * @return {boolean}
         */
        public isInvalid() : boolean {
            return true;
        }

        constructor(__arg0: any) {
            super(__arg0);
        }
    }
    IPAddressProvider$0["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class IPAddressProvider$1 extends IPAddressProvider.NullProvider {
        /**
         * 
         * @return {boolean}
         */
        public isUninitialized() : boolean {
            return true;
        }

        constructor(__arg0: any) {
            super(__arg0);
        }
    }
    IPAddressProvider$1["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];



    export class IPAddressProvider$2 extends IPAddressProvider.NullProvider {
        /**
         * 
         * @return {boolean}
         */
        public isEmpty() : boolean {
            return true;
        }

        constructor(__arg0: any) {
            super(__arg0);
        }
    }
    IPAddressProvider$2["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];


}




IPAddressProvider.EMPTY_PROVIDER_$LI$();

IPAddressProvider.NO_TYPE_PROVIDER_$LI$();

IPAddressProvider.INVALID_PROVIDER_$LI$();
