/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../../Address';
import { AddressStringException } from '../../AddressStringException';
import { AddressStringParameters } from '../../AddressStringParameters';
import { HostIdentifierString } from '../../HostIdentifierString';
import { HostName } from '../../HostName';
import { HostNameException } from '../../HostNameException';
import { HostNameParameters } from '../../HostNameParameters';
import { IPAddress } from '../../IPAddress';
import { IPAddressString } from '../../IPAddressString';
import { IPAddressStringParameters } from '../../IPAddressStringParameters';
import { MACAddressString } from '../../MACAddressString';
import { MACAddressStringParameters } from '../../MACAddressStringParameters';
import { IPAddressLargeDivision } from '../IPAddressLargeDivision';
import { IPv4Address } from '../../ipv4/IPv4Address';
import { IPv4AddressSegment } from '../../ipv4/IPv4AddressSegment';
import { IPv4AddressStringParameters } from '../../ipv4/IPv4AddressStringParameters';
import { IPv6Address } from '../../ipv6/IPv6Address';
import { IPv6AddressSegment } from '../../ipv6/IPv6AddressSegment';
import { IPv6AddressStringParameters } from '../../ipv6/IPv6AddressStringParameters';
import { MACAddress } from '../../mac/MACAddress';
import { MACAddressSegment } from '../../mac/MACAddressSegment';
import { HostIdentifierStringValidator } from './HostIdentifierStringValidator';
import { ParsedHostIdentifierStringQualifier } from './ParsedHostIdentifierStringQualifier';
import { ParsedHost } from './ParsedHost';
import { IPAddressProvider } from './IPAddressProvider';
import { MACAddressProvider } from './MACAddressProvider';
import { ParsedMACAddress } from './ParsedMACAddress';
import { AddressParseData } from './AddressParseData';
import { ParsedIPAddress } from './ParsedIPAddress';

/**
 * Validates host strings, address strings, and prefix lengths.
 * 
 * @author sfoley
 * @class
 */
export class Validator implements HostIdentifierStringValidator {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!Validator.__static_initialized) { Validator.__static_initialized = true; Validator.__static_initializer_0(); Validator.__static_initializer_1(); Validator.__static_initializer_2(); } }

    static extendedChars : number[]; public static extendedChars_$LI$() : number[] { Validator.__static_initialize(); if(Validator.extendedChars == null) Validator.extendedChars = (s => { let a=[]; while(s-->0) a.push(0); return a; })(128); return Validator.extendedChars; };

    static __static_initializer_0() {
        let extendedDigits : string[] = IPAddressLargeDivision.EXTENDED_DIGITS_$LI$();
        for(let i : number = 0; i < extendedDigits.length; i++) {
            Validator.extendedChars_$LI$()[(extendedDigits[i]).charCodeAt(0)] = i;
        };
    }

    static chars : number[]; public static chars_$LI$() : number[] { Validator.__static_initialize(); if(Validator.chars == null) Validator.chars = (s => { let a=[]; while(s-->0) a.push(0); return a; })(128); return Validator.chars; };

    static __static_initializer_1() {
        let charArray : number[] = Validator.chars_$LI$();
        let i : number = 0;
        for(let c : string = '0'; i < 10; i++, c++) {
            charArray[(c).charCodeAt(0)] = i;
        };
        for(let c : string = 'a', c2 : string = 'A'; i < 26; i++, c++, c2++) {
            charArray[(c).charCodeAt(0)] = charArray[(c2).charCodeAt(0)] = i;
        };
    }

    static MAX_HOST_LENGTH : number = 253;

    static MAX_HOST_SEGMENTS : number = 127;

    static MAX_LABEL_LENGTH : number = 63;

    static MAC_MAX_TRIPLE : number; public static MAC_MAX_TRIPLE_$LI$() : number { Validator.__static_initialize(); if(Validator.MAC_MAX_TRIPLE == null) Validator.MAC_MAX_TRIPLE = (MACAddress.MAX_VALUE_PER_SEGMENT << (MACAddress.BITS_PER_SEGMENT << 1)) | (MACAddress.MAX_VALUE_PER_SEGMENT << MACAddress.BITS_PER_SEGMENT) | MACAddress.MAX_VALUE_PER_SEGMENT; return Validator.MAC_MAX_TRIPLE; };

    static MAC_MAX_QUINTUPLE : number; public static MAC_MAX_QUINTUPLE_$LI$() : number { Validator.__static_initialize(); if(Validator.MAC_MAX_QUINTUPLE == null) Validator.MAC_MAX_QUINTUPLE = (Validator.MAC_MAX_TRIPLE_$LI$() << (MACAddress.BITS_PER_SEGMENT << 1)) | (Validator.MAC_MAX_TRIPLE_$LI$() >>> MACAddress.BITS_PER_SEGMENT); return Validator.MAC_MAX_QUINTUPLE; };

    static MAC_DOUBLE_SEGMENT_DIGIT_COUNT : number = 6;

    static MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT : number = 10;

    static MAC_SINGLE_SEGMENT_DIGIT_COUNT : number = 12;

    static MAC_EXTENDED_SINGLE_SEGMENT_DIGIT_COUNT : number = 16;

    static IPV6_SINGLE_SEGMENT_DIGIT_COUNT : number = 32;

    static IPV6_BASE85_SINGLE_SEGMENT_DIGIT_COUNT : number = 20;

    static IPV4_SINGLE_SEGMENT_OCTAL_DIGIT_COUNT : number = 11;

    static LONG_HEX_DIGITS : number; public static LONG_HEX_DIGITS_$LI$() : number { Validator.__static_initialize(); if(Validator.LONG_HEX_DIGITS == null) Validator.LONG_HEX_DIGITS = javaemul.internal.LongHelper.SIZE >>> 2; return Validator.LONG_HEX_DIGITS; };

    static IPvFUTURE_UPPERCASE : string; public static IPvFUTURE_UPPERCASE_$LI$() : string { Validator.__static_initialize(); if(Validator.IPvFUTURE_UPPERCASE == null) Validator.IPvFUTURE_UPPERCASE = /* toUpperCase */HostIdentifierStringValidator.IPvFUTURE.toUpperCase(); return Validator.IPvFUTURE_UPPERCASE; };

    static EMPTY_INDICES : number[]; public static EMPTY_INDICES_$LI$() : number[] { Validator.__static_initialize(); if(Validator.EMPTY_INDICES == null) Validator.EMPTY_INDICES = []; return Validator.EMPTY_INDICES; };

    static PREFIX_CACHE : ParsedHostIdentifierStringQualifier[]; public static PREFIX_CACHE_$LI$() : ParsedHostIdentifierStringQualifier[] { Validator.__static_initialize(); if(Validator.PREFIX_CACHE == null) Validator.PREFIX_CACHE = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv6Address.BIT_COUNT + 1); return Validator.PREFIX_CACHE; };

    static DEFAULT_EMPTY_HOST : ParsedHost; public static DEFAULT_EMPTY_HOST_$LI$() : ParsedHost { Validator.__static_initialize(); if(Validator.DEFAULT_EMPTY_HOST == null) Validator.DEFAULT_EMPTY_HOST = new ParsedHost("", Validator.EMPTY_INDICES_$LI$(), null, ParsedHost.NO_QUALIFIER_$LI$()); return Validator.DEFAULT_EMPTY_HOST; };

    static DEFAULT_PREFIX_OPTIONS : IPAddressStringParameters; public static DEFAULT_PREFIX_OPTIONS_$LI$() : IPAddressStringParameters { Validator.__static_initialize(); if(Validator.DEFAULT_PREFIX_OPTIONS == null) Validator.DEFAULT_PREFIX_OPTIONS = new IPAddressStringParameters.Builder().toParams(); return Validator.DEFAULT_PREFIX_OPTIONS; };

    public static VALIDATOR : HostIdentifierStringValidator; public static VALIDATOR_$LI$() : HostIdentifierStringValidator { Validator.__static_initialize(); if(Validator.VALIDATOR == null) Validator.VALIDATOR = new Validator(); return Validator.VALIDATOR; };

    static DEFAULT_UNC_OPTS : IPAddressStringParameters; public static DEFAULT_UNC_OPTS_$LI$() : IPAddressStringParameters { Validator.__static_initialize(); if(Validator.DEFAULT_UNC_OPTS == null) Validator.DEFAULT_UNC_OPTS = new IPAddressStringParameters.Builder().allowIPv4(false).allowEmpty(false).allowMask(false).allowPrefixOnly(false).allowPrefix(false).toParams(); return Validator.DEFAULT_UNC_OPTS; };

    static REVERSE_DNS_IPV4_OPTS : IPAddressStringParameters; public static REVERSE_DNS_IPV4_OPTS_$LI$() : IPAddressStringParameters { Validator.__static_initialize(); if(Validator.REVERSE_DNS_IPV4_OPTS == null) Validator.REVERSE_DNS_IPV4_OPTS = new IPAddressStringParameters.Builder().allowIPv6(false).allowEmpty(false).allowMask(false).allowPrefixOnly(false).allowPrefix(false).getIPv4AddressParametersBuilder().allow_inet_aton(false).getParentBuilder().toParams(); return Validator.REVERSE_DNS_IPV4_OPTS; };

    static REVERSE_DNS_IPV6_OPTS : IPAddressStringParameters; public static REVERSE_DNS_IPV6_OPTS_$LI$() : IPAddressStringParameters { Validator.__static_initialize(); if(Validator.REVERSE_DNS_IPV6_OPTS == null) Validator.REVERSE_DNS_IPV6_OPTS = new IPAddressStringParameters.Builder().allowIPv4(false).allowEmpty(false).allowMask(false).allowPrefixOnly(false).allowPrefix(false).getIPv6AddressParametersBuilder().allowMixed(false).allowZone(false).getParentBuilder().toParams(); return Validator.REVERSE_DNS_IPV6_OPTS; };

    static BASE_85_POWERS : BigInteger[]; public static BASE_85_POWERS_$LI$() : BigInteger[] { Validator.__static_initialize(); if(Validator.BASE_85_POWERS == null) Validator.BASE_85_POWERS = [null, null, null, null, null, null, null, null, null, null]; return Validator.BASE_85_POWERS; };

    static LOW_BITS_MASK : BigInteger; public static LOW_BITS_MASK_$LI$() : BigInteger { Validator.__static_initialize(); if(Validator.LOW_BITS_MASK == null) Validator.LOW_BITS_MASK = BigInteger.valueOf(-1); return Validator.LOW_BITS_MASK; };

    constructor() {
    }

    /**
     * 
     * @param {HostName} fromHost
     * @return {ParsedHost}
     */
    public validateHost(fromHost : HostName) : ParsedHost {
        return Validator.validateHostImpl(fromHost);
    }

    public validateAddress$inet_ipaddr_IPAddressString(fromString : IPAddressString) : IPAddressProvider {
        return Validator.validateAddressImpl(fromString);
    }

    /**
     * 
     * @param {IPAddressString} fromString
     * @return {IPAddressProvider}
     */
    public validateAddress(fromString? : any) : any {
        if(((fromString != null && fromString instanceof <any>IPAddressString) || fromString === null)) {
            return <any>this.validateAddress$inet_ipaddr_IPAddressString(fromString);
        } else if(((fromString != null && fromString instanceof <any>MACAddressString) || fromString === null)) {
            return <any>this.validateAddress$inet_ipaddr_MACAddressString(fromString);
        } else throw new Error('invalid overload');
    }

    public validateAddress$inet_ipaddr_MACAddressString(fromString : MACAddressString) : MACAddressProvider {
        let str : string = fromString.toString();
        let validationOptions : MACAddressStringParameters = fromString.getValidationOptions();
        let macAddressParseData : ParsedMACAddress.MACAddressParseData = new ParsedMACAddress.MACAddressParseData(str);
        Validator.validateMACAddress(validationOptions, str, 0, str.length, macAddressParseData);
        let addressParseData : AddressParseData = macAddressParseData.addressParseData;
        if(addressParseData.isEmpty) {
            return MACAddressProvider.EMPTY_PROVIDER_$LI$();
        } else if(addressParseData.isAll) {
            return MACAddressProvider.getAllProvider(validationOptions);
        } else {
            let parsedAddress : ParsedMACAddress = Validator.createParsedMACAddress(fromString, fromString.toString(), fromString.getValidationOptions(), macAddressParseData);
            return new MACAddressProvider(parsedAddress);
        }
    }

    static validateAddressImpl(fromString : IPAddressString) : IPAddressProvider {
        let str : string = fromString.toString();
        let validationOptions : IPAddressStringParameters = fromString.getValidationOptions();
        let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
        Validator.validateIPAddress(validationOptions, str, 0, str.length, ipAddressParseData);
        return Validator.createProvider(fromString, str, validationOptions, ipAddressParseData, Validator.parseAddressQualifier(str, validationOptions, null, ipAddressParseData, str.length));
    }

    public static validateIPAddress(validationOptions : IPAddressStringParameters, str : any, strStartIndex : number, strEndIndex : number, parseData : ParsedIPAddress.IPAddressParseData, isEmbeddedIPv4 : boolean = false) {
        Validator.validateAddress(validationOptions, null, str, strStartIndex, strEndIndex, parseData, null, isEmbeddedIPv4);
    }

    /*private*/ static createParsedMACAddress(originator : MACAddressString, fullAddr : string, validationOptions : MACAddressStringParameters, parseData : ParsedMACAddress.MACAddressParseData) : ParsedMACAddress {
        if(parseData.format != null) {
            let hasWildcardSeparator : boolean = parseData.addressParseData.anyWildcard && validationOptions.getFormatParameters().allowWildcardedSeparator;
            let segCount : number = parseData.addressParseData.segmentCount;
            if(parseData.format === MACAddressParseData.MACFormat.DOTTED) {
                if(segCount <= MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT && validationOptions.addressSize !== MACAddressStringParameters.AddressSize.EUI64) {
                    if(!hasWildcardSeparator && segCount !== MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT) {
                        throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
                    }
                } else if(!hasWildcardSeparator && segCount < MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_64_SEGMENT_COUNT) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
                } else {
                    parseData.isExtended = true;
                }
            } else {
                if(segCount > 2) {
                    if(segCount <= MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT && validationOptions.addressSize !== MACAddressStringParameters.AddressSize.EUI64) {
                        if(!hasWildcardSeparator && segCount !== MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT) {
                            throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
                        }
                    } else if(!hasWildcardSeparator && segCount < MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT) {
                        throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
                    } else {
                        parseData.isExtended = true;
                    }
                    if(parseData.format === MACAddressParseData.MACFormat.DASHED) {
                        let max : number = MACAddress.MAX_VALUE_PER_SEGMENT;
                        let maxChars : number = MACAddressSegment.MAX_CHARS;
                        for(let i : number = 0; i < segCount; i++) {
                            Validator.checkMaxValues(fullAddr, parseData.addressParseData, i, validationOptions.getFormatParameters(), max, maxChars, maxChars);
                        };
                    }
                } else {
                    if(parseData.format === MACAddressParseData.MACFormat.DASHED) {
                        if(parseData.isDoubleSegment) {
                            let params : MACAddressStringParameters.MACAddressStringFormatParameters = validationOptions.getFormatParameters();
                            let data : AddressParseData = parseData.addressParseData;
                            Validator.checkMaxValues(fullAddr, data, 0, params, Validator.MAC_MAX_TRIPLE_$LI$(), Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT, Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT);
                            if(parseData.isExtended) {
                                Validator.checkMaxValues(fullAddr, data, 1, params, Validator.MAC_MAX_QUINTUPLE_$LI$(), Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT, Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT);
                            } else {
                                Validator.checkMaxValues(fullAddr, data, 1, params, Validator.MAC_MAX_TRIPLE_$LI$(), Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT, Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT);
                            }
                        }
                    } else if(!hasWildcardSeparator) {
                        throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
                    }
                    if(validationOptions.addressSize === MACAddressStringParameters.AddressSize.EUI64) {
                        parseData.isExtended = true;
                    }
                }
            }
        }
        let parsedAddress : ParsedMACAddress = new ParsedMACAddress(originator, fullAddr, parseData);
        return parsedAddress;
    }

    /*private*/ static validateMACAddress(validationOptions : MACAddressStringParameters, str : string, strStartIndex : number, strEndIndex : number, parseData : ParsedMACAddress.MACAddressParseData) {
        Validator.validateAddress(null, validationOptions, str, strStartIndex, strEndIndex, null, parseData, false);
    }

    /**
     * This method is the mega-parser.
     * It is designed to go through the characters one-by-one if a big if/else.
     * You have basically several cases: digits, segment separators (. : -), end characters like zone or prefix length,
     * range characters denoting a range a-b, wildcard char *, and the 'x' character used to denote hex like 0xf.
     * 
     * Most of the processing occurs in the segment characters, where each segment is analyzed based on what chars came before.
     * 
     * We can parse all possible imaginable variations of mac, ipv4, and ipv6.
     * 
     * This is not the clearest way to write such a parser, because the code for each possible variation is interspersed amongst the various cases,
     * so you cannot easily see the code for a given variation clearly, but written this way it may be the fastest parser since we basically account
     * for all possibilities simultaneously as we move through the characters just once.
     * 
     * @param {IPAddressStringParameters} validationOptions
     * @param {MACAddressStringParameters} macOptions
     * @param {*} str
     * @param {number} strStartIndex
     * @param {number} strEndIndex
     * @param {ParsedIPAddress.IPAddressParseData} ipAddressParseData
     * @param {ParsedMACAddress.MACAddressParseData} macAddressParseData
     * @throws AddressStringException
     * @param {boolean} isEmbeddedIPv4
     * @private
     */
    /*private*/ static validateAddress(validationOptions : IPAddressStringParameters, macOptions : MACAddressStringParameters, str : any, strStartIndex : number, strEndIndex : number, ipAddressParseData : ParsedIPAddress.IPAddressParseData, macAddressParseData : ParsedMACAddress.MACAddressParseData, isEmbeddedIPv4 : boolean) {
        let isMac : boolean = macAddressParseData != null;
        let parseData : AddressParseData;
        let stringFormatParams : AddressStringParameters.AddressStringFormatParameters;
        let ipv6SpecificOptions : IPv6AddressStringParameters = null;
        let ipv4SpecificOptions : IPv4AddressStringParameters = null;
        let macSpecificOptions : MACAddressStringParameters.MACAddressStringFormatParameters = null;
        let baseOptions : AddressStringParameters;
        let macFormat : MACAddressParseData.MACFormat = null;
        let isBase85 : boolean;
        if(isMac) {
            baseOptions = macOptions;
            stringFormatParams = macSpecificOptions = macOptions.getFormatParameters();
            parseData = macAddressParseData.addressParseData;
            isBase85 = false;
        } else {
            baseOptions = validationOptions;
            stringFormatParams = null;
            parseData = ipAddressParseData.addressParseData;
            ipv6SpecificOptions = validationOptions.getIPv6Parameters();
            isBase85 = ipv6SpecificOptions.allowBase85;
            ipv4SpecificOptions = validationOptions.getIPv4Parameters();
        }
        let index : number = strStartIndex;
        let lastSeparatorIndex : number;
        let digitCount : number;
        let leadingZeroCount : number;
        let rangeWildcardIndex : number;
        let hexDelimiterIndex : number;
        let singleWildcardCount : number;
        let wildcardCount : number;
        let frontDigitCount : number;
        let frontLeadingZeroCount : number;
        let frontWildcardCount : number;
        let frontSingleWildcardCount : number;
        let frontHexDelimiterIndex : number;
        let notOctal : boolean;
        let notDecimal : boolean;
        let uppercase : boolean;
        let isSingleIPv6Hex : boolean;
        let isSingleSegment : boolean;
        let isDoubleSegment : boolean;
        let frontNotOctal : boolean;
        let frontNotDecimal : boolean;
        let frontUppercase : boolean;
        let frontIsStandardRange : boolean;
        let firstSegmentDashedRange : boolean;
        let countedCharacters : boolean;
        let countingCharsLater : boolean;
        let extendedCharacterIndex : number;
        let extendedRangeWildcardIndex : number;
        let atEnd : boolean;
        frontDigitCount = frontLeadingZeroCount = frontSingleWildcardCount = digitCount = leadingZeroCount = singleWildcardCount = wildcardCount = frontWildcardCount = 0;
        extendedCharacterIndex = extendedRangeWildcardIndex = lastSeparatorIndex = rangeWildcardIndex = hexDelimiterIndex = frontHexDelimiterIndex = -1;
        frontIsStandardRange = countingCharsLater = countedCharacters = atEnd = firstSegmentDashedRange = frontNotOctal = frontNotDecimal = frontUppercase = notOctal = notDecimal = uppercase = isSingleIPv6Hex = isSingleSegment = isDoubleSegment = false;
        while((index < strEndIndex || (atEnd = (index === strEndIndex)))) {
            let currentChar : string;
            if(atEnd) {
                parseData.addressEndIndex = index;
                let totalDigits : number = leadingZeroCount + digitCount;
                let isSegmented : boolean = isMac?macFormat != null:ipAddressParseData.ipVersion != null;
                if(isSegmented) {
                    if(isMac) {
                        currentChar = ParsedMACAddress.MACAddressParseData.MACFormat["_$wrappers"][macFormat].getSeparator();
                        isDoubleSegment = macAddressParseData.isDoubleSegment = (parseData.segmentCount === 1 && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.RANGE_SEPARATOR));
                        if(isDoubleSegment) {
                            macAddressParseData.isExtended = (totalDigits === Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT);
                        }
                    } else {
                        let version : IPAddress.IPVersion = ipAddressParseData.ipVersion;
                        if(IPAddress.IPVersion["_$wrappers"][version].isIPv4()) {
                            currentChar = IPv4Address.SEGMENT_SEPARATOR;
                        } else {
                            if(index === lastSeparatorIndex + 1) {
                                if(index === parseData.consecutiveSepIndex + 2) {
                                    break;
                                }
                                throw new AddressStringException(str, "ipaddress.error.cannot.end.with.single.separator");
                            } else if(ipAddressParseData.mixedParsedAddress != null) {
                                break;
                            } else {
                                currentChar = IPv6Address.SEGMENT_SEPARATOR;
                            }
                        }
                    }
                } else {
                    let totalCharacterCount : number = index - strStartIndex;
                    if(totalCharacterCount === 0) {
                        if(!isMac && ipAddressParseData.isPrefixed) {
                            if(!validationOptions.allowPrefixOnly) {
                                throw new AddressStringException(str, "ipaddress.error.prefix.only");
                            }
                        } else if(!baseOptions.allowEmpty) {
                            throw new AddressStringException(str, "ipaddress.error.empty");
                        }
                        parseData.isEmpty = true;
                        break;
                    } else if(wildcardCount === totalCharacterCount) {
                        if(singleWildcardCount > 0 || rangeWildcardIndex >= 0 || leadingZeroCount > 0 || digitCount > 0 || hexDelimiterIndex >= 0) {
                            throw new AddressStringException(str, index, true);
                        }
                        if(!baseOptions.allowAll) {
                            throw new AddressStringException(str, "ipaddress.error.all");
                        }
                        parseData.anyWildcard = true;
                        parseData.isAll = true;
                        break;
                    }
                    if(isMac) {
                        let frontTotalDigits : number = frontLeadingZeroCount + frontDigitCount;
                        if((((totalDigits === Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT || totalDigits === Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT) && (frontTotalDigits === Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT || frontWildcardCount > 0)) || (frontTotalDigits === Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT && wildcardCount > 0) || (frontWildcardCount > 0 && wildcardCount > 0)) && !firstSegmentDashedRange) {
                            let addressSize : MACAddressStringParameters.AddressSize = macOptions.addressSize;
                            if(addressSize === MACAddressStringParameters.AddressSize.EUI64 && totalDigits === Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT) {
                                throw new AddressStringException(str, "ipaddress.error.too.few.segments");
                            } else if(addressSize === MACAddressStringParameters.AddressSize.MAC && totalDigits === Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT) {
                                throw new AddressStringException(str, "ipaddress.error.too.many.segments");
                            }
                            if(!macOptions.allowSingleDashed) {
                                throw new AddressStringException(str, "ipaddress.mac.error.format");
                            }
                            isDoubleSegment = macAddressParseData.isDoubleSegment = true;
                            macAddressParseData.isExtended = (totalDigits === Validator.MAC_EXTENDED_DOUBLE_SEGMENT_DIGIT_COUNT);
                            currentChar = MACAddress.DASH_SEGMENT_SEPARATOR;
                            countedCharacters = true;
                        } else if((frontWildcardCount > 0) || (wildcardCount > 0)) {
                            if(!macOptions.allowSingleDashed) {
                                throw new AddressStringException(str, "ipaddress.mac.error.format");
                            }
                            currentChar = MACAddress.DASH_SEGMENT_SEPARATOR;
                        } else {
                            if(!baseOptions.allowSingleSegment) {
                                throw new AddressStringException(str, "ipaddress.error.single.segment");
                            }
                            let is12Digits : boolean = totalDigits === Validator.MAC_SINGLE_SEGMENT_DIGIT_COUNT;
                            if(is12Digits || totalDigits === Validator.MAC_EXTENDED_SINGLE_SEGMENT_DIGIT_COUNT) {
                                if(rangeWildcardIndex >= 0) {
                                    if(frontTotalDigits !== (is12Digits?Validator.MAC_SINGLE_SEGMENT_DIGIT_COUNT:Validator.MAC_EXTENDED_SINGLE_SEGMENT_DIGIT_COUNT)) {
                                        throw new AddressStringException("ipaddress.error.front.digit.count");
                                    }
                                }
                                parseData.isSingleSegment = isSingleSegment = true;
                                macAddressParseData.isExtended = !is12Digits;
                                currentChar = MACAddress.COLON_SEGMENT_SEPARATOR;
                                countedCharacters = true;
                            } else {
                                throw new AddressStringException("ipaddress.error.too.few.segments.digit.count");
                            }
                        }
                    } else {
                        if(!baseOptions.allowSingleSegment) {
                            throw new AddressStringException(str, "ipaddress.error.single.segment");
                        }
                        if(totalDigits === Validator.IPV6_SINGLE_SEGMENT_DIGIT_COUNT) {
                            if(rangeWildcardIndex >= 0) {
                                let frontTotalDigits : number = frontLeadingZeroCount + frontDigitCount;
                                if(frontTotalDigits !== Validator.IPV6_SINGLE_SEGMENT_DIGIT_COUNT) {
                                    throw new AddressStringException("ipaddress.error.front.digit.count");
                                }
                            }
                            parseData.isSingleSegment = isSingleSegment = isSingleIPv6Hex = true;
                            currentChar = IPv6Address.SEGMENT_SEPARATOR;
                            countedCharacters = true;
                        } else {
                            if(isBase85) {
                                if(extendedRangeWildcardIndex < 0) {
                                    if(totalCharacterCount === Validator.IPV6_BASE85_SINGLE_SEGMENT_DIGIT_COUNT) {
                                        if(!validationOptions.allowIPv6) {
                                            throw new AddressStringException(str, "ipaddress.error.ipv6");
                                        }
                                        ipAddressParseData.ipVersion = IPAddress.IPVersion.IPV6;
                                        let val : BigInteger = Validator.parseBig85(str, strStartIndex, strEndIndex);
                                        let value : number = val.and(Validator.LOW_BITS_MASK_$LI$()).longValue();
                                        let shift64 : BigInteger = val.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        let extendedValue : number = shift64.longValue();
                                        let shiftMore : BigInteger = shift64.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        if(!shiftMore.equals(BigInteger.ZERO)) {
                                            throw new AddressStringException(str, "ipaddress.error.address.too.large");
                                        }
                                        parseData.initSegmentData(1);
                                        parseData.segmentCount = 1;
                                        let vals : number[] = parseData.values[0];
                                        let indices : number[] = parseData.indices[0];
                                        Validator.assignAttributes$int$int$int_A$int$int(strStartIndex, strEndIndex, indices, IPv6Address.DEFAULT_TEXTUAL_RADIX, strStartIndex);
                                        vals[AddressParseData.LOWER_INDEX] = vals[AddressParseData.UPPER_INDEX] = value;
                                        vals[AddressParseData.EXTENDED_LOWER_INDEX] = vals[AddressParseData.EXTENDED_UPPER_INDEX] = extendedValue;
                                        ipAddressParseData.isBase85 = true;
                                        break;
                                    }
                                } else {
                                    if(totalCharacterCount === (Validator.IPV6_BASE85_SINGLE_SEGMENT_DIGIT_COUNT << 1) + 1) {
                                        if(!validationOptions.allowIPv6) {
                                            throw new AddressStringException(str, "ipaddress.error.ipv6");
                                        }
                                        ipAddressParseData.ipVersion = IPAddress.IPVersion.IPV6;
                                        let frontEndIndex : number = strStartIndex + Validator.IPV6_BASE85_SINGLE_SEGMENT_DIGIT_COUNT;
                                        let val : BigInteger = Validator.parseBig85(str, strStartIndex, frontEndIndex);
                                        let val2 : BigInteger = Validator.parseBig85(str, frontEndIndex + 1, strEndIndex);
                                        let value : number = val.and(Validator.LOW_BITS_MASK_$LI$()).longValue();
                                        let shift64 : BigInteger = val.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        let extendedValue : number = shift64.longValue();
                                        let shiftMore : BigInteger = shift64.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        let value2 : number = val2.and(Validator.LOW_BITS_MASK_$LI$()).longValue();
                                        shift64 = val2.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        let extendedValue2 : number = shift64.longValue();
                                        shiftMore = shift64.shiftRight(javaemul.internal.LongHelper.SIZE);
                                        if(!shiftMore.equals(BigInteger.ZERO)) {
                                            throw new AddressStringException(str, "ipaddress.error.address.too.large");
                                        } else if(val.compareTo(val2) > 0) {
                                            throw new AddressStringException(str, "ipaddress.error.invalidRange");
                                        }
                                        parseData.initSegmentData(parseData.segmentCount = 1);
                                        let vals : number[] = parseData.values[0];
                                        let indices : number[] = parseData.indices[0];
                                        Validator.assignAttributes$int$int$int$int$int_A$int$int$int$int(strStartIndex, frontEndIndex, frontEndIndex + 1, strEndIndex, indices, strStartIndex, frontEndIndex + 1, IPv6Address.DEFAULT_TEXTUAL_RADIX, IPv6Address.DEFAULT_TEXTUAL_RADIX);
                                        vals[AddressParseData.LOWER_INDEX] = value;
                                        vals[AddressParseData.UPPER_INDEX] = value2;
                                        vals[AddressParseData.EXTENDED_LOWER_INDEX] = extendedValue;
                                        vals[AddressParseData.EXTENDED_UPPER_INDEX] = extendedValue2;
                                        ipAddressParseData.isBase85 = true;
                                        break;
                                    }
                                }
                            }
                            if(digitCount <= Validator.IPV4_SINGLE_SEGMENT_OCTAL_DIGIT_COUNT) {
                                if(rangeWildcardIndex >= 0) {
                                    if(frontDigitCount > Validator.IPV4_SINGLE_SEGMENT_OCTAL_DIGIT_COUNT) {
                                        throw new AddressStringException("ipaddress.error.front.digit.count");
                                    }
                                }
                                currentChar = IPv4Address.SEGMENT_SEPARATOR;
                            } else {
                                throw new AddressStringException("ipaddress.error.too.few.segments.digit.count");
                            }
                        }
                    }
                }
            } else {
                currentChar = str.charAt(index);
            }
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= '1'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= '7'.charCodeAt(0)) {
                ++digitCount;
                ++index;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == '0'.charCodeAt(0)) {
                if(digitCount > 0) {
                    ++digitCount;
                } else {
                    ++leadingZeroCount;
                }
                ++index;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == '8'.charCodeAt(0) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == '9'.charCodeAt(0)) {
                ++digitCount;
                ++index;
                notOctal = true;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= 'f'.charCodeAt(0)) {
                ++digitCount;
                ++index;
                notOctal = notDecimal = true;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= 'F'.charCodeAt(0)) {
                ++digitCount;
                ++index;
                notOctal = notDecimal = uppercase = true;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv4Address.SEGMENT_SEPARATOR)) {
                let segCount : number = parseData.segmentCount;
                if(!isMac && ipAddressParseData.ipVersion != null && IPAddress.IPVersion["_$wrappers"][ipAddressParseData.ipVersion].isIPv6()) {
                    if(extendedCharacterIndex >= 0) {
                        throw new AddressStringException(str, extendedCharacterIndex);
                    }
                    isBase85 = false;
                    if(!ipv6SpecificOptions.allowMixed) {
                        throw new AddressStringException(str, "ipaddress.error.no.mixed");
                    }
                    let totalSegmentCount : number = parseData.segmentCount + IPv6Address.MIXED_REPLACED_SEGMENT_COUNT;
                    if(totalSegmentCount > IPv6Address.SEGMENT_COUNT) {
                        throw new AddressStringException(str, "ipaddress.error.too.many.segments");
                    }
                    if(wildcardCount > 0) {
                        parseData.anyWildcard = true;
                    }
                    let isNotExpandable : boolean = wildcardCount > 0 && parseData.consecutiveSepIndex < 0;
                    if(isNotExpandable && totalSegmentCount < IPv6Address.SEGMENT_COUNT && ipv6SpecificOptions.allowWildcardedSeparator) {
                        parseData.values[segCount][AddressParseData.UPPER_INDEX] = IPv6Address.MAX_VALUE_PER_SEGMENT;
                        parseData.flags[segCount][AddressParseData.WILDCARD_INDEX] = true;
                        parseData.segmentCount++;
                    }
                    let mixedOptions : IPAddressStringParameters = ipv6SpecificOptions.getMixedParameters();
                    let mixedAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                    Validator.validateIPAddress(mixedOptions, str, lastSeparatorIndex + 1, strEndIndex, mixedAddressParseData, true);
                    mixedAddressParseData.clearQualifier();
                    ipAddressParseData.mixedParsedAddress = Validator.createIPAddressProvider(null, str, mixedOptions, mixedAddressParseData, ParsedHost.NO_QUALIFIER_$LI$());
                    index = mixedAddressParseData.addressParseData.addressEndIndex;
                } else {
                    let maxChars : number;
                    if(isMac) {
                        if(segCount === 0) {
                            if(!macOptions.allowDotted) {
                                throw new AddressStringException(str, "ipaddress.mac.error.format");
                            }
                            macAddressParseData.format = macFormat = MACAddressParseData.MACFormat.DOTTED;
                            parseData.initSegmentData(MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_64_SEGMENT_COUNT);
                        } else {
                            if(macFormat !== MACAddressParseData.MACFormat.DOTTED) {
                                throw new AddressStringException(str, "ipaddress.mac.error.mix.format.characters.at.index", index);
                            }
                            if(segCount >= ((macOptions.addressSize === MACAddressStringParameters.AddressSize.MAC)?MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_64_SEGMENT_COUNT)) {
                                throw new AddressStringException(str, "ipaddress.error.too.many.segments");
                            }
                        }
                        maxChars = 4;
                    } else {
                        if(extendedCharacterIndex >= 0) {
                            throw new AddressStringException(str, extendedCharacterIndex);
                        }
                        isBase85 = false;
                        if(!validationOptions.allowIPv4) {
                            throw new AddressStringException(str, "ipaddress.error.ipv4");
                        }
                        ipAddressParseData.ipVersion = IPAddress.IPVersion.IPV4;
                        stringFormatParams = ipv4SpecificOptions;
                        if(segCount === 0) {
                            parseData.initSegmentData(IPv4Address.SEGMENT_COUNT);
                        } else if(segCount >= IPv4Address.SEGMENT_COUNT) {
                            throw new AddressStringException(str, "ipaddress.error.ipv4.too.many.segments");
                        }
                        maxChars = Validator.getMaxIPv4StringLength(3, 8);
                    }
                    let vals : number[] = parseData.values[segCount];
                    let indices : number[] = parseData.indices[segCount];
                    let flags : boolean[] = parseData.flags[segCount];
                    if(wildcardCount > 0) {
                        if(!stringFormatParams.rangeOptions.allowsWildcard()) {
                            throw new AddressStringException(str, "ipaddress.error.no.wildcard");
                        }
                        if(singleWildcardCount > 0 || rangeWildcardIndex >= 0 || leadingZeroCount > 0 || digitCount > 0 || hexDelimiterIndex >= 0) {
                            throw new AddressStringException(str, index, true);
                        }
                        parseData.anyWildcard = true;
                        flags[AddressParseData.WILDCARD_INDEX] = true;
                        vals[AddressParseData.UPPER_INDEX] = isMac?MACAddress.MAX_VALUE_PER_DOTTED_SEGMENT:IPv4Address.MAX_VALUE_PER_SEGMENT;
                        let startIndex : number = index - wildcardCount;
                        Validator.assignAttributes$int$int$int_A$int(startIndex, index, indices, startIndex);
                    } else {
                        let value : number = 0;
                        let isStandard : boolean = false;
                        let radix : number;
                        let startIndex : number = index - digitCount;
                        let leadingZeroStartIndex : number = startIndex - leadingZeroCount;
                        let totalDigits : number = digitCount + leadingZeroCount;
                        let endIndex : number = index;
                        let isSingleWildcard : boolean;
                        let isJustZero : boolean;
                        if(digitCount === 0) {
                            let noLeadingZeros : boolean = leadingZeroCount === 0;
                            if(noLeadingZeros && rangeWildcardIndex >= 0 && hexDelimiterIndex < 0) {
                                if(isMac) {
                                    value = MACAddress.MAX_VALUE_PER_DOTTED_SEGMENT;
                                    radix = 16;
                                } else {
                                    value = IPv4Address.MAX_VALUE_PER_SEGMENT;
                                    radix = 10;
                                }
                                isJustZero = false;
                                isSingleWildcard = false;
                            } else if(noLeadingZeros) {
                                throw new AddressStringException(str, "ipaddress.error.empty.segment.at.index", index);
                            } else {
                                isSingleWildcard = false;
                                isJustZero = true;
                                startIndex--;
                                digitCount++;
                                leadingZeroCount--;
                                let illegalLeadingZeros : boolean = leadingZeroCount > 0 && !stringFormatParams.allowLeadingZeros;
                                if(hexDelimiterIndex >= 0) {
                                    if(isMac) {
                                        throw new AddressStringException(str, hexDelimiterIndex);
                                    }
                                    if(!ipv4SpecificOptions.inet_aton_hex) {
                                        throw new AddressStringException(str, "ipaddress.error.ipv4.segment.hex");
                                    }
                                    radix = 16;
                                } else if(isMac) {
                                    if(illegalLeadingZeros) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                    } else if(!stringFormatParams.allowUnlimitedLeadingZeros && totalDigits > maxChars) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", leadingZeroStartIndex);
                                    } else if(!macSpecificOptions.allowShortSegments && totalDigits < 2) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.short.at.index", leadingZeroStartIndex);
                                    }
                                    radix = 16;
                                } else if(leadingZeroCount > 0 && ipv4SpecificOptions.inet_aton_octal) {
                                    radix = 8;
                                } else {
                                    if(illegalLeadingZeros) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                    }
                                    radix = 10;
                                }
                                flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                Validator.assignAttributes$int$int$int_A$int$int(startIndex, endIndex, indices, radix, leadingZeroStartIndex);
                            }
                        } else {
                            if(digitCount > maxChars) {
                                throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", leadingZeroStartIndex);
                            }
                            isJustZero = false;
                            isSingleWildcard = singleWildcardCount > 0;
                            if(isMac || hexDelimiterIndex >= 0) {
                                if(isMac) {
                                    if(hexDelimiterIndex >= 0) {
                                        throw new AddressStringException(str, hexDelimiterIndex);
                                    } else if(leadingZeroCount > 0 && !stringFormatParams.allowLeadingZeros) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                    } else if(!stringFormatParams.allowUnlimitedLeadingZeros && totalDigits > maxChars) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", leadingZeroStartIndex);
                                    } else if(!macSpecificOptions.allowShortSegments && totalDigits < 2) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.short.at.index", leadingZeroStartIndex);
                                    }
                                } else if(!ipv4SpecificOptions.inet_aton_hex) {
                                    throw new AddressStringException(str, "ipaddress.error.ipv4.segment.hex");
                                }
                                radix = 16;
                                if(isSingleWildcard) {
                                    if(rangeWildcardIndex >= 0) {
                                        throw new AddressStringException(str, index, true);
                                    }
                                    Validator.parseSingleWildcard16(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, stringFormatParams);
                                } else {
                                    value = Validator.parseLong16(str, startIndex, endIndex);
                                }
                            } else {
                                let isOctal : boolean = leadingZeroCount > 0 && ipv4SpecificOptions.inet_aton_octal;
                                if(isOctal) {
                                    if(notOctal) {
                                        throw new AddressStringException(str, "ipaddress.error.ipv4.invalid.octal.digit");
                                    }
                                    radix = 8;
                                    if(isSingleWildcard) {
                                        if(rangeWildcardIndex >= 0) {
                                            throw new AddressStringException(str, index, true);
                                        }
                                        Validator.parseSingleWildcard8(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, stringFormatParams);
                                    } else {
                                        value = Validator.parseLong8(str, startIndex, endIndex);
                                    }
                                } else {
                                    if(notDecimal) {
                                        throw new AddressStringException(str, "ipaddress.error.ipv4.invalid.decimal.digit");
                                    }
                                    if(leadingZeroCount > 0 && !stringFormatParams.allowLeadingZeros) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                    }
                                    radix = 10;
                                    if(isSingleWildcard) {
                                        if(rangeWildcardIndex >= 0) {
                                            throw new AddressStringException(str, index, true);
                                        }
                                        Validator.parseSingleWildcard10(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, ipv4SpecificOptions);
                                    } else {
                                        value = Validator.parseLong10(str, startIndex, endIndex);
                                        isStandard = true;
                                    }
                                }
                            }
                        }
                        if(rangeWildcardIndex >= 0) {
                            let frontRadix : number;
                            let front : number;
                            let frontStartIndex : number = rangeWildcardIndex - frontDigitCount;
                            let frontEndIndex : number = rangeWildcardIndex;
                            let frontLeadingZeroStartIndex : number = frontStartIndex - frontLeadingZeroCount;
                            if(!stringFormatParams.rangeOptions.allowsRangeSeparator()) {
                                throw new AddressStringException(str, "ipaddress.error.no.range");
                            } else if(!stringFormatParams.allowLeadingZeros && frontLeadingZeroCount > 0) {
                                throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                            } else if(frontDigitCount > maxChars) {
                                throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", frontLeadingZeroStartIndex);
                            }
                            let frontEmpty : boolean = frontStartIndex === frontEndIndex;
                            if(isMac || frontHexDelimiterIndex >= 0) {
                                if(isMac) {
                                    if(frontHexDelimiterIndex >= 0) {
                                        throw new AddressStringException(str, frontHexDelimiterIndex);
                                    } else if(!macSpecificOptions.allowShortSegments && totalDigits < 2) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.short.at.index", frontLeadingZeroStartIndex);
                                    }
                                    if(!frontEmpty) {
                                        front = Validator.parseLong16(str, frontStartIndex, frontEndIndex);
                                    } else {
                                        front = 0;
                                    }
                                } else if(!ipv4SpecificOptions.inet_aton_hex) {
                                    throw new AddressStringException(str, "ipaddress.error.ipv4.segment.hex");
                                } else {
                                    if(!frontEmpty) {
                                        front = Validator.parseLong16(str, frontStartIndex, frontEndIndex);
                                    } else {
                                        front = 0;
                                    }
                                }
                                frontRadix = 16;
                            } else {
                                let frontIsOctal : boolean = frontLeadingZeroCount > 0 && frontHexDelimiterIndex < 0 && ipv4SpecificOptions.inet_aton_octal;
                                if(frontIsOctal) {
                                    if(frontNotOctal) {
                                        throw new AddressStringException(str, "ipaddress.error.ipv4.invalid.octal.digit");
                                    }
                                    front = Validator.parseLong8(str, frontStartIndex, frontEndIndex);
                                    frontRadix = 8;
                                } else {
                                    if(frontNotDecimal) {
                                        throw new AddressStringException(str, "ipaddress.error.ipv4.invalid.decimal.digit");
                                    }
                                    if(frontLeadingZeroCount === 0 && !frontEmpty) {
                                        flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                        if(isStandard && leadingZeroCount === 0) {
                                            flags[AddressParseData.STANDARD_RANGE_STR_INDEX] = true;
                                        }
                                    }
                                    if(!frontEmpty) {
                                        front = Validator.parseLong10(str, frontStartIndex, frontEndIndex);
                                    } else {
                                        front = 0;
                                    }
                                    frontRadix = 10;
                                }
                            }
                            if(front > value) {
                                throw new AddressStringException(str, "ipaddress.error.invalidRange");
                            }
                            if(!isJustZero) {
                                Validator.assignAttributes$int$int$int$int$int_A$int$int$int$int(frontStartIndex, frontEndIndex, startIndex, endIndex, indices, frontLeadingZeroStartIndex, leadingZeroStartIndex, frontRadix, radix);
                                vals[AddressParseData.LOWER_INDEX] = front;
                                vals[AddressParseData.UPPER_INDEX] = value;
                            }
                            frontDigitCount = frontLeadingZeroCount = frontWildcardCount = frontSingleWildcardCount = 0;
                            frontNotOctal = frontNotDecimal = frontUppercase = false;
                            frontHexDelimiterIndex = -1;
                        } else if(!isSingleWildcard && !isJustZero) {
                            if(isStandard) {
                                flags[AddressParseData.STANDARD_STR_INDEX] = true;
                            }
                            Validator.assignAttributes$int$int$int_A$int$int(startIndex, endIndex, indices, radix, leadingZeroStartIndex);
                            vals[AddressParseData.LOWER_INDEX] = vals[AddressParseData.UPPER_INDEX] = value;
                        }
                    }
                    parseData.segmentCount++;
                    lastSeparatorIndex = index;
                    digitCount = singleWildcardCount = wildcardCount = leadingZeroCount = 0;
                    hexDelimiterIndex = rangeWildcardIndex = -1;
                    notOctal = notDecimal = uppercase = false;
                    ++index;
                }
            } else {
                let isRangeChar : boolean;
                let isDashedRangeChar : boolean;
                let endOfSegment : boolean;
                let isSpace : boolean;
                let isZoneChar : boolean;
                isSpace = isRangeChar = isDashedRangeChar = isZoneChar = false;
                if((endOfSegment = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR))) || (isRangeChar = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.RANGE_SEPARATOR))) || (isMac && (isDashedRangeChar = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(MACAddress.DASHED_SEGMENT_RANGE_SEPARATOR))) || (endOfSegment = isSpace = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(MACAddress.SPACE_SEGMENT_SEPARATOR))))) {
                    if(!endOfSegment) {
                        if(isRangeChar || isDashedRangeChar) {
                            if(isMac) {
                                if(macFormat == null) {
                                    if(rangeWildcardIndex >= 0 && !firstSegmentDashedRange) {
                                        if(frontHexDelimiterIndex >= 0) {
                                            throw new AddressStringException(str, frontHexDelimiterIndex);
                                        }
                                        if(hexDelimiterIndex >= 0) {
                                            throw new AddressStringException(str, hexDelimiterIndex);
                                        }
                                        if(!macOptions.allowDashed) {
                                            throw new AddressStringException(str, "ipaddress.mac.error.format");
                                        }
                                        macAddressParseData.format = macFormat = MACAddressParseData.MACFormat.DASHED;
                                        countingCharsLater = true;
                                        parseData.initSegmentData(MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT);
                                        let vals : number[] = parseData.values[0];
                                        let flags : boolean[] = parseData.flags[0];
                                        let indices : number[] = parseData.indices[0];
                                        if(frontWildcardCount > 0) {
                                            if(!stringFormatParams.rangeOptions.allowsWildcard()) {
                                                throw new AddressStringException(str, "ipaddress.error.no.wildcard");
                                            }
                                            if(frontSingleWildcardCount > 0 || frontLeadingZeroCount > 0 || frontDigitCount > 0 || frontHexDelimiterIndex >= 0) {
                                                throw new AddressStringException(str, rangeWildcardIndex, true);
                                            }
                                            parseData.anyWildcard = true;
                                            flags[AddressParseData.WILDCARD_INDEX] = true;
                                            if(isDoubleSegment || digitCount + leadingZeroCount === Validator.MAC_DOUBLE_SEGMENT_DIGIT_COUNT) {
                                                vals[AddressParseData.UPPER_INDEX] = Validator.MAC_MAX_TRIPLE_$LI$();
                                            } else {
                                                vals[AddressParseData.UPPER_INDEX] = MACAddress.MAX_VALUE_PER_SEGMENT;
                                            }
                                            let startIndex : number = rangeWildcardIndex - frontWildcardCount;
                                            Validator.assignAttributes$int$int$int_A$int(startIndex, rangeWildcardIndex, indices, startIndex);
                                            frontWildcardCount = 0;
                                            rangeWildcardIndex = -1;
                                        } else {
                                            if(!stringFormatParams.allowLeadingZeros && frontLeadingZeroCount > 0) {
                                                throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                            }
                                            let value : number = 0;
                                            let startIndex : number = rangeWildcardIndex - frontDigitCount;
                                            let leadingZeroStartIndex : number = startIndex - frontLeadingZeroCount;
                                            let endIndex : number = rangeWildcardIndex;
                                            if(frontSingleWildcardCount > 0) {
                                                Validator.parseSingleWildcard16(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, stringFormatParams);
                                            } else {
                                                value = Validator.parseLong16(str, startIndex, endIndex);
                                                if(!uppercase) {
                                                    flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                                }
                                                Validator.assignAttributes$int$int$int_A$int$int(startIndex, endIndex, indices, MACAddress.DEFAULT_TEXTUAL_RADIX, leadingZeroStartIndex);
                                                vals[AddressParseData.LOWER_INDEX] = vals[AddressParseData.UPPER_INDEX] = value;
                                            }
                                            frontDigitCount = frontLeadingZeroCount = frontWildcardCount = frontSingleWildcardCount = 0;
                                            frontNotOctal = frontNotDecimal = frontUppercase = false;
                                            frontHexDelimiterIndex = rangeWildcardIndex = -1;
                                        }
                                        parseData.segmentCount++;
                                        endOfSegment = isRangeChar;
                                    } else {
                                        if(isDashedRangeChar) {
                                            firstSegmentDashedRange = true;
                                        } else {
                                            endOfSegment = firstSegmentDashedRange;
                                        }
                                    }
                                } else {
                                    if(macFormat === MACAddressParseData.MACFormat.DASHED) {
                                        endOfSegment = isRangeChar;
                                    } else {
                                        if(isDashedRangeChar) {
                                            throw new AddressStringException(str, index);
                                        }
                                    }
                                }
                            }
                        }
                        if(!endOfSegment) {
                            if(extendedCharacterIndex < 0) {
                                if(rangeWildcardIndex >= 0) {
                                    if(isBase85) {
                                        if(extendedCharacterIndex < 0) {
                                            extendedCharacterIndex = index;
                                        }
                                    } else {
                                        throw new AddressStringException(str, index, true);
                                    }
                                } else {
                                    rangeWildcardIndex = index;
                                    frontIsStandardRange = isRangeChar;
                                    frontDigitCount = digitCount;
                                    frontLeadingZeroCount = leadingZeroCount;
                                    if(frontDigitCount === 0) {
                                        if(frontLeadingZeroCount !== 0) {
                                            frontDigitCount++;
                                            frontLeadingZeroCount--;
                                        }
                                    }
                                    frontNotOctal = notOctal;
                                    frontNotDecimal = notDecimal;
                                    frontUppercase = uppercase;
                                    frontHexDelimiterIndex = hexDelimiterIndex;
                                    frontWildcardCount = wildcardCount;
                                    frontSingleWildcardCount = singleWildcardCount;
                                    leadingZeroCount = digitCount = 0;
                                    notOctal = notDecimal = uppercase = false;
                                    hexDelimiterIndex = -1;
                                    wildcardCount = singleWildcardCount = 0;
                                }
                            }
                            ++index;
                        }
                    }
                    if(endOfSegment) {
                        if(hexDelimiterIndex >= 0 && !isSingleSegment) {
                            throw new AddressStringException(str, hexDelimiterIndex);
                        }
                        let segCount : number = parseData.segmentCount;
                        let maxChars : number;
                        if(isMac) {
                            if(segCount === 0) {
                                if(isSingleSegment) {
                                    parseData.initSegmentData(1);
                                } else {
                                    if(!(isRangeChar?macOptions.allowDashed:(isSpace?macOptions.allowSpaceDelimited:macOptions.allowColonDelimited))) {
                                        throw new AddressStringException(str, "ipaddress.mac.error.format");
                                    }
                                    if(isRangeChar) {
                                        macAddressParseData.format = macFormat = MACAddressParseData.MACFormat.DASHED;
                                        countingCharsLater = true;
                                    } else {
                                        macAddressParseData.format = macFormat = (isSpace?MACAddressParseData.MACFormat.SPACE_DELIMITED:MACAddressParseData.MACFormat.COLON_DELIMITED);
                                    }
                                    parseData.initSegmentData(MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT);
                                }
                            } else {
                                if(isRangeChar?(macFormat !== MACAddressParseData.MACFormat.DASHED):(macFormat !== (isSpace?MACAddressParseData.MACFormat.SPACE_DELIMITED:MACAddressParseData.MACFormat.COLON_DELIMITED))) {
                                    throw new AddressStringException(str, "ipaddress.mac.error.mix.format.characters.at.index", index);
                                }
                                if(segCount >= ((macOptions.addressSize === MACAddressStringParameters.AddressSize.MAC)?MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT)) {
                                    throw new AddressStringException(str, "ipaddress.error.too.many.segments");
                                }
                            }
                            maxChars = MACAddressSegment.MAX_CHARS;
                        } else {
                            if(extendedCharacterIndex >= 0) {
                                throw new AddressStringException(str, extendedCharacterIndex);
                            }
                            isBase85 = false;
                            if(segCount === 0) {
                                parseData.initSegmentData(isSingleSegment?1:IPv6Address.SEGMENT_COUNT);
                            } else {
                                if(segCount >= IPv6Address.SEGMENT_COUNT) {
                                    throw new AddressStringException(str, "ipaddress.error.too.many.segments");
                                }
                                if(ipAddressParseData.ipVersion == null || IPAddress.IPVersion["_$wrappers"][ipAddressParseData.ipVersion].isIPv4()) {
                                    throw new AddressStringException(str, "ipaddress.error.ipv6.separator");
                                }
                            }
                            if(!validationOptions.allowIPv6) {
                                throw new AddressStringException(str, "ipaddress.error.ipv6");
                            }
                            ipAddressParseData.ipVersion = IPAddress.IPVersion.IPV6;
                            stringFormatParams = ipv6SpecificOptions;
                            maxChars = IPv6AddressSegment.MAX_CHARS;
                        }
                        let vals : number[] = parseData.values[segCount];
                        let flags : boolean[] = parseData.flags[segCount];
                        let indices : number[] = parseData.indices[segCount];
                        if(wildcardCount > 0) {
                            if(!stringFormatParams.rangeOptions.allowsWildcard()) {
                                throw new AddressStringException(str, "ipaddress.error.no.wildcard");
                            }
                            if(singleWildcardCount > 0 || rangeWildcardIndex >= 0 || leadingZeroCount > 0 || digitCount > 0) {
                                throw new AddressStringException(str, index, true);
                            }
                            parseData.anyWildcard = true;
                            flags[AddressParseData.WILDCARD_INDEX] = true;
                            vals[AddressParseData.UPPER_INDEX] = isMac?(isDoubleSegment?Validator.MAC_MAX_TRIPLE_$LI$():MACAddress.MAX_VALUE_PER_SEGMENT):IPv6Address.MAX_VALUE_PER_SEGMENT;
                            let startIndex : number = index - wildcardCount;
                            Validator.assignAttributes$int$int$int_A$int(startIndex, index, indices, startIndex);
                            parseData.segmentCount++;
                        } else {
                            if(index === strStartIndex) {
                                if(isMac) {
                                    throw new AddressStringException(str, "ipaddress.error.empty.segment.at.index", index);
                                }
                                if(index + 1 === strEndIndex) {
                                    throw new AddressStringException(str, "ipaddress.error.too.few.segments");
                                }
                                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(index + 1)) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR)) {
                                    throw new AddressStringException(str, "ipaddress.error.ipv6.cannot.start.with.single.separator");
                                }
                            } else if(index === lastSeparatorIndex + 1) {
                                if(isMac) {
                                    throw new AddressStringException(str, "ipaddress.error.empty.segment.at.index", index);
                                }
                                if(parseData.consecutiveSepIndex >= 0) {
                                    throw new AddressStringException(str, "ipaddress.error.ipv6.ambiguous");
                                }
                                parseData.consecutiveSepIndex = index - 1;
                                Validator.assignAttributes$int$int$int_A$int(index, index, indices, index);
                                parseData.segmentCount++;
                            } else {
                                if(!stringFormatParams.allowLeadingZeros && leadingZeroCount > 0) {
                                    throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                }
                                let value : number;
                                let extendedValue : number;
                                value = extendedValue = 0;
                                let isStandard : boolean = false;
                                let startIndex : number = index - digitCount;
                                let totalDigits : number = digitCount + leadingZeroCount;
                                let leadingZeroStartIndex : number = startIndex - leadingZeroCount;
                                let endIndex : number = index;
                                let checkCharCounts : boolean = !(countedCharacters || countingCharsLater);
                                if(checkCharCounts && !stringFormatParams.allowUnlimitedLeadingZeros && totalDigits > maxChars) {
                                    throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", leadingZeroStartIndex);
                                } else if(isMac && !macSpecificOptions.allowShortSegments && totalDigits < 2) {
                                    throw new AddressStringException(str, "ipaddress.error.segment.too.short.at.index", leadingZeroStartIndex);
                                }
                                let isJustZero : boolean;
                                if(digitCount === 0) {
                                    if(rangeWildcardIndex >= 0 && leadingZeroCount === 0) {
                                        value = isMac?MACAddress.MAX_VALUE_PER_SEGMENT:IPv6Address.MAX_VALUE_PER_SEGMENT;
                                        isJustZero = false;
                                    } else {
                                        startIndex--;
                                        digitCount++;
                                        leadingZeroCount--;
                                        isJustZero = true;
                                        flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                        Validator.assignAttributes$int$int$int_A$int(startIndex, endIndex, indices, leadingZeroStartIndex);
                                    }
                                } else if(checkCharCounts && digitCount > maxChars) {
                                    throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", leadingZeroStartIndex);
                                } else if(singleWildcardCount > 0) {
                                    if(rangeWildcardIndex >= 0) {
                                        throw new AddressStringException(str, index, true);
                                    }
                                    isJustZero = false;
                                    if(isSingleIPv6Hex) {
                                        Validator.parseSingleSegmentSingleWildcard16(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, stringFormatParams);
                                    } else {
                                        Validator.parseSingleWildcard16(str, startIndex, endIndex, singleWildcardCount, indices, vals, flags, leadingZeroStartIndex, stringFormatParams);
                                    }
                                } else {
                                    isJustZero = false;
                                    if(isSingleIPv6Hex) {
                                        let midIndex : number = endIndex - 16;
                                        if(startIndex < midIndex) {
                                            extendedValue = Validator.parseLong16(str, startIndex, midIndex);
                                            value = Validator.parseLong16(str, midIndex, endIndex);
                                        } else {
                                            value = Validator.parseLong16(str, startIndex, endIndex);
                                        }
                                    } else {
                                        value = Validator.parseLong16(str, startIndex, endIndex);
                                    }
                                    isStandard = !uppercase;
                                }
                                if(rangeWildcardIndex >= 0) {
                                    let frontStartIndex : number = rangeWildcardIndex - frontDigitCount;
                                    let frontEndIndex : number = rangeWildcardIndex;
                                    let frontLeadingZeroStartIndex : number = frontStartIndex - frontLeadingZeroCount;
                                    let frontTotalDigitCount : number = frontDigitCount + frontLeadingZeroCount;
                                    if(!stringFormatParams.rangeOptions.allowsRangeSeparator()) {
                                        throw new AddressStringException(str, "ipaddress.error.no.range");
                                    } else if(frontHexDelimiterIndex >= 0 && !isSingleSegment) {
                                        throw new AddressStringException(str, frontHexDelimiterIndex);
                                    } else if(!stringFormatParams.allowLeadingZeros && frontLeadingZeroCount > 0) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.leading.zeros");
                                    } else if(isMac && !macSpecificOptions.allowShortSegments && frontTotalDigitCount < 2) {
                                        throw new AddressStringException(str, "ipaddress.error.segment.too.short.at.index", frontLeadingZeroStartIndex);
                                    } else if(checkCharCounts) {
                                        if(frontDigitCount > maxChars) {
                                            throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", frontLeadingZeroStartIndex);
                                        } else if(!stringFormatParams.allowUnlimitedLeadingZeros && frontTotalDigitCount > maxChars) {
                                            throw new AddressStringException(str, "ipaddress.error.segment.too.long.at.index", frontLeadingZeroStartIndex);
                                        }
                                    }
                                    let front : number;
                                    let extendedFront : number;
                                    let frontEmpty : boolean;
                                    if(isSingleIPv6Hex) {
                                        frontEmpty = false;
                                        let frontMidIndex : number = frontEndIndex - 16;
                                        extendedFront = Validator.parseLong16(str, frontStartIndex, frontMidIndex);
                                        front = Validator.parseLong16(str, frontMidIndex, frontEndIndex);
                                    } else {
                                        frontEmpty = frontStartIndex === frontEndIndex;
                                        if(!frontEmpty) {
                                            front = Validator.parseLong16(str, frontStartIndex, frontEndIndex);
                                        } else {
                                            front = 0;
                                        }
                                        extendedFront = 0;
                                        if(front > value) {
                                            throw new AddressStringException(str, "ipaddress.error.invalidRange");
                                        }
                                    }
                                    if(!isJustZero) {
                                        if(!frontUppercase && frontLeadingZeroCount === 0 && !frontEmpty) {
                                            flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                            if(isStandard && leadingZeroCount === 0 && frontIsStandardRange) {
                                                flags[AddressParseData.STANDARD_RANGE_STR_INDEX] = true;
                                            }
                                        }
                                        Validator.assignAttributes$int$int$int$int$int_A$int$int$int$int(frontStartIndex, frontEndIndex, startIndex, endIndex, indices, frontLeadingZeroStartIndex, leadingZeroStartIndex, IPv6Address.DEFAULT_TEXTUAL_RADIX, IPv6Address.DEFAULT_TEXTUAL_RADIX);
                                        vals[AddressParseData.LOWER_INDEX] = front;
                                        vals[AddressParseData.UPPER_INDEX] = value;
                                        if(isSingleIPv6Hex) {
                                            vals[AddressParseData.EXTENDED_LOWER_INDEX] = extendedFront;
                                            vals[AddressParseData.EXTENDED_UPPER_INDEX] = extendedValue;
                                        }
                                    }
                                    frontDigitCount = frontLeadingZeroCount = frontWildcardCount = frontSingleWildcardCount = 0;
                                    frontNotOctal = frontNotDecimal = frontUppercase = false;
                                    frontHexDelimiterIndex = -1;
                                } else if(singleWildcardCount === 0 && !isJustZero) {
                                    if(isStandard) {
                                        flags[AddressParseData.STANDARD_STR_INDEX] = true;
                                    }
                                    Validator.assignAttributes$int$int$int_A$int$int(startIndex, endIndex, indices, IPv6Address.DEFAULT_TEXTUAL_RADIX, leadingZeroStartIndex);
                                    vals[AddressParseData.LOWER_INDEX] = vals[AddressParseData.UPPER_INDEX] = value;
                                    if(isSingleIPv6Hex) {
                                        vals[AddressParseData.EXTENDED_LOWER_INDEX] = vals[AddressParseData.EXTENDED_UPPER_INDEX] = extendedValue;
                                    }
                                }
                                parseData.segmentCount++;
                            }
                        }
                        lastSeparatorIndex = index;
                        hexDelimiterIndex = rangeWildcardIndex = -1;
                        digitCount = singleWildcardCount = wildcardCount = leadingZeroCount = 0;
                        notOctal = notDecimal = uppercase = false;
                        ++index;
                    }
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                    if(isMac) {
                        throw new AddressStringException(str, index);
                    }
                    strEndIndex = index;
                    ipAddressParseData.isPrefixed = true;
                    ipAddressParseData.qualifierIndex = index + 1;
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.SEGMENT_WILDCARD) || (isZoneChar = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.SEGMENT_SQL_WILDCARD)))) {
                    if(isZoneChar && !isMac && ipv6SpecificOptions.allowZone && ((parseData.segmentCount > 0 && (isEmbeddedIPv4 || ipAddressParseData.ipVersion === IPAddress.IPVersion.IPV6)) || (leadingZeroCount + digitCount === 32 && (rangeWildcardIndex < 0 || frontLeadingZeroCount + frontDigitCount === 32)) || wildcardCount === index)) {
                        if(extendedCharacterIndex >= 0) {
                            throw new AddressStringException(str, extendedCharacterIndex);
                        }
                        isBase85 = false;
                        strEndIndex = index;
                        ipAddressParseData.isZoned = true;
                        ipAddressParseData.qualifierIndex = index + 1;
                    } else {
                        ++wildcardCount;
                        ++index;
                    }
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.SEGMENT_SQL_SINGLE_WILDCARD)) {
                    ++digitCount;
                    ++index;
                    ++singleWildcardCount;
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == 'x'.charCodeAt(0)) {
                    if(digitCount > 0 || leadingZeroCount !== 1 || hexDelimiterIndex >= 0 || singleWildcardCount > 0) {
                        if(isBase85) {
                            if(extendedCharacterIndex < 0) {
                                extendedCharacterIndex = index;
                            }
                        } else {
                            throw new AddressStringException(str, index, true);
                        }
                    } else {
                        hexDelimiterIndex = index;
                        leadingZeroCount = 0;
                    }
                    ++index;
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddressLargeDivision.EXTENDED_DIGITS_RANGE_SEPARATOR_$LI$())) {
                    if(isBase85) {
                        if(extendedCharacterIndex < 0) {
                            extendedCharacterIndex = index;
                        }
                        let base85TotalDigits : number = index - strStartIndex;
                        if(base85TotalDigits === Validator.IPV6_BASE85_SINGLE_SEGMENT_DIGIT_COUNT) {
                            extendedRangeWildcardIndex = index;
                        } else {
                            throw new AddressStringException(str, extendedCharacterIndex);
                        }
                    } else {
                        throw new AddressStringException(str, index);
                    }
                    ++index;
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.ALTERNATIVE_ZONE_SEPARATOR)) {
                    if(isBase85 && !isMac && ipv6SpecificOptions.allowZone) {
                        strEndIndex = index;
                        ipAddressParseData.isZoned = ipAddressParseData.isBase85Zoned = true;
                        ipAddressParseData.qualifierIndex = index + 1;
                    } else {
                        throw new AddressStringException(str, index);
                    }
                } else {
                    if(isBase85) {
                        if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) < 0 || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) > Validator.extendedChars_$LI$().length - 1) {
                            throw new AddressStringException(str, index);
                        }
                        let val : number = Validator.extendedChars_$LI$()[(currentChar).charCodeAt(0)];
                        if(val === 0) {
                            throw new AddressStringException(str, index);
                        }
                        if(extendedCharacterIndex < 0) {
                            extendedCharacterIndex = index;
                        }
                    } else {
                        throw new AddressStringException(str, index);
                    }
                    ++index;
                }
            }
        };
    }

    /*private*/ static createProvider(originator : HostIdentifierString, fullAddr : any, validationOptions : IPAddressStringParameters, parseData : ParsedIPAddress.IPAddressParseData, qualifier : ParsedHostIdentifierStringQualifier) : IPAddressProvider {
        let version : IPAddress.IPVersion = parseData.ipVersion;
        if(version == null) {
            version = qualifier.inferVersion(validationOptions);
            let optionsVersion : IPAddress.IPVersion = validationOptions.inferVersion();
            if(version == null) {
                parseData.ipVersion = version = optionsVersion;
            } else if(optionsVersion != null && !/* Enum.equals */(<any>(version) === <any>(optionsVersion))) {
                throw new AddressStringException(fullAddr, version === IPAddress.IPVersion.IPV6?"ipaddress.error.ipv6":"ipaddress.error.ipv4");
            }
            if(parseData.addressParseData.isEmpty) {
                if(qualifier.getNetworkPrefixLength() != null) {
                    return new IPAddressProvider.MaskCreator(qualifier, version, validationOptions);
                } else {
                    if(validationOptions.emptyIsLoopback) {
                        return new IPAddressProvider.LoopbackCreator(validationOptions);
                    }
                    return IPAddressProvider.EMPTY_PROVIDER_$LI$();
                }
            } else {
                return new IPAddressProvider.AllCreator(qualifier, version, originator, validationOptions);
            }
        } else {
            if(parseData.isZoned && IPAddress.IPVersion["_$wrappers"][parseData.ipVersion].isIPv4()) {
                throw new AddressStringException(fullAddr, "ipaddress.error.only.ipv6.has.zone");
            }
            let valueCreator : ParsedIPAddress = Validator.createIPAddressProvider(originator, fullAddr, validationOptions, parseData, qualifier);
            return new IPAddressProvider.ParsedAddressProvider(valueCreator);
        }
    }

    /*private*/ static checkMaxValues(fullAddr : any, parseData : AddressParseData, segmentIndex : number, params : AddressStringParameters.AddressStringFormatParameters, maxValue : number, maxDigitCount : number, maxUpperDigitCount : number) {
        let flags : boolean[] = parseData.flags[segmentIndex];
        let values : number[] = parseData.values[segmentIndex];
        let indices : number[] = parseData.indices[segmentIndex];
        let lowerRadix : number = indices[AddressParseData.LOWER_RADIX_INDEX];
        if(flags[AddressParseData.SINGLE_WILDCARD_INDEX]) {
            if(values[AddressParseData.LOWER_INDEX] > maxValue) {
                throw new AddressStringException(fullAddr, "ipaddress.error.ipv4.segment.too.large");
            }
            if(values[AddressParseData.UPPER_INDEX] > maxValue) {
                values[AddressParseData.UPPER_INDEX] = maxValue;
            }
            if(!params.allowUnlimitedLeadingZeros) {
                if(indices[AddressParseData.LOWER_STR_END_INDEX] - indices[AddressParseData.LOWER_STR_DIGITS_INDEX] - Validator.getStringPrefixCharCount(lowerRadix) > maxDigitCount) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.segment.too.long");
                }
            }
        } else {
            if(values[AddressParseData.UPPER_INDEX] > maxValue) {
                throw new AddressStringException(fullAddr, "ipaddress.error.ipv4.segment.too.large");
            }
            let upperRadix : number = indices[AddressParseData.UPPER_RADIX_INDEX];
            if(!params.allowUnlimitedLeadingZeros) {
                if(indices[AddressParseData.LOWER_STR_END_INDEX] - indices[AddressParseData.LOWER_STR_DIGITS_INDEX] - Validator.getStringPrefixCharCount(lowerRadix) > maxDigitCount) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.segment.too.long");
                }
                if(indices[AddressParseData.UPPER_STR_END_INDEX] - indices[AddressParseData.UPPER_STR_DIGITS_INDEX] - Validator.getStringPrefixCharCount(upperRadix) > maxUpperDigitCount) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.segment.too.long");
                }
            }
        }
    }

    /*private*/ static createIPAddressProvider(originator : HostIdentifierString, fullAddr : any, validationOptions : IPAddressStringParameters, parseData : ParsedIPAddress.IPAddressParseData, qualifier : ParsedHostIdentifierStringQualifier) : ParsedIPAddress {
        let segCount : number = parseData.addressParseData.segmentCount;
        let version : IPAddress.IPVersion = parseData.ipVersion;
        if(IPAddress.IPVersion["_$wrappers"][version].isIPv4()) {
            let missingCount : number = IPv4Address.SEGMENT_COUNT - segCount;
            let ipv4Options : IPv4AddressStringParameters = validationOptions.getIPv4Parameters();
            let hasWildcardSeparator : boolean = parseData.addressParseData.anyWildcard && ipv4Options.allowWildcardedSeparator;
            if(missingCount > 0 && segCount > 1) {
                if(ipv4Options.inet_aton_joinedSegments) {
                    parseData.is_inet_aton_joined = true;
                } else if(!hasWildcardSeparator) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.ipv4.too.few.segments");
                }
            }
            let oneSegmentMax : number = Validator.getMaxIPv4Value(1);
            for(let i : number = 0; i < segCount; i++) {
                let max : number;
                let maxDigits : number;
                let maxUpperDigits : number;
                let indices : number[] = parseData.addressParseData.indices[i];
                let lowerRadix : number = indices[AddressParseData.LOWER_RADIX_INDEX];
                let upperRadix : number = indices[AddressParseData.UPPER_RADIX_INDEX];
                if(i === segCount - 1 && missingCount > 0 && ipv4Options.inet_aton_joinedSegments) {
                    max = Validator.getMaxIPv4Value(missingCount + 1);
                    maxDigits = Validator.getMaxIPv4StringLength(missingCount, lowerRadix);
                    maxUpperDigits = (upperRadix !== lowerRadix)?Validator.getMaxIPv4StringLength(missingCount, upperRadix):maxDigits;
                } else {
                    max = oneSegmentMax;
                    maxDigits = Validator.getMaxIPv4StringLength(0, lowerRadix);
                    maxUpperDigits = (upperRadix !== lowerRadix)?Validator.getMaxIPv4StringLength(0, upperRadix):maxDigits;
                }
                Validator.checkMaxValues(fullAddr, parseData.addressParseData, i, ipv4Options, max, maxDigits, maxUpperDigits);
            };
        } else {
            let totalSegmentCount : number = segCount;
            if(parseData.mixedParsedAddress != null) {
                totalSegmentCount += IPv6Address.MIXED_REPLACED_SEGMENT_COUNT;
            }
            let hasWildcardSeparator : boolean = parseData.addressParseData.anyWildcard && validationOptions.getIPv6Parameters().allowWildcardedSeparator;
            if(!hasWildcardSeparator && totalSegmentCount !== 1 && totalSegmentCount < IPv6Address.SEGMENT_COUNT && !parseData.isCompressed()) {
                throw new AddressStringException(fullAddr, "ipaddress.error.too.few.segments");
            }
        }
        let valueCreator : ParsedIPAddress = new ParsedIPAddress(originator, fullAddr, validationOptions, parseData, version, qualifier);
        return valueCreator;
    }

    /**
     * 
     * @param {*} fullAddr
     * @param {IPAddress.IPVersion} version
     * @return {number}
     */
    public validatePrefix(fullAddr : any, version : IPAddress.IPVersion) : number {
        return Validator.validatePrefixImpl(fullAddr, version);
    }

    static validatePrefixImpl(fullAddr : any, version : IPAddress.IPVersion) : number {
        let qualifier : ParsedHostIdentifierStringQualifier = Validator.validatePrefix(fullAddr, null, Validator.DEFAULT_PREFIX_OPTIONS_$LI$(), null, 0, fullAddr.length, version);
        if(qualifier == null) {
            throw new AddressStringException(fullAddr.toString(), "ipaddress.error.invalidCIDRPrefix");
        }
        return qualifier.getNetworkPrefixLength();
    }

    /*private*/ static parsePortOrService(fullAddr : any, zone : any, validationOptions : HostNameParameters, index : number, endIndex : number) : ParsedHostIdentifierStringQualifier {
        let isPort : boolean = true;
        let hasLetter : boolean = false;
        let digitCount : number = 0;
        let charCount : number = 0;
        let lastHyphen : number = -1;
        let isAll : boolean = false;
        for(let i : number = index; i < endIndex; i++) {
            let c : string = fullAddr.charAt(i);
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= '1'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= '9'.charCodeAt(0)) {
                ++digitCount;
                ++charCount;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '0'.charCodeAt(0)) {
                if(digitCount > 0) {
                    ++digitCount;
                }
                ++charCount;
            } else {
                isPort = false;
                let isHyphen : boolean = false;
                if(((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'Z'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'z'.charCodeAt(0)) || (isHyphen = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '-'.charCodeAt(0))) || (isAll = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.SEGMENT_WILDCARD)))) {
                    if(isHyphen) {
                        if(i === index) {
                            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalid.service.hyphen.start");
                        } else if(i - 1 === lastHyphen) {
                            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalid.service.hyphen.consecutive");
                        } else if(i === endIndex - 1) {
                            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalid.service.hyphen.end");
                        }
                        lastHyphen = i;
                    } else if(isAll) {
                        if(i > index) {
                            throw new AddressStringException(fullAddr.toString(), i, true);
                        } else if(i + 1 < endIndex) {
                            throw new AddressStringException(fullAddr.toString(), i + 1, true);
                        }
                        hasLetter = true;
                        ++charCount;
                        break;
                    } else {
                        hasLetter = true;
                    }
                    ++charCount;
                } else {
                    throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalid.port.service", i);
                }
            }
        };
        if(isPort) {
            if(!validationOptions.allowPort) {
                throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.port");
            } else if(digitCount === 0) {
                throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidPort.no.digits");
            } else if(digitCount > 5) {
                throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidPort.too.large");
            }
            let result : number = Validator.parse10(fullAddr, index, endIndex);
            if(result > 65535) {
                throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidPort.too.large");
            }
            return new ParsedHostIdentifierStringQualifier(zone, result);
        } else if(!validationOptions.allowService) {
            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.service");
        } else if(charCount === 0) {
            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidService.no.chars");
        } else if(charCount > 15) {
            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidService.too.long");
        } else if(!hasLetter) {
            throw new AddressStringException(fullAddr.toString(), "ipaddress.host.error.invalidService.no.letter");
        }
        let service : any = /* subSequence */fullAddr.substring(index, endIndex);
        return new ParsedHostIdentifierStringQualifier(zone, service);
    }

    /*private*/ static parseValidatedPrefix(fullAddr : any, zone : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, index : number, endIndex : number, digitCount : number, leadingZeros : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        let asIPv4 : boolean = (ipVersion != null && IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv4());
        if(digitCount === 0) {
            leadingZeros--;
            digitCount++;
        }
        if(leadingZeros > 0) {
            if(asIPv4) {
                if(!validationOptions.getIPv4Parameters().allowPrefixLengthLeadingZeros) {
                    throw new AddressStringException(fullAddr.toString(), "ipaddress.error.ipv4.prefix.leading.zeros");
                }
            } else {
                if(!validationOptions.getIPv6Parameters().allowPrefixLengthLeadingZeros) {
                    throw new AddressStringException(fullAddr.toString(), "ipaddress.error.ipv6.prefix.leading.zeros");
                }
            }
        }
        let allowPrefixesBeyondAddressSize : boolean = (asIPv4?validationOptions.getIPv4Parameters():validationOptions.getIPv6Parameters()).allowPrefixesBeyondAddressSize;
        if(!allowPrefixesBeyondAddressSize && digitCount > (asIPv4?2:3)) {
            if(asIPv4 && validationOptions.allowSingleSegment) {
                return null;
            }
            throw new AddressStringException(fullAddr.toString(), "ipaddress.error.prefixSize");
        }
        let result : number = Validator.parse10(fullAddr, index, endIndex);
        if(!allowPrefixesBeyondAddressSize && result > (asIPv4?IPv4Address.BIT_COUNT:IPv6Address.BIT_COUNT)) {
            if(asIPv4 && validationOptions.allowSingleSegment) {
                return null;
            }
            throw new AddressStringException(fullAddr.toString(), "ipaddress.error.prefixSize");
        }
        if(zone == null && result < Validator.PREFIX_CACHE_$LI$().length) {
            let qual : ParsedHostIdentifierStringQualifier = Validator.PREFIX_CACHE_$LI$()[result];
            if(qual == null) {
                qual = Validator.PREFIX_CACHE_$LI$()[result] = new ParsedHostIdentifierStringQualifier(result, null);
            }
            return qual;
        }
        return new ParsedHostIdentifierStringQualifier(result, zone);
    }

    /*private*/ static validatePrefix(fullAddr : any, zone : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, index : number, endIndex : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        if(index === fullAddr.length) {
            return null;
        }
        let isPrefix : boolean = true;
        let prefixEndIndex : number = endIndex;
        let digitCount : number;
        let leadingZeros : number;
        digitCount = leadingZeros = 0;
        let portQualifier : ParsedHostIdentifierStringQualifier = null;
        for(let i : number = index; i < endIndex; i++) {
            let c : string = fullAddr.charAt(i);
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= '1'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= '9'.charCodeAt(0)) {
                ++digitCount;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '0'.charCodeAt(0)) {
                if(digitCount > 0) {
                    ++digitCount;
                } else {
                    ++leadingZeros;
                }
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.PORT_SEPARATOR) && hostValidationOptions != null && (hostValidationOptions.allowPort || hostValidationOptions.allowService) && i > index) {
                try {
                    portQualifier = Validator.parsePortOrService(fullAddr, zone, hostValidationOptions, i + 1, endIndex);
                    prefixEndIndex = i;
                    break;
                } catch(e) {
                    return null;
                };
            } else {
                isPrefix = false;
                break;
            }
        };
        if(isPrefix) {
            let prefixQualifier : ParsedHostIdentifierStringQualifier = Validator.parseValidatedPrefix(fullAddr, zone, validationOptions, hostValidationOptions, index, prefixEndIndex, digitCount, leadingZeros, ipVersion);
            if(portQualifier != null) {
                portQualifier.mergePrefix(prefixQualifier);
                return portQualifier;
            }
            return prefixQualifier;
        }
        return null;
    }

    /*private*/ static parseAddressQualifier(fullAddr : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, ipAddressParseData : ParsedIPAddress.IPAddressParseData, endIndex : number) : ParsedHostIdentifierStringQualifier {
        let index : number = ipAddressParseData.qualifierIndex;
        let addressIsEmpty : boolean = ipAddressParseData.addressParseData.isEmpty;
        let ipVersion : IPAddress.IPVersion = ipAddressParseData.ipVersion;
        if(ipAddressParseData.isPrefixed) {
            return Validator.parsePrefix(fullAddr, null, validationOptions, hostValidationOptions, addressIsEmpty, index, endIndex, ipVersion);
        } else if(ipAddressParseData.isZoned) {
            if(ipAddressParseData.isBase85Zoned && !ipAddressParseData.isBase85) {
                throw new AddressStringException(fullAddr, ipAddressParseData.qualifierIndex - 1);
            }
            if(addressIsEmpty) {
                throw new AddressStringException(fullAddr, "ipaddress.error.only.zone");
            }
            return Validator.parseZone(fullAddr, validationOptions, addressIsEmpty, index, endIndex, ipVersion);
        }
        return ParsedHost.NO_QUALIFIER_$LI$();
    }

    /*private*/ static parseHostAddressQualifier(fullAddr : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, isPrefixed : boolean, hasPort : boolean, ipAddressParseData : ParsedIPAddress.IPAddressParseData, qualifierIndex : number, endIndex : number) : ParsedHostIdentifierStringQualifier {
        let addressIsEmpty : boolean = ipAddressParseData.addressParseData.isEmpty;
        let ipVersion : IPAddress.IPVersion = ipAddressParseData.ipVersion;
        if(isPrefixed) {
            return Validator.parsePrefix(fullAddr, null, validationOptions, hostValidationOptions, addressIsEmpty, qualifierIndex, endIndex, ipVersion);
        } else if(ipAddressParseData.isZoned) {
            if(addressIsEmpty) {
                throw new AddressStringException(fullAddr, "ipaddress.error.only.zone");
            }
            return Validator.parseEncodedZone(fullAddr, validationOptions, addressIsEmpty, qualifierIndex, endIndex, ipVersion);
        } else if(hasPort) {
            return Validator.parsePortOrService(fullAddr, null, hostValidationOptions, qualifierIndex, endIndex);
        }
        return ParsedHost.NO_QUALIFIER_$LI$();
    }

    /*private*/ static parsePrefix(fullAddr : any, zone : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, addressIsEmpty : boolean, index : number, endIndex : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        if(validationOptions.allowPrefix) {
            let qualifier : ParsedHostIdentifierStringQualifier = Validator.validatePrefix(fullAddr, zone, validationOptions, hostValidationOptions, index, endIndex, ipVersion);
            if(qualifier != null) {
                return qualifier;
            }
        }
        if(addressIsEmpty) {
            throw new AddressStringException(fullAddr, "ipaddress.error.invalid.mask.address.empty");
        } else if(validationOptions.allowMask) {
            try {
                let maskOptions : IPAddressStringParameters = Validator.toMaskOptions(validationOptions, ipVersion);
                let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(fullAddr);
                Validator.validateIPAddress(maskOptions, fullAddr, index, endIndex, ipAddressParseData);
                let maskParseData : AddressParseData = ipAddressParseData.addressParseData;
                if(maskParseData.isEmpty) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.invalid.mask.empty");
                } else if(maskParseData.isAll) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.invalid.mask.wildcard");
                }
                let maskAddress : ParsedIPAddress = Validator.createIPAddressProvider(null, fullAddr, maskOptions, ipAddressParseData, ParsedHost.NO_QUALIFIER_$LI$());
                if(maskParseData.addressEndIndex !== endIndex) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.invalid.mask.extra.chars", maskParseData.addressEndIndex + 1);
                }
                let maskVersion : IPAddress.IPVersion = ipAddressParseData.ipVersion;
                if(IPAddress.IPVersion["_$wrappers"][maskVersion].isIPv4() && maskParseData.segmentCount === 1 && !maskParseData.anyWildcard && !validationOptions.getIPv4Parameters().inet_aton_single_segment_mask) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.mask.single.segment");
                } else if(ipVersion != null && (IPAddress.IPVersion["_$wrappers"][maskVersion].isIPv4() !== IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv4() || IPAddress.IPVersion["_$wrappers"][maskVersion].isIPv6() !== IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv6())) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.ipMismatch");
                }
                return new ParsedHostIdentifierStringQualifier(maskAddress, zone);
            } catch(e) {
                throw new AddressStringException(fullAddr, "ipaddress.error.invalidCIDRPrefixOrMask", e);
            };
        }
        throw new AddressStringException(fullAddr, validationOptions.allowPrefix?"ipaddress.error.invalidCIDRPrefixOrMask":"ipaddress.error.CIDRNotAllowed");
    }

    /*private*/ static parseHostNameQualifier(fullAddr : any, validationOptions : IPAddressStringParameters, hostValidationOptions : HostNameParameters, isPrefixed : boolean, isPort : boolean, addressIsEmpty : boolean, index : number, endIndex : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        if(isPrefixed) {
            return Validator.parsePrefix(fullAddr, null, validationOptions, hostValidationOptions, addressIsEmpty, index, endIndex, ipVersion);
        } else if(isPort) {
            return Validator.parsePortOrService(fullAddr, null, hostValidationOptions, index, endIndex);
        }
        return ParsedHost.NO_QUALIFIER_$LI$();
    }

    /**
     * Returns the index of the first invalid character of the zone, or -1 if the zone is valid
     * 
     * @param sequence
     * @return
     * @param {*} zone
     * @return {number}
     */
    public static validateZone(zone : any) : number {
        for(let i : number = 0; i < zone.length; i++) {
            let c : string = zone.charAt(i);
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                return i;
            }
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR)) {
                return i;
            }
        };
        return -1;
    }

    public static isReserved(c : string) : boolean {
        let isUnreserved : boolean = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= '0'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= '9'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'Z'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'z'.charCodeAt(0)) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.RANGE_SEPARATOR) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.LABEL_SEPARATOR) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '_'.charCodeAt(0) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '~'.charCodeAt(0);
        return !isUnreserved;
    }

    /*private*/ static parseZone(fullAddr : any, validationOptions : IPAddressStringParameters, addressIsEmpty : boolean, index : number, endIndex : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        for(let i : number = index; i < endIndex; i++) {
            let c : string = fullAddr.charAt(i);
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                let zone : any = /* subSequence */fullAddr.substring(index, i);
                return Validator.parsePrefix(fullAddr, zone, validationOptions, null, addressIsEmpty, i + 1, endIndex, ipVersion);
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR)) {
                throw new AddressStringException(fullAddr, "ipaddress.error.invalid.zone", i);
            }
        };
        return new ParsedHostIdentifierStringQualifier(/* subSequence */fullAddr.substring(index, endIndex));
    }

    /*private*/ static parseEncodedZone(fullAddr : any, validationOptions : IPAddressStringParameters, addressIsEmpty : boolean, index : number, endIndex : number, ipVersion : IPAddress.IPVersion) : ParsedHostIdentifierStringQualifier {
        let result : { str: string } = null;
        for(let i : number = index; i < endIndex; i++) {
            let c : string = fullAddr.charAt(i);
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.ZONE_SEPARATOR)) {
                if(i + 2 >= endIndex) {
                    throw new AddressStringException(fullAddr, "ipaddress.error.invalid.zone.encoding", i);
                }
                if(result == null) {
                    result = { str: "", toString: function() { return this.str; } };
                    /* append */(sb => { sb.str = sb.str.concat((<any>fullAddr).substr(index, i)); return sb; })(result);
                }
                let charArray : number[] = Validator.chars_$LI$();
                c = String.fromCharCode((charArray[(fullAddr.charAt(++i)).charCodeAt(0)] << 4));
                c = String.fromCharCode((c).charCodeAt(0) | charArray[(fullAddr.charAt(++i)).charCodeAt(0)]);
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                let zone : any = result != null?result:/* subSequence */fullAddr.substring(index, i);
                return Validator.parsePrefix(fullAddr, zone, validationOptions, null, addressIsEmpty, i + 1, endIndex, ipVersion);
            } else if(Validator.isReserved(c)) {
                throw new AddressStringException(fullAddr, "ipaddress.error.invalid.zone", i);
            }
            if(result != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>c); return sb; })(result);
            }
        };
        if(result == null) {
            return new ParsedHostIdentifierStringQualifier(/* subSequence */fullAddr.substring(index, endIndex));
        }
        return new ParsedHostIdentifierStringQualifier(result);
    }

    /**
     * Some options are not supported in masks (prefix, wildcards, etc)
     * So we eliminate those options while preserving the others from the address options.
     * @param {IPAddressStringParameters} validationOptions
     * @param {IPAddress.IPVersion} ipVersion
     * @return
     * @return {IPAddressStringParameters}
     * @private
     */
    /*private*/ static toMaskOptions(validationOptions : IPAddressStringParameters, ipVersion : IPAddress.IPVersion) : IPAddressStringParameters {
        let builder : IPAddressStringParameters.Builder = null;
        if(ipVersion == null || IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv6()) {
            let ipv6Options : IPv6AddressStringParameters = validationOptions.getIPv6Parameters();
            if(!ipv6Options.rangeOptions.isNoRange()) {
                builder = validationOptions.toBuilder();
                builder.getIPv6AddressParametersBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
            }
            if(ipv6Options.allowMixed && !ipv6Options.getMixedParameters().getIPv4Parameters().rangeOptions.isNoRange()) {
                if(builder == null) {
                    builder = validationOptions.toBuilder();
                }
                builder.getIPv6AddressParametersBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
            }
        }
        if(ipVersion == null || IPAddress.IPVersion["_$wrappers"][ipVersion].isIPv4()) {
            let ipv4Options : IPv4AddressStringParameters = validationOptions.getIPv4Parameters();
            if(!ipv4Options.rangeOptions.isNoRange()) {
                if(builder == null) {
                    builder = validationOptions.toBuilder();
                }
                builder.getIPv4AddressParametersBuilder().setRangeOptions(AddressStringParameters.RangeParameters.NO_RANGE_$LI$());
            }
        }
        if(validationOptions.allowAll) {
            if(builder == null) {
                builder = validationOptions.toBuilder();
            }
            builder.allowAll(false);
        }
        let maskOptions : IPAddressStringParameters = (builder == null)?validationOptions:builder.toParams();
        return maskOptions;
    }

    /*private*/ static assignAttributes$int$int$int$int$int_A$int$int(frontStart : number, frontEnd : number, start : number, end : number, indices : number[], frontLeadingZeroStartIndex : number, leadingZeroStartIndex : number) {
        indices[AddressParseData.LOWER_STR_DIGITS_INDEX] = frontLeadingZeroStartIndex;
        indices[AddressParseData.LOWER_STR_START_INDEX] = frontStart;
        indices[AddressParseData.LOWER_STR_END_INDEX] = frontEnd;
        indices[AddressParseData.UPPER_STR_DIGITS_INDEX] = leadingZeroStartIndex;
        indices[AddressParseData.UPPER_STR_START_INDEX] = start;
        indices[AddressParseData.UPPER_STR_END_INDEX] = end;
    }

    public static assignAttributes$int$int$int$int$int_A$int$int$int$int(frontStart : number, frontEnd : number, start : number, end : number, indices : number[], frontLeadingZeroStartIndex : number, leadingZeroStartIndex : number, frontRadix : number, radix : number) {
        indices[AddressParseData.LOWER_RADIX_INDEX] = frontRadix;
        indices[AddressParseData.UPPER_RADIX_INDEX] = radix;
        Validator.assignAttributes$int$int$int$int$int_A$int$int(frontStart, frontEnd, start, end, indices, frontLeadingZeroStartIndex, leadingZeroStartIndex);
    }

    public static assignAttributes(frontStart? : any, frontEnd? : any, start? : any, end? : any, indices? : any, frontLeadingZeroStartIndex? : any, leadingZeroStartIndex? : any, frontRadix? : any, radix? : any) : any {
        if(((typeof frontStart === 'number') || frontStart === null) && ((typeof frontEnd === 'number') || frontEnd === null) && ((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((indices != null && indices instanceof <any>Array && (indices.length==0 || indices[0] == null ||(typeof indices[0] === 'number'))) || indices === null) && ((typeof frontLeadingZeroStartIndex === 'number') || frontLeadingZeroStartIndex === null) && ((typeof leadingZeroStartIndex === 'number') || leadingZeroStartIndex === null) && ((typeof frontRadix === 'number') || frontRadix === null) && ((typeof radix === 'number') || radix === null)) {
            return <any>Validator.assignAttributes$int$int$int$int$int_A$int$int$int$int(frontStart, frontEnd, start, end, indices, frontLeadingZeroStartIndex, leadingZeroStartIndex, frontRadix, radix);
        } else if(((typeof frontStart === 'number') || frontStart === null) && ((typeof frontEnd === 'number') || frontEnd === null) && ((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((indices != null && indices instanceof <any>Array && (indices.length==0 || indices[0] == null ||(typeof indices[0] === 'number'))) || indices === null) && ((typeof frontLeadingZeroStartIndex === 'number') || frontLeadingZeroStartIndex === null) && ((typeof leadingZeroStartIndex === 'number') || leadingZeroStartIndex === null) && frontRadix === undefined && radix === undefined) {
            return <any>Validator.assignAttributes$int$int$int$int$int_A$int$int(frontStart, frontEnd, start, end, indices, frontLeadingZeroStartIndex, leadingZeroStartIndex);
        } else if(((typeof frontStart === 'number') || frontStart === null) && ((typeof frontEnd === 'number') || frontEnd === null) && ((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(typeof start[0] === 'number'))) || start === null) && ((typeof end === 'number') || end === null) && ((typeof indices === 'number') || indices === null) && frontLeadingZeroStartIndex === undefined && leadingZeroStartIndex === undefined && frontRadix === undefined && radix === undefined) {
            return <any>Validator.assignAttributes$int$int$int_A$int$int(frontStart, frontEnd, start, end, indices);
        } else if(((typeof frontStart === 'number') || frontStart === null) && ((typeof frontEnd === 'number') || frontEnd === null) && ((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(typeof start[0] === 'number'))) || start === null) && ((typeof end === 'number') || end === null) && indices === undefined && frontLeadingZeroStartIndex === undefined && leadingZeroStartIndex === undefined && frontRadix === undefined && radix === undefined) {
            return <any>Validator.assignAttributes$int$int$int_A$int(frontStart, frontEnd, start, end);
        } else throw new Error('invalid overload');
    }

    /*private*/ static assignAttributes$int$int$int_A$int(start : number, end : number, indices : number[], leadingZeroStartIndex : number) {
        indices[AddressParseData.UPPER_STR_DIGITS_INDEX] = indices[AddressParseData.LOWER_STR_DIGITS_INDEX] = leadingZeroStartIndex;
        indices[AddressParseData.UPPER_STR_START_INDEX] = indices[AddressParseData.LOWER_STR_START_INDEX] = start;
        indices[AddressParseData.UPPER_STR_END_INDEX] = indices[AddressParseData.LOWER_STR_END_INDEX] = end;
    }

    /*private*/ static assignAttributes$int$int$int_A$int$int(start : number, end : number, indices : number[], radix : number, leadingZeroStartIndex : number) {
        indices[AddressParseData.UPPER_RADIX_INDEX] = indices[AddressParseData.LOWER_RADIX_INDEX] = radix;
        Validator.assignAttributes$int$int$int_A$int(start, end, indices, leadingZeroStartIndex);
    }

    /*private*/ static assignSingleWildcardAttributes(str : any, start : number, end : number, digitsEnd : number, numSingleWildcards : number, indices : number[], flags : boolean[], radix : number, leadingZeroStartIndex : number, options : AddressStringParameters.AddressStringFormatParameters) {
        if(!options.rangeOptions.allowsSingleWildcard()) {
            throw new AddressStringException(str, "ipaddress.error.no.single.wildcard");
        }
        for(let k : number = digitsEnd; k < end; k++) {
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(k)) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.SEGMENT_SQL_SINGLE_WILDCARD)) {
                throw new AddressStringException(str, "ipaddress.error.single.wildcard.order");
            }
        };
        flags[AddressParseData.SINGLE_WILDCARD_INDEX] = true;
        Validator.assignAttributes$int$int$int_A$int$int(start, end, indices, radix, leadingZeroStartIndex);
    }

    /*private*/ static parseSingleWildcard10(s : any, start : number, end : number, numSingleWildcards : number, indices : number[], vals : number[], flags : boolean[], leadingZeroStartIndex : number, options : AddressStringParameters.AddressStringFormatParameters) {
        let digitsEnd : number = end - numSingleWildcards;
        Validator.assignSingleWildcardAttributes(s, start, end, digitsEnd, numSingleWildcards, indices, flags, 10, leadingZeroStartIndex, options);
        let lower : number;
        if(start < digitsEnd) {
            lower = Validator.parseLong10(s, start, digitsEnd);
        } else {
            lower = 0;
        }
        let upper : number;
        switch((numSingleWildcards)) {
        case 1:
            lower *= 10;
            upper = lower + 9;
            break;
        case 2:
            lower *= 100;
            upper = lower + 99;
            break;
        case 3:
            lower *= 1000;
            upper = lower + 999;
            break;
        default:
            let power : number = (n => n<0?Math.ceil(n):Math.floor(n))(<number>Math.pow(10, numSingleWildcards));
            lower *= power;
            upper = lower + power - 1;
        }
        vals[AddressParseData.LOWER_INDEX] = lower;
        vals[AddressParseData.UPPER_INDEX] = upper;
    }

    /*private*/ static parseSingleWildcard8(s : any, start : number, end : number, numSingleWildcards : number, indices : number[], vals : number[], flags : boolean[], leadingZeroStartIndex : number, options : AddressStringParameters.AddressStringFormatParameters) {
        let digitsEnd : number = end - numSingleWildcards;
        Validator.assignSingleWildcardAttributes(s, start, end, digitsEnd, numSingleWildcards, indices, flags, 8, leadingZeroStartIndex, options);
        let lower : number = (start < digitsEnd)?Validator.parseLong8(s, start, digitsEnd):0;
        let upper : number;
        switch((numSingleWildcards)) {
        case 1:
            lower <<= 3;
            upper = lower | 7;
            break;
        case 2:
            lower <<= 6;
            upper = lower | 63;
            break;
        case 3:
            lower <<= 9;
            upper = lower | 511;
            break;
        default:
            let shift : number = numSingleWildcards * 3;
            lower <<= shift;
            upper = lower | ~(~0 << shift);
            break;
        }
        vals[AddressParseData.LOWER_INDEX] = lower;
        vals[AddressParseData.UPPER_INDEX] = upper;
    }

    /*private*/ static parseSingleWildcard16(s : any, start : number, end : number, numSingleWildcards : number, indices : number[], vals : number[], flags : boolean[], leadingZeroStartIndex : number, options : AddressStringParameters.AddressStringFormatParameters) {
        let digitsEnd : number = end - numSingleWildcards;
        Validator.assignSingleWildcardAttributes(s, start, end, digitsEnd, numSingleWildcards, indices, flags, 16, leadingZeroStartIndex, options);
        let lower : number = (start < digitsEnd)?Validator.parseLong16(s, start, digitsEnd):0;
        let shift : number = numSingleWildcards << 2;
        lower <<= shift;
        let upper : number = lower | ~(~0 << shift);
        vals[AddressParseData.LOWER_INDEX] = lower;
        vals[AddressParseData.UPPER_INDEX] = upper;
    }

    /*private*/ static parseSingleSegmentSingleWildcard16(s : any, start : number, end : number, numSingleWildcards : number, indices : number[], vals : number[], flags : boolean[], leadingZeroStartIndex : number, options : AddressStringParameters.AddressStringFormatParameters) {
        let digitsEnd : number = end - numSingleWildcards;
        Validator.assignSingleWildcardAttributes(s, start, end, digitsEnd, numSingleWildcards, indices, flags, 16, leadingZeroStartIndex, options);
        let upper : number;
        let lower : number;
        let extendedLower : number;
        let extendedUpper : number;
        if(numSingleWildcards < Validator.LONG_HEX_DIGITS_$LI$()) {
            let midIndex : number = end - Validator.LONG_HEX_DIGITS_$LI$();
            lower = Validator.parseLong16(s, midIndex, digitsEnd);
            let shift : number = numSingleWildcards << 2;
            lower <<= shift;
            upper = lower | ~(~0 << shift);
            extendedUpper = extendedLower = Validator.parseLong16(s, start, midIndex);
        } else if(numSingleWildcards === Validator.LONG_HEX_DIGITS_$LI$()) {
            lower = 0;
            upper = -1;
            extendedUpper = extendedLower = Validator.parseLong16(s, start, digitsEnd);
        } else {
            lower = 0;
            upper = -1;
            extendedLower = Validator.parseLong16(s, start, digitsEnd);
            let shift : number = (numSingleWildcards - Validator.LONG_HEX_DIGITS_$LI$()) << 2;
            extendedLower <<= shift;
            extendedUpper = extendedLower | ~(~0 << shift);
        }
        vals[AddressParseData.LOWER_INDEX] = lower;
        vals[AddressParseData.UPPER_INDEX] = upper;
        vals[AddressParseData.EXTENDED_LOWER_INDEX] = extendedLower;
        vals[AddressParseData.EXTENDED_UPPER_INDEX] = extendedUpper;
    }

    static MAX_VALUES : number[]; public static MAX_VALUES_$LI$() : number[] { Validator.__static_initialize(); if(Validator.MAX_VALUES == null) Validator.MAX_VALUES = [0, IPv4Address.MAX_VALUE_PER_SEGMENT, 65535, 16777215, 4294967295]; return Validator.MAX_VALUES; };

    /*private*/ static getMaxIPv4Value(segmentCount : number) : number {
        return Validator.MAX_VALUES_$LI$()[segmentCount];
    }

    /*private*/ static getStringPrefixCharCount(radix : number) : number {
        if(radix === 10) {
            return 0;
        } else if(radix === 16) {
            return 2;
        }
        return 1;
    }

    static MAX_IPv4_STRING_LEN : number[][]; public static MAX_IPv4_STRING_LEN_$LI$() : number[][] { Validator.__static_initialize(); if(Validator.MAX_IPv4_STRING_LEN == null) Validator.MAX_IPv4_STRING_LEN = [[3, 6, 8, 11], [], [], [], [3, 6, 8, 11], [IPv4AddressSegment.MAX_CHARS, 5, 8, 10], [], [], [2, 4, 6, 8]]; return Validator.MAX_IPv4_STRING_LEN; };

    /*private*/ static getMaxIPv4StringLength(additionalSegmentsCovered : number, radix : number) : number {
        try {
            return Validator.MAX_IPv4_STRING_LEN_$LI$()[radix >>> 1][additionalSegmentsCovered];
        } catch(e) {
            return 0;
        };
    }

    /*private*/ static parse8(s : any, start : number, end : number) : number {
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result << 3) | charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    /*private*/ static parseLong8(s : any, start : number, end : number) : number {
        if(end - start <= 10) {
            return Validator.parse8(s, start, end);
        }
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result << 3) | charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    /*private*/ static parse10(s : any, start : number, end : number) : number {
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result * 10) + charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    /*private*/ static parseLong10(s : any, start : number, end : number) : number {
        if(end - start <= 9) {
            return Validator.parse10(s, start, end);
        }
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result * 10) + charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    /*private*/ static parse16(s : any, start : number, end : number) : number {
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result << 4) | charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    /*private*/ static parseLong16(s : any, start : number, end : number) : number {
        if(end - start <= 7) {
            return Validator.parse16(s, start, end);
        }
        let charArray : number[] = Validator.chars_$LI$();
        let result : number = charArray[(s.charAt(start)).charCodeAt(0)];
        while((++start < end)) {
            result = (result << 4) | charArray[(s.charAt(start)).charCodeAt(0)];
        };
        return result;
    }

    static __static_initializer_2() {
        let eightyFive : BigInteger = BigInteger.valueOf(85);
        Validator.BASE_85_POWERS_$LI$()[0] = BigInteger.ONE;
        for(let i : number = 1; i < Validator.BASE_85_POWERS_$LI$().length; i++) {
            Validator.BASE_85_POWERS_$LI$()[i] = Validator.BASE_85_POWERS_$LI$()[i - 1].multiply(eightyFive);
        };
    }

    /*private*/ static parseBig85(s : any, start : number, end : number) : BigInteger {
        let charArray : number[] = Validator.extendedChars_$LI$();
        let result : BigInteger = BigInteger.ZERO;
        let last : boolean;
        do {
            let partialEnd : number;
            let power : number;
            let left : number = end - start;
            if(last = (left <= 9)) {
                partialEnd = end;
                power = left;
            } else {
                partialEnd = start + 9;
                power = 9;
            }
            let partialResult : number = charArray[(s.charAt(start)).charCodeAt(0)];
            while((++start < partialEnd)) {
                let next : number = charArray[(s.charAt(start)).charCodeAt(0)];
                partialResult = (partialResult * 85) + next;
            };
            result = result.multiply(Validator.BASE_85_POWERS_$LI$()[power]).add(BigInteger.valueOf(partialResult));
            start = partialEnd;
        } while((!last));
        return result;
    }

    static validateHostImpl(fromHost : HostName) : ParsedHost {
        let str : string = fromHost.toString();
        let validationOptions : HostNameParameters = fromHost.getValidationOptions();
        return Validator.validateHost(fromHost, str, validationOptions);
    }

    /*private*/ static validateHost(fromHost : HostName, str : string, validationOptions : HostNameParameters) : ParsedHost {
        let addrLen : number = str.length;
        if(addrLen > Validator.MAX_HOST_LENGTH) {
            throw new HostNameException(str, "ipaddress.host.error.invalid.length");
        }
        let index : number;
        let lastSeparatorIndex : number;
        let qualifierIndex : number;
        let isSpecialOnlyIndex : number;
        let segmentUppercase : boolean;
        let isNotNormalized : boolean;
        let squareBracketed : boolean;
        let isAllDigits : boolean;
        let isPossiblyIPv6 : boolean;
        let isPossiblyIPv4 : boolean;
        let tryIPv6 : boolean;
        let tryIPv4 : boolean;
        let isPrefixed : boolean;
        let hasPortOrService : boolean;
        let addressIsEmpty : boolean;
        isSpecialOnlyIndex = qualifierIndex = index = lastSeparatorIndex = -1;
        let labelCount : number = 0;
        let maxLocalLabels : number = 6;
        let separatorIndices : number[] = null;
        let normalizedFlags : boolean[] = null;
        let sep0 : number;
        let sep1 : number;
        let sep2 : number;
        let sep3 : number;
        let sep4 : number;
        let sep5 : number;
        let upper0 : boolean;
        let upper1 : boolean;
        let upper2 : boolean;
        let upper3 : boolean;
        let upper4 : boolean;
        let upper5 : boolean;
        segmentUppercase = isNotNormalized = squareBracketed = tryIPv6 = tryIPv4 = isPrefixed = hasPortOrService = addressIsEmpty = false;
        isAllDigits = isPossiblyIPv6 = isPossiblyIPv4 = true;
        sep0 = sep1 = sep2 = sep3 = sep4 = sep5 = -1;
        upper0 = upper1 = upper2 = upper3 = upper4 = upper5 = false;
        while((++index <= addrLen)) {
            let currentChar : string;
            if(index === addrLen) {
                if(index === 0) {
                    addressIsEmpty = true;
                    break;
                }
                let segmentCountMatchesIPv4 : boolean = isPossiblyIPv4 && (labelCount + 1 === IPv4Address.SEGMENT_COUNT) || (labelCount + 1 < IPv4Address.SEGMENT_COUNT && isSpecialOnlyIndex >= 0) || (labelCount + 1 < IPv4Address.SEGMENT_COUNT && validationOptions.addressOptions.getIPv4Parameters().inet_aton_joinedSegments) || labelCount === 0 && validationOptions.addressOptions.allowSingleSegment;
                if(isAllDigits) {
                    if(isPossiblyIPv4 && segmentCountMatchesIPv4) {
                        tryIPv4 = true;
                        break;
                    }
                    isPossiblyIPv4 = false;
                    if(hasPortOrService && isPossiblyIPv6) {
                        tryIPv6 = true;
                        break;
                    }
                    throw new HostNameException(str, "ipaddress.host.error.invalid");
                }
                isPossiblyIPv4 = segmentCountMatchesIPv4 && isPossiblyIPv4;
                currentChar = HostName.LABEL_SEPARATOR;
            } else {
                currentChar = str.charAt(index);
            }
            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= 'z'.charCodeAt(0)) {
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) > 'f'.charCodeAt(0)) {
                    isPossiblyIPv6 = false;
                    isPossiblyIPv4 = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == 'x'.charCodeAt(0) && validationOptions.addressOptions.getIPv4Parameters().inet_aton_hex) && isPossiblyIPv4;
                } else {
                    isPossiblyIPv4 = false;
                }
                isAllDigits = false;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= '0'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= '9'.charCodeAt(0)) {
                continue;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) <= 'Z'.charCodeAt(0)) {
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) > 'F'.charCodeAt(0)) {
                    isPossiblyIPv6 = false;
                }
                segmentUppercase = true;
                isAllDigits = isPossiblyIPv4 = false;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.LABEL_SEPARATOR)) {
                let len : number = index - lastSeparatorIndex - 1;
                if(len > Validator.MAX_LABEL_LENGTH) {
                    throw new HostNameException(str, "ipaddress.error.segment.too.long");
                }
                if(len === 0) {
                    throw new HostNameException(str, "ipaddress.host.error.segment.too.short");
                }
                if(labelCount < maxLocalLabels) {
                    if(labelCount < 3) {
                        if(labelCount === 0) {
                            sep0 = index;
                            upper0 = segmentUppercase;
                        } else if(labelCount === 1) {
                            sep1 = index;
                            upper1 = segmentUppercase;
                        } else {
                            sep2 = index;
                            upper2 = segmentUppercase;
                        }
                    } else {
                        if(labelCount === 3) {
                            sep3 = index;
                            upper3 = segmentUppercase;
                        } else if(labelCount === 4) {
                            sep4 = index;
                            upper4 = segmentUppercase;
                        } else {
                            sep5 = index;
                            upper5 = segmentUppercase;
                        }
                    }
                    labelCount++;
                } else if(labelCount === maxLocalLabels) {
                    separatorIndices = (s => { let a=[]; while(s-->0) a.push(0); return a; })(Validator.MAX_HOST_SEGMENTS + 1);
                    separatorIndices[labelCount] = index;
                    if(validationOptions.normalizeToLowercase) {
                        normalizedFlags = (s => { let a=[]; while(s-->0) a.push(false); return a; })(Validator.MAX_HOST_SEGMENTS + 1);
                        normalizedFlags[labelCount] = !segmentUppercase;
                        isNotNormalized = segmentUppercase || isNotNormalized;
                    }
                    labelCount++;
                } else {
                    separatorIndices[labelCount] = index;
                    if(normalizedFlags != null) {
                        normalizedFlags[labelCount] = !segmentUppercase;
                        isNotNormalized = segmentUppercase || isNotNormalized;
                    }
                    if(++labelCount > Validator.MAX_HOST_SEGMENTS) {
                        throw new HostNameException(str, "ipaddress.host.error.too.many.segments");
                    }
                }
                lastSeparatorIndex = index;
                segmentUppercase = false;
                isPossiblyIPv6 = (index === addrLen) && isPossiblyIPv6;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == '_'.charCodeAt(0)) {
                isAllDigits = false;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == '-'.charCodeAt(0)) {
                if(index === lastSeparatorIndex + 1 || index === addrLen - 1 || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(index + 1)) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.LABEL_SEPARATOR)) {
                    throw new HostNameException(str, index);
                }
                isAllDigits = false;
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.IPV6_START_BRACKET)) {
                if(index === 0 && labelCount === 0 && addrLen > 2) {
                    squareBracketed = true;
                    break;
                }
                throw new HostNameException(str, index);
            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                isPrefixed = true;
                qualifierIndex = index + 1;
                addrLen = index;
                isNotNormalized = true;
                index--;
            } else {
                let b : boolean = false;
                if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.SEGMENT_WILDCARD) || (b = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.SEGMENT_SQL_WILDCARD)))) {
                    let addressOptions : IPAddressStringParameters = validationOptions.addressOptions;
                    if(b && addressOptions.getIPv6Parameters().allowZone) {
                        if(isPossiblyIPv6 && labelCount < IPv6Address.SEGMENT_COUNT) {
                            tryIPv6 = true;
                            isPossiblyIPv4 = false;
                            break;
                        }
                        throw new HostNameException(str, index);
                    } else {
                        if(isPossiblyIPv4 && addressOptions.getIPv4Parameters().rangeOptions.allowsWildcard()) {
                            if(isSpecialOnlyIndex < 0) {
                                isSpecialOnlyIndex = index;
                            }
                        } else {
                            isPossiblyIPv4 = false;
                        }
                        if(isPossiblyIPv6 && addressOptions.getIPv6Parameters().rangeOptions.allowsWildcard()) {
                            if(isSpecialOnlyIndex < 0) {
                                isSpecialOnlyIndex = index;
                            }
                        } else {
                            if(!isPossiblyIPv4) {
                                throw new HostNameException(str, index);
                            }
                            isPossiblyIPv6 = false;
                        }
                    }
                    isAllDigits = false;
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR)) {
                    if(validationOptions.allowPort || validationOptions.allowService) {
                        hasPortOrService = true;
                        qualifierIndex = index + 1;
                        addrLen = index;
                        isNotNormalized = true;
                        index--;
                    } else {
                        isPossiblyIPv4 = false;
                        if(isPossiblyIPv6) {
                            tryIPv6 = true;
                            break;
                        }
                        throw new HostNameException(str, index);
                    }
                } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(currentChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.ALTERNATIVE_RANGE_SEPARATOR)) {
                    isAllDigits = false;
                } else {
                    throw new HostNameException(str, index);
                }
            }
        };
        let addressOptions : IPAddressStringParameters = validationOptions.addressOptions;
        try {
            let isIPAddress : boolean = squareBracketed || tryIPv4 || tryIPv6;
            if(!validationOptions.allowIPAddress) {
                if(isIPAddress) {
                    throw new HostNameException(str, "ipaddress.host.error.ipaddress");
                }
            } else if(isIPAddress || isPossiblyIPv4 || isPossiblyIPv6) {
                try {
                    let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                    let addrQualifier : ParsedHostIdentifierStringQualifier = null;
                    let hostQualifier : ParsedHostIdentifierStringQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                    if(squareBracketed) {
                        let endIndex : number = addrLen - 1;
                        let endsWithQualifier : boolean = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(endIndex)) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.IPV6_END_BRACKET));
                        if(endsWithQualifier) {
                            while(((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(--endIndex)) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.IPV6_END_BRACKET))) {
                                if(endIndex === 1) {
                                    throw new HostNameException(str, "ipaddress.host.error.bracketed.missing.end");
                                }
                            };
                        }
                        let startIndex : number = 1;
                        if(/* startsWith */((str, searchString, position = 0) => str.substr(position, searchString.length) === searchString)(str, HostIdentifierStringValidator.SMTP_IPV6_IDENTIFIER, 1)) {
                            startIndex = 6;
                        } else {
                            let firstChar : string = str.charAt(1);
                            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(firstChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostIdentifierStringValidator.IPvFUTURE) || (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(firstChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Validator.IPvFUTURE_UPPERCASE_$LI$())) {
                                throw new HostNameException(str, "ipaddress.host.error.invalid.mechanism");
                            }
                        }
                        Validator.validateIPAddress(addressOptions, str, startIndex, endIndex, ipAddressParseData);
                        if(endsWithQualifier) {
                            let prefixIndex : number = endIndex + 1;
                            let prefixChar : string = str.charAt(prefixIndex);
                            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(prefixChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.PREFIX_LEN_SEPARATOR)) {
                                isPrefixed = true;
                            } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(prefixChar) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(HostName.PORT_SEPARATOR)) {
                                hasPortOrService = true;
                            } else {
                                throw new HostNameException(str, prefixIndex);
                            }
                            qualifierIndex = prefixIndex + 1;
                            endIndex = str.length;
                            let parsedHostQualifier : ParsedHostIdentifierStringQualifier = Validator.parseHostNameQualifier(str, addressOptions, validationOptions, isPrefixed, hasPortOrService, ipAddressParseData.addressParseData.isEmpty, qualifierIndex, endIndex, ipAddressParseData.ipVersion);
                            let insideBracketsQualifierIndex : number = ipAddressParseData.qualifierIndex;
                            if(ipAddressParseData.isZoned && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(insideBracketsQualifierIndex)) == '2'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(insideBracketsQualifierIndex + 1)) == '5'.charCodeAt(0)) {
                                insideBracketsQualifierIndex += 2;
                            }
                            addrQualifier = Validator.parseHostAddressQualifier(str, addressOptions, null, ipAddressParseData.isPrefixed, false, ipAddressParseData, insideBracketsQualifierIndex, prefixIndex - 1);
                            if(isPrefixed) {
                                if(addrQualifier === ParsedHost.NO_QUALIFIER_$LI$()) {
                                    addrQualifier = parsedHostQualifier;
                                } else {
                                    let addPrefLength : number = addrQualifier.getEquivalentPrefixLength();
                                    if(addPrefLength != null) {
                                        let hostPrefLength : number = parsedHostQualifier.getEquivalentPrefixLength();
                                        if(hostPrefLength != null && /* intValue */(addPrefLength|0) !== /* intValue */(hostPrefLength|0)) {
                                            throw new HostNameException(str, "ipaddress.host.error.bracketed.conflicting.prefix.length");
                                        }
                                    }
                                    let one : IPAddress = addrQualifier.getMask();
                                    if(one != null) {
                                        let two : IPAddress = parsedHostQualifier.getMask();
                                        if(two != null && !one.equals(two)) {
                                            throw new HostNameException(str, "ipaddress.host.error.bracketed.conflicting.mask");
                                        }
                                    }
                                    addrQualifier.mergePrefix(parsedHostQualifier);
                                }
                            } else {
                                hostQualifier = parsedHostQualifier;
                            }
                        } else {
                            qualifierIndex = ipAddressParseData.qualifierIndex;
                            isPrefixed = ipAddressParseData.isPrefixed;
                            hasPortOrService = false;
                            if(ipAddressParseData.isZoned && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(ipAddressParseData.qualifierIndex)) == '2'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(str.charAt(ipAddressParseData.qualifierIndex + 1)) == '5'.charCodeAt(0)) {
                                qualifierIndex += 2;
                            }
                            addrQualifier = Validator.parseHostAddressQualifier(str, addressOptions, validationOptions, isPrefixed, hasPortOrService, ipAddressParseData, qualifierIndex, endIndex);
                        }
                        let version : IPAddress.IPVersion = ipAddressParseData.ipVersion;
                        if(version !== IPAddress.IPVersion.IPV6 && !validationOptions.allowBracketedIPv4) {
                            throw new HostNameException(str, "ipaddress.host.error.bracketed.not.ipv6");
                        }
                    } else {
                        let firstTrySucceeded : boolean = false;
                        let hasAddressPortOrService : boolean = false;
                        let addressQualifierIndex : number = -1;
                        let isPotentiallyIPv6 : boolean = isPossiblyIPv6 || tryIPv6;
                        if(isPotentiallyIPv6) {
                            if(!isPrefixed && (validationOptions.allowPort || validationOptions.allowService)) {
                                for(let j : number = str.length - 1; j >= 0; j--) {
                                    let c : string = str.charAt(j);
                                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.SEGMENT_SEPARATOR)) {
                                        hasAddressPortOrService = true;
                                        addressQualifierIndex = j + 1;
                                    } else if(((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= '0'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= '9'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'A'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'Z'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) >= 'a'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) <= 'z'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == '-'.charCodeAt(0)) || ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(Address.SEGMENT_WILDCARD))) {
                                        continue;
                                    }
                                    break;
                                };
                            }
                        } else {
                            hasAddressPortOrService = hasPortOrService;
                            addressQualifierIndex = qualifierIndex;
                        }
                        let endIndex : number;
                        if(hasAddressPortOrService) {
                            try {
                                let hostPortQualifier : ParsedHostIdentifierStringQualifier = hostQualifier = Validator.parsePortOrService(str, null, validationOptions, addressQualifierIndex, str.length);
                                if(isPotentiallyIPv6) {
                                    let expectPort : boolean = validationOptions.expectPort;
                                    try {
                                        if(expectPort) {
                                            endIndex = addressQualifierIndex - 1;
                                        } else {
                                            endIndex = str.length;
                                            hostQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                                        }
                                        Validator.validateIPAddress(addressOptions, str, 0, endIndex, ipAddressParseData);
                                        addrQualifier = Validator.parseAddressQualifier(str, addressOptions, null, ipAddressParseData, endIndex);
                                        firstTrySucceeded = true;
                                    } catch(e) {
                                        ipAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                                        if(expectPort) {
                                            hostQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                                            endIndex = str.length;
                                        } else {
                                            hostQualifier = hostPortQualifier;
                                            endIndex = addressQualifierIndex - 1;
                                        }
                                    };
                                } else {
                                    endIndex = addressQualifierIndex - 1;
                                }
                            } catch(e) {
                                if(!isPotentiallyIPv6) {
                                    throw e;
                                }
                                hostQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                                endIndex = str.length;
                            };
                        } else {
                            endIndex = str.length;
                        }
                        if(!firstTrySucceeded) {
                            Validator.validateIPAddress(addressOptions, str, 0, endIndex, ipAddressParseData);
                            addrQualifier = Validator.parseAddressQualifier(str, addressOptions, null, ipAddressParseData, endIndex);
                        }
                    }
                    let provider : IPAddressProvider = Validator.createProvider(fromHost, str, addressOptions, ipAddressParseData, addrQualifier);
                    return new ParsedHost(str, provider, hostQualifier);
                } catch(e) {
                    if(isIPAddress) {
                        throw e;
                    }
                };
            }
            let qualifier : ParsedHostIdentifierStringQualifier = Validator.parseHostNameQualifier(str, addressOptions, validationOptions, isPrefixed, hasPortOrService, addressIsEmpty, qualifierIndex, str.length, null);
            let parsedHost : ParsedHost;
            if(addressIsEmpty) {
                if(!validationOptions.allowEmpty) {
                    throw new HostNameException(str, "ipaddress.host.error.empty");
                }
                if(qualifier === ParsedHost.NO_QUALIFIER_$LI$()) {
                    parsedHost = Validator.DEFAULT_EMPTY_HOST_$LI$();
                } else {
                    parsedHost = new ParsedHost(str, Validator.EMPTY_INDICES_$LI$(), null, qualifier);
                }
            } else {
                if(labelCount <= maxLocalLabels) {
                    separatorIndices = (s => { let a=[]; while(s-->0) a.push(0); return a; })(maxLocalLabels = labelCount);
                    if(validationOptions.normalizeToLowercase) {
                        normalizedFlags = (s => { let a=[]; while(s-->0) a.push(false); return a; })(labelCount);
                    }
                } else if(labelCount !== separatorIndices.length) {
                    let trimmedSeparatorIndices : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(labelCount);
                    /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(separatorIndices, maxLocalLabels, trimmedSeparatorIndices, maxLocalLabels, labelCount - maxLocalLabels);
                    separatorIndices = trimmedSeparatorIndices;
                    if(normalizedFlags != null) {
                        let trimmedNormalizedFlags : boolean[] = (s => { let a=[]; while(s-->0) a.push(false); return a; })(labelCount);
                        /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(normalizedFlags, maxLocalLabels, trimmedNormalizedFlags, maxLocalLabels, labelCount - maxLocalLabels);
                        normalizedFlags = trimmedNormalizedFlags;
                    }
                }
                for(let i : number = 0; i < maxLocalLabels; i++) {
                    let nextSep : number;
                    let isUpper : boolean;
                    if(i < 2) {
                        if(i === 0) {
                            nextSep = sep0;
                            isUpper = upper0;
                        } else {
                            nextSep = sep1;
                            isUpper = upper1;
                        }
                    } else if(i < 4) {
                        if(i === 2) {
                            nextSep = sep2;
                            isUpper = upper2;
                        } else {
                            nextSep = sep3;
                            isUpper = upper3;
                        }
                    } else if(i === 4) {
                        nextSep = sep4;
                        isUpper = upper4;
                    } else {
                        nextSep = sep5;
                        isUpper = upper5;
                    }
                    separatorIndices[i] = nextSep;
                    if(normalizedFlags != null) {
                        normalizedFlags[i] = !isUpper;
                        isNotNormalized = isUpper || isNotNormalized;
                    }
                };
                let addrQualifier : ParsedHostIdentifierStringQualifier;
                let hostQualifier : ParsedHostIdentifierStringQualifier;
                if(isPrefixed) {
                    addrQualifier = qualifier;
                    hostQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                } else {
                    hostQualifier = qualifier;
                    addrQualifier = ParsedHost.NO_QUALIFIER_$LI$();
                }
                let addr : ParsedHost.EmbeddedAddress = Validator.checkSpecialHosts(str, addrLen, addrQualifier);
                let embeddedException : AddressStringException = null;
                if(isSpecialOnlyIndex >= 0 && (addr == null || (embeddedException = addr.addressStringException) != null)) {
                    if(embeddedException != null) {
                        throw new HostNameException(str, isSpecialOnlyIndex, embeddedException);
                    }
                    throw new HostNameException(str, isSpecialOnlyIndex);
                }
                parsedHost = new ParsedHost(str, separatorIndices, normalizedFlags, addr == null?qualifier:hostQualifier, addr);
                if(!isNotNormalized && addr == null) {
                    parsedHost.host = str;
                }
            }
            return parsedHost;
        } catch(e) {
            throw new HostNameException(str, e, "ipaddress.host.error.invalid");
        };
    }

    /*private*/ static checkSpecialHosts(str : string, addrLen : number, hostQualifier : ParsedHostIdentifierStringQualifier) : ParsedHost.EmbeddedAddress {
        let emb : ParsedHost.EmbeddedAddress = null;
        try {
            let suffix : string = IPv6Address.UNC_SUFFIX;
            let suffixStartIndex : number;
            if(addrLen > suffix.length && str.regionMatches(true, suffixStartIndex = addrLen - suffix.length, suffix, 0, suffix.length)) {
                let builder : { str: string } = { str: str.substring(0, suffixStartIndex), toString: function() { return this.str; } };
                for(let i : number = 0; i < /* length */builder.str.length; i++) {
                    let c : string = /* charAt */builder.str.charAt(i);
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.UNC_SEGMENT_SEPARATOR)) {
                        /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(builder, i, IPv6Address.SEGMENT_SEPARATOR);
                    } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.UNC_RANGE_SEPARATOR_$LI$())) {
                        /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(builder, i, IPv6Address.RANGE_SEPARATOR);
                    } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv6Address.UNC_ZONE_SEPARATOR)) {
                        /* setCharAt */((sb, index, c) => sb.str = sb.str.substr(0, index) + c + sb.str.substr(index + 1))(builder, i, IPv6Address.ZONE_SEPARATOR);
                    }
                };
                emb = new ParsedHost.EmbeddedAddress();
                emb.isUNCIPv6Literal = true;
                let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                let params : IPAddressStringParameters = Validator.DEFAULT_UNC_OPTS_$LI$();
                Validator.validateIPAddress(params, builder, 0, /* length */builder.str.length, ipAddressParseData);
                let qual : ParsedHostIdentifierStringQualifier;
                let addrQualifier : ParsedHostIdentifierStringQualifier = Validator.parseAddressQualifier(builder, Validator.DEFAULT_UNC_OPTS_$LI$(), null, ipAddressParseData, /* length */builder.str.length);
                if(addrQualifier === ParsedHost.NO_QUALIFIER_$LI$()) {
                    qual = hostQualifier;
                } else if(hostQualifier === ParsedHost.NO_QUALIFIER_$LI$()) {
                    qual = addrQualifier;
                } else {
                    addrQualifier.mergePrefix(hostQualifier);
                    qual = addrQualifier;
                }
                let provider : IPAddressProvider = Validator.createProvider(null, builder, params, ipAddressParseData, qual);
                emb.addressProvider = provider;
            }
            let suffix3 : string = IPv6Address.REVERSE_DNS_SUFFIX_DEPRECATED;
            if(addrLen > suffix3.length) {
                suffix = IPv4Address.REVERSE_DNS_SUFFIX;
                let suffix2 : string = IPv6Address.REVERSE_DNS_SUFFIX;
                let isIPv4 : boolean;
                if((isIPv4 = str.regionMatches(true, suffixStartIndex = addrLen - suffix.length, suffix, 0, suffix.length)) || ((addrLen > suffix2.length && str.regionMatches(true, suffixStartIndex = addrLen - suffix2.length, suffix2, 0, suffix2.length)) || (addrLen > suffix3.length && str.regionMatches(true, suffixStartIndex = addrLen - suffix3.length, suffix3, 0, suffix3.length)))) {
                    emb = new ParsedHost.EmbeddedAddress();
                    emb.isReverseDNS = true;
                    if(isIPv4) {
                        let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                        let params : IPAddressStringParameters = Validator.REVERSE_DNS_IPV4_OPTS_$LI$();
                        Validator.validateIPAddress(params, str, 0, suffixStartIndex, ipAddressParseData);
                        ipAddressParseData.reverseSegments();
                        let provider : IPAddressProvider = Validator.createProvider(null, str, params, ipAddressParseData, hostQualifier != null?hostQualifier:ParsedHost.NO_QUALIFIER_$LI$());
                        emb.addressProvider = provider;
                    } else {
                        let sequence : any = Validator.convertReverseDNSIPv6(str, suffixStartIndex);
                        let ipAddressParseData : ParsedIPAddress.IPAddressParseData = new ParsedIPAddress.IPAddressParseData(str);
                        let params : IPAddressStringParameters = Validator.REVERSE_DNS_IPV6_OPTS_$LI$();
                        Validator.validateIPAddress(params, sequence, 0, sequence.length, ipAddressParseData);
                        let provider : IPAddressProvider = Validator.createProvider(null, sequence, params, ipAddressParseData, hostQualifier != null?hostQualifier:ParsedHost.NO_QUALIFIER_$LI$());
                        emb.addressProvider = provider;
                    }
                }
            }
        } catch(e) {
            emb.addressStringException = e;
        };
        return emb;
    }

    /*private*/ static convertReverseDNSIPv6(str : string, suffixStartIndex : number) : any {
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        let low : { str: string } = { str: "", toString: function() { return this.str; } };
        let high : { str: string } = { str: "", toString: function() { return this.str; } };
        let segCount : number = 0;
        for(let i : number = suffixStartIndex - 1; i >= 0; ) {
            let isRange : boolean = false;
            for(let j : number = 0; j < 4; j++) {
                let c1 : string = str.charAt(i--);
                if(i >= 0) {
                    let c2 : string = str.charAt(i--);
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv4Address.SEGMENT_SEPARATOR)) {
                        if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c1) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.SEGMENT_WILDCARD)) {
                            isRange = true;
                            /* append */(sb => { sb.str = sb.str.concat(<any>'0'); return sb; })(low);
                            /* append */(sb => { sb.str = sb.str.concat(<any>'f'); return sb; })(high);
                        } else {
                            if(isRange) {
                                throw new AddressStringException(str, i + 1);
                            }
                            /* append */(sb => { sb.str = sb.str.concat(<any>c1); return sb; })(low);
                            /* append */(sb => { sb.str = sb.str.concat(<any>c1); return sb; })(high);
                        }
                    } else if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.RANGE_SEPARATOR)) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>c1); return sb; })(high);
                        if(i >= 1) {
                            c2 = str.charAt(i--);
                            /* append */(sb => { sb.str = sb.str.concat(<any>c2); return sb; })(low);
                            let isFullRange : boolean = ((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) == '0'.charCodeAt(0) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c1) == 'f'.charCodeAt(0));
                            if(isRange && !isFullRange) {
                                throw new AddressStringException(str, i + 1);
                            }
                            c2 = str.charAt(i--);
                            if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c2) != (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPv4Address.SEGMENT_SEPARATOR)) {
                                throw new AddressStringException(str, i + 1);
                            }
                        } else {
                            throw new AddressStringException(str, i);
                        }
                        isRange = true;
                    } else {
                        throw new AddressStringException(str, i + 1);
                    }
                } else if(j < 3) {
                    throw new AddressStringException(str, i + 1);
                } else {
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(c1) == (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(IPAddress.SEGMENT_WILDCARD)) {
                        isRange = true;
                        /* append */(sb => { sb.str = sb.str.concat(<any>'0'); return sb; })(low);
                        /* append */(sb => { sb.str = sb.str.concat(<any>'f'); return sb; })(high);
                    } else {
                        if(isRange) {
                            throw new AddressStringException(str, 0);
                        }
                        /* append */(sb => { sb.str = sb.str.concat(<any>c1); return sb; })(low);
                        /* append */(sb => { sb.str = sb.str.concat(<any>c1); return sb; })(high);
                    }
                }
            };
            segCount++;
            if(/* length */builder.str.length > 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>IPv6Address.SEGMENT_SEPARATOR); return sb; })(builder);
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>low); return sb; })(builder);
            if(isRange) {
                /* append */(sb => { sb.str = sb.str.concat(<any>high); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.RANGE_SEPARATOR); return sb; })(builder));
            }
            /* setLength */((sb, length) => sb.str = sb.str.substring(0, length))(low, 0);
            /* setLength */((sb, length) => sb.str = sb.str.substring(0, length))(high, 0);
        };
        if(segCount !== 8) {
            throw new AddressStringException(str, 0);
        }
        return builder;
    }
}
Validator["__class"] = "inet.ipaddr.format.validate.Validator";
Validator["__interfaces"] = ["inet.ipaddr.format.validate.HostIdentifierStringValidator"];





Validator.MAX_IPv4_STRING_LEN_$LI$();

Validator.MAX_VALUES_$LI$();

Validator.LOW_BITS_MASK_$LI$();

Validator.BASE_85_POWERS_$LI$();

Validator.REVERSE_DNS_IPV6_OPTS_$LI$();

Validator.REVERSE_DNS_IPV4_OPTS_$LI$();

Validator.DEFAULT_UNC_OPTS_$LI$();

Validator.VALIDATOR_$LI$();

Validator.DEFAULT_PREFIX_OPTIONS_$LI$();

Validator.DEFAULT_EMPTY_HOST_$LI$();

Validator.PREFIX_CACHE_$LI$();

Validator.EMPTY_INDICES_$LI$();

Validator.IPvFUTURE_UPPERCASE_$LI$();

Validator.LONG_HEX_DIGITS_$LI$();

Validator.MAC_MAX_QUINTUPLE_$LI$();

Validator.MAC_MAX_TRIPLE_$LI$();

Validator.chars_$LI$();

Validator.extendedChars_$LI$();

Validator.__static_initialize();
