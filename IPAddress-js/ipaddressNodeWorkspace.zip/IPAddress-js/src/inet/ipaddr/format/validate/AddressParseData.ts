/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IncompatibleAddressException } from '../../IncompatibleAddressException';
import { HostIdentifierString } from '../../HostIdentifierString';
import { IPAddress } from '../../IPAddress';
import { IPAddressSection } from '../../IPAddressSection';
import { IPAddressSegment } from '../../IPAddressSegment';
import { IPAddressStringParameters } from '../../IPAddressStringParameters';
import { MACAddressString } from '../../MACAddressString';
import { IPv4Address } from '../../ipv4/IPv4Address';
import { IPv4AddressSection } from '../../ipv4/IPv4AddressSection';
import { IPv4AddressSegment } from '../../ipv4/IPv4AddressSegment';
import { IPv6Address } from '../../ipv6/IPv6Address';
import { IPv6AddressSection } from '../../ipv6/IPv6AddressSection';
import { IPv6AddressSegment } from '../../ipv6/IPv6AddressSegment';
import { MACAddress } from '../../mac/MACAddress';
import { MACAddressSection } from '../../mac/MACAddressSection';
import { MACAddressSegment } from '../../mac/MACAddressSegment';
import { MACAddressNetwork } from '../../mac/MACAddressNetwork';
import { MACAddressStringParameters } from '../../MACAddressStringParameters';
import { ParsedAddressCreator } from './ParsedAddressCreator';
import { ParsedHostIdentifierStringQualifier } from './ParsedHostIdentifierStringQualifier';
import { IPv6AddressNetwork } from '../../ipv6/IPv6AddressNetwork';
import { IPv6AddressStringParameters } from '../../ipv6/IPv6AddressStringParameters';
import { IPv4AddressNetwork } from '../../ipv4/IPv4AddressNetwork';
import { IPv4AddressStringParameters } from '../../ipv4/IPv4AddressStringParameters';
import { AddressNetwork } from '../../AddressNetwork';

export class AddressParseData {
    static serialVersionUID : number = 4;

    public static LOWER_INDEX : number = 0;

    public static UPPER_INDEX : number = 1;

    public static EXTENDED_LOWER_INDEX : number = 2;

    public static EXTENDED_UPPER_INDEX : number = 3;

    public static LOWER_RADIX_INDEX : number = 0;

    public static UPPER_RADIX_INDEX : number = 1;

    public static LOWER_STR_DIGITS_INDEX : number = 2;

    public static LOWER_STR_START_INDEX : number = 3;

    public static LOWER_STR_END_INDEX : number = 4;

    public static UPPER_STR_DIGITS_INDEX : number = 5;

    public static UPPER_STR_START_INDEX : number = 6;

    public static UPPER_STR_END_INDEX : number = 7;

    public static WILDCARD_INDEX : number = 0;

    public static SINGLE_WILDCARD_INDEX : number = 1;

    public static STANDARD_STR_INDEX : number = 2;

    public static STANDARD_RANGE_STR_INDEX : number = 3;

    flags : boolean[][];

    indices : number[][];

    values : number[][];

    segmentCount : number;

    anyWildcard : boolean;

    isEmpty : boolean;

    isAll : boolean;

    isSingleSegment : boolean;

    consecutiveSepIndex : number = -1;

    addressEndIndex : number;

    str : any;

    constructor(str : any) {
        if(this.flags===undefined) this.flags = null;
        if(this.indices===undefined) this.indices = null;
        if(this.values===undefined) this.values = null;
        if(this.segmentCount===undefined) this.segmentCount = 0;
        if(this.anyWildcard===undefined) this.anyWildcard = false;
        if(this.isEmpty===undefined) this.isEmpty = false;
        if(this.isAll===undefined) this.isAll = false;
        if(this.isSingleSegment===undefined) this.isSingleSegment = false;
        if(this.addressEndIndex===undefined) this.addressEndIndex = 0;
        if(this.str===undefined) this.str = null;
        this.str = str;
    }

    initSegmentData(segmentCapacity : number) {
        this.flags = <any> (function(dims) { let allocate = function(dims) { if(dims.length==0) { return false; } else { let array = []; for(let i = 0; i < dims[0]; i++) { array.push(allocate(dims.slice(1))); } return array; }}; return allocate(dims);})([segmentCapacity, AddressParseData.STANDARD_RANGE_STR_INDEX + 1]);
        this.indices = <any> (function(dims) { let allocate = function(dims) { if(dims.length==0) { return 0; } else { let array = []; for(let i = 0; i < dims[0]; i++) { array.push(allocate(dims.slice(1))); } return array; }}; return allocate(dims);})([segmentCapacity, AddressParseData.UPPER_STR_END_INDEX + 1]);
        this.values = <any> (function(dims) { let allocate = function(dims) { if(dims.length==0) { return 0; } else { let array = []; for(let i = 0; i < dims[0]; i++) { array.push(allocate(dims.slice(1))); } return array; }}; return allocate(dims);})([segmentCapacity, AddressParseData.EXTENDED_UPPER_INDEX + 1]);
    }

    isWildcard(index : number) : boolean {
        return this.flags[index][AddressParseData.WILDCARD_INDEX];
    }

    reverseSegments() {
        let mid : number = this.segmentCount >>> 1;
        for(let i : number = 0, reverseIndex : number = this.segmentCount - 1; i < mid; i++, reverseIndex--) {
            let tmpb : boolean[] = this.flags[i];
            let tmpi : number[] = this.indices[i];
            let tmpl : number[] = this.values[i];
            this.flags[i] = this.flags[reverseIndex];
            this.indices[i] = this.indices[reverseIndex];
            this.values[i] = this.values[reverseIndex];
            this.flags[reverseIndex] = tmpb;
            this.indices[reverseIndex] = tmpi;
            this.values[reverseIndex] = tmpl;
        };
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        let builder : { str: string } = { str: "", toString: function() { return this.str; } };
        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.str); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"address string: "); return sb; })(builder)));
        if(this.addressEndIndex > 0 && this.addressEndIndex < this.str.length) {
            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>/* subSequence */this.str.substring(this.addressEndIndex, this.str.length)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"address end: "); return sb; })(builder)));
        }
        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.segmentCount); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"segment count: "); return sb; })(builder)));
        if(this.segmentCount > 0) {
            for(let i : number = 0; i < this.segmentCount; i++) {
                /* append */(sb => { sb.str = sb.str.concat(<any>":\n"); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>i); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"segment "); return sb; })(builder)));
                let flags : boolean[] = this.flags[i];
                let isWildcard : boolean = flags[AddressParseData.WILDCARD_INDEX];
                if(isWildcard) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tis wildcard"); return sb; })(builder));
                } else {
                    let values : number[] = this.values[i];
                    let lower : number = values[AddressParseData.LOWER_INDEX];
                    let upper : number = values[AddressParseData.UPPER_INDEX];
                    let extendedUpper : number = values[AddressParseData.EXTENDED_UPPER_INDEX];
                    let extendedLower : number = values[AddressParseData.EXTENDED_LOWER_INDEX];
                    let lowerResult : BigInteger;
                    if(extendedLower !== 0) {
                        let extended : BigInteger = BigInteger.valueOf(extendedLower);
                        let shiftMore : BigInteger = extended.shiftLeft(javaemul.internal.LongHelper.SIZE);
                        let notExtended : BigInteger = BigInteger.valueOf(lower);
                        lowerResult = shiftMore.or(notExtended);
                        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>lowerResult); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tvalue: "); return sb; })(builder)));
                        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>lowerResult.toString(16)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tvalue in hex: "); return sb; })(builder)));
                    } else {
                        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>lower); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tvalue: "); return sb; })(builder)));
                        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>javaemul.internal.LongHelper.toHexString(lower)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tvalue in hex: "); return sb; })(builder)));
                        lowerResult = null;
                    }
                    let indices : number[] = this.indices[i];
                    /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>/* subSequence */this.str.substring(indices[AddressParseData.LOWER_STR_START_INDEX], indices[AddressParseData.LOWER_STR_END_INDEX])); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tstring: "); return sb; })(builder)));
                    /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>indices[AddressParseData.LOWER_RADIX_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tradix: "); return sb; })(builder)));
                    /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>flags[AddressParseData.STANDARD_STR_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tis standard: "); return sb; })(builder)));
                    if(extendedUpper !== 0) {
                        let extended : BigInteger = BigInteger.valueOf(extendedUpper);
                        let shiftMore : BigInteger = extended.shiftLeft(javaemul.internal.LongHelper.SIZE);
                        let notExtended : BigInteger = BigInteger.valueOf(upper);
                        let result : BigInteger = shiftMore.or(notExtended);
                        if(!result.equals(lowerResult)) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>result); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper value: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>result.toString(16)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper value in hex: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>/* subSequence */this.str.substring(indices[AddressParseData.UPPER_STR_START_INDEX], indices[AddressParseData.UPPER_STR_END_INDEX])); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper string: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>indices[AddressParseData.UPPER_RADIX_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper radix: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>flags[AddressParseData.STANDARD_RANGE_STR_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tis standard range: "); return sb; })(builder)));
                        }
                    } else {
                        if(upper !== lower) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>upper); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper value: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>javaemul.internal.LongHelper.toHexString(upper)); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper value in hex: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>/* subSequence */this.str.substring(indices[AddressParseData.UPPER_STR_START_INDEX], indices[AddressParseData.UPPER_STR_END_INDEX])); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper string: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>indices[AddressParseData.UPPER_RADIX_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tupper radix: "); return sb; })(builder)));
                            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>flags[AddressParseData.STANDARD_RANGE_STR_INDEX]); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\tis standard range: "); return sb; })(builder)));
                        }
                    }
                    if(flags[AddressParseData.SINGLE_WILDCARD_INDEX]) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"\thas single wildcard: "); return sb; })(builder));
                    }
                }
            };
            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.anyWildcard); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"has a wildcard segment: "); return sb; })(builder)));
            if(this.consecutiveSepIndex >= 0) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.consecutiveSepIndex + 1); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"has compressed segment(s) at character "); return sb; })(builder)));
            }
            if(this.isSingleSegment) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"is single segment"); return sb; })(builder));
            }
        } else if(this.isEmpty) {
            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"is empty"); return sb; })(builder));
        } else if(this.isAll) {
            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"is all addresses"); return sb; })(builder));
        }
        return /* toString */builder.str;
    }
}
AddressParseData["__class"] = "inet.ipaddr.format.validate.AddressParseData";
AddressParseData["__interfaces"] = ["java.io.Serializable"];



export class ParsedMACAddress {
    static serialVersionUID : number = 4;

    /*private*/ addressString : string;

    /*private*/ originator : MACAddressString;

    /*private*/ parseData : ParsedMACAddress.MACAddressParseData;

    constructor(from : MACAddressString, addressString : string, parseData : ParsedMACAddress.MACAddressParseData) {
        if(this.addressString===undefined) this.addressString = null;
        if(this.originator===undefined) this.originator = null;
        if(this.parseData===undefined) this.parseData = null;
        this.parseData = parseData;
        this.addressString = addressString;
        this.originator = from;
    }

    getMACAddressCreator() : MACAddressNetwork.MACAddressCreator {
        return this.originator.getValidationOptions().getNetwork().getAddressCreator();
    }

    createAddress() : MACAddress {
        let creator : ParsedAddressCreator<any, MACAddressSection, any, any> = this.getMACAddressCreator();
        return creator.createAddressInternal(this.createSection(), this.originator);
    }

    createSection() : MACAddressSection {
        let addressParseData : AddressParseData = this.parseData.addressParseData;
        let actualInitialSegmentCount : number = addressParseData.segmentCount;
        let creator : MACAddressNetwork.MACAddressCreator = this.getMACAddressCreator();
        let format : MACAddressParseData.MACFormat = this.parseData.format;
        let finalSegmentCount : number;
        let initialSegmentCount : number;
        if(format == null) {
            initialSegmentCount = finalSegmentCount = this.parseData.isExtended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT;
        } else if(format === MACAddressParseData.MACFormat.DOTTED) {
            initialSegmentCount = this.parseData.isExtended?MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT;
            if(actualInitialSegmentCount <= MACAddress.MEDIA_ACCESS_CONTROL_DOTTED_SEGMENT_COUNT && !this.parseData.isExtended) {
                finalSegmentCount = MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT;
            } else {
                finalSegmentCount = MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
            }
        } else {
            if(addressParseData.isSingleSegment || this.parseData.isDoubleSegment) {
                finalSegmentCount = this.parseData.isExtended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT;
            } else if(actualInitialSegmentCount <= MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT && !this.parseData.isExtended) {
                finalSegmentCount = MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT;
            } else {
                finalSegmentCount = MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
            }
            initialSegmentCount = finalSegmentCount;
        }
        let missingCount : number = initialSegmentCount - actualInitialSegmentCount;
        let expandedSegments : boolean = (missingCount <= 0);
        let segments : MACAddressSegment[] = creator.createSegmentArray(finalSegmentCount);
        for(let i : number = 0, normalizedSegmentIndex : number = 0; i < actualInitialSegmentCount; i++) {
            let vals : number[] = addressParseData.values[i];
            let flags : boolean[] = addressParseData.flags[i];
            let indices : number[] = addressParseData.indices[i];
            let lower : number = vals[AddressParseData.LOWER_INDEX];
            let upper : number = vals[AddressParseData.UPPER_INDEX];
            if(format === MACAddressParseData.MACFormat.DOTTED) {
                let lowerHalfLower : number = (((<number>lower|0)) >>> 8);
                let lowerHalfUpper : number = (((<number>upper|0)) >>> 8);
                let adjustedLower2 : number = ((<number>lower|0)) & 255;
                let adjustedUpper2 : number = ((<number>upper|0)) & 255;
                if(lowerHalfLower !== lowerHalfUpper && adjustedUpper2 - adjustedLower2 !== 255) {
                    throw new IncompatibleAddressException(this.addressString, "ipaddress.error.invalid.joined.ranges");
                }
                segments[normalizedSegmentIndex++] = <any>(ParsedMACAddress.createSegment<any>(this.addressString, lowerHalfLower, lowerHalfUpper, null, null, creator));
                segments[normalizedSegmentIndex] = <any>(ParsedMACAddress.createSegment<any>(this.addressString, adjustedLower2, adjustedUpper2, null, null, creator));
            } else {
                if(addressParseData.isSingleSegment || this.parseData.isDoubleSegment) {
                    let count : number = (i === actualInitialSegmentCount - 1)?missingCount:(MACAddress.ORGANIZATIONAL_UNIQUE_IDENTIFIER_SEGMENT_COUNT - 1);
                    missingCount -= count;
                    let isRange : boolean = (lower !== upper);
                    let previousAdjustedWasRange : boolean = false;
                    while((count >= 0)) {
                        let newLower : number;
                        let newUpper : number;
                        let segFlags : boolean[] = flags;
                        if(isRange) {
                            let segmentMask : number = MACAddress.MAX_VALUE_PER_SEGMENT;
                            let shift : number = count << 3;
                            newLower = (<number>(lower >>> shift)|0) & segmentMask;
                            newUpper = (<number>(upper >>> shift)|0) & segmentMask;
                            if(previousAdjustedWasRange && newUpper - newLower !== MACAddress.MAX_VALUE_PER_SEGMENT) {
                                throw new IncompatibleAddressException(this.addressString, "ipaddress.error.invalid.joined.ranges");
                            }
                            previousAdjustedWasRange = newLower !== newUpper;
                            if(count === 0 && newLower === lower) {
                                if(newUpper !== upper) {
                                    segFlags[AddressParseData.STANDARD_RANGE_STR_INDEX] = false;
                                }
                            } else {
                                segFlags = null;
                            }
                        } else {
                            newLower = newUpper = (<number>(lower >> (count << 3))|0) & MACAddress.MAX_VALUE_PER_SEGMENT;
                            if(count !== 0 || newLower !== lower) {
                                segFlags = null;
                            }
                        }
                        segments[normalizedSegmentIndex] = <any>(ParsedMACAddress.createSegment<any>(this.addressString, newLower, newUpper, segFlags, indices, creator));
                        ++normalizedSegmentIndex;
                        count--;
                    };
                    continue;
                }
                segments[normalizedSegmentIndex] = <any>(ParsedMACAddress.createSegment<any>(this.addressString, (<number>lower|0), (<number>upper|0), flags, indices, creator));
            }
            if(!expandedSegments) {
                if(this.parseData.isWildcard(i)) {
                    let expandSegments : boolean = true;
                    for(let j : number = i + 1; j < actualInitialSegmentCount; j++) {
                        if(this.parseData.isWildcard(j)) {
                            expandSegments = false;
                            break;
                        }
                    };
                    if(expandSegments) {
                        expandedSegments = true;
                        let count : number = missingCount;
                        while((count-- > 0)) {
                            if(format === MACAddressParseData.MACFormat.DOTTED) {
                                let seg : MACAddressSegment = <any>(ParsedMACAddress.createSegment<any>(this.addressString, 0, MACAddress.MAX_VALUE_PER_SEGMENT, null, null, creator));
                                segments[++normalizedSegmentIndex] = seg;
                                segments[++normalizedSegmentIndex] = seg;
                            } else {
                                segments[++normalizedSegmentIndex] = <any>(ParsedMACAddress.createSegment<any>(this.addressString, 0, MACAddress.MAX_VALUE_PER_SEGMENT, null, null, creator));
                            }
                        };
                    }
                }
            }
            normalizedSegmentIndex++;
        };
        let addressCreator : ParsedAddressCreator<any, MACAddressSection, any, MACAddressSegment> = creator;
        let result : MACAddressSection = addressCreator.createSectionInternal$inet_ipaddr_AddressSegment_A(segments);
        return result;
    }

    static createSegment<S extends MACAddressSegment>(addressString : string, val : number, upperVal : number, flags : boolean[], indices : number[], creator : ParsedAddressCreator<any, any, any, S>) : S {
        if(val !== upperVal) {
            return <any>(ParsedMACAddress.createRangeSegment<any>(addressString, val, upperVal, flags, indices, creator));
        }
        let result : S;
        if(flags == null) {
            result = creator.createSegment$int$int$java_lang_Integer(val, val, null);
        } else {
            result = creator.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(val, null, addressString, val, flags[AddressParseData.STANDARD_STR_INDEX], indices[AddressParseData.LOWER_STR_START_INDEX], indices[AddressParseData.LOWER_STR_END_INDEX]);
        }
        return result;
    }

    static createRangeSegment<S extends MACAddressSegment>(addressString : string, lower : number, upper : number, flags : boolean[], indices : number[], creator : ParsedAddressCreator<any, any, any, S>) : S {
        let result : S;
        if(flags == null) {
            result = creator.createSegment$int$int$java_lang_Integer(lower, upper, null);
        } else {
            result = creator.createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower, upper, null, addressString, lower, upper, flags[AddressParseData.STANDARD_STR_INDEX], flags[AddressParseData.STANDARD_RANGE_STR_INDEX], indices[AddressParseData.LOWER_STR_START_INDEX], indices[AddressParseData.LOWER_STR_END_INDEX], indices[AddressParseData.UPPER_STR_END_INDEX]);
        }
        return result;
    }
}
ParsedMACAddress["__class"] = "inet.ipaddr.format.validate.ParsedMACAddress";
ParsedMACAddress["__interfaces"] = ["java.io.Serializable"];



export namespace ParsedMACAddress {

    export class MACAddressParseData {
        static serialVersionUID : number = 4;

        addressParseData : AddressParseData;

        isDoubleSegment : boolean;

        isExtended : boolean;

        format : MACAddressParseData.MACFormat;

        constructor(str : any) {
            if(this.addressParseData===undefined) this.addressParseData = null;
            if(this.isDoubleSegment===undefined) this.isDoubleSegment = false;
            if(this.isExtended===undefined) this.isExtended = false;
            if(this.format===undefined) this.format = null;
            this.addressParseData = new AddressParseData(str);
        }

        initSegmentData(segmentCapacity : number) {
            this.addressParseData.initSegmentData(segmentCapacity);
        }

        isWildcard(index : number) : boolean {
            return this.addressParseData.isWildcard(index);
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            /* append */(sb => { sb.str = sb.str.concat(<any>this.addressParseData); return sb; })(builder);
            if(this.isDoubleSegment) {
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"is double segment"); return sb; })(builder));
            }
            /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.isExtended?64:48); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"bit length:"); return sb; })(builder)));
            if(this.format != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>this.format); return sb; })(builder);
            }
            return /* toString */builder.str;
        }
    }
    MACAddressParseData["__class"] = "inet.ipaddr.format.validate.ParsedMACAddress.MACAddressParseData";
    MACAddressParseData["__interfaces"] = ["java.io.Serializable"];



    export namespace MACAddressParseData {

        export enum MACFormat {
            DASHED, COLON_DELIMITED, DOTTED, SPACE_DELIMITED
        }

        /** @ignore */
        export class MACFormat_$WRAPPER {
            separator;

            constructor(protected _$ordinal : number, protected _$name : string, separator) {
                if(this.separator===undefined) this.separator = null;
                this.separator = separator;
            }

            getSeparator() : string {
                return this.separator;
            }

            /**
             * 
             * @return {string}
             */
            public toString() : string {
                let builder = { str: "", toString: function() { return this.str; } };
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>super.toString()); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"mac format:"); return sb; })(builder)));
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>this.separator); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"segment separator:"); return sb; })(builder)));
                return /* toString */builder.str;
            }
            public name() : string { return this._$name; }
            public ordinal() : number { return this._$ordinal; }
        }
        MACFormat["__class"] = "inet.ipaddr.format.validate.ParsedMACAddress.MACAddressParseData.MACFormat";
        MACFormat["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

        MACFormat["_$wrappers"] = [new MACFormat_$WRAPPER(0, "DASHED", MACAddress.DASH_SEGMENT_SEPARATOR), new MACFormat_$WRAPPER(1, "COLON_DELIMITED", MACAddress.COLON_SEGMENT_SEPARATOR), new MACFormat_$WRAPPER(2, "DOTTED", MACAddress.DOTTED_SEGMENT_SEPARATOR), new MACFormat_$WRAPPER(3, "SPACE_DELIMITED", MACAddress.SPACE_SEGMENT_SEPARATOR)];

    }

}


/**
 * The result from parsing a valid address string.  This can be converted into an {@link IPv4Address} or {@link IPv6Address} instance.
 * 
 * @author sfoley
 * @class
 */
export class ParsedIPAddress {
    static serialVersionUID : number = 4;

    /*private*/ ipVersion : IPAddress.IPVersion;

    /*private*/ qualifier : ParsedHostIdentifierStringQualifier;

    /*private*/ addressString : any;

    options : IPAddressStringParameters;

    /*private*/ originator : HostIdentifierString;

    /*private*/ parseData : ParsedIPAddress.IPAddressParseData;

    constructor(from : HostIdentifierString, addressString : any, options : IPAddressStringParameters, parseData : ParsedIPAddress.IPAddressParseData, ipVersion : IPAddress.IPVersion, qualifier : ParsedHostIdentifierStringQualifier) {
        if(this.ipVersion===undefined) this.ipVersion = null;
        if(this.qualifier===undefined) this.qualifier = null;
        if(this.addressString===undefined) this.addressString = null;
        if(this.options===undefined) this.options = null;
        if(this.originator===undefined) this.originator = null;
        if(this.parseData===undefined) this.parseData = null;
        this.ipVersion = ipVersion;
        this.parseData = parseData;
        this.qualifier = qualifier;
        this.addressString = addressString;
        this.options = options;
        this.originator = from;
    }

    getIPv6AddressCreator() : IPv6AddressNetwork.IPv6AddressCreator {
        return this.options.getIPv6Parameters().getNetwork().getAddressCreator();
    }

    getIPv4AddressCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.options.getIPv4Parameters().getNetwork().getAddressCreator();
    }

    reverseSegments() {
        this.parseData.reverseSegments();
    }

    getIPVersion() : IPAddress.IPVersion {
        return this.ipVersion;
    }

    isMixedIPv6() : boolean {
        return this.parseData.isMixedIPv6();
    }

    isBase85IPv6() : boolean {
        return this.parseData.isBase85;
    }

    isIPv6() : boolean {
        return IPAddress.IPVersion["_$wrappers"][this.parseData.ipVersion].isIPv6();
    }

    isIPv4() : boolean {
        return IPAddress.IPVersion["_$wrappers"][this.parseData.ipVersion].isIPv4();
    }

    getNetworkPrefixLength() : number {
        return this.qualifier.getNetworkPrefixLength();
    }

    isPrefixed() : boolean {
        return this.getNetworkPrefixLength() != null;
    }

    createAddresses() : ParsedIPAddress.IPAddresses<any, any> {
        let version : IPAddress.IPVersion = this.ipVersion;
        if(version === IPAddress.IPVersion.IPV4) {
            return this.createIPv4Addresses();
        } else if(version === IPAddress.IPVersion.IPV6) {
            return this.createIPv6Addresses();
        }
        return null;
    }

    static allocateHostSegments<S extends IPAddressSegment>(segments : S[], originalSegments : S[], creator : AddressNetwork.AddressSegmentCreator<S>, segmentCount : number, originalCount : number) : S[] {
        if(segments == null) {
            segments = creator.createSegmentArray(segmentCount);
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(originalSegments, 0, segments, 0, originalCount);
        }
        return segments;
    }

    createIPv4Addresses() : ParsedIPAddress.IPAddresses<IPv4Address, IPv4AddressSection> {
        let mask : IPAddress = this.qualifier.getMask();
        if(mask != null && mask.getBlockMaskPrefixLength(true) != null) {
            mask = null;
        }
        let hasMask : boolean = mask != null;
        let segmentCount : number = this.parseData.addressParseData.segmentCount;
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getIPv4AddressCreator();
        let ipv4SegmentCount : number = IPv4Address.SEGMENT_COUNT;
        let missingCount : number = ipv4SegmentCount - segmentCount;
        let hostSegments : IPv4AddressSegment[] = null;
        let segments : IPv4AddressSegment[] = creator.createSegmentArray(ipv4SegmentCount);
        let expandedSegments : boolean = (missingCount <= 0);
        let expandedStart : number;
        let expandedEnd : number;
        expandedStart = expandedEnd = -1;
        for(let i : number = 0, normalizedSegmentIndex : number = 0; i < segmentCount; i++, normalizedSegmentIndex++) {
            let vals : number[] = this.parseData.addressParseData.values[i];
            let flags : boolean[] = this.parseData.addressParseData.flags[i];
            let indices : number[] = this.parseData.addressParseData.indices[i];
            let lower : number = vals[AddressParseData.LOWER_INDEX];
            let upper : number = vals[AddressParseData.UPPER_INDEX];
            let isLastSegment : boolean = i === segmentCount - 1;
            if(!expandedSegments && isLastSegment && !this.parseData.isWildcard(i)) {
                expandedSegments = true;
                let count : number = missingCount;
                expandedStart = i;
                expandedEnd = i + count;
                while((count >= 0)) {
                    let currentPrefix : number = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv4Address.BITS_PER_SEGMENT, this.qualifier);
                    let newLower : number;
                    let newUpper : number;
                    let segFlags : boolean[] = flags;
                    if(lower !== upper) {
                        let shift : number = IPv4Address.BITS_PER_SEGMENT * count;
                        let segmentMask : number = IPv4Address.MAX_VALUE_PER_SEGMENT;
                        newLower = (<number>(lower >>> shift)|0) & segmentMask;
                        newUpper = (<number>(upper >>> shift)|0) & segmentMask;
                        if(count === 0 && newLower === lower) {
                            if(newUpper !== upper) {
                                segFlags[AddressParseData.STANDARD_RANGE_STR_INDEX] = false;
                            }
                        } else {
                            segFlags = null;
                        }
                    } else {
                        newLower = newUpper = (<number>(lower >> (IPv4Address.BITS_PER_SEGMENT * count))|0) & IPv4Address.MAX_VALUE_PER_SEGMENT;
                        if(count !== 0 || newLower !== lower) {
                            segFlags = null;
                        }
                    }
                    let segmentMask : number = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
                    if(segmentMask != null || currentPrefix != null) {
                        hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv4SegmentCount, normalizedSegmentIndex);
                        hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, newLower, newUpper, flags, indices, null, null, creator));
                    }
                    segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, newLower, newUpper, segFlags, indices, currentPrefix, segmentMask, creator));
                    ++normalizedSegmentIndex;
                    count--;
                };
                break;
            }
            let segmentMask : number = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
            let segmentPrefixLength : number = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv4Address.BITS_PER_SEGMENT, this.qualifier);
            if(segmentMask != null || segmentPrefixLength != null) {
                hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv4SegmentCount, normalizedSegmentIndex);
                hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, (<number>lower|0), (<number>upper|0), flags, indices, null, null, creator));
            }
            segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, (<number>lower|0), (<number>upper|0), flags, indices, segmentPrefixLength, segmentMask, creator));
            if(!expandedSegments && this.parseData.isWildcard(i) && (!this.parseData.is_inet_aton_joined || isLastSegment)) {
                let expandSegments : boolean = true;
                for(let j : number = i + 1; j < segmentCount; j++) {
                    if(this.parseData.isWildcard(j)) {
                        expandSegments = false;
                        break;
                    }
                };
                if(expandSegments) {
                    expandedSegments = true;
                    let count : number = missingCount;
                    while((count-- > 0)) {
                        ++normalizedSegmentIndex;
                        segmentMask = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
                        segmentPrefixLength = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv4Address.BITS_PER_SEGMENT, this.qualifier);
                        if(segmentMask != null || segmentPrefixLength != null) {
                            hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv4SegmentCount, normalizedSegmentIndex);
                            hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, (<number>lower|0), (<number>upper|0), flags, indices, null, null, creator));
                        }
                        segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV4, 0, IPv4Address.MAX_VALUE_PER_SEGMENT, null, null, segmentPrefixLength, segmentMask, creator));
                    };
                }
            }
        };
        let addressCreator : ParsedAddressCreator<IPv4Address, IPv4AddressSection, any, IPv4AddressSegment> = creator;
        let prefLength : number = ParsedIPAddress.getPrefixLength(this.qualifier);
        let result : IPv4AddressSection = addressCreator.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefLength);
        let hostResult : IPv4AddressSection;
        if(hostSegments != null) {
            hostResult = addressCreator.createSectionInternal$inet_ipaddr_AddressSegment_A(hostSegments);
        } else {
            hostResult = null;
        }
        if(this.checkExpandedValues(result, expandedStart, expandedEnd)) {
            throw new IncompatibleAddressException(this.addressString, "ipaddress.error.invalid.joined.ranges");
        }
        if(this.checkExpandedValues(hostResult, expandedStart, expandedEnd)) {
            hostResult = null;
        }
        return new ParsedIPAddress.ParsedIPAddress$0(this, result, hostResult);
    }

    checkExpandedValues(section : IPAddressSection, start : number, end : number) : boolean {
        if(section != null && start < end) {
            let seg : IPAddressSegment = section.getSegment(start);
            let lastWasRange : boolean = seg.isMultiple();
            do {
                seg = section.getSegment(++start);
                if(lastWasRange) {
                    if(!seg.isFullRange()) {
                        return true;
                    }
                } else {
                    lastWasRange = seg.isMultiple();
                }
            } while((start < end));
        }
        return false;
    }

    createIPv6Addresses() : ParsedIPAddress.IPAddresses<IPv6Address, IPv6AddressSection> {
        let mask : IPAddress = this.qualifier.getMask();
        if(mask != null && mask.getBlockMaskPrefixLength(true) != null) {
            mask = null;
        }
        let hasMask : boolean = mask != null;
        let segmentCount : number = this.parseData.addressParseData.segmentCount;
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getIPv6AddressCreator();
        let ipv6SegmentCount : number = IPv6Address.SEGMENT_COUNT;
        let hostSegments : IPv6AddressSegment[] = null;
        let segments : IPv6AddressSegment[] = creator.createSegmentArray(ipv6SegmentCount);
        let mixed : boolean = this.isMixedIPv6();
        let normalizedSegmentIndex : number = 0;
        let missingSegmentCount : number = (mixed?IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT:IPv6Address.SEGMENT_COUNT) - segmentCount;
        let expandedSegments : boolean = (missingSegmentCount <= 0);
        let expandedStart : number;
        let expandedEnd : number;
        expandedStart = expandedEnd = -1;
        for(let i : number = 0; i < segmentCount; i++) {
            let vals : number[] = this.parseData.addressParseData.values[i];
            let flags : boolean[] = this.parseData.addressParseData.flags[i];
            let indices : number[] = this.parseData.addressParseData.indices[i];
            let lower : number = vals[AddressParseData.LOWER_INDEX];
            let upper : number = vals[AddressParseData.UPPER_INDEX];
            if(!expandedSegments && i === segmentCount - 1 && !this.parseData.isWildcard(i)) {
                expandedSegments = true;
                let count : number = missingSegmentCount;
                let lowerHighBytes : number;
                let upperHighBytes : number;
                let isRange : boolean;
                if(count >= 4) {
                    lowerHighBytes = vals[AddressParseData.EXTENDED_LOWER_INDEX];
                    upperHighBytes = vals[AddressParseData.EXTENDED_UPPER_INDEX];
                    isRange = (lower !== upper) || (lowerHighBytes !== upperHighBytes);
                } else {
                    lowerHighBytes = upperHighBytes = 0;
                    isRange = (lower !== upper);
                }
                expandedStart = i;
                expandedEnd = i + count;
                while((count >= 0)) {
                    let currentPrefix : number = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv6Address.BITS_PER_SEGMENT, this.qualifier);
                    let newLower : number;
                    let newUpper : number;
                    let segFlags : boolean[] = flags;
                    if(isRange) {
                        let segmentMask : number = IPv6Address.MAX_VALUE_PER_SEGMENT;
                        if(count >= 4) {
                            let shift : number = IPv6Address.BITS_PER_SEGMENT * (count % 4);
                            newLower = (<number>(lowerHighBytes >>> shift)|0) & segmentMask;
                            newUpper = (<number>(upperHighBytes >>> shift)|0) & segmentMask;
                        } else {
                            let shift : number = IPv6Address.BITS_PER_SEGMENT * count;
                            newLower = (<number>(lower >>> shift)|0) & segmentMask;
                            newUpper = (<number>(upper >>> shift)|0) & segmentMask;
                        }
                        if(count === 0 && newLower === lower && lowerHighBytes === 0) {
                            if(newUpper !== upper || upperHighBytes !== 0) {
                                segFlags[AddressParseData.STANDARD_RANGE_STR_INDEX] = false;
                            }
                        } else {
                            segFlags = null;
                        }
                    } else {
                        if(count >= 4) {
                            newLower = newUpper = (<number>(lowerHighBytes >>> (IPv6Address.BITS_PER_SEGMENT * (count % 4)))|0) & IPv6Address.MAX_VALUE_PER_SEGMENT;
                            segFlags = null;
                        } else {
                            newLower = newUpper = (<number>(lower >>> (IPv6Address.BITS_PER_SEGMENT * count))|0) & IPv6Address.MAX_VALUE_PER_SEGMENT;
                            if(count !== 0 || newLower !== lower || lowerHighBytes !== 0) {
                                segFlags = null;
                            }
                        }
                    }
                    let segmentMask : number = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
                    if(segmentMask != null || currentPrefix != null) {
                        hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv6SegmentCount, normalizedSegmentIndex);
                        hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, newLower, newUpper, segFlags, indices, null, null, creator));
                    }
                    segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, newLower, newUpper, segFlags, indices, currentPrefix, segmentMask, creator));
                    ++normalizedSegmentIndex;
                    count--;
                };
                break;
            }
            let segmentMask : number = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
            let segmentPrefixLength : number = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv6Address.BITS_PER_SEGMENT, this.qualifier);
            if(segmentMask != null || segmentPrefixLength != null) {
                hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv6SegmentCount, normalizedSegmentIndex);
                hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, (<number>lower|0), (<number>upper|0), flags, indices, null, null, creator));
            }
            segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, (<number>lower|0), (<number>upper|0), flags, indices, segmentPrefixLength, segmentMask, creator));
            normalizedSegmentIndex++;
            let expandValueLower : number = 0;
            let expandValueUpper : number = 0;
            if(!expandedSegments) {
                let expandSegments : boolean = false;
                if(this.parseData.isWildcard(i)) {
                    expandValueLower = 0;
                    expandValueUpper = IPv6Address.MAX_VALUE_PER_SEGMENT;
                    expandSegments = true;
                    for(let j : number = i + 1; j < segmentCount; j++) {
                        if(this.parseData.isWildcard(j) || this.parseData.isCompressed$int(j)) {
                            expandSegments = false;
                            break;
                        }
                    };
                } else {
                    if(this.parseData.isCompressed$int(i)) {
                        expandSegments = true;
                        expandValueLower = expandValueUpper = 0;
                    }
                }
                if(expandSegments) {
                    expandedSegments = true;
                    let count : number = missingSegmentCount;
                    while((count-- > 0)) {
                        segmentMask = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
                        segmentPrefixLength = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv6Address.BITS_PER_SEGMENT, this.qualifier);
                        if(segmentMask != null || segmentPrefixLength != null) {
                            hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv6SegmentCount, normalizedSegmentIndex);
                            hostSegments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, expandValueLower, expandValueUpper, null, null, null, null, creator));
                        }
                        segments[normalizedSegmentIndex] = <any>(ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(this.addressString, IPAddress.IPVersion.IPV6, expandValueLower, expandValueUpper, null, null, segmentPrefixLength, segmentMask, creator));
                        normalizedSegmentIndex++;
                    };
                }
            }
        };
        let result : IPv6AddressSection;
        let hostResult : IPv6AddressSection;
        result = hostResult = null;
        let addressCreator : ParsedAddressCreator<any, IPv6AddressSection, IPv4AddressSection, IPv6AddressSegment> = creator;
        if(mixed) {
            let ipv4AddressSection : IPv4AddressSection = this.parseData.mixedParsedAddress.createIPv4Addresses().getSection();
            let embeddedSectionIsChanged : boolean = false;
            for(let n : number = 0; n < 2; n++) {
                let m : number = n << 1;
                let one : IPv4AddressSegment = ipv4AddressSection.getSegment(m);
                let two : IPv4AddressSegment = ipv4AddressSection.getSegment(m + 1);
                let segmentMask : number = hasMask?mask.getSegment(normalizedSegmentIndex).getLowerSegmentValue():null;
                let newSegment : IPv6AddressSegment;
                let segmentPrefixLength : number = ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(normalizedSegmentIndex, IPv6Address.BITS_PER_SEGMENT, this.qualifier);
                let doHostSegment : boolean = segmentMask != null || segmentPrefixLength != null;
                if(doHostSegment) {
                    hostSegments = ParsedIPAddress.allocateHostSegments<any>(hostSegments, segments, creator, ipv6SegmentCount, normalizedSegmentIndex);
                }
                let oneLower : number = one.getLowerSegmentValue();
                let twoLower : number = two.getLowerSegmentValue();
                if(!one.isMultiple() && !two.isMultiple()) {
                    if(doHostSegment) {
                        hostSegments[normalizedSegmentIndex] = ParsedIPAddress.createSegment$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(oneLower, twoLower, null, null, creator);
                    }
                    segments[normalizedSegmentIndex] = newSegment = ParsedIPAddress.createSegment$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(oneLower, twoLower, segmentPrefixLength, segmentMask, creator);
                } else {
                    let oneUpper : number = one.getUpperSegmentValue();
                    let twoUpper : number = two.getUpperSegmentValue();
                    if(doHostSegment) {
                        hostSegments[normalizedSegmentIndex] = ParsedIPAddress.createSegment$inet_ipaddr_ipv4_IPv4AddressSegment$inet_ipaddr_ipv4_IPv4AddressSegment$int$int$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(one, two, oneLower, oneUpper, twoLower, twoUpper, null, null, creator);
                    }
                    segments[normalizedSegmentIndex] = newSegment = ParsedIPAddress.createSegment$inet_ipaddr_ipv4_IPv4AddressSegment$inet_ipaddr_ipv4_IPv4AddressSegment$int$int$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(one, two, oneLower, oneUpper, twoLower, twoUpper, segmentPrefixLength, segmentMask, creator);
                }
                embeddedSectionIsChanged = newSegment.isPrefixed() || newSegment.getLowerSegmentValue() !== ((one.getLowerSegmentValue() << IPv4Address.BITS_PER_SEGMENT) | two.getLowerSegmentValue()) || newSegment.getUpperSegmentValue() !== ((one.getUpperSegmentValue() << IPv4Address.BITS_PER_SEGMENT) | two.getUpperSegmentValue()) || embeddedSectionIsChanged;
                normalizedSegmentIndex++;
            };
            if(!embeddedSectionIsChanged) {
                if(hostSegments != null) {
                    hostResult = addressCreator.createSectionInternal(hostSegments, ipv4AddressSection);
                }
                result = addressCreator.createSectionInternal(segments, ipv4AddressSection, ParsedIPAddress.getPrefixLength(this.qualifier));
            }
        }
        if(result == null) {
            if(hostSegments != null) {
                hostResult = addressCreator.createSectionInternal$inet_ipaddr_AddressSegment_A(hostSegments);
            }
            result = addressCreator.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, ParsedIPAddress.getPrefixLength(this.qualifier));
        }
        if(this.checkExpandedValues(result, expandedStart, expandedEnd)) {
            throw new IncompatibleAddressException(this.addressString, "ipaddress.error.invalid.joined.ranges");
        }
        if(this.checkExpandedValues(hostResult, expandedStart, expandedEnd)) {
            hostResult = null;
        }
        return new ParsedIPAddress.ParsedIPAddress$1(this, result, hostResult);
    }

    public static createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator<S extends IPAddressSegment>(addressString : any, version : IPAddress.IPVersion, val : number, upperVal : number, flags : boolean[], indices : number[], segmentPrefixLength : number, mask : number, creator : ParsedAddressCreator<any, any, any, S>) : S {
        if(val !== upperVal) {
            return <any>(ParsedIPAddress.createRangeSegment<any>(addressString, version, val, upperVal, flags, indices, segmentPrefixLength, mask, creator));
        }
        let stringVal : number = val;
        if(mask != null) {
            val &= mask;
        }
        let result : S;
        if(flags == null) {
            result = creator.createSegment$int$int$java_lang_Integer(val, val, segmentPrefixLength);
        } else {
            result = creator.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(val, segmentPrefixLength, addressString, stringVal, flags[AddressParseData.STANDARD_STR_INDEX], indices[AddressParseData.LOWER_STR_START_INDEX], indices[AddressParseData.LOWER_STR_END_INDEX]);
        }
        return result;
    }

    public static createSegment<S extends IPAddressSegment>(addressString? : any, version? : any, val? : any, upperVal? : any, flags? : any, indices? : any, segmentPrefixLength? : any, mask? : any, creator? : any) : any {
        if(((addressString != null && (addressString["__interfaces"] != null && addressString["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressString.constructor != null && addressString.constructor["__interfaces"] != null && addressString.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressString === "string")) || addressString === null) && ((typeof version === 'number') || version === null) && ((typeof val === 'number') || val === null) && ((typeof upperVal === 'number') || upperVal === null) && ((flags != null && flags instanceof <any>Array && (flags.length==0 || flags[0] == null ||(typeof flags[0] === 'boolean'))) || flags === null) && ((indices != null && indices instanceof <any>Array && (indices.length==0 || indices[0] == null ||(typeof indices[0] === 'number'))) || indices === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof mask === 'number') || mask === null) && ((creator != null && creator instanceof <any>ParsedAddressCreator) || creator === null)) {
            return <any>ParsedIPAddress.createSegment$java_lang_CharSequence$inet_ipaddr_IPAddress_IPVersion$int$int$boolean_A$int_A$java_lang_Integer$java_lang_Integer$inet_ipaddr_format_validate_ParsedAddressCreator(addressString, version, val, upperVal, flags, indices, segmentPrefixLength, mask, creator);
        } else if(((addressString != null && addressString instanceof <any>IPv4AddressSegment) || addressString === null) && ((version != null && version instanceof <any>IPv4AddressSegment) || version === null) && ((typeof val === 'number') || val === null) && ((typeof upperVal === 'number') || upperVal === null) && ((typeof flags === 'number') || flags === null) && ((typeof indices === 'number') || indices === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof mask === 'number') || mask === null) && ((creator != null && creator instanceof <any>IPv6AddressNetwork.IPv6AddressCreator) || creator === null)) {
            return <any>ParsedIPAddress.createSegment$inet_ipaddr_ipv4_IPv4AddressSegment$inet_ipaddr_ipv4_IPv4AddressSegment$int$int$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(addressString, version, val, upperVal, flags, indices, segmentPrefixLength, mask, creator);
        } else if(((typeof addressString === 'number') || addressString === null) && ((typeof version === 'number') || version === null) && ((typeof val === 'number') || val === null) && ((typeof upperVal === 'number') || upperVal === null) && ((flags != null && flags instanceof <any>IPv6AddressNetwork.IPv6AddressCreator) || flags === null) && indices === undefined && segmentPrefixLength === undefined && mask === undefined && creator === undefined) {
            return <any>ParsedIPAddress.createSegment$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(addressString, version, val, upperVal, flags);
        } else throw new Error('invalid overload');
    }

    static createSegment$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(value1 : number, value2 : number, segmentPrefixLength : number, mask : number, creator : IPv6AddressNetwork.IPv6AddressCreator) : IPv6AddressSegment {
        let value : number = (value1 << IPv4Address.BITS_PER_SEGMENT) | value2;
        if(mask != null) {
            value &= mask;
        }
        let result : IPv6AddressSegment = creator.createSegment$int$java_lang_Integer(value, segmentPrefixLength);
        return result;
    }

    static createSegment$inet_ipaddr_ipv4_IPv4AddressSegment$inet_ipaddr_ipv4_IPv4AddressSegment$int$int$int$int$java_lang_Integer$java_lang_Integer$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator(one : IPv4AddressSegment, two : IPv4AddressSegment, upperRangeLower : number, upperRangeUpper : number, lowerRangeLower : number, lowerRangeUpper : number, segmentPrefixLength : number, mask : number, creator : IPv6AddressNetwork.IPv6AddressCreator) : IPv6AddressSegment {
        let hasMask : boolean = (mask != null);
        if(hasMask) {
            let maskInt : number = /* intValue */(mask|0);
            let shift : number = IPv4Address.BITS_PER_SEGMENT;
            let shiftedMask : number = maskInt >> shift;
            upperRangeLower &= shiftedMask;
            upperRangeUpper &= shiftedMask;
            lowerRangeLower &= maskInt;
            lowerRangeUpper &= maskInt;
        }
        let result : IPv6AddressSegment = ParsedIPAddress.join(one, two, upperRangeLower, upperRangeUpper, lowerRangeLower, lowerRangeUpper, segmentPrefixLength, creator);
        if(hasMask && !result.isMaskCompatibleWithRange$int$java_lang_Integer(/* intValue */(mask|0), segmentPrefixLength)) {
            throw new IncompatibleAddressException(result, mask, "ipaddress.error.maskMismatch");
        }
        return result;
    }

    static join(one : IPv4AddressSegment, two : IPv4AddressSegment, upperRangeLower : number, upperRangeUpper : number, lowerRangeLower : number, lowerRangeUpper : number, segmentPrefixLength : number, creator : IPv6AddressNetwork.IPv6AddressCreator) : IPv6AddressSegment {
        let shift : number = IPv4Address.BITS_PER_SEGMENT;
        if(upperRangeLower !== upperRangeUpper) {
            if(segmentPrefixLength != null && AddressNetwork.PrefixConfiguration["_$wrappers"][creator.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                if(segmentPrefixLength > shift) {
                    let lowerPrefixLength : number = segmentPrefixLength - shift;
                    let fullMask : number = ~(~0 << shift);
                    let networkMask : number = fullMask & (fullMask << (shift - lowerPrefixLength));
                    let hostMask : number = ~networkMask & fullMask;
                    lowerRangeLower &= networkMask;
                    lowerRangeUpper |= hostMask;
                    if(lowerRangeLower !== 0 || lowerRangeUpper !== IPv4Address.MAX_VALUE_PER_SEGMENT) {
                        throw new IncompatibleAddressException(one, two, "ipaddress.error.invalidMixedRange");
                    }
                } else {
                    lowerRangeLower = 0;
                    lowerRangeUpper = IPv4Address.MAX_VALUE_PER_SEGMENT;
                }
            } else if(lowerRangeLower !== 0 || lowerRangeUpper !== IPv4Address.MAX_VALUE_PER_SEGMENT) {
                throw new IncompatibleAddressException(one, two, "ipaddress.error.invalidMixedRange");
            }
        }
        return creator.createSegment$int$int$java_lang_Integer((upperRangeLower << shift) | lowerRangeLower, (upperRangeUpper << shift) | lowerRangeUpper, segmentPrefixLength);
    }

    static createRangeSegment<S extends IPAddressSegment>(addressString : any, version : IPAddress.IPVersion, stringLower : number, stringUpper : number, flags : boolean[], indices : number[], segmentPrefixLength : number, mask : number, creator : ParsedAddressCreator<any, any, any, S>) : S {
        let lower : number = stringLower;
        let upper : number = stringUpper;
        let hasMask : boolean = (mask != null);
        if(hasMask) {
            let maskInt : number = /* intValue */(mask|0);
            lower &= maskInt;
            upper &= maskInt;
        }
        let result : S;
        if(flags == null) {
            result = creator.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
        } else {
            result = creator.createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower, upper, segmentPrefixLength, addressString, stringLower, stringUpper, flags[AddressParseData.STANDARD_STR_INDEX], flags[AddressParseData.STANDARD_RANGE_STR_INDEX], indices[AddressParseData.LOWER_STR_START_INDEX], indices[AddressParseData.LOWER_STR_END_INDEX], indices[AddressParseData.UPPER_STR_END_INDEX]);
        }
        if(hasMask && !result.isMaskCompatibleWithRange$int$java_lang_Integer(/* intValue */(mask|0), segmentPrefixLength)) {
            throw new IncompatibleAddressException(result, mask, "ipaddress.error.maskMismatch");
        }
        return result;
    }

    static createAllAddress(version : IPAddress.IPVersion, qualifier : ParsedHostIdentifierStringQualifier, originator : HostIdentifierString, options : IPAddressStringParameters) : IPAddress {
        let segmentCount : number = IPAddress.getSegmentCount(version);
        let mask : IPAddress = qualifier.getMask();
        if(mask != null && mask.getBlockMaskPrefixLength(true) != null) {
            mask = null;
        }
        let hasMask : boolean = mask != null;
        let prefLength : number = ParsedIPAddress.getPrefixLength(qualifier);
        if(IPAddress.IPVersion["_$wrappers"][version].isIPv4()) {
            let creator : ParsedAddressCreator<IPv4Address, IPv4AddressSection, any, IPv4AddressSegment> = options.getIPv4Parameters().getNetwork().getAddressCreator();
            let segments : IPv4AddressSegment[] = creator.createSegmentArray(segmentCount);
            for(let i : number = 0; i < segmentCount; i++) {
                let segmentMask : number = hasMask?mask.getSegment(i).getLowerSegmentValue():null;
                segments[i] = <any>(ParsedIPAddress.createRangeSegment<any>(null, version, 0, IPv4Address.MAX_VALUE_PER_SEGMENT, null, null, ParsedIPAddress.getSegmentPrefixLength$int$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(i, version, qualifier), segmentMask, creator));
            };
            return creator.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, originator, prefLength);
        } else {
            let creator : ParsedAddressCreator<IPv6Address, IPv6AddressSection, any, IPv6AddressSegment> = options.getIPv6Parameters().getNetwork().getAddressCreator();
            let segments : IPv6AddressSegment[] = creator.createSegmentArray(segmentCount);
            for(let i : number = 0; i < segmentCount; i++) {
                let segmentMask : number = hasMask?mask.getSegment(i).getLowerSegmentValue():null;
                segments[i] = <any>(ParsedIPAddress.createRangeSegment<any>(null, version, 0, IPv6Address.MAX_VALUE_PER_SEGMENT, null, null, ParsedIPAddress.getSegmentPrefixLength$int$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(i, version, qualifier), segmentMask, creator));
            };
            return creator.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_CharSequence$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, qualifier.getZone(), originator, prefLength);
        }
    }

    static getPrefixLength(qualifier : ParsedHostIdentifierStringQualifier) : number {
        let mask : IPAddress = qualifier.getMask();
        let bits : number = mask != null?mask.getBlockMaskPrefixLength(true):qualifier.getNetworkPrefixLength();
        return bits;
    }

    static getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(segmentIndex : number, bitsPerSegment : number, qualifier : ParsedHostIdentifierStringQualifier) : number {
        let mask : IPAddress = qualifier.getMask();
        let networkPrefixLength : number = qualifier.getNetworkPrefixLength();
        let bits : number = mask != null?mask.getBlockMaskPrefixLength(true):networkPrefixLength;
        return IPAddressSection.getSegmentPrefixLength$int$java_lang_Integer$int(bitsPerSegment, bits, segmentIndex);
    }

    public static getSegmentPrefixLength$int$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(segmentIndex : number, version : IPAddress.IPVersion, qualifier : ParsedHostIdentifierStringQualifier) : number {
        return ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(segmentIndex, IPAddressSection.bitsPerSegment(version), qualifier);
    }

    /**
     * Across the address prefixes are:
     * IPv6: (null):...:(null):(1 to 16):(0):...:(0)
     * or IPv4: ...(null).(1 to 8).(0)...
     * 
     * @param {number} segmentIndex
     * @param segmentCount
     * @param {IPAddress.IPVersion} version
     * @return
     * @param {ParsedHostIdentifierStringQualifier} qualifier
     * @return {number}
     * @private
     */
    public static getSegmentPrefixLength(segmentIndex? : any, version? : any, qualifier? : any) : any {
        if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((typeof version === 'number') || version === null) && ((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null)) {
            return <any>ParsedIPAddress.getSegmentPrefixLength$int$inet_ipaddr_IPAddress_IPVersion$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(segmentIndex, version, qualifier);
        } else if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((typeof version === 'number') || version === null) && ((qualifier != null && qualifier instanceof <any>ParsedHostIdentifierStringQualifier) || qualifier === null)) {
            return <any>ParsedIPAddress.getSegmentPrefixLength$int$int$inet_ipaddr_format_validate_ParsedHostIdentifierStringQualifier(segmentIndex, version, qualifier);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return this.addressString.toString();
    }
}
ParsedIPAddress["__class"] = "inet.ipaddr.format.validate.ParsedIPAddress";
ParsedIPAddress["__interfaces"] = ["java.io.Serializable"];



export namespace ParsedIPAddress {

    /**
     * Stores the data from a parsed address.  This data can later be translated into {@link IPv4Address} or {@link IPv6Address} objects.
     * @author sfoley
     * @class
     */
    export class IPAddressParseData {
        static serialVersionUID : number = 4;

        addressParseData : AddressParseData;

        qualifierIndex : number = -1;

        isPrefixed : boolean;

        isZoned : boolean;

        ipVersion : IPAddress.IPVersion;

        is_inet_aton_joined : boolean;

        mixedParsedAddress : ParsedIPAddress;

        isBase85 : boolean;

        isBase85Zoned : boolean;

        constructor(str : any) {
            if(this.addressParseData===undefined) this.addressParseData = null;
            if(this.isPrefixed===undefined) this.isPrefixed = false;
            if(this.isZoned===undefined) this.isZoned = false;
            if(this.ipVersion===undefined) this.ipVersion = null;
            if(this.is_inet_aton_joined===undefined) this.is_inet_aton_joined = false;
            if(this.mixedParsedAddress===undefined) this.mixedParsedAddress = null;
            if(this.isBase85===undefined) this.isBase85 = false;
            if(this.isBase85Zoned===undefined) this.isBase85Zoned = false;
            this.addressParseData = new AddressParseData(str);
        }

        initSegmentData(segmentCapacity : number) {
            this.addressParseData.initSegmentData(segmentCapacity);
        }

        clearQualifier() {
            this.qualifierIndex = -1;
            this.isBase85Zoned = this.isPrefixed = this.isZoned = false;
        }

        reverseSegments() {
            if(this.mixedParsedAddress != null) {
                this.mixedParsedAddress.reverseSegments();
            }
            this.addressParseData.reverseSegments();
        }

        isCompressed$() : boolean {
            return this.addressParseData.consecutiveSepIndex >= 0;
        }

        public isCompressed$int(index : number) : boolean {
            let inds : number[] = this.addressParseData.indices[index];
            let end : number = inds[AddressParseData.UPPER_STR_END_INDEX];
            let start : number = inds[AddressParseData.LOWER_STR_START_INDEX];
            return start === end;
        }

        public isCompressed(index? : any) : any {
            if(((typeof index === 'number') || index === null)) {
                return <any>this.isCompressed$int(index);
            } else if(index === undefined) {
                return <any>this.isCompressed$();
            } else throw new Error('invalid overload');
        }

        isWildcard(index : number) : boolean {
            return this.addressParseData.isWildcard(index);
        }

        isMixedIPv6() : boolean {
            return this.mixedParsedAddress != null;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            /* append */(sb => { sb.str = sb.str.concat(<any>this.addressParseData); return sb; })(builder);
            /* append */(sb => { sb.str = sb.str.concat(<any>this.ipVersion); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>"ip version: "); return sb; })(builder));
            if(IPAddress.IPVersion["_$wrappers"][this.ipVersion].isIPv6()) {
                if(this.isMixedIPv6()) {
                    if(this.isZoned) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>", with zone "); return sb; })(builder);
                        this.printQualifier(builder);
                    }
                    if(this.isPrefixed) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>", with prefix length "); return sb; })(builder);
                        this.printQualifier(builder);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>this.mixedParsedAddress.parseData); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>", with IPv4 embedded address: "); return sb; })(builder)));
                } else {
                    if(this.isBase85) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>" base 85"); return sb; })(builder);
                        if(this.isBase85Zoned) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>", with zone "); return sb; })(builder);
                            this.printQualifier(builder);
                        }
                    } else {
                        if(this.isZoned) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>", with zone "); return sb; })(builder);
                            this.printQualifier(builder);
                        }
                    }
                    if(this.isPrefixed) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>", with prefix length "); return sb; })(builder);
                        this.printQualifier(builder);
                    }
                    /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(builder);
                }
            } else if(IPAddress.IPVersion["_$wrappers"][this.ipVersion].isIPv4()) {
                if(this.isPrefixed) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>", with prefix length  "); return sb; })(builder);
                    this.printQualifier(builder);
                }
                if(this.is_inet_aton_joined) {
                    /* append */(sb => { sb.str = sb.str.concat(<any>", with joined segments"); return sb; })(builder);
                }
                /* append */(sb => { sb.str = sb.str.concat(<any>'\n'); return sb; })(builder);
            }
            return /* toString */builder.str;
        }

        printQualifier(builder : { str: string }) {
            if(this.qualifierIndex >= 0) {
                let str : any = this.addressParseData.str;
                /* append */(sb => { sb.str = sb.str.concat(<any>/* subSequence */str.substring(this.qualifierIndex, str.length)); return sb; })(builder);
            } else {
                /* append */(sb => { sb.str = sb.str.concat(<any>"unknown"); return sb; })(builder);
            }
        }
    }
    IPAddressParseData["__class"] = "inet.ipaddr.format.validate.ParsedIPAddress.IPAddressParseData";
    IPAddressParseData["__interfaces"] = ["java.io.Serializable"];



    export class CachedIPAddresses<T extends IPAddress> {
        static serialVersionUID : number = 4;

        address : T;

        hostAddress : T;

        public constructor(address? : any, hostAddress? : any) {
            if(((address != null) || address === null) && ((hostAddress != null) || hostAddress === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.address===undefined) this.address = null;
                if(this.hostAddress===undefined) this.hostAddress = null;
                if(this.address===undefined) this.address = null;
                if(this.hostAddress===undefined) this.hostAddress = null;
                (() => {
                    this.address = address;
                    this.hostAddress = hostAddress;
                })();
            } else if(((address != null) || address === null) && hostAddress === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let hostAddress : any = __args[0];
                    if(this.address===undefined) this.address = null;
                    if(this.hostAddress===undefined) this.hostAddress = null;
                    if(this.address===undefined) this.address = null;
                    if(this.hostAddress===undefined) this.hostAddress = null;
                    (() => {
                        this.address = address;
                        this.hostAddress = hostAddress;
                    })();
                }
            } else if(address === undefined && hostAddress === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.address===undefined) this.address = null;
                if(this.hostAddress===undefined) this.hostAddress = null;
                if(this.address===undefined) this.address = null;
                if(this.hostAddress===undefined) this.hostAddress = null;
            } else throw new Error('invalid overload');
        }

        public getAddress() : T {
            return this.address;
        }

        public getHostAddress() : T {
            return this.hostAddress;
        }
    }
    CachedIPAddresses["__class"] = "inet.ipaddr.format.validate.ParsedIPAddress.CachedIPAddresses";
    CachedIPAddresses["__interfaces"] = ["java.io.Serializable"];



    export abstract class IPAddresses<T extends IPAddress, R extends IPAddressSection> extends ParsedIPAddress.CachedIPAddresses<T> {
        public __parent: any;
        static __inet_ipaddr_format_validate_ParsedIPAddress_IPAddresses_serialVersionUID : number = 4;

        section : R;

        hostSection : R;

        constructor(__parent: any, section : R, hostSection : R) {
            super();
            this.__parent = __parent;
            if(this.section===undefined) this.section = null;
            if(this.hostSection===undefined) this.hostSection = null;
            this.section = section;
            this.hostSection = hostSection;
        }

        abstract getCreator() : ParsedAddressCreator<T, R, any, any>;

        /**
         * 
         * @return {IPAddress}
         */
        public getAddress() : T {
            if(this.address == null) {
                this.address = this.getCreator().createAddressInternal(this.section, this.__parent.qualifier.getZone(), this.__parent.originator);
            }
            return this.address;
        }

        /**
         * 
         * @return {IPAddress}
         */
        public getHostAddress() : T {
            if(this.hostSection == null) {
                return this.getAddress();
            }
            if(this.hostAddress == null) {
                this.hostAddress = this.getCreator().createAddressInternal(this.hostSection, this.__parent.qualifier.getZone(), null);
            }
            return this.hostAddress;
        }

        getSection() : R {
            return this.section;
        }
    }
    IPAddresses["__class"] = "inet.ipaddr.format.validate.ParsedIPAddress.IPAddresses";
    IPAddresses["__interfaces"] = ["java.io.Serializable"];



    export class ParsedIPAddress$0 extends ParsedIPAddress.IPAddresses<IPv4Address, IPv4AddressSection> {
        public __parent: any;
        /**
         * 
         * @return {ParsedAddressCreator}
         */
        getCreator() : ParsedAddressCreator<IPv4Address, IPv4AddressSection, any, any> {
            return this.__parent.getIPv4AddressCreator();
        }

        constructor(__parent: any, __arg0: any, __arg1: any) {
            super(__parent, __arg0, __arg1);
            this.__parent = __parent;
        }
    }
    ParsedIPAddress$0["__interfaces"] = ["java.io.Serializable"];



    export class ParsedIPAddress$1 extends ParsedIPAddress.IPAddresses<IPv6Address, IPv6AddressSection> {
        public __parent: any;
        /**
         * 
         * @return {ParsedAddressCreator}
         */
        getCreator() : ParsedAddressCreator<IPv6Address, IPv6AddressSection, any, any> {
            return this.__parent.getIPv6AddressCreator();
        }

        constructor(__parent: any, __arg0: any, __arg1: any) {
            super(__parent, __arg0, __arg1);
            this.__parent = __parent;
        }
    }
    ParsedIPAddress$1["__interfaces"] = ["java.io.Serializable"];


}



