/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../../Address';
import { AddressSection } from '../../AddressSection';
import { AddressSegment } from '../../AddressSegment';
import { HostIdentifierString } from '../../HostIdentifierString';

/**
 * Has methods for creating addresses, segments and sections that are available to the parser.
 * 
 * @author sfoley
 * 
 * @param <T>
 * @param <R>
 * @param <E>
 * @param <S>
 * @class
 */
export abstract class ParsedAddressCreator<T extends Address, R extends AddressSection, E extends AddressSection, S extends AddressSegment> {
    static serialVersionUID : number = 4;

    public abstract createSegmentArray(length : number) : S[];

    public createSegment$int$int$java_lang_Integer(lower : number, upper : number, segmentPrefixLength : number) : S { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createSegment(lower? : any, upper? : any, segmentPrefixLength? : any) : any {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            return <any>this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(value : number, segmentPrefixLength : number, addressStr : any, originalVal : number, isStandardString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number) : S { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower : number, upper : number, segmentPrefixLength : number, addressStr : any, originalLower : number, originalUpper : number, isStandardString : boolean, isStandardRangeString : boolean, lowerStringStartIndex : number, lowerStringEndIndex : number, upperStringEndIndex : number) : S { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    public createSegmentInternal(lower? : any, upper? : any, segmentPrefixLength? : any, addressStr? : any, originalLower? : any, originalUpper? : any, isStandardString? : any, isStandardRangeString? : any, lowerStringStartIndex? : any, lowerStringEndIndex? : any, upperStringEndIndex? : any) : any {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((addressStr != null && (addressStr["__interfaces"] != null && addressStr["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || addressStr.constructor != null && addressStr.constructor["__interfaces"] != null && addressStr.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof addressStr === "string")) || addressStr === null) && ((typeof originalLower === 'number') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'boolean') || isStandardString === null) && ((typeof isStandardRangeString === 'boolean') || isStandardRangeString === null) && ((typeof lowerStringStartIndex === 'number') || lowerStringStartIndex === null) && ((typeof lowerStringEndIndex === 'number') || lowerStringEndIndex === null) && ((typeof upperStringEndIndex === 'number') || upperStringEndIndex === null)) {
            return <any>this.createSegmentInternal$int$int$java_lang_Integer$java_lang_CharSequence$int$int$boolean$boolean$int$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString, isStandardRangeString, lowerStringStartIndex, lowerStringEndIndex, upperStringEndIndex);
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((segmentPrefixLength != null && (segmentPrefixLength["__interfaces"] != null && segmentPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentPrefixLength.constructor != null && segmentPrefixLength.constructor["__interfaces"] != null && segmentPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentPrefixLength === "string")) || segmentPrefixLength === null) && ((typeof addressStr === 'number') || addressStr === null) && ((typeof originalLower === 'boolean') || originalLower === null) && ((typeof originalUpper === 'number') || originalUpper === null) && ((typeof isStandardString === 'number') || isStandardString === null) && isStandardRangeString === undefined && lowerStringStartIndex === undefined && lowerStringEndIndex === undefined && upperStringEndIndex === undefined) {
            return <any>this.createSegmentInternal$int$java_lang_Integer$java_lang_CharSequence$int$boolean$int$int(lower, upper, segmentPrefixLength, addressStr, originalLower, originalUpper, isStandardString);
        } else throw new Error('invalid overload');
    }

    public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
            return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
        } else throw new Error('invalid overload');
    }

    createSectionInternal$inet_ipaddr_AddressSegment_A(segments : S[]) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    /**
     * 
     * @param {Array} segments
     * @param {number} prefix
     * @param {boolean} singleOnly
     * @return {IPv4AddressSection}
     */
    public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
        if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
            return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
        } else throw new Error('invalid overload');
    }

    createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments : S[], prefix : number) : R { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(segments : S[], embeddedSection : E) : R {
        return this.createSectionInternal$inet_ipaddr_AddressSegment_A(segments);
    }

    createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(segments : S[], embeddedSection : E, prefix : number) : R {
        return this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
    }

    createAddressInternal$byte_A$java_lang_CharSequence(bytes : number[], zone : any) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(section : R, from : HostIdentifierString) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(section : R, zone : any, from : HostIdentifierString) : T { throw new Error('cannot invoke abstract overloaded method... check your argument(s) type(s)'); }

    createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments : S[], from : HostIdentifierString, prefix : number) : T {
        return this.createAddressInternal(this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix), from);
    }

    public createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_CharSequence$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments : S[], zone : any, from : HostIdentifierString, prefix : number) : T {
        return this.createAddressInternal(this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix), zone, from);
    }

    public createAddressInternal(segments? : any, zone? : any, from? : any, prefix? : any) : any {
        if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && ((typeof prefix === 'number') || prefix === null)) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_CharSequence$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, zone, from, prefix);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof from === 'number') || from === null) && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(segments, zone, from);
        } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((from != null && (from["__interfaces"] != null && from["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || from.constructor != null && from.constructor["__interfaces"] != null && from.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || from === null) && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(segments, zone, from);
        } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(typeof segments[0] === 'number'))) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(segments, zone);
        } else if(((segments != null) || segments === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && from === undefined && prefix === undefined) {
            return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(segments, zone);
        } else throw new Error('invalid overload');
    }

    constructor() {
    }
}
ParsedAddressCreator["__class"] = "inet.ipaddr.format.validate.ParsedAddressCreator";
ParsedAddressCreator["__interfaces"] = ["java.io.Serializable"];




