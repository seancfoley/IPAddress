/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddress } from '../../IPAddress';
import { IPAddressStringParameters } from '../../IPAddressStringParameters';
import { ParsedIPAddress } from './ParsedIPAddress';
import { IPv4AddressStringParameters } from '../../ipv4/IPv4AddressStringParameters';

/**
 * The result of parsing a qualifier for a host name or address, the qualifier being either a mask, prefix length, or zone that follows the string.
 * 
 * @author sfoley
 * @class
 */
export class ParsedHostIdentifierStringQualifier {
    static serialVersionUID : number = 4;

    /*private*/ networkPrefixLength : number;

    /*private*/ port : number;

    /*private*/ service : any;

    /*private*/ mask : ParsedIPAddress;

    /*private*/ zone : any;

    public constructor(networkPrefixLength? : any, mask? : any, zone? : any, port? : any, service? : any) {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((mask != null && mask instanceof <any>ParsedIPAddress) || mask === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((typeof port === 'number') || port === null) && ((service != null && (service["__interfaces"] != null && service["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || service.constructor != null && service.constructor["__interfaces"] != null && service.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof service === "string")) || service === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.port===undefined) this.port = null;
            if(this.service===undefined) this.service = null;
            if(this.mask===undefined) this.mask = null;
            if(this.zone===undefined) this.zone = null;
            if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
            if(this.port===undefined) this.port = null;
            if(this.service===undefined) this.service = null;
            if(this.mask===undefined) this.mask = null;
            if(this.zone===undefined) this.zone = null;
            (() => {
                this.networkPrefixLength = networkPrefixLength;
                this.mask = mask;
                this.zone = zone;
                this.port = port;
                this.service = service;
            })();
        } else if(((networkPrefixLength != null && (networkPrefixLength["__interfaces"] != null && networkPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || networkPrefixLength.constructor != null && networkPrefixLength.constructor["__interfaces"] != null && networkPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof networkPrefixLength === "string")) || networkPrefixLength === null) && ((typeof mask === 'number') || mask === null) && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let zone : any = __args[0];
            let port : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let mask : any = null;
                let service : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((mask != null && (mask["__interfaces"] != null && mask["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || mask.constructor != null && mask.constructor["__interfaces"] != null && mask.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof mask === "string")) || mask === null) && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let mask : any = null;
                let port : any = null;
                let service : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
        } else if(((networkPrefixLength != null && networkPrefixLength instanceof <any>ParsedIPAddress) || networkPrefixLength === null) && ((mask != null && (mask["__interfaces"] != null && mask["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || mask.constructor != null && mask.constructor["__interfaces"] != null && mask.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof mask === "string")) || mask === null) && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let mask : any = __args[0];
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let port : any = null;
                let service : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
        } else if(((networkPrefixLength != null && (networkPrefixLength["__interfaces"] != null && networkPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || networkPrefixLength.constructor != null && networkPrefixLength.constructor["__interfaces"] != null && networkPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof networkPrefixLength === "string")) || networkPrefixLength === null) && ((mask != null && (mask["__interfaces"] != null && mask["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || mask.constructor != null && mask.constructor["__interfaces"] != null && mask.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof mask === "string")) || mask === null) && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let zone : any = __args[0];
            let service : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let mask : any = null;
                let port : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
            (() => {
                if(zone != null && service != null) {
                    throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
                }
            })();
        } else if(((networkPrefixLength != null && (networkPrefixLength["__interfaces"] != null && networkPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || networkPrefixLength.constructor != null && networkPrefixLength.constructor["__interfaces"] != null && networkPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof networkPrefixLength === "string")) || networkPrefixLength === null) && mask === undefined && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let zone : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let mask : any = null;
                let port : any = null;
                let service : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
        } else if(networkPrefixLength === undefined && mask === undefined && zone === undefined && port === undefined && service === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let mask : any = null;
                let zone : any = null;
                let port : any = null;
                let service : any = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                if(this.networkPrefixLength===undefined) this.networkPrefixLength = null;
                if(this.port===undefined) this.port = null;
                if(this.service===undefined) this.service = null;
                if(this.mask===undefined) this.mask = null;
                if(this.zone===undefined) this.zone = null;
                (() => {
                    this.networkPrefixLength = networkPrefixLength;
                    this.mask = mask;
                    this.zone = zone;
                    this.port = port;
                    this.service = service;
                })();
            }
        } else throw new Error('invalid overload');
    }

    mergePrefix(other : ParsedHostIdentifierStringQualifier) {
        if(other.mask != null) {
            this.mask = other.mask;
        }
        if(other.networkPrefixLength != null) {
            this.networkPrefixLength = other.networkPrefixLength;
        }
    }

    getMask() : IPAddress {
        if(this.mask != null) {
            return this.mask.createAddresses().getAddress();
        }
        return null;
    }

    getEquivalentPrefixLength() : number {
        let pref : number = this.getNetworkPrefixLength();
        if(pref == null) {
            let mask : IPAddress = this.getMask();
            if(mask != null) {
                pref = mask.getBlockMaskPrefixLength(true);
            }
        }
        return pref;
    }

    getZone() : any {
        return this.zone;
    }

    getNetworkPrefixLength() : number {
        return this.networkPrefixLength;
    }

    getPort() : number {
        return this.port;
    }

    getService() : any {
        return this.service;
    }

    inferVersion(validationOptions : IPAddressStringParameters) : IPAddress.IPVersion {
        if(this.networkPrefixLength != null) {
            if(this.networkPrefixLength > IPAddress.getBitCount(IPAddress.IPVersion.IPV4) && !validationOptions.getIPv4Parameters().allowPrefixesBeyondAddressSize) {
                return IPAddress.IPVersion.IPV6;
            }
        } else if(this.mask != null) {
            if(this.mask.isIPv6()) {
                return IPAddress.IPVersion.IPV6;
            } else if(this.mask.isIPv4()) {
                return IPAddress.IPVersion.IPV4;
            }
        } else if(this.zone != null) {
            return IPAddress.IPVersion.IPV6;
        }
        return null;
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return "network prefix length: " + this.networkPrefixLength + " mask: " + this.mask + " zone: " + this.zone + " port: " + this.port + " service: " + this.service;
    }
}
ParsedHostIdentifierStringQualifier["__class"] = "inet.ipaddr.format.validate.ParsedHostIdentifierStringQualifier";
ParsedHostIdentifierStringQualifier["__interfaces"] = ["java.io.Serializable"];




