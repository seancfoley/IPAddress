/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { MACAddressStringParameters } from '../../MACAddressStringParameters';
import { MACAddress } from '../../mac/MACAddress';
import { MACAddressNetwork } from '../../mac/MACAddressNetwork';
import { MACAddressSection } from '../../mac/MACAddressSection';
import { MACAddressSegment } from '../../mac/MACAddressSegment';
import { ParsedMACAddress } from './ParsedMACAddress';
import { ParsedAddressCreator } from './ParsedAddressCreator';

export class MACAddressProvider {
    static serialVersionUID : number = 4;

    /*private*/ parsedAddress : ParsedMACAddress;

    /*private*/ address : MACAddress;

    static EMPTY_PROVIDER : MACAddressProvider; public static EMPTY_PROVIDER_$LI$() : MACAddressProvider { if(MACAddressProvider.EMPTY_PROVIDER == null) MACAddressProvider.EMPTY_PROVIDER = new MACAddressProvider.MACAddressProvider$0(); return MACAddressProvider.EMPTY_PROVIDER; };

    public constructor(parsedAddress? : any) {
        if(((parsedAddress != null && parsedAddress instanceof <any>ParsedMACAddress) || parsedAddress === null)) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
            (() => {
                this.parsedAddress = parsedAddress;
            })();
        } else if(((parsedAddress != null && parsedAddress instanceof <any>MACAddress) || parsedAddress === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
            (() => {
                this.address = address;
            })();
        } else if(parsedAddress === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
            if(this.parsedAddress===undefined) this.parsedAddress = null;
            if(this.address===undefined) this.address = null;
        } else throw new Error('invalid overload');
    }

    public getAddress() : MACAddress {
        if(this.parsedAddress != null) {
            {
                if(this.parsedAddress != null) {
                    this.address = this.parsedAddress.createAddress();
                    this.parsedAddress = null;
                }
            };
        }
        return this.address;
    }

    public static getAllProvider(validationOptions : MACAddressStringParameters) : MACAddressProvider {
        let network : MACAddressNetwork = validationOptions.getNetwork();
        let allAddresses : MACAddressStringParameters.AddressSize = validationOptions.addressSize;
        let creator : MACAddressNetwork.MACAddressCreator = network.getAddressCreator();
        let allRangeSegment : MACAddressSegment = creator.createRangeSegment(0, MACAddress.MAX_VALUE_PER_SEGMENT);
        let segments : MACAddressSegment[] = creator.createSegmentArray(allAddresses === MACAddressStringParameters.AddressSize.EUI64?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.MEDIA_ACCESS_CONTROL_SEGMENT_COUNT);
        /* fill */((a, v) => { for(let i=0;i<a.length;i++) a[i]=v; })(segments, allRangeSegment);
        return new MACAddressProvider.MACAddressProvider$1(creator, segments);
    }

    /**
     * 
     * @return {string}
     */
    public toString() : string {
        return /* valueOf */new String(this.getAddress()).toString();
    }
}
MACAddressProvider["__class"] = "inet.ipaddr.format.validate.MACAddressProvider";
MACAddressProvider["__interfaces"] = ["java.io.Serializable"];



export namespace MACAddressProvider {

    export class MACAddressProvider$0 extends MACAddressProvider {
        /**
         * 
         * @return {MACAddress}
         */
        public getAddress() : MACAddress {
            return null;
        }

        constructor() {
            super();
        }
    }
    MACAddressProvider$0["__interfaces"] = ["java.io.Serializable"];



    export class MACAddressProvider$1 extends MACAddressProvider {
        static serialVersionUID : number = 4;

        /**
         * 
         * @return {MACAddress}
         */
        public getAddress() : MACAddress {
            let parsedCreator : ParsedAddressCreator<MACAddress, MACAddressSection, MACAddressSection, MACAddressSegment> = this.creator;
            let section : MACAddressSection = parsedCreator.createSectionInternal$inet_ipaddr_AddressSegment_A(this.segments);
            return this.creator.createAddress$inet_ipaddr_mac_MACAddressSection(section);
        }

        constructor(private creator: any, private segments: any) {
            super();
        }
    }
    MACAddressProvider$1["__interfaces"] = ["java.io.Serializable"];


}




MACAddressProvider.EMPTY_PROVIDER_$LI$();
