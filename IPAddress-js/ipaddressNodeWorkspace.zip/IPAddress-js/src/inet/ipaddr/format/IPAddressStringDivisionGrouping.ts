/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { IPAddressNetwork } from '../IPAddressNetwork';
import { AddressStringDivisionGrouping } from './AddressStringDivisionGrouping';
import { IPAddressStringDivisionSeries } from './IPAddressStringDivisionSeries';
import { IPAddressStringDivision } from './IPAddressStringDivision';
import { AddressStringDivision } from './AddressStringDivision';
import { AddressNetwork } from '../AddressNetwork';

export class IPAddressStringDivisionGrouping extends AddressStringDivisionGrouping implements IPAddressStringDivisionSeries {
    static __inet_ipaddr_format_IPAddressStringDivisionGrouping_serialVersionUID : number = 4;

    /*private*/ network : IPAddressNetwork<any, any, any, any, any>;

    /*private*/ prefixLength : number;

    public constructor(divisions : IPAddressStringDivision[], network : IPAddressNetwork<any, any, any, any, any>, prefixLength : number) {
        super(divisions);
        if(this.network===undefined) this.network = null;
        if(this.prefixLength===undefined) this.prefixLength = null;
        this.prefixLength = prefixLength;
        this.network = network;
    }

    /**
     * 
     * @return {IPAddressNetwork}
     */
    public getNetwork() : IPAddressNetwork<any, any, any, any, any> {
        return this.network;
    }

    /**
     * 
     * @param {number} index
     * @return {*}
     */
    public getDivision(index : number) : IPAddressStringDivision {
        return <IPAddressStringDivision><any>this.divisions[index];
    }

    /**
     * 
     * @return {boolean}
     */
    public isPrefixed() : boolean {
        return this.prefixLength != null;
    }

    /**
     * 
     * @return {number}
     */
    public getPrefixLength() : number {
        return this.prefixLength;
    }

    /**
     * 
     * @return {boolean}
     */
    public isPrefixBlock() : boolean {
        let networkPrefixLength : number = this.getPrefixLength();
        if(networkPrefixLength == null) {
            return false;
        }
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.network.getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return true;
        }
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressStringDivision = this.getDivision(i);
            let segmentPrefixLength : number = div.getDivisionPrefixLength();
            if(segmentPrefixLength != null) {
                if(!div.isPrefixBlock()) {
                    return false;
                }
                for(++i; i < divCount; i++) {
                    div = this.getDivision(i);
                    if(!div.isFullRange()) {
                        return false;
                    }
                };
            }
        };
        return true;
    }
}
IPAddressStringDivisionGrouping["__class"] = "inet.ipaddr.format.IPAddressStringDivisionGrouping";
IPAddressStringDivisionGrouping["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.IPAddressStringDivisionSeries","java.io.Serializable"];




