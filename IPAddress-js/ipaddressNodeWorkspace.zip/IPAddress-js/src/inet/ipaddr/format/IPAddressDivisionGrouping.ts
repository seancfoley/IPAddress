/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressNetwork } from '../AddressNetwork';
import { AddressValueException } from '../AddressValueException';
import { IPAddress } from '../IPAddress';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressSegment } from '../IPAddressSegment';
import { InconsistentPrefixException } from '../InconsistentPrefixException';
import { IPAddressStringWriter } from './util/IPAddressStringWriter';
import { IPv6Address } from '../ipv6/IPv6Address';
import { AddressDivisionGrouping } from './AddressDivisionGrouping';
import { IPAddressStringDivisionSeries } from './IPAddressStringDivisionSeries';
import { IPAddressDivision } from './IPAddressDivision';
import { AddressDivision } from './AddressDivision';
import { AddressDivisionSeries } from './AddressDivisionSeries';
import { IPAddressSection } from '../IPAddressSection';
import { IPAddressStringDivision } from './IPAddressStringDivision';

/**
 * If the grouping is prefixed, then note that we allow both null:null:x:0:0 where is x is the division bit count and null:null:0:0:0 which essentially have the same overall prefix grouping prefix.
 * For further discussion of this, see {@link AddressDivisionGrouping#normalizePrefixBoundary(int, IPAddressSegment[], int, int, java.util.function.BiFunction)}
 * 
 * @param {Array} divisions
 * @param {IPAddressNetwork} network
 * @throws NullPointerException if network is null or a division is null
 * @class
 * @extends AddressDivisionGrouping
 * @author sfoley
 */
export class IPAddressDivisionGrouping extends AddressDivisionGrouping implements IPAddressStringDivisionSeries {
    static __static_initialized : boolean = false;
    static __static_initialize() { if(!IPAddressDivisionGrouping.__static_initialized) { IPAddressDivisionGrouping.__static_initialized = true; IPAddressDivisionGrouping.__static_initializer_0(); } }

    static __inet_ipaddr_format_IPAddressDivisionGrouping_serialVersionUID : number = 4;

    /*private*/ network : IPAddressNetwork<any, any, any, any, any>;

    static ZEROS_CACHE : IPAddressDivisionGrouping.RangeCache; public static ZEROS_CACHE_$LI$() : IPAddressDivisionGrouping.RangeCache { IPAddressDivisionGrouping.__static_initialize(); if(IPAddressDivisionGrouping.ZEROS_CACHE == null) IPAddressDivisionGrouping.ZEROS_CACHE = new IPAddressDivisionGrouping.RangeCache(); return IPAddressDivisionGrouping.ZEROS_CACHE; };

    static __static_initializer_0() {
        if(IPAddressDivisionGrouping.RangeCache.PRELOAD_CACHE) {
            IPAddressDivisionGrouping.ZEROS_CACHE_$LI$().preloadCache(-1);
        }
    }

    public constructor(divisions? : any, network? : any) {
        if(((divisions != null && divisions instanceof <any>Array && (divisions.length==0 || divisions[0] == null ||(divisions[0] != null && divisions[0] instanceof <any>IPAddressDivision))) || divisions === null) && ((network != null && network instanceof <any>IPAddressNetwork) || network === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(divisions);
            if(this.network===undefined) this.network = null;
            if(this.network===undefined) this.network = null;
            (() => {
                if(network == null) {
                    throw Object.defineProperty(new Error(AddressDivisionGrouping.getMessage("ipaddress.error.nullNetwork")), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                }
                this.network = network;
                let totalPrefixBits : number = 0;
                for(let i : number = 0; i < divisions.length; i++) {
                    let division : IPAddressDivision = divisions[i];
                    let divPrefix : number = division.getDivisionPrefixLength();
                    if(divPrefix != null) {
                        this.cachedPrefixLength = totalPrefixBits + divPrefix;
                        for(++i; i < divisions.length; i++) {
                            division = divisions[i];
                            divPrefix = division.getDivisionPrefixLength();
                            if(divPrefix == null || divPrefix !== 0) {
                                throw new InconsistentPrefixException(divisions[i - 1], division, divPrefix);
                            }
                        };
                        return;
                    }
                    totalPrefixBits += division.getBitCount();
                };
                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            })();
        } else if(((divisions != null && divisions instanceof <any>Array && (divisions.length==0 || divisions[0] == null ||(divisions[0] != null && divisions[0] instanceof <any>IPAddressDivision))) || divisions === null) && ((typeof network === 'boolean') || network === null)) {
            let __args = Array.prototype.slice.call(arguments);
            let checkSegs : any = __args[1];
            super(divisions, checkSegs);
            if(this.network===undefined) this.network = null;
            if(this.network===undefined) this.network = null;
            (() => {
                this.network = this.getNetwork();
                if(this.network == null) {
                    throw Object.defineProperty(new Error(AddressDivisionGrouping.getMessage("ipaddress.error.nullNetwork")), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
                }
            })();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPAddressNetwork}
     */
    public getNetwork() : IPAddressNetwork<any, any, any, any, any> {
        return this.network;
    }

    /**
     * 
     * @param {number} index
     * @return {IPAddressDivision}
     */
    public getDivision(index : number) : IPAddressDivision {
        return <IPAddressDivision>super.getDivision(index);
    }

    /**
     * 
     * @param {*} other
     * @return {number}
     */
    public isMore(other : AddressDivisionSeries) : number {
        if(!this.isMultiple()) {
            return other.isMultiple()?-1:0;
        }
        if(!other.isMultiple()) {
            return 1;
        }
        if(this.isSinglePrefixBlock() && other.isSinglePrefixBlock()) {
            let bits : number = this.getBitCount() - this.getPrefixLength();
            let otherBits : number = other.getBitCount() - other.getPrefixLength();
            return bits - otherBits;
        }
        return this.getCount().compareTo(other.getCount());
    }

    /**
     * @return {boolean} whether this address represents a network prefix or the set of all addresses with the same network prefix
     */
    public isPrefixed() : boolean {
        return this.getNetworkPrefixLength() != null;
    }

    /**
     * 
     * @return {number}
     */
    public getPrefixLength() : number {
        return this.getNetworkPrefixLength();
    }

    calculatePrefix() : number {
        let result : number = 0;
        let count : number = this.getDivisionCount();
        for(let i : number = 0; i < count; i++) {
            let div : IPAddressDivision = this.getDivision(i);
            let prefix : number = div.getDivisionPrefixLength();
            if(prefix != null) {
                result += prefix;
                return result;
            } else {
                result += div.getBitCount();
            }
        };
        return null;
    }

    public getNetworkPrefixLength(segmentIndex? : any, segmentPrefix? : any) : any {
        if(segmentIndex === undefined && segmentPrefix === undefined) {
            return <any>this.getNetworkPrefixLength$();
        } else throw new Error('invalid overload');
    }

    public getNetworkPrefixLength$() : number {
        let ret : number = this.cachedPrefixLength;
        if(ret == null) {
            let count : number = this.getDivisionCount();
            if(count > 0) {
                if(!AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets() || this.getDivision(count - 1).isPrefixed()) {
                    let result : number = this.calculatePrefix();
                    if(result != null) {
                        return this.cachedPrefixLength = result;
                    }
                }
            }
            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            return null;
        }
        if(ret === AddressDivisionGrouping.NO_PREFIX_LENGTH) {
            return null;
        }
        return ret;
    }

    /**
     * Returns whether this address section represents a subnet block of addresses associated its prefix length.
     * 
     * Returns false if it has no prefix length, if it is a single address with a prefix length (ie not a subnet), or if it is a range of addresses that does not include
     * the entire subnet block for its prefix length.
     * 
     * If {@link AddressNetwork#getPrefixConfiguration} is set to consider all prefixes as subnets, this returns true for any grouping with prefix length.
     * 
     * @return
     * @return {boolean}
     */
    public isPrefixBlock() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null) {
            return false;
        }
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return true;
        }
        return this.containsPrefixBlock(networkPrefixLength);
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {boolean}
     */
    public containsPrefixBlock(prefixLength : number) : boolean {
        this.checkSubnet(prefixLength);
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        if(isAllSubnets && this.isPrefixed() && this.getNetworkPrefixLength() <= prefixLength) {
            return true;
        }
        let prevBitCount : number = 0;
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressDivision = this.getDivision(i);
            let bitCount : number = div.getBitCount();
            let totalBitCount : number = bitCount + prevBitCount;
            if(prefixLength < totalBitCount) {
                let divPrefixLen : number = Math.max(0, prefixLength - prevBitCount);
                if(!div.isPrefixBlock$int(divPrefixLen)) {
                    return false;
                }
                if(isAllSubnets && div.isPrefixed()) {
                    return true;
                }
                for(++i; i < divCount; i++) {
                    div = this.getDivision(i);
                    if(!div.isFullRange()) {
                        return false;
                    }
                    if(isAllSubnets && div.isPrefixed()) {
                        return true;
                    }
                };
                return true;
            }
            prevBitCount = totalBitCount;
        };
        return true;
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {boolean}
     */
    public containsSinglePrefixBlock(prefixLength : number) : boolean {
        this.checkSubnet(prefixLength);
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        if(isAllSubnets && this.isPrefixed() && this.getNetworkPrefixLength() < prefixLength) {
            return false;
        }
        let prevBitCount : number = 0;
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressDivision = this.getDivision(i);
            let bitCount : number = div.getBitCount();
            let totalBitCount : number = bitCount + prevBitCount;
            if(prefixLength >= totalBitCount) {
                if(div.isMultiple()) {
                    return false;
                }
            } else {
                let divPrefixLen : number = Math.max(0, prefixLength - prevBitCount);
                if(!div.isSinglePrefixBlock$int(divPrefixLen)) {
                    return false;
                }
                if(isAllSubnets && div.isPrefixed()) {
                    return true;
                }
                for(++i; i < divCount; i++) {
                    div = this.getDivision(i);
                    if(!div.isFullRange()) {
                        return false;
                    }
                    if(isAllSubnets && div.isPrefixed()) {
                        return true;
                    }
                };
                return true;
            }
            prevBitCount = totalBitCount;
        };
        return true;
    }

    /**
     * Returns whether the division grouping range matches the block of values for its prefix length.
     * In other words, returns true if and only if it has a prefix length and it has just a single prefix.
     * @return {boolean}
     */
    public isSinglePrefixBlock() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null) {
            return false;
        }
        return this.containsSinglePrefixBlock(networkPrefixLength);
    }

    /**
     * 
     * @return {number}
     */
    public getPrefixLengthForSingleBlock() : number {
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            let totalPrefix : number = 0;
            let divCount : number = this.getDivisionCount();
            for(let i : number = 0; i < divCount; i++) {
                let div : IPAddressDivision = this.getDivision(i);
                let segPrefix : number = div.getMinPrefixLengthForBlock();
                if(!div.isSinglePrefixBlock$int(segPrefix)) {
                    return null;
                }
                if(div.isPrefixed()) {
                    return totalPrefix + segPrefix;
                }
                if(segPrefix < div.getBitCount()) {
                    for(i++; i < divCount; i++) {
                        let laterDiv : IPAddressDivision = this.getDivision(i);
                        if(!laterDiv.isFullRange()) {
                            return null;
                        }
                        if(laterDiv.isPrefixed()) {
                            break;
                        }
                    };
                    return totalPrefix + segPrefix;
                }
                totalPrefix += segPrefix;
            };
            return totalPrefix;
        }
        return super.getPrefixLengthForSingleBlock();
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {boolean}
     */
    public includesZeroHost(networkPrefixLength? : any) : any {
        if(networkPrefixLength === undefined) {
            return <any>this.includesZeroHost$();
        } else throw new Error('invalid overload');
    }

    public includesZeroHost$() : boolean {
        let networkPrefixLength : number = this.getNetworkPrefixLength();
        if(networkPrefixLength == null || networkPrefixLength >= this.getBitCount()) {
            return false;
        }
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return true;
        }
        let divCount : number = this.getDivisionCount();
        for(let i : number = 0; i < divCount; i++) {
            let div : IPAddressDivision = this.getDivision(i);
            let segmentPrefixLength : number = div.getDivisionPrefixLength();
            if(segmentPrefixLength != null) {
                let mask : number = ~(~0 << (div.getBitCount() - segmentPrefixLength));
                if((mask & div.getLowerValue()) !== 0) {
                    return false;
                }
                for(++i; i < divCount; i++) {
                    div = this.getDivision(i);
                    if(!div.includesZero()) {
                        return false;
                    }
                };
            }
        };
        return true;
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>IPAddressDivisionGrouping) {
            let other : IPAddressDivisionGrouping = <IPAddressDivisionGrouping>o;
            return other.isSameGrouping(this);
        }
        return false;
    }

    public getZeroSegments$() : IPAddressDivisionGrouping.RangeList {
        return this.getZeroSegments$boolean(false);
    }

    /**
     * @return {IPAddressDivisionGrouping.RangeList} the segments which are zero or whose prefix-based range includes 0
     */
    public getZeroRangeSegments() : IPAddressDivisionGrouping.RangeList {
        if(this.isPrefixed()) {
            return this.getZeroSegments$boolean(true);
        }
        return this.getZeroSegments();
    }

    static getNoZerosRange() : IPAddressDivisionGrouping.RangeList {
        return IPAddressDivisionGrouping.RangeCache.NO_ZEROS_$LI$();
    }

    static getSingleRange(index : number, len : number) : IPAddressDivisionGrouping.RangeList {
        let cache : IPAddressDivisionGrouping.RangeCache = IPAddressDivisionGrouping.ZEROS_CACHE_$LI$().addRange(index, -1, len);
        return cache.get();
    }

    public getZeroSegments$boolean(includeRanges : boolean) : IPAddressDivisionGrouping.RangeList {
        let cache : IPAddressDivisionGrouping.RangeCache = IPAddressDivisionGrouping.ZEROS_CACHE_$LI$();
        let divisionCount : number = this.getDivisionCount();
        let isFullRangeHost : boolean = !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].prefixedSubnetsAreExplicit() && this.isPrefixBlock();
        includeRanges = isFullRangeHost && includeRanges;
        let currentIndex : number = -1;
        let lastIndex : number = -1;
        let currentCount : number = 0;
        for(let i : number = 0; i < divisionCount; i++) {
            let division : IPAddressDivision = this.getDivision(i);
            let isCompressible : boolean = division.isZero() || (includeRanges && division.isPrefixed() && division.isSinglePrefixBlock$long$int(0, division.getDivisionPrefixLength()));
            if(isCompressible) {
                if(++currentCount === 1) {
                    currentIndex = i;
                }
                if(i === divisionCount - 1) {
                    cache = cache.addRange(currentIndex, lastIndex, currentCount);
                    lastIndex = currentIndex + currentCount;
                }
            } else if(currentCount > 0) {
                cache = cache.addRange(currentIndex, lastIndex, currentCount);
                lastIndex = currentIndex + currentCount;
                currentCount = 0;
            }
        };
        return cache.get();
    }

    public getZeroSegments(includeRanges? : any) : any {
        if(((typeof includeRanges === 'boolean') || includeRanges === null)) {
            return <any>this.getZeroSegments$boolean(includeRanges);
        } else if(includeRanges === undefined) {
            return <any>this.getZeroSegments$();
        } else throw new Error('invalid overload');
    }
}
IPAddressDivisionGrouping["__class"] = "inet.ipaddr.format.IPAddressDivisionGrouping";
IPAddressDivisionGrouping["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.format.IPAddressStringDivisionSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



export namespace IPAddressDivisionGrouping {

    export class Range {
        public index : number;

        public length : number;

        constructor(index : number, length : number) {
            if(this.index===undefined) this.index = 0;
            if(this.length===undefined) this.length = 0;
            this.index = index;
            this.length = length;
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            return "[" + this.index + ',' + (this.index + this.length) + ']';
        }
    }
    Range["__class"] = "inet.ipaddr.format.IPAddressDivisionGrouping.Range";


    export class RangeList {
        ranges : IPAddressDivisionGrouping.Range[];

        constructor(ranges : IPAddressDivisionGrouping.Range[]) {
            if(this.ranges===undefined) this.ranges = null;
            if(ranges == null) {
                throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.NullPointerException','java.lang.Exception'] });
            }
            this.ranges = ranges;
        }

        public size() : number {
            return this.ranges.length;
        }

        public getRange(index : number) : IPAddressDivisionGrouping.Range {
            return this.ranges[index];
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            return /* toString */('['+/* asList */this.ranges.slice(0).join(', ')+']');
        }
    }
    RangeList["__class"] = "inet.ipaddr.format.IPAddressDivisionGrouping.RangeList";


    /**
     * A cache of ZeroRange objects in a tree structure.
     * 
     * Starting from the root of the tree, as you traverse an address grouping from left to right,
     * if you have another range located at offset x from the last one, and it has length y,
     * then you follow nextRange[x][y] in the tree.
     * 
     * When you have no more ranges (and this no more tree nodes to follow), then you can use the field for the cached ZeroRanges object
     * which is associated with the path you've followed (which corresponds to the zero-ranges in the address).
     * 
     * @author sfoley
     * @class
     */
    export class RangeCache {
        static PRELOAD_CACHE : boolean = false;

        static MAX_DIVISION_COUNT : number; public static MAX_DIVISION_COUNT_$LI$() : number { if(RangeCache.MAX_DIVISION_COUNT == null) RangeCache.MAX_DIVISION_COUNT = IPv6Address.SEGMENT_COUNT; return RangeCache.MAX_DIVISION_COUNT; };

        static NO_ZEROS : IPAddressDivisionGrouping.RangeList; public static NO_ZEROS_$LI$() : IPAddressDivisionGrouping.RangeList { if(RangeCache.NO_ZEROS == null) RangeCache.NO_ZEROS = new IPAddressDivisionGrouping.RangeList([]); return RangeCache.NO_ZEROS; };

        nextRange : IPAddressDivisionGrouping.RangeCache[][];

        parent : IPAddressDivisionGrouping.RangeCache;

        zeroRanges : IPAddressDivisionGrouping.RangeList;

        range : IPAddressDivisionGrouping.Range;

        public constructor(parent? : any, potentialZeroOffsets? : any, range? : any) {
            if(((parent != null && parent instanceof <any>IPAddressDivisionGrouping.RangeCache) || parent === null) && ((typeof potentialZeroOffsets === 'number') || potentialZeroOffsets === null) && ((range != null && range instanceof <any>IPAddressDivisionGrouping.Range) || range === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.nextRange===undefined) this.nextRange = null;
                if(this.parent===undefined) this.parent = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.range===undefined) this.range = null;
                if(this.nextRange===undefined) this.nextRange = null;
                if(this.parent===undefined) this.parent = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.range===undefined) this.range = null;
                (() => {
                    if(potentialZeroOffsets > 0) {
                        this.nextRange = (s => { let a=[]; while(s-->0) a.push(null); return a; })(potentialZeroOffsets);
                        for(let i : number = 0; i < potentialZeroOffsets; i++) {
                            this.nextRange[i] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(potentialZeroOffsets - i);
                        };
                    }
                    this.parent = parent;
                    this.range = range;
                })();
            } else if(parent === undefined && potentialZeroOffsets === undefined && range === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let parent : any = null;
                    let potentialZeroOffsets : any = RangeCache.MAX_DIVISION_COUNT_$LI$();
                    let range : any = null;
                    if(this.nextRange===undefined) this.nextRange = null;
                    if(this.parent===undefined) this.parent = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.range===undefined) this.range = null;
                    if(this.nextRange===undefined) this.nextRange = null;
                    if(this.parent===undefined) this.parent = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.range===undefined) this.range = null;
                    (() => {
                        if(potentialZeroOffsets > 0) {
                            this.nextRange = (s => { let a=[]; while(s-->0) a.push(null); return a; })(potentialZeroOffsets);
                            for(let i : number = 0; i < potentialZeroOffsets; i++) {
                                this.nextRange[i] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(potentialZeroOffsets - i);
                            };
                        }
                        this.parent = parent;
                        this.range = range;
                    })();
                }
                (() => {
                    this.zeroRanges = RangeCache.NO_ZEROS_$LI$();
                })();
            } else throw new Error('invalid overload');
        }

        public get$inet_ipaddr_format_IPAddressDivisionGrouping_Range_A$int(ranges : IPAddressDivisionGrouping.Range[], rangesIndex : number) {
            ranges[--rangesIndex] = this.range;
            if(rangesIndex > 0) {
                this.parent.get$inet_ipaddr_format_IPAddressDivisionGrouping_Range_A$int(ranges, rangesIndex);
            }
        }

        public get(ranges? : any, rangesIndex? : any) : any {
            if(((ranges != null && ranges instanceof <any>Array && (ranges.length==0 || ranges[0] == null ||(ranges[0] != null && ranges[0] instanceof <any>IPAddressDivisionGrouping.Range))) || ranges === null) && ((typeof rangesIndex === 'number') || rangesIndex === null)) {
                return <any>this.get$inet_ipaddr_format_IPAddressDivisionGrouping_Range_A$int(ranges, rangesIndex);
            } else if(ranges === undefined && rangesIndex === undefined) {
                return <any>this.get$();
            } else throw new Error('invalid overload');
        }

        public get$() : IPAddressDivisionGrouping.RangeList {
            let result : IPAddressDivisionGrouping.RangeList = this.zeroRanges;
            if(result == null) {
                let depth : number = 0;
                let up : IPAddressDivisionGrouping.RangeCache = this.parent;
                while((up != null)) {
                    depth++;
                    up = up.parent;
                };
                let ranges : IPAddressDivisionGrouping.Range[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(depth);
                if(depth > 0) {
                    ranges[--depth] = this.range;
                    if(depth > 0) {
                        this.parent.get$inet_ipaddr_format_IPAddressDivisionGrouping_Range_A$int(ranges, depth);
                    }
                }
                this.zeroRanges = result = new IPAddressDivisionGrouping.RangeList(ranges);
            }
            return result;
        }

        preloadCache(lastIndex : number) {
            if(this.nextRange != null) {
                for(let i : number = 0; i < this.nextRange.length; i++) {
                    let next : IPAddressDivisionGrouping.RangeCache[] = this.nextRange[i];
                    for(let j : number = 0; j < next.length; j++) {
                        let newRange : IPAddressDivisionGrouping.Range;
                        if(lastIndex === -1) {
                            newRange = new IPAddressDivisionGrouping.Range(i + lastIndex + 1, j + 1);
                        } else {
                            newRange = IPAddressDivisionGrouping.ZEROS_CACHE_$LI$().nextRange[i + lastIndex + 1][j].range;
                        }
                        let nextPotentialZeroIndex : number = i + lastIndex + j + 3;
                        let remainingPotentialZeroOffsets : number = IPAddressDivisionGrouping.RangeCache.MAX_DIVISION_COUNT_$LI$() - nextPotentialZeroIndex;
                        let newRangeCache : IPAddressDivisionGrouping.RangeCache = new IPAddressDivisionGrouping.RangeCache(this, remainingPotentialZeroOffsets, newRange);
                        newRangeCache.get();
                        next[j] = newRangeCache;
                    };
                };
                for(let i : number = 0; i < this.nextRange.length; i++) {
                    let next : IPAddressDivisionGrouping.RangeCache[] = this.nextRange[i];
                    for(let j : number = 0; j < next.length; j++) {
                        let nextCache : IPAddressDivisionGrouping.RangeCache = next[j];
                        let nextRange : IPAddressDivisionGrouping.Range = nextCache.range;
                        nextCache.preloadCache(nextRange.index + nextRange.length);
                    };
                };
            }
        }

        public addRange(currentIndex : number, lastIndex : number, currentCount : number) : IPAddressDivisionGrouping.RangeCache {
            let offset : number = currentIndex - lastIndex;
            let cacheOffset : number = offset - 1;
            let cacheCount : number = currentCount - 1;
            let next : IPAddressDivisionGrouping.RangeCache = this.nextRange[cacheOffset][cacheCount];
            if(next == null) {
                {
                    next = this.nextRange[cacheOffset][cacheCount];
                    if(next == null) {
                        let nextPotentialZeroIndex : number = lastIndex + 1;
                        let remainingPotentialZeroOffsets : number = IPAddressDivisionGrouping.RangeCache.MAX_DIVISION_COUNT_$LI$() - nextPotentialZeroIndex;
                        let newRange : IPAddressDivisionGrouping.Range;
                        if(this === IPAddressDivisionGrouping.ZEROS_CACHE_$LI$()) {
                            newRange = new IPAddressDivisionGrouping.Range(currentIndex, currentCount);
                        } else {
                            let rootNext : IPAddressDivisionGrouping.RangeCache = IPAddressDivisionGrouping.ZEROS_CACHE_$LI$().nextRange[currentIndex][currentCount - 1];
                            if(rootNext == null) {
                                IPAddressDivisionGrouping.ZEROS_CACHE_$LI$().nextRange[currentIndex][currentCount - 1] = new IPAddressDivisionGrouping.RangeCache(IPAddressDivisionGrouping.ZEROS_CACHE_$LI$(), IPAddressDivisionGrouping.RangeCache.MAX_DIVISION_COUNT_$LI$(), newRange = new IPAddressDivisionGrouping.Range(currentIndex, currentCount));
                            } else {
                                newRange = rootNext.range;
                            }
                        }
                        this.nextRange[cacheOffset][cacheCount] = next = new IPAddressDivisionGrouping.RangeCache(this, remainingPotentialZeroOffsets, newRange);
                    }
                };
            }
            return next;
        }
    }
    RangeCache["__class"] = "inet.ipaddr.format.IPAddressDivisionGrouping.RangeCache";


    /**
     * Each StringParams has settings to write exactly one type of IP address part string.
     * 
     * @author sfoley
     * @param {number} radix
     * @param {string} separator
     * @param {boolean} uppercase
     * @param {string} zoneSeparator
     * @class
     * @extends AddressDivisionGrouping.AddressStringParams
     */
    export class IPAddressStringParams<T extends IPAddressStringDivisionSeries> extends AddressDivisionGrouping.AddressStringParams<T> implements IPAddressStringWriter<T> {
        public static DEFAULT_WILDCARD_OPTION : WildcardOptions.WildcardOption; public static DEFAULT_WILDCARD_OPTION_$LI$() : WildcardOptions.WildcardOption { if(IPAddressStringParams.DEFAULT_WILDCARD_OPTION == null) IPAddressStringParams.DEFAULT_WILDCARD_OPTION = WildcardOptions.WildcardOption.NETWORK_ONLY; return IPAddressStringParams.DEFAULT_WILDCARD_OPTION; };

        static EXTRA_SPACE : number = 16;

        wildcardOption : WildcardOptions.WildcardOption;

        __expandSegment : number[];

        addressSuffix : string;

        public constructor(radix? : any, separator? : any, uppercase? : any, zoneSeparator? : any) {
            if(((typeof radix === 'number') || radix === null) && ((typeof separator === 'string') || separator === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof zoneSeparator === 'string') || zoneSeparator === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(radix, separator, uppercase, zoneSeparator);
                if(this.__expandSegment===undefined) this.__expandSegment = null;
                this.wildcardOption = IPAddressStringParams.DEFAULT_WILDCARD_OPTION_$LI$();
                this.addressSuffix = "";
                if(this.__expandSegment===undefined) this.__expandSegment = null;
            } else if(((typeof radix === 'number') || radix === null) && ((typeof separator === 'string') || separator === null) && ((typeof uppercase === 'boolean') || uppercase === null) && zoneSeparator === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zoneSeparator : any = String.fromCharCode(0);
                    super(radix, separator, uppercase, zoneSeparator);
                    if(this.__expandSegment===undefined) this.__expandSegment = null;
                    this.wildcardOption = IPAddressStringParams.DEFAULT_WILDCARD_OPTION_$LI$();
                    this.addressSuffix = "";
                    if(this.__expandSegment===undefined) this.__expandSegment = null;
                }
            } else throw new Error('invalid overload');
        }

        public getAddressSuffix() : string {
            return this.addressSuffix;
        }

        public setAddressSuffix(suffix : string) {
            this.addressSuffix = suffix;
        }

        /**
         * 
         * @return {boolean}
         */
        public preferWildcards() : boolean {
            return this.wildcardOption === WildcardOptions.WildcardOption.ALL;
        }

        public setWildcardOption(option : WildcardOptions.WildcardOption) {
            this.wildcardOption = option;
        }

        public getExpandedSegmentLength(segmentIndex : number) : number {
            if(this.__expandSegment == null || this.__expandSegment.length <= segmentIndex) {
                return 0;
            }
            return this.__expandSegment[segmentIndex];
        }

        public expandSegment(index : number, expansionLength : number, segmentCount : number) {
            if(this.__expandSegment == null) {
                this.__expandSegment = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segmentCount);
            }
            this.__expandSegment[index] = expansionLength;
        }

        /**
         * 
         * @return {string}
         */
        public getTrailingSegmentSeparator() : string {
            return String.fromCharCode(this.separator);
        }

        public appendSuffix(builder : { str: string }) : { str: string } {
            let suffix : string = this.getAddressSuffix();
            if(suffix != null) {
                /* append */(sb => { sb.str = sb.str.concat(<any>suffix); return sb; })(builder);
            }
            return builder;
        }

        public getAddressSuffixLength() : number {
            let suffix : string = this.getAddressSuffix();
            if(suffix != null) {
                return suffix.length;
            }
            return 0;
        }

        /**
         * 
         * @param {number} segmentIndex
         * @return {number}
         */
        public getLeadingZeros(segmentIndex : number) : number {
            if(this.__expandSegments) {
                return -1;
            } else if(this.__expandSegment != null && this.__expandSegment.length > segmentIndex) {
                return this.__expandSegment[segmentIndex];
            }
            return 0;
        }

        /**
         * 
         * @return {IPAddressDivisionGrouping.IPAddressStringParams}
         */
        public clone() : IPAddressDivisionGrouping.IPAddressStringParams<T> {
            let parms : IPAddressDivisionGrouping.IPAddressStringParams<T> = <IPAddressDivisionGrouping.IPAddressStringParams<T>>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
            if(this.__expandSegment != null) {
                parms.__expandSegment = /* clone */this.__expandSegment.slice(0);
            }
            return parms;
        }

        /**
         * 
         * @param {IPv6AddressSection} addr
         * @return {number}
         */
        public getTrailingSeparatorCount(addr? : any) : any {
            if(((addr != null) || addr === null)) {
                return <any>this.getTrailingSeparatorCount$inet_ipaddr_format_IPAddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public getTrailingSeparatorCount$inet_ipaddr_format_IPAddressStringDivisionSeries(addr : T) : number {
            let count : number = addr.getDivisionCount();
            if(count > 0) {
                return count - 1;
            }
            return 0;
        }

        public static getPrefixIndicatorStringLength(addr : IPAddressStringDivisionSeries) : number {
            if(addr.isPrefixed()) {
                return AddressDivision.toUnsignedStringLengthFast(addr.getPrefixLength(), 10) + 1;
            }
            return 0;
        }

        public getStringLength(addr? : any, zone? : any) : any {
            if(((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                super.getStringLength(addr, zone);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_format_IPAddressStringDivisionSeries(addr);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_format_AddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public getStringLength$inet_ipaddr_format_IPAddressStringDivisionSeries(addr : T) : number {
            let count : number = this.getSegmentsStringLength(addr);
            if(!this.isReverse() && !this.preferWildcards()) {
                count += IPAddressStringParams.getPrefixIndicatorStringLength(addr);
            }
            return count + this.getAddressSuffixLength() + this.getAddressLabelLength();
        }

        public appendPrefixIndicator(builder : { str: string }, addr : IPAddressStringDivisionSeries) {
            if(addr.isPrefixed()) {
                /* append */(sb => { sb.str = sb.str.concat(<any>addr.getPrefixLength()); return sb; })(/* append */(sb => { sb.str = sb.str.concat(<any>IPAddress.PREFIX_LEN_SEPARATOR); return sb; })(builder));
            }
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {IPv6AddressSection} addr
         * @param {*} zone
         * @return {{ str: string }}
         */
        public append(builder? : any, addr? : any, zone? : any) : any {
            if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_IPAddressStringDivisionSeries$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && zone === undefined) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder, addr);
            } else throw new Error('invalid overload');
        }

        public append$java_lang_StringBuilder$inet_ipaddr_format_IPAddressStringDivisionSeries$java_lang_CharSequence(builder : { str: string }, addr : T, zone : any) : { str: string } {
            this.appendSuffix(this.appendZone(this.appendSegments(this.appendLabel(builder), addr), zone));
            if(!this.isReverse() && !this.preferWildcards()) {
                this.appendPrefixIndicator(builder, addr);
            }
            return builder;
        }

        public appendSegment$int$java_lang_StringBuilder$inet_ipaddr_format_IPAddressStringDivisionSeries(segmentIndex : number, builder : { str: string }, part : T) : number {
            let seg : IPAddressStringDivision = part.getDivision(segmentIndex);
            let config : AddressNetwork.PrefixConfiguration = part.getNetwork().getPrefixConfiguration();
            let prefix : number;
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][config].prefixedSubnetsAreExplicit() || this.preferWildcards() || (prefix = seg.getDivisionPrefixLength()) == null || prefix >= seg.getBitCount() || (AddressNetwork.PrefixConfiguration["_$wrappers"][config].zeroHostsAreSubnets() && !part.isPrefixBlock()) || this.isSplitDigits()) {
                return seg.getStandardString(segmentIndex, this, builder);
            }
            if(seg.isSinglePrefixBlock()) {
                return seg.getLowerStandardString(segmentIndex, this, builder);
            }
            return seg.getPrefixAdjustedRangeString(segmentIndex, this, builder);
        }

        /**
         * 
         * @param {number} segmentIndex
         * @param {{ str: string }} builder
         * @param {*} part
         * @return {number}
         */
        public appendSegment(segmentIndex? : any, builder? : any, part? : any) : any {
            if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((builder != null && (builder instanceof Object)) || builder === null) && ((part != null) || part === null)) {
                return <any>this.appendSegment$int$java_lang_StringBuilder$inet_ipaddr_format_IPAddressStringDivisionSeries(segmentIndex, builder, part);
            } else if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((builder != null && (builder instanceof Object)) || builder === null) && ((part != null) || part === null)) {
                return <any>this.appendSegment$int$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(segmentIndex, builder, part);
            } else throw new Error('invalid overload');
        }
    }
    IPAddressStringParams["__class"] = "inet.ipaddr.format.IPAddressDivisionGrouping.IPAddressStringParams";
    IPAddressStringParams["__interfaces"] = ["inet.ipaddr.format.util.AddressDivisionWriter","inet.ipaddr.format.util.AddressSegmentParams","java.lang.Cloneable","inet.ipaddr.format.util.IPAddressStringWriter"];


}




IPAddressDivisionGrouping.IPAddressStringParams.DEFAULT_WILDCARD_OPTION_$LI$();

IPAddressDivisionGrouping.RangeCache.NO_ZEROS_$LI$();

IPAddressDivisionGrouping.RangeCache.MAX_DIVISION_COUNT_$LI$();

IPAddressDivisionGrouping.ZEROS_CACHE_$LI$();

IPAddressDivisionGrouping.__static_initialize();
