/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressConversionException } from '../AddressConversionException';
import { AddressValueException } from '../AddressValueException';
import { IPAddress } from '../IPAddress';
import { IPAddressConverter } from '../IPAddressConverter';
import { IPAddressSegmentSeries } from '../IPAddressSegmentSeries';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { IPAddressStringDivisionSeries } from '../format/IPAddressStringDivisionSeries';
import { IPAddressPartStringCollection } from '../format/util/IPAddressPartStringCollection';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { IPv6AddressSegment } from '../ipv6/IPv6AddressSegment';
import { IPv4AddressSection } from './IPv4AddressSection';
import { IPv4AddressSegment } from './IPv4AddressSegment';
import { IPv4AddressNetwork } from './IPv4AddressNetwork';
import { IPAddressSection } from '../IPAddressSection';
import { AddressNetwork } from '../AddressNetwork';
import { AddressComparator } from '../AddressComparator';

/**
 * Constructs an IPv4 address or subnet.
 * <p>
 * Similar to {@link #IPv4Address(byte[],Integer)} except that you can specify the start and end of the address in the given byte array.
 * <p>
 * When networkPrefixLength is non-null, depending on the prefix configuration (see {@link inet.ipaddr.AddressNetwork#getPrefixConfiguration()},
 * this object may represent either a single address with that network prefix length, or the prefix subnet block containing all addresses with the same network prefix.
 * <p>
 * 
 * @param {Array} bytes the 4 byte IPv4 address - if longer than 4 bytes the additional bytes must be zero, if shorter than 4 bytes then the bytes are sign-extended to 4 bytes.
 * @param {number} networkPrefixLength the CIDR network prefix length, which can be null for no prefix
 * @throws AddressValueException if bytes not equivalent to a 4 byte address
 * @param {number} byteStartIndex
 * @param {number} byteEndIndex
 * @class
 * @extends IPAddress
 * @author sfoley
 */
export class IPv4Address extends IPAddress {
    static serialVersionUID : number = 4;

    public static SEGMENT_SEPARATOR : string = '.';

    public static BITS_PER_SEGMENT : number = 8;

    public static BYTES_PER_SEGMENT : number = 1;

    public static SEGMENT_COUNT : number = 4;

    public static BYTE_COUNT : number = 4;

    public static BIT_COUNT : number = 32;

    public static DEFAULT_TEXTUAL_RADIX : number = 10;

    public static MAX_VALUE_PER_SEGMENT : number = 255;

    public static REVERSE_DNS_SUFFIX : string = ".in-addr.arpa";

    sectionCache : IPv4AddressSection.AddressCache;

    public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, networkPrefixLength? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv4Address.SEGMENT_COUNT, networkPrefixLength));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let networkPrefixLength : any = __args[2];
            super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv4Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let networkPrefixLength : any = __args[1];
            super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                if(this.getSegmentCount() !== IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.ipv4.invalid.segment.count", this.getSegmentCount());
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv4Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else if(((typeof bytes === 'number') || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            let networkPrefixLength : any = __args[1];
            super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSectionInternal$int$java_lang_Integer(address, networkPrefixLength));
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(this.getSegmentCount() !== IPv4Address.SEGMENT_COUNT) {
                        throw new AddressValueException("ipaddress.error.ipv4.invalid.segment.count", this.getSegmentCount());
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>IPv4AddressSection) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            super(section);
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                if(section.getSegmentCount() !== IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.ipv4.invalid.segment.count", section.getSegmentCount());
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Inet4Address) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let inet4Address : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let bytes : any = inet4Address.getAddress();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let networkPrefixLength : any = null;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let byteStartIndex : any = 0;
                        let byteEndIndex : any = __args[0].length;
                        super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv4Address.SEGMENT_COUNT, networkPrefixLength));
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                    }
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv4Address.SEGMENT_COUNT, networkPrefixLength));
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                }
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = <number>null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let lowerValueProvider : any = valueProvider;
                    let upperValueProvider : any = valueProvider;
                    super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                }
            }
        } else if(((typeof bytes === 'number') || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let address : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv4Address>thisAddress).getAddressCreator().createSectionInternal$int$java_lang_Integer(address, networkPrefixLength));
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
            }
        } else throw new Error('invalid overload');
    }

    public getSection$() : IPv4AddressSection {
        return <IPv4AddressSection>super.getSection();
    }

    public getSection$int(index : number) : IPv4AddressSection {
        return this.getSection().getSection$int(index);
    }

    public getSection$int$int(index : number, endIndex : number) : IPv4AddressSection {
        return this.getSection().getSection$int$int(index, endIndex);
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPv4AddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            super.getSection(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} index
     * @return {IPv4AddressSegment}
     */
    public getDivision(index : number) : IPv4AddressSegment {
        return this.getSegment(index);
    }

    /**
     * 
     * @param {number} index
     * @return {IPv4AddressSegment}
     */
    public getSegment(index : number) : IPv4AddressSegment {
        return this.getSection().getSegment(index);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} index
     */
    public getSegments(start? : any, end? : any, segs? : any, index? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof index === 'number') || index === null)) {
            super.getSegments(start, end, segs, index);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(start === undefined && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    public getSegments$() : IPv4AddressSegment[] {
        return this.getSection().getSegments();
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        return this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.from(options));
    }

    public getParts$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(options : IPv4AddressSection.IPv4StringBuilderOptions) : IPAddressStringDivisionSeries[] {
        let parts : IPAddressStringDivisionSeries[] = this.getSection().getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        let ipv6Addr : IPv6Address = this.getConverted(options);
        if(ipv6Addr != null) {
            let ipv6Parts : IPAddressStringDivisionSeries[] = ipv6Addr.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options.ipv6ConverterOptions);
            let tmp : IPAddressStringDivisionSeries[] = parts;
            parts = (s => { let a=[]; while(s-->0) a.push(null); return a; })(tmp.length + ipv6Parts.length);
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(tmp, 0, parts, 0, tmp.length);
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(ipv6Parts, 0, parts, tmp.length, ipv6Parts.length);
        }
        return parts;
    }

    public getParts(options? : any) : any {
        if(((options != null && options instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(options);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getSegmentCount() : number {
        return IPv4Address.SEGMENT_COUNT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return IPv4Address.BYTE_COUNT;
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return IPv4Address.BIT_COUNT;
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public toIPv4() : IPv4Address {
        return this;
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv4Convertible() : boolean {
        return true;
    }

    /**
     * Create an IPv6 mixed address using the given ipv6 segments and using this address for the embedded IPv4 segments
     * 
     * @param {Array} segs
     * @return
     * @return {IPv6Address}
     */
    public getIPv6Address(segs : IPv6AddressSegment[]) : IPv6Address {
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getIPv6Network().getAddressCreator();
        return creator.createAddress$inet_ipaddr_ipv6_IPv6AddressSection(IPv6AddressSection.createSection(creator, segs, this));
    }

    public getIPv4MappedAddress() : IPv6Address {
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getIPv6Network().getAddressCreator();
        let zero : IPv6AddressSegment = creator.createSegment$int(0);
        let segs : IPv6AddressSegment[] = creator.createSegmentArray(IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT);
        segs[0] = segs[1] = segs[2] = segs[3] = segs[4] = zero;
        segs[5] = creator.createSegment$int(IPv6Address.MAX_VALUE_PER_SEGMENT);
        return this.getIPv6Address(segs);
    }

    /**
     * @see IPv4Address#toIPv6()
     * @return {boolean}
     */
    public isIPv6Convertible() : boolean {
        let conv : IPAddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
        return conv != null && conv.isIPv6Convertible(this);
    }

    /**
     * Returns this address converted to IPv6.
     * <p>
     * This uses {@link #isIPv6Convertible()} to determine convertibility, and that uses an instance of {@link IPAddressConverter.DefaultAddressConverter} which uses IPv4-mapped address mappings from rfc 4038.
     * <p>
     * Override this method and {@link IPv6Address#isIPv4Convertible()} if you wish to map IPv4 to IPv6 according to the mappings defined by
     * in {@link IPv6Address#isIPv4Compatible()}, {@link IPv6Address#isIPv4Mapped()}, {@link IPv6Address#is6To4()} or some other mapping.
     * <p>
     * If you override this method, you should also override the {@link IPv4Address#isIPv6Convertible()} method to match this behaviour,
     * and potentially also override the reverse conversion {@link IPv6Address#toIPv4()} in your {@link IPv6Address} subclass.
     * @return {IPv6Address}
     */
    public toIPv6() : IPv6Address {
        let conv : IPAddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
        if(conv != null) {
            return conv.toIPv6(this);
        }
        return null;
    }

    getLowestOrHighest(lowest : boolean, excludeZeroHost : boolean) : IPv4Address {
        return this.getSection().getLowestOrHighest(this, lowest, excludeZeroHost);
    }

    public toBroadcastAddress() : IPv4Address {
        return this.toMaxHost();
    }

    public toNetworkAddress() : IPv4Address {
        return this.toZeroHost();
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public getLowerNonZeroHost() : IPv4Address {
        return this.getLowestOrHighest(true, true);
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public getLower() : IPv4Address {
        return this.getLowestOrHighest(true, false);
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public getUpper() : IPv4Address {
        return this.getLowestOrHighest(false, false);
    }

    /**
     * @return {number} the address (or lowest value of the address if a subnet) as a signed integer
     */
    public intValue() : number {
        return this.getSection().intValue();
    }

    /**
     * @return {number} the address (or highest value of the address if a subnet) as a signed integer
     */
    public upperIntValue() : number {
        return this.getSection().upperIntValue();
    }

    /**
     * @return {number} the address (or lowest value of the address if a subnet) as a positive integer
     */
    public longValue() : number {
        return this.getSection().longValue();
    }

    /**
     * @return {number} the address (or highest value of the address if a subnet) as a positive integer
     */
    public upperLongValue() : number {
        return this.getSection().upperLongValue();
    }

    /**
     * Replaces segments starting from startIndex and ending before endIndex with the same number of segments starting at replacementStartIndex from the replacement section
     * 
     * @param {number} startIndex
     * @param {number} endIndex
     * @param {IPv4Address} replacement
     * @param {number} replacementIndex
     * @throws IndexOutOfBoundsException
     * @return
     * @return {IPv4Address}
     */
    public replace(startIndex : number, endIndex : number, replacement : IPv4Address, replacementIndex : number) : IPv4Address {
        return this.checkIdentity(this.getSection().replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(startIndex, endIndex, replacement.getSection(), replacementIndex, replacementIndex + (endIndex - startIndex)));
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPv4Address}
     */
    public reverseBits(perByte : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().reverseBits(perByte));
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public reverseBytes() : IPv4Address {
        return this.checkIdentity(this.getSection().reverseBytes());
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public reverseBytesPerSegment() : IPv4Address {
        return this;
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public reverseSegments() : IPv4Address {
        return this.checkIdentity(this.getSection().reverseSegments());
    }

    checkIdentity(newSection : IPv4AddressSection) : IPv4Address {
        let section : IPv4AddressSection = this.getSection();
        if(newSection === section) {
            return this;
        }
        return this.getAddressCreator().createAddress$inet_ipaddr_ipv4_IPv4AddressSection(newSection);
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean(nextSegment));
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed));
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPv4Address}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : IPv4Address {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int(adjustment));
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int$boolean(adjustment, zeroed));
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPv4Address}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : IPv4Address {
        return this.setPrefixLength$int$boolean(prefixLength, true);
    }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().setPrefixLength$int$boolean(prefixLength, zeroed));
    }

    /**
     * 
     * @param {number} prefixLength
     * @param {boolean} zeroed
     * @return {IPv4Address}
     */
    public setPrefixLength(prefixLength? : any, zeroed? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.setPrefixLength$int$boolean(prefixLength, zeroed);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.setPrefixLength$int$boolean(prefixLength, zeroed);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.setPrefixLength$int$boolean(prefixLength, zeroed);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && zeroed === undefined) {
            return <any>this.setPrefixLength$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && zeroed === undefined) {
            return <any>this.setPrefixLength$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null) && zeroed === undefined) {
            return <any>this.setPrefixLength$int(prefixLength);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4Address}
     */
    public applyPrefixLength(networkPrefixLength : number) : IPv4Address {
        return this.checkIdentity(this.getSection().applyPrefixLength(networkPrefixLength));
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().removePrefixLength$boolean(zeroed));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPv4Address}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public removePrefixLength$() : IPv4Address {
        return this.removePrefixLength$boolean(true);
    }

    /**
     * 
     * @return {*}
     */
    public segmentsNonZeroHostIterator() : any {
        return this.getSection().segmentsNonZeroHostIterator();
    }

    /**
     * 
     * @return {*}
     */
    public segmentsIterator() : any {
        return this.getSection().segmentsIterator();
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        return this.getSection().iterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator$boolean(this, this.getAddressCreator(), false);
    }

    /**
     * 
     * @return {*}
     */
    public nonZeroHostIterator() : any {
        return this.getSection().iterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator$boolean(this, this.getAddressCreator(), true);
    }

    /**
     * 
     * @return {*}
     */
    public prefixBlockIterator() : any {
        return this.getSection().prefixBlockIterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator(this, this.getAddressCreator());
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<IPv4Address> {
        return this;
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv4Address}
     */
    public increment(increment : number) : IPv4Address {
        return this.checkIdentity(this.getSection().increment(increment));
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv4Address}
     */
    public incrementBoundary(increment : number) : IPv4Address {
        return this.checkIdentity(this.getSection().incrementBoundary(increment));
    }

    getAddressCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    /**
     * 
     * @return {IPv4AddressNetwork}
     */
    public getNetwork() : IPv4AddressNetwork {
        return Address.defaultIpv4Network();
    }

    public getIPv6Network() : IPv6AddressNetwork {
        return Address.defaultIpv6Network();
    }

    convertArg(arg : IPAddress) : IPv4Address {
        let converted : IPv4Address = arg.toIPv4();
        if(converted == null) {
            throw new AddressConversionException(this, arg);
        }
        return converted;
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {IPv4Address}
     */
    public intersect(other : IPAddress) : IPv4Address {
        let thisSection : IPv4AddressSection = this.getSection();
        let section : IPv4AddressSection = thisSection.intersect(this.convertArg(other).getSection());
        if(section == null) {
            return null;
        }
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getAddressCreator();
        let result : IPv4Address = creator.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(section);
        return result;
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {Array}
     */
    public subtract(other : IPAddress) : IPv4Address[] {
        let thisSection : IPv4AddressSection = this.getSection();
        let sections : IPv4AddressSection[] = thisSection.subtract(this.convertArg(other).getSection());
        if(sections == null) {
            return null;
        }
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getAddressCreator();
        let result : IPv4Address[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(sections.length);
        for(let i : number = 0; i < result.length; i++) {
            result[i] = creator.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(sections[i]);
        };
        return result;
    }

    public toZeroHost$() : IPv4Address {
        if(!this.isPrefixed()) {
            let config : AddressNetwork.PrefixConfiguration = this.getNetwork().getPrefixConfiguration();
            let addr : IPv4Address = this.getNetwork().getNetworkMask(0, !AddressNetwork.PrefixConfiguration["_$wrappers"][config].allPrefixedAddressesAreSubnets());
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][config].zeroHostsAreSubnets()) {
                addr = addr.getLower();
            }
            return addr;
        }
        if(this.includesZeroHost() && this.isSingleNetwork()) {
            return this.getLower();
        }
        return this.checkIdentity(this.getSection().createZeroHost());
    }

    public toZeroHost$int(prefixLength : number) : IPv4Address {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toZeroHost();
        }
        return this.checkIdentity(this.getSection().toZeroHost$int(prefixLength));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv4Address}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toZeroHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPv4Address {
        if(!this.isPrefixed()) {
            let resultNoPrefix : IPv4Address = this.getNetwork().getHostMask(0);
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                return resultNoPrefix;
            }
            return resultNoPrefix.setPrefixLength$int(0);
        }
        if(this.includesMaxHost() && this.isSingleNetwork()) {
            return this.getUpper();
        }
        return this.checkIdentity(this.getSection().createMaxHost());
    }

    public toMaxHost$int(prefixLength : number) : IPv4Address {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toMaxHost();
        }
        return this.checkIdentity(this.getSection().toMaxHost$int(prefixLength));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv4Address}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toMaxHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().mask$inet_ipaddr_ipv4_IPv4AddressSection$boolean(this.convertArg(mask).getSection(), retainPrefix));
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {boolean} retainPrefix
     * @return {IPv4Address}
     */
    public mask(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.mask$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            super.mask(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_IPAddress(mask);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_IPAddress(mask : IPAddress) : IPv4Address {
        return this.mask$inet_ipaddr_IPAddress$boolean(mask, false);
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength
     * @return {IPv4Address}
     */
    public maskNetwork(mask : IPAddress, networkPrefixLength : number) : IPv4Address {
        return this.checkIdentity(this.getSection().maskNetwork(this.convertArg(mask).getSection(), networkPrefixLength));
    }

    public bitwiseOr$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPv4Address {
        return this.checkIdentity(this.getSection().bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection$boolean(this.convertArg(mask).getSection(), retainPrefix));
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {boolean} retainPrefix
     * @return {IPv4Address}
     */
    public bitwiseOr(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            super.bitwiseOr(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress(mask);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    public bitwiseOr$inet_ipaddr_IPAddress(mask : IPAddress) : IPv4Address {
        return this.bitwiseOr$inet_ipaddr_IPAddress$boolean(mask, false);
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength
     * @return {IPv4Address}
     */
    public bitwiseOrNetwork(mask : IPAddress, networkPrefixLength : number) : IPv4Address {
        return this.checkIdentity(this.getSection().bitwiseOrNetwork(this.convertArg(mask).getSection(), networkPrefixLength));
    }

    public getNetworkSection$() : IPv4AddressSection {
        return this.getSection().getNetworkSection();
    }

    public getNetworkSection$int(networkPrefixLength : number) : IPv4AddressSection {
        return this.getSection().getNetworkSection$int(networkPrefixLength);
    }

    public getNetworkSection$int$boolean(networkPrefixLength : number, withPrefixLength : boolean) : IPv4AddressSection {
        return this.getSection().getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @param {boolean} withPrefixLength
     * @return {IPv4AddressSection}
     */
    public getNetworkSection(networkPrefixLength? : any, withPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null)) {
            return <any>this.getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$();
        } else throw new Error('invalid overload');
    }

    public getHostSection$() : IPv4AddressSection {
        return this.getSection().getHostSection();
    }

    public getHostSection$int(networkPrefixLength : number) : IPv4AddressSection {
        return this.getSection().getHostSection$int(networkPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4AddressSection}
     */
    public getHostSection(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostSection$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : IPv4Address {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null || AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return this;
        }
        return this.toPrefixBlock$int(prefixLength);
    }

    public toPrefixBlock$int(networkPrefixLength : number) : IPv4Address {
        return this.checkIdentity(this.getSection().toPrefixBlock$int(networkPrefixLength));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4Address}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            super.toPrefixBlock(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public assignPrefixForSingleBlock() : IPv4Address {
        return <IPv4Address>super.assignPrefixForSingleBlock();
    }

    /**
     * 
     * @return {IPv4Address}
     */
    public assignMinPrefixForBlock() : IPv4Address {
        return <IPv4Address>super.assignMinPrefixForBlock();
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {Array}
     */
    public spanWithPrefixBlocks(other : IPAddress) : IPv4Address[] {
        return IPAddress.getSpanningPrefixBlocks<any>(this, this.convertArg(other), () => { return IPv4Address.getLower() }, () => { return IPv4Address.getUpper() }, (arg0,arg1) => { return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$().compare(arg0,arg1) }, () => { return IPv4Address.removePrefixLength() }, (length) => { return this.getAddressCreator().createAddressArray(length) });
    }

    /**
     * 
     * @param {Array} addresses
     * @return {Array}
     */
    public mergePrefixBlocks(...addresses : IPAddress[]) : IPv4Address[] {
        if(addresses.length === 0) {
            return [this];
        }
        for(let i : number = 0; i < addresses.length; i++) {
            addresses[i] = this.convertArg(addresses[i]);
        };
        let blocks : Array<IPAddressSegmentSeries> = IPAddress.getMergedBlocks(this, addresses);
        return /* toArray */blocks.slice(0);
    }

    /**
     * 
     * @return {Inet4Address}
     */
    public toUpperInetAddress() : Inet4Address {
        return <Inet4Address>super.toInetAddress();
    }

    /**
     * 
     * @return {Inet4Address}
     */
    public toInetAddress() : Inet4Address {
        return <Inet4Address>super.toInetAddress();
    }

    /**
     * 
     * @return {boolean}
     */
    public isLocal() : boolean {
        if(this.isMulticast()) {
            let seg0 : IPv4AddressSegment = this.getSegment(0);
            if(seg0.matches$int(239)) {
                return true;
            }
            let seg1 : IPv4AddressSegment = this.getSegment(1);
            let seg2 : IPv4AddressSegment = this.getSegment(2);
            return (seg0.matches$int(224) && seg1.isZero() && seg2.isZero()) || (seg0.matches$int(232) && !(seg1.isZero() && seg2.isZero()));
        }
        return this.isLinkLocal() || this.isPrivate() || this.isAnyLocal();
    }

    /**
     * @see java.net.InetAddress#isLinkLocalAddress()
     * @return {boolean}
     */
    public isLinkLocal() : boolean {
        if(this.isMulticast()) {
            return this.getSegment(0).matches$int(224) && this.getSegment(1).isZero() && this.getSegment(2).isZero() && this.getSegment(3).matches$int(252);
        }
        return this.getSegment(0).matches$int(169) && this.getSegment(1).matches$int(254);
    }

    /**
     * Unicast addresses allocated for private use
     * 
     * @see java.net.InetAddress#isSiteLocalAddress()
     * @return {boolean}
     */
    public isPrivate() : boolean {
        let seg0 : IPv4AddressSegment = this.getSegment(0);
        let seg1 : IPv4AddressSegment = this.getSegment(1);
        return seg0.matches$int(10) || seg0.matches$int(172) && seg1.matchesWithPrefixMask$int$java_lang_Integer(16, 4) || seg0.matches$int(192) && seg1.matches$int(168);
    }

    /**
     * 
     * @return {boolean}
     */
    public isMulticast() : boolean {
        return this.getSegment(0).matchesWithPrefixMask$int$java_lang_Integer(224, 4);
    }

    /**
     * @see java.net.InetAddress#isLoopbackAddress()
     * @return {boolean}
     */
    public isLoopback() : boolean {
        return this.getSegment(0).matches$int(127);
    }

    /**
     * 
     * @return {IPAddressStringParameters}
     */
    createFromStringParams() : IPAddressStringParameters {
        return new IPAddressStringParameters.Builder().getIPv4AddressParametersBuilder().setNetwork(this.getNetwork()).getParentBuilder().getIPv6AddressParametersBuilder().setNetwork(this.getIPv6Network()).getParentBuilder().toParams();
    }

    public static toNormalizedString(prefixConfiguration? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any, segmentCount? : any, bytesPerSegment? : any, bitsPerSegment? : any, segmentMaxValue? : any, separator? : any, radix? : any, zone? : any, builder? : any) : any {
        if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((builder != null && (builder instanceof Object)) || builder === null)) {
            super.toNormalizedString(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone, builder);
        } else if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && builder === undefined) {
            return <any>IPv4Address.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone);
        } else if(((prefixConfiguration != null && prefixConfiguration instanceof <any>IPv4AddressNetwork) || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && segmentCount === undefined && bytesPerSegment === undefined && bitsPerSegment === undefined && segmentMaxValue === undefined && separator === undefined && radix === undefined && zone === undefined && builder === undefined) {
            return <any>IPv4Address.toNormalizedString$inet_ipaddr_ipv4_IPv4AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength);
        } else throw new Error('invalid overload');
    }

    public static toNormalizedString$inet_ipaddr_ipv4_IPv4AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(network : IPv4AddressNetwork, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number) : string {
        return IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(network.getPrefixConfiguration(), lowerValueProvider, upperValueProvider, prefixLength, IPv4Address.SEGMENT_COUNT, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, IPv4Address.MAX_VALUE_PER_SEGMENT, IPv4Address.SEGMENT_SEPARATOR, IPv4Address.DEFAULT_TEXTUAL_RADIX, null);
    }

    public toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix : IPv4Address.inet_aton_radix) : string {
        return this.getSection().toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix);
    }

    public toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix : IPv4Address.inet_aton_radix, joinedCount : number) : string {
        return this.getSection().toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix, joinedCount);
    }

    public toInetAtonString(radix? : any, joinedCount? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof joinedCount === 'number') || joinedCount === null)) {
            return <any>this.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix, joinedCount);
        } else if(((typeof radix === 'number') || radix === null) && joinedCount === undefined) {
            return <any>this.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {string}
     */
    public toUNCHostName() : string {
        return super.toCanonicalString();
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.STANDARD_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toAllStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$());
    }

    public toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts : IPAddressSection.IPStringBuilderOptions) : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.from(opts));
    }

    getConverted(opts : IPv4AddressSection.IPv4StringBuilderOptions) : IPv6Address {
        if(opts.includes(IPv4AddressSection.IPv4StringBuilderOptions.IPV6_CONVERSIONS)) {
            let converter : IPv6Address.IPv6AddressConverter = opts.converter;
            return converter.toIPv6(this);
        }
        return null;
    }

    public toStringCollection$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(opts : IPv4AddressSection.IPv4StringBuilderOptions) : IPAddressPartStringCollection {
        let coll : IPv4AddressSection.IPv4StringCollection = new IPv4AddressSection.IPv4StringCollection();
        let sectionColl : IPAddressPartStringCollection = this.getSection().toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        coll.addAll(sectionColl);
        let ipv6Addr : IPv6Address = this.getConverted(opts);
        if(ipv6Addr != null) {
            let ipv6StringCollection : IPAddressPartStringCollection = ipv6Addr.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts.ipv6ConverterOptions);
            coll.addAll(ipv6StringCollection);
        }
        return coll;
    }

    public toStringCollection(opts? : any) : any {
        if(((opts != null && opts instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(opts);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }
}
IPv4Address["__class"] = "inet.ipaddr.ipv4.IPv4Address";
IPv4Address["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];



export namespace IPv4Address {

    /**
     * @custom.core
     * @author sfoley
     * @class
     */
    export interface IPv4AddressConverter {
        /**
         * If the given address is IPv4, or can be converted to IPv4, returns that {@link IPv4Address}.  Otherwise, returns null.
         * @param {IPAddress} address
         * @return {IPv4Address}
         */
        toIPv4(address : IPAddress) : IPv4Address;
    }

    /**
     * @author sfoley
     * @enum
     * @property {IPv4Address.inet_aton_radix} OCTAL
     * @property {IPv4Address.inet_aton_radix} HEX
     * @property {IPv4Address.inet_aton_radix} DECIMAL
     * @class
     */
    export enum inet_aton_radix {
        OCTAL, HEX, DECIMAL
    }

    /** @ignore */
    export class inet_aton_radix_$WRAPPER {
        constructor(protected _$ordinal : number, protected _$name : string) {
        }

        getRadix() : number {
            if(this._$ordinal === inet_aton_radix.OCTAL) {
                return 8;
            } else if(this._$ordinal === inet_aton_radix.HEX) {
                return 16;
            }
            return 10;
        }

        getSegmentStrPrefix() : string {
            if(this._$ordinal === inet_aton_radix.OCTAL) {
                return "0";
            } else if(this._$ordinal === inet_aton_radix.HEX) {
                return "0x";
            }
            return null;
        }
        public name() : string { return this._$name; }
        public ordinal() : number { return this._$ordinal; }
    }
    inet_aton_radix["__class"] = "inet.ipaddr.ipv4.IPv4Address.inet_aton_radix";
    inet_aton_radix["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

    inet_aton_radix["_$wrappers"] = [new inet_aton_radix_$WRAPPER(0, "OCTAL"), new inet_aton_radix_$WRAPPER(1, "HEX"), new inet_aton_radix_$WRAPPER(2, "DECIMAL")];

}



