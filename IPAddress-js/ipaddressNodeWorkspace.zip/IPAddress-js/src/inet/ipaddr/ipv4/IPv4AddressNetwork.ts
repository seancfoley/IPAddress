/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressNetwork } from '../AddressNetwork';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressSection } from '../IPAddressSection';
import { IPv4Address } from './IPv4Address';
import { IPv4AddressSection } from './IPv4AddressSection';
import { IPv4AddressSegment } from './IPv4AddressSegment';
import { Address } from '../Address';
import { IPAddress } from '../IPAddress';
import { HostName } from '../HostName';
import { HostIdentifierString } from '../HostIdentifierString';

/**
 * 
 * @author sfoley
 * @class
 * @extends IPAddressNetwork
 */
export class IPv4AddressNetwork extends IPAddressNetwork<IPv4Address, IPv4AddressSection, IPv4AddressSection, IPv4AddressSegment, Inet4Address> {
    static serialVersionUID : number = 4;

    static __inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration : AddressNetwork.PrefixConfiguration; public static __inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration_$LI$() : AddressNetwork.PrefixConfiguration { if(IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration == null) IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration = AddressNetwork.getDefaultPrefixConfiguration(); return IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration; };

    static CACHE_SEGMENTS_BY_PREFIX : boolean = true;

    static EMPTY_SEGMENTS : IPv4AddressSegment[]; public static EMPTY_SEGMENTS_$LI$() : IPv4AddressSegment[] { if(IPv4AddressNetwork.EMPTY_SEGMENTS == null) IPv4AddressNetwork.EMPTY_SEGMENTS = []; return IPv4AddressNetwork.EMPTY_SEGMENTS; };

    static EMPTY_SECTION : IPv4AddressSection[]; public static EMPTY_SECTION_$LI$() : IPv4AddressSection[] { if(IPv4AddressNetwork.EMPTY_SECTION == null) IPv4AddressNetwork.EMPTY_SECTION = []; return IPv4AddressNetwork.EMPTY_SECTION; };

    static EMPTY_ADDRESS : IPv4Address[]; public static EMPTY_ADDRESS_$LI$() : IPv4Address[] { if(IPv4AddressNetwork.EMPTY_ADDRESS == null) IPv4AddressNetwork.EMPTY_ADDRESS = []; return IPv4AddressNetwork.EMPTY_ADDRESS; };

    public constructor() {
        super(IPv4Address);
    }

    /**
     * 
     * @return {AddressNetwork.PrefixConfiguration}
     */
    public getPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
        return IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration_$LI$();
    }

    /**
     * Sets the default prefix configuration used by this network.
     * 
     * @see #getPrefixConfiguration()
     * @see #getDefaultPrefixConfiguration()
     * @see PrefixConfiguration
     * @param {AddressNetwork.PrefixConfiguration} config
     */
    public static setDefaultPrefixConfiguration(config : AddressNetwork.PrefixConfiguration) {
        IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration = config;
    }

    /**
     * Gets the default prefix configuration used by this network.
     * 
     * @see AddressNetwork#getDefaultPrefixConfiguration()
     * @see PrefixConfiguration
     * @return {AddressNetwork.PrefixConfiguration}
     */
    public static getDefaultPrefixConfiguration() : AddressNetwork.PrefixConfiguration {
        return IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration_$LI$();
    }

    /**
     * 
     * @return {*}
     */
    getSegmentProducer() : (p1: IPv4Address, p2: number) => IPv4AddressSegment {
        return (address, index) => address.getSegment(index);
    }

    /**
     * 
     * @return {*}
     */
    getSectionProducer() : (p1: IPv4Address) => IPv4AddressSection {
        return () => { return IPv4Address.getSection() };
    }

    /**
     * 
     * @return {IPv4AddressNetwork.IPv4AddressCreator}
     */
    createAddressCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return new IPv4AddressNetwork.IPv4AddressCreator(this);
    }

    /**
     * 
     * @return {IPv4Address}
     */
    createLoopback() : IPv4Address {
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getAddressCreator();
        let zero : IPv4AddressSegment = creator.createSegment$int(0);
        let segs : IPv4AddressSegment[] = creator.createSegmentArray(IPv4Address.SEGMENT_COUNT);
        segs[0] = creator.createSegment$int(127);
        segs[1] = segs[2] = zero;
        segs[3] = creator.createSegment$int(1);
        return creator.createAddressInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(segs);
    }

    /**
     * 
     * @return {IPv4AddressNetwork.IPv4AddressCreator}
     */
    public getAddressCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return <IPv4AddressNetwork.IPv4AddressCreator>super.getAddressCreator();
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv4() : boolean {
        return true;
    }

    /**
     * 
     * @return {IPAddress.IPVersion}
     */
    public getIPVersion() : IPAddress.IPVersion {
        return IPAddress.IPVersion.IPV4;
    }
}
IPv4AddressNetwork["__class"] = "inet.ipaddr.ipv4.IPv4AddressNetwork";
IPv4AddressNetwork["__interfaces"] = ["java.io.Serializable"];



export namespace IPv4AddressNetwork {

    export class IPv4AddressCreator extends IPAddressNetwork.IPAddressCreator<IPv4Address, IPv4AddressSection, IPv4AddressSection, IPv4AddressSegment, Inet4Address> {
        public __parent: any;
        static __inet_ipaddr_ipv4_IPv4AddressNetwork_IPv4AddressCreator_serialVersionUID : number = 4;

        ZERO_PREFIX_SEGMENT : IPv4AddressSegment;

        ALL_RANGE_SEGMENT : IPv4AddressSegment;

        segmentCache : IPv4AddressSegment[];

        segmentPrefixCache : IPv4AddressSegment[][];

        allPrefixedCache : IPv4AddressSegment[];

        public constructor(__parent: any) {
            super(__parent);
            this.__parent = __parent;
            if(this.ZERO_PREFIX_SEGMENT===undefined) this.ZERO_PREFIX_SEGMENT = null;
            if(this.ALL_RANGE_SEGMENT===undefined) this.ALL_RANGE_SEGMENT = null;
            if(this.segmentCache===undefined) this.segmentCache = null;
            if(this.segmentPrefixCache===undefined) this.segmentPrefixCache = null;
            if(this.allPrefixedCache===undefined) this.allPrefixedCache = null;
        }

        /**
         * 
         */
        public clearCaches() {
            this.segmentCache = null;
            this.allPrefixedCache = null;
            this.segmentPrefixCache = null;
        }

        /**
         * 
         * @return {IPv4AddressNetwork}
         */
        public getNetwork() : IPv4AddressNetwork {
            return this.__parent;
        }

        /**
         * 
         * @param {number} length
         * @return {Array}
         */
        public createSegmentArray(length : number) : IPv4AddressSegment[] {
            if(length === 0) {
                return IPv4AddressNetwork.EMPTY_SEGMENTS_$LI$();
            }
            return (s => { let a=[]; while(s-->0) a.push(null); return a; })(length);
        }

        public createSegment$int(value : number) : IPv4AddressSegment {
            if(value >= 0 && value <= IPv4Address.MAX_VALUE_PER_SEGMENT) {
                let result : IPv4AddressSegment;
                let cache : IPv4AddressSegment[] = this.segmentCache;
                if(cache == null) {
                    this.segmentCache = cache = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.MAX_VALUE_PER_SEGMENT + 1);
                    cache[value] = result = new IPv4AddressSegment(value);
                } else {
                    result = cache[value];
                    if(result == null) {
                        cache[value] = result = new IPv4AddressSegment(value);
                    }
                }
                return result;
            }
            return new IPv4AddressSegment(value);
        }

        public createSegment$int$java_lang_Integer(value : number, segmentPrefixLength : number) : IPv4AddressSegment {
            if(segmentPrefixLength == null) {
                return this.createSegment$int(value);
            }
            if(value >= 0 && value <= IPv4Address.MAX_VALUE_PER_SEGMENT && segmentPrefixLength >= 0 && segmentPrefixLength <= IPv4Address.BIT_COUNT) {
                if(segmentPrefixLength === 0 && AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                    let result : IPv4AddressSegment = this.ZERO_PREFIX_SEGMENT;
                    if(result == null) {
                        this.ZERO_PREFIX_SEGMENT = result = new IPv4AddressSegment(0, 0);
                    }
                    return result;
                }
                if(IPv4AddressNetwork.CACHE_SEGMENTS_BY_PREFIX) {
                    let mask : number = this.__parent.getSegmentNetworkMask(segmentPrefixLength);
                    let prefixIndex : number = segmentPrefixLength;
                    let valueIndex : number;
                    let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
                    if(isAllSubnets) {
                        value &= mask;
                        valueIndex = value >>> (IPv4Address.BITS_PER_SEGMENT - segmentPrefixLength);
                    } else {
                        valueIndex = value;
                    }
                    let result : IPv4AddressSegment;
                    let block : IPv4AddressSegment[];
                    let cache : IPv4AddressSegment[][] = this.segmentPrefixCache;
                    if(cache == null) {
                        this.segmentPrefixCache = cache = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.BITS_PER_SEGMENT + 1);
                        cache[prefixIndex] = block = (s => { let a=[]; while(s-->0) a.push(null); return a; })(isAllSubnets?(1 << prefixIndex):256);
                        block[valueIndex] = result = new IPv4AddressSegment(value, segmentPrefixLength);
                    } else {
                        block = cache[prefixIndex];
                        if(block == null) {
                            cache[prefixIndex] = block = (s => { let a=[]; while(s-->0) a.push(null); return a; })(isAllSubnets?(1 << prefixIndex):256);
                            block[valueIndex] = result = new IPv4AddressSegment(value, segmentPrefixLength);
                        } else {
                            result = block[valueIndex];
                            if(result == null) {
                                block[valueIndex] = result = new IPv4AddressSegment(value, segmentPrefixLength);
                            }
                        }
                    }
                    return result;
                }
            }
            let result : IPv4AddressSegment = new IPv4AddressSegment(value, segmentPrefixLength);
            return result;
        }

        public createSegment$int$int$java_lang_Integer(lower : number, upper : number, segmentPrefixLength : number) : IPv4AddressSegment {
            if(segmentPrefixLength == null) {
                if(lower === upper) {
                    return this.createSegment$int(lower);
                }
                if(lower === 0 && upper === IPv4Address.MAX_VALUE_PER_SEGMENT) {
                    let result : IPv4AddressSegment = this.ALL_RANGE_SEGMENT;
                    if(result == null) {
                        this.ALL_RANGE_SEGMENT = result = new IPv4AddressSegment(0, IPv4Address.MAX_VALUE_PER_SEGMENT, null);
                    }
                    return result;
                }
            } else {
                if(lower >= 0 && lower <= IPv4Address.MAX_VALUE_PER_SEGMENT && upper >= 0 && upper <= IPv4Address.MAX_VALUE_PER_SEGMENT && segmentPrefixLength >= 0 && segmentPrefixLength <= IPv4Address.BIT_COUNT) {
                    if(segmentPrefixLength === 0 && AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                        return this.createSegment$int$java_lang_Integer(0, 0);
                    }
                    if(IPv4AddressNetwork.CACHE_SEGMENTS_BY_PREFIX) {
                        let bitsPerSegment : number = IPv4Address.BITS_PER_SEGMENT;
                        if(segmentPrefixLength > bitsPerSegment) {
                            segmentPrefixLength = bitsPerSegment;
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                            let mask : number = this.__parent.getSegmentNetworkMask(segmentPrefixLength);
                            lower &= mask;
                            if((upper & mask) === lower) {
                                return this.createSegment$int$java_lang_Integer(lower, segmentPrefixLength);
                            }
                            if(lower === 0 && upper >= mask) {
                                let prefixIndex : number = segmentPrefixLength;
                                let result : IPv4AddressSegment;
                                let cache : IPv4AddressSegment[] = this.allPrefixedCache;
                                if(cache == null) {
                                    this.allPrefixedCache = cache = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.BITS_PER_SEGMENT + 1);
                                    cache[prefixIndex] = result = new IPv4AddressSegment(0, IPv4Address.MAX_VALUE_PER_SEGMENT, segmentPrefixLength);
                                } else {
                                    result = cache[prefixIndex];
                                    if(result == null) {
                                        cache[prefixIndex] = result = new IPv4AddressSegment(0, IPv4Address.MAX_VALUE_PER_SEGMENT, segmentPrefixLength);
                                    }
                                }
                                return result;
                            }
                        } else {
                            if(lower === 0 && upper === IPv4Address.MAX_VALUE_PER_SEGMENT) {
                                let prefixIndex : number = segmentPrefixLength;
                                let result : IPv4AddressSegment;
                                let cache : IPv4AddressSegment[] = this.allPrefixedCache;
                                if(cache == null) {
                                    this.allPrefixedCache = cache = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.BITS_PER_SEGMENT + 1);
                                    cache[prefixIndex] = result = new IPv4AddressSegment(0, IPv4Address.MAX_VALUE_PER_SEGMENT, segmentPrefixLength);
                                } else {
                                    result = cache[prefixIndex];
                                    if(result == null) {
                                        cache[prefixIndex] = result = new IPv4AddressSegment(0, IPv4Address.MAX_VALUE_PER_SEGMENT, segmentPrefixLength);
                                    }
                                }
                                return result;
                            }
                        }
                    }
                }
            }
            let result : IPv4AddressSegment = new IPv4AddressSegment(lower, upper, segmentPrefixLength);
            return result;
        }

        /**
         * 
         * @param {number} lower
         * @param {number} upper
         * @param {number} segmentPrefixLength
         * @return {IPv4AddressSegment}
         */
        public createSegment(lower? : any, upper? : any, segmentPrefixLength? : any) : any {
            if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                return <any>this.createSegment$int$int$java_lang_Integer(lower, upper, segmentPrefixLength);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
                super.createSegment(lower, upper, segmentPrefixLength);
            } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
                return <any>this.createSegment$int$java_lang_Integer(lower, upper);
            } else if(((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
                return <any>this.createSegment$int(lower);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {number} length
         * @return {Array}
         */
        createSectionArray(length : number) : IPv4AddressSection[] {
            if(length === 0) {
                return IPv4AddressNetwork.EMPTY_SECTION_$LI$();
            }
            return (s => { let a=[]; while(s-->0) a.push(null); return a; })(length);
        }

        createSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(segments : IPv4AddressSegment[]) : IPv4AddressSection {
            return new IPv4AddressSection(segments, false);
        }

        public createPrefixedSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer$boolean(segments : IPv4AddressSegment[], prefix : number, singleOnly : boolean) : IPv4AddressSection {
            return new IPv4AddressSection(segments, false, prefix, singleOnly);
        }

        /**
         * 
         * @param {Array} segments
         * @param {number} prefix
         * @param {boolean} singleOnly
         * @return {IPv4AddressSection}
         */
        public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>IPv4AddressSegment))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$int(value : number) : IPv4AddressSection {
            return new IPv4AddressSection(value);
        }

        createSectionInternal$int$java_lang_Integer(value : number, prefix : number) : IPv4AddressSection {
            return new IPv4AddressSection(value, prefix);
        }

        /**
         * 
         * @param {*} lowerValueProvider
         * @param {*} upperValueProvider
         * @param {number} prefix
         * @return {IPv4AddressSection}
         */
        public createFullSectionInternal(lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefix : number) : IPv4AddressSection {
            return new IPv4AddressSection(lowerValueProvider, upperValueProvider, IPv4Address.SEGMENT_COUNT, prefix);
        }

        public createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes : number[], segmentCount : number, prefix : number, singleOnly : boolean) : IPv4AddressSection {
            return new IPv4AddressSection(bytes, segmentCount, prefix, false, singleOnly);
        }

        /**
         * 
         * @param {Array} bytes
         * @param {number} segmentCount
         * @param {number} prefix
         * @param {boolean} singleOnly
         * @return {IPv4AddressSection}
         */
        public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createSectionInternal$byte_A$int$java_lang_Integer$boolean(bytes, segmentCount, prefix, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$byte_A$java_lang_Integer(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
            } else if(((typeof bytes === 'number') || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$int$java_lang_Integer(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else if(((typeof bytes === 'number') || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$int(bytes);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A$int$boolean(segments : IPv4AddressSegment[], startIndex : number, extended : boolean) : IPv4AddressSection {
            return new IPv4AddressSection(segments);
        }

        public createSection$byte_A$int$int$java_lang_Integer(bytes : number[], byteStartIndex : number, byteEndIndex : number, prefix : number) : IPv4AddressSection {
            return new IPv4AddressSection(bytes, byteStartIndex, byteEndIndex, -1, prefix, true, false);
        }

        public createSection$byte_A$java_lang_Integer(bytes : number[], prefix : number) : IPv4AddressSection {
            return new IPv4AddressSection(bytes, prefix);
        }

        public createSection$byte_A$int$int$int$java_lang_Integer(bytes : number[], byteStartIndex : number, byteEndIndex : number, segmentCount : number, prefix : number) : IPv4AddressSection {
            return new IPv4AddressSection(bytes, byteStartIndex, byteEndIndex, segmentCount, prefix);
        }

        public createSection(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, prefix? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null)) {
                return <any>this.createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined) {
                return <any>this.createSection$byte_A$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined) {
                return <any>this.createSection$byte_A$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$byte_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$byte_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, byteStartIndex);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && prefix === undefined) {
                return <any>this.createSection$inet_ipaddr_IPAddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        public createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A$java_lang_Integer(segments : IPv4AddressSegment[], networkPrefixLength : number) : IPv4AddressSection {
            return new IPv4AddressSection(segments, networkPrefixLength);
        }

        public createSection$inet_ipaddr_ipv4_IPv4AddressSegment_A(segments : IPv4AddressSegment[]) : IPv4AddressSection {
            return new IPv4AddressSection(segments);
        }

        public createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_ipv4_IPv4AddressSegment_A(encompassingSection : IPAddressSection, segments : IPv4AddressSegment[]) : IPv4AddressSection {
            return new IPv4AddressSection.EmbeddedIPv4AddressSection(encompassingSection, segments);
        }

        /**
         * 
         * @param {IPAddressSection} encompassingSection
         * @param {Array} segments
         * @return {IPv4AddressSection}
         */
        public createEmbeddedSectionInternal(encompassingSection? : any, segments? : any) : any {
            if(((encompassingSection != null && encompassingSection instanceof <any>IPAddressSection) || encompassingSection === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>IPv4AddressSegment))) || segments === null)) {
                return <any>this.createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_ipv4_IPv4AddressSegment_A(encompassingSection, segments);
            } else if(((encompassingSection != null && encompassingSection instanceof <any>IPAddressSection) || encompassingSection === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null)) {
                return <any>this.createEmbeddedSectionInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_IPAddressSegment_A(encompassingSection, segments);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {number} length
         * @return {Array}
         */
        createAddressArray(length : number) : IPv4Address[] {
            if(length === 0) {
                return IPv4AddressNetwork.EMPTY_ADDRESS_$LI$();
            }
            return (s => { let a=[]; while(s-->0) a.push(null); return a; })(length);
        }

        public createAddressInternal(bytes? : any, prefix? : any, zone? : any, fromHost? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((fromHost != null && fromHost instanceof <any>HostName) || fromHost === null)) {
                super.createAddressInternal(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof fromHost === 'number') || fromHost === null)) {
                super.createAddressInternal(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && zone instanceof <any>HostName) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && ((typeof zone === 'number') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>IPv4AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv4_IPv4AddressSection$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createAddressInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(segments : IPv4AddressSegment[]) : IPv4Address {
            return this.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(this.createSectionInternal$inet_ipaddr_ipv4_IPv4AddressSegment_A(segments));
        }

        createAddressInternal$inet_ipaddr_ipv4_IPv4AddressSection$java_lang_CharSequence(section : IPv4AddressSection, zone : any) : IPv4Address {
            return this.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(section);
        }

        public createAddress(lowerValueProvider? : any, upperValueProvider? : any, prefix? : any, zone? : any) : any {
            if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                super.createAddress(lowerValueProvider, upperValueProvider, prefix, zone);
            } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(lowerValueProvider, upperValueProvider, prefix);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>IPv4AddressSection) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Inet4Address) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$java_net_Inet4Address(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$java_net_InetAddress(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_AddressSection(lowerValueProvider);
            } else throw new Error('invalid overload');
        }

        public createAddress$inet_ipaddr_ipv4_IPv4AddressSection(section : IPv4AddressSection) : IPv4Address {
            return new IPv4Address(section);
        }

        public createAddress$java_net_Inet4Address(addr : Inet4Address) : IPv4Address {
            return new IPv4Address(addr);
        }
    }
    IPv4AddressCreator["__class"] = "inet.ipaddr.ipv4.IPv4AddressNetwork.IPv4AddressCreator";
    IPv4AddressCreator["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];


}




IPv4AddressNetwork.EMPTY_ADDRESS_$LI$();

IPv4AddressNetwork.EMPTY_SECTION_$LI$();

IPv4AddressNetwork.EMPTY_SEGMENTS_$LI$();

IPv4AddressNetwork.__inet_ipaddr_ipv4_IPv4AddressNetwork_defaultPrefixConfiguration_$LI$();
