/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressSegment } from '../AddressSegment';
import { AddressValueException } from '../AddressValueException';
import { IPAddressSegment } from '../IPAddressSegment';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { IPv6AddressSegment } from '../ipv6/IPv6AddressSegment';
import { IPv4Address } from './IPv4Address';
import { IPAddress } from '../IPAddress';
import { IPv4AddressNetwork } from './IPv4AddressNetwork';
import { AddressNetwork } from '../AddressNetwork';
import { IPv6AddressNetwork } from '../ipv6/IPv6AddressNetwork';

/**
 * Constructs a segment of an IPv4 address that represents a range of values.
 * 
 * @throws AddressValueException if either lower or upper value or prefix length is negative or too large
 * @param {number} segmentPrefixLength the segment prefix length, which can be null.    If segmentPrefixLength is non-null, this segment represents a range of segment values with the given network prefix length.
 * @param {number} lower the lower value of the range of values represented by the segment.  If segmentPrefixLength is non-null, the lower value becomes the smallest value with the same network prefix.
 * @param {number} upper the upper value of the range of values represented by the segment.  If segmentPrefixLength is non-null, the upper value becomes the largest value with the same network prefix.
 * @class
 * @extends IPAddressSegment
 * @author sfoley
 */
export class IPv4AddressSegment extends IPAddressSegment {
    static serialVersionUID : number = 4;

    /**
     * When printed with the default radix of 10, the max number of characters per segment
     */
    public static MAX_CHARS : number = 3;

    public constructor(lower? : any, upper? : any, segmentPrefixLength? : any) {
        if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(lower, upper, segmentPrefixLength);
            (() => {
                if(this.getUpperSegmentValue() > IPv4Address.MAX_VALUE_PER_SEGMENT) {
                    throw new AddressValueException(this.getUpperSegmentValue());
                }
                if(segmentPrefixLength != null && segmentPrefixLength > IPv4Address.BIT_COUNT) {
                    throw new PrefixLenException(segmentPrefixLength);
                }
            })();
        } else if(((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            let segmentPrefixLength : any = __args[1];
            super(value, segmentPrefixLength);
            (() => {
                if(value > IPv4Address.MAX_VALUE_PER_SEGMENT) {
                    throw new AddressValueException(value);
                }
                if(segmentPrefixLength != null && segmentPrefixLength > IPv4Address.BIT_COUNT) {
                    throw new PrefixLenException(segmentPrefixLength);
                }
            })();
        } else if(((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            super(value);
            (() => {
                if(value > IPv4Address.MAX_VALUE_PER_SEGMENT) {
                    throw new AddressValueException(value);
                }
            })();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv4() : boolean {
        return true;
    }

    /**
     * 
     * @return {IPAddress.IPVersion}
     */
    public getIPVersion() : IPAddress.IPVersion {
        return IPAddress.IPVersion.IPV4;
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        return [(<number>(low?this.getLowerSegmentValue():this.getUpperSegmentValue())|0)];
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getSegmentNetworkMask(bits : number) : number {
        return this.getNetwork().getSegmentNetworkMask(bits);
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getSegmentHostMask(bits : number) : number {
        return this.getNetwork().getSegmentHostMask(bits);
    }

    /**
     * 
     * @return {number}
     */
    public getMaxSegmentValue() : number {
        return IPAddressSegment.getMaxSegmentValue(IPAddress.IPVersion.IPV4);
    }

    public toPrefixedSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            super.toPrefixedSegment(segmentPrefixLength, creator);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && creator === undefined) {
            return <any>this.toPrefixedSegment$java_lang_Integer(segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    toPrefixedSegment$java_lang_Integer(segmentPrefixLength : number) : IPv4AddressSegment {
        if(this.isChangedByPrefix(segmentPrefixLength, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets())) {
            return <any>(super.toPrefixedSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator(segmentPrefixLength, this.getSegmentCreator()));
        }
        return this;
    }

    public toNetworkSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, withPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            super.toNetworkSegment(segmentPrefixLength, withPrefixLength, creator);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null) && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength, withPrefixLength);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null) && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength, withPrefixLength);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && withPrefixLength === undefined && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer(segmentPrefixLength);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && withPrefixLength === undefined && creator === undefined) {
            return <any>this.toNetworkSegment$java_lang_Integer(segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    public toNetworkSegment$java_lang_Integer(segmentPrefixLength : number) : IPv4AddressSegment {
        return this.toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength, true);
    }

    public toNetworkSegment$java_lang_Integer$boolean(segmentPrefixLength : number, withPrefixLength : boolean) : IPv4AddressSegment {
        if(this.isNetworkChangedByPrefix(segmentPrefixLength, withPrefixLength)) {
            return <any>(super.toNetworkSegment$java_lang_Integer$boolean$inet_ipaddr_AddressNetwork_AddressSegmentCreator(segmentPrefixLength, withPrefixLength, this.getSegmentCreator()));
        }
        return this;
    }

    public toHostSegment<S extends IPAddressSegment>(segmentPrefixLength? : any, creator? : any) : any {
        if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && ((creator != null && (creator["__interfaces"] != null && creator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || creator.constructor != null && creator.constructor["__interfaces"] != null && creator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || creator === null)) {
            super.toHostSegment(segmentPrefixLength, creator);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && creator === undefined) {
            return <any>this.toHostSegment$java_lang_Integer(segmentPrefixLength);
        } else if(((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null) && creator === undefined) {
            return <any>this.toHostSegment$java_lang_Integer(segmentPrefixLength);
        } else throw new Error('invalid overload');
    }

    public toHostSegment$java_lang_Integer(bits : number) : IPv4AddressSegment {
        if(this.isHostChangedByPrefix(bits)) {
            return <any>(super.toHostSegment$java_lang_Integer$inet_ipaddr_AddressNetwork_AddressSegmentCreator(bits, this.getSegmentCreator()));
        }
        return this;
    }

    /**
     * 
     * @return {IPv4AddressSegment}
     */
    public getLower() : IPv4AddressSegment {
        return <any>(IPAddressSegment.getLowestOrHighest<any>(this, this.getSegmentCreator(), true));
    }

    /**
     * 
     * @return {IPv4AddressSegment}
     */
    public getUpper() : IPv4AddressSegment {
        return <any>(IPAddressSegment.getLowestOrHighest<any>(this, this.getSegmentCreator(), false));
    }

    /**
     * 
     * @return {IPv4AddressNetwork}
     */
    public getNetwork() : IPv4AddressNetwork {
        return Address.defaultIpv4Network();
    }

    public getSegmentCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<IPv4AddressSegment> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        return AddressDivision.iterator<any>(this, this.getSegmentCreator(), !this.isPrefixed(), null);
    }

    /**
     * 
     * @return {*}
     */
    public prefixBlockIterator() : any {
        return AddressDivision.iterator<any>(this, this.getSegmentCreator(), true, this.getSegmentPrefixLength());
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return IPv4Address.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return IPv4Address.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return IPv4Address.DEFAULT_TEXTUAL_RADIX;
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        return IPv4AddressSegment.MAX_CHARS;
    }

    public reverseBits$boolean(perByte : boolean) : IPv4AddressSegment {
        return this.reverseBits();
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPv4AddressSegment}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else if(((typeof perByte === 'boolean') || perByte === null)) {
            super.reverseBits(perByte);
        } else if(perByte === undefined) {
            return <any>this.reverseBits$();
        } else throw new Error('invalid overload');
    }

    public reverseBits$() : IPv4AddressSegment {
        if(this.isMultiple()) {
            if(AddressDivision.isReversibleRange<any>(this)) {
                if(this.isPrefixed()) {
                    let creator : AddressNetwork.AddressSegmentCreator<IPv4AddressSegment> = this.getSegmentCreator();
                    return creator['createSegment$int$int$java_lang_Integer'](this.getLowerSegmentValue(), this.getUpperSegmentValue(), null);
                }
                return this;
            }
            throw new IncompatibleAddressException(this, "ipaddress.error.reverseRange");
        }
        let oldVal : number = this.getLowerSegmentValue();
        let newVal : number = AddressDivision.reverseBits$byte((<number>oldVal|0));
        if(oldVal === newVal && !this.isPrefixed()) {
            return this;
        }
        let creator : AddressNetwork.AddressSegmentCreator<IPv4AddressSegment> = this.getSegmentCreator();
        return creator['createSegment$int'](newVal);
    }

    /**
     * 
     * @return {IPv4AddressSegment}
     */
    public reverseBytes() : IPv4AddressSegment {
        return <any>(IPAddressSegment.removePrefix<any>(this, false, this.getSegmentCreator()));
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPv4AddressSegment {
        return <any>(IPAddressSegment.removePrefix<any>(this, zeroed, this.getSegmentCreator()));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPv4AddressSegment}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public removePrefixLength$() : IPv4AddressSegment {
        return this.removePrefixLength$boolean(true);
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public contains(other : AddressSegment) : boolean {
        return (other != null && other instanceof <any>IPv4AddressSegment) && this.containsSeg(other);
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public equals(other : any) : boolean {
        if(this === other) {
            return true;
        }
        return (other != null && other instanceof <any>IPv4AddressSegment) && this.isSameValues$inet_ipaddr_format_AddressDivision(<IPv4AddressSegment>other);
    }

    /**
     * Joins with another IPv4 segment to produce a IPv6 segment.
     * 
     * @param {IPv6AddressNetwork.IPv6AddressCreator} creator
     * @param {IPv4AddressSegment} low
     * @return
     * @return {IPv6AddressSegment}
     */
    public join(creator : IPv6AddressNetwork.IPv6AddressCreator, low : IPv4AddressSegment) : IPv6AddressSegment {
        let shift : number = IPv4Address.BITS_PER_SEGMENT;
        let prefix : number = IPv4AddressSegment.getJoinedSegmentPrefixLength(shift, this.getSegmentPrefixLength(), low.getSegmentPrefixLength());
        if(this.isMultiple()) {
            if(!low.isFullRange()) {
                throw new IncompatibleAddressException(this, low, "ipaddress.error.invalidMixedRange");
            }
        }
        return creator.createSegment$int$int$java_lang_Integer((this.getLowerSegmentValue() << shift) | low.getLowerSegmentValue(), (this.getUpperSegmentValue() << shift) | low.getUpperSegmentValue(), prefix);
    }

    static getJoinedSegmentPrefixLength(bitsPerSegment : number, highBits : number, lowBits : number) : number {
        if(lowBits == null) {
            return null;
        }
        if(lowBits === 0) {
            return highBits;
        }
        return lowBits + bitsPerSegment;
    }
}
IPv4AddressSegment["__class"] = "inet.ipaddr.ipv4.IPv4AddressSegment";
IPv4AddressSegment["__interfaces"] = ["inet.ipaddr.AddressSegment","inet.ipaddr.AddressComponent","inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];




