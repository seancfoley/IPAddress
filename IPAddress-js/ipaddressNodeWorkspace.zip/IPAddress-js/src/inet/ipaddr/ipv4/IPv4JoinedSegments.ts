/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { AddressValueException } from '../AddressValueException';
import { PrefixLenException } from '../PrefixLenException';
import { IPAddressJoinedSegments } from '../format/IPAddressJoinedSegments';
import { IPv4Address } from './IPv4Address';

/**
 * 
 * @author sfoley
 * @param {number} joinedCount
 * @param {number} lower
 * @param {number} upper
 * @param {number} segmentPrefixLength
 * @class
 * @extends IPAddressJoinedSegments
 */
export class IPv4JoinedSegments extends IPAddressJoinedSegments {
    static serialVersionUID : number = 4;

    static MAX_CHARS : number[]; public static MAX_CHARS_$LI$() : number[] { if(IPv4JoinedSegments.MAX_CHARS == null) IPv4JoinedSegments.MAX_CHARS = (s => { let a=[]; while(s-->0) a.push(0); return a; })(IPv4Address.SEGMENT_COUNT - 1); return IPv4JoinedSegments.MAX_CHARS; };

    public constructor(joinedCount? : any, lower? : any, upper? : any, segmentPrefixLength? : any) {
        if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && ((typeof segmentPrefixLength === 'number') || segmentPrefixLength === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super(joinedCount, lower, upper, segmentPrefixLength);
            (() => {
                if(joinedCount >= IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException(joinedCount);
                } else if(segmentPrefixLength != null && segmentPrefixLength > IPv4Address.BIT_COUNT) {
                    throw new PrefixLenException(segmentPrefixLength);
                } else {
                    this.checkMax(this.getUpperValue());
                }
            })();
        } else if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && ((typeof upper === 'number') || upper === null) && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[1];
            let segmentPrefixLength : any = __args[2];
            super(joinedCount, value, segmentPrefixLength);
            (() => {
                if(joinedCount >= IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException(joinedCount);
                } else if(segmentPrefixLength != null && segmentPrefixLength > IPv4Address.BIT_COUNT) {
                    throw new PrefixLenException(segmentPrefixLength);
                } else {
                    this.checkMax(value);
                }
            })();
        } else if(((typeof joinedCount === 'number') || joinedCount === null) && ((typeof lower === 'number') || lower === null) && upper === undefined && segmentPrefixLength === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[1];
            super(joinedCount, value);
            (() => {
                if(joinedCount >= IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException(joinedCount);
                }
            })();
        } else throw new Error('invalid overload');
    }

    /*private*/ checkMax(val : number) {
        let max : number = 0;
        switch((this.joinedCount)) {
        case 0:
            max = 255;
            break;
        case 1:
            max = 65535;
            break;
        case 2:
            max = 16777215;
            break;
        case 3:
            max = 4294967295;
            break;
        }
        if(this.value > max) {
            throw new AddressValueException(this.value);
        }
    }

    /**
     * 
     * @param {number} radix
     * @return {number}
     */
    public getMaxDigitCount(radix? : any) : any {
        if(((typeof radix === 'number') || radix === null)) {
            super.getMaxDigitCount(radix);
        } else if(radix === undefined) {
            return <any>this.getMaxDigitCount$();
        } else throw new Error('invalid overload');
    }

    public getMaxDigitCount$() : number {
        let result : number = IPv4JoinedSegments.MAX_CHARS_$LI$()[this.joinedCount - 1];
        if(result === 0) {
            result = IPv4JoinedSegments.MAX_CHARS_$LI$()[this.joinedCount - 1] = super.getMaxDigitCount();
        }
        return result;
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionNetworkMask(bits : number) : number {
        let totalBits : number = IPv4Address.BITS_PER_SEGMENT * (this.joinedCount + 1);
        let fullMask : number = ~(~0 << totalBits);
        let networkMask : number = fullMask & (fullMask << (totalBits - bits));
        return networkMask;
    }

    /**
     * 
     * @param {number} bits
     * @return {number}
     */
    getDivisionHostMask(bits : number) : number {
        let totalBits : number = IPv4Address.BITS_PER_SEGMENT * (this.joinedCount + 1);
        let hostMask : number = ~(~0 << (totalBits - bits));
        return hostMask;
    }

    /**
     * 
     * @return {number}
     */
    getBitsPerSegment() : number {
        return IPv4Address.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getDefaultTextualRadix() : number {
        return IPv4Address.DEFAULT_TEXTUAL_RADIX;
    }
}
IPv4JoinedSegments["__class"] = "inet.ipaddr.ipv4.IPv4JoinedSegments";
IPv4JoinedSegments["__interfaces"] = ["inet.ipaddr.format.IPAddressStringDivision","inet.ipaddr.format.AddressStringDivision","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];





IPv4JoinedSegments.MAX_CHARS_$LI$();
