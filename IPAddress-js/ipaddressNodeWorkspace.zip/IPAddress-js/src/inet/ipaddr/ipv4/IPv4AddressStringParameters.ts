/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressStringParameters } from '../AddressStringParameters';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IPv6AddressStringParameters } from '../ipv6/IPv6AddressStringParameters';
import { IPv4AddressNetwork } from './IPv4AddressNetwork';

/**
 * The IPv4-specific parameters within a {@link IPAddressStringParameters} instance.
 * 
 * @author sfoley
 * @param {boolean} allowLeadingZeros
 * @param {boolean} allowCIDRPrefixLeadingZeros
 * @param {boolean} allowUnlimitedLeadingZeros
 * @param {AddressStringParameters.RangeParameters} rangeOptions
 * @param {boolean} allowWildcardedSeparator
 * @param {boolean} allowPrefixesBeyondAddressSize
 * @param {boolean} inet_aton_hex
 * @param {boolean} inet_aton_octal
 * @param {boolean} inet_aton_joinedSegments
 * @param {boolean} inet_aton_single_segment_mask
 * @param {IPv4AddressNetwork} network
 * @class
 * @extends IPAddressStringParameters.IPAddressStringFormatParameters
 */
export class IPv4AddressStringParameters extends IPAddressStringParameters.IPAddressStringFormatParameters {
    static serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_IPV4_INET_ATON : boolean = true;

    public static DEFAULT_ALLOW_IPV4_INET_ATON_SINGLE_SEGMENT_MASK : boolean = false;

    /**
     * Allows ipv4 inet_aton hexadecimal format 0xa.0xb.0xc.0cd
     */
    public inet_aton_hex : boolean;

    /**
     * Allows ipv4 inet_aton octal format, 04.05.06.07 being an example.
     * Can be overridden by {@link IPAddressStringFormatParameters#allowLeadingZeros}
     */
    public inet_aton_octal : boolean;

    /**
     * Allows ipv4 joined segments like 1.2.3, 1.2, or just 1
     * 
     * For the case of just 1 segment, the behaviour is controlled by {@link AddressStringParameters#allowSingleSegment}
     */
    public inet_aton_joinedSegments : boolean;

    /**
     * If you allow ipv4 joined segments, whether you allow a mask that looks like a prefix length: 1.2.3.5/255
     */
    public inet_aton_single_segment_mask : boolean;

    /**
     * The network that will be used to construct addresses - both parameters inside the network, and the network's address creator
     */
    /*private*/ network : IPv4AddressNetwork;

    public constructor(allowLeadingZeros : boolean, allowCIDRPrefixLeadingZeros : boolean, allowUnlimitedLeadingZeros : boolean, rangeOptions : AddressStringParameters.RangeParameters, allowWildcardedSeparator : boolean, allowPrefixesBeyondAddressSize : boolean, inet_aton_hex : boolean, inet_aton_octal : boolean, inet_aton_joinedSegments : boolean, inet_aton_single_segment_mask : boolean, network : IPv4AddressNetwork) {
        super(allowLeadingZeros, allowCIDRPrefixLeadingZeros, allowUnlimitedLeadingZeros, rangeOptions, allowWildcardedSeparator, allowPrefixesBeyondAddressSize);
        if(this.inet_aton_hex===undefined) this.inet_aton_hex = false;
        if(this.inet_aton_octal===undefined) this.inet_aton_octal = false;
        if(this.inet_aton_joinedSegments===undefined) this.inet_aton_joinedSegments = false;
        if(this.inet_aton_single_segment_mask===undefined) this.inet_aton_single_segment_mask = false;
        if(this.network===undefined) this.network = null;
        this.inet_aton_hex = inet_aton_hex;
        this.inet_aton_octal = inet_aton_octal;
        this.inet_aton_joinedSegments = inet_aton_joinedSegments;
        this.inet_aton_single_segment_mask = inet_aton_single_segment_mask;
        this.network = network;
    }

    public toBuilder(builder? : any) : any {
        if(((builder != null && builder instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase) || builder === null)) {
            super.toBuilder(builder);
        } else if(((builder != null && builder instanceof <any>AddressStringParameters.AddressStringFormatParameters.BuilderBase) || builder === null)) {
            return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
        } else if(builder === undefined) {
            return <any>this.toBuilder$();
        } else throw new Error('invalid overload');
    }

    public toBuilder$() : IPv4AddressStringParameters.Builder {
        let builder : IPv4AddressStringParameters.Builder = new IPv4AddressStringParameters.Builder();
        builder.inet_aton_hex = this.inet_aton_hex;
        builder.inet_aton_octal = this.inet_aton_octal;
        builder.inet_aton_joinedSegments = this.inet_aton_joinedSegments;
        builder.inet_aton_single_segment_mask = this.inet_aton_single_segment_mask;
        builder.network = this.network;
        return <IPv4AddressStringParameters.Builder>this.toBuilder$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase(builder);
    }

    /**
     * 
     * @return {IPv4AddressNetwork}
     */
    public getNetwork() : IPv4AddressNetwork {
        if(this.network == null) {
            return Address.defaultIpv4Network();
        }
        return this.network;
    }

    /**
     * 
     * @return {IPv4AddressStringParameters}
     */
    public clone() : IPv4AddressStringParameters {
        try {
            return <IPv4AddressStringParameters>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
        } catch(e) {
        };
        return null;
    }

    public compareTo$inet_ipaddr_ipv4_IPv4AddressStringParameters(o : IPv4AddressStringParameters) : number {
        let result : number = super.compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o);
        if(result === 0) {
            result = javaemul.internal.BooleanHelper.compare(this.inet_aton_hex, o.inet_aton_hex);
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.inet_aton_octal, o.inet_aton_octal);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.inet_aton_joinedSegments, o.inet_aton_joinedSegments);
                }
            }
        }
        return result;
    }

    /**
     * 
     * @param {IPv4AddressStringParameters} o
     * @return {number}
     */
    public compareTo(o? : any) : any {
        if(((o != null && o instanceof <any>IPv4AddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_ipv4_IPv4AddressStringParameters(o);
        } else if(((o != null && o instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o);
        } else if(((o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>IPv4AddressStringParameters) {
            if(super.equals(o)) {
                let other : IPv4AddressStringParameters = <IPv4AddressStringParameters>o;
                return this.inet_aton_hex === other.inet_aton_hex && this.inet_aton_octal === other.inet_aton_octal && this.inet_aton_joinedSegments === other.inet_aton_joinedSegments;
            }
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
        if(this.inet_aton_hex) {
            hash |= 64;
        }
        if(this.inet_aton_octal) {
            hash |= 128;
        }
        if(this.inet_aton_joinedSegments) {
            hash |= 256;
        }
        return hash;
    }
}
IPv4AddressStringParameters["__class"] = "inet.ipaddr.ipv4.IPv4AddressStringParameters";
IPv4AddressStringParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



export namespace IPv4AddressStringParameters {

    export class Builder extends IPAddressStringParameters.IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
        inet_aton_hex : boolean = IPv4AddressStringParameters.DEFAULT_ALLOW_IPV4_INET_ATON;

        inet_aton_octal : boolean = IPv4AddressStringParameters.DEFAULT_ALLOW_IPV4_INET_ATON;

        inet_aton_joinedSegments : boolean = IPv4AddressStringParameters.DEFAULT_ALLOW_IPV4_INET_ATON;

        inet_aton_single_segment_mask : boolean = IPv4AddressStringParameters.DEFAULT_ALLOW_IPV4_INET_ATON_SINGLE_SEGMENT_MASK;

        network : IPv4AddressNetwork;

        mixedParent : IPv6AddressStringParameters.Builder;

        public setMixedParent(parent : IPv6AddressStringParameters.Builder) {
            this.mixedParent = parent;
        }

        public getEmbeddedIPv4AddressParentBuilder() : IPv6AddressStringParameters.Builder {
            return this.mixedParent;
        }

        public allow_inet_aton(allow : boolean) : IPv4AddressStringParameters.Builder {
            this.inet_aton_joinedSegments = this.inet_aton_octal = this.inet_aton_hex = allow;
            super.allowUnlimitedLeadingZeros(allow);
            return this;
        }

        /**
         * @see IPv4AddressStringParameters#inet_aton_hex
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder} the builder
         */
        public allow_inet_aton_hex(allow : boolean) : IPv4AddressStringParameters.Builder {
            this.inet_aton_hex = allow;
            return this;
        }

        /**
         * @see IPv4AddressStringParameters#inet_aton_octal
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder} the builder
         */
        public allow_inet_aton_octal(allow : boolean) : IPv4AddressStringParameters.Builder {
            this.inet_aton_octal = allow;
            return this;
        }

        /**
         * @see IPv4AddressStringParameters#inet_aton_joinedSegments
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder} the builder
         */
        public allow_inet_aton_joined_segments(allow : boolean) : IPv4AddressStringParameters.Builder {
            this.inet_aton_joinedSegments = allow;
            return this;
        }

        /**
         * @see IPv4AddressStringParameters#inet_aton_single_segment_mask
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder} the builder
         */
        public allow_inet_aton_single_segment_mask(allow : boolean) : IPv4AddressStringParameters.Builder {
            this.inet_aton_single_segment_mask = allow;
            return this;
        }

        /**
         * @see IPv4AddressStringParameters#network
         * @param {IPv4AddressNetwork} network if null, the default network will be used
         * @return {IPv4AddressStringParameters.Builder} the builder
         */
        public setNetwork(network : IPv4AddressNetwork) : IPv4AddressStringParameters.Builder {
            this.network = network;
            return this;
        }

        /**
         * 
         * @param {AddressStringParameters.RangeParameters} rangeOptions
         * @return {IPv4AddressStringParameters.Builder}
         */
        public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : IPv4AddressStringParameters.Builder {
            super.setRangeOptions(rangeOptions);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder}
         */
        public allowPrefixesBeyondAddressSize(allow : boolean) : IPv4AddressStringParameters.Builder {
            super.allowPrefixesBeyondAddressSize(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder}
         */
        public allowWildcardedSeparator(allow : boolean) : IPv4AddressStringParameters.Builder {
            super.allowWildcardedSeparator(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder}
         */
        public allowLeadingZeros(allow : boolean) : IPv4AddressStringParameters.Builder {
            super.allowLeadingZeros(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder}
         */
        public allowPrefixLengthLeadingZeros(allow : boolean) : IPv4AddressStringParameters.Builder {
            super.allowPrefixLengthLeadingZeros(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv4AddressStringParameters.Builder}
         */
        public allowUnlimitedLeadingZeros(allow : boolean) : IPv4AddressStringParameters.Builder {
            super.allowUnlimitedLeadingZeros(allow);
            return this;
        }

        public toParams() : IPv4AddressStringParameters {
            return new IPv4AddressStringParameters(this.__allowLeadingZeros, this.__allowPrefixLengthLeadingZeros, this.__allowUnlimitedLeadingZeros, this.rangeOptions, this.__allowWildcardedSeparator, this.__allowPrefixesBeyondAddressSize, this.inet_aton_hex, this.inet_aton_octal, this.inet_aton_joinedSegments, this.inet_aton_single_segment_mask, this.network);
        }

        constructor() {
            super();
            if(this.network===undefined) this.network = null;
            if(this.mixedParent===undefined) this.mixedParent = null;
        }
    }
    Builder["__class"] = "inet.ipaddr.ipv4.IPv4AddressStringParameters.Builder";

}



