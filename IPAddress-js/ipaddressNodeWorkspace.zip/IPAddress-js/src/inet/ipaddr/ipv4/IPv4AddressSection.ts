/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressSection } from '../AddressSection';
import { AddressValueException } from '../AddressValueException';
import { IPAddress } from '../IPAddress';
import { IPAddressSection } from '../IPAddressSection';
import { IPAddressSegment } from '../IPAddressSegment';
import { IPAddressSegmentSeries } from '../IPAddressSegmentSeries';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { SizeMismatchException } from '../SizeMismatchException';
import { AddressCreator } from '../format/AddressCreator';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { AddressStringDivision } from '../format/AddressStringDivision';
import { IPAddressDivision } from '../format/IPAddressDivision';
import { IPAddressDivisionGrouping } from '../format/IPAddressDivisionGrouping';
import { IPAddressStringDivisionSeries } from '../format/IPAddressStringDivisionSeries';
import { IPAddressPartConfiguredString } from '../format/util/IPAddressPartConfiguredString';
import { IPAddressPartStringCollection } from '../format/util/IPAddressPartStringCollection';
import { IPAddressPartStringSubCollection } from '../format/util/IPAddressPartStringSubCollection';
import { IPv6AddressSection } from '../ipv6/IPv6AddressSection';
import { IPv4Address } from './IPv4Address';
import { IPv4AddressSegment } from './IPv4AddressSegment';
import { IPv4AddressNetwork } from './IPv4AddressNetwork';
import { AddressNetwork } from '../AddressNetwork';
import { AddressComparator } from '../AddressComparator';
import { IPv4JoinedSegments } from './IPv4JoinedSegments';
import { IPv6Address } from '../ipv6/IPv6Address';
import { IPAddressConverter } from '../IPAddressConverter';
import { IPAddressStringDivision } from '../format/IPAddressStringDivision';

/**
 * 
 * @author sfoley
 * @param {*} lowerValueProvider
 * @param {*} upperValueProvider
 * @param {number} segmentCount
 * @param {number} networkPrefixLength
 * @class
 * @extends IPAddressSection
 */
export class IPv4AddressSection extends IPAddressSection {
    static __inet_ipaddr_ipv4_IPv4AddressSection_serialVersionUID : number = 4;

    static MAX_VALUES : number[]; public static MAX_VALUES_$LI$() : number[] { if(IPv4AddressSection.MAX_VALUES == null) IPv4AddressSection.MAX_VALUES = [0, IPv4Address.MAX_VALUE_PER_SEGMENT, 65535, 16777215, 4294967295]; return IPv4AddressSection.MAX_VALUES; };

    stringCache : IPv4AddressSection.IPv4StringCache;

    /*private*/ sectionCache : AddressDivisionGrouping.SectionCache<IPv4AddressSection>;

    public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, networkPrefixLength? : any, cloneBytes? : any, singleOnly? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof cloneBytes === 'boolean') || cloneBytes === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                let network : IPv4AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                let byteLengthIsExact : boolean = bytes.length === segs.length;
                if(networkPrefixLength != null) {
                    if(networkPrefixLength < 0) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    let max : number = segs.length << 3;
                    if(networkPrefixLength > max) {
                        if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        networkPrefixLength = max;
                    }
                    if(segs.length > 0) {
                        let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                            if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                            } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    } else if(byteLengthIsExact) {
                        this.setBytes(bytes);
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    if(byteLengthIsExact) {
                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                    }
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && ((typeof networkPrefixLength === 'boolean') || networkPrefixLength === null) && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segmentCount : any = __args[1];
            let networkPrefixLength : any = __args[2];
            let cloneBytes : any = __args[3];
            let singleOnly : any = __args[4];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === segs.length;
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 3;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[4];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = prefix;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === segs.length;
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 3;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let segmentCount : any = __args[2];
            let networkPrefixLength : any = __args[3];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                let network : IPv4AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                if(networkPrefixLength != null) {
                    if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'boolean') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let cloneSegments : any = __args[1];
            let networkPrefixLength : any = __args[2];
            let singleOnly : any = __args[3];
            {
                let __args = Array.prototype.slice.call(arguments);
                let normalizeSegments : any = networkPrefixLength == null;
                super(segments, cloneSegments, true);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(normalizeSegments && this.isPrefixed()) {
                        AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                    }
                    if(segments.length > IPv4Address.SEGMENT_COUNT) {
                        throw new AddressValueException(segments.length);
                    }
                })();
            }
            (() => {
                if(networkPrefixLength != null) {
                    let max : number = segments.length << 3;
                    if(networkPrefixLength > max) {
                        if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        networkPrefixLength = max;
                    }
                    if(segments.length > 0) {
                        if(this.cachedPrefixLength !== AddressDivisionGrouping.NO_PREFIX_LENGTH && this.cachedPrefixLength < networkPrefixLength) {
                            networkPrefixLength = this.cachedPrefixLength;
                        }
                        let network : IPv4AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), !singleOnly && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segments, networkPrefixLength, network, false)?(segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) }:(segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        this.cachedPrefixLength = networkPrefixLength;
                    }
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[3];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = -1;
                let networkPrefixLength : any = prefix;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === segs.length;
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 3;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let segmentCount : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let segmentCount : any = __args[1];
            let networkPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'boolean') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let cloneSegments : any = __args[1];
            let normalizeSegments : any = __args[2];
            super(segments, cloneSegments, true);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                if(normalizeSegments && this.isPrefixed()) {
                    AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                }
                if(segments.length > IPv4Address.SEGMENT_COUNT) {
                    throw new AddressValueException(segments.length);
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = -1;
                let networkPrefixLength : any = null;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === segs.length;
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 3;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let cloneSegments : any = true;
                let singleOnly : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = networkPrefixLength == null;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        if(segments.length > IPv4Address.SEGMENT_COUNT) {
                            throw new AddressValueException(segments.length);
                        }
                    })();
                }
                (() => {
                    if(networkPrefixLength != null) {
                        let max : number = segments.length << 3;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segments.length > 0) {
                            if(this.cachedPrefixLength !== AddressDivisionGrouping.NO_PREFIX_LENGTH && this.cachedPrefixLength < networkPrefixLength) {
                                networkPrefixLength = this.cachedPrefixLength;
                            }
                            let network : IPv4AddressNetwork = this.getNetwork();
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), !singleOnly && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segments, networkPrefixLength, network, false)?(segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) }:(segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                            this.cachedPrefixLength = networkPrefixLength;
                        }
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = __args[0].length;
                let networkPrefixLength : any = prefix;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                        let network : IPv4AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                        let byteLengthIsExact : boolean = bytes.length === segs.length;
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength < 0) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            let max : number = segs.length << 3;
                            if(networkPrefixLength > max) {
                                if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                    throw new PrefixLenException(networkPrefixLength);
                                }
                                networkPrefixLength = max;
                            }
                            if(segs.length > 0) {
                                let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                                if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                    if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                    } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                    }
                                } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact) {
                                this.setBytes(bytes);
                            }
                            this.cachedPrefixLength = networkPrefixLength;
                        } else {
                            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                            if(byteLengthIsExact) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'boolean') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let cloneSegments : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let normalizeSegments : any = true;
                super(segments, cloneSegments, true);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(normalizeSegments && this.isPrefixed()) {
                        AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                    }
                    if(segments.length > IPv4Address.SEGMENT_COUNT) {
                        throw new AddressValueException(segments.length);
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let segmentCount : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let networkPrefixLength : any = null;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                        let network : IPv4AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                            }
                            this.cachedPrefixLength = networkPrefixLength;
                        } else {
                            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        }
                    })();
                }
            }
        } else if(((typeof bytes === 'number') || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            let networkPrefixLength : any = __args[1];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.SEGMENT_COUNT), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                let network : IPv4AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, 0, value, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                if(networkPrefixLength != null) {
                    if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>IPv4AddressSegment) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segment : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segments : any = [segment];
                let cloneSegments : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = true;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        if(segments.length > IPv4Address.SEGMENT_COUNT) {
                            throw new AddressValueException(segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv4AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let cloneSegments : any = true;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = true;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv4AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        if(segments.length > IPv4Address.SEGMENT_COUNT) {
                            throw new AddressValueException(segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = __args[0].length;
                let networkPrefixLength : any = null;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:Math.max(0, byteEndIndex - byteStartIndex)), false, false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                        let network : IPv4AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                        let byteLengthIsExact : boolean = bytes.length === segs.length;
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength < 0) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            let max : number = segs.length << 3;
                            if(networkPrefixLength > max) {
                                if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                                    throw new PrefixLenException(networkPrefixLength);
                                }
                                networkPrefixLength = max;
                            }
                            if(segs.length > 0) {
                                let prefConf : AddressNetwork.PrefixConfiguration = network.getPrefixConfiguration();
                                if(AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].zeroHostsAreSubnets()) {
                                    if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false) && !singleOnly) {
                                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                    } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                    }
                                } else if(byteLengthIsExact && (AddressNetwork.PrefixConfiguration["_$wrappers"][prefConf].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount())) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact) {
                                this.setBytes(bytes);
                            }
                            this.cachedPrefixLength = networkPrefixLength;
                        } else {
                            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                            if(byteLengthIsExact) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        }
                    })();
                }
            }
        } else if(((typeof bytes === 'number') || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let value : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv4Address.SEGMENT_COUNT), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    let segs : IPv4AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv4AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, 0, value, IPv4Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength > IPv4Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv4Address.BITS_PER_SEGMENT, IPv4Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv4AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                })();
            }
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} destIndex
     */
    public getSegments(start? : any, end? : any, segs? : any, destIndex? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof destIndex === 'number') || destIndex === null)) {
            super.getSegments(start, end, segs, destIndex);
        } else if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && (segs instanceof Array)) || segs === null) && destIndex === undefined) {
            return <any>this.getSegments$int$int$java_util_Collection(start, end, segs);
        } else if(((start != null && (start instanceof Array)) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$java_util_Collection(start);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(start === undefined && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    public getSegments$() : IPv4AddressSegment[] {
        return <IPv4AddressSegment[]>/* clone */this.getDivisionsInternal().slice(0);
    }

    public getSection$() : IPv4AddressSection {
        return this;
    }

    public getSection$int(index : number) : IPv4AddressSection {
        return this.getSection$int$int(index, this.getSegmentCount());
    }

    public getSection$int$int(index : number, endIndex : number) : IPv4AddressSection {
        return <any>(AddressDivisionGrouping.getSection<any, any>(index, endIndex, this, this.getAddressCreator()));
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPv4AddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            super.getSection(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    getLowestOrHighestSection(lowest : boolean, excludeZeroHost : boolean) : IPv4AddressSection {
        let result : IPv4AddressSection = <any>(AddressDivisionGrouping.getSingleLowestOrHighestSection<any>(this));
        if(result == null) {
            let cache : AddressDivisionGrouping.SectionCache<IPv4AddressSection> = this.sectionCache;
            if(cache == null || (lowest?(excludeZeroHost?((result = cache.lowerNonZeroHost) == null && !cache.lowerNonZeroHostIsNull):(result = cache.lower) == null):(result = cache.upper) == null)) {
                {
                    cache = this.sectionCache;
                    let create : boolean = (cache == null);
                    if(create) {
                        this.sectionCache = cache = <any>(new AddressDivisionGrouping.SectionCache<IPv4AddressSection>());
                    } else {
                        if(lowest) {
                            if(excludeZeroHost) {
                                create = (result = cache.lowerNonZeroHost) == null && !cache.lowerNonZeroHostIsNull;
                            } else {
                                create = (result = cache.lower) == null;
                            }
                        } else {
                            create = (result = cache.upper) == null;
                        }
                    }
                    if(create) {
                        result = <any>(IPAddressSection.getLowestOrHighestSection<any, any>(this, this.getAddressCreator(), () => { return this.segmentsNonZeroHostIterator() }, (i) => lowest?this.getSegment(i).getLower():this.getSegment(i).getUpper(), lowest, excludeZeroHost));
                        if(result == null) {
                            cache.lowerNonZeroHostIsNull = true;
                        } else if(lowest) {
                            if(excludeZeroHost) {
                                cache.lowerNonZeroHost = result;
                            } else {
                                cache.lower = result;
                            }
                        } else {
                            cache.upper = result;
                        }
                    }
                };
            }
        } else if(excludeZeroHost && this.includesZeroHost()) {
            return null;
        }
        return result;
    }

    getLowestOrHighest(addr : IPv4Address, lowest : boolean, excludeZeroHost : boolean) : IPv4Address {
        let sectionResult : IPv4AddressSection = this.getLowestOrHighestSection(lowest, excludeZeroHost);
        if(sectionResult === this) {
            return addr;
        } else if(sectionResult == null) {
            return null;
        }
        let result : IPv4Address = null;
        let cache : IPv4AddressSection.AddressCache = addr.sectionCache;
        if(cache == null || (result = lowest?(excludeZeroHost?cache.lowerNonZeroHost:cache.lower):cache.upper) == null) {
            {
                cache = addr.sectionCache;
                let create : boolean = (cache == null);
                if(create) {
                    cache = addr.sectionCache = new IPv4AddressSection.AddressCache();
                } else {
                    if(lowest) {
                        if(excludeZeroHost) {
                            create = (result = cache.lowerNonZeroHost) == null;
                        } else {
                            create = (result = cache.lower) == null;
                        }
                    } else {
                        create = (result = cache.upper) == null;
                    }
                }
                if(create) {
                    result = this.getAddressCreator().createAddress$inet_ipaddr_ipv4_IPv4AddressSection(sectionResult);
                    if(lowest) {
                        if(excludeZeroHost) {
                            cache.lowerNonZeroHost = result;
                        } else {
                            cache.lower = result;
                        }
                    } else {
                        cache.upper = result;
                    }
                }
            };
        }
        return result;
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public getLowerNonZeroHost() : IPv4AddressSection {
        return this.getLowestOrHighestSection(true, true);
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public getLower() : IPv4AddressSection {
        return this.getLowestOrHighestSection(true, false);
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public getUpper() : IPv4AddressSection {
        return this.getLowestOrHighestSection(false, false);
    }

    public intValue() : number {
        return this.getIntValue(true);
    }

    public upperIntValue() : number {
        return this.getIntValue(false);
    }

    public longValue() : number {
        return this.intValue() & 4294967295;
    }

    public upperLongValue() : number {
        return this.upperIntValue() & 4294967295;
    }

    getIntValue(lower : boolean) : number {
        let segCount : number = this.getSegmentCount();
        let result : number = 0;
        for(let i : number = 0; i < segCount; i++) {
            let seg : IPv4AddressSegment = this.getSegment(i);
            result = (result << IPv4Address.BITS_PER_SEGMENT) | (lower?seg.getLowerSegmentValue():seg.getUpperSegmentValue());
        };
        return result;
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPv4AddressSection}
     */
    public reverseBits(perByte : boolean) : IPv4AddressSection {
        return <any>(AddressDivisionGrouping.reverseBits<any, any>(perByte, this, this.getAddressCreator(), (i) => this.getSegment(i).reverseBits$boolean(perByte), true));
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public reverseBytes() : IPv4AddressSection {
        return this.reverseSegments();
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public reverseBytesPerSegment() : IPv4AddressSection {
        if(!this.isPrefixed()) {
            return this;
        }
        return this.removePrefixLength$boolean(false);
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public reverseSegments() : IPv4AddressSection {
        if(this.getSegmentCount() <= 1) {
            if(this.isPrefixed()) {
                return this.removePrefixLength$boolean(false);
            }
            return this;
        }
        return <any>(AddressDivisionGrouping.reverseSegments<any, any>(this, this.getAddressCreator(), (i) => this.getSegment(i).removePrefixLength$boolean(false), true));
    }

    /**
     * 
     * @return {Array}
     */
    getSegmentsInternal() : IPv4AddressSegment[] {
        return <IPv4AddressSegment[]>super.getDivisionsInternal();
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<IPv4AddressSection> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && ((typeof networkSegmentIndex === 'number') || networkSegmentIndex === null) && ((typeof hostSegmentIndex === 'number') || hostSegmentIndex === null) && ((typeof prefixedSegIteratorProducer === 'function' && (<any>prefixedSegIteratorProducer).length == 1) || prefixedSegIteratorProducer === null)) {
            super.iterator(segmentCreator, segSupplier, segIteratorProducer, excludeFunc, networkSegmentIndex, hostSegmentIndex, prefixedSegIteratorProducer);
        } else if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(segmentCreator, segSupplier, segIteratorProducer, excludeFunc);
        } else if(((segmentCreator != null && segmentCreator instanceof <any>IPv4Address) || segmentCreator === null) && ((segSupplier != null && segSupplier instanceof <any>AddressCreator) || segSupplier === null) && ((typeof segIteratorProducer === 'boolean') || segIteratorProducer === null) && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator$boolean(segmentCreator, segSupplier, segIteratorProducer);
        } else if(((typeof segmentCreator === 'boolean') || segmentCreator === null) && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$boolean(segmentCreator);
        } else if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    iterator$boolean(excludeZeroHosts : boolean) : any {
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        let useOriginal : boolean = !this.isMultiple() && (!isAllSubnets || !this.isPrefixed());
        let original : IPv4AddressSection;
        if(useOriginal && excludeZeroHosts && this.includesZeroHost()) {
            original = null;
        } else {
            original = this;
        }
        return AddressDivisionGrouping.iterator(useOriginal, original, this.getAddressCreator(), useOriginal?null:this.segmentsIterator$boolean(excludeZeroHosts), isAllSubnets?null:this.getPrefixLength());
    }

    /**
     * 
     * @return {*}
     */
    public nonZeroHostIterator() : any {
        return this.iterator$boolean(true);
    }

    public iterator$() : any {
        return this.iterator$boolean(false);
    }

    public prefixBlockIterator$() : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator();
        }
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getAddressCreator();
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(useOriginal, this, creator, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), IPAddressSection.getNetworkSegmentIndex(prefLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT), IPAddressSection.getHostSegmentIndex(prefLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT), (index) => this.getSegment(index).prefixBlockIterator()), prefLength);
    }

    public segmentsIterator$boolean(excludeZeroHosts : boolean) : any {
        return this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(this.getSegmentCreator(), () => this.getLower().getSegments(), (index) => this.getSegment(index).iterator(), excludeZeroHosts?(segments) => { return this.isZeroHost(segments) }:<any>(null));
    }

    public segmentsIterator(excludeZeroHosts? : any) : any {
        if(((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>this.segmentsIterator$boolean(excludeZeroHosts);
        } else if(excludeZeroHosts === undefined) {
            return <any>this.segmentsIterator$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {*}
     */
    public segmentsNonZeroHostIterator() : any {
        return this.segmentsIterator$boolean(true);
    }

    public segmentsIterator$() : any {
        return this.segmentsIterator$boolean(false);
    }

    iterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator$boolean(original : IPv4Address, creator : AddressCreator<IPv4Address, any, any, IPv4AddressSegment>, excludeZeroHosts : boolean) : any {
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        let useOriginal : boolean = !this.isMultiple() && (!isAllSubnets || !this.isPrefixed());
        if(useOriginal && excludeZeroHosts && original.includesZeroHost()) {
            original = null;
        }
        return AddressDivisionGrouping.iterator(original, creator, useOriginal, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(creator, () => this.getLower().getSegmentsInternal(), (index) => this.getSegment(index).iterator(), excludeZeroHosts?(segments) => { return this.isZeroHost(segments) }:<any>(null)), isAllSubnets?null:this.getPrefixLength());
    }

    public prefixBlockIterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator(original : IPv4Address, creator : AddressCreator<IPv4Address, any, any, IPv4AddressSegment>) : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator$boolean(original, creator, false);
        }
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(original, creator, useOriginal, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), IPAddressSection.getNetworkSegmentIndex(prefLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT), IPAddressSection.getHostSegmentIndex(prefLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT), (index) => this.getSegment(index).prefixBlockIterator()), prefLength);
    }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(((original != null && original instanceof <any>IPv4Address) || original === null) && ((creator != null && creator instanceof <any>AddressCreator) || creator === null)) {
            return <any>this.prefixBlockIterator$inet_ipaddr_ipv4_IPv4Address$inet_ipaddr_format_AddressCreator(original, creator);
        } else if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    static getMaxValue(segmentCount : number) : number {
        return IPv4AddressSection.MAX_VALUES_$LI$()[segmentCount];
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv4AddressSection}
     */
    public incrementBoundary(increment : number) : IPv4AddressSection {
        if(increment <= 0) {
            if(increment === 0) {
                return this;
            }
            return this.getLower().increment(increment);
        }
        return this.getUpper().increment(increment);
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv4AddressSection}
     */
    public increment(increment : number) : IPv4AddressSection {
        if(increment === 0 && !this.isMultiple()) {
            return this;
        }
        let lowerValue : number = 4294967295 & this.intValue();
        let upperValue : number = 4294967295 & this.upperIntValue();
        let count : number = this.getCount().longValue();
        AddressDivisionGrouping.checkOverflow$long$long$long$long$java_util_function_LongSupplier(increment, lowerValue, upperValue, count, () => IPv4AddressSection.getMaxValue(this.getSegmentCount()));
        return <any>(AddressDivisionGrouping.increment(this, increment, this.getAddressCreator(), count, lowerValue, upperValue, () => { return this.getLower() }, () => { return this.getUpper() }, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength()));
    }

    static getCount(countProvider : any, segCount : number) : number {
        let result : number = (target => (typeof target === 'function')?target(0):(<any>target).applyAsInt(0))(countProvider);
        for(let i : number = 1; i < segCount; i++) {
            result *= (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(countProvider);
        };
        return result;
    }

    public getIPv4Count(excludeZeroHosts : boolean) : number {
        if(!this.isMultiple()) {
            if(excludeZeroHosts && this.isZero()) {
                return 0;
            }
            return 1;
        }
        let segCount : number = this.getSegmentCount();
        let result : number = IPv4AddressSection.getCount((i) => this.getSegment(i).getValueCount(), segCount);
        if(excludeZeroHosts && this.includesZeroHost()) {
            let prefixedSegment : number = IPAddressSection.getNetworkSegmentIndex(this.getNetworkPrefixLength(), this.getBytesPerSegment(), this.getBitsPerSegment());
            let zeroHostCount : number = IPv4AddressSection.getCount(((prefixedSegment) => {
                return (i) => {
                    if(i === prefixedSegment) {
                        let seg : IPAddressSegment = this.getSegment(i);
                        let shift : number = seg.getBitCount() - seg.getSegmentPrefixLength();
                        let count : number = ((seg.getUpperSegmentValue() >>> shift) - (seg.getLowerSegmentValue() >>> shift)) + 1;
                        return count;
                    }
                    return this.getSegment(i).getValueCount();
                }
            })(prefixedSegment), prefixedSegment + 1);
            result -= zeroHostCount;
        }
        return result;
    }

    public getCountImpl$boolean(excludeZeroHosts : boolean) : BigInteger {
        if(!this.isMultiple()) {
            if(excludeZeroHosts && this.includesZeroHost()) {
                return BigInteger.ZERO;
            }
            return BigInteger.ONE;
        }
        return BigInteger.valueOf(this.getIPv4Count(excludeZeroHosts));
    }

    /**
     * 
     * @param {boolean} excludeZeroHosts
     * @return {BigInteger}
     */
    public getCountImpl(excludeZeroHosts? : any) : any {
        if(((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>this.getCountImpl$boolean(excludeZeroHosts);
        } else if(excludeZeroHosts === undefined) {
            return <any>this.getCountImpl$();
        } else throw new Error('invalid overload');
    }

    public getIPv4PrefixCount() : number {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength == null || prefixLength >= this.getBitCount() || !this.isMultiple()) {
            return this.getIPv4Count(false);
        }
        let networkSegmentIndex : number = IPAddressSection.getNetworkSegmentIndex(prefixLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT);
        let hostSegmentIndex : number = IPAddressSection.getHostSegmentIndex(prefixLength, IPv4Address.BYTES_PER_SEGMENT, IPv4Address.BITS_PER_SEGMENT);
        let hasPrefixedSegment : boolean = (networkSegmentIndex === hostSegmentIndex);
        return IPv4AddressSection.getCount(((hasPrefixedSegment,networkSegmentIndex) => {
            return (i) => {
                if(hasPrefixedSegment && i === networkSegmentIndex) {
                    return this.getSegment(i).getPrefixValueCount();
                }
                return this.getSegment(i).getValueCount();
            }
        })(hasPrefixedSegment,networkSegmentIndex), networkSegmentIndex + 1);
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getPrefixCount() : BigInteger {
        return BigInteger.valueOf(this.getIPv4PrefixCount());
    }

    getSegmentCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.getIPv4SegmentCreator();
    }

    getAddressCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.getIPv4SegmentCreator();
    }

    getIPv4SegmentCreator() : IPv4AddressNetwork.IPv4AddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    /**
     * 
     * @param {number} index
     * @return {IPv4AddressSegment}
     */
    public getDivision(index : number) : IPv4AddressSegment {
        return <IPv4AddressSegment>super.getDivision(index);
    }

    /**
     * 
     * @param {number} index
     * @return {IPv4AddressSegment}
     */
    public getSegment(index : number) : IPv4AddressSegment {
        return <IPv4AddressSegment>super.getSegment(index);
    }

    public getSegments$java_util_Collection(segs : Array<any>) {
        this.getSegments$int$int$java_util_Collection(0, this.getSegmentCount(), segs);
    }

    public getSegments$int$int$java_util_Collection(start : number, end : number, segs : Array<any>) {
        for(let i : number = start; i < end; i++) {
            /* add */(segs.push(this.getSegment(i))>0);
        };
    }

    /**
     * 
     * @return {number}
     */
    public getBitsPerSegment() : number {
        return IPv4Address.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBytesPerSegment() : number {
        return IPv4Address.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSegmentCount() << 3;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSegmentCount();
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        let segmentCount : number = this.getSegmentCount();
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(segmentCount);
        for(let i : number = 0; i < segmentCount; i++) {
            let seg : IPv4AddressSegment = this.getSegment(i);
            let val : number = low?seg.getLowerSegmentValue():seg.getUpperSegmentValue();
            bytes[i] = (<number>val|0);
        };
        return bytes;
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv4() : boolean {
        return true;
    }

    /**
     * 
     * @return {IPAddress.IPVersion}
     */
    public getIPVersion() : IPAddress.IPVersion {
        return IPAddress.IPVersion.IPV4;
    }

    /**
     * 
     * @param {IPAddressSection} other
     * @param {IPAddressSection} mask
     * @return {boolean}
     */
    public matchesWithMask(other : IPAddressSection, mask : IPAddressSection) : boolean {
        return (other != null && other instanceof <any>IPv4AddressSection) && (mask != null && mask instanceof <any>IPv4AddressSection) && super.matchesWithMask(other, mask);
    }

    /**
     * 
     * @param {AddressDivisionGrouping} other
     * @return {boolean}
     */
    isSameGrouping(other : AddressDivisionGrouping) : boolean {
        return (other != null && other instanceof <any>IPv4AddressSection) && super.isSameGrouping(other);
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>IPv4AddressSection) {
            return super.isSameGrouping(<IPv4AddressSection>o);
        }
        return false;
    }

    public append(other : IPv4AddressSection) : IPv4AddressSection {
        let count : number = this.getSegmentCount();
        return this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(count, count, other, 0, other.getSegmentCount());
    }

    public insert(index : number, other : IPv4AddressSection) : IPv4AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(index, index, other, 0, other.getSegmentCount());
    }

    public replace$int$inet_ipaddr_ipv4_IPv4AddressSection(index : number, other : IPv4AddressSection) : IPv4AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(index, index + other.getSegmentCount(), other, 0, other.getSegmentCount());
    }

    public appendToNetwork(other : IPv4AddressSection) : IPv4AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null) {
            return this.append(other);
        }
        let thizz : IPv4AddressSection = this;
        let bitsPerSegment : number = this.getBitsPerSegment();
        let adjustment : number = prefixLength % bitsPerSegment;
        if(adjustment !== 0) {
            prefixLength += bitsPerSegment - adjustment;
            thizz = this.setPrefixLength$int$boolean(prefixLength, false);
        }
        let index : number = prefixLength >>> 3;
        if(other.isPrefixed() && other.getPrefixLength() === 0) {
            return this.insert(index, other);
        }
        return thizz.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int$boolean(index, index, other, 0, other.getSegmentCount(), true);
    }

    public replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(startIndex : number, endIndex : number, replacement : IPv4AddressSection, replacementStartIndex : number, replacementEndIndex : number) : IPv4AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, false);
    }

    public replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int$boolean(startIndex : number, endIndex : number, replacement : IPv4AddressSection, replacementStartIndex : number, replacementEndIndex : number, appendNetwork : boolean) : IPv4AddressSection {
        let segmentCount : number = this.getSegmentCount();
        let replacedCount : number = endIndex - startIndex;
        let replacementCount : number = replacementEndIndex - replacementStartIndex;
        if(replacedCount < 0 || replacementCount < 0 || startIndex < 0 || replacementStartIndex < 0 || replacementEndIndex > replacement.getSegmentCount() || endIndex > segmentCount) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.IndexOutOfBoundsException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }
        let thizz : IPv4AddressSection = this;
        if(segmentCount + replacementCount - replacedCount > IPv4Address.SEGMENT_COUNT) {
            throw new AddressValueException(this, replacement, segmentCount + replacementCount - replacedCount);
        } else if(replacementCount === 0 && replacedCount === 0) {
            return this;
        } else if(segmentCount === replacedCount) {
            return replacement;
        } else if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            if(appendNetwork) {
                thizz = this.removePrefixLength$boolean(false);
                let replacementEndBits : number = replacementEndIndex << 3;
                if(!replacement.isPrefixed() || replacement.getNetworkPrefixLength() > replacementEndBits) {
                    replacement = replacement.setPrefixLength$int$boolean(replacementEndBits, false);
                }
            }
        } else {
            let prefixLength : number = this.getPrefixLength();
            if(appendNetwork) {
                let additionalSegs : number = segmentCount - endIndex;
                if(additionalSegs > 0) {
                    thizz = this.getSection$int$int(0, startIndex).removePrefixLength$boolean(false);
                    replacement = replacement.insert(replacementEndIndex, this.getSection$int(endIndex));
                    replacementEndIndex += additionalSegs;
                    endIndex = startIndex;
                } else {
                    thizz = this.removePrefixLength$boolean(false);
                    let replacementEndBits : number = replacementEndIndex << 3;
                    if(!replacement.isPrefixed() || replacement.getNetworkPrefixLength() > replacementEndBits) {
                        replacement = replacement.setPrefixLength$int$boolean(replacementEndBits, false);
                    }
                }
            } else if(prefixLength != null && !appendNetwork && prefixLength <= startIndex << 3) {
                replacement = replacement.setPrefixLength$int$boolean(0, false);
            } else if(endIndex < segmentCount) {
                let replacementEndBits : number = replacementEndIndex << 3;
                if(replacement.isPrefixed() && replacement.getNetworkPrefixLength() <= replacementEndBits) {
                    let thisNextIndexBits : number = endIndex << 3;
                    if(prefixLength == null || prefixLength > thisNextIndexBits) {
                        if(replacedCount > 0 || replacement.getPrefixLength() === 0) {
                            thizz = this.setPrefixLength$int$boolean(thisNextIndexBits, false);
                        } else {
                            let additionalSegs : number = segmentCount - endIndex;
                            thizz = this.getSection$int$int(0, startIndex);
                            replacement = replacement.insert(replacementEndIndex, this.getSection$int(endIndex));
                            replacementEndIndex += additionalSegs;
                        }
                    }
                }
            }
        }
        return <any>(AddressDivisionGrouping.replace<any, any>(thizz, startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, this.getAddressCreator(), appendNetwork, false));
    }

    public replace(startIndex? : any, endIndex? : any, replacement? : any, replacementStartIndex? : any, replacementEndIndex? : any, appendNetwork? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>IPv4AddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && ((typeof appendNetwork === 'boolean') || appendNetwork === null)) {
            return <any>this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, appendNetwork);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>IPv4AddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && appendNetwork === undefined) {
            return <any>this.replace$int$int$inet_ipaddr_ipv4_IPv4AddressSection$int$int(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((endIndex != null && endIndex instanceof <any>IPv4AddressSection) || endIndex === null) && replacement === undefined && replacementStartIndex === undefined && replacementEndIndex === undefined && appendNetwork === undefined) {
            return <any>this.replace$int$inet_ipaddr_ipv4_IPv4AddressSection(startIndex, endIndex);
        } else throw new Error('invalid overload');
    }

    /**
     * Produces the subnet sections whose addresses are found in both this and the given argument.
     * <p>
     * This is also known as the conjunction of the two sets of address sections.
     * <p>
     * @param {IPv4AddressSection} other
     * @return {IPv4AddressSection} the section containing the sections found in both this and the given subnet sections
     */
    public intersect(other : IPv4AddressSection) : IPv4AddressSection {
        return <any>(IPAddressSection.intersect<any, any, any>(this, other, this.getAddressCreator(), (index) => { return this.getSegment(index) }, (index) => { return other.getSegment(index) }));
    }

    /**
     * Subtract the given subnet from this subnet, returning an array of sections for the result (the subnets will not be contiguous so an array is required).
     * <p>
     * Computes the subnet difference, the set of addresses in this address section but not in the provided section.  This is also known as the relative complement of the given argument in this subnet.
     * <p>
     * Keep in mind this is set subtraction, not subtraction of segment values.  We have a subnet of addresses and we are removing some of those addresses.
     * 
     * @param {IPv4AddressSection} other
     * @throws SizeMismatchException if the two sections are different sizes
     * @return {Array} the difference
     */
    public subtract(other : IPv4AddressSection) : IPv4AddressSection[] {
        return IPAddressSection.subtract<any, any, any>(this, other, this.getAddressCreator(), (index) => { return this.getSegment(index) }, (section, prefix) => section.setPrefixLength$int$boolean$boolean(prefix, false, true));
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public contains(other : AddressSection) : boolean {
        return (other != null && other instanceof <any>IPv4AddressSection) && super.contains(other);
    }

    /**
     * 
     * @return {IPv4AddressNetwork}
     */
    public getNetwork() : IPv4AddressNetwork {
        return Address.defaultIpv4Network();
    }

    public getNetworkPrefixLength$int$int(segmentIndex : number, segmentPrefix : number) : number {
        return (segmentIndex << 3) + segmentPrefix;
    }

    /**
     * 
     * @param {number} segmentIndex
     * @param {number} segmentPrefix
     * @return {number}
     */
    public getNetworkPrefixLength(segmentIndex? : any, segmentPrefix? : any) : any {
        if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((typeof segmentPrefix === 'number') || segmentPrefix === null)) {
            return <any>this.getNetworkPrefixLength$int$int(segmentIndex, segmentPrefix);
        } else if(segmentIndex === undefined && segmentPrefix === undefined) {
            return <any>this.getNetworkPrefixLength$();
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPv4AddressSection {
        return this.adjustPrefixBySegment$boolean$boolean(nextSegment, true);
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPv4AddressSection {
        return <IPv4AddressSection>super.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPv4AddressSection}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : IPv4AddressSection {
        return this.adjustPrefixLength$int$boolean(adjustment, true);
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPv4AddressSection {
        return <IPv4AddressSection>IPAddressSection.adjustPrefixLength<any, any>(this, adjustment, zeroed, this.getAddressCreator(), (section, i) => section.getSegment(i));
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPv4AddressSection}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4AddressSection}
     */
    public applyPrefixLength(networkPrefixLength : number) : IPv4AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, true, true);
    }

    public setPrefixLength$int(networkPrefixLength : number) : IPv4AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, true, false);
    }

    public setPrefixLength$int$boolean(networkPrefixLength : number, withZeros : boolean) : IPv4AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, withZeros, false);
    }

    public setPrefixLength$int$boolean$boolean(networkPrefixLength : number, withZeros : boolean, noShrink : boolean) : IPv4AddressSection {
        return <any>(IPAddressSection.setPrefixLength<any, any>(this, this.getAddressCreator(), networkPrefixLength, withZeros, noShrink, (section, i) => section.getSegment(i)));
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && ((typeof noShrink === 'boolean') || noShrink === null)) {
            return <any>this.setPrefixLength$int$boolean$boolean(networkPrefixLength, withZeros, noShrink);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public removePrefixLength$() : IPv4AddressSection {
        return this.removePrefixLength$boolean(true);
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPv4AddressSection {
        return <any>(IPAddressSection.removePrefixLength<any, any>(this, zeroed, this.getAddressCreator(), (index) => { return IPv4AddressSection.getSegment(index) }));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPv4AddressSection}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    public toZeroHost$() : IPv4AddressSection {
        if(!this.isPrefixed()) {
            let networkMask : IPv4Address = this.getNetwork().getNetworkMask(0, !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets());
            return networkMask.getSection$int$int(0, this.getSegmentCount());
        }
        if(this.includesZeroHost() && this.isSingleNetwork()) {
            return this.getLower();
        }
        return this.createZeroHost();
    }

    createZeroHost() : IPv4AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        let mask : IPv4Address = this.getNetwork().getNetworkMask(prefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:prefixLength, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask), true));
    }

    public toZeroHost$int(prefixLength : number) : IPv4AddressSection {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toZeroHost();
        }
        let mask : IPv4Address = this.getNetwork().getNetworkMask(prefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, null, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask), true));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv4AddressSection}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toZeroHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPv4AddressSection {
        if(!this.isPrefixed()) {
            let resultNoPrefix : IPv4Address = this.getNetwork().getHostMask(0);
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                return resultNoPrefix.getSection$int$int(0, this.getSegmentCount());
            }
            return resultNoPrefix.setPrefixLength$int(0).getSection$int$int(0, this.getSegmentCount());
        }
        if(this.includesZeroHost() && this.isSingleNetwork()) {
            return this.getLower();
        }
        return this.createMaxHost();
    }

    public createMaxHost() : IPv4AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        let mask : IPv4Address = this.getNetwork().getHostMask(prefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:prefixLength, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask)));
    }

    public toMaxHost$int(prefixLength : number) : IPv4AddressSection {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toMaxHost();
        }
        let mask : IPv4Address = this.getNetwork().getHostMask(prefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, null, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask)));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv4AddressSection}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toMaxHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask : IPv4AddressSection, retainPrefix : boolean) : IPv4AddressSection {
        this.checkMaskSectionCount(mask);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, retainPrefix?this.getPrefixLength():null, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue(), false));
    }

    /**
     * Does the bitwise conjunction with this address.  Useful when subnetting.
     * 
     * @param {IPv4AddressSection} mask
     * @param {boolean} retainPrefix whether to drop the prefix
     * @return
     * @throws IncompatibleAddressException
     * @return {IPv4AddressSection}
     */
    public mask(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPv4AddressSection) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.mask$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPv4AddressSection) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_ipv4_IPv4AddressSection(mask);
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_ipv4_IPv4AddressSection(mask : IPv4AddressSection) : IPv4AddressSection {
        return this.mask$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask, false);
    }

    /**
     * Produces the bitwise conjunction of the given mask with the network section of the address as indicated by the given prefix length.
     * Useful for subnetting.  Once you have zeroed a section of the network you can insert bits
     * using {@link #bitwiseOr(IPv4AddressSection)} or {@link #replace(int, IPv4AddressSection)}
     * 
     * @param {IPv4AddressSection} mask
     * @param {number} networkPrefixLength
     * @return
     * @throws IncompatibleAddressException
     * @return {IPv4AddressSection}
     */
    public maskNetwork(mask : IPv4AddressSection, networkPrefixLength : number) : IPv4AddressSection {
        this.checkMaskSectionCount(mask);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return <any>(IPAddressSection.getSubnetSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue(), false));
        }
        let hostMask : IPv4AddressSection = this.getNetwork().getHostMaskSection(networkPrefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, ((hostMask) => {
            return (i) => {
                let val1 : number = mask.getSegment(i).getLowerSegmentValue();
                let val2 : number = hostMask.getSegment(i).getLowerSegmentValue();
                return val1 | val2;
            }
        })(hostMask), false));
    }

    public bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection(mask : IPv4AddressSection) : IPv4AddressSection {
        return this.bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask, false);
    }

    public bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask : IPv4AddressSection, retainPrefix : boolean) : IPv4AddressSection {
        this.checkMaskSectionCount(mask);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, retainPrefix?this.getPrefixLength():null, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue()));
    }

    /**
     * Does the bitwise disjunction with this address section.  Useful when subnetting.  Similar to {@link #mask(IPv4AddressSection)} which does the bitwise conjunction.
     * 
     * @param {boolean} retainPrefix whether the result will retain the same prefix length as this.
     * @return
     * @throws IncompatibleAddressException
     * @param {IPv4AddressSection} mask
     * @return {IPv4AddressSection}
     */
    public bitwiseOr(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPv4AddressSection) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPv4AddressSection) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_ipv4_IPv4AddressSection(mask);
        } else throw new Error('invalid overload');
    }

    /**
     * Does the bitwise disjunction with this address section.  Useful when subnetting.  Similar to {@link #maskNetwork(IPv4AddressSection, int)} which does the bitwise conjunction.
     * <p>
     * Any existing prefix length is dropped for the new prefix length and the disjunction is applied up to the end the new prefix length.
     * 
     * @param {IPv4AddressSection} mask
     * @return
     * @throws IncompatibleAddressException
     * @param {number} networkPrefixLength
     * @return {IPv4AddressSection}
     */
    public bitwiseOrNetwork(mask : IPv4AddressSection, networkPrefixLength : number) : IPv4AddressSection {
        this.checkMaskSectionCount(mask);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return <any>(IPAddressSection.getOredSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue()));
        }
        let networkMask : IPv4AddressSection = this.getNetwork().getNetworkMaskSection(networkPrefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, ((networkMask) => {
            return (i) => {
                let val1 : number = mask.getSegment(i).getLowerSegmentValue();
                let val2 : number = networkMask.getSegment(i).getLowerSegmentValue();
                return val1 & val2;
            }
        })(networkMask)));
    }

    public getNetworkSection$() : IPv4AddressSection {
        if(this.isPrefixed()) {
            return this.getNetworkSection$int(this.getNetworkPrefixLength());
        }
        return this.getNetworkSection$int(this.getBitCount());
    }

    public getNetworkSection$int(networkPrefixLength : number) : IPv4AddressSection {
        return this.getNetworkSection$int$boolean(networkPrefixLength, true);
    }

    public getNetworkSection$int$boolean(networkPrefixLength : number, withPrefixLength : boolean) : IPv4AddressSection {
        return <any>(IPAddressSection.getNetworkSection<any, any, any>(this, networkPrefixLength, withPrefixLength, this.getAddressCreator(), (i, prefix) => this.getSegment(i).toNetworkSegment$java_lang_Integer$boolean(prefix, withPrefixLength)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @param {boolean} withPrefixLength
     * @return {IPv4AddressSection}
     */
    public getNetworkSection(networkPrefixLength? : any, withPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null)) {
            return <any>this.getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$();
        } else throw new Error('invalid overload');
    }

    public getHostSection$() : IPv4AddressSection {
        if(this.isPrefixed()) {
            return this.getHostSection$int(this.getNetworkPrefixLength());
        }
        return this.getHostSection$int(0);
    }

    public getHostSection$int(networkPrefixLength : number) : IPv4AddressSection {
        let hostSegmentCount : number = this.getHostSegmentCount$int(networkPrefixLength);
        return <any>(IPAddressSection.getHostSection<any, any, any>(this, networkPrefixLength, hostSegmentCount, this.getAddressCreator(), (i, prefix) => this.getSegment(i).toHostSegment$java_lang_Integer(prefix)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4AddressSection}
     */
    public getHostSection(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostSection$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : IPv4AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null || AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return this;
        }
        return this.toPrefixBlock$int(prefixLength);
    }

    public toPrefixBlock$int(networkPrefixLength : number) : IPv4AddressSection {
        return <any>(IPAddressSection.toPrefixBlock<any, any, any>(this, networkPrefixLength, this.getAddressCreator(), (i, prefix) => this.getSegment(i).toNetworkSegment$java_lang_Integer$boolean(prefix, true)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv4AddressSection}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            super.toPrefixBlock(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public assignPrefixForSingleBlock() : IPv4AddressSection {
        return <IPv4AddressSection>super.assignPrefixForSingleBlock();
    }

    /**
     * 
     * @return {IPv4AddressSection}
     */
    public assignMinPrefixForBlock() : IPv4AddressSection {
        return <IPv4AddressSection>super.assignMinPrefixForBlock();
    }

    /**
     * Produces the list of prefix block subnets that span from this series to the given series.
     * 
     * @param {IPv4AddressSection} other
     * @return
     * @return {Array}
     */
    public getSpanningPrefixBlocks(other : IPv4AddressSection) : IPv4AddressSection[] {
        return IPAddressSection.getSpanningPrefixBlocks<any>(this, other, () => { return IPv4AddressSection.getLower() }, () => { return IPv4AddressSection.getUpper() }, (one,two) => { return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$().compare(one,two) }, (section) => section.removePrefixLength$boolean(false), (length) => { return this.getAddressCreator().createSectionArray(length) });
    }

    /**
     * Merges this with the list of sections to produce the smallest array of prefix blocks, going from smallest to largest
     * 
     * @param {Array} sections the sections to merge with this
     * @return
     * @return {Array}
     */
    public mergeBlocks(...sections : IPv6AddressSection[]) : IPv4AddressSection[] {
        if(sections.length === 0) {
            return [this];
        }
        let blocks : Array<IPAddressSegmentSeries> = IPAddressSection.getMergedBlocks(this, sections, true);
        return /* toArray */blocks.slice(0);
    }

    /**
     * 
     * @return {boolean}
     */
    hasNoStringCache() : boolean {
        if(this.stringCache == null) {
            {
                if(this.stringCache == null) {
                    this.stringCache = new IPv4AddressSection.IPv4StringCache();
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 
     * @return {IPv4AddressSection.IPv4StringCache}
     */
    getStringCache() : IPv4AddressSection.IPv4StringCache {
        return this.stringCache;
    }

    /**
     * This produces a canonical string.
     * 
     * If this has a prefix length, that will be included in the string.
     * @return {string}
     */
    public toCanonicalString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.canonicalString) == null) {
            this.stringCache.canonicalString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.canonicalParams_$LI$());
        }
        return result;
    }

    /**
     * This produces a string with no compressed segments and all segments of full length,
     * which is 3 characters for IPv4 segments.
     * @return {string}
     */
    public toFullString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.fullString) == null) {
            this.stringCache.fullString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.fullParams_$LI$());
        }
        return result;
    }

    /**
     * The shortest string for IPv4 addresses is the same as the canonical string.
     * @return {string}
     */
    public toCompressedString() : string {
        return this.toCanonicalString();
    }

    public toNormalizedString$() : string {
        return this.toCanonicalString();
    }

    /**
     * 
     * @param {string} str
     */
    cacheNormalizedString(str : string) {
        if(this.hasNoStringCache() || this.stringCache.canonicalString == null) {
            this.stringCache.canonicalString = str;
        }
    }

    /**
     * 
     * @return {string}
     */
    public toCompressedWildcardString() : string {
        return this.toNormalizedWildcardString();
    }

    /**
     * 
     * @return {string}
     */
    public toSubnetString() : string {
        return this.toNormalizedWildcardString();
    }

    /**
     * 
     * @return {string}
     */
    public toPrefixLengthString() : string {
        return this.toCanonicalString();
    }

    public toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix : IPv4Address.inet_aton_radix) : string {
        let result : string;
        if(radix === IPv4Address.inet_aton_radix.OCTAL) {
            if(this.hasNoStringCache() || (result = this.stringCache.octalString) == null) {
                this.stringCache.octalString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.inetAtonOctalParams_$LI$());
            }
        } else if(radix === IPv4Address.inet_aton_radix.HEX) {
            if(this.hasNoStringCache() || (result = this.stringCache.hexString) == null) {
                this.stringCache.hexString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.inetAtonHexParams_$LI$());
            }
        } else {
            result = this.toCanonicalString();
        }
        return result;
    }

    public toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix : IPv4Address.inet_aton_radix, joinedCount : number) : string {
        if(joinedCount <= 0) {
            return this.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix);
        }
        let stringParams : IPAddressSection.IPStringOptions;
        if(radix === IPv4Address.inet_aton_radix.OCTAL) {
            stringParams = IPv4AddressSection.IPv4StringCache.inetAtonOctalParams_$LI$();
        } else if(radix === IPv4Address.inet_aton_radix.HEX) {
            stringParams = IPv4AddressSection.IPv4StringCache.inetAtonHexParams_$LI$();
        } else {
            stringParams = IPv4AddressSection.IPv4StringCache.canonicalParams_$LI$();
        }
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$int(stringParams, joinedCount);
    }

    public toInetAtonString(radix? : any, joinedCount? : any) : any {
        if(((typeof radix === 'number') || radix === null) && ((typeof joinedCount === 'number') || joinedCount === null)) {
            return <any>this.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix$int(radix, joinedCount);
        } else if(((typeof radix === 'number') || radix === null) && joinedCount === undefined) {
            return <any>this.toInetAtonString$inet_ipaddr_ipv4_IPv4Address_inet_aton_radix(radix);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {string}
     */
    public toNormalizedWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.normalizedWildcardString) == null) {
            this.stringCache.normalizedWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.normalizedWildcardParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toCanonicalWildcardString() : string {
        return this.toNormalizedWildcardString();
    }

    /**
     * 
     * @return {string}
     */
    public toSQLWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.sqlWildcardString) == null) {
            this.stringCache.sqlWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.sqlWildcardParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toReverseDNSLookupString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.reverseDNSString) == null) {
            this.stringCache.reverseDNSString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv4AddressSection.IPv4StringCache.reverseDNSParams_$LI$());
        }
        return result;
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$int(stringParams : IPAddressSection.IPStringOptions, joinCount : number) : string {
        if(joinCount <= 0) {
            return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringParams);
        }
        let thisCount : number = this.getSegmentCount();
        if(thisCount <= 1) {
            return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringParams);
        }
        let equivalentPart : IPAddressStringDivisionSeries = this.toJoinedSegments(joinCount);
        return IPAddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_IPAddressStringDivisionSeries(stringParams, equivalentPart);
    }

    public toNormalizedString(stringParams? : any, joinCount? : any) : any {
        if(((stringParams != null && stringParams instanceof <any>IPAddressSection.IPStringOptions) || stringParams === null) && ((typeof joinCount === 'number') || joinCount === null)) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$int(stringParams, joinCount);
        } else if(((stringParams != null && stringParams instanceof <any>IPAddressSection.IPStringOptions) || stringParams === null) && joinCount === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringParams);
        } else if(stringParams === undefined && joinCount === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toJoinedSegments(joinCount : number) : IPAddressDivisionGrouping {
        let thisCount : number = this.getSegmentCount();
        if(joinCount <= 0 || thisCount <= 1) {
            return this;
        }
        let totalCount : number;
        if(joinCount >= thisCount) {
            joinCount = thisCount - 1;
            totalCount = 1;
        } else {
            totalCount = thisCount - joinCount;
        }
        let notJoinedCount : number = totalCount - 1;
        let segs : IPAddressDivision[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(totalCount);
        let i : number = 0;
        for(; i < notJoinedCount; i++) {
            segs[i] = this.getDivision(i);
        };
        let joinedSegment : IPv4JoinedSegments = this.joinSegments(joinCount);
        segs[notJoinedCount] = joinedSegment;
        let equivalentPart : IPAddressDivisionGrouping = new IPAddressDivisionGrouping(segs, this.getNetwork());
        return equivalentPart;
    }

    joinSegments(joinCount : number) : IPv4JoinedSegments {
        let lower : number = 0;
        let upper : number = 0;
        let networkPrefixLength : number = 0;
        let prefix : number = null;
        let firstSegIndex : number = 0;
        let firstRange : IPv4AddressSegment = null;
        let firstJoinedIndex : number = this.getSegmentCount() - 1 - joinCount;
        for(let j : number = 0; j <= joinCount; j++) {
            let thisSeg : IPv4AddressSegment = this.getSegment(firstJoinedIndex + j);
            if(firstRange != null) {
                if(!thisSeg.isFullRange()) {
                    throw new IncompatibleAddressException(firstRange, firstSegIndex, thisSeg, firstJoinedIndex + j, "ipaddress.error.segmentMismatch");
                }
            } else if(thisSeg.isMultiple()) {
                firstSegIndex = firstJoinedIndex + j;
                firstRange = thisSeg;
            }
            lower = lower << IPv4Address.BITS_PER_SEGMENT | thisSeg.getLowerSegmentValue();
            upper = upper << IPv4Address.BITS_PER_SEGMENT | thisSeg.getUpperSegmentValue();
            if(prefix == null) {
                let thisSegPrefix : number = thisSeg.getSegmentPrefixLength();
                if(thisSegPrefix != null) {
                    prefix = networkPrefixLength + thisSegPrefix;
                } else {
                    networkPrefixLength += thisSeg.getBitCount();
                }
            }
        };
        let joinedSegment : IPv4JoinedSegments = new IPv4JoinedSegments(joinCount, lower, upper, prefix);
        return joinedSegment;
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toAllStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.STANDARD_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toDatabaseSearchStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.DATABASE_SEARCH_OPTS_$LI$());
    }

    public toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts : IPAddressSection.IPStringBuilderOptions) : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.from(opts));
    }

    public toStringCollection$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(opts : IPv4AddressSection.IPv4StringBuilderOptions) : IPAddressPartStringCollection {
        let collection : IPv4AddressSection.IPv4SectionStringCollection = new IPv4AddressSection.IPv4SectionStringCollection();
        let parts : IPAddressStringDivisionSeries[] = this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        for(let index130=0; index130 < parts.length; index130++) {
            let part = parts[index130];
            {
                let builder : IPv4StringCollection.IPv4StringBuilder = new IPv4StringCollection.IPv4StringBuilder(part, opts, new IPv4StringCollection.IPv4AddressSectionStringCollection(part));
                let subCollection : IPv4StringCollection.IPv4AddressSectionStringCollection = builder.getVariations();
                collection.add(subCollection);
            }
        }
        return collection;
    }

    public toStringCollection(opts? : any) : any {
        if(((opts != null && opts instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(opts);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        return this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv4AddressSection.IPv4StringBuilderOptions.from(options));
    }

    public getParts$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(options : IPv4AddressSection.IPv4StringBuilderOptions) : IPAddressStringDivisionSeries[] {
        if(!options.includesAny(IPv4AddressSection.IPv4StringBuilderOptions.ALL_JOINS_$LI$())) {
            return super.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        }
        let parts : Array<IPAddressStringDivisionSeries> = <any>([]);
        if(options.includes(IPAddressSection.IPStringBuilderOptions.BASIC)) {
            /* add */(parts.push(this)>0);
        }
        let joined : boolean[] = (s => { let a=[]; while(s-->0) a.push(false); return a; })(IPv4Address.SEGMENT_COUNT);
        let segmentCount : number = this.getSegmentCount();
        joined[Math.max(3, segmentCount - 1)] = options.includes(IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ALL);
        joined[Math.max(2, Math.min(2, segmentCount - 1))] = options.includes(IPv4AddressSection.IPv4StringBuilderOptions.JOIN_TWO) || joined[Math.max(2, Math.min(2, segmentCount - 1))];
        joined[Math.max(1, Math.min(1, segmentCount - 1))] = options.includes(IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ONE) || joined[Math.max(1, Math.min(1, segmentCount - 1))];
        for(let i : number = 1; i < joined.length; i++) {
            if(joined[i]) {
                /* add */(parts.push(this.toJoinedSegments(i))>0);
            }
        };
        return /* toArray */parts.slice(0);
    }

    public getParts(options? : any) : any {
        if(((options != null && options instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringBuilderOptions(options);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        } else throw new Error('invalid overload');
    }
}
IPv4AddressSection["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection";
IPv4AddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



export namespace IPv4AddressSection {

    export class IPv4StringCache extends IPAddressSection.IPStringCache {
        static __static_initialized : boolean = false;
        static __static_initialize() { if(!IPv4StringCache.__static_initialized) { IPv4StringCache.__static_initialized = true; IPv4StringCache.__static_initializer_0(); } }

        static fullParams : IPAddressSection.IPStringOptions; public static fullParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.fullParams; };

        static normalizedWildcardParams : IPAddressSection.IPStringOptions; public static normalizedWildcardParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.normalizedWildcardParams; };

        static sqlWildcardParams : IPAddressSection.IPStringOptions; public static sqlWildcardParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.sqlWildcardParams; };

        static inetAtonOctalParams : IPAddressSection.IPStringOptions; public static inetAtonOctalParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.inetAtonOctalParams; };

        static inetAtonHexParams : IPAddressSection.IPStringOptions; public static inetAtonHexParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.inetAtonHexParams; };

        static canonicalParams : IPAddressSection.IPStringOptions; public static canonicalParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.canonicalParams; };

        static reverseDNSParams : IPAddressSection.IPStringOptions; public static reverseDNSParams_$LI$() : IPAddressSection.IPStringOptions { IPv4StringCache.__static_initialize(); return IPv4StringCache.reverseDNSParams; };

        static __static_initializer_0() {
            let allWildcards : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.ALL);
            let allSQLWildcards : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.ALL, new StringOptions.Wildcards(IPAddress.SEGMENT_SQL_WILDCARD_STR_$LI$(), IPAddress.SEGMENT_SQL_SINGLE_WILDCARD_STR_$LI$()));
            let wildcardsRangeOnlyNetworkOnly : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.NETWORK_ONLY, new StringOptions.Wildcards(IPAddress.RANGE_SEPARATOR_STR_$LI$()));
            IPv4StringCache.fullParams = new IPv4AddressSection.IPv4StringOptions.Builder().setExpandedSegments(true).setWildcardOptions(wildcardsRangeOnlyNetworkOnly).toOptions();
            IPv4StringCache.normalizedWildcardParams = new IPv4AddressSection.IPv4StringOptions.Builder().setWildcardOptions(allWildcards).toOptions();
            IPv4StringCache.sqlWildcardParams = new IPv4AddressSection.IPv4StringOptions.Builder().setWildcardOptions(allSQLWildcards).toOptions();
            IPv4StringCache.inetAtonOctalParams = new IPv4AddressSection.IPv4StringOptions.Builder().setRadix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.OCTAL].getRadix()).setSegmentStrPrefix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.OCTAL].getSegmentStrPrefix()).toOptions();
            IPv4StringCache.inetAtonHexParams = new IPv4AddressSection.IPv4StringOptions.Builder().setRadix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.HEX].getRadix()).setSegmentStrPrefix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.HEX].getSegmentStrPrefix()).toOptions();
            IPv4StringCache.canonicalParams = new IPv4AddressSection.IPv4StringOptions.Builder(IPv4Address.DEFAULT_TEXTUAL_RADIX, IPv4Address.SEGMENT_SEPARATOR).toOptions();
            IPv4StringCache.reverseDNSParams = new IPv4AddressSection.IPv4StringOptions.Builder().setWildcardOptions(allWildcards).setReverse(true).setAddressSuffix(IPv4Address.REVERSE_DNS_SUFFIX).toOptions();
        }

        public octalString : string;

        public hexString : string;

        constructor() {
            super();
            if(this.octalString===undefined) this.octalString = null;
            if(this.hexString===undefined) this.hexString = null;
        }
    }
    IPv4StringCache["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringCache";


    export class AddressCache extends AddressDivisionGrouping.SectionCache<IPv4Address> {
        constructor() {
            super();
        }
    }
    AddressCache["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.AddressCache";


    export class EmbeddedIPv4AddressSection extends IPv4AddressSection {
        static serialVersionUID : number = 4;

        encompassingSection : IPAddressSection;

        constructor(encompassingSection : IPAddressSection, subSegments : IPv4AddressSegment[]) {
            super(subSegments, false);
            if(this.encompassingSection===undefined) this.encompassingSection = null;
            this.encompassingSection = encompassingSection;
        }

        /**
         * 
         * @return {boolean}
         */
        public isPrefixBlock() : boolean {
            return this.encompassingSection.isPrefixBlock();
        }
    }
    EmbeddedIPv4AddressSection["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.EmbeddedIPv4AddressSection";
    EmbeddedIPv4AddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



    export class IPv4SectionStringCollection extends IPAddressPartStringCollection {
        /**
         * 
         * @param {IPAddressPartStringSubCollection} collection
         */
        add(collection : IPAddressPartStringSubCollection<any, any, any>) {
            super.add(collection);
        }

        /**
         * 
         * @param {IPAddressPartStringCollection} collections
         */
        addAll(collections : IPAddressPartStringCollection) {
            super.addAll(collections);
        }

        constructor() {
            super();
        }
    }
    IPv4SectionStringCollection["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4SectionStringCollection";
    IPv4SectionStringCollection["__interfaces"] = ["java.lang.Iterable"];



    export class IPv4StringBuilderOptions extends IPAddressSection.IPStringBuilderOptions {
        public static JOIN_ALL : number = 2;

        public static JOIN_TWO : number = 4;

        public static JOIN_ONE : number = 8;

        public static ALL_JOINS : number; public static ALL_JOINS_$LI$() : number { if(IPv4StringBuilderOptions.ALL_JOINS == null) IPv4StringBuilderOptions.ALL_JOINS = IPv4StringBuilderOptions.JOIN_ALL | IPv4StringBuilderOptions.JOIN_TWO | IPv4StringBuilderOptions.JOIN_ONE; return IPv4StringBuilderOptions.ALL_JOINS; };

        public static IPV6_CONVERSIONS : number = 65536;

        public static OCTAL : number = 256;

        public static HEX : number = 512;

        public ipv6ConverterOptions : IPv6AddressSection.IPv6StringBuilderOptions;

        public converter : IPv6Address.IPv6AddressConverter;

        public static STANDARD_OPTS : IPv4AddressSection.IPv4StringBuilderOptions; public static STANDARD_OPTS_$LI$() : IPv4AddressSection.IPv4StringBuilderOptions { if(IPv4StringBuilderOptions.STANDARD_OPTS == null) IPv4StringBuilderOptions.STANDARD_OPTS = new IPv4AddressSection.IPv4StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS); return IPv4StringBuilderOptions.STANDARD_OPTS; };

        public static DATABASE_SEARCH_OPTS : IPv4AddressSection.IPv4StringBuilderOptions; public static DATABASE_SEARCH_OPTS_$LI$() : IPv4AddressSection.IPv4StringBuilderOptions { if(IPv4StringBuilderOptions.DATABASE_SEARCH_OPTS == null) IPv4StringBuilderOptions.DATABASE_SEARCH_OPTS = new IPv4AddressSection.IPv4StringBuilderOptions(); return IPv4StringBuilderOptions.DATABASE_SEARCH_OPTS; };

        public static ALL_OPTS : IPv4AddressSection.IPv4StringBuilderOptions; public static ALL_OPTS_$LI$() : IPv4AddressSection.IPv4StringBuilderOptions { if(IPv4StringBuilderOptions.ALL_OPTS == null) IPv4StringBuilderOptions.ALL_OPTS = new IPv4AddressSection.IPv4StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ALL | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_TWO | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ONE | IPv4AddressSection.IPv4StringBuilderOptions.HEX | IPv4AddressSection.IPv4StringBuilderOptions.OCTAL | IPv4AddressSection.IPv4StringBuilderOptions.IPV6_CONVERSIONS | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$(), null, new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.MIXED | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$() | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$())); return IPv4StringBuilderOptions.ALL_OPTS; };

        public constructor(options? : any, ipv6AddressConverter? : any, ipv6ConverterOptions? : any) {
            if(((typeof options === 'number') || options === null) && ((ipv6AddressConverter != null && (ipv6AddressConverter["__interfaces"] != null && ipv6AddressConverter["__interfaces"].indexOf("inet.ipaddr.ipv6.IPv6Address.IPv6AddressConverter") >= 0 || ipv6AddressConverter.constructor != null && ipv6AddressConverter.constructor["__interfaces"] != null && ipv6AddressConverter.constructor["__interfaces"].indexOf("inet.ipaddr.ipv6.IPv6Address.IPv6AddressConverter") >= 0)) || ipv6AddressConverter === null) && ((ipv6ConverterOptions != null && ipv6ConverterOptions instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || ipv6ConverterOptions === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(options | (ipv6ConverterOptions == null?0:IPv4StringBuilderOptions.IPV6_CONVERSIONS));
                if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                (() => {
                    if(this.includes(IPv4StringBuilderOptions.IPV6_CONVERSIONS)) {
                        if(ipv6ConverterOptions == null) {
                            ipv6ConverterOptions = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$() | IPv6AddressSection.IPv6StringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS | IPv6AddressSection.IPv6StringBuilderOptions.MIXED);
                        }
                        if(ipv6AddressConverter == null) {
                            ipv6AddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
                            if(ipv6AddressConverter == null) {
                                ipv6AddressConverter = new IPAddressConverter.DefaultAddressConverter();
                            }
                        }
                    }
                    this.ipv6ConverterOptions = ipv6ConverterOptions;
                    this.converter = ipv6AddressConverter;
                })();
            } else if(((typeof options === 'number') || options === null) && ipv6AddressConverter === undefined && ipv6ConverterOptions === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let ipv6AddressConverter : any = null;
                    let ipv6ConverterOptions : any = null;
                    super(options | (ipv6ConverterOptions == null?0:IPv4StringBuilderOptions.IPV6_CONVERSIONS));
                    if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    (() => {
                        if(this.includes(IPv4StringBuilderOptions.IPV6_CONVERSIONS)) {
                            if(ipv6ConverterOptions == null) {
                                ipv6ConverterOptions = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$() | IPv6AddressSection.IPv6StringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS | IPv6AddressSection.IPv6StringBuilderOptions.MIXED);
                            }
                            if(ipv6AddressConverter == null) {
                                ipv6AddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
                                if(ipv6AddressConverter == null) {
                                    ipv6AddressConverter = new IPAddressConverter.DefaultAddressConverter();
                                }
                            }
                        }
                        this.ipv6ConverterOptions = ipv6ConverterOptions;
                        this.converter = ipv6AddressConverter;
                    })();
                }
            } else if(options === undefined && ipv6AddressConverter === undefined && ipv6ConverterOptions === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                super();
                if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                if(this.ipv6ConverterOptions===undefined) this.ipv6ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                (() => {
                    this.ipv6ConverterOptions = null;
                    this.converter = null;
                })();
            } else throw new Error('invalid overload');
        }

        public static from(opts : IPAddressSection.IPStringBuilderOptions) : IPv4AddressSection.IPv4StringBuilderOptions {
            if(opts != null && opts instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) {
                return <IPv4AddressSection.IPv4StringBuilderOptions>opts;
            }
            return new IPv4AddressSection.IPv4StringBuilderOptions(opts.options & ~(IPv4StringBuilderOptions.ALL_JOINS_$LI$() | IPv4StringBuilderOptions.IPV6_CONVERSIONS | IPv4StringBuilderOptions.OCTAL | IPv4StringBuilderOptions.HEX));
        }
    }
    IPv4StringBuilderOptions["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringBuilderOptions";


    /**
     * Represents a clear way to create a specific type of string.
     * 
     * @author sfoley
     * @extends IPAddressSection.IPStringOptions
     * @class
     */
    export class IPv4StringOptions extends IPAddressSection.IPStringOptions {
        constructor(base : number, expandSegments : boolean, wildcardOption : WildcardOptions.WildcardOption, wildcards : StringOptions.Wildcards, segmentStrPrefix : string, separator : string, label : string, suffix : string, reverse : boolean, splitDigits : boolean, uppercase : boolean) {
            super(base, expandSegments, wildcardOption, wildcards, segmentStrPrefix, separator, ' ', label, suffix, reverse, splitDigits, uppercase);
        }
    }
    IPv4StringOptions["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringOptions";


    export namespace IPv4StringOptions {

        export class Builder extends IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
            public constructor(base : number = IPv4Address.DEFAULT_TEXTUAL_RADIX, separator : string = IPv4Address.SEGMENT_SEPARATOR) {
                super(base, separator);
            }

            /**
             * 
             * @return {IPv4AddressSection.IPv4StringOptions}
             */
            public toOptions() : IPv4AddressSection.IPv4StringOptions {
                return new IPv4AddressSection.IPv4StringOptions(this.base, this.expandSegments, this.wildcardOption, this.wildcards, this.segmentStrPrefix, this.separator, this.addrLabel, this.addrSuffix, this.reverse, this.splitDigits, this.uppercase);
            }
        }
        Builder["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringOptions.Builder";

    }


    /**
     * Each IPv4StringParams instance has settings to write exactly one IPv4 address section string.
     * Using this class allows us to avoid referencing StringParams<IPAddressPart> everywhere,
     * but in reality this class has no functionality of its own.
     * 
     * @author sfoley
     * @extends IPAddressDivisionGrouping.IPAddressStringParams
     * @class
     */
    export class IPv4StringParams extends IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> {
        constructor(radix : number) {
            super(radix, IPv4Address.SEGMENT_SEPARATOR, false);
        }

        /**
         * 
         * @return {IPv4AddressSection.IPv4StringParams}
         */
        public clone() : IPv4AddressSection.IPv4StringParams {
            return <IPv4AddressSection.IPv4StringParams>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
        }
    }
    IPv4StringParams["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringParams";
    IPv4StringParams["__interfaces"] = ["inet.ipaddr.format.util.AddressDivisionWriter","inet.ipaddr.format.util.AddressSegmentParams","java.lang.Cloneable","inet.ipaddr.format.util.IPAddressStringWriter"];



    export class IPv4StringCollection extends IPAddressPartStringCollection {
        /**
         * 
         * @param {IPAddressPartStringCollection} collections
         */
        addAll(collections : IPAddressPartStringCollection) {
            super.addAll(collections);
        }

        constructor() {
            super();
        }
    }
    IPv4StringCollection["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringCollection";
    IPv4StringCollection["__interfaces"] = ["java.lang.Iterable"];



    export namespace IPv4StringCollection {

        export class IPv4AddressSectionStringCollection extends IPAddressPartStringSubCollection<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams, IPAddressPartConfiguredString<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams>> {
            constructor(addr : IPAddressStringDivisionSeries) {
                super(addr);
            }

            /**
             * 
             * @return {*}
             */
            public iterator() : any {
                return new IPv4AddressSectionStringCollection.IPv4AddressSectionStringCollection$0(this);
            }
        }
        IPv4AddressSectionStringCollection["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringCollection.IPv4AddressSectionStringCollection";
        IPv4AddressSectionStringCollection["__interfaces"] = ["java.lang.Iterable"];



        export namespace IPv4AddressSectionStringCollection {

            export class IPv4AddressSectionStringCollection$0 extends IPAddressPartStringSubCollection.IPAddressConfigurableStringIterator {
                public __parent: any;
                /**
                 * 
                 * @return {IPAddressPartConfiguredString}
                 */
                public next() : IPAddressPartConfiguredString<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams> {
                    return <any>(new IPAddressPartConfiguredString<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams>(this.__parent.part, this.iterator.next()));
                }

                constructor(__parent: any) {
                    super(__parent);
                    this.__parent = __parent;
                }
            }
            IPv4AddressSectionStringCollection$0["__interfaces"] = ["java.util.Iterator"];


        }


        /**
         * Capable of building any and all possible representations of IPv4 addresses.
         * Not all such representations are necessarily something you might consider valid.
         * For example: 001.02.3.04
         * This string has the number '2' and '4' expanded partially to 02 (a partial expansion), rather than left as is, or expanded to the full 3 chars 002.
         * The number '1' is fully expanded to 3 characters.
         * 
         * With the default settings of this class, a single address can have 16 variations.  If partial expansions are allowed, there are many more.
         * 
         * @author sfoley
         * @extends IPAddressPartStringCollection.AddressPartStringBuilder
         * @class
         */
        export class IPv4StringBuilder extends IPAddressPartStringCollection.AddressPartStringBuilder<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams, IPAddressPartConfiguredString<IPAddressStringDivisionSeries, IPv4AddressSection.IPv4StringParams>, IPv4StringCollection.IPv4AddressSectionStringCollection, IPv4AddressSection.IPv4StringBuilderOptions> {
            constructor(address : IPAddressStringDivisionSeries, options : IPv4AddressSection.IPv4StringBuilderOptions, collection : IPv4StringCollection.IPv4AddressSectionStringCollection) {
                super(address, options, collection);
            }

            /**
             * 
             * @return {boolean} whether this section in decimal appears the same as this segment in octal.
             * This is true if all the values lies between 0 and 8 (so the octal and decimal values are the same)
             * @param {*} part
             */
            public static isDecimalSameAsOctal(part : IPAddressStringDivisionSeries) : boolean {
                let count : number = part.getDivisionCount();
                for(let i : number = 0; i < count; i++) {
                    let seg : AddressStringDivision = part.getDivision(i);
                    if(!seg.isBoundedBy(8)) {
                        return false;
                    }
                };
                return true;
            }

            /**
             * 
             */
            public addAllVariations() {
                let allParams : Array<IPv4AddressSection.IPv4StringParams> = <any>([]);
                let radices : Array<number> = <any>([]);
                /* add */(radices.push(IPv4Address.DEFAULT_TEXTUAL_RADIX)>0);
                if(this.options.includes(IPv4AddressSection.IPv4StringBuilderOptions.HEX)) {
                    /* add */(radices.push(16)>0);
                }
                let hasDecimalOctalDups : boolean = false;
                if(this.options.includes(IPv4AddressSection.IPv4StringBuilderOptions.OCTAL)) {
                    /* add */(radices.push(8)>0);
                    hasDecimalOctalDups = this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS_$LI$()) && /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.OCTAL].getSegmentStrPrefix(),"0")) && IPv4StringBuilder.isDecimalSameAsOctal(this.addressSection);
                }
                for(let index131=0; index131 < radices.length; index131++) {
                    let radix = radices[index131];
                    {
                        let radixParams : Array<IPv4AddressSection.IPv4StringParams> = <any>([]);
                        let stringParams : IPv4AddressSection.IPv4StringParams = new IPv4AddressSection.IPv4StringParams(radix);
                        /* add */(radixParams.push(stringParams)>0);
                        switch((radix)) {
                        case 8:
                            stringParams.setSegmentStrPrefix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.OCTAL].getSegmentStrPrefix());
                            break;
                        case 16:
                            stringParams.setSegmentStrPrefix(IPv4Address.inet_aton_radix["_$wrappers"][IPv4Address.inet_aton_radix.HEX].getSegmentStrPrefix());
                            break;
                        }
                        if(this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$())) {
                            let expandables : number[] = this.getExpandableSegments(radix);
                            let count : number = this.addressSection.getDivisionCount();
                            for(let i : number = 0; i < count; i++) {
                                let expansionLength : number = expandables[i];
                                let len : number = /* size */(<number>radixParams.length);
                                while((expansionLength > 0)) {
                                    for(let j : number = 0; j < len; j++) {
                                        let clone : IPv4AddressSection.IPv4StringParams = /* get */radixParams[j];
                                        if(hasDecimalOctalDups && radix === 10) {
                                            let isDup : boolean = true;
                                            for(let k : number = 0; k < count; k++) {
                                                if(k !== i) {
                                                    let length : number = clone.getExpandedSegmentLength(k);
                                                    if(length === 0) {
                                                        isDup = false;
                                                        break;
                                                    }
                                                }
                                            };
                                            if(isDup) {
                                                continue;
                                            }
                                        }
                                        clone = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(clone);
                                        clone.expandSegment(i, expansionLength, this.addressSection.getDivisionCount());
                                        /* add */(radixParams.push(clone)>0);
                                    };
                                    if(!this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS_$LI$())) {
                                        break;
                                    }
                                    expansionLength--;
                                };
                            };
                        } else if(this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS)) {
                            let allExpandable : boolean = this.isExpandable(radix);
                            if(allExpandable) {
                                let expandParams : IPv4AddressSection.IPv4StringParams = new IPv4AddressSection.IPv4StringParams(IPv4Address.DEFAULT_TEXTUAL_RADIX);
                                expandParams.expandSegments(true);
                                /* add */(radixParams.push(expandParams)>0);
                            }
                        }
                        /* addAll */((l1, l2) => l1.push.apply(l1, l2))(allParams, radixParams);
                    }
                }
                for(let i : number = 0; i < /* size */(<number>allParams.length); i++) {
                    let param : IPv4AddressSection.IPv4StringParams = /* get */allParams[i];
                    this.addStringParam$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringParams(param);
                };
            }

            public addStringParam$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringParams(stringParams : IPv4AddressSection.IPv4StringParams) {
                super.addStringParam(stringParams);
            }

            /**
             * 
             * @param {IPv4AddressSection.IPv4StringParams} stringParams
             */
            public addStringParam(stringParams? : any) : any {
                if(((stringParams != null && stringParams instanceof <any>IPv4AddressSection.IPv4StringParams) || stringParams === null)) {
                    return <any>this.addStringParam$inet_ipaddr_ipv4_IPv4AddressSection_IPv4StringParams(stringParams);
                } else if(((stringParams != null) || stringParams === null)) {
                    return <any>this.addStringParam$inet_ipaddr_format_util_IPAddressStringWriter(stringParams);
                } else throw new Error('invalid overload');
            }
        }
        IPv4StringBuilder["__class"] = "inet.ipaddr.ipv4.IPv4AddressSection.IPv4StringCollection.IPv4StringBuilder";

    }

}




IPv4AddressSection.IPv4StringBuilderOptions.ALL_OPTS_$LI$();

IPv4AddressSection.IPv4StringBuilderOptions.DATABASE_SEARCH_OPTS_$LI$();

IPv4AddressSection.IPv4StringBuilderOptions.STANDARD_OPTS_$LI$();

IPv4AddressSection.IPv4StringBuilderOptions.ALL_JOINS_$LI$();

IPv4AddressSection.IPv4StringCache.reverseDNSParams_$LI$();

IPv4AddressSection.IPv4StringCache.canonicalParams_$LI$();

IPv4AddressSection.IPv4StringCache.inetAtonHexParams_$LI$();

IPv4AddressSection.IPv4StringCache.inetAtonOctalParams_$LI$();

IPv4AddressSection.IPv4StringCache.sqlWildcardParams_$LI$();

IPv4AddressSection.IPv4StringCache.normalizedWildcardParams_$LI$();

IPv4AddressSection.IPv4StringCache.fullParams_$LI$();

IPv4AddressSection.IPv4StringCache.__static_initialize();

IPv4AddressSection.MAX_VALUES_$LI$();
