/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressPositionException } from '../AddressPositionException';
import { AddressSection } from '../AddressSection';
import { AddressValueException } from '../AddressValueException';
import { IPAddress } from '../IPAddress';
import { IPAddressSection } from '../IPAddressSection';
import { IPAddressSegment } from '../IPAddressSegment';
import { IPAddressSegmentSeries } from '../IPAddressSegmentSeries';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { InconsistentPrefixException } from '../InconsistentPrefixException';
import { PrefixLenException } from '../PrefixLenException';
import { SizeMismatchException } from '../SizeMismatchException';
import { AddressCreator } from '../format/AddressCreator';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { AddressStringDivision } from '../format/AddressStringDivision';
import { IPAddressBitsDivision } from '../format/IPAddressBitsDivision';
import { IPAddressDivision } from '../format/IPAddressDivision';
import { IPAddressDivisionGrouping } from '../format/IPAddressDivisionGrouping';
import { IPAddressLargeDivision } from '../format/IPAddressLargeDivision';
import { IPAddressStringDivision } from '../format/IPAddressStringDivision';
import { IPAddressStringDivisionGrouping } from '../format/IPAddressStringDivisionGrouping';
import { IPAddressStringDivisionSeries } from '../format/IPAddressStringDivisionSeries';
import { IPAddressPartConfiguredString } from '../format/util/IPAddressPartConfiguredString';
import { IPAddressPartStringCollection } from '../format/util/IPAddressPartStringCollection';
import { IPAddressPartStringSubCollection } from '../format/util/IPAddressPartStringSubCollection';
import { IPAddressStringWriter } from '../format/util/IPAddressStringWriter';
import { IPAddressSQLTranslator } from '../format/util/sql/IPAddressSQLTranslator';
import { SQLStringMatcher } from '../format/util/sql/SQLStringMatcher';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressNetwork } from '../ipv4/IPv4AddressNetwork';
import { IPv4AddressSection } from '../ipv4/IPv4AddressSection';
import { IPv4AddressSegment } from '../ipv4/IPv4AddressSegment';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressNetwork } from '../mac/MACAddressNetwork';
import { MACAddressSection } from '../mac/MACAddressSection';
import { MACAddressSegment } from '../mac/MACAddressSegment';
import { IPv6Address } from './IPv6Address';
import { IPv6AddressNetwork } from './IPv6AddressNetwork';
import { IPv6AddressSegment } from './IPv6AddressSegment';
import { AddressNetwork } from '../AddressNetwork';
import { AddressComparator } from '../AddressComparator';
import { AddressDivisionWriter } from '../format/util/AddressDivisionWriter';
import { IPAddressNetwork } from '../IPAddressNetwork';
import { IPAddressConverter } from '../IPAddressConverter';

/**
 * 
 * @author sfoley
 * @param {*} lowerValueProvider
 * @param {*} upperValueProvider
 * @param {number} segmentCount
 * @param {number} networkPrefixLength
 * @class
 * @extends IPAddressSection
 */
export class IPv6AddressSection extends IPAddressSection {
    static __inet_ipaddr_ipv6_IPv6AddressSection_serialVersionUID : number = 4;

    static creators : IPv6AddressNetwork.IPv6AddressCreator[]; public static creators_$LI$() : IPv6AddressNetwork.IPv6AddressCreator[] { if(IPv6AddressSection.creators == null) IPv6AddressSection.creators = (s => { let a=[]; while(s-->0) a.push(null); return a; })(IPv6Address.SEGMENT_COUNT); return IPv6AddressSection.creators; };

    /*private*/ stringCache : IPv6AddressSection.IPv6StringCache;

    /*private*/ sectionCache : AddressDivisionGrouping.SectionCache<IPv6AddressSection>;

    embeddedIPv4Section : IPv4AddressSection;

    defaultMixedAddressSection : IPv6AddressSection.IPv6v4MixedAddressSection;

    public addressSegmentIndex : number;

    /*private*/ zeroSegments : IPAddressDivisionGrouping.RangeList;

    /*private*/ zeroRanges : IPAddressDivisionGrouping.RangeList;

    public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, segmentCount? : any, networkPrefixLength? : any, cloneBytes? : any, singleOnly? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof cloneBytes === 'boolean') || cloneBytes === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            (() => {
                let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                let network : IPv6AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                if(networkPrefixLength != null) {
                    if(networkPrefixLength < 0) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    let max : number = segs.length << 4;
                    if(networkPrefixLength > max) {
                        if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        networkPrefixLength = max;
                    }
                    if(segs.length > 0) {
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                            if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                            } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    } else if(byteLengthIsExact) {
                        this.setBytes(bytes);
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    if(byteLengthIsExact) {
                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                    }
                }
                this.addressSegmentIndex = 0;
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && ((typeof networkPrefixLength === 'boolean') || networkPrefixLength === null) && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segmentCount : any = __args[1];
            let networkPrefixLength : any = __args[2];
            let cloneBytes : any = __args[3];
            let singleOnly : any = __args[4];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof networkPrefixLength === 'boolean') || networkPrefixLength === null) && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let startIndex : any = __args[1];
            let cloneSegments : any = __args[2];
            let networkPrefixLength : any = __args[3];
            let singleOnly : any = __args[4];
            {
                let __args = Array.prototype.slice.call(arguments);
                let normalizeSegments : any = networkPrefixLength == null;
                super(segments, cloneSegments, true);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    if(normalizeSegments && this.isPrefixed()) {
                        AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                    }
                    this.addressSegmentIndex = startIndex;
                    if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                        throw new AddressPositionException(startIndex);
                    } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException(startIndex + segments.length);
                    }
                })();
            }
            (() => {
                if(networkPrefixLength != null) {
                    if(networkPrefixLength < 0) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    let max : number = segments.length << 4;
                    if(networkPrefixLength > max) {
                        if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        networkPrefixLength = max;
                    }
                    if(segments.length > 0) {
                        if(this.cachedPrefixLength !== AddressDivisionGrouping.NO_PREFIX_LENGTH && this.cachedPrefixLength < networkPrefixLength) {
                            networkPrefixLength = this.cachedPrefixLength;
                        }
                        let network : IPv6AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), !singleOnly && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segments, networkPrefixLength, network, false)?(segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) }:(segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        this.cachedPrefixLength = networkPrefixLength;
                    }
                }
            })();
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let segmentCount : any = __args[2];
            let networkPrefixLength : any = __args[3];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            (() => {
                let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                let network : IPv6AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                if(networkPrefixLength != null) {
                    if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                }
                this.addressSegmentIndex = 0;
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segmentCount : any = __args[1];
            let prefix : any = __args[2];
            let cloneBytes : any = __args[3];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                let networkPrefixLength : any = prefix;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[3];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = -1;
                let networkPrefixLength : any = prefix;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && ((typeof segmentCount === 'boolean') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let startIndex : any = __args[1];
            let cloneSegments : any = __args[2];
            let normalizeSegments : any = __args[3];
            super(segments, cloneSegments, true);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            (() => {
                if(normalizeSegments && this.isPrefixed()) {
                    AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                }
                this.addressSegmentIndex = startIndex;
                if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                    throw new AddressPositionException(startIndex);
                } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                    throw new AddressValueException(startIndex + segments.length);
                }
            })();
        } else if(((typeof bytes === 'number') || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof segmentCount === 'number') || segmentCount === null) && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let highBytes : any = __args[0];
            let lowBytes : any = __args[1];
            let segmentCount : any = __args[2];
            let networkPrefixLength : any = __args[3];
            super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            (() => {
                let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                let network : IPv6AddressNetwork = this.getNetwork();
                AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, highBytes, lowBytes, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                if(networkPrefixLength != null) {
                    if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                        throw new PrefixLenException(networkPrefixLength);
                    }
                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                    }
                    this.cachedPrefixLength = networkPrefixLength;
                } else {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                }
                this.addressSegmentIndex = 0;
            })();
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let segmentCount : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let startIndex : any = __args[1];
            let networkPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let cloneSegments : any = true;
                let singleOnly : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = networkPrefixLength == null;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        this.addressSegmentIndex = startIndex;
                        if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressPositionException(startIndex);
                        } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressValueException(startIndex + segments.length);
                        }
                    })();
                }
                (() => {
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segments.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segments.length > 0) {
                            if(this.cachedPrefixLength !== AddressDivisionGrouping.NO_PREFIX_LENGTH && this.cachedPrefixLength < networkPrefixLength) {
                                networkPrefixLength = this.cachedPrefixLength;
                            }
                            let network : IPv6AddressNetwork = this.getNetwork();
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), !singleOnly && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segments, networkPrefixLength, network, false)?(segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) }:(segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                            this.cachedPrefixLength = networkPrefixLength;
                        }
                    }
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let segmentCount : any = __args[1];
            let networkPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            let segmentCount : any = __args[1];
            let networkPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let bytes : any = val.toByteArray();
                let prefix : any = networkPrefixLength;
                let cloneBytes : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    let networkPrefixLength : any = prefix;
                    let singleOnly : any = false;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                        let network : IPv6AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                        let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength < 0) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            let max : number = segs.length << 4;
                            if(networkPrefixLength > max) {
                                if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                    throw new PrefixLenException(networkPrefixLength);
                                }
                                networkPrefixLength = max;
                            }
                            if(segs.length > 0) {
                                if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                    if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                        AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                    } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                    }
                                } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact) {
                                this.setBytes(bytes);
                            }
                            this.cachedPrefixLength = networkPrefixLength;
                        } else {
                            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                            if(byteLengthIsExact) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        }
                        this.addressSegmentIndex = 0;
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let startIndex : any = __args[1];
            let cloneSegments : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let normalizeSegments : any = true;
                super(segments, cloneSegments, true);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    if(normalizeSegments && this.isPrefixed()) {
                        AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                    }
                    this.addressSegmentIndex = startIndex;
                    if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                        throw new AddressPositionException(startIndex);
                    } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException(startIndex + segments.length);
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let segmentCount : any = -1;
                let networkPrefixLength : any = null;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>MACAddressSection) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let eui : any = __args[0];
            let ipv6StartIndex : any = __args[1];
            let ipv6SegmentCount : any = __args[2];
            super(ipv6SegmentCount <= 0?IPv6AddressNetwork.EMPTY_SEGMENTS_$LI$():(s => { let a=[]; while(s-->0) a.push(null); return a; })(ipv6SegmentCount), false, false);
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
            if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
            if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
            if(this.zeroSegments===undefined) this.zeroSegments = null;
            if(this.zeroRanges===undefined) this.zeroRanges = null;
            (() => {
                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                this.addressSegmentIndex = ipv6StartIndex;
                let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                IPv6Address.toEUI64Segments(segs, 0, eui, eui.addressSegmentIndex, eui.isExtended(), this.getNetwork().getAddressCreator(), this.getMACNetwork().getAddressCreator(), null);
                this.checkSegments(segs);
            })();
        } else if(((typeof bytes === 'number') || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let highBytes : any = __args[0];
            let lowBytes : any = __args[1];
            let segmentCount : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, highBytes, lowBytes, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let startIndex : any = 0;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let cloneSegments : any = true;
                    let singleOnly : any = false;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let normalizeSegments : any = networkPrefixLength == null;
                        super(segments, cloneSegments, true);
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                        if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                        if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                        if(this.zeroSegments===undefined) this.zeroSegments = null;
                        if(this.zeroRanges===undefined) this.zeroRanges = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                        if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                        if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                        if(this.zeroSegments===undefined) this.zeroSegments = null;
                        if(this.zeroRanges===undefined) this.zeroRanges = null;
                        (() => {
                            if(normalizeSegments && this.isPrefixed()) {
                                AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                            }
                            this.addressSegmentIndex = startIndex;
                            if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                                throw new AddressPositionException(startIndex);
                            } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                                throw new AddressValueException(startIndex + segments.length);
                            }
                        })();
                    }
                    (() => {
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength < 0) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            let max : number = segments.length << 4;
                            if(networkPrefixLength > max) {
                                if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                    throw new PrefixLenException(networkPrefixLength);
                                }
                                networkPrefixLength = max;
                            }
                            if(segments.length > 0) {
                                if(this.cachedPrefixLength !== AddressDivisionGrouping.NO_PREFIX_LENGTH && this.cachedPrefixLength < networkPrefixLength) {
                                    networkPrefixLength = this.cachedPrefixLength;
                                }
                                let network : IPv6AddressNetwork = this.getNetwork();
                                AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), !singleOnly && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segments, networkPrefixLength, network, false)?(segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) }:(segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                                this.cachedPrefixLength = networkPrefixLength;
                            }
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                let segmentCount : any = -1;
                let networkPrefixLength : any = prefix;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSegment) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segment : any = __args[0];
            let startIndex : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segments : any = [segment];
                let cloneSegments : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = true;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        this.addressSegmentIndex = startIndex;
                        if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressPositionException(startIndex);
                        } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressValueException(startIndex + segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let segmentCount : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let networkPrefixLength : any = null;
                    super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount), false, false);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                        let network : IPv6AddressNetwork = this.getNetwork();
                        AddressDivisionGrouping.createSegments$inet_ipaddr_AddressSegment_A$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$int$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segs, lowerValueProvider, upperValueProvider, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                        if(networkPrefixLength != null) {
                            if(networkPrefixLength < 0 || networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                            }
                            this.cachedPrefixLength = networkPrefixLength;
                        } else {
                            this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        }
                        this.addressSegmentIndex = 0;
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            let segmentCount : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let bytes : any = val.toByteArray();
                    let prefix : any = networkPrefixLength;
                    let cloneBytes : any = false;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let byteStartIndex : any = 0;
                        let byteEndIndex : any = __args[0].length;
                        let networkPrefixLength : any = prefix;
                        let singleOnly : any = false;
                        super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                        if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                        if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                        if(this.zeroSegments===undefined) this.zeroSegments = null;
                        if(this.zeroRanges===undefined) this.zeroRanges = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                        if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                        if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                        if(this.zeroSegments===undefined) this.zeroSegments = null;
                        if(this.zeroRanges===undefined) this.zeroRanges = null;
                        (() => {
                            let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                            let network : IPv6AddressNetwork = this.getNetwork();
                            AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                            let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                            if(networkPrefixLength != null) {
                                if(networkPrefixLength < 0) {
                                    throw new PrefixLenException(networkPrefixLength);
                                }
                                let max : number = segs.length << 4;
                                if(networkPrefixLength > max) {
                                    if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                        throw new PrefixLenException(networkPrefixLength);
                                    }
                                    networkPrefixLength = max;
                                }
                                if(segs.length > 0) {
                                    if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                        if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                            AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                        } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                        }
                                    } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                        this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                    }
                                } else if(byteLengthIsExact) {
                                    this.setBytes(bytes);
                                }
                                this.cachedPrefixLength = networkPrefixLength;
                            } else {
                                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                                if(byteLengthIsExact) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            }
                            this.addressSegmentIndex = 0;
                        })();
                    }
                }
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSegment) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segment : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let segments : any = [segment];
                let startIndex : any = 0;
                let cloneSegments : any = false;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = true;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        this.addressSegmentIndex = startIndex;
                        if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressPositionException(startIndex);
                        } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressValueException(startIndex + segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let startIndex : any = 0;
                let cloneSegments : any = true;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let normalizeSegments : any = true;
                    super(segments, cloneSegments, true);
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                    if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                    if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                    if(this.zeroSegments===undefined) this.zeroSegments = null;
                    if(this.zeroRanges===undefined) this.zeroRanges = null;
                    (() => {
                        if(normalizeSegments && this.isPrefixed()) {
                            AddressDivisionGrouping.normalizePrefixBoundary<any>(this.getNetworkPrefixLength(), this.getSegmentsInternal(), IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, (segmentPrefixLength) => { return IPv6AddressSegment.toPrefixedSegment(segmentPrefixLength) });
                        }
                        this.addressSegmentIndex = startIndex;
                        if(startIndex < 0 || startIndex > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressPositionException(startIndex);
                        } else if(startIndex + segments.length > IPv6Address.SEGMENT_COUNT) {
                            throw new AddressValueException(startIndex + segments.length);
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                let segmentCount : any = -1;
                let networkPrefixLength : any = null;
                let cloneBytes : any = true;
                let singleOnly : any = false;
                super((s => { let a=[]; while(s-->0) a.push(null); return a; })(segmentCount >= 0?segmentCount:(Math.max(0, byteEndIndex - byteStartIndex) + IPv6Address.BYTES_PER_SEGMENT - 1) >> 1), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    let network : IPv6AddressNetwork = this.getNetwork();
                    AddressDivisionGrouping.toSegments<any>(segs, bytes, byteStartIndex, byteEndIndex, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, network, networkPrefixLength);
                    let byteLengthIsExact : boolean = bytes.length === (segs.length << 1);
                    if(networkPrefixLength != null) {
                        if(networkPrefixLength < 0) {
                            throw new PrefixLenException(networkPrefixLength);
                        }
                        let max : number = segs.length << 4;
                        if(networkPrefixLength > max) {
                            if(networkPrefixLength > IPv6Address.BIT_COUNT) {
                                throw new PrefixLenException(networkPrefixLength);
                            }
                            networkPrefixLength = max;
                        }
                        if(segs.length > 0) {
                            if(AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].zeroHostsAreSubnets() && !singleOnly) {
                                if(IPAddressSection.isPrefixSubnet$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$inet_ipaddr_IPAddressNetwork$boolean(segs, networkPrefixLength, network, false)) {
                                    AddressDivisionGrouping.setPrefixedSegments<any>(network, networkPrefixLength, segs, IPv6Address.BITS_PER_SEGMENT, IPv6Address.BYTES_PER_SEGMENT, network.getAddressCreator(), (segmentPrefixLength) => { return IPv6AddressSegment.toNetworkSegment(segmentPrefixLength) });
                                } else if(byteLengthIsExact && networkPrefixLength >= this.getBitCount()) {
                                    this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                                }
                            } else if(byteLengthIsExact && AddressNetwork.PrefixConfiguration["_$wrappers"][network.getPrefixConfiguration()].prefixedSubnetsAreExplicit() || networkPrefixLength >= this.getBitCount()) {
                                this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                            }
                        } else if(byteLengthIsExact) {
                            this.setBytes(bytes);
                        }
                        this.cachedPrefixLength = networkPrefixLength;
                    } else {
                        this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                        if(byteLengthIsExact) {
                            this.setBytes(cloneBytes?/* clone */bytes.slice(0):bytes);
                        }
                    }
                    this.addressSegmentIndex = 0;
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>MACAddress) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let eui : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let eui : any = __args[0].getSection();
                let ipv6StartIndex : any = 4;
                let ipv6SegmentCount : any = 4;
                super(ipv6SegmentCount <= 0?IPv6AddressNetwork.EMPTY_SEGMENTS_$LI$():(s => { let a=[]; while(s-->0) a.push(null); return a; })(ipv6SegmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    this.addressSegmentIndex = ipv6StartIndex;
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    IPv6Address.toEUI64Segments(segs, 0, eui, eui.addressSegmentIndex, eui.isExtended(), this.getNetwork().getAddressCreator(), this.getMACNetwork().getAddressCreator(), null);
                    this.checkSegments(segs);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>MACAddressSection) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && segmentCount === undefined && networkPrefixLength === undefined && cloneBytes === undefined && singleOnly === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let eui : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let ipv6StartIndex : any = IPv6AddressSection.getIPv6StartIndex(__args[0]);
                let ipv6SegmentCount : any = IPv6AddressSection.getIPv6SegmentCount(__args[0]);
                super(ipv6SegmentCount <= 0?IPv6AddressNetwork.EMPTY_SEGMENTS_$LI$():(s => { let a=[]; while(s-->0) a.push(null); return a; })(ipv6SegmentCount), false, false);
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.embeddedIPv4Section===undefined) this.embeddedIPv4Section = null;
                if(this.defaultMixedAddressSection===undefined) this.defaultMixedAddressSection = null;
                if(this.addressSegmentIndex===undefined) this.addressSegmentIndex = 0;
                if(this.zeroSegments===undefined) this.zeroSegments = null;
                if(this.zeroRanges===undefined) this.zeroRanges = null;
                (() => {
                    this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
                    this.addressSegmentIndex = ipv6StartIndex;
                    let segs : IPv6AddressSegment[] = this.getSegmentsInternal();
                    IPv6Address.toEUI64Segments(segs, 0, eui, eui.addressSegmentIndex, eui.isExtended(), this.getNetwork().getAddressCreator(), this.getMACNetwork().getAddressCreator(), null);
                    this.checkSegments(segs);
                })();
            }
        } else throw new Error('invalid overload');
    }

    static getIPv6SegmentCount(eui : MACAddressSection) : number {
        let euiStartIndex : number = eui.addressSegmentIndex;
        let euiEndIndex : number = euiStartIndex + eui.getSegmentCount();
        let result : number = (euiEndIndex + 1) >> 1;
        result -= euiStartIndex >> 1;
        if(!eui.isExtended() && euiStartIndex <= 2 && euiEndIndex >= 4) {
            result++;
        }
        return result;
    }

    static getIPv6StartIndex(eui : MACAddressSection) : number {
        let euiStartIndex : number = eui.addressSegmentIndex;
        let result : number = 4 + (euiStartIndex >> 1);
        if(!eui.isExtended() && euiStartIndex >= 3) {
            result++;
        }
        return result;
    }

    public initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(prefixLen : number, network : boolean, cachedNetworkPrefix : number, cachedMinPrefix : number, cachedEquivalentPrefix : number, cachedCount : BigInteger, zeroSegments : IPAddressDivisionGrouping.RangeList, zeroRanges : IPAddressDivisionGrouping.RangeList) {
        super.initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(prefixLen, network, cachedNetworkPrefix, cachedMinPrefix, cachedEquivalentPrefix, cachedCount, zeroSegments, zeroRanges);
        this.zeroSegments = zeroSegments;
        this.zeroRanges = zeroRanges;
    }

    /**
     * 
     * @param {number} prefixLen
     * @param {boolean} network
     * @param {number} cachedNetworkPrefix
     * @param {number} cachedMinPrefix
     * @param {number} cachedEquivalentPrefix
     * @param {BigInteger} cachedCount
     * @param {IPAddressDivisionGrouping.RangeList} zeroSegments
     * @param {IPAddressDivisionGrouping.RangeList} zeroRanges
     */
    public initCachedValues(prefixLen? : any, network? : any, cachedNetworkPrefix? : any, cachedMinPrefix? : any, cachedEquivalentPrefix? : any, cachedCount? : any, zeroSegments? : any, zeroRanges? : any) : any {
        if(((typeof prefixLen === 'number') || prefixLen === null) && ((typeof network === 'boolean') || network === null) && ((typeof cachedNetworkPrefix === 'number') || cachedNetworkPrefix === null) && ((typeof cachedMinPrefix === 'number') || cachedMinPrefix === null) && ((typeof cachedEquivalentPrefix === 'number') || cachedEquivalentPrefix === null) && ((cachedCount != null && cachedCount instanceof <any>BigInteger) || cachedCount === null) && ((zeroSegments != null && zeroSegments instanceof <any>IPAddressDivisionGrouping.RangeList) || zeroSegments === null) && ((zeroRanges != null && zeroRanges instanceof <any>IPAddressDivisionGrouping.RangeList) || zeroRanges === null)) {
            return <any>this.initCachedValues$java_lang_Integer$boolean$java_lang_Integer$java_lang_Integer$java_lang_Integer$java_math_BigInteger$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList$inet_ipaddr_format_IPAddressDivisionGrouping_RangeList(prefixLen, network, cachedNetworkPrefix, cachedMinPrefix, cachedEquivalentPrefix, cachedCount, zeroSegments, zeroRanges);
        } else if(((typeof prefixLen === 'number') || prefixLen === null) && ((network != null && network instanceof <any>BigInteger) || network === null) && cachedNetworkPrefix === undefined && cachedMinPrefix === undefined && cachedEquivalentPrefix === undefined && cachedCount === undefined && zeroSegments === undefined && zeroRanges === undefined) {
            return <any>this.initCachedValues$java_lang_Integer$java_math_BigInteger(prefixLen, network);
        } else throw new Error('invalid overload');
    }

    public getSection$() : IPv6AddressSection {
        return this;
    }

    public getSection$int(index : number) : IPv6AddressSection {
        return this.getSection$int$int(index, this.getSegmentCount());
    }

    public getSection$int$int(index : number, endIndex : number) : IPv6AddressSection {
        return <any>(AddressDivisionGrouping.getSection<any, any>(index, endIndex, this, this.getAddressCreator$int(this.addressSegmentIndex + index)));
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPv6AddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            super.getSection(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} destIndex
     */
    public getSegments(start? : any, end? : any, segs? : any, destIndex? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof destIndex === 'number') || destIndex === null)) {
            super.getSegments(start, end, segs, destIndex);
        } else if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && (segs instanceof Array)) || segs === null) && destIndex === undefined) {
            return <any>this.getSegments$int$int$java_util_Collection(start, end, segs);
        } else if(((start != null && (start instanceof Array)) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$java_util_Collection(start);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(start === undefined && end === undefined && segs === undefined && destIndex === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    public getSegments$() : IPv6AddressSegment[] {
        return <IPv6AddressSegment[]>/* clone */this.getDivisionsInternal().slice(0);
    }

    getLowestOrHighestSection(lowest : boolean, excludeZeroHost : boolean) : IPv6AddressSection {
        let result : IPv6AddressSection = <any>(AddressDivisionGrouping.getSingleLowestOrHighestSection<any>(this));
        if(result == null) {
            let cache : AddressDivisionGrouping.SectionCache<IPv6AddressSection> = this.sectionCache;
            if(cache == null || (lowest?(excludeZeroHost?((result = cache.lowerNonZeroHost) == null && !cache.lowerNonZeroHostIsNull):(result = cache.lower) == null):(result = cache.upper) == null)) {
                {
                    cache = this.sectionCache;
                    let create : boolean = (cache == null);
                    if(create) {
                        this.sectionCache = cache = <any>(new AddressDivisionGrouping.SectionCache<IPv6AddressSection>());
                    } else {
                        if(lowest) {
                            if(excludeZeroHost) {
                                create = (result = cache.lowerNonZeroHost) == null && !cache.lowerNonZeroHostIsNull;
                            } else {
                                create = (result = cache.lower) == null;
                            }
                        } else {
                            create = (result = cache.upper) == null;
                        }
                    }
                    if(create) {
                        result = <any>(IPAddressSection.getLowestOrHighestSection<any, any>(this, this.getAddressCreator(), () => { return this.segmentsNonZeroHostIterator() }, (i) => lowest?this.getSegment(i).getLower():this.getSegment(i).getUpper(), lowest, excludeZeroHost));
                        if(result == null) {
                            cache.lowerNonZeroHostIsNull = true;
                        } else if(lowest) {
                            if(excludeZeroHost) {
                                cache.lowerNonZeroHost = result;
                            } else {
                                cache.lower = result;
                            }
                        } else {
                            cache.upper = result;
                        }
                    }
                };
            }
        } else if(excludeZeroHost && this.includesZeroHost()) {
            return null;
        }
        return result;
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public getLowerNonZeroHost() : IPv6AddressSection {
        return this.getLowestOrHighestSection(true, true);
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public getLower() : IPv6AddressSection {
        return this.getLowestOrHighestSection(true, false);
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public getUpper() : IPv6AddressSection {
        return this.getLowestOrHighestSection(false, false);
    }

    public reverseBits$boolean(perByte : boolean) : IPv6AddressSection {
        return <any>(AddressDivisionGrouping.reverseBits<any, any>(perByte, this, this.getAddressCreator(), (i) => this.getSegment(i).reverseBits$boolean(perByte), true));
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPv6AddressSection}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else throw new Error('invalid overload');
    }

    public reverseBytes$() : IPv6AddressSection {
        return this.reverseBytes$boolean(false);
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public reverseBytesPerSegment() : IPv6AddressSection {
        return this.reverseBytes$boolean(true);
    }

    public reverseBytes$boolean(perSegment : boolean) : IPv6AddressSection {
        return <any>(AddressDivisionGrouping.reverseBytes<any, any>(perSegment, this, this.getAddressCreator(), (i) => this.getSegment(i).reverseBytes(), true));
    }

    public reverseBytes(perSegment? : any) : any {
        if(((typeof perSegment === 'boolean') || perSegment === null)) {
            return <any>this.reverseBytes$boolean(perSegment);
        } else if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else if(perSegment === undefined) {
            return <any>this.reverseBytes$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public reverseSegments() : IPv6AddressSection {
        if(this.getSegmentCount() <= 1) {
            return this;
        }
        return <any>(AddressDivisionGrouping.reverseSegments<any, any>(this, this.getAddressCreator(), (i) => this.getSegment(i).removePrefixLength$boolean(false), true));
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<IPv6AddressSection> {
        return this;
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && ((typeof networkSegmentIndex === 'number') || networkSegmentIndex === null) && ((typeof hostSegmentIndex === 'number') || hostSegmentIndex === null) && ((typeof prefixedSegIteratorProducer === 'function' && (<any>prefixedSegIteratorProducer).length == 1) || prefixedSegIteratorProducer === null)) {
            super.iterator(segmentCreator, segSupplier, segIteratorProducer, excludeFunc, networkSegmentIndex, hostSegmentIndex, prefixedSegIteratorProducer);
        } else if(((segmentCreator != null && (segmentCreator["__interfaces"] != null && segmentCreator["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0 || segmentCreator.constructor != null && segmentCreator.constructor["__interfaces"] != null && segmentCreator.constructor["__interfaces"].indexOf("inet.ipaddr.AddressNetwork.AddressSegmentCreator") >= 0)) || segmentCreator === null) && ((typeof segSupplier === 'function' && (<any>segSupplier).length == 0) || segSupplier === null) && ((typeof segIteratorProducer === 'function' && (<any>segIteratorProducer).length == 1) || segIteratorProducer === null) && ((typeof excludeFunc === 'function' && (<any>excludeFunc).length == 1) || excludeFunc === null) && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(segmentCreator, segSupplier, segIteratorProducer, excludeFunc);
        } else if(((segmentCreator != null && segmentCreator instanceof <any>IPv6Address) || segmentCreator === null) && ((segSupplier != null && segSupplier instanceof <any>AddressCreator) || segSupplier === null) && ((typeof segIteratorProducer === 'boolean') || segIteratorProducer === null) && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator$boolean(segmentCreator, segSupplier, segIteratorProducer);
        } else if(((typeof segmentCreator === 'boolean') || segmentCreator === null) && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$boolean(segmentCreator);
        } else if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    iterator$boolean(excludeZeroHosts : boolean) : any {
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        let useOriginal : boolean = !this.isMultiple() && (!isAllSubnets || !this.isPrefixed());
        let original : IPv6AddressSection;
        if(useOriginal && excludeZeroHosts && this.includesZeroHost()) {
            original = null;
        } else {
            original = this;
        }
        return AddressDivisionGrouping.iterator(useOriginal, original, this.getAddressCreator(), useOriginal?null:this.segmentsIterator$boolean(excludeZeroHosts), isAllSubnets?null:this.getPrefixLength());
    }

    /**
     * 
     * @return {*}
     */
    public nonZeroHostIterator() : any {
        return this.iterator$boolean(true);
    }

    public iterator$() : any {
        return this.iterator$boolean(false);
    }

    public prefixBlockIterator$() : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator();
        }
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getAddressCreator();
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(useOriginal, this, creator, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), IPAddressSection.getNetworkSegmentIndex(prefLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT), IPAddressSection.getHostSegmentIndex(prefLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT), (index) => this.getSegment(index).prefixBlockIterator()), prefLength);
    }

    public segmentsIterator$boolean(excludeZeroHosts : boolean) : any {
        return super.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(this.getSegmentCreator(), () => this.getLower().getSegments(), (index) => this.getSegment(index).iterator(), excludeZeroHosts?(segments) => { return this.isZeroHost(segments) }:<any>(null));
    }

    public segmentsIterator(excludeZeroHosts? : any) : any {
        if(((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>this.segmentsIterator$boolean(excludeZeroHosts);
        } else if(excludeZeroHosts === undefined) {
            return <any>this.segmentsIterator$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {*}
     */
    public segmentsNonZeroHostIterator() : any {
        return this.segmentsIterator$boolean(true);
    }

    public segmentsIterator$() : any {
        return this.segmentsIterator$boolean(false);
    }

    /**
     * 
     * @return {Array}
     */
    getSegmentsInternal() : IPv6AddressSegment[] {
        return <IPv6AddressSegment[]>super.getDivisionsInternal();
    }

    iterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator$boolean(original : IPv6Address, creator : AddressCreator<IPv6Address, any, any, IPv6AddressSegment>, excludeZeroHosts : boolean) : any {
        let isAllSubnets : boolean = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets();
        let useOriginal : boolean = !this.isMultiple() && (!isAllSubnets || !this.isPrefixed());
        if(useOriginal && excludeZeroHosts && original.includesZeroHost()) {
            original = null;
        }
        return AddressDivisionGrouping.iterator(original, creator, useOriginal, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate(creator, () => <IPv6AddressSegment[]>this.getLower().getSegmentsInternal(), (index) => this.getSegment(index).iterator(), excludeZeroHosts?(segs) => this.isZeroHost<any>(segs):<any>(null)), isAllSubnets?null:this.getPrefixLength());
    }

    public prefixBlockIterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator(original : IPv6Address, creator : AddressCreator<IPv6Address, any, any, IPv6AddressSegment>) : any {
        let prefLength : number = this.getPrefixLength();
        if(prefLength == null || prefLength > this.getBitCount()) {
            return this.iterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator$boolean(original, creator, false);
        }
        let useOriginal : boolean = this.isSinglePrefixBlock();
        return AddressDivisionGrouping.iterator(original, creator, useOriginal, useOriginal?null:this.iterator$inet_ipaddr_AddressNetwork_AddressSegmentCreator$java_util_function_Supplier$java_util_function_IntFunction$java_util_function_Predicate$int$int$java_util_function_IntFunction(creator, <any>(null), (index) => this.getSegment(index).iterator(), <any>(null), IPAddressSection.getNetworkSegmentIndex(prefLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT), IPAddressSection.getHostSegmentIndex(prefLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT), (index) => this.getSegment(index).prefixBlockIterator()), prefLength);
    }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(((original != null && original instanceof <any>IPv6Address) || original === null) && ((creator != null && creator instanceof <any>AddressCreator) || creator === null)) {
            return <any>this.prefixBlockIterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator(original, creator);
        } else if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    static MAX_VALUES_BY_SEGMENT : BigInteger[]; public static MAX_VALUES_BY_SEGMENT_$LI$() : BigInteger[] { if(IPv6AddressSection.MAX_VALUES_BY_SEGMENT == null) IPv6AddressSection.MAX_VALUES_BY_SEGMENT = [BigInteger.ZERO, BigInteger.valueOf(IPv6Address.MAX_VALUE_PER_SEGMENT), BigInteger.valueOf(-1), BigInteger.valueOf(281474976710655), BigInteger.valueOf(1).shiftLeft(16 * 4).subtract(BigInteger.ONE), BigInteger.valueOf(1).shiftLeft(16 * 5).subtract(BigInteger.ONE), BigInteger.valueOf(1).shiftLeft(16 * 6).subtract(BigInteger.ONE), BigInteger.valueOf(1).shiftLeft(16 * 7).subtract(BigInteger.ONE), BigInteger.valueOf(1).shiftLeft(16 * 8).subtract(BigInteger.ONE)]; return IPv6AddressSection.MAX_VALUES_BY_SEGMENT; };

    public static getMaxValue(segmentCount : number) : BigInteger {
        return IPv6AddressSection.MAX_VALUES_BY_SEGMENT_$LI$()[segmentCount];
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv6AddressSection}
     */
    public incrementBoundary(increment : number) : IPv6AddressSection {
        if(increment <= 0) {
            if(increment === 0) {
                return this;
            }
            return this.getLower().increment(increment);
        }
        return this.getUpper().increment(increment);
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv6AddressSection}
     */
    public increment(increment : number) : IPv6AddressSection {
        if(increment === 0 && !this.isMultiple()) {
            return this;
        }
        let lowerValue : BigInteger = this.getValue();
        let upperValue : BigInteger = this.getUpperValue();
        let count : BigInteger = this.getCount();
        let bigIncrement : BigInteger = BigInteger.valueOf(increment);
        AddressDivisionGrouping.checkOverflow$long$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_math_BigInteger$java_util_function_Supplier(increment, bigIncrement, lowerValue, upperValue, count, () => IPv6AddressSection.getMaxValue(this.getSegmentCount()));
        let prefixLength : number = AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:this.getPrefixLength();
        let result : IPv6AddressSection = <any>(AddressDivisionGrouping.fastIncrement<any, any>(this, increment, this.getAddressCreator(), () => { return this.getLower() }, () => { return this.getUpper() }, prefixLength));
        if(result != null) {
            return result;
        }
        return <any>(AddressDivisionGrouping.increment(this, increment, bigIncrement, this.getAddressCreator(), () => { return this.getLower() }, () => { return this.getUpper() }, prefixLength));
    }

    static multiply(result1 : number, result2 : number) : BigInteger {
        if(result1 <= -1257966797) {
            if(result1 === 1) {
                return BigInteger.valueOf(result2);
            }
            if(result2 <= -1257966797) {
                if(result2 === 1) {
                    return BigInteger.valueOf(result1);
                }
                return BigInteger.valueOf(result1 * result2);
            }
        } else if(result2 === 1) {
            return BigInteger.valueOf(result1);
        }
        return BigInteger.valueOf(result1).multiply(BigInteger.valueOf(result2));
    }

    static getCount(segmentValueCountProvider : any, segCount : number) : BigInteger {
        if(segCount < 0) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.Object','java.lang.RuntimeException','java.lang.IllegalArgumentException','java.lang.Exception'] });
        }
        if(segCount === 0) {
            return BigInteger.ZERO;
        }
        let result1 : number = (target => (typeof target === 'function')?target(0):(<any>target).applyAsInt(0))(segmentValueCountProvider);
        let limit : number = Math.min(segCount, 3);
        for(let i : number = 1; i < limit; i++) {
            let nextValue : number = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentValueCountProvider);
            if(result1 === 1) {
                result1 = nextValue;
            } else if(nextValue !== 1) {
                result1 *= nextValue;
            }
        };
        if(segCount <= 3) {
            return BigInteger.valueOf(result1);
        }
        let result2 : number = (target => (typeof target === 'function')?target(3):(<any>target).applyAsInt(3))(segmentValueCountProvider);
        limit = Math.min(segCount, 6);
        for(let i : number = 4; i < limit; i++) {
            let nextValue : number = (target => (typeof target === 'function')?target(i):(<any>target).applyAsInt(i))(segmentValueCountProvider);
            if(result2 === 1) {
                result2 = nextValue;
            } else if(nextValue !== 1) {
                result2 *= nextValue;
            }
        };
        if(segCount <= 6) {
            return IPv6AddressSection.multiply(result1, result2);
        }
        let result3 : number = (target => (typeof target === 'function')?target(6):(<any>target).applyAsInt(6))(segmentValueCountProvider);
        if(segCount > 7) {
            let nextValue : number = (target => (typeof target === 'function')?target(7):(<any>target).applyAsInt(7))(segmentValueCountProvider);
            if(result3 === 1) {
                result3 = nextValue;
            } else if(nextValue !== 1) {
                result3 *= nextValue;
            }
        }
        if(result3 <= -1257966797) {
            if(result3 === 1) {
                return IPv6AddressSection.multiply(result1, result2);
            }
            if(result2 <= -1257966797) {
                result2 *= result3;
                return IPv6AddressSection.multiply(result1, result2);
            }
            if(result1 <= -1257966797) {
                result1 *= result3;
                return IPv6AddressSection.multiply(result1, result2);
            }
        } else if(result2 <= -1257966797) {
            if(result2 === 1) {
                return IPv6AddressSection.multiply(result1, result3);
            }
            if(result1 <= -1257966797) {
                result1 *= result2;
                return IPv6AddressSection.multiply(result1, result3);
            }
        } else if(result1 === 1) {
            return IPv6AddressSection.multiply(result2, result3);
        }
        return IPv6AddressSection.multiply(result1, result2).multiply(BigInteger.valueOf(result3));
    }

    public getCountImpl$boolean(excludeZeroHosts : boolean) : BigInteger {
        if(!this.isMultiple()) {
            if(excludeZeroHosts && this.includesZeroHost()) {
                return BigInteger.ZERO;
            }
            return BigInteger.ONE;
        }
        let segCount : number = this.getSegmentCount();
        let result : BigInteger = IPv6AddressSection.getCount((i) => this.getSegment(i).getValueCount(), segCount);
        if(excludeZeroHosts && this.includesZeroHost()) {
            let prefixedSegment : number = IPAddressSection.getNetworkSegmentIndex(this.getNetworkPrefixLength(), this.getBytesPerSegment(), this.getBitsPerSegment());
            let zeroHostCount : BigInteger = IPv6AddressSection.getCount(((prefixedSegment) => {
                return (i) => {
                    if(i === prefixedSegment) {
                        let seg : IPAddressSegment = this.getSegment(i);
                        let shift : number = seg.getBitCount() - seg.getSegmentPrefixLength();
                        let count : number = ((seg.getUpperSegmentValue() >>> shift) - (seg.getLowerSegmentValue() >>> shift)) + 1;
                        return count;
                    }
                    return this.getSegment(i).getValueCount();
                }
            })(prefixedSegment), prefixedSegment + 1);
            return result.subtract(zeroHostCount);
        }
        return result;
    }

    /**
     * 
     * @param {boolean} excludeZeroHosts
     * @return {BigInteger}
     */
    public getCountImpl(excludeZeroHosts? : any) : any {
        if(((typeof excludeZeroHosts === 'boolean') || excludeZeroHosts === null)) {
            return <any>this.getCountImpl$boolean(excludeZeroHosts);
        } else if(excludeZeroHosts === undefined) {
            return <any>this.getCountImpl$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {BigInteger}
     */
    public getPrefixCount() : BigInteger {
        let prefixLength : number = this.getPrefixLength();
        if(prefixLength == null || prefixLength >= this.getBitCount() || !this.isMultiple()) {
            return this.getCount();
        }
        let networkSegmentIndex : number = IPAddressSection.getNetworkSegmentIndex(prefixLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT);
        let hostSegmentIndex : number = IPAddressSection.getHostSegmentIndex(prefixLength, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT);
        let hasPrefixedSegment : boolean = (networkSegmentIndex === hostSegmentIndex);
        return IPv6AddressSection.getCount(((hasPrefixedSegment,networkSegmentIndex) => {
            return (i) => {
                if(hasPrefixedSegment && i === networkSegmentIndex) {
                    return this.getSegment(i).getPrefixValueCount();
                }
                return this.getSegment(i).getValueCount();
            }
        })(hasPrefixedSegment,networkSegmentIndex), networkSegmentIndex + 1);
    }

    getSegmentCreator() : AddressNetwork.AddressSegmentCreator<IPv6AddressSegment> {
        return this.getNetwork().getAddressCreator();
    }

    getAddressCreator$() : IPv6AddressNetwork.IPv6AddressCreator {
        return this.getAddressCreator$int(this.addressSegmentIndex);
    }

    public getAddressCreator$int(startIndex : number) : IPv6AddressNetwork.IPv6AddressCreator {
        let creator : IPv6AddressNetwork.IPv6AddressCreator = null;
        let useCached : boolean = startIndex < MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT;
        if(useCached) {
            creator = IPv6AddressSection.creators_$LI$()[startIndex];
        }
        if(creator != null) {
            useCached = /* equals */(<any>((o1: any, o2: any) => { if(o1 && o1.equals) { return o1.equals(o2); } else { return o1 === o2; } })(creator.getNetwork(),this.getNetwork())) || useCached;
            if(useCached) {
                return creator;
            }
        }
        creator = new IPv6AddressSection.IPv6AddressSection$0(this, this.getNetwork(), startIndex);
        if(useCached) {
            IPv6AddressSection.creators_$LI$()[startIndex] = creator;
        }
        return creator;
    }

    public getAddressCreator(startIndex? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null)) {
            return <any>this.getAddressCreator$int(startIndex);
        } else if(startIndex === undefined) {
            return <any>this.getAddressCreator$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} index
     * @return {IPv6AddressSegment}
     */
    public getDivision(index : number) : IPv6AddressSegment {
        return <IPv6AddressSegment>super.getDivision(index);
    }

    /**
     * 
     * @param {number} index
     * @return {IPv6AddressSegment}
     */
    public getSegment(index : number) : IPv6AddressSegment {
        return <IPv6AddressSegment>super.getSegment(index);
    }

    public getSegments$java_util_Collection(segs : Array<any>) {
        this.getSegments$int$int$java_util_Collection(0, this.getSegmentCount(), segs);
    }

    public getSegments$int$int$java_util_Collection(start : number, end : number, segs : Array<any>) {
        for(let i : number = start; i < end; i++) {
            /* add */(segs.push(this.getSegment(i))>0);
        };
    }

    public isEUI64$() : boolean {
        return this.isEUI64$boolean(false);
    }

    public isEUI64$boolean(partial : boolean) : boolean {
        let segmentCount : number = this.getSegmentCount();
        let endIndex : number = this.addressSegmentIndex + segmentCount;
        if(this.addressSegmentIndex <= 5) {
            if(endIndex > 6) {
                let index3 : number = 5 - this.addressSegmentIndex;
                let seg3 : IPv6AddressSegment = this.getSegment(index3);
                let seg4 : IPv6AddressSegment = this.getSegment(index3 + 1);
                return seg4.matchesWithMask$int$int(65024, 65280) && seg3.matchesWithMask$int$int(255, 255);
            } else if(partial && endIndex === 6) {
                let seg3 : IPv6AddressSegment = this.getSegment(5 - this.addressSegmentIndex);
                return seg3.matchesWithMask$int$int(255, 255);
            }
        } else if(partial && this.addressSegmentIndex === 6 && endIndex > 6) {
            let seg4 : IPv6AddressSegment = this.getSegment(6 - this.addressSegmentIndex);
            return seg4.matchesWithMask$int$int(65024, 65280);
        }
        return partial;
    }

    /**
     * Whether this section is consistent with an EUI64 section,
     * which means it came from an extended 8 byte address,
     * and the corresponding segments in the middle match 0xff and 0xfe
     * 
     * @param {boolean} partial whether missing segments are considered a match
     * @return
     * @return {boolean}
     */
    public isEUI64(partial? : any) : any {
        if(((typeof partial === 'boolean') || partial === null)) {
            return <any>this.isEUI64$boolean(partial);
        } else if(partial === undefined) {
            return <any>this.isEUI64$();
        } else throw new Error('invalid overload');
    }

    /**
     * Returns the corresponding mac section, or null if this address section does not correspond to a mac section.
     * If this address section has a prefix length it is ignored.
     * 
     * @param {boolean} extended
     * @return
     * @return {MACAddressSection}
     */
    public toEUI(extended : boolean) : MACAddressSection {
        let segs : MACAddressSegment[] = this.toEUISegments(extended);
        if(segs == null) {
            return null;
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getMACNetwork().getAddressCreator();
        return IPv6AddressSection.createSectionInternal$inet_ipaddr_mac_MACAddressNetwork_MACAddressCreator$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(creator, segs, Math.max(0, this.addressSegmentIndex - 4) << 1, extended);
    }

    public static createSectionInternal$inet_ipaddr_mac_MACAddressNetwork_MACAddressCreator$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(creator : MACAddressNetwork.MACAddressCreator, segments : MACAddressSegment[], startIndex : number, extended : boolean) : MACAddressSection {
        return <any>(AddressDivisionGrouping.createSectionInternal$inet_ipaddr_format_AddressCreator$inet_ipaddr_AddressSegment_A$int$boolean(creator, segments, startIndex, extended));
    }

    public static createSectionInternal(creator? : any, segments? : any, startIndex? : any, extended? : any) : any {
        if(((creator != null && creator instanceof <any>MACAddressNetwork.MACAddressCreator) || creator === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>MACAddressSegment))) || segments === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null)) {
            return <any>IPv6AddressSection.createSectionInternal$inet_ipaddr_mac_MACAddressNetwork_MACAddressCreator$inet_ipaddr_mac_MACAddressSegment_A$int$boolean(creator, segments, startIndex, extended);
        } else if(((creator != null && creator instanceof <any>AddressCreator) || creator === null) && ((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof startIndex === 'number') || startIndex === null) && ((typeof extended === 'boolean') || extended === null)) {
            return <any>IPv6AddressSection.createSectionInternal$inet_ipaddr_format_AddressCreator$inet_ipaddr_AddressSegment_A$int$boolean(creator, segments, startIndex, extended);
        } else throw new Error('invalid overload');
    }

    toEUISegments(extended : boolean) : MACAddressSegment[] {
        let seg0 : IPv6AddressSegment;
        let seg1 : IPv6AddressSegment;
        let seg2 : IPv6AddressSegment;
        let seg3 : IPv6AddressSegment;
        let start : number = this.addressSegmentIndex;
        let segmentCount : number = this.getSegmentCount();
        let segmentIndex : number;
        if(start < 4) {
            start = 0;
            segmentIndex = 4 - start;
        } else {
            start -= 4;
            segmentIndex = 0;
        }
        let originalSegmentIndex : number = segmentIndex;
        seg0 = (start === 0 && segmentIndex < segmentCount)?this.getSegment(segmentIndex++):null;
        seg1 = (start <= 1 && segmentIndex < segmentCount)?this.getSegment(segmentIndex++):null;
        seg2 = (start <= 2 && segmentIndex < segmentCount)?this.getSegment(segmentIndex++):null;
        seg3 = (start <= 3 && segmentIndex < segmentCount)?this.getSegment(segmentIndex++):null;
        let macSegCount : number = (segmentIndex - originalSegmentIndex) << 1;
        if(!extended) {
            macSegCount -= 2;
        }
        if((seg1 != null && !seg1.matchesWithMask$int$int(255, 255)) || (seg2 != null && !seg2.matchesWithMask$int$int(65024, 65280)) || macSegCount === 0) {
            return null;
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getMACNetwork().getAddressCreator();
        let ZERO_SEGMENT : MACAddressSegment = creator.createSegment$int(0);
        let newSegs : MACAddressSegment[] = creator.createSegmentArray(macSegCount);
        let macStartIndex : number = 0;
        if(seg0 != null) {
            seg0.getSplitSegments<any>(newSegs, macStartIndex, creator);
            let macSegment0 : MACAddressSegment = newSegs[0];
            let lower0 : number = macSegment0.getLowerSegmentValue();
            let upper0 : number = macSegment0.getUpperSegmentValue();
            let mask2ndBit : number = 2;
            if(!macSegment0.matchesWithMask$int$int(mask2ndBit & lower0, mask2ndBit)) {
                return null;
            }
            lower0 ^= mask2ndBit;
            upper0 ^= mask2ndBit;
            newSegs[0] = creator.createSegment$int$int$java_lang_Integer(lower0, upper0, null);
            macStartIndex += 2;
        }
        if(seg1 != null) {
            seg1.getSplitSegments<any>(newSegs, macStartIndex, creator);
            if(!extended) {
                newSegs[macStartIndex + 1] = ZERO_SEGMENT;
            }
            macStartIndex += 2;
        }
        if(seg2 != null) {
            if(!extended) {
                if(seg1 != null) {
                    macStartIndex -= 2;
                    let first : MACAddressSegment = newSegs[macStartIndex];
                    seg2.getSplitSegments<any>(newSegs, macStartIndex, creator);
                    newSegs[macStartIndex] = first;
                } else {
                    seg2.getSplitSegments<any>(newSegs, macStartIndex, creator);
                    newSegs[macStartIndex] = ZERO_SEGMENT;
                }
            } else {
                seg2.getSplitSegments<any>(newSegs, macStartIndex, creator);
            }
            macStartIndex += 2;
        }
        if(seg3 != null) {
            seg3.getSplitSegments<any>(newSegs, macStartIndex, creator);
        }
        return newSegs;
    }

    public getEmbeddedIPv4AddressSection$int$int(startIndex : number, endIndex : number) : IPv4AddressSection {
        if(startIndex === ((IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex) << 1) && endIndex === (this.getSegmentCount() << 1)) {
            return this.getEmbeddedIPv4AddressSection();
        }
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getIPv4Network().getAddressCreator();
        let segments : IPv4AddressSegment[] = creator.createSegmentArray((endIndex - startIndex) >> 1);
        let i : number = startIndex;
        let j : number = 0;
        if(i % IPv6Address.BYTES_PER_SEGMENT === 1) {
            let ipv6Segment : IPv6AddressSegment = this.getSegment(i >> 1);
            i++;
            ipv6Segment.getSplitSegments<any>(segments, j - 1, creator);
            j++;
        }
        for(; i < endIndex; i <<= 1, j <<= 1) {
            let ipv6Segment : IPv6AddressSegment = this.getSegment(i >> 1);
            ipv6Segment.getSplitSegments<any>(segments, j, creator);
        };
        return <any>(IPAddressSection.createEmbeddedSection<any, any, any>(creator, segments, this));
    }

    /**
     * Produces an IPv4 address section from any sequence of bytes in this IPv6 address section
     * 
     * @param {number} startIndex the byte index in this section to start from
     * @param {number} endIndex the byte index in this section to end at
     * @throws IndexOutOfBoundsException
     * @return
     * 
     * @see #getEmbeddedIPv4AddressSection()
     * @see #getMixedAddressSection()
     * @return {IPv4AddressSection}
     */
    public getEmbeddedIPv4AddressSection(startIndex? : any, endIndex? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getEmbeddedIPv4AddressSection$int$int(startIndex, endIndex);
        } else if(startIndex === undefined && endIndex === undefined) {
            return <any>this.getEmbeddedIPv4AddressSection$();
        } else throw new Error('invalid overload');
    }

    public getEmbeddedIPv4AddressSection$() : IPv4AddressSection {
        if(this.embeddedIPv4Section == null) {
            {
                if(this.embeddedIPv4Section == null) {
                    let mixedCount : number = this.getSegmentCount() - Math.max(IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex, 0);
                    let lastIndex : number = this.getSegmentCount() - 1;
                    let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getIPv4Network().getAddressCreator();
                    let mixed : IPv4AddressSegment[];
                    if(mixedCount === 0) {
                        mixed = creator.createSegmentArray(0);
                    } else {
                        if(mixedCount === 1) {
                            mixed = creator.createSegmentArray(IPv6Address.BYTES_PER_SEGMENT);
                            let last : IPv6AddressSegment = this.getSegment(lastIndex);
                            last.getSplitSegments<any>(mixed, 0, creator);
                        } else {
                            mixed = creator.createSegmentArray(IPv6Address.BYTES_PER_SEGMENT << 1);
                            let low : IPv6AddressSegment = this.getSegment(lastIndex);
                            let high : IPv6AddressSegment = this.getSegment(lastIndex - 1);
                            high.getSplitSegments<any>(mixed, 0, creator);
                            low.getSplitSegments<any>(mixed, IPv6Address.BYTES_PER_SEGMENT, creator);
                        }
                    }
                    this.embeddedIPv4Section = <any>(IPAddressSection.createEmbeddedSection<any, any, any>(creator, mixed, this));
                }
            };
        }
        return this.embeddedIPv4Section;
    }

    public createNonMixedSection() : IPv6AddressSection {
        let mixedCount : number = this.getSegmentCount() - Math.max(IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex, 0);
        if(mixedCount <= 0) {
            return this;
        }
        let nonMixedCount : number = Math.max(0, this.getSegmentCount() - mixedCount);
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getNetwork().getAddressCreator();
        let nonMixed : IPv6AddressSegment[] = creator.createSegmentArray(nonMixedCount);
        this.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, nonMixedCount, nonMixed, 0);
        return creator.createEmbeddedSectionInternal$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$int(this, nonMixed, this.addressSegmentIndex);
    }

    public getMixedAddressSection() : IPv6AddressSection.IPv6v4MixedAddressSection {
        if(this.defaultMixedAddressSection == null) {
            {
                if(this.defaultMixedAddressSection == null) {
                    this.defaultMixedAddressSection = new IPv6AddressSection.IPv6v4MixedAddressSection(this.createNonMixedSection(), this.getEmbeddedIPv4AddressSection());
                }
            };
        }
        return this.defaultMixedAddressSection;
    }

    public static createSection(creator : IPv6AddressNetwork.IPv6AddressCreator, nonMixedSection : IPv6AddressSegment[], mixedSection : IPv4Address) : IPv6AddressSection {
        let ipv4Section : IPv4AddressSection = mixedSection.getSection();
        let newSegs : IPv6AddressSegment[] = creator.createSegmentArray(nonMixedSection.length + IPv6Address.MIXED_REPLACED_SEGMENT_COUNT);
        newSegs[0] = nonMixedSection[0];
        newSegs[1] = nonMixedSection[1];
        newSegs[2] = nonMixedSection[2];
        newSegs[3] = nonMixedSection[3];
        newSegs[4] = nonMixedSection[4];
        newSegs[5] = nonMixedSection[5];
        newSegs[6] = ipv4Section.getSegment(0).join(creator, ipv4Section.getSegment(1));
        newSegs[7] = ipv4Section.getSegment(2).join(creator, ipv4Section.getSegment(3));
        let result : IPv6AddressSection = creator.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(newSegs);
        result.embeddedIPv4Section = ipv4Section;
        return result;
    }

    /**
     * Create an IPv6 mixed address using the given address for the embedded IPv4 segments
     * 
     * @param {IPv4Address} mixedSection the IPv4 address used to construct the terminating segments of the returned address
     * @return
     * @return {IPv6Address}
     */
    public getIPv6Address(mixedSection : IPv4Address) : IPv6Address {
        return mixedSection.getIPv6Address(this.getSegmentsInternal());
    }

    /**
     * 
     * @return {number}
     */
    public getBitsPerSegment() : number {
        return IPv6Address.BITS_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBytesPerSegment() : number {
        return IPv6Address.BYTES_PER_SEGMENT;
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return this.getSegmentCount() << 4;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return this.getSegmentCount() << 1;
    }

    /**
     * 
     * @param {boolean} low
     * @return {Array}
     */
    getBytesImpl(low : boolean) : number[] {
        let bytes : number[] = (s => { let a=[]; while(s-->0) a.push(0); return a; })(this.getByteCount());
        let segmentCount : number = this.getSegmentCount();
        for(let i : number = 0; i < segmentCount; i++) {
            let seg : IPv6AddressSegment = this.getSegment(i);
            let byteIndex : number = i << 1;
            let val : number = low?seg.getLowerSegmentValue():seg.getUpperSegmentValue();
            bytes[byteIndex] = (<number>(val >> 8)|0);
            bytes[byteIndex + 1] = (<number>val|0);
        };
        return bytes;
    }

    /**
     * Returns whether this subnet or address has alphabetic digits when printed.
     * 
     * Note that this method does not indicate whether any address contained within this subnet has alphabetic digits,
     * only whether the subnet itself when printed has alphabetic digits.
     * 
     * @return {boolean} whether the section has alphabetic digits when printed.
     * @param {number} base
     * @param {boolean} lowerOnly
     */
    public hasUppercaseVariations(base : number, lowerOnly : boolean) : boolean {
        if(base > 10) {
            let count : number = this.getSegmentCount();
            for(let i : number = 0; i < count; i++) {
                let seg : IPv6AddressSegment = this.getSegment(i);
                if(seg.hasUppercaseVariations(base, lowerOnly)) {
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv6() : boolean {
        return true;
    }

    /**
     * 
     * @return {IPAddress.IPVersion}
     */
    public getIPVersion() : IPAddress.IPVersion {
        return IPAddress.IPVersion.IPV6;
    }

    public append(other : IPv6AddressSection) : IPv6AddressSection {
        let count : number = this.getSegmentCount();
        return this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(count, count, other, 0, other.getSegmentCount());
    }

    public appendToNetwork(other : IPv6AddressSection) : IPv6AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null) {
            return this.append(other);
        }
        let thizz : IPv6AddressSection = this;
        let bitsPerSegment : number = this.getBitsPerSegment();
        let adjustment : number = prefixLength % bitsPerSegment;
        if(adjustment !== 0) {
            prefixLength += bitsPerSegment - adjustment;
            thizz = this.setPrefixLength$int$boolean(prefixLength, false);
        }
        let index : number = prefixLength >>> 4;
        if(other.isPrefixed() && other.getPrefixLength() === 0) {
            return this.insert(index, other);
        }
        return thizz.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int$boolean(index, index, other, 0, other.getSegmentCount(), true);
    }

    public insert(index : number, other : IPv6AddressSection) : IPv6AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(index, index, other, 0, other.getSegmentCount());
    }

    public replace$int$inet_ipaddr_ipv6_IPv6AddressSection(index : number, replacement : IPv6AddressSection) : IPv6AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(index, index + replacement.getSegmentCount(), replacement, 0, replacement.getSegmentCount());
    }

    public replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(startIndex : number, endIndex : number, replacement : IPv6AddressSection, replacementStartIndex : number, replacementEndIndex : number) : IPv6AddressSection {
        return this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, false);
    }

    public replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int$boolean(startIndex : number, endIndex : number, replacement : IPv6AddressSection, replacementStartIndex : number, replacementEndIndex : number, appendNetwork : boolean) : IPv6AddressSection {
        let segmentCount : number = this.getSegmentCount();
        let replacedCount : number = endIndex - startIndex;
        let replacementCount : number = replacementEndIndex - replacementStartIndex;
        if(replacedCount < 0 || replacementCount < 0 || startIndex < 0 || replacementStartIndex < 0 || replacementEndIndex > replacement.getSegmentCount() || endIndex > segmentCount) {
            throw Object.defineProperty(new Error(), '__classes', { configurable: true, value: ['java.lang.Throwable','java.lang.IndexOutOfBoundsException','java.lang.Object','java.lang.RuntimeException','java.lang.Exception'] });
        }
        let thizz : IPv6AddressSection = this;
        if(this.addressSegmentIndex + segmentCount + replacementCount - replacedCount > IPv6Address.SEGMENT_COUNT) {
            throw new AddressValueException(this, replacement);
        } else if(replacementCount === 0 && replacedCount === 0) {
            return this;
        } else if(this.addressSegmentIndex === replacement.addressSegmentIndex && segmentCount === replacedCount) {
            return replacement;
        } else if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            if(appendNetwork) {
                thizz = this.removePrefixLength$boolean(false);
                let replacementEndBits : number = replacementEndIndex << 4;
                if(!replacement.isPrefixed() || replacement.getNetworkPrefixLength() > replacementEndBits) {
                    replacement = replacement.setPrefixLength$int$boolean(replacementEndBits, false);
                }
            }
        } else {
            let prefixLength : number = this.getPrefixLength();
            if(appendNetwork) {
                let additionalSegs : number = segmentCount - endIndex;
                if(additionalSegs > 0) {
                    thizz = this.getSection$int$int(0, startIndex).removePrefixLength$boolean(false);
                    replacement = replacement.insert(replacementEndIndex, this.getSection$int(endIndex));
                    replacementEndIndex += additionalSegs;
                    endIndex = startIndex;
                } else {
                    thizz = this.removePrefixLength$boolean(false);
                    let replacementEndBits : number = replacementEndIndex << 4;
                    if(!replacement.isPrefixed() || replacement.getNetworkPrefixLength() > replacementEndBits) {
                        replacement = replacement.setPrefixLength$int$boolean(replacementEndBits, false);
                    }
                }
            } else if(prefixLength != null && prefixLength <= startIndex << 4) {
                replacement = replacement.setPrefixLength$int$boolean(0, false);
            } else if(endIndex < segmentCount) {
                let replacementEndBits : number = replacementEndIndex << 4;
                if(replacement.isPrefixed() && replacement.getNetworkPrefixLength() <= replacementEndBits) {
                    let thisNextIndexBits : number = endIndex << 4;
                    if(prefixLength == null || prefixLength > thisNextIndexBits) {
                        if(replacedCount > 0 || replacement.getPrefixLength() === 0) {
                            thizz = this.setPrefixLength$int$boolean(thisNextIndexBits, false);
                        } else {
                            let additionalSegs : number = segmentCount - endIndex;
                            thizz = this.getSection$int$int(0, startIndex);
                            replacement = replacement.insert(replacementEndIndex, this.getSection$int(endIndex));
                            replacementEndIndex += additionalSegs;
                        }
                    }
                }
            }
        }
        return <any>(AddressDivisionGrouping.replace<any, any>(thizz, startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, this.getAddressCreator(), appendNetwork, false));
    }

    public replace(startIndex? : any, endIndex? : any, replacement? : any, replacementStartIndex? : any, replacementEndIndex? : any, appendNetwork? : any) : any {
        if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>IPv6AddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && ((typeof appendNetwork === 'boolean') || appendNetwork === null)) {
            return <any>this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int$boolean(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex, appendNetwork);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((typeof endIndex === 'number') || endIndex === null) && ((replacement != null && replacement instanceof <any>IPv6AddressSection) || replacement === null) && ((typeof replacementStartIndex === 'number') || replacementStartIndex === null) && ((typeof replacementEndIndex === 'number') || replacementEndIndex === null) && appendNetwork === undefined) {
            return <any>this.replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(startIndex, endIndex, replacement, replacementStartIndex, replacementEndIndex);
        } else if(((typeof startIndex === 'number') || startIndex === null) && ((endIndex != null && endIndex instanceof <any>IPv6AddressSection) || endIndex === null) && replacement === undefined && replacementStartIndex === undefined && replacementEndIndex === undefined && appendNetwork === undefined) {
            return <any>this.replace$int$inet_ipaddr_ipv6_IPv6AddressSection(startIndex, endIndex);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} other
     * @return {boolean}
     */
    public contains(other : AddressSection) : boolean {
        return (other != null && other instanceof <any>IPv6AddressSection) && this.addressSegmentIndex === (<IPv6AddressSection><any>other).addressSegmentIndex && super.contains(other);
    }

    /**
     * 
     * @param {IPAddressSection} other
     * @param {IPAddressSection} mask
     * @return {boolean}
     */
    public matchesWithMask(other : IPAddressSection, mask : IPAddressSection) : boolean {
        return (other != null && other instanceof <any>IPv6AddressSection) && (mask != null && mask instanceof <any>IPv6AddressSection) && super.matchesWithMask(other, mask);
    }

    /**
     * 
     * @param {AddressDivisionGrouping} other
     * @return {boolean}
     */
    isSameGrouping(other : AddressDivisionGrouping) : boolean {
        return (other != null && other instanceof <any>IPv6AddressSection) && this.addressSegmentIndex === (<IPv6AddressSection>other).addressSegmentIndex && super.isSameGrouping(other);
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o === this) {
            return true;
        }
        if(o != null && o instanceof <any>IPv6AddressSection) {
            let other : IPv6AddressSection = <IPv6AddressSection>o;
            return this.addressSegmentIndex === other.addressSegmentIndex && super.isSameGrouping(other);
        }
        return false;
    }

    /**
     * Produces the subnet sections whose addresses are found in both this and the given argument.
     * <p>
     * This is also known as the conjunction of the two sets of address sections.
     * <p>
     * @param {IPv6AddressSection} other
     * @return {IPv6AddressSection} the section containing the sections found in both this and the given subnet sections
     */
    public intersect(other : IPv6AddressSection) : IPv6AddressSection {
        return <any>(IPAddressSection.intersect<any, any, any>(this, other, this.getAddressCreator(), (index) => { return this.getSegment(index) }, (index) => { return other.getSegment(index) }));
    }

    /**
     * Subtract the give subnet from this subnet, returning an array of sections for the result (the subnets will not be contiguous so an array is required).
     * <p>
     * Computes the subnet difference, the set of addresses in this address section but not in the provided section.  This is also known as the relative complement of the given argument in this subnet.
     * <p>
     * Keep in mind this is set subtraction, not subtraction of segment values.  We have a subnet of addresses and we are removing some of those addresses.
     * 
     * @param {IPv6AddressSection} other
     * @throws SizeMismatchException if the two sections have different sizes
     * @return {Array} the difference
     */
    public subtract(other : IPv6AddressSection) : IPv6AddressSection[] {
        return IPAddressSection.subtract<any, any, any>(this, other, this.getAddressCreator(), (index) => { return this.getSegment(index) }, (section, prefix) => section.setPrefixLength$int$boolean$boolean(prefix, false, true));
    }

    /**
     * 
     * @return {IPv6AddressNetwork}
     */
    public getNetwork() : IPv6AddressNetwork {
        return Address.defaultIpv6Network();
    }

    public getIPv4Network() : IPv4AddressNetwork {
        return Address.defaultIpv4Network();
    }

    public getMACNetwork() : MACAddressNetwork {
        return Address.defaultMACNetwork();
    }

    public getNetworkPrefixLength$int$int(segmentIndex : number, segmentPrefix : number) : number {
        return (segmentIndex << 4) + segmentPrefix;
    }

    /**
     * 
     * @param {number} segmentIndex
     * @param {number} segmentPrefix
     * @return {number}
     */
    public getNetworkPrefixLength(segmentIndex? : any, segmentPrefix? : any) : any {
        if(((typeof segmentIndex === 'number') || segmentIndex === null) && ((typeof segmentPrefix === 'number') || segmentPrefix === null)) {
            return <any>this.getNetworkPrefixLength$int$int(segmentIndex, segmentPrefix);
        } else if(segmentIndex === undefined && segmentPrefix === undefined) {
            return <any>this.getNetworkPrefixLength$();
        } else throw new Error('invalid overload');
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPv6AddressSection {
        return this.adjustPrefixBySegment$boolean$boolean(nextSegment, true);
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPv6AddressSection {
        return <IPv6AddressSection>super.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPv6AddressSection}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : IPv6AddressSection {
        return this.adjustPrefixLength$int$boolean(adjustment, true);
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPv6AddressSection {
        return <IPv6AddressSection>IPAddressSection.adjustPrefixLength<any, any>(this, adjustment, zeroed, this.getAddressCreator(), (section, i) => section.getSegment(i));
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPv6AddressSection}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6AddressSection}
     */
    public applyPrefixLength(networkPrefixLength : number) : IPv6AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, true, true);
    }

    public setPrefixLength$int(networkPrefixLength : number) : IPv6AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, true, false);
    }

    public setPrefixLength$int$boolean(networkPrefixLength : number, withZeros : boolean) : IPv6AddressSection {
        return this.setPrefixLength$int$boolean$boolean(networkPrefixLength, withZeros, false);
    }

    public setPrefixLength$int$boolean$boolean(networkPrefixLength : number, withZeros : boolean, noShrink : boolean) : IPv6AddressSection {
        return <any>(IPAddressSection.setPrefixLength<any, any>(this, this.getAddressCreator(), networkPrefixLength, withZeros, noShrink, (section, i) => section.getSegment(i)));
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && ((typeof noShrink === 'boolean') || noShrink === null)) {
            return <any>this.setPrefixLength$int$boolean$boolean(networkPrefixLength, withZeros, noShrink);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public removePrefixLength$() : IPv6AddressSection {
        return this.removePrefixLength$boolean(true);
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPv6AddressSection {
        return <any>(IPAddressSection.removePrefixLength<any, any>(this, zeroed, this.getAddressCreator(), (index) => { return IPv6AddressSection.getSegment(index) }));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPv6AddressSection}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    /**
     * Does the bitwise disjunction with this address.  Useful when subnetting.  Similar to {@link #maskNetwork(IPv6AddressSection, int)} which does the bitwise conjunction.
     * <p>
     * Any existing prefix length is dropped for the new prefix length and the mask is applied up to the end the new prefix length.
     * 
     * @param {IPv6AddressSection} mask
     * @return
     * @throws IncompatibleAddressException
     * @param {number} networkPrefixLength
     * @return {IPv6AddressSection}
     */
    public bitwiseOrNetwork(mask : IPv6AddressSection, networkPrefixLength : number) : IPv6AddressSection {
        this.checkMaskSectionCount(mask);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return <any>(IPAddressSection.getOredSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue()));
        }
        let networkMask : IPv6AddressSection = this.getNetwork().getNetworkMaskSection(networkPrefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, ((networkMask) => {
            return (i) => {
                let val1 : number = mask.getSegment(i).getLowerSegmentValue();
                let val2 : number = networkMask.getSegment(i).getLowerSegmentValue();
                return val1 & val2;
            }
        })(networkMask)));
    }

    public bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection(mask : IPv6AddressSection) : IPv6AddressSection {
        return this.bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask, false);
    }

    public bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask : IPv6AddressSection, retainPrefix : boolean) : IPv6AddressSection {
        this.checkMaskSectionCount(mask);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, retainPrefix?this.getPrefixLength():null, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue()));
    }

    /**
     * Does the bitwise disjunction with this address.  Useful when subnetting.  Similar to {@link #mask(IPv6AddressSection)} which does the bitwise conjunction.
     * 
     * @param {IPv6AddressSection} mask
     * @param {boolean} retainPrefix whether to drop the prefix
     * @return
     * @throws IncompatibleAddressException
     * @return {IPv6AddressSection}
     */
    public bitwiseOr(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPv6AddressSection) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPv6AddressSection) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection(mask);
        } else throw new Error('invalid overload');
    }

    public toZeroHost$() : IPv6AddressSection {
        if(!this.isPrefixed()) {
            let networkMask : IPv6Address = this.getNetwork().getNetworkMask(0, !AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets());
            return networkMask.getSection$int$int(0, this.getSegmentCount());
        }
        if(this.includesZeroHost() && this.isSingleNetwork()) {
            return this.getLower();
        }
        return this.createZeroHost();
    }

    createZeroHost() : IPv6AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        let mask : IPv6Address = this.getNetwork().getNetworkMask(prefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:prefixLength, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask), true));
    }

    public toZeroHost$int(prefixLength : number) : IPv6AddressSection {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toZeroHost();
        }
        let mask : IPv6Address = this.getNetwork().getNetworkMask(prefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, null, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask), true));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv6AddressSection}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toZeroHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPv6AddressSection {
        if(!this.isPrefixed()) {
            let resultNoPrefix : IPv6Address = this.getNetwork().getHostMask(0);
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                return resultNoPrefix.getSection$int$int(0, this.getSegmentCount());
            }
            return resultNoPrefix.setPrefixLength$int(0).getSection$int$int(0, this.getSegmentCount());
        }
        if(this.includesMaxHost() && this.isSingleNetwork()) {
            return this.getUpper();
        }
        return this.createMaxHost();
    }

    public createMaxHost() : IPv6AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        let mask : IPv6Address = this.getNetwork().getHostMask(prefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()?null:prefixLength, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask)));
    }

    public toMaxHost$int(prefixLength : number) : IPv6AddressSection {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toMaxHost();
        }
        let mask : IPv6Address = this.getNetwork().getHostMask(prefixLength);
        return <any>(IPAddressSection.getOredSegments<any, any>(this, null, this.getAddressCreator(), false, (index) => { return this.getSegment(index) }, ((mask) => {
            return (i) => mask.getSegment(i).getLowerSegmentValue()
        })(mask)));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv6AddressSection}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toMaxHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask : IPv6AddressSection, retainPrefix : boolean) : IPv6AddressSection {
        this.checkMaskSectionCount(mask);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, retainPrefix?this.getPrefixLength():null, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue(), false));
    }

    /**
     * Does the bitwise conjuction with this address.  Useful when subnetting.
     * 
     * @param {IPv6AddressSection} mask
     * @param {boolean} retainPrefix whether to drop the prefix
     * @return
     * @throws IncompatibleAddressException
     * @return {IPv6AddressSection}
     */
    public mask(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPv6AddressSection) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.mask$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPv6AddressSection) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_ipv6_IPv6AddressSection(mask);
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_ipv6_IPv6AddressSection(mask : IPv6AddressSection) : IPv6AddressSection {
        return this.mask$inet_ipaddr_ipv6_IPv6AddressSection$boolean(mask, false);
    }

    /**
     * Applies the given mask to the network section of the address as indicated by the given prefix length.
     * Useful for subnetting.  Once you have zeroed a section of the network you can insert bits
     * using {@link #bitwiseOr(IPv6AddressSection)} or {@link #replace(int, IPv6AddressSection)}
     * 
     * @param {IPv6AddressSection} mask
     * @param {number} networkPrefixLength
     * @return
     * @throws IncompatibleAddressException
     * @return {IPv6AddressSection}
     */
    public maskNetwork(mask : IPv6AddressSection, networkPrefixLength : number) : IPv6AddressSection {
        this.checkMaskSectionCount(mask);
        if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return <any>(IPAddressSection.getSubnetSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, (i) => mask.getSegment(i).getLowerSegmentValue(), false));
        }
        let hostMask : IPv6AddressSection = this.getNetwork().getHostMaskSection(networkPrefixLength);
        return <any>(IPAddressSection.getSubnetSegments<any, any>(this, networkPrefixLength, this.getAddressCreator(), true, (index) => { return this.getSegment(index) }, ((hostMask) => {
            return (i) => {
                let val1 : number = mask.getSegment(i).getLowerSegmentValue();
                let val2 : number = hostMask.getSegment(i).getLowerSegmentValue();
                return val1 | val2;
            }
        })(hostMask), false));
    }

    public getNetworkSection$() : IPv6AddressSection {
        if(this.isPrefixed()) {
            return this.getNetworkSection$int(this.getNetworkPrefixLength());
        }
        return this.getNetworkSection$int(this.getBitCount());
    }

    public getNetworkSection$int(networkPrefixLength : number) : IPv6AddressSection {
        return this.getNetworkSection$int$boolean(networkPrefixLength, true);
    }

    public getNetworkSection$int$boolean(networkPrefixLength : number, withPrefixLength : boolean) : IPv6AddressSection {
        return <any>(IPAddressSection.getNetworkSection<any, any, any>(this, networkPrefixLength, withPrefixLength, this.getAddressCreator(), (i, prefix) => this.getSegment(i).toNetworkSegment$java_lang_Integer$boolean(prefix, withPrefixLength)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @param {boolean} withPrefixLength
     * @return {IPv6AddressSection}
     */
    public getNetworkSection(networkPrefixLength? : any, withPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null)) {
            return <any>this.getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$();
        } else throw new Error('invalid overload');
    }

    public getHostSection$() : IPv6AddressSection {
        if(this.isPrefixed()) {
            return this.getHostSection$int(this.getNetworkPrefixLength());
        }
        return this.getHostSection$int(0);
    }

    public getHostSection$int(networkPrefixLength : number) : IPv6AddressSection {
        let hostSegmentCount : number = this.getHostSegmentCount$int(networkPrefixLength);
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getAddressCreator$int(this.addressSegmentIndex + (this.getSegmentCount() - hostSegmentCount));
        return <any>(IPAddressSection.getHostSection<any, any, any>(this, networkPrefixLength, hostSegmentCount, creator, (i, prefix) => this.getSegment(i).toHostSegment$java_lang_Integer(prefix)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6AddressSection}
     */
    public getHostSection(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostSection$();
        } else throw new Error('invalid overload');
    }

    public toPrefixBlock$() : IPv6AddressSection {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null || AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return this;
        }
        return this.toPrefixBlock$int(prefixLength);
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public assignPrefixForSingleBlock() : IPv6AddressSection {
        return <IPv6AddressSection>super.assignPrefixForSingleBlock();
    }

    /**
     * 
     * @return {IPv6AddressSection}
     */
    public assignMinPrefixForBlock() : IPv6AddressSection {
        return <IPv6AddressSection>super.assignMinPrefixForBlock();
    }

    public toPrefixBlock$int(networkPrefixLength : number) : IPv6AddressSection {
        return <any>(IPAddressSection.toPrefixBlock<any, any, any>(this, networkPrefixLength, this.getAddressCreator(), (i, prefix) => this.getSegment(i).toNetworkSegment$java_lang_Integer$boolean(prefix, true)));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6AddressSection}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            super.toPrefixBlock(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * Produces the list of prefix block subnets that span from this series to the given series.
     * 
     * @param {IPv6AddressSection} other
     * @return
     * @return {Array}
     */
    public getSpanningPrefixBlocks(other : IPv6AddressSection) : IPv6AddressSection[] {
        if(other.addressSegmentIndex !== this.addressSegmentIndex) {
            throw new AddressPositionException(other, other.addressSegmentIndex, this.addressSegmentIndex);
        }
        return IPAddressSection.getSpanningPrefixBlocks<any>(this, other, () => { return IPv6AddressSection.getLower() }, () => { return IPv6AddressSection.getUpper() }, (one,two) => { return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$().compare(one,two) }, (section) => section.removePrefixLength$boolean(false), (length) => { return this.getAddressCreator().createSectionArray(length) });
    }

    /**
     * Merges this with the list of sections to produce the smallest array of prefix blocks, going from smallest to largest
     * 
     * @param {Array} sections the sections to merge with this
     * @return
     * @return {Array}
     */
    public mergeBlocks(...sections : IPv6AddressSection[]) : IPv6AddressSection[] {
        if(sections.length === 0) {
            return [this];
        }
        for(let i : number = 0; i < sections.length; i++) {
            let section : IPv6AddressSection = sections[i];
            if(section.addressSegmentIndex !== this.addressSegmentIndex) {
                throw new AddressPositionException(section, section.addressSegmentIndex, this.addressSegmentIndex);
            }
        };
        let blocks : Array<IPAddressSegmentSeries> = IPAddressSection.getMergedBlocks(this, sections, true);
        return /* toArray */blocks.slice(0);
    }

    /**
     * 
     * @return {boolean}
     */
    hasNoStringCache() : boolean {
        if(this.stringCache == null) {
            {
                if(this.stringCache == null) {
                    this.stringCache = new IPv6AddressSection.IPv6StringCache();
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 
     * @return {IPv6AddressSection.IPv6StringCache}
     */
    getStringCache() : IPv6AddressSection.IPv6StringCache {
        return this.stringCache;
    }

    /**
     * This produces the shortest valid string for the address.
     * @return {string}
     */
    public toCompressedString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().compressedString) == null) {
            this.getStringCache().compressedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.compressedParams_$LI$());
        }
        return result;
    }

    /**
     * This produces a canonical string.
     * 
     * RFC 5952 describes canonical representations.
     * http://en.wikipedia.org/wiki/IPv6_address#Recommended_representation_as_text
     * http://tools.ietf.org/html/rfc5952
     * @return {string}
     */
    public toCanonicalString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.canonicalString) == null) {
            this.stringCache.canonicalString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.canonicalParams_$LI$());
        }
        return result;
    }

    /**
     * This produces the mixed IPv6/IPv4 string.  It is the shortest such string (ie fully compressed).
     * @return {string}
     */
    public toMixedString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().mixedString) == null) {
            this.getStringCache().mixedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.mixedParams_$LI$());
        }
        return result;
    }

    /**
     * This produces a string with no compressed segments and all segments of full length,
     * which is 4 characters for IPv6 segments and 3 characters for IPv4 segments.
     * @return {string}
     */
    public toFullString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().fullString) == null) {
            this.getStringCache().fullString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.fullParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toCompressedWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().compressedWildcardString) == null) {
            this.getStringCache().compressedWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardCompressedParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toPrefixLengthString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().networkPrefixLengthString) == null) {
            this.getStringCache().networkPrefixLengthString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.networkPrefixLengthParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toSubnetString() : string {
        return this.toPrefixLengthString();
    }

    /**
     * 
     * @return {string}
     */
    public toCanonicalWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().canonicalWildcardString) == null) {
            this.getStringCache().canonicalWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardCanonicalParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toNormalizedWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().normalizedWildcardString) == null) {
            this.getStringCache().normalizedWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardNormalizedParams_$LI$());
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toSQLWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().sqlWildcardString) == null) {
            this.getStringCache().sqlWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.sqlWildcardParams_$LI$());
        }
        return result;
    }

    public toNormalizedString$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().normalizedString) == null) {
            this.getStringCache().normalizedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.normalizedParams_$LI$());
        }
        return result;
    }

    public toBase85String$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().base85String) == null) {
            this.getStringCache().base85String = result = this.toBase85String$java_lang_String(null);
        }
        return result;
    }

    public toBase85String$java_lang_String(zone : string) : string {
        let prefixLength : number = this.getNetworkPrefixLength();
        let largeDiv : IPAddressLargeDivision;
        if(this.isDualString()) {
            largeDiv = new IPAddressLargeDivision(this.getBytesInternal(), this.getUpperBytesInternal(), this.getBitCount(), 85, this.getNetwork(), prefixLength);
        } else {
            largeDiv = new IPAddressLargeDivision(this.getBytesInternal(), this.getBitCount(), 85, this.getNetwork(), prefixLength);
        }
        let part : IPAddressStringDivisionSeries = new IPAddressStringDivisionGrouping([largeDiv], this.getNetwork(), prefixLength);
        return IPv6AddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence$inet_ipaddr_format_IPAddressStringDivisionSeries(IPv6AddressSection.IPv6StringCache.base85Params_$LI$(), zone, part);
    }

    public toBase85String(zone? : any) : any {
        if(((typeof zone === 'string') || zone === null)) {
            return <any>this.toBase85String$java_lang_String(zone);
        } else if(zone === undefined) {
            return <any>this.toBase85String$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {string} str
     */
    cacheNormalizedString(str : string) {
        if(this.hasNoStringCache() || this.getStringCache().normalizedString == null) {
            this.getStringCache().normalizedString = str;
        }
    }

    /**
     * 
     * @return {string}
     */
    public toReverseDNSLookupString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.getStringCache().reverseDNSString) == null) {
            let stringCache : IPAddressSection.IPStringCache = this.getStringCache();
            stringCache.reverseDNSString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(IPv6AddressSection.IPv6StringCache.reverseDNSParams_$LI$(), "");
        }
        return result;
    }

    public toBinaryString$java_lang_CharSequence(zone : any) : string {
        if(this.isDualString()) {
            let params : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> = IPAddressSection.toIPParams(IPAddressSection.IPStringCache.binaryParams_$LI$());
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(params, this.getLower(), this.getUpper(), zone);
        }
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(IPAddressSection.IPStringCache.binaryParams_$LI$(), zone);
    }

    /**
     * 
     * @param {*} zone
     * @return {string}
     */
    public toBinaryString(zone? : any) : any {
        if(((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toBinaryString$java_lang_CharSequence(zone);
        } else if(zone === undefined) {
            return <any>this.toBinaryString$();
        } else throw new Error('invalid overload');
    }

    public toHexString$boolean$java_lang_CharSequence(with0xPrefix : boolean, zone : any) : string {
        if(this.isDualString()) {
            let params : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> = IPAddressSection.toIPParams(with0xPrefix?IPAddressSection.IPStringCache.hexPrefixedParams_$LI$():IPAddressSection.IPStringCache.hexParams_$LI$());
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(params, this.getLower(), this.getUpper(), zone);
        }
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(with0xPrefix?IPAddressSection.IPStringCache.hexPrefixedParams_$LI$():IPAddressSection.IPStringCache.hexParams_$LI$(), zone);
    }

    /**
     * 
     * @param {boolean} with0xPrefix
     * @param {*} zone
     * @return {string}
     */
    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toHexString$boolean$java_lang_CharSequence(with0xPrefix, zone);
        } else if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toOctalString$boolean$java_lang_CharSequence(with0Prefix : boolean, zone : any) : string {
        if(zone == null) {
            return super.toOctalString$boolean$java_lang_CharSequence(with0Prefix, null);
        }
        let params : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> = IPAddressSection.toIPParams(with0Prefix?IPAddressSection.IPStringCache.octalPrefixedParams_$LI$():IPAddressSection.IPStringCache.octalParams_$LI$());
        if(this.isDualString()) {
            let lower : IPv6AddressSection = this.getLower();
            let upper : IPv6AddressSection = this.getUpper();
            let lowerDivs : IPAddressBitsDivision[] = lower.createNewDivisions<any>(3, (value,upperValue,bitCount,defaultRadix) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
            let lowerPart : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(lowerDivs, this.getNetwork());
            let upperDivs : IPAddressBitsDivision[] = upper.createNewDivisions<any>(3, (value,upperValue,bitCount,defaultRadix) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
            let upperPart : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(upperDivs, this.getNetwork());
            return AddressDivisionGrouping.toNormalizedStringRange<any, any>(params, lowerPart, upperPart, zone);
        }
        let divs : IPAddressBitsDivision[] = this.createNewPrefixedDivisions<any>(3, null, null, (value,upperValue,bitCount,defaultRadix,network,networkPrefixLength) => { return new IPAddressBitsDivision(value,upperValue,bitCount,defaultRadix,network,networkPrefixLength) }, (arg0) => { return new Array<IPAddressBitsDivision>(arg0) });
        let part : IPAddressStringDivisionSeries = new IPAddressDivisionGrouping(divs, this.getNetwork());
        return params.toString(part, zone);
    }

    /**
     * 
     * @param {boolean} with0Prefix
     * @param {*} zone
     * @return {string}
     */
    public toOctalString(with0Prefix? : any, zone? : any) : any {
        if(((typeof with0Prefix === 'boolean') || with0Prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toOctalString$boolean$java_lang_CharSequence(with0Prefix, zone);
        } else if(((typeof with0Prefix === 'boolean') || with0Prefix === null) && zone === undefined) {
            return <any>this.toOctalString$boolean(with0Prefix);
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options : IPAddressSection.IPStringOptions) : string {
        if(options != null && options instanceof <any>IPv6AddressSection.IPv6StringOptions) {
            return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(<IPv6AddressSection.IPv6StringOptions>options);
        }
        return super.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
    }

    public toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(options : IPv6AddressSection.IPv6StringOptions) : string {
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(options, <string>null);
    }

    toNormalizedMixedString(mixedParams : IPv6AddressSection.IPv6v4MixedParams, zone : any) : string {
        let mixed : IPv6AddressSection.IPv6v4MixedAddressSection = this.getMixedAddressSection();
        let result : string = mixedParams.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection$java_lang_CharSequence(mixed, zone);
        return result;
    }

    toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(options : IPAddressSection.IPStringOptions, zone : any) : string {
        if(zone == null) {
            return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
        }
        if(options != null && options instanceof <any>IPv6AddressSection.IPv6StringOptions) {
            return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(<IPv6AddressSection.IPv6StringOptions>options, zone);
        }
        let params : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries> = IPAddressSection.toIPParams(options);
        return params.toString(this, zone);
    }

    public toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions$java_lang_CharSequence(options : IPv6AddressSection.IPv6StringOptions, zone : any) : string {
        let stringParams : IPv6AddressSection.IPv6StringParams;
        if(options.isCacheable()) {
            let cachedParams : IPAddressStringWriter<any> = <IPAddressStringWriter<any>><any>AddressDivisionGrouping.getCachedParams(options);
            if(cachedParams == null) {
                stringParams = options.from(this);
                if(options.makeMixed()) {
                    let mixedParams : IPv6AddressSection.IPv6v4MixedParams = new IPv6AddressSection.IPv6v4MixedParams(stringParams, options.ipv4Opts);
                    AddressDivisionGrouping.setCachedParams(options, mixedParams);
                    return this.toNormalizedMixedString(mixedParams, zone);
                } else {
                    AddressDivisionGrouping.setCachedParams(options, stringParams);
                }
            } else {
                if(cachedParams != null && cachedParams instanceof <any>IPv6AddressSection.IPv6v4MixedParams) {
                    return this.toNormalizedMixedString(<IPv6AddressSection.IPv6v4MixedParams><any>cachedParams, zone);
                }
                stringParams = <IPv6AddressSection.IPv6StringParams><any>cachedParams;
            }
        } else {
            stringParams = options.from(this);
            if(options.makeMixed() && stringParams.nextUncompressedIndex <= IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex) {
                return this.toNormalizedMixedString(new IPv6AddressSection.IPv6v4MixedParams(stringParams, options.ipv4Opts), zone);
            }
        }
        return stringParams.toString(this, zone);
    }

    public toNormalizedString(options? : any, zone? : any) : any {
        if(((options != null && options instanceof <any>IPv6AddressSection.IPv6StringOptions) || options === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions$java_lang_CharSequence(options, zone);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(options, zone);
        } else if(((options != null && options instanceof <any>IPv6AddressSection.IPv6StringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(options);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && zone === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(options);
        } else if(options === undefined && zone === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public static toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence$inet_ipaddr_format_IPAddressStringDivisionSeries(options : IPAddressSection.IPStringOptions, zone : any, part : IPAddressStringDivisionSeries) : string {
        let params : AddressDivisionGrouping.AddressStringParams<IPAddressStringDivisionSeries> = IPAddressSection.toParams(options);
        let result : string = params.toString(part, zone);
        return result;
    }

    public static toNormalizedString(options? : any, zone? : any, part? : any) : any {
        if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((part != null && (part["__interfaces"] != null && part["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0 || part.constructor != null && part.constructor["__interfaces"] != null && part.constructor["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0)) || part === null)) {
            return <any>IPv6AddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence$inet_ipaddr_format_IPAddressStringDivisionSeries(options, zone, part);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringOptions) || options === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.format.IPAddressStringDivisionSeries") >= 0)) || zone === null) && part === undefined) {
            return <any>IPv6AddressSection.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$inet_ipaddr_format_IPAddressStringDivisionSeries(options, zone);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.STANDARD_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toAllStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toDatabaseSearchStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.DATABASE_SEARCH_OPTS_$LI$());
    }

    public toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.from(options));
    }

    public toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts : IPv6AddressSection.IPv6StringBuilderOptions) : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions$java_lang_CharSequence(opts, null);
    }

    public toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions$java_lang_CharSequence(opts : IPv6AddressSection.IPv6StringBuilderOptions, zone : any) : IPv6AddressSection.IPv6StringCollection {
        let collection : IPv6AddressSection.IPv6StringCollection = new IPv6AddressSection.IPv6StringCollection();
        let mixedCount : number = this.getSegmentCount() - Math.max(IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex, 0);
        if(mixedCount > 0 && opts.includes(IPv6AddressSection.IPv6StringBuilderOptions.MIXED)) {
            let mixed : IPv6AddressSection.IPv6v4MixedAddressSection = this.getMixedAddressSection();
            let mixedBuilder : IPv6StringCollection.IPv6v4MixedStringBuilder = new IPv6StringCollection.IPv6v4MixedStringBuilder(mixed, opts, zone);
            let mixedCollection : IPv6AddressSection.IPv6v4MixedStringCollection = mixedBuilder.getVariations();
            collection.add(mixedCollection);
        }
        if(opts.includes(IPAddressSection.IPStringBuilderOptions.BASIC)) {
            let ipv6Builder : IPv6StringCollection.IPv6StringBuilder = new IPv6StringCollection.IPv6StringBuilder(this, opts, zone);
            let ipv6Collection : IPv6AddressSection.IPv6AddressSectionStringCollection = ipv6Builder.getVariations();
            collection.add(ipv6Collection);
        }
        return collection;
    }

    public toStringCollection(opts? : any, zone? : any) : any {
        if(((opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || opts === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            return <any>this.toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions$java_lang_CharSequence(opts, zone);
        } else if(((opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || opts === null) && zone === undefined) {
            return <any>this.toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null) && zone === undefined) {
            return <any>this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        return this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.from(opts));
    }

    public getParts$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts : IPv6AddressSection.IPv6StringBuilderOptions) : IPAddressStringDivisionSeries[] {
        if(opts.includes(IPv6AddressSection.IPv6StringBuilderOptions.MIXED)) {
            if(opts.includes(IPAddressSection.IPStringBuilderOptions.BASIC)) {
                return [this, this.getMixedAddressSection()];
            }
            return [this.getMixedAddressSection()];
        }
        return super.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
    }

    public getParts(opts? : any) : any {
        if(((opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || opts === null)) {
            return <any>this.getParts$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }

    public getZeroSegments(includeRanges? : any) : any {
        if(((typeof includeRanges === 'boolean') || includeRanges === null)) {
            super.getZeroSegments(includeRanges);
        } else if(includeRanges === undefined) {
            return <any>this.getZeroSegments$();
        } else throw new Error('invalid overload');
    }

    public getZeroSegments$() : IPAddressDivisionGrouping.RangeList {
        if(this.zeroSegments == null) {
            this.zeroSegments = super.getZeroSegments();
        }
        return this.zeroSegments;
    }

    /**
     * 
     * @return {IPAddressDivisionGrouping.RangeList}
     */
    public getZeroRangeSegments() : IPAddressDivisionGrouping.RangeList {
        if(this.zeroRanges == null) {
            this.zeroRanges = super.getZeroRangeSegments();
        }
        return this.zeroRanges;
    }

    /**
     * 
     * @return {boolean}
     */
    public isZero() : boolean {
        let ranges : IPAddressDivisionGrouping.RangeList = this.getZeroSegments();
        return ranges.size() === 1 && ranges.getRange(0).length === this.getSegmentCount();
    }

    getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions(options : IPv6AddressSection.CompressOptions) : number[] {
        return this.getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions$boolean(options, false);
    }

    public getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions$boolean(options : IPv6AddressSection.CompressOptions, createMixed : boolean) : number[] {
        if(options != null) {
            let rangeSelection : CompressOptions.CompressionChoiceOptions = options.rangeSelection;
            let compressibleSegs : IPAddressDivisionGrouping.RangeList = IPv6AddressSection.CompressOptions.CompressionChoiceOptions["_$wrappers"][rangeSelection].compressHost()?this.getZeroRangeSegments():this.getZeroSegments();
            let maxIndex : number = -1;
            let maxCount : number = 0;
            let segmentCount : number = this.getSegmentCount();
            let compressMixed : boolean = createMixed && IPv6AddressSection.CompressOptions.MixedCompressionOptions["_$wrappers"][options.compressMixedOptions].compressMixed(this);
            let preferHost : boolean = (rangeSelection === IPv6AddressSection.CompressOptions.CompressionChoiceOptions.HOST_PREFERRED);
            let preferMixed : boolean = createMixed && (rangeSelection === IPv6AddressSection.CompressOptions.CompressionChoiceOptions.MIXED_PREFERRED);
            for(let i : number = compressibleSegs.size() - 1; i >= 0; i--) {
                let range : IPAddressDivisionGrouping.Range = compressibleSegs.getRange(i);
                let index : number = range.index;
                let count : number = range.length;
                if(createMixed) {
                    let mixedIndex : number = IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - this.addressSegmentIndex;
                    if(!compressMixed || index > mixedIndex || index + count < segmentCount) {
                        count = Math.min(count, mixedIndex - index);
                    }
                }
                if(count > 0 && count >= maxCount && (options.compressSingle || count > 1)) {
                    maxIndex = index;
                    maxCount = count;
                }
                if(preferHost && this.isPrefixed() && ((index + count) * IPv6Address.BITS_PER_SEGMENT) > this.getNetworkPrefixLength()) {
                    break;
                }
                if(preferMixed && index + count >= segmentCount) {
                    break;
                }
            };
            if(maxIndex >= 0) {
                return [maxIndex, maxCount];
            }
        }
        return null;
    }

    /**
     * Chooses a single segment to be compressed, or null if no segment could be chosen.
     * @param {IPv6AddressSection.CompressOptions} options
     * @param {boolean} createMixed
     * @return
     * @return {Array}
     * @private
     */
    public getCompressIndexAndCount(options? : any, createMixed? : any) : any {
        if(((options != null && options instanceof <any>IPv6AddressSection.CompressOptions) || options === null) && ((typeof createMixed === 'boolean') || createMixed === null)) {
            return <any>this.getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions$boolean(options, createMixed);
        } else if(((options != null && options instanceof <any>IPv6AddressSection.CompressOptions) || options === null) && createMixed === undefined) {
            return <any>this.getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions(options);
        } else throw new Error('invalid overload');
    }
}
IPv6AddressSection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection";
IPv6AddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



export namespace IPv6AddressSection {

    export class IPv6StringCache extends IPAddressSection.IPStringCache {
        static __static_initialized : boolean = false;
        static __static_initialize() { if(!IPv6StringCache.__static_initialized) { IPv6StringCache.__static_initialized = true; IPv6StringCache.__static_initializer_0(); } }

        static mixedParams : IPv6AddressSection.IPv6StringOptions; public static mixedParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.mixedParams; };

        static fullParams : IPv6AddressSection.IPv6StringOptions; public static fullParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.fullParams; };

        static normalizedParams : IPv6AddressSection.IPv6StringOptions; public static normalizedParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.normalizedParams; };

        static canonicalParams : IPv6AddressSection.IPv6StringOptions; public static canonicalParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.canonicalParams; };

        static uncParams : IPv6AddressSection.IPv6StringOptions; public static uncParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.uncParams; };

        static compressedParams : IPv6AddressSection.IPv6StringOptions; public static compressedParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.compressedParams; };

        static wildcardNormalizedParams : IPv6AddressSection.IPv6StringOptions; public static wildcardNormalizedParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.wildcardNormalizedParams; };

        static wildcardCanonicalParams : IPv6AddressSection.IPv6StringOptions; public static wildcardCanonicalParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.wildcardCanonicalParams; };

        static sqlWildcardParams : IPv6AddressSection.IPv6StringOptions; public static sqlWildcardParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.sqlWildcardParams; };

        static wildcardCompressedParams : IPv6AddressSection.IPv6StringOptions; public static wildcardCompressedParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.wildcardCompressedParams; };

        static networkPrefixLengthParams : IPv6AddressSection.IPv6StringOptions; public static networkPrefixLengthParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.networkPrefixLengthParams; };

        static reverseDNSParams : IPv6AddressSection.IPv6StringOptions; public static reverseDNSParams_$LI$() : IPv6AddressSection.IPv6StringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.reverseDNSParams; };

        static base85Params : IPAddressSection.IPStringOptions; public static base85Params_$LI$() : IPAddressSection.IPStringOptions { IPv6StringCache.__static_initialize(); return IPv6StringCache.base85Params; };

        static __static_initializer_0() {
            let compressAll : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST);
            let compressMixed : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.MIXED_PREFERRED);
            let compressAllNoSingles : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(false, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS_OR_HOST);
            let compressHostPreferred : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.HOST_PREFERRED);
            let compressZeros : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(true, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS);
            let compressZerosNoSingles : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(false, IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS);
            IPv6StringCache.mixedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setMakeMixed(true).setCompressOptions(compressMixed).toOptions();
            IPv6StringCache.fullParams = new IPv6AddressSection.IPv6StringOptions.Builder().setExpandedSegments(true).setWildcardOptions(new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.NETWORK_ONLY, new StringOptions.Wildcards(IPAddress.RANGE_SEPARATOR_STR))).toOptions();
            IPv6StringCache.canonicalParams = new IPv6AddressSection.IPv6StringOptions.Builder().setCompressOptions(compressAllNoSingles).toOptions();
            IPv6StringCache.uncParams = new IPv6AddressSection.IPv6StringOptions.Builder().setSeparator(IPv6Address.UNC_SEGMENT_SEPARATOR).setZoneSeparator(IPv6Address.UNC_ZONE_SEPARATOR).setAddressSuffix(IPv6Address.UNC_SUFFIX).setWildcardOptions(new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.NETWORK_ONLY, new StringOptions.Wildcards(IPv6Address.UNC_RANGE_SEPARATOR_STR, IPAddress.SEGMENT_WILDCARD_STR, null))).toOptions();
            IPv6StringCache.compressedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setCompressOptions(compressAll).toOptions();
            IPv6StringCache.normalizedParams = new IPv6AddressSection.IPv6StringOptions.Builder().toOptions();
            let allWildcards : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.ALL);
            let allSQLWildcards : IPAddressSection.WildcardOptions = new IPAddressSection.WildcardOptions(IPAddressSection.WildcardOptions.WildcardOption.ALL, new StringOptions.Wildcards(IPAddress.SEGMENT_SQL_WILDCARD_STR_$LI$(), IPAddress.SEGMENT_SQL_SINGLE_WILDCARD_STR_$LI$()));
            IPv6StringCache.wildcardCanonicalParams = new IPv6AddressSection.IPv6StringOptions.Builder().setWildcardOptions(allWildcards).setCompressOptions(compressZerosNoSingles).toOptions();
            IPv6StringCache.wildcardNormalizedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setWildcardOptions(allWildcards).toOptions();
            IPv6StringCache.sqlWildcardParams = new IPv6AddressSection.IPv6StringOptions.Builder().setWildcardOptions(allSQLWildcards).toOptions();
            IPv6StringCache.wildcardCompressedParams = new IPv6AddressSection.IPv6StringOptions.Builder().setWildcardOptions(allWildcards).setCompressOptions(compressZeros).toOptions();
            IPv6StringCache.networkPrefixLengthParams = new IPv6AddressSection.IPv6StringOptions.Builder().setCompressOptions(compressHostPreferred).toOptions();
            IPv6StringCache.reverseDNSParams = new IPv6AddressSection.IPv6StringOptions.Builder().setReverse(true).setAddressSuffix(IPv6Address.REVERSE_DNS_SUFFIX).setSplitDigits(true).setExpandedSegments(true).setSeparator('.').toOptions();
            IPv6StringCache.base85Params = new IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder(85).setExpandedSegments(true).setWildcards(new StringOptions.Wildcards(Address.ALTERNATIVE_RANGE_SEPARATOR_STR)).setZoneSeparator(IPv6Address.ALTERNATIVE_ZONE_SEPARATOR).toOptions();
        }

        public normalizedString : string;

        public compressedString : string;

        public mixedString : string;

        public compressedWildcardString : string;

        public canonicalWildcardString : string;

        public networkPrefixLengthString : string;

        public base85String : string;

        public uncString : string;

        constructor() {
            super();
            if(this.normalizedString===undefined) this.normalizedString = null;
            if(this.compressedString===undefined) this.compressedString = null;
            if(this.mixedString===undefined) this.mixedString = null;
            if(this.compressedWildcardString===undefined) this.compressedWildcardString = null;
            if(this.canonicalWildcardString===undefined) this.canonicalWildcardString = null;
            if(this.networkPrefixLengthString===undefined) this.networkPrefixLengthString = null;
            if(this.base85String===undefined) this.base85String = null;
            if(this.uncString===undefined) this.uncString = null;
        }
    }
    IPv6StringCache["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringCache";


    export class AddressCache extends AddressDivisionGrouping.SectionCache<IPv6Address> {
        constructor() {
            super();
        }
    }
    AddressCache["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.AddressCache";


    export class IPv6StringMatcher extends SQLStringMatcher<IPv6AddressSection, IPv6AddressSection.IPv6StringParams, IPv6AddressSection.IPv6AddressSectionString> {
        constructor(networkString : IPv6AddressSection.IPv6AddressSectionString, translator : IPAddressSQLTranslator) {
            super(networkString, networkString.addr.isEntireAddress(), translator);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {string} columnName
         * @return {{ str: string }}
         */
        public getSQLCondition(builder : { str: string }, columnName : string) : { str: string } {
            if(this.networkString.addr.isEntireAddress()) {
                this.matchString(builder, columnName, this.networkString.getString());
            } else if(this.networkString.endIsCompressed()) {
                let sep : string = this.networkString.getTrailingSegmentSeparator();
                let searchStr : string = this.networkString.getString().substring(0, this.networkString.getString().length - 1);
                /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
                this.matchSubString(builder, columnName, sep, this.networkString.getTrailingSeparatorCount(), searchStr);
                let extraSeparatorCountMax : number = (IPv6Address.SEGMENT_COUNT - 1) - this.networkString.addr.getSegmentCount();
                /* append */(sb => { sb.str = sb.str.concat(<any>") AND ("); return sb; })(builder);
                this.boundSeparatorCount(builder, columnName, sep, extraSeparatorCountMax + this.networkString.getTrailingSeparatorCount());
                /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
            } else if(this.networkString.isCompressed()) {
                let sep : string = this.networkString.getTrailingSegmentSeparator();
                /* append */(sb => { sb.str = sb.str.concat(<any>'('); return sb; })(builder);
                this.matchSubString(builder, columnName, sep, this.networkString.getTrailingSeparatorCount() + 1, this.networkString.getString());
                let extraSeparatorCount : number = IPv6Address.SEGMENT_COUNT - this.networkString.addr.getSegmentCount();
                /* append */(sb => { sb.str = sb.str.concat(<any>") AND ("); return sb; })(builder);
                this.matchSeparatorCount(builder, columnName, sep, extraSeparatorCount + this.networkString.getTrailingSeparatorCount());
                /* append */(sb => { sb.str = sb.str.concat(<any>')'); return sb; })(builder);
            } else {
                this.matchSubString(builder, columnName, this.networkString.getTrailingSegmentSeparator(), this.networkString.getTrailingSeparatorCount() + 1, this.networkString.getString());
            }
            return builder;
        }
    }
    IPv6StringMatcher["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringMatcher";


    export class CompressOptions {
        public compressSingle : boolean;

        public rangeSelection : CompressOptions.CompressionChoiceOptions;

        public compressMixedOptions : CompressOptions.MixedCompressionOptions;

        public constructor(compressSingle? : any, rangeSelection? : any, compressMixedOptions? : any) {
            if(((typeof compressSingle === 'boolean') || compressSingle === null) && ((typeof rangeSelection === 'number') || rangeSelection === null) && ((typeof compressMixedOptions === 'number') || compressMixedOptions === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.compressSingle===undefined) this.compressSingle = false;
                if(this.rangeSelection===undefined) this.rangeSelection = null;
                if(this.compressMixedOptions===undefined) this.compressMixedOptions = null;
                if(this.compressSingle===undefined) this.compressSingle = false;
                if(this.rangeSelection===undefined) this.rangeSelection = null;
                if(this.compressMixedOptions===undefined) this.compressMixedOptions = null;
                (() => {
                    this.compressSingle = compressSingle;
                    this.rangeSelection = rangeSelection;
                    this.compressMixedOptions = compressMixedOptions == null?CompressOptions.MixedCompressionOptions.YES:compressMixedOptions;
                })();
            } else if(((typeof compressSingle === 'boolean') || compressSingle === null) && ((typeof rangeSelection === 'number') || rangeSelection === null) && compressMixedOptions === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let compressMixedOptions : any = CompressOptions.MixedCompressionOptions.YES;
                    if(this.compressSingle===undefined) this.compressSingle = false;
                    if(this.rangeSelection===undefined) this.rangeSelection = null;
                    if(this.compressMixedOptions===undefined) this.compressMixedOptions = null;
                    if(this.compressSingle===undefined) this.compressSingle = false;
                    if(this.rangeSelection===undefined) this.rangeSelection = null;
                    if(this.compressMixedOptions===undefined) this.compressMixedOptions = null;
                    (() => {
                        this.compressSingle = compressSingle;
                        this.rangeSelection = rangeSelection;
                        this.compressMixedOptions = compressMixedOptions == null?CompressOptions.MixedCompressionOptions.YES:compressMixedOptions;
                    })();
                }
            } else throw new Error('invalid overload');
        }
    }
    CompressOptions["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.CompressOptions";


    export namespace CompressOptions {

        export enum CompressionChoiceOptions {
            HOST_PREFERRED, MIXED_PREFERRED, ZEROS_OR_HOST, ZEROS
        }

        /** @ignore */
        export class CompressionChoiceOptions_$WRAPPER {
            constructor(protected _$ordinal : number, protected _$name : string) {
            }

            compressHost() : boolean {
                return this._$ordinal !== CompressionChoiceOptions.ZEROS;
            }
            public name() : string { return this._$name; }
            public ordinal() : number { return this._$ordinal; }
        }
        CompressionChoiceOptions["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.CompressOptions.CompressionChoiceOptions";
        CompressionChoiceOptions["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

        CompressionChoiceOptions["_$wrappers"] = [new CompressionChoiceOptions_$WRAPPER(0, "HOST_PREFERRED"), new CompressionChoiceOptions_$WRAPPER(1, "MIXED_PREFERRED"), new CompressionChoiceOptions_$WRAPPER(2, "ZEROS_OR_HOST"), new CompressionChoiceOptions_$WRAPPER(3, "ZEROS")];


        export enum MixedCompressionOptions {
            NO, NO_HOST, COVERED_BY_HOST, YES
        }

        /** @ignore */
        export class MixedCompressionOptions_$WRAPPER {
            constructor(protected _$ordinal : number, protected _$name : string) {
            }

            compressMixed(addressSection) : boolean {
                switch((this._$ordinal)) {
                default:
                case IPv6AddressSection.CompressOptions.MixedCompressionOptions.YES:
                    return true;
                case IPv6AddressSection.CompressOptions.MixedCompressionOptions.NO:
                    return false;
                case IPv6AddressSection.CompressOptions.MixedCompressionOptions.NO_HOST:
                    return !addressSection.isPrefixed();
                case IPv6AddressSection.CompressOptions.MixedCompressionOptions.COVERED_BY_HOST:
                    if(addressSection.isPrefixed()) {
                        let mixedDistance = IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT - addressSection.addressSegmentIndex;
                        let mixedCount = addressSection.getSegmentCount() - Math.max(mixedDistance, 0);
                        if(mixedCount > 0) {
                            return (mixedDistance * addressSection.getBitsPerSegment()) >= addressSection.getNetworkPrefixLength();
                        }
                    }
                    return true;
                }
            }
            public name() : string { return this._$name; }
            public ordinal() : number { return this._$ordinal; }
        }
        MixedCompressionOptions["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.CompressOptions.MixedCompressionOptions";
        MixedCompressionOptions["__interfaces"] = ["java.lang.Comparable","java.io.Serializable"];

        MixedCompressionOptions["_$wrappers"] = [new MixedCompressionOptions_$WRAPPER(0, "NO"), new MixedCompressionOptions_$WRAPPER(1, "NO_HOST"), new MixedCompressionOptions_$WRAPPER(2, "COVERED_BY_HOST"), new MixedCompressionOptions_$WRAPPER(3, "YES")];

    }


    /**
     * Provides a clear way to create a specific type of string.
     * 
     * @author sfoley
     * @extends IPAddressSection.IPStringOptions
     * @class
     */
    export class IPv6StringOptions extends IPAddressSection.IPStringOptions {
        public ipv4Opts : IPAddressSection.IPStringOptions;

        public compressOptions : IPv6AddressSection.CompressOptions;

        constructor(base : number, expandSegments : boolean, wildcardOption : WildcardOptions.WildcardOption, wildcards : StringOptions.Wildcards, segmentStrPrefix : string, makeMixed : boolean, ipv4Opts : IPAddressSection.IPStringOptions, compressOptions : IPv6AddressSection.CompressOptions, separator : string, zoneSeparator : string, addressPrefix : string, addressSuffix : string, reverse : boolean, splitDigits : boolean, uppercase : boolean) {
            super(base, expandSegments, wildcardOption, wildcards, segmentStrPrefix, separator, zoneSeparator, addressPrefix, addressSuffix, reverse, splitDigits, uppercase);
            if(this.ipv4Opts===undefined) this.ipv4Opts = null;
            if(this.compressOptions===undefined) this.compressOptions = null;
            this.compressOptions = compressOptions;
            if(makeMixed) {
                if(ipv4Opts == null) {
                    ipv4Opts = new IPv4AddressSection.IPv4StringOptions.Builder().setExpandedSegments(expandSegments).setWildcardOption(wildcardOption).setWildcards(wildcards).toOptions();
                }
                this.ipv4Opts = ipv4Opts;
            } else {
                this.ipv4Opts = null;
            }
        }

        isCacheable() : boolean {
            return this.compressOptions == null;
        }

        makeMixed() : boolean {
            return this.ipv4Opts != null;
        }

        from(addr : IPv6AddressSection) : IPv6AddressSection.IPv6StringParams {
            let result : IPv6AddressSection.IPv6StringParams = new IPv6AddressSection.IPv6StringParams();
            if(this.compressOptions != null) {
                let makeMixed : boolean = this.makeMixed();
                let vals : number[] = addr.getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions$boolean(this.compressOptions, makeMixed);
                if(vals != null) {
                    let maxIndex : number = vals[0];
                    let maxCount : number = vals[1];
                    result.firstCompressedSegmentIndex = maxIndex;
                    result.nextUncompressedIndex = maxIndex + maxCount;
                    result.hostCompressed = IPv6AddressSection.CompressOptions.CompressionChoiceOptions["_$wrappers"][this.compressOptions.rangeSelection].compressHost() && addr.isPrefixed() && (result.nextUncompressedIndex > IPAddressSection.getHostSegmentIndex(addr.getNetworkPrefixLength(), IPv6Address.BYTE_COUNT, IPv6Address.BYTES_PER_SEGMENT));
                }
            }
            result.expandSegments(this.expandSegments);
            result.setWildcardOption(this.wildcardOption);
            result.setWildcards(this.wildcards);
            result.setSeparator(this.separator);
            result.setAddressSuffix(this.addrSuffix);
            result.setAddressLabel(this.addrLabel);
            result.setReverse(this.reverse);
            result.setSplitDigits(this.splitDigits);
            result.setZoneSeparator(this.zoneSeparator);
            result.setUppercase(this.uppercase);
            result.setRadix(this.base);
            result.setSegmentStrPrefix(this.segmentStrPrefix);
            return result;
        }

        public static from(opts : IPAddressSection.IPStringOptions) : IPv6AddressSection.IPv6StringOptions {
            if(opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringOptions) {
                return <IPv6AddressSection.IPv6StringOptions>opts;
            }
            return new IPv6AddressSection.IPv6StringOptions(opts.base, opts.expandSegments, opts.wildcardOption, opts.wildcards, opts.segmentStrPrefix, false, null, null, opts.separator, IPv6Address.ZONE_SEPARATOR, opts.addrLabel, opts.addrSuffix, opts.reverse, opts.splitDigits, opts.uppercase);
        }
    }
    IPv6StringOptions["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringOptions";


    export namespace IPv6StringOptions {

        export class Builder extends IPAddressSection.IPStringOptions.__inet_ipaddr_IPAddressSection_IPStringOptions_Builder {
            makeMixed : boolean;

            ipv4Options : IPAddressSection.IPStringOptions;

            compressOptions : IPv6AddressSection.CompressOptions;

            public constructor() {
                super(IPv6Address.DEFAULT_TEXTUAL_RADIX, IPv6Address.SEGMENT_SEPARATOR);
                if(this.makeMixed===undefined) this.makeMixed = false;
                if(this.ipv4Options===undefined) this.ipv4Options = null;
                if(this.compressOptions===undefined) this.compressOptions = null;
            }

            public setCompressOptions(compressOptions : IPv6AddressSection.CompressOptions) : IPv6StringOptions.Builder {
                this.compressOptions = compressOptions;
                return this;
            }

            public setMakeMixed$boolean(makeMixed : boolean) : IPv6StringOptions.Builder {
                this.makeMixed = makeMixed;
                return this;
            }

            public setMakeMixed$inet_ipaddr_IPAddressSection_IPStringOptions(ipv4Options : IPAddressSection.IPStringOptions) : IPv6StringOptions.Builder {
                this.makeMixed = true;
                this.ipv4Options = ipv4Options;
                return this;
            }

            public setMakeMixed(ipv4Options? : any) : any {
                if(((ipv4Options != null && ipv4Options instanceof <any>IPAddressSection.IPStringOptions) || ipv4Options === null)) {
                    return <any>this.setMakeMixed$inet_ipaddr_IPAddressSection_IPStringOptions(ipv4Options);
                } else if(((typeof ipv4Options === 'boolean') || ipv4Options === null)) {
                    return <any>this.setMakeMixed$boolean(ipv4Options);
                } else throw new Error('invalid overload');
            }

            /**
             * 
             * @param {IPAddressSection.WildcardOptions} wildcardOptions
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setWildcardOptions(wildcardOptions : IPAddressSection.WildcardOptions) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setWildcardOptions(wildcardOptions);
            }

            /**
             * 
             * @param {boolean} expandSegments
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setExpandedSegments(expandSegments : boolean) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setExpandedSegments(expandSegments);
            }

            /**
             * 
             * @param {number} base
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setRadix(base : number) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setRadix(base);
            }

            /**
             * 
             * @param {string} separator
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setSeparator(separator : string) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setSeparator(separator);
            }

            /**
             * 
             * @param {string} separator
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setZoneSeparator(separator : string) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setZoneSeparator(separator);
            }

            /**
             * 
             * @param {string} suffix
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setAddressSuffix(suffix : string) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setAddressSuffix(suffix);
            }

            /**
             * 
             * @param {string} prefix
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setSegmentStrPrefix(prefix : string) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setSegmentStrPrefix(prefix);
            }

            /**
             * 
             * @param {boolean} reverse
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setReverse(reverse : boolean) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setReverse(reverse);
            }

            /**
             * 
             * @param {boolean} upper
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setUppercase(upper : boolean) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setUppercase(upper);
            }

            /**
             * 
             * @param {boolean} splitDigits
             * @return {IPv6AddressSection.IPv6StringOptions.Builder}
             */
            public setSplitDigits(splitDigits : boolean) : IPv6StringOptions.Builder {
                return <IPv6StringOptions.Builder>super.setSplitDigits(splitDigits);
            }

            /**
             * 
             * @return {IPv6AddressSection.IPv6StringOptions}
             */
            public toOptions() : IPv6AddressSection.IPv6StringOptions {
                return new IPv6AddressSection.IPv6StringOptions(this.base, this.expandSegments, this.wildcardOption, this.wildcards, this.segmentStrPrefix, this.makeMixed, this.ipv4Options, this.compressOptions, this.separator, this.zoneSeparator, this.addrLabel, this.addrSuffix, this.reverse, this.splitDigits, this.uppercase);
            }
        }
        Builder["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringOptions.Builder";

    }


    /**
     * Each IPv6StringParams has settings to write exactly one IPv6 address section string
     * 
     * @author sfoley
     * @extends IPAddressDivisionGrouping.IPAddressStringParams
     * @class
     */
    export class IPv6StringParams extends IPAddressDivisionGrouping.IPAddressStringParams<IPv6AddressSection> {
        firstCompressedSegmentIndex : number;

        nextUncompressedIndex : number;

        hostCompressed : boolean;

        public constructor(expandSegments? : any, firstCompressedSegmentIndex? : any, compressedCount? : any, uppercase? : any, separator? : any, zoneSeparator? : any) {
            if(((typeof expandSegments === 'boolean') || expandSegments === null) && ((typeof firstCompressedSegmentIndex === 'number') || firstCompressedSegmentIndex === null) && ((typeof compressedCount === 'number') || compressedCount === null) && ((typeof uppercase === 'boolean') || uppercase === null) && ((typeof separator === 'string') || separator === null) && ((typeof zoneSeparator === 'string') || zoneSeparator === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(IPv6Address.DEFAULT_TEXTUAL_RADIX, separator, uppercase, zoneSeparator);
                if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                if(this.hostCompressed===undefined) this.hostCompressed = false;
                if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                if(this.hostCompressed===undefined) this.hostCompressed = false;
                (() => {
                    this.expandSegments(expandSegments);
                    this.firstCompressedSegmentIndex = firstCompressedSegmentIndex;
                    this.nextUncompressedIndex = firstCompressedSegmentIndex + compressedCount;
                })();
            } else if(((typeof expandSegments === 'number') || expandSegments === null) && ((typeof firstCompressedSegmentIndex === 'number') || firstCompressedSegmentIndex === null) && compressedCount === undefined && uppercase === undefined && separator === undefined && zoneSeparator === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                let firstCompressedSegmentIndex : any = __args[0];
                let compressedCount : any = __args[1];
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let expandSegments : any = false;
                    let uppercase : any = false;
                    let separator : any = IPv6Address.SEGMENT_SEPARATOR;
                    let zoneSeparator : any = IPv6Address.ZONE_SEPARATOR;
                    super(IPv6Address.DEFAULT_TEXTUAL_RADIX, separator, uppercase, zoneSeparator);
                    if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                    if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                    if(this.hostCompressed===undefined) this.hostCompressed = false;
                    if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                    if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                    if(this.hostCompressed===undefined) this.hostCompressed = false;
                    (() => {
                        this.expandSegments(expandSegments);
                        this.firstCompressedSegmentIndex = firstCompressedSegmentIndex;
                        this.nextUncompressedIndex = firstCompressedSegmentIndex + compressedCount;
                    })();
                }
            } else if(expandSegments === undefined && firstCompressedSegmentIndex === undefined && compressedCount === undefined && uppercase === undefined && separator === undefined && zoneSeparator === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let firstCompressedSegmentIndex : any = -1;
                    let compressedCount : any = 0;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let expandSegments : any = false;
                        let uppercase : any = false;
                        let separator : any = IPv6Address.SEGMENT_SEPARATOR;
                        let zoneSeparator : any = IPv6Address.ZONE_SEPARATOR;
                        super(IPv6Address.DEFAULT_TEXTUAL_RADIX, separator, uppercase, zoneSeparator);
                        if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                        if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                        if(this.hostCompressed===undefined) this.hostCompressed = false;
                        if(this.firstCompressedSegmentIndex===undefined) this.firstCompressedSegmentIndex = 0;
                        if(this.nextUncompressedIndex===undefined) this.nextUncompressedIndex = 0;
                        if(this.hostCompressed===undefined) this.hostCompressed = false;
                        (() => {
                            this.expandSegments(expandSegments);
                            this.firstCompressedSegmentIndex = firstCompressedSegmentIndex;
                            this.nextUncompressedIndex = firstCompressedSegmentIndex + compressedCount;
                        })();
                    }
                }
            } else throw new Error('invalid overload');
        }

        public endIsCompressed(addr : IPAddressStringDivisionSeries) : boolean {
            return this.nextUncompressedIndex >= addr.getDivisionCount();
        }

        public isCompressed(addr : IPAddressStringDivisionSeries) : boolean {
            return this.firstCompressedSegmentIndex >= 0;
        }

        public getTrailingSeparatorCount$inet_ipaddr_ipv6_IPv6AddressSection(addr : IPv6AddressSection) : number {
            return this.getTrailingSepCount(addr);
        }

        /**
         * 
         * @param {IPv6AddressSection} addr
         * @return {number}
         */
        public getTrailingSeparatorCount(addr? : any) : any {
            if(((addr != null && addr instanceof <any>IPv6AddressSection) || addr === null)) {
                return <any>this.getTrailingSeparatorCount$inet_ipaddr_ipv6_IPv6AddressSection(addr);
            } else if(((addr != null) || addr === null)) {
                return <any>this.getTrailingSeparatorCount$inet_ipaddr_format_IPAddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public getTrailingSepCount(addr : IPAddressStringDivisionSeries) : number {
            let divisionCount : number = addr.getDivisionCount();
            if(divisionCount === 0) {
                return 0;
            }
            let count : number = divisionCount - 1;
            if(this.isCompressed(addr)) {
                count -= (this.nextUncompressedIndex - this.firstCompressedSegmentIndex) - 1;
                if(this.firstCompressedSegmentIndex === 0 || this.nextUncompressedIndex >= divisionCount) {
                    count++;
                }
            }
            return count;
        }

        public getStringLength(addr? : any, zone? : any) : any {
            if(((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                super.getStringLength(addr, zone);
            } else if(((addr != null && addr instanceof <any>IPv6AddressSection) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_ipv6_IPv6AddressSection(addr);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_format_IPAddressStringDivisionSeries(addr);
            } else if(((addr != null) || addr === null) && zone === undefined) {
                return <any>this.getStringLength$inet_ipaddr_format_AddressStringDivisionSeries(addr);
            } else throw new Error('invalid overload');
        }

        public getStringLength$inet_ipaddr_ipv6_IPv6AddressSection(addr : IPv6AddressSection) : number {
            let count : number = this.getSegmentsStringLength$inet_ipaddr_ipv6_IPv6AddressSection(addr);
            if(!this.isReverse() && (!this.preferWildcards() || this.hostCompressed)) {
                count += IPAddressStringParams.getPrefixIndicatorStringLength(addr);
            }
            count += this.getAddressSuffixLength();
            count += this.getAddressLabelLength();
            return count;
        }

        public append$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(builder : { str: string }, addr : IPv6AddressSection, zone : any) : { str: string } {
            this.appendSuffix(this.appendZone(this.appendSegments$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection(this.appendLabel(builder), addr), zone));
            if(!this.isReverse() && (!this.preferWildcards() || this.hostCompressed)) {
                this.appendPrefixIndicator(builder, addr);
            }
            return builder;
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {IPv6AddressSection} addr
         * @param {*} zone
         * @return {{ str: string }}
         */
        public append(builder? : any, addr? : any, zone? : any) : any {
            if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null && addr instanceof <any>IPv6AddressSection) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_IPAddressStringDivisionSeries$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries$java_lang_CharSequence(builder, addr, zone);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null) && zone === undefined) {
                return <any>this.append$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder, addr);
            } else throw new Error('invalid overload');
        }

        public appendSegments$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection(builder : { str: string }, addr : IPv6AddressSection) : { str: string } {
            let divisionCount : number = addr.getDivisionCount();
            if(divisionCount <= 0) {
                return builder;
            }
            let lastIndex : number = divisionCount - 1;
            let separator : string = this.getSeparator();
            let reverse : boolean = this.isReverse();
            let i : number = 0;
            while((true)) {
                let segIndex : number = reverse?lastIndex - i:i;
                if(segIndex < this.firstCompressedSegmentIndex || segIndex >= this.nextUncompressedIndex) {
                    this.appendSegment(segIndex, builder, addr);
                    if(++i > lastIndex) {
                        break;
                    }
                    if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(builder);
                    }
                } else {
                    if(segIndex === (reverse?this.nextUncompressedIndex - 1:this.firstCompressedSegmentIndex) && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                        /* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(builder);
                        if(i === 0) {
                            /* append */(sb => { sb.str = sb.str.concat(<any>separator); return sb; })(builder);
                        }
                    }
                    if(++i > lastIndex) {
                        break;
                    }
                }
            };
            return builder;
        }

        /**
         * @see inet.ipaddr.format.util.IPAddressPartStringCollection.IPAddressStringParams#appendSegments(java.lang.StringBuilder, inet.ipaddr.format.IPAddressStringDivisionSeries)
         * @param {{ str: string }} builder
         * @param {IPv6AddressSection} addr
         * @return {{ str: string }}
         */
        public appendSegments(builder? : any, addr? : any) : any {
            if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null && addr instanceof <any>IPv6AddressSection) || addr === null)) {
                return <any>this.appendSegments$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection(builder, addr);
            } else if(((builder != null && (builder instanceof Object)) || builder === null) && ((addr != null) || addr === null)) {
                return <any>this.appendSegments$java_lang_StringBuilder$inet_ipaddr_format_AddressStringDivisionSeries(builder, addr);
            } else throw new Error('invalid overload');
        }

        public getSegmentsStringLength$inet_ipaddr_ipv6_IPv6AddressSection(part : IPv6AddressSection) : number {
            let count : number = 0;
            let divCount : number = part.getDivisionCount();
            if(divCount !== 0) {
                let separator : string = this.getSeparator();
                let i : number = 0;
                while((true)) {
                    if(i < this.firstCompressedSegmentIndex || i >= this.nextUncompressedIndex) {
                        count += this.appendSegment(i, null, part);
                        if(++i >= divCount) {
                            break;
                        }
                        if((c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                            count++;
                        }
                    } else {
                        if(i === this.firstCompressedSegmentIndex && (c => c.charCodeAt==null?<any>c:c.charCodeAt(0))(separator) != null) {
                            count++;
                            if(i === 0) {
                                count++;
                            }
                        }
                        if(++i >= divCount) {
                            break;
                        }
                    }
                };
            }
            return count;
        }

        /**
         * 
         * @param {IPv6AddressSection} part
         * @return {number}
         */
        public getSegmentsStringLength(part? : any) : any {
            if(((part != null && part instanceof <any>IPv6AddressSection) || part === null)) {
                return <any>this.getSegmentsStringLength$inet_ipaddr_ipv6_IPv6AddressSection(part);
            } else if(((part != null) || part === null)) {
                return <any>this.getSegmentsStringLength$inet_ipaddr_format_AddressStringDivisionSeries(part);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {IPv6AddressSection.IPv6StringParams}
         */
        public clone() : IPv6AddressSection.IPv6StringParams {
            return <IPv6AddressSection.IPv6StringParams>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
        }
    }
    IPv6StringParams["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringParams";
    IPv6StringParams["__interfaces"] = ["inet.ipaddr.format.util.AddressDivisionWriter","inet.ipaddr.format.util.AddressSegmentParams","java.lang.Cloneable","inet.ipaddr.format.util.IPAddressStringWriter"];



    export class EmbeddedIPv6AddressSection extends IPv6AddressSection {
        static serialVersionUID : number = 4;

        encompassingSection : IPAddressSection;

        constructor(encompassingSection : IPAddressSection, subSegments : IPv6AddressSegment[], startIndex : number) {
            super(subSegments, startIndex, false);
            if(this.encompassingSection===undefined) this.encompassingSection = null;
            this.encompassingSection = encompassingSection;
        }

        /**
         * 
         * @return {boolean}
         */
        public isPrefixBlock() : boolean {
            return this.encompassingSection.isPrefixBlock();
        }
    }
    EmbeddedIPv6AddressSection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.EmbeddedIPv6AddressSection";
    EmbeddedIPv6AddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","inet.ipaddr.format.IPAddressStringDivisionSeries","java.lang.Comparable","inet.ipaddr.AddressSection","java.lang.Iterable","java.io.Serializable"];



    export class IPv6v4MixedAddressSection extends IPAddressDivisionGrouping {
        static serialVersionUID : number = 4;

        ipv6Section : IPv6AddressSection;

        ipv4Section : IPv4AddressSection;

        string : string;

        constructor(ipv6Section : IPv6AddressSection, ipv4Section : IPv4AddressSection) {
            super(IPv6v4MixedAddressSection.createSegments$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_ipv4_IPv4AddressSection(ipv6Section, ipv4Section), ipv6Section.getNetwork());
            if(this.ipv6Section===undefined) this.ipv6Section = null;
            if(this.ipv4Section===undefined) this.ipv4Section = null;
            if(this.string===undefined) this.string = null;
            if(ipv6Section.isPrefixed()) {
                if(!ipv4Section.isPrefixed() || ipv4Section.getNetworkPrefixLength() !== 0) {
                    throw new InconsistentPrefixException(ipv6Section, ipv4Section, ipv4Section.getNetworkPrefixLength());
                }
                this.cachedPrefixLength = ipv6Section.getNetworkPrefixLength();
            } else if(ipv4Section.isPrefixed()) {
                this.cachedPrefixLength = ipv4Section.getNetworkPrefixLength() + ipv6Section.getBitCount();
            } else {
                this.cachedPrefixLength = AddressDivisionGrouping.NO_PREFIX_LENGTH;
            }
            this.ipv4Section = ipv4Section;
            this.ipv6Section = ipv6Section;
        }

        public static createSegments<S extends AddressSegment>(segments? : any, lowerValueProvider? : any, upperValueProvider? : any, bytesPerSegment? : any, bitsPerSegment? : any, network? : any, prefixLength? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((network != null && network instanceof <any>AddressNetwork) || network === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
                super.createSegments(segments, lowerValueProvider, upperValueProvider, bytesPerSegment, bitsPerSegment, network, prefixLength);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof lowerValueProvider === 'number') || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((bitsPerSegment != null && bitsPerSegment instanceof <any>AddressNetwork) || bitsPerSegment === null) && ((typeof network === 'number') || network === null) && prefixLength === undefined) {
                return <any>IPv6AddressSection.IPv6v4MixedAddressSection.createSegments$inet_ipaddr_AddressSegment_A$long$long$int$inet_ipaddr_AddressNetwork$java_lang_Integer(segments, lowerValueProvider, upperValueProvider, bytesPerSegment, bitsPerSegment, network);
            } else if(((segments != null && segments instanceof <any>IPv6AddressSection) || segments === null) && ((lowerValueProvider != null && lowerValueProvider instanceof <any>IPv4AddressSection) || lowerValueProvider === null) && upperValueProvider === undefined && bytesPerSegment === undefined && bitsPerSegment === undefined && network === undefined && prefixLength === undefined) {
                return <any>IPv6AddressSection.IPv6v4MixedAddressSection.createSegments$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_ipv4_IPv4AddressSection(segments, lowerValueProvider);
            } else throw new Error('invalid overload');
        }

        static createSegments$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_ipv4_IPv4AddressSection(ipv6Section : IPv6AddressSection, ipv4Section : IPv4AddressSection) : IPAddressDivision[] {
            let ipv6Len : number = ipv6Section.getSegmentCount();
            let ipv4Len : number = ipv4Section.getSegmentCount();
            if(ipv6Len + ((ipv4Len + 1) >> 1) + ipv6Section.addressSegmentIndex > IPv6Address.SEGMENT_COUNT) {
                throw new AddressValueException(ipv6Section, ipv4Section);
            }
            let allSegs : IPAddressSegment[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(ipv6Len + ipv4Len);
            ipv6Section.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, ipv6Len, allSegs, 0);
            ipv4Section.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, ipv4Len, allSegs, ipv6Len);
            return allSegs;
        }

        public getByteCount() : number {
            return this.ipv6Section.getByteCount() + this.ipv4Section.getByteCount();
        }

        /**
         * 
         * @return {number}
         */
        public getBitCount() : number {
            return this.ipv6Section.getBitCount() + this.ipv4Section.getBitCount();
        }

        /**
         * 
         * @return {boolean}
         */
        public isPrefixBlock() : boolean {
            let networkPrefixLength : number = this.getNetworkPrefixLength();
            if(networkPrefixLength == null) {
                return false;
            }
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                return true;
            }
            if(this.ipv6Section.isPrefixed()) {
                return this.ipv6Section.isPrefixBlock() && this.ipv4Section.isFullRange();
            }
            return this.ipv4Section.isPrefixBlock();
        }

        /**
         * 
         * @return {string}
         */
        public toString() : string {
            if(this.string == null) {
                let mixedParams : IPv6AddressSection.IPv6StringOptions = IPv6AddressSection.IPv6StringCache.mixedParams_$LI$();
                let ipv6Params : IPv6AddressSection.IPv6StringParams = mixedParams.from(this.ipv6Section);
                let ipv4Opts : IPAddressSection.IPStringOptions = mixedParams.ipv4Opts;
                let parms : IPv6AddressSection.IPv6v4MixedParams = new IPv6AddressSection.IPv6v4MixedParams(ipv6Params, ipv4Opts);
                this.string = parms.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection(this);
            }
            return this.string;
        }

        /**
         * 
         * @param {AddressDivisionGrouping} o
         * @return {boolean}
         */
        isSameGrouping(o : AddressDivisionGrouping) : boolean {
            if(o != null && o instanceof <any>IPv6AddressSection.IPv6v4MixedAddressSection) {
                let other : IPv6AddressSection.IPv6v4MixedAddressSection = <IPv6AddressSection.IPv6v4MixedAddressSection>o;
                return this.ipv6Section.equals(other.ipv6Section) && this.ipv4Section.equals(other.ipv4Section);
            }
            return false;
        }

        /**
         * 
         * @param {*} o
         * @return {boolean}
         */
        public equals(o : any) : boolean {
            if(o === this) {
                return true;
            }
            if(o != null && o instanceof <any>IPv6AddressSection.IPv6v4MixedAddressSection) {
                let other : IPv6AddressSection.IPv6v4MixedAddressSection = <IPv6AddressSection.IPv6v4MixedAddressSection>o;
                return this.ipv6Section.equals(other.ipv6Section) && this.ipv4Section.equals(other.ipv4Section);
            }
            return false;
        }
    }
    IPv6v4MixedAddressSection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6v4MixedAddressSection";
    IPv6v4MixedAddressSection["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.format.IPAddressStringDivisionSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.io.Serializable"];



    export class IPv6v4MixedParams implements IPAddressStringWriter<IPv6AddressSection.IPv6v4MixedAddressSection> {
        ipv4Params : IPAddressDivisionGrouping.IPAddressStringParams<IPAddressStringDivisionSeries>;

        ipv6Params : IPv6AddressSection.IPv6StringParams;

        public constructor(ipv6Variation? : any, ipv4Variation? : any) {
            if(((ipv6Variation != null && ipv6Variation instanceof <any>IPv6AddressSection.IPv6AddressSectionString) || ipv6Variation === null) && ((ipv4Variation != null && ipv4Variation instanceof <any>IPAddressPartConfiguredString) || ipv4Variation === null)) {
                let __args = Array.prototype.slice.call(arguments);
                if(this.ipv4Params===undefined) this.ipv4Params = null;
                if(this.ipv6Params===undefined) this.ipv6Params = null;
                if(this.ipv4Params===undefined) this.ipv4Params = null;
                if(this.ipv6Params===undefined) this.ipv6Params = null;
                (() => {
                    this.ipv4Params = <any>ipv4Variation.stringParams;
                    this.ipv6Params = ipv6Variation.stringParams;
                })();
            } else if(((ipv6Variation != null && ipv6Variation instanceof <any>IPv6AddressSection.IPv6StringParams) || ipv6Variation === null) && ((ipv4Variation != null && ipv4Variation instanceof <any>IPAddressSection.IPStringOptions) || ipv4Variation === null)) {
                let __args = Array.prototype.slice.call(arguments);
                let ipv6Params : any = __args[0];
                let ipv4Opts : any = __args[1];
                if(this.ipv4Params===undefined) this.ipv4Params = null;
                if(this.ipv6Params===undefined) this.ipv6Params = null;
                if(this.ipv4Params===undefined) this.ipv4Params = null;
                if(this.ipv6Params===undefined) this.ipv6Params = null;
                (() => {
                    this.ipv4Params = IPAddressSection.toIPParams(ipv4Opts);
                    this.ipv6Params = ipv6Params;
                })();
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @return {string}
         */
        public getTrailingSegmentSeparator() : string {
            return this.ipv4Params.getTrailingSegmentSeparator();
        }

        public getTrailingSeparatorCount$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection(addr : IPv6AddressSection.IPv6v4MixedAddressSection) : number {
            return this.ipv4Params.getTrailingSeparatorCount(addr.ipv4Section);
        }

        /**
         * 
         * @param {IPv6AddressSection.IPv6v4MixedAddressSection} addr
         * @return {number}
         */
        public getTrailingSeparatorCount(addr? : any) : any {
            if(((addr != null && addr instanceof <any>IPv6AddressSection.IPv6v4MixedAddressSection) || addr === null)) {
                return <any>this.getTrailingSeparatorCount$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection(addr);
            } else throw new Error('invalid overload');
        }

        public getStringLength(addr : IPv6AddressSection.IPv6v4MixedAddressSection, zone : any) : number {
            let ipv6length : number = this.ipv6Params.getSegmentsStringLength$inet_ipaddr_ipv6_IPv6AddressSection(addr.ipv6Section);
            let ipv4length : number = this.ipv4Params.getSegmentsStringLength(addr.ipv4Section);
            let length : number = ipv6length + ipv4length;
            if(this.ipv6Params.nextUncompressedIndex < addr.ipv6Section.getSegmentCount()) {
                length++;
            }
            length += this.getPrefixStringLength(addr);
            length += this.ipv6Params.getZoneLength(zone);
            length += this.ipv6Params.getAddressSuffixLength();
            length += this.ipv6Params.getAddressLabelLength();
            return length;
        }

        public toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection(addr : IPv6AddressSection.IPv6v4MixedAddressSection) : string {
            return this.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection$java_lang_CharSequence(addr, null);
        }

        public toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection$java_lang_CharSequence(addr : IPv6AddressSection.IPv6v4MixedAddressSection, zone : any) : string {
            let length : number = this.getStringLength(addr, zone);
            let builder : { str: string } = { str: "", toString: function() { return this.str; } };
            this.append(builder, addr, zone);
            AddressDivisionGrouping.AddressStringParams.checkLengths(length, builder);
            return /* toString */builder.str;
        }

        /**
         * 
         * @param {IPv6AddressSection.IPv6v4MixedAddressSection} addr
         * @param {*} zone
         * @return {string}
         */
        public toString(addr? : any, zone? : any) : any {
            if(((addr != null && addr instanceof <any>IPv6AddressSection.IPv6v4MixedAddressSection) || addr === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                return <any>this.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection$java_lang_CharSequence(addr, zone);
            } else if(((addr != null && addr instanceof <any>IPv6AddressSection.IPv6v4MixedAddressSection) || addr === null) && zone === undefined) {
                return <any>this.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection(addr);
            } else throw new Error('invalid overload');
        }

        /**
         * 
         * @param {*} seg
         * @return {number}
         */
        public getDivisionStringLength(seg : AddressStringDivision) : number {
            return this.ipv6Params.getDivisionStringLength(seg);
        }

        /**
         * 
         * @param {{ str: string }} builder
         * @param {*} seg
         * @return {{ str: string }}
         */
        public appendDivision(builder : { str: string }, seg : AddressStringDivision) : { str: string } {
            return this.ipv6Params.appendDivision(builder, seg);
        }

        public append(builder : { str: string }, addr : IPv6AddressSection.IPv6v4MixedAddressSection, zone : any) : { str: string } {
            this.ipv6Params.appendLabel(builder);
            this.ipv6Params.appendSegments$java_lang_StringBuilder$inet_ipaddr_ipv6_IPv6AddressSection(builder, addr.ipv6Section);
            if(this.ipv6Params.nextUncompressedIndex < addr.ipv6Section.getSegmentCount()) {
                /* append */(sb => { sb.str = sb.str.concat(<any>this.ipv6Params.getTrailingSegmentSeparator()); return sb; })(builder);
            }
            this.ipv4Params.appendSegments(builder, addr.ipv4Section);
            this.ipv6Params.appendZone(builder, zone);
            this.ipv6Params.appendSuffix(builder);
            this.appendPrefixIndicator(builder, addr);
            return builder;
        }

        getPrefixStringLength(addr : IPv6AddressSection.IPv6v4MixedAddressSection) : number {
            if(this.requiresPrefixIndicator$inet_ipaddr_ipv6_IPv6AddressSection(addr.ipv6Section) || this.requiresPrefixIndicator$inet_ipaddr_ipv4_IPv4AddressSection(addr.ipv4Section)) {
                return IPAddressDivisionGrouping.IPAddressStringParams.getPrefixIndicatorStringLength(addr);
            }
            return 0;
        }

        public appendPrefixIndicator(builder : { str: string }, addr : IPv6AddressSection.IPv6v4MixedAddressSection) {
            if(this.requiresPrefixIndicator$inet_ipaddr_ipv6_IPv6AddressSection(addr.ipv6Section) || this.requiresPrefixIndicator$inet_ipaddr_ipv4_IPv4AddressSection(addr.ipv4Section)) {
                this.ipv6Params.appendPrefixIndicator(builder, addr);
            }
        }

        public requiresPrefixIndicator$inet_ipaddr_ipv4_IPv4AddressSection(ipv4Section : IPv4AddressSection) : boolean {
            return ipv4Section.isPrefixed() && !this.ipv4Params.preferWildcards();
        }

        public requiresPrefixIndicator(ipv4Section? : any) : any {
            if(((ipv4Section != null && ipv4Section instanceof <any>IPv4AddressSection) || ipv4Section === null)) {
                return <any>this.requiresPrefixIndicator$inet_ipaddr_ipv4_IPv4AddressSection(ipv4Section);
            } else if(((ipv4Section != null && ipv4Section instanceof <any>IPv6AddressSection) || ipv4Section === null)) {
                return <any>this.requiresPrefixIndicator$inet_ipaddr_ipv6_IPv6AddressSection(ipv4Section);
            } else throw new Error('invalid overload');
        }

        requiresPrefixIndicator$inet_ipaddr_ipv6_IPv6AddressSection(ipv6Section : IPv6AddressSection) : boolean {
            return ipv6Section.isPrefixed() && (!this.ipv6Params.preferWildcards() || this.ipv6Params.hostCompressed);
        }

        /**
         * 
         * @return {IPv6AddressSection.IPv6v4MixedParams}
         */
        public clone() : IPv6AddressSection.IPv6v4MixedParams {
            try {
                let params : IPv6AddressSection.IPv6v4MixedParams = <IPv6AddressSection.IPv6v4MixedParams>/* clone *//* clone */((o:any) => { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; })(this);
                params.ipv6Params = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.ipv6Params);
                params.ipv4Params = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.ipv4Params);
                return params;
            } catch(e) {
                return null;
            };
        }
    }
    IPv6v4MixedParams["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6v4MixedParams";
    IPv6v4MixedParams["__interfaces"] = ["inet.ipaddr.format.util.AddressDivisionWriter","java.lang.Cloneable","inet.ipaddr.format.util.IPAddressStringWriter"];



    export class IPv6AddressSectionStringCollection extends IPAddressPartStringSubCollection<IPv6AddressSection, IPv6AddressSection.IPv6StringParams, IPv6AddressSection.IPv6AddressSectionString> {
        zone : any;

        constructor(addr : IPv6AddressSection, zone : any) {
            super(addr);
            if(this.zone===undefined) this.zone = null;
            this.zone = zone;
        }

        /**
         * 
         * @return {*}
         */
        public iterator() : any {
            return new IPv6AddressSectionStringCollection.IPv6AddressSectionStringCollection$0(this);
        }
    }
    IPv6AddressSectionStringCollection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6AddressSectionStringCollection";
    IPv6AddressSectionStringCollection["__interfaces"] = ["java.lang.Iterable"];



    export namespace IPv6AddressSectionStringCollection {

        export class IPv6AddressSectionStringCollection$0 extends IPAddressPartStringSubCollection.IPAddressConfigurableStringIterator {
            public __parent: any;
            /**
             * 
             * @return {IPv6AddressSection.IPv6AddressSectionString}
             */
            public next() : IPv6AddressSection.IPv6AddressSectionString {
                return new IPv6AddressSection.IPv6AddressSectionString(this.__parent.part, this.iterator.next(), this.__parent.zone);
            }

            constructor(__parent: any) {
                super(__parent);
                this.__parent = __parent;
            }
        }
        IPv6AddressSectionStringCollection$0["__interfaces"] = ["java.util.Iterator"];


    }


    export class IPv6v4MixedStringCollection extends IPAddressPartStringSubCollection<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams, IPAddressPartConfiguredString<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams>> {
        zone : any;

        public constructor(part : IPv6AddressSection.IPv6v4MixedAddressSection, zone : any) {
            super(part);
            if(this.zone===undefined) this.zone = null;
            this.zone = zone;
        }

        /**
         * 
         * @return {*}
         */
        public iterator() : any {
            return new IPv6v4MixedStringCollection.IPv6v4MixedStringCollection$0(this);
        }
    }
    IPv6v4MixedStringCollection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6v4MixedStringCollection";
    IPv6v4MixedStringCollection["__interfaces"] = ["java.lang.Iterable"];



    export namespace IPv6v4MixedStringCollection {

        export class IPv6v4MixedStringCollection$0 extends IPAddressPartStringSubCollection.IPAddressConfigurableStringIterator {
            public __parent: any;
            /**
             * 
             * @return {IPAddressPartConfiguredString}
             */
            public next() : IPAddressPartConfiguredString<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams> {
                return new IPv6v4MixedStringCollection$0.IPv6v4MixedStringCollection$0$0(this, this.__parent.part, this.iterator.next());
            }

            constructor(__parent: any) {
                super(__parent);
                this.__parent = __parent;
            }
        }
        IPv6v4MixedStringCollection$0["__interfaces"] = ["java.util.Iterator"];



        export namespace IPv6v4MixedStringCollection$0 {

            export class IPv6v4MixedStringCollection$0$0 extends IPAddressPartConfiguredString<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams> {
                public __parent: any;
                /**
                 * 
                 * @return {string}
                 */
                public getString() : string {
                    if(this.string == null) {
                        this.string = this.stringParams.toString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6v4MixedAddressSection$java_lang_CharSequence(this.addr, this.__parent.__parent.zone);
                    }
                    return this.string;
                }

                constructor(__parent: any, __arg0: any, __arg1: any) {
                    super(__arg0, __arg1);
                    this.__parent = __parent;
                }
            }

        }

    }


    export class IPv6StringCollection extends IPAddressPartStringCollection {
        /**
         * 
         * @param {IPAddressPartStringSubCollection} collection
         */
        add(collection : IPAddressPartStringSubCollection<any, any, any>) {
            super.add(collection);
        }

        /**
         * 
         * @param {IPAddressPartStringCollection} collections
         */
        addAll(collections : IPAddressPartStringCollection) {
            super.addAll(collections);
        }

        constructor() {
            super();
        }
    }
    IPv6StringCollection["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringCollection";
    IPv6StringCollection["__interfaces"] = ["java.lang.Iterable"];



    export namespace IPv6StringCollection {

        /**
         * Capable of building any and all possible representations of IPv6 addresses.
         * Not all such representations are necessarily something you might consider valid.
         * For example: a:0::b:0c:d:1:2
         * This string has a single zero segment compressed rather than two consecutive (a partial compression),
         * it has the number 'c' expanded partially to 0c (a partial expansion), rather than left as is, or expanded to the full 4 chars 000c.
         * 
         * Mixed representation strings are produced by the IPv6 mixed builder.
         * The one other type of variation not produced by this class are mixed case, containing both upper and lower case characters: A-F vs a-f.
         * That would result in gazillions of possible representations.
         * But such variations are easy to work with for comparison purposes because you can easily convert strings to lowercase,
         * so in general there is no need to cover such variations.
         * However, this does provide the option to have either all uppercase or all lowercase strings.
         * 
         * A single address can have hundreds of thousands, even millions, of possible variations.
         * The default settings for this class will produce at most a couple thousand possible variations.
         * 
         * @author sfoley
         * @extends IPAddressPartStringCollection.AddressPartStringBuilder
         * @class
         */
        export class IPv6StringBuilder extends IPAddressPartStringCollection.AddressPartStringBuilder<IPv6AddressSection, IPv6AddressSection.IPv6StringParams, IPv6AddressSection.IPv6AddressSectionString, IPv6AddressSection.IPv6AddressSectionStringCollection, IPv6AddressSection.IPv6StringBuilderOptions> {
            constructor(address : IPv6AddressSection, opts : IPv6AddressSection.IPv6StringBuilderOptions, zone : any) {
                super(address, opts, new IPv6AddressSection.IPv6AddressSectionStringCollection(address, zone));
            }

            addUppercaseVariations(allParams : Array<IPv6AddressSection.IPv6StringParams>, base : number) {
                let lowerOnly : boolean = true;
                if(this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE) && this.addressSection.hasUppercaseVariations(base, lowerOnly)) {
                    let len : number = /* size */(<number>allParams.length);
                    for(let j : number = 0; j < len; j++) {
                        let clone : IPv6AddressSection.IPv6StringParams = /* get */allParams[j];
                        clone = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(clone);
                        clone.setUppercase(true);
                        /* add */(allParams.push(clone)>0);
                    };
                }
            }

            addAllExpansions(firstCompressedIndex : number, count : number, segmentCount : number) {
                let stringParams : IPv6AddressSection.IPv6StringParams = new IPv6AddressSection.IPv6StringParams(firstCompressedIndex, count);
                let base : number = stringParams.getRadix();
                let allParams : Array<IPv6AddressSection.IPv6StringParams> = <any>([]);
                /* add */(allParams.push(stringParams)>0);
                let radix : number = IPv6Address.DEFAULT_TEXTUAL_RADIX;
                if(this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$())) {
                    let expandables : number[] = this.getExpandableSegments(radix);
                    let nextUncompressedIndex : number = firstCompressedIndex + count;
                    let ipv6SegmentEnd : number = this.addressSection.getSegmentCount();
                    for(let i : number = 0; i < ipv6SegmentEnd; i++) {
                        if(i < firstCompressedIndex || i >= nextUncompressedIndex) {
                            let expansionLength : number = expandables[i];
                            let len : number = /* size */(<number>allParams.length);
                            while((expansionLength > 0)) {
                                for(let j : number = 0; j < len; j++) {
                                    let clone : IPv6AddressSection.IPv6StringParams = /* get */allParams[j];
                                    clone = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(clone);
                                    clone.expandSegment(i, expansionLength, this.addressSection.getSegmentCount());
                                    /* add */(allParams.push(clone)>0);
                                };
                                if(!this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_PARTIAL_SOME_SEGMENTS_$LI$())) {
                                    break;
                                }
                                expansionLength--;
                            };
                        }
                    };
                } else if(this.options.includes(IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS)) {
                    let isExpandable : boolean = this.isExpandableOutsideRange(radix, firstCompressedIndex, count);
                    if(isExpandable) {
                        let len : number = /* size */(<number>allParams.length);
                        for(let j : number = 0; j < len; j++) {
                            let clone : IPv6AddressSection.IPv6StringParams = /* get */allParams[j];
                            clone = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(clone);
                            clone.expandSegments(true);
                            /* add */(allParams.push(clone)>0);
                        };
                    }
                }
                this.addUppercaseVariations(allParams, base);
                for(let i : number = 0; i < /* size */(<number>allParams.length); i++) {
                    let param : IPv6AddressSection.IPv6StringParams = /* get */allParams[i];
                    this.addStringParam(param);
                };
            }

            addAllCompressedStrings(zeroStartIndex : number, count : number, partial : boolean, segmentCount : number) {
                let end : number = zeroStartIndex + count;
                if(partial) {
                    for(let i : number = zeroStartIndex; i < end; i++) {
                        for(let j : number = i + 1; j <= end; j++) {
                            this.addAllExpansions(i, j - i, segmentCount);
                        };
                    };
                } else {
                    let len : number = end - zeroStartIndex;
                    if(len > 0) {
                        this.addAllExpansions(zeroStartIndex, len, segmentCount);
                    }
                }
            }

            /**
             * 
             */
            addAllVariations() {
                let segmentCount : number = this.addressSection.getSegmentCount();
                this.addAllExpansions(-1, 0, segmentCount);
                if(this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$())) {
                    let zeroSegs : IPAddressDivisionGrouping.RangeList = this.addressSection.getZeroSegments();
                    for(let i : number = 0; i < zeroSegs.size(); i++) {
                        let range : IPAddressDivisionGrouping.Range = zeroSegs.getRange(i);
                        this.addAllCompressedStrings(range.index, range.length, this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL_$LI$()), segmentCount);
                    };
                } else if(this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_CANONICAL)) {
                    let opts : IPv6AddressSection.CompressOptions = new IPv6AddressSection.CompressOptions(this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_SINGLE_$LI$()), IPv6AddressSection.CompressOptions.CompressionChoiceOptions.ZEROS);
                    let indexes : number[] = this.addressSection.getCompressIndexAndCount$inet_ipaddr_ipv6_IPv6AddressSection_CompressOptions(opts);
                    if(indexes != null) {
                        if(this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_LARGEST_$LI$())) {
                            let maxCount : number = indexes[1];
                            let zeroSegs : IPAddressDivisionGrouping.RangeList = this.addressSection.getZeroSegments();
                            for(let i : number = 0; i < zeroSegs.size(); i++) {
                                let range : IPAddressDivisionGrouping.Range = zeroSegs.getRange(i);
                                let count : number = range.length;
                                if(count === maxCount) {
                                    this.addAllCompressedStrings(range.index, count, this.options.includes(IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL_$LI$()), segmentCount);
                                }
                            };
                        } else {
                            let maxIndex : number = indexes[0];
                            let maxCount : number = indexes[1];
                            this.addAllCompressedStrings(maxIndex, maxCount, false, segmentCount);
                        }
                    }
                }
            }
        }
        IPv6StringBuilder["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringCollection.IPv6StringBuilder";


        export class IPv6v4MixedStringBuilder extends IPAddressPartStringCollection.AddressPartStringBuilder<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams, IPAddressPartConfiguredString<IPv6AddressSection.IPv6v4MixedAddressSection, IPv6AddressSection.IPv6v4MixedParams>, IPv6AddressSection.IPv6v4MixedStringCollection, IPv6AddressSection.IPv6StringBuilderOptions> {
            zone : any;

            constructor(address : IPv6AddressSection.IPv6v4MixedAddressSection, opts : IPv6AddressSection.IPv6StringBuilderOptions, zone : any) {
                super(address, opts, new IPv6AddressSection.IPv6v4MixedStringCollection(address, zone));
                if(this.zone===undefined) this.zone = null;
                this.zone = zone;
            }

            /**
             * 
             */
            addAllVariations() {
                let ipv6Builder : IPv6StringCollection.IPv6StringBuilder = new IPv6StringCollection.IPv6StringBuilder(this.addressSection.ipv6Section, this.options, this.zone);
                let ipv6Variations : IPv6AddressSection.IPv6AddressSectionStringCollection = ipv6Builder.getVariations();
                let ipv4Collection : IPAddressPartStringCollection = this.addressSection.ipv4Section.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(this.options.mixedOptions);
                for(let index132=ipv6Variations.iterator();index132.hasNext();) {
                    let ipv6Variation = index132.next();
                    {
                        for(let index133=ipv4Collection.iterator();index133.hasNext();) {
                            let ipv4Variation = index133.next();
                            {
                                let mixed : IPv6AddressSection.IPv6v4MixedParams = new IPv6AddressSection.IPv6v4MixedParams(ipv6Variation, ipv4Variation);
                                this.addStringParam(mixed);
                            }
                        }
                    }
                }
            }
        }
        IPv6v4MixedStringBuilder["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringCollection.IPv6v4MixedStringBuilder";

    }


    export class IPv6AddressSectionString extends IPAddressPartConfiguredString<IPv6AddressSection, IPv6AddressSection.IPv6StringParams> {
        zone : any;

        constructor(addr : IPv6AddressSection, stringParams : IPv6AddressSection.IPv6StringParams, zone : any) {
            super(addr, stringParams);
            if(this.zone===undefined) this.zone = null;
            this.zone = zone;
        }

        /**
         * 
         * @param {boolean} isEntireAddress
         * @param {*} translator
         * @return {IPv6AddressSection.IPv6StringMatcher}
         */
        public getNetworkStringMatcher(isEntireAddress : boolean, translator : IPAddressSQLTranslator) : IPv6AddressSection.IPv6StringMatcher {
            return new IPv6AddressSection.IPv6StringMatcher(this, translator);
        }

        public endIsCompressed() : boolean {
            return this.stringParams.endIsCompressed(this.addr);
        }

        public isCompressed() : boolean {
            return this.stringParams.isCompressed(this.addr);
        }

        /**
         * 
         * @return {string}
         */
        public getString() : string {
            if(this.string == null) {
                this.string = this.stringParams.toString(this.addr, this.zone);
            }
            return this.string;
        }
    }
    IPv6AddressSectionString["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6AddressSectionString";


    export class IPv6StringBuilderOptions extends IPAddressSection.IPStringBuilderOptions {
        public static MIXED : number = 2;

        public static UPPERCASE : number = 4;

        public static COMPRESSION_CANONICAL : number = 256;

        public static COMPRESSION_SINGLE : number; public static COMPRESSION_SINGLE_$LI$() : number { if(IPv6StringBuilderOptions.COMPRESSION_SINGLE == null) IPv6StringBuilderOptions.COMPRESSION_SINGLE = IPv6StringBuilderOptions.COMPRESSION_CANONICAL | 512; return IPv6StringBuilderOptions.COMPRESSION_SINGLE; };

        public static COMPRESSION_LARGEST : number; public static COMPRESSION_LARGEST_$LI$() : number { if(IPv6StringBuilderOptions.COMPRESSION_LARGEST == null) IPv6StringBuilderOptions.COMPRESSION_LARGEST = IPv6StringBuilderOptions.COMPRESSION_SINGLE_$LI$() | 1024; return IPv6StringBuilderOptions.COMPRESSION_LARGEST; };

        public static COMPRESSION_ALL_FULL : number; public static COMPRESSION_ALL_FULL_$LI$() : number { if(IPv6StringBuilderOptions.COMPRESSION_ALL_FULL == null) IPv6StringBuilderOptions.COMPRESSION_ALL_FULL = IPv6StringBuilderOptions.COMPRESSION_LARGEST_$LI$() | 2048; return IPv6StringBuilderOptions.COMPRESSION_ALL_FULL; };

        public static COMPRESSION_ALL_PARTIAL : number; public static COMPRESSION_ALL_PARTIAL_$LI$() : number { if(IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL == null) IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL = IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$() | 4096; return IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL; };

        public static IPV4_CONVERSIONS : number = 65536;

        public mixedOptions : IPv4AddressSection.IPv4StringBuilderOptions;

        public ipv4ConverterOptions : IPv4AddressSection.IPv4StringBuilderOptions;

        public converter : IPv4Address.IPv4AddressConverter;

        public static STANDARD_OPTS : IPv6AddressSection.IPv6StringBuilderOptions; public static STANDARD_OPTS_$LI$() : IPv6AddressSection.IPv6StringBuilderOptions { if(IPv6StringBuilderOptions.STANDARD_OPTS == null) IPv6StringBuilderOptions.STANDARD_OPTS = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$(), new IPv4AddressSection.IPv4StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_ALL_SEGMENTS)); return IPv6StringBuilderOptions.STANDARD_OPTS; };

        public static ALL_OPTS : IPv6AddressSection.IPv6StringBuilderOptions; public static ALL_OPTS_$LI$() : IPv6AddressSection.IPv6StringBuilderOptions { if(IPv6StringBuilderOptions.ALL_OPTS == null) IPv6StringBuilderOptions.ALL_OPTS = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.MIXED | IPv6AddressSection.IPv6StringBuilderOptions.UPPERCASE | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$() | IPv6AddressSection.IPv6StringBuilderOptions.IPV4_CONVERSIONS | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$(), new IPv4AddressSection.IPv4StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$()), null, new IPv4AddressSection.IPv4StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ALL | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_TWO | IPv4AddressSection.IPv4StringBuilderOptions.JOIN_ONE | IPv4AddressSection.IPv4StringBuilderOptions.HEX | IPv4AddressSection.IPv4StringBuilderOptions.OCTAL | IPAddressSection.IPStringBuilderOptions.LEADING_ZEROS_FULL_SOME_SEGMENTS_$LI$())); return IPv6StringBuilderOptions.ALL_OPTS; };

        public static DATABASE_SEARCH_OPTS : IPv6AddressSection.IPv6StringBuilderOptions; public static DATABASE_SEARCH_OPTS_$LI$() : IPv6AddressSection.IPv6StringBuilderOptions { if(IPv6StringBuilderOptions.DATABASE_SEARCH_OPTS == null) IPv6StringBuilderOptions.DATABASE_SEARCH_OPTS = new IPv6AddressSection.IPv6StringBuilderOptions(IPAddressSection.IPStringBuilderOptions.BASIC | IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_LARGEST_$LI$()); return IPv6StringBuilderOptions.DATABASE_SEARCH_OPTS; };

        public constructor(options? : any, mixedOptions? : any, ipv4AddressConverter? : any, ipv4ConverterOptions? : any) {
            if(((typeof options === 'number') || options === null) && ((mixedOptions != null && mixedOptions instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || mixedOptions === null) && ((ipv4AddressConverter != null && (ipv4AddressConverter["__interfaces"] != null && ipv4AddressConverter["__interfaces"].indexOf("inet.ipaddr.ipv4.IPv4Address.IPv4AddressConverter") >= 0 || ipv4AddressConverter.constructor != null && ipv4AddressConverter.constructor["__interfaces"] != null && ipv4AddressConverter.constructor["__interfaces"].indexOf("inet.ipaddr.ipv4.IPv4Address.IPv4AddressConverter") >= 0)) || ipv4AddressConverter === null) && ((ipv4ConverterOptions != null && ipv4ConverterOptions instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || ipv4ConverterOptions === null)) {
                let __args = Array.prototype.slice.call(arguments);
                super(options | (mixedOptions == null?0:IPv6StringBuilderOptions.MIXED) | (ipv4ConverterOptions == null?0:IPv6StringBuilderOptions.IPV4_CONVERSIONS));
                if(this.mixedOptions===undefined) this.mixedOptions = null;
                if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                if(this.mixedOptions===undefined) this.mixedOptions = null;
                if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                if(this.converter===undefined) this.converter = null;
                (() => {
                    if(this.includes(IPv6StringBuilderOptions.MIXED) && mixedOptions == null) {
                        mixedOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                    }
                    this.mixedOptions = mixedOptions;
                    if(this.includes(IPv6StringBuilderOptions.IPV4_CONVERSIONS)) {
                        if(ipv4ConverterOptions == null) {
                            ipv4ConverterOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                        }
                        if(ipv4AddressConverter == null) {
                            ipv4AddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
                            if(ipv4AddressConverter == null) {
                                ipv4AddressConverter = new IPAddressConverter.DefaultAddressConverter();
                            }
                        }
                    }
                    this.ipv4ConverterOptions = ipv4ConverterOptions;
                    this.converter = ipv4AddressConverter;
                })();
            } else if(((typeof options === 'number') || options === null) && ((mixedOptions != null && mixedOptions instanceof <any>IPv4AddressSection.IPv4StringBuilderOptions) || mixedOptions === null) && ipv4AddressConverter === undefined && ipv4ConverterOptions === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let ipv4AddressConverter : any = null;
                    let ipv4ConverterOptions : any = null;
                    super(options | (mixedOptions == null?0:IPv6StringBuilderOptions.MIXED) | (ipv4ConverterOptions == null?0:IPv6StringBuilderOptions.IPV4_CONVERSIONS));
                    if(this.mixedOptions===undefined) this.mixedOptions = null;
                    if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    if(this.mixedOptions===undefined) this.mixedOptions = null;
                    if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    (() => {
                        if(this.includes(IPv6StringBuilderOptions.MIXED) && mixedOptions == null) {
                            mixedOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                        }
                        this.mixedOptions = mixedOptions;
                        if(this.includes(IPv6StringBuilderOptions.IPV4_CONVERSIONS)) {
                            if(ipv4ConverterOptions == null) {
                                ipv4ConverterOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                            }
                            if(ipv4AddressConverter == null) {
                                ipv4AddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
                                if(ipv4AddressConverter == null) {
                                    ipv4AddressConverter = new IPAddressConverter.DefaultAddressConverter();
                                }
                            }
                        }
                        this.ipv4ConverterOptions = ipv4ConverterOptions;
                        this.converter = ipv4AddressConverter;
                    })();
                }
            } else if(((typeof options === 'number') || options === null) && mixedOptions === undefined && ipv4AddressConverter === undefined && ipv4ConverterOptions === undefined) {
                let __args = Array.prototype.slice.call(arguments);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let mixedOptions : any = null;
                    let ipv4AddressConverter : any = null;
                    let ipv4ConverterOptions : any = null;
                    super(options | (mixedOptions == null?0:IPv6StringBuilderOptions.MIXED) | (ipv4ConverterOptions == null?0:IPv6StringBuilderOptions.IPV4_CONVERSIONS));
                    if(this.mixedOptions===undefined) this.mixedOptions = null;
                    if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    if(this.mixedOptions===undefined) this.mixedOptions = null;
                    if(this.ipv4ConverterOptions===undefined) this.ipv4ConverterOptions = null;
                    if(this.converter===undefined) this.converter = null;
                    (() => {
                        if(this.includes(IPv6StringBuilderOptions.MIXED) && mixedOptions == null) {
                            mixedOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                        }
                        this.mixedOptions = mixedOptions;
                        if(this.includes(IPv6StringBuilderOptions.IPV4_CONVERSIONS)) {
                            if(ipv4ConverterOptions == null) {
                                ipv4ConverterOptions = new IPv4AddressSection.IPv4StringBuilderOptions();
                            }
                            if(ipv4AddressConverter == null) {
                                ipv4AddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
                                if(ipv4AddressConverter == null) {
                                    ipv4AddressConverter = new IPAddressConverter.DefaultAddressConverter();
                                }
                            }
                        }
                        this.ipv4ConverterOptions = ipv4ConverterOptions;
                        this.converter = ipv4AddressConverter;
                    })();
                }
            } else throw new Error('invalid overload');
        }

        public static from(opts : IPAddressSection.IPStringBuilderOptions) : IPv6AddressSection.IPv6StringBuilderOptions {
            if(opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) {
                return <IPv6AddressSection.IPv6StringBuilderOptions>opts;
            }
            return new IPv6AddressSection.IPv6StringBuilderOptions(opts.options & ~(IPv6StringBuilderOptions.MIXED | IPv6StringBuilderOptions.UPPERCASE | IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL_$LI$() | IPv6StringBuilderOptions.IPV4_CONVERSIONS));
        }
    }
    IPv6StringBuilderOptions["__class"] = "inet.ipaddr.ipv6.IPv6AddressSection.IPv6StringBuilderOptions";


    export class IPv6AddressSection$0 extends IPv6AddressNetwork.IPv6AddressCreator {
        public __parent: any;
        static serialVersionUID : number = 4;

        /**
         * 
         * @param {Array} bytes
         * @param {number} segmentCount
         * @param {number} prefix
         * @param {boolean} singleOnly
         * @return {IPv6AddressSection}
         */
        public createSectionInternal(bytes? : any, segmentCount? : any, prefix? : any, singleOnly? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                super.createSectionInternal(bytes, segmentCount, prefix, singleOnly);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((segmentCount != null && segmentCount instanceof <any>IPv4AddressSection) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$inet_ipaddr_ipv4_IPv4AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection$java_lang_Integer(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$byte_A$int$java_lang_Integer(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof prefix === 'boolean') || prefix === null) && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$int$boolean(bytes, segmentCount, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((segmentCount != null && segmentCount instanceof <any>IPv4AddressSection) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$inet_ipaddr_ipv4_IPv4AddressSection(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$byte_A$java_lang_Integer(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof segmentCount === 'number') || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$int(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((segmentCount != null) || segmentCount === null) && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_AddressSection(bytes, segmentCount);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && segmentCount === undefined && prefix === undefined && singleOnly === undefined) {
                return <any>this.createSectionInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(segments : IPv6AddressSegment[]) : IPv6AddressSection {
            return this.getNetwork().getAddressCreator().createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$int(segments, this.startIndex);
        }

        public createPrefixedSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer$boolean(segments : IPv6AddressSegment[], prefix : number, singleOnly : boolean) : IPv6AddressSection {
            return new IPv6AddressSection(segments, this.startIndex, false, prefix, singleOnly);
        }

        /**
         * 
         * @param {Array} segments
         * @param {number} prefix
         * @param {boolean} singleOnly
         * @return {IPv6AddressSection}
         */
        public createPrefixedSectionInternal(segments? : any, prefix? : any, singleOnly? : any) : any {
            if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null && segments[0] instanceof <any>IPv6AddressSegment))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof singleOnly === 'boolean') || singleOnly === null)) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(segments, prefix, singleOnly);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(segments, prefix);
            } else if(((segments != null && segments instanceof <any>Array && (segments.length==0 || segments[0] == null ||(segments[0] != null))) || segments === null) && ((typeof prefix === 'number') || prefix === null) && singleOnly === undefined) {
                return <any>this.createPrefixedSectionInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(segments, prefix);
            } else throw new Error('invalid overload');
        }

        constructor(__parent: any, __arg0: any, private startIndex: any) {
            super(__arg0);
            this.__parent = __parent;
        }
    }
    IPv6AddressSection$0["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];


}




IPv6AddressSection.IPv6StringBuilderOptions.DATABASE_SEARCH_OPTS_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.STANDARD_OPTS_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_PARTIAL_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_ALL_FULL_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_LARGEST_$LI$();

IPv6AddressSection.IPv6StringBuilderOptions.COMPRESSION_SINGLE_$LI$();

IPv6AddressSection.IPv6StringCache.base85Params_$LI$();

IPv6AddressSection.IPv6StringCache.reverseDNSParams_$LI$();

IPv6AddressSection.IPv6StringCache.networkPrefixLengthParams_$LI$();

IPv6AddressSection.IPv6StringCache.wildcardCompressedParams_$LI$();

IPv6AddressSection.IPv6StringCache.sqlWildcardParams_$LI$();

IPv6AddressSection.IPv6StringCache.wildcardCanonicalParams_$LI$();

IPv6AddressSection.IPv6StringCache.wildcardNormalizedParams_$LI$();

IPv6AddressSection.IPv6StringCache.compressedParams_$LI$();

IPv6AddressSection.IPv6StringCache.uncParams_$LI$();

IPv6AddressSection.IPv6StringCache.canonicalParams_$LI$();

IPv6AddressSection.IPv6StringCache.normalizedParams_$LI$();

IPv6AddressSection.IPv6StringCache.fullParams_$LI$();

IPv6AddressSection.IPv6StringCache.mixedParams_$LI$();

IPv6AddressSection.IPv6StringCache.__static_initialize();

IPv6AddressSection.MAX_VALUES_BY_SEGMENT_$LI$();

IPv6AddressSection.creators_$LI$();
