/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IPv4AddressStringParameters } from '../ipv4/IPv4AddressStringParameters';
import { IPv6AddressNetwork } from './IPv6AddressNetwork';
import { AddressStringParameters } from '../AddressStringParameters';

/**
 * The IPv6-specific parameters within a {@link IPAddressStringParameters} instance.
 * 
 * @author sfoley
 * @param {boolean} allowLeadingZeros
 * @param {boolean} allowCIDRPrefixLeadingZeros
 * @param {boolean} allowUnlmitedLeadingZeros
 * @param {boolean} allowMixed
 * @param {IPAddressStringParameters} mixedOptions
 * @param {boolean} allowZone
 * @param {boolean} allowBase85
 * @param {AddressStringParameters.RangeParameters} rangeOptions
 * @param {boolean} allowWildcardedSeparator
 * @param {boolean} allowPrefixesBeyondAddressSize
 * @param {IPv6AddressNetwork} network
 * @class
 * @extends IPAddressStringParameters.IPAddressStringFormatParameters
 */
export class IPv6AddressStringParameters extends IPAddressStringParameters.IPAddressStringFormatParameters {
    static serialVersionUID : number = 4;

    public static DEFAULT_ALLOW_MIXED : boolean = true;

    public static DEFAULT_ALLOW_ZONE : boolean = true;

    public static DEFAULT_ALLOW_BASE85 : boolean = true;

    /**
     * Allows IPv6 addresses with embedded ipv4 like a:b:c:d:e:f:1.2.3.4
     * @see #DEFAULT_ALLOW_MIXED
     */
    public allowMixed : boolean;

    /**
     * Allows IPv6 zones with the '%' character, which generally denotes either scope identifiers or network interfaces.
     * @see #DEFAULT_ALLOW_ZONE
     */
    public allowZone : boolean;

    public allowBase85 : boolean;

    /**
     * The network that will be used to construct addresses - both parameters inside the network, and the network's address creator
     */
    /*private*/ network : IPv6AddressNetwork;

    /**
     * if you allow mixed, this is the options used for the ipv4 section,
     * in which really only the ipv4 options apply and the ipv6 options are ignored except for the zone allowed setting
     */
    /*private*/ embeddedIPv4Options : IPAddressStringParameters;

    public constructor(allowLeadingZeros : boolean, allowCIDRPrefixLeadingZeros : boolean, allowUnlmitedLeadingZeros : boolean, allowMixed : boolean, mixedOptions : IPAddressStringParameters, allowZone : boolean, allowBase85 : boolean, rangeOptions : AddressStringParameters.RangeParameters, allowWildcardedSeparator : boolean, allowPrefixesBeyondAddressSize : boolean, network : IPv6AddressNetwork) {
        super(allowLeadingZeros, allowCIDRPrefixLeadingZeros, allowUnlmitedLeadingZeros, rangeOptions, allowWildcardedSeparator, allowPrefixesBeyondAddressSize);
        if(this.allowMixed===undefined) this.allowMixed = false;
        if(this.allowZone===undefined) this.allowZone = false;
        if(this.allowBase85===undefined) this.allowBase85 = false;
        if(this.network===undefined) this.network = null;
        if(this.embeddedIPv4Options===undefined) this.embeddedIPv4Options = null;
        this.allowMixed = allowMixed;
        this.allowZone = allowZone;
        this.allowBase85 = allowBase85;
        this.embeddedIPv4Options = mixedOptions;
        this.network = network;
    }

    public toBuilder(builder? : any) : any {
        if(((builder != null && builder instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters.BuilderBase) || builder === null)) {
            super.toBuilder(builder);
        } else if(((builder != null && builder instanceof <any>AddressStringParameters.AddressStringFormatParameters.BuilderBase) || builder === null)) {
            return <any>this.toBuilder$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters_BuilderBase(builder);
        } else if(((typeof builder === 'boolean') || builder === null)) {
            return <any>this.toBuilder$boolean(builder);
        } else if(builder === undefined) {
            return <any>this.toBuilder$();
        } else throw new Error('invalid overload');
    }

    public toBuilder$() : IPv6AddressStringParameters.Builder {
        return this.toBuilder$boolean(false);
    }

    public toBuilder$boolean(isMixed : boolean) : IPv6AddressStringParameters.Builder {
        let builder : IPv6AddressStringParameters.Builder = new IPv6AddressStringParameters.Builder();
        builder.__allowMixed = this.allowMixed;
        builder.__allowZone = this.allowZone;
        builder.allowBase85 = this.allowBase85;
        builder.network = this.network;
        if(!isMixed) {
            builder.embeddedIPv4OptionsBuilder = this.embeddedIPv4Options.toBuilder$boolean(true);
        }
        return <IPv6AddressStringParameters.Builder>this.toBuilder$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase(builder);
    }

    /**
     * 
     * @return {IPv6AddressNetwork}
     */
    public getNetwork() : IPv6AddressNetwork {
        if(this.network == null) {
            return Address.defaultIpv6Network();
        }
        return this.network;
    }

    /**
     * 
     * @return {IPv6AddressStringParameters}
     */
    public clone() : IPv6AddressStringParameters {
        try {
            let result : IPv6AddressStringParameters = <IPv6AddressStringParameters>/* clone *//* clone */((o:any) => { if(super.clone!=undefined) { return super.clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this);
            result.embeddedIPv4Options = /* clone *//* clone */((o:any) => { if(o.clone!=undefined) { return (<any>o).clone(); } else { let clone = Object.create(o); for(let p in o) { if (o.hasOwnProperty(p)) clone[p] = o[p]; } return clone; } })(this.embeddedIPv4Options);
            return result;
        } catch(e) {
        };
        return null;
    }

    public getMixedParameters() : IPAddressStringParameters {
        return this.embeddedIPv4Options;
    }

    public compareTo$inet_ipaddr_ipv6_IPv6AddressStringParameters(o : IPv6AddressStringParameters) : number {
        let result : number = super.compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o);
        if(result === 0) {
            result = this.embeddedIPv4Options.getIPv4Parameters().compareTo$inet_ipaddr_ipv4_IPv4AddressStringParameters(o.embeddedIPv4Options.getIPv4Parameters());
            if(result === 0) {
                result = javaemul.internal.BooleanHelper.compare(this.allowMixed, o.allowMixed);
                if(result === 0) {
                    result = javaemul.internal.BooleanHelper.compare(this.allowZone, o.allowZone);
                    if(result === 0) {
                        result = javaemul.internal.BooleanHelper.compare(this.allowBase85, o.allowBase85);
                    }
                }
            }
        }
        return result;
    }

    /**
     * 
     * @param {IPv6AddressStringParameters} o
     * @return {number}
     */
    public compareTo(o? : any) : any {
        if(((o != null && o instanceof <any>IPv6AddressStringParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_ipv6_IPv6AddressStringParameters(o);
        } else if(((o != null && o instanceof <any>IPAddressStringParameters.IPAddressStringFormatParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters(o);
        } else if(((o != null && o instanceof <any>AddressStringParameters.AddressStringFormatParameters) || o === null)) {
            return <any>this.compareTo$inet_ipaddr_AddressStringParameters_AddressStringFormatParameters(o);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {*} o
     * @return {boolean}
     */
    public equals(o : any) : boolean {
        if(o != null && o instanceof <any>IPv6AddressStringParameters) {
            if(super.equals(o)) {
                let other : IPv6AddressStringParameters = <IPv6AddressStringParameters>o;
                return Objects.equals(this.embeddedIPv4Options.getIPv4Parameters(), other.embeddedIPv4Options.getIPv4Parameters()) && this.allowMixed === other.allowMixed && this.allowZone === other.allowZone && this.allowBase85 === other.allowBase85;
            }
        }
        return false;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let hash : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
        hash |= /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.embeddedIPv4Options.getIPv4Parameters())) << 6;
        if(this.allowMixed) {
            hash |= 32768;
        }
        if(this.allowZone) {
            hash |= 65536;
        }
        if(this.allowBase85) {
            hash |= 131072;
        }
        return hash;
    }
}
IPv6AddressStringParameters["__class"] = "inet.ipaddr.ipv6.IPv6AddressStringParameters";
IPv6AddressStringParameters["__interfaces"] = ["java.lang.Cloneable","java.lang.Comparable","java.io.Serializable"];



export namespace IPv6AddressStringParameters {

    export class Builder extends IPAddressStringParameters.IPAddressStringFormatParameters.__inet_ipaddr_IPAddressStringParameters_IPAddressStringFormatParameters_BuilderBase {
        __allowMixed : boolean = IPv6AddressStringParameters.DEFAULT_ALLOW_MIXED;

        __allowZone : boolean = IPv6AddressStringParameters.DEFAULT_ALLOW_ZONE;

        allowBase85 : boolean = IPv6AddressStringParameters.DEFAULT_ALLOW_BASE85;

        embeddedIPv4OptionsBuilder : IPAddressStringParameters.Builder;

        network : IPv6AddressNetwork;

        static DEFAULT_MIXED_OPTS : IPAddressStringParameters; public static DEFAULT_MIXED_OPTS_$LI$() : IPAddressStringParameters { if(Builder.DEFAULT_MIXED_OPTS == null) Builder.DEFAULT_MIXED_OPTS = new IPAddressStringParameters.Builder().allowEmpty(false).allowPrefix(false).allowMask(false).allowPrefixOnly(false).allowAll(false).getIPv6AddressParametersBuilder().allowMixed(false).getParentBuilder().toParams(); return Builder.DEFAULT_MIXED_OPTS; };

        public constructor() {
            super();
            if(this.embeddedIPv4OptionsBuilder===undefined) this.embeddedIPv4OptionsBuilder = null;
            if(this.network===undefined) this.network = null;
        }

        public allowZone(allow : boolean) : IPv6AddressStringParameters.Builder {
            this.getEmbeddedIPv4ParametersBuilder().getIPv6AddressParametersBuilder().__allowZone = allow;
            this.__allowZone = allow;
            return this;
        }

        /**
         * Allow inet_aton formats in the mixed part of an IPv6 address
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder} the builder
         */
        public allow_mixed_inet_aton(allow : boolean) : IPv6AddressStringParameters.Builder {
            if(allow) {
                this.allowMixed(allow);
            }
            this.getEmbeddedIPv4ParametersBuilder().getIPv4AddressParametersBuilder().allow_inet_aton(allow);
            return this;
        }

        /**
         * @see IPv6AddressStringParameters#allowMixed
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder} the builder
         */
        public allowMixed(allow : boolean) : IPv6AddressStringParameters.Builder {
            this.__allowMixed = allow;
            return this;
        }

        /**
         * Gets the builder for the parameters governing the IPv4 mixed part of an IPv6 address.
         * @return
         * @return {IPv4AddressStringParameters.Builder}
         */
        public getEmbeddedIPv4AddressParametersBuilder() : IPv4AddressStringParameters.Builder {
            return this.getEmbeddedIPv4ParametersBuilder().getIPv4AddressParametersBuilder();
        }

        /**
         * Gets the builder for the parameters governing the mixed part of an IPv6 address.
         * @return
         * @return {IPAddressStringParameters.Builder}
         */
        getEmbeddedIPv4ParametersBuilder() : IPAddressStringParameters.Builder {
            if(this.embeddedIPv4OptionsBuilder == null) {
                this.embeddedIPv4OptionsBuilder = new IPAddressStringParameters.Builder().allowEmpty(false).allowPrefix(false).allowMask(false).allowPrefixOnly(false).allowAll(false).allowIPv6(false);
                this.embeddedIPv4OptionsBuilder.getIPv6AddressParametersBuilder().__allowZone = this.__allowZone;
            }
            this.embeddedIPv4OptionsBuilder.getIPv4AddressParametersBuilder().setMixedParent(this);
            return this.embeddedIPv4OptionsBuilder;
        }

        /**
         * @see IPv6AddressStringParameters#network
         * @param {IPv6AddressNetwork} network if null, the default network will be used
         * @return {IPv6AddressStringParameters.Builder} the builder
         */
        public setNetwork(network : IPv6AddressNetwork) : IPv6AddressStringParameters.Builder {
            this.network = network;
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder}
         */
        public allowWildcardedSeparator(allow : boolean) : IPv6AddressStringParameters.Builder {
            this.getEmbeddedIPv4AddressParametersBuilder().allowWildcardedSeparator(allow);
            super.allowWildcardedSeparator(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder}
         */
        public allowLeadingZeros(allow : boolean) : IPv6AddressStringParameters.Builder {
            this.getEmbeddedIPv4AddressParametersBuilder().allowLeadingZeros(allow);
            super.allowLeadingZeros(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder}
         */
        public allowUnlimitedLeadingZeros(allow : boolean) : IPv6AddressStringParameters.Builder {
            this.getEmbeddedIPv4AddressParametersBuilder().allowUnlimitedLeadingZeros(allow);
            super.allowUnlimitedLeadingZeros(allow);
            return this;
        }

        /**
         * 
         * @param {AddressStringParameters.RangeParameters} rangeOptions
         * @return {IPv6AddressStringParameters.Builder}
         */
        public setRangeOptions(rangeOptions : AddressStringParameters.RangeParameters) : IPv6AddressStringParameters.Builder {
            this.getEmbeddedIPv4ParametersBuilder().getIPv4AddressParametersBuilder().setRangeOptions(rangeOptions);
            super.setRangeOptions(rangeOptions);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder}
         */
        public allowPrefixesBeyondAddressSize(allow : boolean) : IPv6AddressStringParameters.Builder {
            super.allowPrefixesBeyondAddressSize(allow);
            return this;
        }

        /**
         * 
         * @param {boolean} allow
         * @return {IPv6AddressStringParameters.Builder}
         */
        public allowPrefixLengthLeadingZeros(allow : boolean) : IPv6AddressStringParameters.Builder {
            super.allowPrefixLengthLeadingZeros(allow);
            return this;
        }

        public toParams() : IPv6AddressStringParameters {
            let mixedOptions : IPAddressStringParameters;
            if(this.embeddedIPv4OptionsBuilder == null) {
                mixedOptions = Builder.DEFAULT_MIXED_OPTS_$LI$();
            } else {
                mixedOptions = this.embeddedIPv4OptionsBuilder.toParams();
            }
            return new IPv6AddressStringParameters(this.__allowLeadingZeros, this.__allowPrefixLengthLeadingZeros, this.__allowUnlimitedLeadingZeros, this.__allowMixed, mixedOptions, this.__allowZone, this.allowBase85, this.rangeOptions, this.__allowWildcardedSeparator, this.__allowPrefixesBeyondAddressSize, this.network);
        }
    }
    Builder["__class"] = "inet.ipaddr.ipv6.IPv6AddressStringParameters.Builder";

}




IPv6AddressStringParameters.Builder.DEFAULT_MIXED_OPTS_$LI$();
