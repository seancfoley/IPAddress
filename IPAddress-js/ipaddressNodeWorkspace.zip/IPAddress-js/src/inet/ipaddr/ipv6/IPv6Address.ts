/*
* Copyright 2017 Sean C Foley
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*     or at
*     https://github.com/seancfoley/IPAddress/blob/master/LICENSE
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import { Address } from '../Address';
import { AddressConversionException } from '../AddressConversionException';
import { AddressPositionException } from '../AddressPositionException';
import { AddressValueException } from '../AddressValueException';
import { IPAddress } from '../IPAddress';
import { IPAddressConverter } from '../IPAddressConverter';
import { IPAddressSegmentSeries } from '../IPAddressSegmentSeries';
import { IPAddressString } from '../IPAddressString';
import { IPAddressStringParameters } from '../IPAddressStringParameters';
import { IncompatibleAddressException } from '../IncompatibleAddressException';
import { PrefixLenException } from '../PrefixLenException';
import { IPAddressStringDivisionSeries } from '../format/IPAddressStringDivisionSeries';
import { IPAddressPartStringCollection } from '../format/util/IPAddressPartStringCollection';
import { Validator } from '../format/validate/Validator';
import { IPv4Address } from '../ipv4/IPv4Address';
import { IPv4AddressNetwork } from '../ipv4/IPv4AddressNetwork';
import { IPv4AddressSection } from '../ipv4/IPv4AddressSection';
import { MACAddress } from '../mac/MACAddress';
import { MACAddressNetwork } from '../mac/MACAddressNetwork';
import { MACAddressSection } from '../mac/MACAddressSection';
import { MACAddressSegment } from '../mac/MACAddressSegment';
import { IPv6AddressSection } from './IPv6AddressSection';
import { IPv6AddressSegment } from './IPv6AddressSegment';
import { IPv6AddressNetwork } from './IPv6AddressNetwork';
import { IPAddressSection } from '../IPAddressSection';
import { AddressNetwork } from '../AddressNetwork';
import { AddressComparator } from '../AddressComparator';
import { HostIdentifierString } from '../HostIdentifierString';
import { AddressDivisionGrouping } from '../format/AddressDivisionGrouping';
import { HostName } from '../HostName';

/**
 * Constructs an IPv6 address or subnet.
 * <p>
 * Similar to {@link #IPv6Address(byte[], Integer)} except that you can specify the start and end of the address in the given byte array.
 * @param {Array} bytes
 * @param {number} byteStartIndex
 * @param {number} byteEndIndex
 * @param {number} networkPrefixLength
 * @class
 * @extends IPAddress
 * @author sfoley
 */
export class IPv6Address extends IPAddress {
    static serialVersionUID : number = 4;

    public static SEGMENT_SEPARATOR : string = ':';

    public static ZONE_SEPARATOR : string = '%';

    public static ALTERNATIVE_ZONE_SEPARATOR : string = '\u00a7';

    public static UNC_SEGMENT_SEPARATOR : string = '-';

    public static UNC_ZONE_SEPARATOR : string = 's';

    public static UNC_RANGE_SEPARATOR : string; public static UNC_RANGE_SEPARATOR_$LI$() : string { if(IPv6Address.UNC_RANGE_SEPARATOR == null) IPv6Address.UNC_RANGE_SEPARATOR = Address.ALTERNATIVE_RANGE_SEPARATOR; return IPv6Address.UNC_RANGE_SEPARATOR; };

    public static UNC_RANGE_SEPARATOR_STR : string; public static UNC_RANGE_SEPARATOR_STR_$LI$() : string { if(IPv6Address.UNC_RANGE_SEPARATOR_STR == null) IPv6Address.UNC_RANGE_SEPARATOR_STR = /* valueOf */new String(IPv6Address.UNC_RANGE_SEPARATOR_$LI$()).toString(); return IPv6Address.UNC_RANGE_SEPARATOR_STR; };

    public static UNC_SUFFIX : string = ".ipv6-literal.net";

    public static REVERSE_DNS_SUFFIX : string = ".ip6.arpa";

    public static REVERSE_DNS_SUFFIX_DEPRECATED : string = ".ip6.int";

    public static BITS_PER_SEGMENT : number = 16;

    public static BYTES_PER_SEGMENT : number = 2;

    public static SEGMENT_COUNT : number = 8;

    public static MIXED_REPLACED_SEGMENT_COUNT : number = 2;

    public static MIXED_ORIGINAL_SEGMENT_COUNT : number = 6;

    public static BYTE_COUNT : number = 16;

    public static BIT_COUNT : number = 128;

    public static DEFAULT_TEXTUAL_RADIX : number = 16;

    public static MAX_VALUE_PER_SEGMENT : number = 65535;

    /*private*/ zone : string;

    /*private*/ valueCache : IPv6Address.ValueCache;

    /*private*/ stringCache : IPv6AddressSection.IPv6StringCache;

    sectionCache : IPv6AddressSection.AddressCache;

    public constructor(bytes? : any, byteStartIndex? : any, byteEndIndex? : any, networkPrefixLength? : any, zone? : any) {
        if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
            let __args = Array.prototype.slice.call(arguments);
            super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                this.zone = IPv6Address.checkZone(zone);
            })();
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((networkPrefixLength != null && (networkPrefixLength["__interfaces"] != null && networkPrefixLength["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || networkPrefixLength.constructor != null && networkPrefixLength.constructor["__interfaces"] != null && networkPrefixLength.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof networkPrefixLength === "string")) || networkPrefixLength === null) && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let networkPrefixLength : any = __args[2];
            let zone : any = __args[3];
            super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                this.zone = IPv6Address.checkZone(zone);
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && ((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((byteEndIndex != null && (byteEndIndex["__interfaces"] != null && byteEndIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteEndIndex.constructor != null && byteEndIndex.constructor["__interfaces"] != null && byteEndIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteEndIndex === "string")) || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let networkPrefixLength : any = __args[1];
            let zone : any = __args[2];
            super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                if(segments.length !== IPv6Address.SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", segments.length);
                }
                this.zone = IPv6Address.checkZone(zone);
            })();
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((byteEndIndex != null && (byteEndIndex["__interfaces"] != null && byteEndIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteEndIndex.constructor != null && byteEndIndex.constructor["__interfaces"] != null && byteEndIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteEndIndex === "string")) || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            let networkPrefixLength : any = __args[1];
            let zone : any = __args[2];
            super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSectionInternal$byte_A$int$java_lang_Integer(val.toByteArray(), IPv6Address.SEGMENT_COUNT, networkPrefixLength));
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                this.zone = IPv6Address.checkZone(zone);
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((byteEndIndex != null && (byteEndIndex["__interfaces"] != null && byteEndIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteEndIndex.constructor != null && byteEndIndex.constructor["__interfaces"] != null && byteEndIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteEndIndex === "string")) || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let networkPrefixLength : any = __args[1];
            let zone : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let byteStartIndex : any = 0;
                let byteEndIndex : any = __args[0].length;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let networkPrefixLength : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && ((byteEndIndex != null && (byteEndIndex["__interfaces"] != null && byteEndIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteEndIndex.constructor != null && byteEndIndex.constructor["__interfaces"] != null && byteEndIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteEndIndex === "string")) || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            let zone : any = __args[2];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((byteStartIndex != null && byteStartIndex instanceof <any>MACAddressSection) || byteStartIndex === null) && ((byteEndIndex != null && (byteEndIndex["__interfaces"] != null && byteEndIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteEndIndex.constructor != null && byteEndIndex.constructor["__interfaces"] != null && byteEndIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteEndIndex === "string")) || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            let eui : any = __args[1];
            let zone : any = __args[2];
            super((thisAddress) => IPv6Address.toFullEUI64Section(section, eui, (<IPv6Address>thisAddress).getDefaultCreator(), (<IPv6Address>thisAddress).getMACNetwork().getAddressCreator()));
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                this.zone = IPv6Address.checkZone(zone);
            })();
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteStartIndex === "string")) || byteStartIndex === null) && ((typeof byteEndIndex === 'boolean') || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            let zone : any = __args[1];
            let checkZone : any = __args[2];
            super(section);
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            if(this.zone===undefined) this.zone = null;
            if(this.valueCache===undefined) this.valueCache = null;
            if(this.stringCache===undefined) this.stringCache = null;
            if(this.sectionCache===undefined) this.sectionCache = null;
            (() => {
                if(section.getSegmentCount() !== IPv6Address.SEGMENT_COUNT) {
                    throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", section.getSegmentCount());
                }
                if(section.addressSegmentIndex !== 0) {
                    throw new AddressPositionException(section.addressSegmentIndex);
                }
                if(checkZone) {
                    this.zone = IPv6Address.checkZone(zone);
                } else if(zone != null && zone.length > 0) {
                    this.zone = zone.toString();
                } else {
                    this.zone = null;
                }
            })();
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && ((typeof byteEndIndex === 'number') || byteEndIndex === null) && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteStartIndex === "string")) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let checkZone : any = true;
                super(section);
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(section.getSegmentCount() !== IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", section.getSegmentCount());
                    }
                    if(section.addressSegmentIndex !== 0) {
                        throw new AddressPositionException(section.addressSegmentIndex);
                    }
                    if(checkZone) {
                        this.zone = IPv6Address.checkZone(zone);
                    } else if(zone != null && zone.length > 0) {
                        this.zone = zone.toString();
                    } else {
                        this.zone = null;
                    }
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(segments.length !== IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", segments.length);
                    }
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteStartIndex === "string")) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(segments.length !== IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", segments.length);
                    }
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteStartIndex === "string")) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSectionInternal$byte_A$int$java_lang_Integer(val.toByteArray(), IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof byteStartIndex === "string")) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            let zone : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSectionInternal$byte_A$int$java_lang_Integer(val.toByteArray(), IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((byteStartIndex != null && (byteStartIndex["__interfaces"] != null && byteStartIndex["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || byteStartIndex.constructor != null && byteStartIndex.constructor["__interfaces"] != null && byteStartIndex.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let lowerValueProvider : any = __args[0];
            let upperValueProvider : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && ((typeof byteStartIndex === 'number') || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            let networkPrefixLength : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let lowerValueProvider : any = valueProvider;
                let upperValueProvider : any = valueProvider;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zone : any = null;
                    super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6Address) || bytes === null) && ((byteStartIndex != null && byteStartIndex instanceof <any>MACAddress) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let prefix : any = __args[0];
            let eui : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let section : any = prefix.getSection();
                let eui : any = __args[1].getSection();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zone : any = null;
                    super((thisAddress) => IPv6Address.toFullEUI64Section(section, eui, (<IPv6Address>thisAddress).getDefaultCreator(), (<IPv6Address>thisAddress).getMACNetwork().getAddressCreator()));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((byteStartIndex != null && byteStartIndex instanceof <any>MACAddress) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            let eui : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let eui : any = __args[1].getSection();
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let zone : any = null;
                    super((thisAddress) => IPv6Address.toFullEUI64Section(section, eui, (<IPv6Address>thisAddress).getDefaultCreator(), (<IPv6Address>thisAddress).getMACNetwork().getAddressCreator()));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((byteStartIndex != null && byteStartIndex instanceof <any>MACAddressSection) || byteStartIndex === null) && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            let eui : any = __args[1];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = null;
                super((thisAddress) => IPv6Address.toFullEUI64Section(section, eui, (<IPv6Address>thisAddress).getDefaultCreator(), (<IPv6Address>thisAddress).getMACNetwork().getAddressCreator()));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let section : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let zone : any = <any><any>null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let checkZone : any = true;
                    super(section);
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        if(section.getSegmentCount() !== IPv6Address.SEGMENT_COUNT) {
                            throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", section.getSegmentCount());
                        }
                        if(section.addressSegmentIndex !== 0) {
                            throw new AddressPositionException(section.addressSegmentIndex);
                        }
                        if(checkZone) {
                            this.zone = IPv6Address.checkZone(zone);
                        } else if(zone != null && zone.length > 0) {
                            this.zone = zone.toString();
                        } else {
                            this.zone = null;
                        }
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let segments : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_Integer(segments, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    if(segments.length !== IPv6Address.SEGMENT_COUNT) {
                        throw new AddressValueException("ipaddress.error.ipv6.invalid.segment.count", segments.length);
                    }
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && bytes instanceof <any>Inet6Address) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let inet6Address : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let bytes : any = inet6Address.getAddress();
                let zone : any = IPv6Address.getZone(inet6Address);
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let networkPrefixLength : any = null;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let byteStartIndex : any = 0;
                        let byteEndIndex : any = __args[0].length;
                        super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                        if(this.zone===undefined) this.zone = null;
                        if(this.valueCache===undefined) this.valueCache = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.zone===undefined) this.zone = null;
                        if(this.valueCache===undefined) this.valueCache = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        (() => {
                            this.zone = IPv6Address.checkZone(zone);
                        })();
                    }
                }
            }
        } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let zone : any = null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let byteStartIndex : any = 0;
                    let byteEndIndex : any = __args[0].length;
                    super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSection$byte_A$int$int$int$java_lang_Integer(bytes, byteStartIndex, byteEndIndex, IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    if(this.zone===undefined) this.zone = null;
                    if(this.valueCache===undefined) this.valueCache = null;
                    if(this.stringCache===undefined) this.stringCache = null;
                    if(this.sectionCache===undefined) this.sectionCache = null;
                    (() => {
                        this.zone = IPv6Address.checkZone(zone);
                    })();
                }
            }
        } else if(((bytes != null && bytes instanceof <any>BigInteger) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let val : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = null;
                let zone : any = null;
                super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createSectionInternal$byte_A$int$java_lang_Integer(val.toByteArray(), IPv6Address.SEGMENT_COUNT, networkPrefixLength));
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                if(this.zone===undefined) this.zone = null;
                if(this.valueCache===undefined) this.valueCache = null;
                if(this.stringCache===undefined) this.stringCache = null;
                if(this.sectionCache===undefined) this.sectionCache = null;
                (() => {
                    this.zone = IPv6Address.checkZone(zone);
                })();
            }
        } else if(((bytes != null && (bytes["__interfaces"] != null && bytes["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || bytes.constructor != null && bytes.constructor["__interfaces"] != null && bytes.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || bytes === null) && byteStartIndex === undefined && byteEndIndex === undefined && networkPrefixLength === undefined && zone === undefined) {
            let __args = Array.prototype.slice.call(arguments);
            let valueProvider : any = __args[0];
            {
                let __args = Array.prototype.slice.call(arguments);
                let networkPrefixLength : any = <number>null;
                {
                    let __args = Array.prototype.slice.call(arguments);
                    let lowerValueProvider : any = valueProvider;
                    let upperValueProvider : any = valueProvider;
                    {
                        let __args = Array.prototype.slice.call(arguments);
                        let zone : any = null;
                        super((thisAddress) => (<IPv6Address>thisAddress).getDefaultCreator().createFullSectionInternal(lowerValueProvider, upperValueProvider, networkPrefixLength));
                        if(this.zone===undefined) this.zone = null;
                        if(this.valueCache===undefined) this.valueCache = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        if(this.zone===undefined) this.zone = null;
                        if(this.valueCache===undefined) this.valueCache = null;
                        if(this.stringCache===undefined) this.stringCache = null;
                        if(this.sectionCache===undefined) this.sectionCache = null;
                        (() => {
                            this.zone = IPv6Address.checkZone(zone);
                        })();
                    }
                }
            }
        } else throw new Error('invalid overload');
    }

    static checkZone(zone : any) : string {
        if(zone == null || zone.length === 0) {
            return null;
        }
        let invalidIndex : number = Validator.validateZone(zone);
        if(invalidIndex >= 0) {
            throw new AddressValueException("ipaddress.error.invalid.zone", invalidIndex);
        }
        return zone.toString();
    }

    getDefaultCreator() : IPv6AddressNetwork.IPv6AddressCreator {
        return this.getNetwork().getAddressCreator();
    }

    getCreator() : IPv6AddressNetwork.IPv6AddressCreator {
        if(!this.hasZone()) {
            return this.getDefaultCreator();
        }
        return new IPv6Address.IPv6Address$0(this, this.getNetwork());
    }

    static getZone(inet6Address : Inet6Address) : any {
        let networkInterface : NetworkInterface = inet6Address.getScopedInterface();
        let zone : string = null;
        if(networkInterface == null) {
            let scopeId : number = inet6Address.getScopeId();
            if(scopeId !== 0) {
                zone = /* toString */(''+(scopeId));
            }
        } else {
            zone = networkInterface.getName();
        }
        return zone;
    }

    static toFullEUI64Section(section : IPv6AddressSection, eui : MACAddressSection, creator : IPv6AddressNetwork.IPv6AddressCreator, macCreator : MACAddressNetwork.MACAddressCreator) : IPv6AddressSection {
        let euiIsExtended : boolean = eui.isExtended();
        if(eui.addressSegmentIndex !== 0) {
            throw new AddressPositionException(eui, eui.addressSegmentIndex);
        }
        if(section.addressSegmentIndex !== 0) {
            throw new AddressPositionException(section, section.addressSegmentIndex);
        }
        if(section.getSegmentCount() < 4) {
            throw new AddressValueException(section, "ipaddress.mac.error.not.eui.convertible");
        }
        if(eui.getSegmentCount() !== (euiIsExtended?MACAddress.EXTENDED_UNIQUE_IDENTIFIER_64_SEGMENT_COUNT:MACAddress.EXTENDED_UNIQUE_IDENTIFIER_48_SEGMENT_COUNT_$LI$())) {
            throw new AddressValueException(eui, "ipaddress.mac.error.not.eui.convertible");
        }
        let segments : IPv6AddressSegment[] = creator.createSegmentArray(8);
        section.getSegments$int$int$inet_ipaddr_AddressSegment_A$int(0, 4, segments, 0);
        let prefLength : number = section.getNetworkPrefixLength();
        let prefixLength : number = prefLength != null && (prefLength <= 64)?prefLength:null;
        IPv6Address.toEUI64Segments(segments, 4, eui, 0, eui.isExtended(), creator, macCreator, prefixLength);
        return creator.createSectionInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(segments);
    }

    static toEUI64Segments(segments : IPv6AddressSegment[], ipv6StartIndex : number, eui : MACAddressSection, euiStartIndex : number, isExtended : boolean, creator : IPv6AddressNetwork.IPv6AddressCreator, macCreator : MACAddressNetwork.MACAddressCreator, prefixLength : number) : IPv6AddressSegment[] {
        let euiSegmentIndex : number = 0;
        let euiSegmentCount : number = eui.getSegmentCount();
        let seg0 : MACAddressSegment;
        let seg1 : MACAddressSegment;
        let seg2 : MACAddressSegment;
        let seg3 : MACAddressSegment;
        let seg4 : MACAddressSegment;
        let seg5 : MACAddressSegment;
        let seg6 : MACAddressSegment;
        let seg7 : MACAddressSegment;
        seg0 = (euiStartIndex === 0 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg1 = (euiStartIndex <= 1 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg2 = (euiStartIndex <= 2 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg3 = (euiStartIndex <= 3 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg4 = (euiStartIndex <= 4 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg5 = (euiStartIndex <= 5 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg6 = (euiStartIndex <= 6 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex++):null;
        seg7 = (euiStartIndex <= 7 && euiSegmentIndex < euiSegmentCount)?eui.getSegment(euiSegmentIndex):null;
        let isNotNull : boolean;
        let zeroSegment : MACAddressSegment = macCreator.createSegment$int(0);
        let ffSegment : MACAddressSegment = macCreator.createSegment$int(255);
        let feSegment : MACAddressSegment = macCreator.createSegment$int(254);
        let currentPrefix : number = null;
        if(prefixLength != null) {
            currentPrefix = 0;
        }
        if((isNotNull = (seg0 != null)) || seg1 != null) {
            if(isNotNull) {
                if(seg1 == null) {
                    seg1 = zeroSegment;
                }
            } else {
                seg0 = zeroSegment;
            }
            segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$boolean$java_lang_Integer(creator, seg0, seg1, true, currentPrefix);
        }
        if(isExtended) {
            if((isNotNull = (seg2 != null)) || seg3 != null) {
                if(!isNotNull) {
                    seg2 = zeroSegment;
                    if(!seg3.matches$int(255)) {
                        throw new IncompatibleAddressException(eui, "ipaddress.mac.error.not.eui.convertible");
                    }
                }
                segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, seg2, ffSegment, currentPrefix);
            }
            if((isNotNull = (seg4 != null)) || seg5 != null) {
                if(isNotNull) {
                    if(!seg4.matches$int(254)) {
                        throw new IncompatibleAddressException(eui, "ipaddress.mac.error.not.eui.convertible");
                    }
                    if(seg5 == null) {
                        seg5 = zeroSegment;
                    }
                }
                segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, feSegment, seg5, currentPrefix);
            }
        } else {
            if(seg2 != null) {
                segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, seg2, ffSegment, currentPrefix);
            }
            if(seg3 != null) {
                segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, feSegment, seg3, currentPrefix);
            }
            if((isNotNull = (seg4 != null)) || seg5 != null) {
                if(isNotNull) {
                    if(seg5 == null) {
                        seg5 = zeroSegment;
                    }
                } else {
                    seg4 = zeroSegment;
                }
                segments[ipv6StartIndex++] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, seg4, seg5, currentPrefix);
            }
        }
        if((isNotNull = (seg6 != null)) || seg7 != null) {
            if(isNotNull) {
                if(seg7 == null) {
                    seg7 = zeroSegment;
                }
            } else {
                seg6 = zeroSegment;
            }
            segments[ipv6StartIndex] = IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, seg6, seg7, currentPrefix);
        }
        return segments;
    }

    static join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator : IPv6AddressNetwork.IPv6AddressCreator, macSegment0 : MACAddressSegment, macSegment1 : MACAddressSegment, prefixLength : number) : IPv6AddressSegment {
        return IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$boolean$java_lang_Integer(creator, macSegment0, macSegment1, false, prefixLength);
    }

    public static join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$boolean$java_lang_Integer(creator : IPv6AddressNetwork.IPv6AddressCreator, macSegment0 : MACAddressSegment, macSegment1 : MACAddressSegment, flip : boolean, prefixLength : number) : IPv6AddressSegment {
        let lower0 : number = macSegment0.getLowerSegmentValue();
        let upper0 : number = macSegment0.getUpperSegmentValue();
        if(flip) {
            let mask2ndBit : number = 2;
            if(!macSegment0.matchesWithMask$int$int(mask2ndBit & lower0, mask2ndBit)) {
                throw new IncompatibleAddressException(macSegment0, "ipaddress.mac.error.not.eui.convertible");
            }
            lower0 ^= mask2ndBit;
            upper0 ^= mask2ndBit;
        }
        return creator.createSegment$int$int$java_lang_Integer((lower0 << 8) | macSegment1.getLowerSegmentValue(), (upper0 << 8) | macSegment1.getUpperSegmentValue(), prefixLength);
    }

    public static join(creator? : any, macSegment0? : any, macSegment1? : any, flip? : any, prefixLength? : any) : any {
        if(((creator != null && creator instanceof <any>IPv6AddressNetwork.IPv6AddressCreator) || creator === null) && ((macSegment0 != null && macSegment0 instanceof <any>MACAddressSegment) || macSegment0 === null) && ((macSegment1 != null && macSegment1 instanceof <any>MACAddressSegment) || macSegment1 === null) && ((typeof flip === 'boolean') || flip === null) && ((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$boolean$java_lang_Integer(creator, macSegment0, macSegment1, flip, prefixLength);
        } else if(((creator != null && creator instanceof <any>IPv6AddressNetwork.IPv6AddressCreator) || creator === null) && ((macSegment0 != null && macSegment0 instanceof <any>MACAddressSegment) || macSegment0 === null) && ((macSegment1 != null && macSegment1 instanceof <any>MACAddressSegment) || macSegment1 === null) && ((typeof flip === 'number') || flip === null) && prefixLength === undefined) {
            return <any>IPv6Address.join$inet_ipaddr_ipv6_IPv6AddressNetwork_IPv6AddressCreator$inet_ipaddr_mac_MACAddressSegment$inet_ipaddr_mac_MACAddressSegment$java_lang_Integer(creator, macSegment0, macSegment1, flip);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv6AddressNetwork}
     */
    public getNetwork() : IPv6AddressNetwork {
        return Address.defaultIpv6Network();
    }

    public getMACNetwork() : MACAddressNetwork {
        return Address.defaultMACNetwork();
    }

    public getIPv4Network() : IPv4AddressNetwork {
        return Address.defaultIpv4Network();
    }

    public getSection$() : IPv6AddressSection {
        return <IPv6AddressSection>super.getSection();
    }

    public getSection$int(index : number) : IPv6AddressSection {
        return this.getSection().getSection$int(index);
    }

    public getSection$int$int(index : number, endIndex : number) : IPv6AddressSection {
        return this.getSection().getSection$int$int(index, endIndex);
    }

    /**
     * 
     * @param {number} index
     * @param {number} endIndex
     * @return {IPv6AddressSection}
     */
    public getSection(index? : any, endIndex? : any) : any {
        if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            return <any>this.getSection$int$int(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && ((typeof endIndex === 'number') || endIndex === null)) {
            super.getSection(index, endIndex);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(((typeof index === 'number') || index === null) && endIndex === undefined) {
            return <any>this.getSection$int(index);
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else if(index === undefined && endIndex === undefined) {
            return <any>this.getSection$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {number} index
     * @return {IPv6AddressSegment}
     */
    public getDivision(index : number) : IPv6AddressSegment {
        return this.getSegment(index);
    }

    /**
     * 
     * @param {number} index
     * @return {IPv6AddressSegment}
     */
    public getSegment(index : number) : IPv6AddressSegment {
        return this.getSection().getSegment(index);
    }

    /**
     * 
     * @param {number} start
     * @param {number} end
     * @param {Array} segs
     * @param {number} index
     */
    public getSegments(start? : any, end? : any, segs? : any, index? : any) : any {
        if(((typeof start === 'number') || start === null) && ((typeof end === 'number') || end === null) && ((segs != null && segs instanceof <any>Array && (segs.length==0 || segs[0] == null ||(segs[0] != null && (segs[0]["__interfaces"] != null && segs[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || segs[0].constructor != null && segs[0].constructor["__interfaces"] != null && segs[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || segs === null) && ((typeof index === 'number') || index === null)) {
            super.getSegments(start, end, segs, index);
        } else if(((start != null && start instanceof <any>Array && (start.length==0 || start[0] == null ||(start[0] != null && (start[0]["__interfaces"] != null && start[0]["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0 || start[0].constructor != null && start[0].constructor["__interfaces"] != null && start[0].constructor["__interfaces"].indexOf("inet.ipaddr.AddressSegment") >= 0)))) || start === null) && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$inet_ipaddr_AddressSegment_A(start);
        } else if(start === undefined && end === undefined && segs === undefined && index === undefined) {
            return <any>this.getSegments$();
        } else throw new Error('invalid overload');
    }

    public getSegments$() : IPv6AddressSegment[] {
        return this.getSection().getSegments();
    }

    public isEUI64() : boolean {
        return this.getSection().isEUI64();
    }

    public toEUI(extended : boolean) : MACAddress {
        let section : MACAddressSection = this.getSection().toEUI(extended);
        if(section == null) {
            return null;
        }
        let creator : MACAddressNetwork.MACAddressCreator = this.getMACNetwork().getAddressCreator();
        return creator.createAddress$inet_ipaddr_mac_MACAddressSection(section);
    }

    public getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options : IPAddressSection.IPStringBuilderOptions) : IPAddressStringDivisionSeries[] {
        return this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.from(options));
    }

    public getParts$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(options : IPv6AddressSection.IPv6StringBuilderOptions) : IPAddressStringDivisionSeries[] {
        let parts : IPAddressStringDivisionSeries[] = this.getSection().getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        let ipv4Addr : IPv4Address = this.getConverted(options);
        if(ipv4Addr != null) {
            let ipv4Parts : IPAddressStringDivisionSeries[] = ipv4Addr.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options.ipv4ConverterOptions);
            let tmp : IPAddressStringDivisionSeries[] = parts;
            parts = (s => { let a=[]; while(s-->0) a.push(null); return a; })(tmp.length + ipv4Parts.length);
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(tmp, 0, parts, 0, tmp.length);
            /* arraycopy */((srcPts, srcOff, dstPts, dstOff, size) => { if(srcPts !== dstPts || dstOff >= srcOff + size) { while (--size >= 0) dstPts[dstOff++] = srcPts[srcOff++];} else { let tmp = srcPts.slice(srcOff, srcOff + size); for (let i = 0; i < size; i++) dstPts[dstOff++] = tmp[i]; }})(ipv4Parts, 0, parts, tmp.length, ipv4Parts.length);
        }
        return parts;
    }

    public getParts(options? : any) : any {
        if(((options != null && options instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(options);
        } else if(((options != null && options instanceof <any>IPAddressSection.IPStringBuilderOptions) || options === null)) {
            return <any>this.getParts$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(options);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {number}
     */
    public getSegmentCount() : number {
        return IPv6Address.SEGMENT_COUNT;
    }

    /**
     * 
     * @return {number}
     */
    public getByteCount() : number {
        return IPv6Address.BYTE_COUNT;
    }

    /**
     * 
     * @return {number}
     */
    public getBitCount() : number {
        return IPv6Address.BIT_COUNT;
    }

    getLowestOrHighest(lowest : boolean, excludeZeroHost : boolean) : IPv6Address {
        let currentSection : IPv6AddressSection = this.getSection();
        let sectionResult : IPv6AddressSection = currentSection.getLowestOrHighestSection(lowest, excludeZeroHost);
        if(sectionResult === currentSection) {
            return this;
        } else if(sectionResult == null) {
            return null;
        }
        let result : IPv6Address = null;
        let cache : IPv6AddressSection.AddressCache = this.sectionCache;
        if(cache == null || (result = lowest?(excludeZeroHost?cache.lowerNonZeroHost:cache.lower):cache.upper) == null) {
            {
                cache = this.sectionCache;
                let create : boolean = (cache == null);
                if(create) {
                    this.sectionCache = cache = new IPv6AddressSection.AddressCache();
                } else {
                    if(lowest) {
                        if(excludeZeroHost) {
                            create = (result = cache.lowerNonZeroHost) == null;
                        } else {
                            create = (result = cache.lower) == null;
                        }
                    } else {
                        create = (result = cache.upper) == null;
                    }
                }
                if(create) {
                    result = this.getCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(sectionResult);
                    if(lowest) {
                        if(excludeZeroHost) {
                            cache.lowerNonZeroHost = result;
                        } else {
                            cache.lower = result;
                        }
                    } else {
                        cache.upper = result;
                    }
                }
            };
        }
        return result;
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public getLowerNonZeroHost() : IPv6Address {
        return this.getLowestOrHighest(true, true);
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public getLower() : IPv6Address {
        return this.getLowestOrHighest(true, false);
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public getUpper() : IPv6Address {
        return this.getLowestOrHighest(false, false);
    }

    /**
     * Replaces segments starting from startIndex and ending before endIndex with the same number of segments starting at replacementStartIndex from the replacement section
     * 
     * @param {number} startIndex
     * @param {number} endIndex
     * @param {IPv6Address} replacement
     * @param {number} replacementIndex
     * @throws IndexOutOfBoundsException
     * @return
     * @return {IPv6Address}
     */
    public replace(startIndex : number, endIndex : number, replacement : IPv6Address, replacementIndex : number) : IPv6Address {
        return this.checkIdentity(this.getSection().replace$int$int$inet_ipaddr_ipv6_IPv6AddressSection$int$int(startIndex, endIndex, replacement.getSection(), replacementIndex, replacementIndex + (endIndex - startIndex)));
    }

    public reverseBits$boolean(perByte : boolean) : IPv6Address {
        let creator : IPv6AddressNetwork.IPv6AddressCreator = this.getCreator();
        return creator.createAddress$inet_ipaddr_ipv6_IPv6AddressSection(this.getSection().reverseBits$boolean(perByte));
    }

    /**
     * 
     * @param {boolean} perByte
     * @return {IPv6Address}
     */
    public reverseBits(perByte? : any) : any {
        if(((typeof perByte === 'boolean') || perByte === null)) {
            return <any>this.reverseBits$boolean(perByte);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public reverseBytes() : IPv6Address {
        return this.checkIdentity(this.getSection().reverseBytes());
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public reverseBytesPerSegment() : IPv6Address {
        return this.checkIdentity(this.getSection().reverseBytesPerSegment());
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public reverseSegments() : IPv6Address {
        return this.checkIdentity(this.getSection().reverseSegments());
    }

    /**
     * 
     * @return {*}
     */
    public segmentsNonZeroHostIterator() : any {
        return this.getSection().segmentsNonZeroHostIterator();
    }

    public segmentsIterator(excludeZeroHosts? : any) : any {
        if(excludeZeroHosts === undefined) {
            return <any>this.segmentsIterator$();
        } else throw new Error('invalid overload');
    }

    public segmentsIterator$() : any {
        return this.getSection().segmentsIterator();
    }

    public prefixBlockIterator(original? : any, creator? : any) : any {
        if(original === undefined && creator === undefined) {
            return <any>this.prefixBlockIterator$();
        } else throw new Error('invalid overload');
    }

    public prefixBlockIterator$() : any {
        return this.getSection().prefixBlockIterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator(this, this.getCreator());
    }

    public iterator<S extends AddressSegment>(segmentCreator? : any, segSupplier? : any, segIteratorProducer? : any, excludeFunc? : any, networkSegmentIndex? : any, hostSegmentIndex? : any, prefixedSegIteratorProducer? : any) : any {
        if(segmentCreator === undefined && segSupplier === undefined && segIteratorProducer === undefined && excludeFunc === undefined && networkSegmentIndex === undefined && hostSegmentIndex === undefined && prefixedSegIteratorProducer === undefined) {
            return <any>this.iterator$();
        } else throw new Error('invalid overload');
    }

    public iterator$() : any {
        return this.getSection().iterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator$boolean(this, this.getCreator(), false);
    }

    /**
     * 
     * @return {*}
     */
    public nonZeroHostIterator() : any {
        return this.getSection().iterator$inet_ipaddr_ipv6_IPv6Address$inet_ipaddr_format_AddressCreator$boolean(this, this.getCreator(), true);
    }

    /**
     * 
     * @return {*}
     */
    public getIterable() : java.lang.Iterable<IPv6Address> {
        return this;
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv6Address}
     */
    public increment(increment : number) : IPv6Address {
        return this.checkIdentity(this.getSection().increment(increment));
    }

    /**
     * 
     * @param {number} increment
     * @return {IPv6Address}
     */
    public incrementBoundary(increment : number) : IPv6Address {
        return this.checkIdentity(this.getSection().incrementBoundary(increment));
    }

    /**
     * If this address is IPv4 convertible, returns that address.
     * Otherwise, returns null.
     * <p>
     * This uses {@link #isIPv4Convertible()} to determine convertibility, and that uses an instance of {@link IPAddressConverter.DefaultAddressConverter} which uses IPv4-mapped address mappings from rfc 4038.
     * <p>
     * Override this method and {@link IPv6Address#isIPv4Convertible()} if you wish to map IPv6 to IPv4 according to the mappings defined by
     * in {@link IPv6Address#isIPv4Compatible()}, {@link IPv6Address#isIPv4Mapped()}, {@link IPv6Address#is6To4()} or by some other mapping.
     * <p>
     * For the reverse mapping, see {@link IPv4Address#toIPv6()}
     * @return {IPv4Address}
     */
    public toIPv4() : IPv4Address {
        let conv : IPAddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
        if(conv != null) {
            return conv.toIPv4(this);
        }
        return null;
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public toIPv6() : IPv6Address {
        return this;
    }

    /**
     * Determines whether this address can be converted to IPv4.
     * Override this method to convert in your own way.
     * The default behaviour is to use isIPv4Mapped()
     * 
     * You should also override {@link #toIPv4()} to match the conversion.
     * 
     * @return
     * @return {boolean}
     */
    public isIPv4Convertible() : boolean {
        let conv : IPAddressConverter = IPAddress.DEFAULT_ADDRESS_CONVERTER_$LI$();
        return conv != null && conv.isIPv4Convertible(this);
    }

    /**
     * 
     * @return {boolean}
     */
    public isIPv6Convertible() : boolean {
        return true;
    }

    /**
     * ::ffff:x:x/96 indicates IPv6 address mapped to IPv4
     * @return {IPv4AddressSection}
     */
    public toMappedIPv4Segments() : IPv4AddressSection {
        if(this.isIPv4Mapped()) {
            return this.getSection().getEmbeddedIPv4AddressSection();
        }
        return null;
    }

    /**
     * Returns the second and third bytes as an {@link IPv4Address}.
     * 
     * This can be used for IPv4 or for IPv6 6to4 addresses convertible to IPv4.
     * 
     * @return {IPv4Address} the address
     */
    public get6to4IPv4Address() : IPv4Address {
        return this.getEmbeddedIPv4Address$int(2);
    }

    public getEmbeddedIPv4Address$() : IPv4Address {
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getIPv4Network().getAddressCreator();
        return creator.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(this.getSection().getEmbeddedIPv4AddressSection());
    }

    public getEmbeddedIPv4Address$int(byteIndex : number) : IPv4Address {
        if(byteIndex === IPv6Address.MIXED_ORIGINAL_SEGMENT_COUNT * IPv6Address.BYTES_PER_SEGMENT) {
            return this.getEmbeddedIPv4Address();
        }
        let creator : IPv4AddressNetwork.IPv4AddressCreator = this.getIPv4Network().getAddressCreator();
        return creator.createAddress$inet_ipaddr_ipv4_IPv4AddressSection(this.getSection().getEmbeddedIPv4AddressSection$int$int(byteIndex, byteIndex + IPv4Address.BYTE_COUNT));
    }

    /**
     * Produces an IPv4 address from any sequence of 4 bytes in this IPv6 address.
     * 
     * @param {number} byteIndex the byte index to start
     * @throws IndexOutOfBoundsException if the index is less than zero or bigger than 7
     * @return
     * @return {IPv4Address}
     */
    public getEmbeddedIPv4Address(byteIndex? : any) : any {
        if(((typeof byteIndex === 'number') || byteIndex === null)) {
            return <any>this.getEmbeddedIPv4Address$int(byteIndex);
        } else if(byteIndex === undefined) {
            return <any>this.getEmbeddedIPv4Address$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {boolean}
     */
    public isLocal() : boolean {
        if(this.isMulticast()) {
            let firstSeg : IPv6AddressSegment = this.getSegment(0);
            if(firstSeg.matchesWithMask$int$int(8, 15)) {
                return true;
            }
            if(firstSeg.getValueCount() <= 5 && (firstSeg.getLowerSegmentValue() & 15) >= 1 && (firstSeg.getUpperSegmentValue() & 15) <= 5) {
                return true;
            }
            if(firstSeg.matchesWithPrefixMask$int$java_lang_Integer(65328, 12) && this.getSegment(6).matchesWithPrefixMask$int$java_lang_Integer(32768, 1)) {
                return true;
            }
        }
        return this.isLinkLocal() || this.isSiteLocal() || this.isUniqueLocal() || this.isAnyLocal();
    }

    /**
     * @see java.net.InetAddress#isLinkLocalAddress()
     * @return {boolean}
     */
    public isLinkLocal() : boolean {
        let firstSeg : IPv6AddressSegment = this.getSegment(0);
        return (this.isMulticast() && firstSeg.matchesWithMask$int$int(2, 15)) || firstSeg.matchesWithPrefixMask$int$java_lang_Integer(65152, 10);
    }

    /**
     * @see java.net.InetAddress#isSiteLocalAddress()
     * @return {boolean}
     */
    public isSiteLocal() : boolean {
        let firstSeg : IPv6AddressSegment = this.getSegment(0);
        return (this.isMulticast() && firstSeg.matchesWithMask$int$int(5, 15)) || firstSeg.matchesWithPrefixMask$int$java_lang_Integer(65216, 10);
    }

    public isUniqueLocal() : boolean {
        return this.getSegment(0).matchesWithPrefixMask$int$java_lang_Integer(64512, 7);
    }

    /**
     * Whether the address is IPv4-mapped
     * 
     * ::ffff:x:x/96 indicates IPv6 address mapped to IPv4
     * @return {boolean}
     */
    public isIPv4Mapped() : boolean {
        if(this.getSegment(5).matches$int(IPv6Address.MAX_VALUE_PER_SEGMENT)) {
            for(let i : number = 0; i < 5; i++) {
                if(!this.getSegment(i).isZero()) {
                    return false;
                }
            };
            return true;
        }
        return false;
    }

    /**
     * Whether the address is IPv4-compatible
     * 
     * @see java.net.Inet6Address#isIPv4CompatibleAddress()
     * @return {boolean}
     */
    public isIPv4Compatible() : boolean {
        return this.getSegment(0).isZero() && this.getSegment(1).isZero() && this.getSegment(2).isZero() && this.getSegment(3).isZero() && this.getSegment(4).isZero() && this.getSegment(5).isZero();
    }

    /**
     * Whether the address is IPv6 to IPv4 relay
     * @see #get6to4IPv4Address()
     * @return {boolean}
     */
    public is6To4() : boolean {
        return this.getSegment(0).matches$int(8194);
    }

    /**
     * Whether the address is 6over4
     * @return {boolean}
     */
    public is6Over4() : boolean {
        return this.getSegment(4).isZero() && this.getSegment(5).isZero();
    }

    /**
     * Whether the address is Teredo
     * @return {boolean}
     */
    public isTeredo() : boolean {
        return this.getSegment(0).matches$int(8193) && this.getSegment(1).isZero();
    }

    /**
     * Whether the address is ISATAP
     * @return {boolean}
     */
    public isIsatap() : boolean {
        return this.getSegment(4).isZero() && this.getSegment(5).matches$int(24318);
    }

    /**
     * 
     * @return {boolean} Whether the address is IPv4 translatable as in rfc 2765
     */
    public isIPv4Translatable() : boolean {
        if(this.getSegment(4).matches$int(65535) && this.getSegment(5).isZero()) {
            for(let i : number = 0; i < 3; i++) {
                if(!this.getSegment(i).isZero()) {
                    return false;
                }
            };
            return true;
        }
        return false;
    }

    /**
     * Whether the address has the well-known prefix for IPv4 translatable addresses as in rfc 6052 and 6144
     * @return
     * @return {boolean}
     */
    public isWellKnownIPv4Translatable() : boolean {
        if(this.getSegment(0).matches$int(100) && this.getSegment(1).matches$int(65435)) {
            for(let i : number = 2; i <= 5; i++) {
                if(!this.getSegment(i).isZero()) {
                    return false;
                }
            };
            return true;
        }
        return false;
    }

    /**
     * 
     * @return {boolean}
     */
    public isMulticast() : boolean {
        return this.getSegment(0).matchesWithPrefixMask$int$java_lang_Integer(255, 8);
    }

    /**
     * @see java.net.InetAddress#isLoopbackAddress()
     * @return {boolean}
     */
    public isLoopback() : boolean {
        let i : number = 0;
        for(; i < this.getSegmentCount() - 1; i++) {
            if(!this.getSegment(i).isZero()) {
                return false;
            }
        };
        return this.getSegment(i).matches$int(1);
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {IPv6Address}
     */
    public intersect(other : IPAddress) : IPv6Address {
        let thisSection : IPv6AddressSection = this.getSection();
        let otherAddr : IPv6Address = this.convertArg(other);
        let section : IPv6AddressSection = thisSection.intersect(otherAddr.getSection());
        if(section == null) {
            return null;
        }
        let creator : IPv6AddressNetwork.IPv6AddressCreator = Objects.equals(this.zone, otherAddr.zone)?this.getCreator():this.getDefaultCreator();
        let result : IPv6Address = creator.createAddress$inet_ipaddr_ipv6_IPv6AddressSection(section);
        return result;
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {Array}
     */
    public subtract(other : IPAddress) : IPv6Address[] {
        let thisSection : IPv6AddressSection = this.getSection();
        let sections : IPv6AddressSection[] = thisSection.subtract(this.convertArg(other).getSection());
        if(sections == null) {
            return null;
        }
        let result : IPv6Address[] = (s => { let a=[]; while(s-->0) a.push(null); return a; })(sections.length);
        for(let i : number = 0; i < result.length; i++) {
            result[i] = this.getCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(sections[i]);
        };
        return result;
    }

    checkIdentity(newSection : IPv6AddressSection) : IPv6Address {
        if(newSection === this.getSection()) {
            return this;
        }
        return this.getCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(newSection);
    }

    public adjustPrefixBySegment$boolean(nextSegment : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean(nextSegment));
    }

    public adjustPrefixBySegment$boolean$boolean(nextSegment : boolean, zeroed : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed));
    }

    /**
     * 
     * @param {boolean} nextSegment
     * @param {boolean} zeroed
     * @return {IPv6Address}
     */
    public adjustPrefixBySegment(nextSegment? : any, zeroed? : any) : any {
        if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixBySegment$boolean$boolean(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixBySegment(nextSegment, zeroed);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else if(((typeof nextSegment === 'boolean') || nextSegment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixBySegment$boolean(nextSegment);
        } else throw new Error('invalid overload');
    }

    public adjustPrefixLength$int(adjustment : number) : IPv6Address {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int(adjustment));
    }

    public adjustPrefixLength$int$boolean(adjustment : number, zeroed : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().adjustPrefixLength$int$boolean(adjustment, zeroed));
    }

    /**
     * 
     * @param {number} adjustment
     * @param {boolean} zeroed
     * @return {IPv6Address}
     */
    public adjustPrefixLength(adjustment? : any, zeroed? : any) : any {
        if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.adjustPrefixLength$int$boolean(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && ((typeof zeroed === 'boolean') || zeroed === null)) {
            super.adjustPrefixLength(adjustment, zeroed);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else if(((typeof adjustment === 'number') || adjustment === null) && zeroed === undefined) {
            return <any>this.adjustPrefixLength$int(adjustment);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength(networkPrefixLength? : any, withZeros? : any, noShrink? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withZeros === 'boolean') || withZeros === null) && noShrink === undefined) {
            return <any>this.setPrefixLength$int$boolean(networkPrefixLength, withZeros);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withZeros === undefined && noShrink === undefined) {
            return <any>this.setPrefixLength$int(networkPrefixLength);
        } else throw new Error('invalid overload');
    }

    public setPrefixLength$int(prefixLength : number) : IPv6Address {
        return this.setPrefixLength$int$boolean(prefixLength, true);
    }

    public setPrefixLength$int$boolean(prefixLength : number, zeroed : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().setPrefixLength$int$boolean(prefixLength, zeroed));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6Address}
     */
    public applyPrefixLength(networkPrefixLength : number) : IPv6Address {
        return this.checkIdentity(this.getSection().applyPrefixLength(networkPrefixLength));
    }

    public removePrefixLength$() : IPv6Address {
        return this.removePrefixLength$boolean(true);
    }

    public removePrefixLength$boolean(zeroed : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().removePrefixLength$boolean(zeroed));
    }

    /**
     * 
     * @param {boolean} zeroed
     * @return {IPv6Address}
     */
    public removePrefixLength(zeroed? : any) : any {
        if(((typeof zeroed === 'boolean') || zeroed === null)) {
            return <any>this.removePrefixLength$boolean(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(((typeof zeroed === 'boolean') || zeroed === null)) {
            super.removePrefixLength(zeroed);
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else if(zeroed === undefined) {
            return <any>this.removePrefixLength$();
        } else throw new Error('invalid overload');
    }

    convertArg(arg : IPAddress) : IPv6Address {
        let converted : IPv6Address = arg.toIPv6();
        if(converted == null) {
            throw new AddressConversionException(this, arg);
        }
        return converted;
    }

    public toZeroHost$() : IPv6Address {
        if(!this.isPrefixed()) {
            let config : AddressNetwork.PrefixConfiguration = this.getNetwork().getPrefixConfiguration();
            let addr : IPv6Address = this.getNetwork().getNetworkMask(0, !AddressNetwork.PrefixConfiguration["_$wrappers"][config].allPrefixedAddressesAreSubnets());
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][config].zeroHostsAreSubnets()) {
                addr = addr.getLower();
            }
            return addr;
        }
        if(this.includesZeroHost() && this.isSingleNetwork()) {
            return this.getLower();
        }
        return this.checkIdentity(this.getSection().createZeroHost());
    }

    public toZeroHost$int(prefixLength : number) : IPv6Address {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toZeroHost();
        }
        return this.checkIdentity(this.getSection().toZeroHost$int(prefixLength));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv6Address}
     */
    public toZeroHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toZeroHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toZeroHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toZeroHost$();
        } else throw new Error('invalid overload');
    }

    public toMaxHost$() : IPv6Address {
        if(!this.isPrefixed()) {
            let resultNoPrefix : IPv6Address = this.getNetwork().getHostMask(0);
            if(AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
                return resultNoPrefix;
            }
            return resultNoPrefix.setPrefixLength$int(0);
        }
        if(this.includesMaxHost() && this.isSingleNetwork()) {
            return this.getUpper();
        }
        return this.checkIdentity(this.getSection().createMaxHost());
    }

    public toMaxHost$int(prefixLength : number) : IPv6Address {
        if(this.isPrefixed() && prefixLength === this.getNetworkPrefixLength()) {
            return this.toMaxHost();
        }
        return this.checkIdentity(this.getSection().toMaxHost$int(prefixLength));
    }

    /**
     * 
     * @param {number} prefixLength
     * @return {IPv6Address}
     */
    public toMaxHost(prefixLength? : any) : any {
        if(((typeof prefixLength === 'number') || prefixLength === null)) {
            return <any>this.toMaxHost$int(prefixLength);
        } else if(((typeof prefixLength === 'number') || prefixLength === null)) {
            super.toMaxHost(prefixLength);
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else if(prefixLength === undefined) {
            return <any>this.toMaxHost$();
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().mask$inet_ipaddr_ipv6_IPv6AddressSection$boolean(this.convertArg(mask).getSection(), retainPrefix));
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {boolean} retainPrefix
     * @return {IPv6Address}
     */
    public mask(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.mask$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            super.mask(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_IPAddress(mask);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.mask$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    public mask$inet_ipaddr_IPAddress(mask : IPAddress) : IPv6Address {
        return this.mask$inet_ipaddr_IPAddress$boolean(mask, false);
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength
     * @return {IPv6Address}
     */
    public maskNetwork(mask : IPAddress, networkPrefixLength : number) : IPv6Address {
        return this.checkIdentity(this.getSection().maskNetwork(this.convertArg(mask).getSection(), networkPrefixLength));
    }

    public bitwiseOr$inet_ipaddr_IPAddress$boolean(mask : IPAddress, retainPrefix : boolean) : IPv6Address {
        return this.checkIdentity(this.getSection().bitwiseOr$inet_ipaddr_ipv6_IPv6AddressSection$boolean(this.convertArg(mask).getSection(), retainPrefix));
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {boolean} retainPrefix
     * @return {IPv6Address}
     */
    public bitwiseOr(mask? : any, retainPrefix? : any) : any {
        if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress$boolean(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && ((typeof retainPrefix === 'boolean') || retainPrefix === null)) {
            super.bitwiseOr(mask, retainPrefix);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress(mask);
        } else if(((mask != null && mask instanceof <any>IPAddress) || mask === null) && retainPrefix === undefined) {
            return <any>this.bitwiseOr$inet_ipaddr_IPAddress(mask);
        } else throw new Error('invalid overload');
    }

    public bitwiseOr$inet_ipaddr_IPAddress(mask : IPAddress) : IPv6Address {
        return this.bitwiseOr$inet_ipaddr_IPAddress$boolean(mask, false);
    }

    /**
     * 
     * @param {IPAddress} mask
     * @param {number} networkPrefixLength
     * @return {IPv6Address}
     */
    public bitwiseOrNetwork(mask : IPAddress, networkPrefixLength : number) : IPv6Address {
        return this.checkIdentity(this.getSection().bitwiseOrNetwork(this.convertArg(mask).getSection(), networkPrefixLength));
    }

    public getNetworkSection$() : IPv6AddressSection {
        return this.getSection().getNetworkSection();
    }

    public getNetworkSection$int(networkPrefixLength : number) : IPv6AddressSection {
        return this.getSection().getNetworkSection$int(networkPrefixLength);
    }

    public getNetworkSection$int$boolean(networkPrefixLength : number, withPrefixLength : boolean) : IPv6AddressSection {
        return this.getSection().getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @param {boolean} withPrefixLength
     * @return {IPv6AddressSection}
     */
    public getNetworkSection(networkPrefixLength? : any, withPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && ((typeof withPrefixLength === 'boolean') || withPrefixLength === null)) {
            return <any>this.getNetworkSection$int$boolean(networkPrefixLength, withPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null) && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined && withPrefixLength === undefined) {
            return <any>this.getNetworkSection$();
        } else throw new Error('invalid overload');
    }

    public getHostSection$int(networkPrefixLength : number) : IPv6AddressSection {
        return this.getSection().getHostSection$int(networkPrefixLength);
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6AddressSection}
     */
    public getHostSection(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.getHostSection$int(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.getHostSection$();
        } else throw new Error('invalid overload');
    }

    public getHostSection$() : IPv6AddressSection {
        return this.getSection().getHostSection();
    }

    public toPrefixBlock$() : IPv6Address {
        let prefixLength : number = this.getNetworkPrefixLength();
        if(prefixLength == null || AddressNetwork.PrefixConfiguration["_$wrappers"][this.getNetwork().getPrefixConfiguration()].allPrefixedAddressesAreSubnets()) {
            return this;
        }
        return this.toPrefixBlock$int(prefixLength);
    }

    public toPrefixBlock$int(networkPrefixLength : number) : IPv6Address {
        return this.checkIdentity(this.getSection().toPrefixBlock$int(networkPrefixLength));
    }

    /**
     * 
     * @param {number} networkPrefixLength
     * @return {IPv6Address}
     */
    public toPrefixBlock(networkPrefixLength? : any) : any {
        if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            return <any>this.toPrefixBlock$int(networkPrefixLength);
        } else if(((typeof networkPrefixLength === 'number') || networkPrefixLength === null)) {
            super.toPrefixBlock(networkPrefixLength);
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else if(networkPrefixLength === undefined) {
            return <any>this.toPrefixBlock$();
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public assignPrefixForSingleBlock() : IPv6Address {
        return <IPv6Address>super.assignPrefixForSingleBlock();
    }

    /**
     * 
     * @return {IPv6Address}
     */
    public assignMinPrefixForBlock() : IPv6Address {
        return <IPv6Address>super.assignMinPrefixForBlock();
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {Array}
     */
    public spanWithPrefixBlocks(other : IPAddress) : IPv6Address[] {
        return IPAddress.getSpanningPrefixBlocks<any>(this, this.convertArg(other), () => { return IPv6Address.getLower() }, () => { return IPv6Address.getUpper() }, (arg0,arg1) => { return Address.DEFAULT_ADDRESS_COMPARATOR_$LI$().compare(arg0,arg1) }, () => { return IPv6Address.removePrefixLength() }, (length) => { return this.getCreator().createAddressArray(length) });
    }

    /**
     * 
     * @param {Array} addresses
     * @return {Array}
     */
    public mergePrefixBlocks(...addresses : IPAddress[]) : IPv6Address[] {
        if(addresses.length === 0) {
            return [this];
        }
        for(let i : number = 0; i < addresses.length; i++) {
            addresses[i] = this.convertArg(addresses[i]);
        };
        let blocks : Array<IPAddressSegmentSeries> = IPAddress.getMergedBlocks(this, addresses);
        return /* toArray */blocks.slice(0);
    }

    public hasZone() : boolean {
        return this.zone != null;
    }

    /**
     * The zone or scope id, which is typically appended to an address with a '%', eg fe80::71a3:2b00:ddd3:753f%16
     * 
     * If there is no zone or scope id, returns null
     * 
     * @return
     * @return {string}
     */
    public getZone() : string {
        return this.zone;
    }

    public removeZone() : IPv6Address {
        return this.getDefaultCreator().createAddress$inet_ipaddr_ipv6_IPv6AddressSection(this.getSection());
    }

    hasNoValueCache() : boolean {
        if(this.valueCache == null) {
            {
                if(this.valueCache == null) {
                    this.valueCache = new IPv6Address.ValueCache();
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 
     * @return {Inet6Address}
     */
    public toInetAddress() : Inet6Address {
        if(this.hasZone()) {
            let result : Inet6Address;
            if(this.hasNoValueCache() || (result = this.valueCache.inetAddress) == null) {
                this.valueCache.inetAddress = result = <Inet6Address>this.toInetAddressImpl(this.getBytes());
            }
            return result;
        }
        return <Inet6Address>super.toUpperInetAddress();
    }

    /**
     * 
     * @return {Inet6Address}
     */
    public toUpperInetAddress() : Inet6Address {
        if(this.hasZone()) {
            let result : Inet6Address;
            if(this.hasNoValueCache() || (result = this.valueCache.upperInetAddress) == null) {
                this.valueCache.upperInetAddress = result = this.toInetAddressImpl(this.getUpperBytes());
            }
            return result;
        }
        return <Inet6Address>super.toInetAddress();
    }

    /**
     * 
     * @param {Array} bytes
     * @return {Inet6Address}
     */
    toInetAddressImpl(bytes : number[]) : Inet6Address {
        let result : InetAddress;
        try {
            if(this.hasZone()) {
                try {
                    let scopeId : number = parseFloat(this.zone);
                    result = Inet6Address.getByAddress(null, bytes, scopeId);
                } catch(e) {
                    result = InetAddress.getByName(this.toNormalizedString());
                };
            } else {
                result = InetAddress.getByAddress(bytes);
            }
        } catch(e) {
            result = null;
        };
        return <Inet6Address>result;
    }

    /**
     * 
     * @return {number}
     */
    public hashCode() : number {
        let result : number = /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this));
        if(this.hasZone()) {
            result *= /* hashCode */(<any>((o: any) => { if(o.hashCode) { return o.hashCode(); } else { return o.toString(); } })(this.zone));
        }
        return result;
    }

    public isSameAddress$inet_ipaddr_Address(other : Address) : boolean {
        return (other != null && other instanceof <any>IPAddress) && this.isSameAddress$inet_ipaddr_Address(<IPAddress>other);
    }

    public isSameAddress$inet_ipaddr_IPAddress(other : IPAddress) : boolean {
        if(super.isSameAddress$inet_ipaddr_IPAddress(other)) {
            let otherIPv6Address : IPv6Address = other.toIPv6();
            let otherZone : string = otherIPv6Address.zone;
            return Objects.equals(this.zone, otherZone);
        }
        return false;
    }

    /**
     * 
     * @param {IPAddress} other
     * @return {boolean}
     */
    public isSameAddress(other? : any) : any {
        if(((other != null && other instanceof <any>IPAddress) || other === null)) {
            return <any>this.isSameAddress$inet_ipaddr_IPAddress(other);
        } else if(((other != null && other instanceof <any>Address) || other === null)) {
            return <any>this.isSameAddress$inet_ipaddr_Address(other);
        } else throw new Error('invalid overload');
    }

    /**
     * 
     * @param {Address} other
     * @return {boolean} whether this subnet contains the given address
     */
    public contains(other : Address) : boolean {
        if(super.contains(other)) {
            if(other !== this) {
                if(this.zone != null) {
                    let otherIPv6Address : IPv6Address = <IPv6Address>other;
                    let otherZone : string = otherIPv6Address.zone;
                    return Objects.equals(this.zone, otherZone);
                }
            }
            return true;
        }
        return false;
    }

    /**
     * 
     * @return {IPAddressStringParameters}
     */
    createFromStringParams() : IPAddressStringParameters {
        return new IPAddressStringParameters.Builder().getIPv4AddressParametersBuilder().setNetwork(this.getIPv4Network()).getParentBuilder().getIPv6AddressParametersBuilder().setNetwork(this.getNetwork()).getParentBuilder().toParams();
    }

    hasNoStringCache() : boolean {
        if(this.stringCache == null) {
            {
                if(this.stringCache == null) {
                    if(this.hasZone()) {
                        this.stringCache = new IPv6AddressSection.IPv6StringCache();
                        return true;
                    } else {
                        let section : IPv6AddressSection = this.getSection();
                        let result : boolean = section.hasNoStringCache();
                        this.stringCache = section.getStringCache();
                        return result;
                    }
                }
            };
        }
        return false;
    }

    public toMixedString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.mixedString) == null) {
            if(this.hasZone()) {
                this.stringCache.mixedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.mixedParams_$LI$());
            } else {
                result = this.getSection().toMixedString();
            }
        }
        return result;
    }

    /**
     * This produces a canonical string.
     * 
     * RFC 5952 describes canonical representations.
     * http://en.wikipedia.org/wiki/IPv6_address#Recommended_representation_as_text
     * http://tools.ietf.org/html/rfc5952
     * 
     * If this has a prefix length, that will be included in the string.
     * @return {string}
     */
    public toCanonicalString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.canonicalString) == null) {
            if(this.hasZone()) {
                this.stringCache.canonicalString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.canonicalParams_$LI$());
            } else {
                result = this.getSection().toCanonicalString();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toFullString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.fullString) == null) {
            if(this.hasZone()) {
                this.stringCache.fullString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.fullParams_$LI$());
            } else {
                result = this.getSection().toFullString();
            }
        }
        return result;
    }

    public static toNormalizedString(prefixConfiguration? : any, lowerValueProvider? : any, upperValueProvider? : any, prefixLength? : any, segmentCount? : any, bytesPerSegment? : any, bitsPerSegment? : any, segmentMaxValue? : any, separator? : any, radix? : any, zone? : any, builder? : any) : any {
        if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((builder != null && (builder instanceof Object)) || builder === null)) {
            super.toNormalizedString(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone, builder);
        } else if(((typeof prefixConfiguration === 'number') || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((typeof segmentCount === 'number') || segmentCount === null) && ((typeof bytesPerSegment === 'number') || bytesPerSegment === null) && ((typeof bitsPerSegment === 'number') || bitsPerSegment === null) && ((typeof segmentMaxValue === 'number') || segmentMaxValue === null) && ((typeof separator === 'string') || separator === null) && ((typeof radix === 'number') || radix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && builder === undefined) {
            return <any>IPv6Address.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount, bytesPerSegment, bitsPerSegment, segmentMaxValue, separator, radix, zone);
        } else if(((prefixConfiguration != null && prefixConfiguration instanceof <any>IPv6AddressNetwork) || prefixConfiguration === null) && ((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefixLength === 'number') || prefixLength === null) && ((segmentCount != null && (segmentCount["__interfaces"] != null && segmentCount["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || segmentCount.constructor != null && segmentCount.constructor["__interfaces"] != null && segmentCount.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof segmentCount === "string")) || segmentCount === null) && bytesPerSegment === undefined && bitsPerSegment === undefined && segmentMaxValue === undefined && separator === undefined && radix === undefined && zone === undefined && builder === undefined) {
            return <any>IPv6Address.toNormalizedString$inet_ipaddr_ipv6_IPv6AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(prefixConfiguration, lowerValueProvider, upperValueProvider, prefixLength, segmentCount);
        } else throw new Error('invalid overload');
    }

    public static toNormalizedString$inet_ipaddr_ipv6_IPv6AddressNetwork$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$java_lang_CharSequence(network : IPv6AddressNetwork, lowerValueProvider : Address.SegmentValueProvider, upperValueProvider : Address.SegmentValueProvider, prefixLength : number, zone : any) : string {
        return IPAddress.toNormalizedString$inet_ipaddr_AddressNetwork_PrefixConfiguration$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer$int$int$int$int$char$int$java_lang_CharSequence(network.getPrefixConfiguration(), lowerValueProvider, upperValueProvider, prefixLength, IPv6Address.SEGMENT_COUNT, IPv6Address.BYTES_PER_SEGMENT, IPv6Address.BITS_PER_SEGMENT, IPv6Address.MAX_VALUE_PER_SEGMENT, IPv6Address.SEGMENT_SEPARATOR, IPv6Address.DEFAULT_TEXTUAL_RADIX, zone);
    }

    public toNormalizedString(stringParams? : any, joinCount? : any) : any {
        if(((typeof stringParams === 'boolean') || stringParams === null) && ((joinCount != null && joinCount instanceof <any>IPv6AddressSection.IPv6StringOptions) || joinCount === null)) {
            return <any>this.toNormalizedString$boolean$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(stringParams, joinCount);
        } else if(((stringParams != null && stringParams instanceof <any>IPv6AddressSection.IPv6StringOptions) || stringParams === null) && joinCount === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(stringParams);
        } else if(((stringParams != null && stringParams instanceof <any>IPAddressSection.IPStringOptions) || stringParams === null) && joinCount === undefined) {
            return <any>this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(stringParams);
        } else if(stringParams === undefined && joinCount === undefined) {
            return <any>this.toNormalizedString$();
        } else throw new Error('invalid overload');
    }

    public toNormalizedString$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.normalizedString) == null) {
            if(this.hasZone()) {
                this.stringCache.normalizedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.normalizedParams_$LI$());
            } else {
                result = this.getSection().toNormalizedString();
            }
        }
        return result;
    }

    /**
     * This compresses the maximum number of zeros and/or host segments with the IPv6 compression notation '::'
     * @return {string}
     */
    public toCompressedString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.compressedString) == null) {
            if(this.hasZone()) {
                this.stringCache.compressedString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.compressedParams_$LI$());
            } else {
                result = this.getSection().toCompressedString();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toSubnetString() : string {
        return this.toPrefixLengthString();
    }

    /**
     * 
     * @return {string}
     */
    public toNormalizedWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.normalizedWildcardString) == null) {
            if(this.hasZone()) {
                this.stringCache.normalizedWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardNormalizedParams_$LI$());
            } else {
                result = this.getSection().toNormalizedWildcardString();
            }
        }
        return result;
    }

    /**
     * The base 85 string is described by RFC 1924
     * @return
     * @return {string}
     */
    public toBase85String() : string {
        let originator : IPAddressString = this.getAddressfromString();
        if(originator != null && (!this.isPrefixed() || this.getNetworkPrefixLength() === IPv6Address.BIT_COUNT) && originator.isBase85IPv6()) {
            return originator.toString();
        }
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.base85String) == null) {
            if(this.hasZone()) {
                this.stringCache.base85String = result = this.getSection().toBase85String$java_lang_String(this.getZone());
            } else {
                result = this.getSection().toBase85String();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toCanonicalWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.canonicalWildcardString) == null) {
            if(this.hasZone()) {
                this.stringCache.canonicalWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardCanonicalParams_$LI$());
            } else {
                result = this.getSection().toCanonicalWildcardString();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toCompressedWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.compressedWildcardString) == null) {
            if(this.hasZone()) {
                this.stringCache.compressedWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.wildcardCompressedParams_$LI$());
            } else {
                result = this.getSection().toCompressedWildcardString();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toSQLWildcardString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.sqlWildcardString) == null) {
            if(this.hasZone()) {
                this.stringCache.sqlWildcardString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.sqlWildcardParams_$LI$());
            } else {
                result = this.getSection().toSQLWildcardString();
            }
        }
        return result;
    }

    public toHexString(with0xPrefix? : any, zone? : any) : any {
        if(((typeof with0xPrefix === 'boolean') || with0xPrefix === null) && zone === undefined) {
            return <any>this.toHexString$boolean(with0xPrefix);
        } else throw new Error('invalid overload');
    }

    public toHexString$boolean(with0xPrefix : boolean) : string {
        let result : string;
        if(this.hasNoStringCache() || (result = (with0xPrefix?this.stringCache.hexStringPrefixed:this.stringCache.hexString)) == null) {
            if(this.hasZone()) {
                result = this.getSection().toHexString$boolean$java_lang_CharSequence(with0xPrefix, this.zone);
                if(with0xPrefix) {
                    this.stringCache.hexStringPrefixed = result;
                } else {
                    this.stringCache.hexString = result;
                }
            } else {
                result = this.getSection().toHexString$boolean(with0xPrefix);
            }
        }
        return result;
    }

    public toBinaryString(zone? : any) : any {
        if(zone === undefined) {
            return <any>this.toBinaryString$();
        } else throw new Error('invalid overload');
    }

    public toBinaryString$() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.binaryString) == null) {
            if(this.hasZone()) {
                result = this.getSection().toBinaryString$java_lang_CharSequence(this.zone);
                this.stringCache.binaryString = result;
            } else {
                result = this.getSection().toBinaryString();
            }
        }
        return result;
    }

    public toOctalString(with0Prefix? : any, zone? : any) : any {
        if(((typeof with0Prefix === 'boolean') || with0Prefix === null) && zone === undefined) {
            return <any>this.toOctalString$boolean(with0Prefix);
        } else throw new Error('invalid overload');
    }

    public toOctalString$boolean(with0Prefix : boolean) : string {
        let result : string;
        if(this.hasNoStringCache() || (result = (with0Prefix?this.stringCache.octalStringPrefixed:this.stringCache.octalString)) == null) {
            if(this.hasZone()) {
                result = this.getSection().toOctalString$boolean$java_lang_CharSequence(with0Prefix, this.zone);
                if(with0Prefix) {
                    this.stringCache.octalStringPrefixed = result;
                } else {
                    this.stringCache.octalString = result;
                }
            } else {
                result = this.getSection().toOctalString$boolean(with0Prefix);
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toPrefixLengthString() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.networkPrefixLengthString) == null) {
            if(this.hasZone()) {
                this.stringCache.networkPrefixLengthString = result = this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(IPv6AddressSection.IPv6StringCache.networkPrefixLengthParams_$LI$());
            } else {
                result = this.getSection().toPrefixLengthString();
            }
        }
        return result;
    }

    /**
     * 
     * @return {string}
     */
    public toConvertedString() : string {
        if(this.isIPv4Convertible()) {
            return this.toMixedString();
        }
        return this.toNormalizedString();
    }

    public toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(params : IPAddressSection.IPStringOptions) : string {
        return this.getSection().toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(params, this.zone);
    }

    public toNormalizedString$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(params : IPv6AddressSection.IPv6StringOptions) : string {
        return this.getSection().toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(params, this.zone);
    }

    public toNormalizedString$boolean$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringOptions(keepMixed : boolean, params : IPv6AddressSection.IPv6StringOptions) : string {
        if(keepMixed && this.fromString != null && this.getAddressfromString().isMixedIPv6() && !params.makeMixed()) {
            params = new IPv6AddressSection.IPv6StringOptions(params.base, params.expandSegments, params.wildcardOption, params.wildcards, params.segmentStrPrefix, true, params.ipv4Opts, params.compressOptions, params.separator, params.zoneSeparator, params.addrLabel, params.addrSuffix, params.reverse, params.splitDigits, params.uppercase);
        }
        return this.toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions(params);
    }

    /**
     * 
     * @return {string}
     */
    public toUNCHostName() : string {
        let result : string;
        if(this.hasNoStringCache() || (result = this.stringCache.uncString) == null) {
            let newZone : string;
            if(this.zone != null) {
                newZone = /* replace *//* replace */this.zone.split(IPv6Address.ZONE_SEPARATOR).join(IPv6Address.UNC_ZONE_SEPARATOR).split(IPv6Address.SEGMENT_SEPARATOR).join(IPv6Address.UNC_SEGMENT_SEPARATOR);
            } else {
                newZone = null;
            }
            this.stringCache.uncString = result = this.getSection().toNormalizedString$inet_ipaddr_IPAddressSection_IPStringOptions$java_lang_CharSequence(IPv6AddressSection.IPv6StringCache.uncParams_$LI$(), newZone);
        }
        return result;
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toStandardStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.STANDARD_OPTS_$LI$());
    }

    /**
     * 
     * @return {IPAddressPartStringCollection}
     */
    public toAllStringCollection() : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.ALL_OPTS_$LI$());
    }

    public toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts : IPAddressSection.IPStringBuilderOptions) : IPAddressPartStringCollection {
        return this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(IPv6AddressSection.IPv6StringBuilderOptions.from(opts));
    }

    getConverted(opts : IPv6AddressSection.IPv6StringBuilderOptions) : IPv4Address {
        if(!this.hasZone() && opts.includes(IPv6AddressSection.IPv6StringBuilderOptions.IPV4_CONVERSIONS)) {
            let converter : IPv4Address.IPv4AddressConverter = opts.converter;
            return converter.toIPv4(this);
        }
        return null;
    }

    public toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts : IPv6AddressSection.IPv6StringBuilderOptions) : IPAddressPartStringCollection {
        let coll : IPv6AddressSection.IPv6StringCollection = this.getSection().toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions$java_lang_CharSequence(opts, this.zone);
        let ipv4Addr : IPv4Address = this.getConverted(opts);
        if(ipv4Addr != null) {
            let ipv4StringCollection : IPAddressPartStringCollection = ipv4Addr.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts.ipv4ConverterOptions);
            coll.addAll(ipv4StringCollection);
        }
        return coll;
    }

    public toStringCollection(opts? : any) : any {
        if(((opts != null && opts instanceof <any>IPv6AddressSection.IPv6StringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_ipv6_IPv6AddressSection_IPv6StringBuilderOptions(opts);
        } else if(((opts != null && opts instanceof <any>IPAddressSection.IPStringBuilderOptions) || opts === null)) {
            return <any>this.toStringCollection$inet_ipaddr_IPAddressSection_IPStringBuilderOptions(opts);
        } else throw new Error('invalid overload');
    }
}
IPv6Address["__class"] = "inet.ipaddr.ipv6.IPv6Address";
IPv6Address["__interfaces"] = ["inet.ipaddr.format.AddressStringDivisionSeries","inet.ipaddr.IPAddressSegmentSeries","inet.ipaddr.format.AddressDivisionSeries","inet.ipaddr.AddressComponent","inet.ipaddr.AddressSegmentSeries","inet.ipaddr.format.AddressItem","java.lang.Comparable","java.lang.Iterable","java.io.Serializable"];



export namespace IPv6Address {

    export class ValueCache {
        public inetAddress : Inet6Address;

        public upperInetAddress : Inet6Address;

        constructor() {
            if(this.inetAddress===undefined) this.inetAddress = null;
            if(this.upperInetAddress===undefined) this.upperInetAddress = null;
        }
    }
    ValueCache["__class"] = "inet.ipaddr.ipv6.IPv6Address.ValueCache";


    /**
     * @custom.core
     * @author sfoley
     * @class
     */
    export interface IPv6AddressConverter {
        /**
         * If the given address is IPv6, or can be converted to IPv6, returns that {@link IPv6Address}.  Otherwise, returns null.
         * @param {IPAddress} address
         * @return {IPv6Address}
         */
        toIPv6(address : IPAddress) : IPv6Address;
    }

    export class IPv6Address$0 extends IPv6AddressNetwork.IPv6AddressCreator {
        public __parent: any;
        static serialVersionUID : number = 4;

        public createAddressInternal(bytes? : any, prefix? : any, zone? : any, fromHost? : any) : any {
            if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && ((fromHost != null && fromHost instanceof <any>HostName) || fromHost === null)) {
                super.createAddressInternal(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && ((typeof fromHost === 'number') || fromHost === null)) {
                super.createAddressInternal(bytes, prefix, zone, fromHost);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && zone instanceof <any>HostName) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$inet_ipaddr_HostName(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer$java_lang_CharSequence(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && ((typeof zone === 'number') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$inet_ipaddr_HostIdentifierString$java_lang_Integer(bytes, prefix, zone);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$java_lang_CharSequence$inet_ipaddr_HostIdentifierString(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && ((typeof zone === 'boolean') || zone === null) && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer$boolean(bytes, prefix, zone);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>IPv6AddressSection) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSection$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A$java_lang_Integer(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(typeof bytes[0] === 'number'))) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof prefix === "string")) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$byte_A$java_lang_CharSequence(bytes, prefix);
            } else if(((bytes != null) || bytes === null) && ((prefix != null && (prefix["__interfaces"] != null && prefix["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0 || prefix.constructor != null && prefix.constructor["__interfaces"] != null && prefix.constructor["__interfaces"].indexOf("inet.ipaddr.HostIdentifierString") >= 0)) || prefix === null) && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSection$inet_ipaddr_HostIdentifierString(bytes, prefix);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null && bytes[0] instanceof <any>IPv6AddressSegment))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_IPAddressSegment_A(bytes);
            } else if(((bytes != null && bytes instanceof <any>Array && (bytes.length==0 || bytes[0] == null ||(bytes[0] != null))) || bytes === null) && prefix === undefined && zone === undefined && fromHost === undefined) {
                return <any>this.createAddressInternal$inet_ipaddr_AddressSegment_A(bytes);
            } else throw new Error('invalid overload');
        }

        createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A(segments : IPv6AddressSegment[]) : IPv6Address {
            let creator : IPv6AddressNetwork.IPv6AddressCreator = this.__parent.getDefaultCreator();
            return creator.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSegment_A$java_lang_CharSequence(segments, this.__parent.zone);
        }

        public createAddress(lowerValueProvider? : any, upperValueProvider? : any, prefix? : any, zone? : any) : any {
            if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && ((zone != null && (zone["__interfaces"] != null && zone["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || zone.constructor != null && zone.constructor["__interfaces"] != null && zone.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof zone === "string")) || zone === null)) {
                super.createAddress(lowerValueProvider, upperValueProvider, prefix, zone);
            } else if(((lowerValueProvider != null && (lowerValueProvider["__interfaces"] != null && lowerValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || lowerValueProvider.constructor != null && lowerValueProvider.constructor["__interfaces"] != null && lowerValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("inet.ipaddr.Address.SegmentValueProvider") >= 0)) || upperValueProvider === null) && ((typeof prefix === 'number') || prefix === null) && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_Address_SegmentValueProvider$inet_ipaddr_Address_SegmentValueProvider$java_lang_Integer(lowerValueProvider, upperValueProvider, prefix);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>IPv6AddressSection) || lowerValueProvider === null) && ((upperValueProvider != null && (upperValueProvider["__interfaces"] != null && upperValueProvider["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || upperValueProvider.constructor != null && upperValueProvider.constructor["__interfaces"] != null && upperValueProvider.constructor["__interfaces"].indexOf("java.lang.CharSequence") >= 0 || typeof upperValueProvider === "string")) || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && ((typeof upperValueProvider === 'number') || upperValueProvider === null) && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A$java_lang_Integer(lowerValueProvider, upperValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>IPv6AddressSection) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_ipv6_IPv6AddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Inet6Address) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$java_net_Inet6Address(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(lowerValueProvider[0] != null))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSegment_A(lowerValueProvider);
            } else if(((lowerValueProvider != null && lowerValueProvider instanceof <any>Array && (lowerValueProvider.length==0 || lowerValueProvider[0] == null ||(typeof lowerValueProvider[0] === 'number'))) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$byte_A(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$java_net_InetAddress(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_IPAddressSection(lowerValueProvider);
            } else if(((lowerValueProvider != null) || lowerValueProvider === null) && upperValueProvider === undefined && prefix === undefined && zone === undefined) {
                return <any>this.createAddress$inet_ipaddr_AddressSection(lowerValueProvider);
            } else throw new Error('invalid overload');
        }

        public createAddress$inet_ipaddr_ipv6_IPv6AddressSection(section : IPv6AddressSection) : IPv6Address {
            let creator : IPv6AddressNetwork.IPv6AddressCreator = this.__parent.getDefaultCreator();
            return creator.createAddressInternal$inet_ipaddr_ipv6_IPv6AddressSection$java_lang_CharSequence(section, this.__parent.zone);
        }

        constructor(__parent: any, __arg0: any) {
            super(__arg0);
            this.__parent = __parent;
        }
    }
    IPv6Address$0["__interfaces"] = ["inet.ipaddr.AddressNetwork.AddressSegmentCreator","java.io.Serializable"];


}




IPv6Address.UNC_RANGE_SEPARATOR_STR_$LI$();

IPv6Address.UNC_RANGE_SEPARATOR_$LI$();
